import { ValueType } from 'realgrid'

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'titleNm',
            dataType: ValueType.TEXT, // 상품
        },
        {
            fieldName: 'dealcoCnt',
            dataType: ValueType.NUMBER, // 대상거래처 수
        },
        {
            fieldName: 'totalAsgnQty',
            dataType: ValueType.NUMBER, // 배정수량총계
        },
        {
            fieldName: 'totalAutoAsgnQty',
            dataType: ValueType.NUMBER, // 자동배정수량총계
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, // 비고
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT, // 처리자
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'reqStCd',
            dataType: ValueType.TEXT, // 요청상태코드
        },
        {
            fieldName: 'reqStNm',
            dataType: ValueType.TEXT, // 요청상태명
        },
        {
            fieldName: 'strdDt',
            dataType: ValueType.TEXT, // 시뮬레이션일시
        },
        {
            fieldName: 'strdTs',
            dataType: ValueType.NUMBER, // 시뮬레이션차수
        },
    ],
    columns: [
        {
            name: 'titleNm',
            fieldName: 'titleNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealcoCnt',
            fieldName: 'dealcoCnt',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '대상거래처',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'totalAsgnQty',
            fieldName: 'totalAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '배정수량총계',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'totalAutoAsgnQty',
            fieldName: 'totalAutoAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '자동배정수량총계',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'reqStCd',
            fieldName: 'reqStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청상태코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'reqStNm',
            fieldName: 'reqStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청상태',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'strdDt',
            fieldName: 'strdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시뮬레이션일시',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'strdTs',
            fieldName: 'strdTs',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '시뮬레이션차수',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
    ],
}
