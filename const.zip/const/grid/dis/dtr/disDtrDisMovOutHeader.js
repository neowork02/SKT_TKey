import { ValueType } from 'realgrid'

export const DisDtrDisMovOutGRID_HEADER = {
    fields: [
        {
            fieldName: 'outOrgTreeNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgTreeNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'movOutQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outFixDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'outFixReport',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixReport',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOprId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'inOprId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'outOrgTreeNm',
            fieldName: 'outOrgTreeNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고조직',
                showTooltip: false,
            },
            width: '400',
        },
        {
            name: 'outDealSktCd',
            fieldName: 'outDealSktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outDealcoCd',
            fieldName: 'outDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'inOrgTreeNm',
            fieldName: 'inOrgTreeNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고조직',
                showTooltip: false,
            },
            width: '400',
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'movOutQty',
            fieldName: 'movOutQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고수량',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outFixDt',
            fieldName: 'outFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
            width: '100',
        },
        {
            name: 'outFixReport',
            fieldName: 'outFixReport',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고증',
                showTooltip: false,
            },
            editable: false,
            renderer: {
                type: 'button',
            },
            width: '100',
        },
        // {
        //     name: 'inFixReport',
        //     fieldName: 'inFixReport',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '미입고출고증',
        //         showTooltip: false,
        //     },
        //     editable: false,
        //     renderer: {
        //         type: 'button',
        //     },
        //     width: '100',
        // },
        {
            name: 'outOprId',
            fieldName: 'outOprId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처리자',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inFixDt',
            fieldName: 'inFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
            width: '100',
        },
        {
            name: 'inOprId',
            fieldName: 'inOprId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처리자',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outMgmtNo',
            fieldName: 'outMgmtNo',
            visible: false,
            type: 'data',
        },
        {
            name: 'outOrgCd',
            fieldName: 'outOrgCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'inOrgCd',
            fieldName: 'inOrgCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'outOrgNm',
            fieldName: 'outOrgNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'inOrgNm',
            fieldName: 'inOrgNm',
            visible: false,
            type: 'data',
        },
    ],
}
