import { ValueType } from 'realgrid'

export const GRIDHEADER = {
    fields: [
        {
            fieldName: 'saleDtm',
            dataType: ValueType.TEXT, // 개통일시
            //     dataType: 'datetime',
            //     datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, // 일반판매번호
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT, // 일반판매변경순번
        },
        {
            fieldName: 'saleStCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, // 서비스관리번호
        },
        {
            fieldName: 'svcTypCd',
            dataType: ValueType.TEXT, // 개통구분
        },
        {
            fieldName: 'svcTypNm',
            dataType: ValueType.TEXT, // 개통구분
        },
        {
            fieldName: 'cntrctMgmtNum',
            dataType: ValueType.TEXT, // 계약관리번호
        },
        {
            fieldName: 'eqpProdNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'eqpSerNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'usimProdNm',
            dataType: ValueType.TEXT, // USIM모델명
        },
        {
            fieldName: 'usimSerNo',
            dataType: ValueType.TEXT, // USIM일련번호
        },
    ],
    columns: [
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            width: '130',
            header: {
                text: '개통일시',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'svcTypNm',
            fieldName: 'svcTypNm',
            type: 'data',
            width: '200',
            header: {
                text: '개통구분',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'eqpProdNm',
            fieldName: 'eqpProdNm',
            type: 'data',
            width: '120',
            //styleName: 'left-column',
            header: {
                text: '모델명',
                showTooltip: true,
            },
        },
        {
            name: 'eqpSerNum',
            fieldName: 'eqpSerNum',
            type: 'data',
            width: '100',
            //           styleName: 'left-column',
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'usimProdNm',
            fieldName: 'usimProdNm',
            type: 'data',
            width: '100',
            //  styleName: 'left-column',
            header: {
                text: 'USIM모델명',
                showTooltip: true,
            },
        },
        {
            name: 'usimSerNo',
            fieldName: 'usimSerNo',
            type: 'data',
            width: '100',
            //  styleName: 'left-column',
            header: {
                text: 'USIM일련번호',
                showTooltip: true,
            },
        },
    ],
}
