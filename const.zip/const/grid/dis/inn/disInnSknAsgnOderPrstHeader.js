import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'ordDt',
            dataType: ValueType.TEXT, //주문일
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, //주문시각
        },
        {
            fieldName: 'sknTrmsDtm',
            dataType: ValueType.TEXT, //전송시각
        },
        {
            fieldName: 'fidcDisYn',
            dataType: ValueType.TEXT, //수탁재고
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, //레벨0조직코드
        },
        {
            fieldName: 'lvOrgNm',
            dataType: ValueType.TEXT, //레벨0조직명
        },
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT, //레벨1조직코드
        },
        {
            fieldName: 'orgId2Nm',
            dataType: ValueType.TEXT, //레벨1조직명
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, //레벨2조직코드
        },
        {
            fieldName: 'orgId3Nm',
            dataType: ValueType.TEXT, //레벨2조직명
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT, //레벨3조직코드
        },
        {
            fieldName: 'newOrgNm',
            dataType: ValueType.TEXT, //레벨3조직명
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직명
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'dealcoShopCd',
            dataType: ValueType.TEXT, //거래처매장코드
        },
        {
            fieldName: 'dealSt',
            dataType: ValueType.TEXT, //거래상태
        },
        {
            fieldName: 'sknDlvDealcoCd',
            dataType: ValueType.TEXT, //배송지코드
        },
        {
            fieldName: 'sknDelvDealcdNm',
            dataType: ValueType.TEXT, //배송지명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'ordAsgnQty',
            dataType: ValueType.TEXT, //수량
        },
        {
            fieldName: 'realPrchsPrc',
            dataType: ValueType.TEXT, //단가
        },
        {
            fieldName: 'sknTrmsYn',
            dataType: ValueType.TEXT, //전송여부
        },
    ],
    columns: [
        {
            name: 'ordDt',
            fieldName: 'ordDt',
            type: 'data',
            header: {
                text: '주문일',
                showTooltip: false,
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            header: {
                text: '주문시각',
                showTooltip: false,
            },
        },
        {
            name: 'sknTrmsDtm',
            fieldName: 'sknTrmsDtm',
            type: 'data',
            header: {
                text: '전송시각',
                showTooltip: false,
            },
        },
        {
            name: 'fidcDisYn',
            fieldName: 'fidcDisYn',
            type: 'data',
            header: {
                text: '수탁재고',
                showTooltip: false,
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: {
                text: '대리점명',
                showTooltip: false,
            },
        },
        // {
        //     name: 'orgCd',
        //     fieldName: 'orgCd',
        //     type: 'data',
        //     header: {
        //         text: '조직',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            header: {
                text: '조직명',
                showTooltip: false,
            },
        },
        // {
        //     name: 'orgId2Nm',
        //     fieldName: 'orgId2Nm',
        //     type: 'data',
        //     header: {
        //         text: '관리조직',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: 'orgId3Nm',
        //     fieldName: 'orgId3Nm',
        //     type: 'data',
        //     header: {
        //         text: '사업팀(영업팀)',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: 'newOrgNm',
        //     fieldName: 'newOrgNm',
        //     type: 'data',
        //     header: {
        //         text: 'PT(센터)',
        //         // text: '조직',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'dealcoShopCd',
            fieldName: 'dealcoShopCd',
            type: 'data',
            header: {
                text: '거래처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealSt',
            fieldName: 'dealSt',
            type: 'data',
            header: {
                text: '거래상태',
                showTooltip: false,
            },
        },
        {
            name: 'sknDlvDealcoCd',
            fieldName: 'sknDlvDealcoCd',
            type: 'data',
            header: {
                text: '배송지코드',
                showTooltip: false,
            },
        },
        {
            name: 'sknDelvDealcdNm',
            fieldName: 'sknDelvDealcdNm',
            type: 'data',
            width: '150',
            header: {
                text: '배송지명',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            header: {
                text: '상품명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'ordAsgnQty',
            fieldName: 'ordAsgnQty',
            type: 'data',
            header: {
                text: '수량',
                showTooltip: false,
            },
        },
        {
            name: 'realPrchsPrc',
            fieldName: 'realPrchsPrc',
            type: 'data',
            header: {
                text: '단가',
                showTooltip: false,
            },
        },
        {
            name: 'sknTrmsYn',
            fieldName: 'sknTrmsYn',
            type: 'data',
            header: {
                text: '전송여부',
                showTooltip: false,
            },
        },
    ],
}
