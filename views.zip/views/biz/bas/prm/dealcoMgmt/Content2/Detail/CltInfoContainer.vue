<template>
    <div v-if="this.isGridCltInfo1">
        <!-- SubTit  -->
        <div class="stitHead">
            <h4 class="subTit">담보정보</h4>
        </div>
        <!-- //SubTit -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div3">
                    <TCComComboBox
                        v-model="cltInfo.crdtTypCd"
                        labelName="여신유형"
                        :eRequired="true"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :itemList="crdTyp"
                        @change="changeCrdTyp"
                        :disabled="isDisabledAdd"
                        @input="setData"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div3">
                    <TCComComboBox
                        v-model="cltInfo.grtInstCd"
                        labelName="보증기관"
                        :eRequired="true"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :itemList="zbasC00200"
                        :filterFunc="filterGrtInst"
                        @change="changeGrtInst"
                        :disabled="isDisabledAdd"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="cltInfo.dealCoNmMst"
                        :codeVal.sync="cltInfo.mstDealcoCd"
                        :eRequired="isDataBtnCrdDeal"
                        labelName="공유담보거래처"
                        placeholder="선택해주세요"
                        :disabledAfter="true"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                        :disabled="
                            isDisabledAdd ? isDisabledAdd : !isDataBtnCrdDeal
                        "
                    />
                    <BasBcoCtlDealcosPopup
                        v-if="showBasBcoDealcos"
                        :parentParam="cltSearchFrom"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                        :disabled="isDisabledAdd"
                    />
                </div>
                <!-- //item 1-3 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div3">
                    <TCComDatePicker
                        calType="D"
                        v-model="cltInfo.setDt"
                        labelName="설정일"
                        :disabled="isDisabledAdd"
                        @input="setData"
                    />
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div3">
                    <TCComDatePicker
                        calType="D"
                        v-model="cltInfo.expirDt"
                        labelName="만료일"
                        :disabled="isDisabledAdd"
                        @input="setData"
                    />
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div3">
                    <TCComInput
                        labelName="담보금액"
                        v-model="cltInfo.mrtgAmt"
                        :disabled="isDisabledAdd"
                        @input="setData"
                    />
                </div>
                <!-- //item 2-3 -->
            </div>
            <!-- //Search_line 2 -->
            <!-- Search_line 3 -->
            <div class="searchform">
                <!-- item 3-1 -->
                <div class="formitem div3">
                    <TCComInput
                        labelName="담보잔액"
                        v-model="cltInfo.mrtgBlc"
                        :disabled="true"
                        @input="setData"
                    />
                </div>
                <!-- //item 3-1 -->
                <!-- item 3-2-->
                <div class="formitem div3">
                    <TCComInput
                        labelName="수수료"
                        v-model="cltInfo.cmmsAmt"
                        :disabled="isDisabledAdd"
                        @input="setData"
                    />
                </div>
                <!-- //item 3-2 -->
                <!-- item 3-3 -->
                <div class="formitem div3">
                    <TCComInput
                        labelName="담보설정금액"
                        :eRequired="true"
                        v-model="cltInfo.mrtgSetAmt"
                        :disabled="isDisabledAdd"
                        @input="setData"
                    />
                    <!-- arrayType_btnType -->
                    <!--
                    <div class="arrayType btnType">
                        <div class="colinput">
                            <TCComInput
                                labelName="담보설정금액"
                                :eRequired="true"
                                v-model="cltInfo.mrtgSetAmt"
                                :disabled="isDisabledAdd"
                                @input="setData"
                            />
                        </div>
                        <div class="colbtn">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="임시저장"
                                :objAuth="objAuth"
                                @click="tempSave"
                            />
                        </div>
                        <div>
                        -->

                    <!-- //arrayType_btnType -->
                </div>
                <!-- //item 3-3 -->
            </div>
            <!-- //Search_line 3 -->
            <!-- Search_line 4 -->
            <div class="searchform">
                <!-- item 4-1 -->
                <div class="formitem div1">
                    <!-- arrayType -->
                    <div class="arrayType">
                        <div class="col75">
                            <TCComInput
                                v-model="cltInfo.setBasisDesc"
                                labelName="설정근거"
                                :eRequired="true"
                                :disabled="isDisabledAdd"
                                @input="setData"
                            />
                        </div>
                        <div class="col0">
                            <span class="basicTxt"
                                >(증권번호/계좌번호/질권주소 등)</span
                            >
                        </div>
                    </div>
                    <!-- //arrayType -->
                </div>
                <!-- //item 4-1 -->
            </div>
            <!-- //Search_line 4 -->
            <!-- Search_line 5 -->
            <div class="searchform">
                <!-- item 5-1 -->
                <div class="formitem div1">
                    <TCComTextArea
                        labelName="비고"
                        v-model="cltInfo.crdRmks"
                        :disabled="isDisabledAdd"
                        @input="setData"
                    />
                </div>
                <!-- //item 5-1 -->
            </div>
            <!-- //Search_line 5 -->
            <!--
            <div class="searchform">
                
                <div class="formitem div1">
                    <div class="rightArea">
                        <span class="inner">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="임시저장"
                                :objAuth="objAuth"
                                @click="tempSave"
                            />
                        </span>
                    </div>
                </div>
                
            </div>
          -->
        </div>
        <!-- //Search_div -->

        <!-- SubTit  -->

        <div class="stitHead">
            <span class="stitBtnRef notit mb10">
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_filesave"
                    labelName="입력저장"
                    :objAuth="objAuth"
                    @click="tempSave"
                />
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowadd"
                    labelName="행추가"
                    @click="gridAddRowBtn"
                />
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowdel"
                    labelName="행삭제"
                    @click="gridChkDelRowBtn"
                />
            </span>
        </div>
        <!-- //SubTit -->
        <TCRealGrid
            id="gridCltInfo"
            ref="gridCltInfo"
            :editable="false"
            :movable="false"
            :columnMovable="false"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
        <p class="infoTxt">
            <span class="color-red">
                수정/등록 후 입력저장 버튼을 눌러야 반영이 됩니다.
            </span>
        </p>
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/tDealcoMgmt/helpers'
import _ from 'lodash'
import { GRID_CLT_INFO_HEADER } from '@/const/grid/bas/prm/basPrmtDealcoMgmtHeader'
import { CommonGrid, CommonUtil } from '@/utils'
//====================담보거래처====================
import BasBcoCtlDealcosPopup from '@/components/common/BasBcoCtlDealcosPopup'
import bacBcoCtlDealcosApi from '@/api/biz/bas/bco/bacBcoCtlDealcos'
//====================//담보거래처==================
import CommonMixin from '@/mixins'
import { msgTxt } from '@/const/msg.Properties'
import moment from 'moment'

export default {
    name: 'CltInfoContainer',
    mixins: [CommonMixin],
    computed: {
        ...serviceComputed,
        //==================== 상세데이터 ==================
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
        //==================== //상세데이터 ==================

        crdTyp: {
            get() {
                return this.CRD_TYP
            },
        },
        zbasC00200: {
            get() {
                return this.ZBAS_C_00200
            },
        },
        basPrmDealcoDtlCrdList1: {
            get() {
                return this.basPrmDealcoDtlCrdList
            },
        },
        isGridCltInfo1: {
            get() {
                return this.isGridCltInfo
            },
        },
    },
    components: {
        BasBcoCtlDealcosPopup,
    },
    data() {
        return {
            objCnt: 0,
            objAuth: {},
            gridData: this.GridSetData(),
            gridObj: {},
            cltInfo: {
                crdtTypCd: '',
                grtInstCd: '',
                dealCoNmMst: '',
                mstDealcoCd: '',
                setDt: '',
                expirDt: '',
                mrtgAmt: '',
                mrtgBlc: '',
                cmmsAmt: '',
                mrtgSetAmt: '',
                setBasisDesc: '',
                crdRmks: '',
            },
            cltInfoParam: {},
            storeKey: 'cltInfoData',

            layout1: [
                'crdtTypCd',
                'grtInstCd',
                'mrtgSetAmt',
                'cmmsAmt',
                'setDt',
                'expirDt',
                // 'expirDt1',
                'setBasisDesc',
                'modUserId',
                'modUserNm',
                'modDtm',
            ],

            isDisabledAdd: true,
            view: GRID_CLT_INFO_HEADER,
            isDtlAdd: false,
            initItems: [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ],
            gridStyle: {
                height: '130px', //그리드 높이 조절
            },
            //====================담보거래처====================
            showBasBcoDealcos: false,
            cltSearchFrom: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLvl: '', // 조직레벨
            },
            resultDealcoRows: [],
            //====================//담보거래처==================
            clickStatus: null,
            isDataBtnCrdDeal: false,

            isUptCltInfo: false,
            clickIndex: 0,
        }
    },
    mounted() {
        this.initData()
        //this.initGridCltInfo()
    },

    methods: {
        ...serviceMethods,
        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        initData() {
            this.cltInfo = {
                crdtTypCd: '',
                grtInstCd: '',
                dealCoNmMst: '',
                mstDealcoCd: '',
                setDt: '',
                expirDt: '',
                mrtgAmt: '',
                mrtgBlc: '',
                cmmsAmt: '',
                mrtgSetAmt: '',
                setBasisDesc: '',
                crdRmks: '',
            }
            this.isDataBtnCrdDeal = false
            this.isUptCltInfo = false
        },
        setData() {
            let params = { ...this.cltInfo }

            if (!_.isEmpty(params['setDt'])) {
                params['setDt'] = moment(params['setDt']).format('YYYY-MM-DD')
            }
            if (!_.isEmpty(params['expirDt'])) {
                params['expirDt'] = moment(params['expirDt']).format(
                    'YYYY-MM-DD'
                )
            }
            if (!_.isEmpty(this.cltInfoData)) {
                let checkKeys = [
                    'crdtTypCd', // 여신유형
                    'grtInstCd', // 보증기관
                    'mstDealcoCd', // 공유담보거래처
                    'setDt', // 설정일
                    'expirDt', // 만료일
                    'mrtgAmt', // 담보금액
                    'mrtgBlc', // 담보잔액
                    'cmmsAmt', // 수수료
                    'mrtgSetAmt', // 담보설정금액
                    'setBasisDesc', // 설정근거
                    'crdRmks', // 비고
                ]

                checkKeys.some((key) => {
                    if (
                        !_.isEmpty(this.cltInfoDataOld) &&
                        !_.isEqual(
                            this.cltInfoDataOld[key],
                            this.cltInfoData[key]
                        )
                    ) {
                        this.isUptCltInfo = true
                        return true
                    } else {
                        if (_.isEmpty(this.cltInfoDataOld)) {
                            this.storeSet('cltInfoDataOld', params)
                        }

                        this.isUptCltInfo = false
                    }
                })
            }

            this.storeSet('isCltInfo', this.isUptCltInfo)

            this.storeSet(this.storeKey, params)
        },
        initGridCltInfo() {
            this.gridObj = this.$refs.gridCltInfo
            this.gridObj.gridView.setColumnLayout(this.layout1)
            this.gridObj.setGridState(true, true, true, false)
            this.gridObj.gridView.displayOptions.selectionStyle = 'rows'

            this.gridObj.gridView.columnByName('crdtTypCd').values =
                CommonUtil.convListToGridLovValues(
                    this.crdTyp,
                    'commCdVal',
                    'SELECT'
                )
            this.gridObj.gridView.columnByName('crdtTypCd').labels =
                CommonUtil.convListToGridLovLabels(
                    this.crdTyp,
                    'commCdValNm',
                    'SELECT'
                )
            this.gridObj.gridView.columnByName('grtInstCd').values =
                CommonUtil.convListToGridLovValues(
                    this.zbasC00200,
                    'commCdVal',
                    'SELECT'
                )
            this.gridObj.gridView.columnByName('grtInstCd').labels =
                CommonUtil.convListToGridLovLabels(
                    this.zbasC00200,
                    'commCdValNm',
                    'SELECT'
                )

            if (!this.isDtlAdd) {
                if (!_.isEmpty(this.basPrmDealcoDtlCrdList1)) {
                    this.gridObj.setRows(this.basPrmDealcoDtlCrdList1)
                    this.gridObj.gridView.onCellClicked = (grid, clickData) => {
                        this.clickIndex = clickData.itemIndex
                        if (typeof clickData.itemIndex !== 'undefined') {
                            this.isDisabledAdd = false
                            _.forEach(GRID_CLT_INFO_HEADER.fields, (item) => {
                                const key = item.fieldName
                                const value = grid.getValue(
                                    clickData.itemIndex,
                                    key
                                )
                                this.cltInfo[key] = _.isEmpty(value)
                                    ? ''
                                    : value
                            })
                        }
                    }
                }
                this.isDtlAdd = true
            }
        },
        GridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        isDisabled(key, isDisabled) {
            this.defaultAssign_({
                key: key,
                value: isDisabled,
            })
        },
        gridAddRowBtn: function () {
            //this.initGridCltInfo()
            this.isDisabledAdd = false
            this.cltInfo.crdtTypCd = ''
            this.cltInfo.grtInstCd = ''
            this.cltInfo.dealCoNmMst = ''
            this.cltInfo.mstDealcoCd = ''
            this.cltInfo.setDt = ''
            this.cltInfo.expirDt = ''
            this.cltInfo.mrtgAmt = ''
            this.cltInfo.mrtgBlc = ''
            this.cltInfo.cmmsAmt = ''
            this.cltInfo.mrtgSetAmt = ''
            this.cltInfo.setBasisDesc = ''
            this.cltInfo.crdRmks = ''
            this.$refs.gridCltInfo.dataProvider.addRow([])

            let focuscell = this.$refs.gridCltInfo.gridView.getCurrent()
            focuscell.dataRow =
                this.$refs.gridCltInfo.dataProvider.getRows(0, -1).length - 1
            this.clickIndex = focuscell.dataRow
            this.$refs.gridCltInfo.gridView.setCurrent(focuscell)
        },

        gridChkDelRowBtn: function () {
            this.$refs.gridCltInfo.gridView.commit()
            let newRows = []
            let checkRows = this.$refs.gridCltInfo.gridView.getCheckedRows(true)
            let rows = this.$refs.gridCltInfo.dataProvider.getJsonRows()

            if (checkRows.length >= 1) {
                checkRows.forEach((n) => {
                    rows.forEach((v, i) => {
                        if (n === i) {
                            v.__rowState = 'deleted'
                            newRows.push(v)
                        }
                    })
                })

                //this.storeSet('basPrmDealcoDtlCrdListDel', newRows) // 삭제된 항목
                this.$refs.gridCltInfo.dataProvider.beginUpdate()
                this.$refs.gridCltInfo.dataProvider.removeRows(checkRows)
                this.$refs.gridCltInfo.dataProvider.endUpdate()
                this.objCnt -= checkRows.length
            } else {
                this.showTcComAlert('삭제할 대상을 선택해 주세요.')
                return false
            }

            if (this.objCnt < 0) {
                this.isDisabledAdd = true
                this.initData()
            }
        },
        changeCrdTyp(code) {
            if (
                _.isEqual(code, '04') &&
                _.isEqual(this.cltInfo.grtInstCd, '06')
            ) {
                this.isDataBtnCrdDeal = true
            } else {
                this.isDataBtnCrdDeal = false
            }

            let params = { ...this.cltInfo }
            this.storeSet(this.storeKey, params)
        },
        filterGrtInst(items) {
            if (!_.isEmpty(this.cltInfo.crdtTypCd)) {
                if (_.isEqual(this.cltInfo.crdtTypCd, '01')) {
                    return items.filter(
                        (item) =>
                            _.isEqual(item['commCdVal'], '01') ||
                            _.isEqual(item['commCdVal'], '02') ||
                            _.isEqual(item['commCdVal'], '03') ||
                            _.isEqual(item['commCdVal'], '04') ||
                            _.isEqual(item['commCdVal'], '05')
                    )
                } else if (
                    _.isEqual(this.cltInfo.crdtTypCd, '02') ||
                    _.isEqual(this.cltInfo.crdtTypCd, '03')
                ) {
                    return items.filter((item) =>
                        _.isEqual(item['commCdVal'], '05')
                    )
                } else if (_.isEqual(this.cltInfo.crdtTypCd, '04')) {
                    return items.filter((item) =>
                        _.isEqual(item['commCdVal'], '06')
                    )
                } else {
                    return this.initItems
                }
            } else {
                return this.initItems
            }
        },
        changeGrtInst(code) {
            if (
                _.isEqual(this.cltInfo.crdtTypCd, '04') &&
                _.isEqual(code, '06')
            ) {
                this.isDataBtnCrdDeal = true
            } else {
                this.isDataBtnCrdDeal = false
            }

            let params = { ...this.cltInfo }
            this.storeSet(this.storeKey, params)
        },
        cltInfoValidation() {
            const crdtTypCd = this.cltInfo.crdtTypCd
            const grtInstCd = this.cltInfo.grtInstCd
            const mstDealcoCd = this.cltInfo.mstDealcoCd
            const mrtgSetAmt = this.cltInfo.mrtgSetAmt
            const setBasisDesc = this.cltInfo.setBasisDesc
            console.log(' ======================================== ')
            console.log('crdtTypCd ->', crdtTypCd)
            console.log('grtInstCd ->', grtInstCd)
            console.log('mstDealcoCd ->', mstDealcoCd)
            console.log('mrtgSetAmt ->', mrtgSetAmt)
            console.log('setBasisDesc ->', setBasisDesc)

            if (_.isEmpty(crdtTypCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '여신유형을')
                )
                return false
            } else if (_.isEmpty(grtInstCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '보증기관을')
                )
                return false
            }
            // 여신유형이 공유담보이면서 보증기관이 공유담보거래처인 경우
            else if (_.isEqual(crdtTypCd, '04') && _.isEqual(crdtTypCd, '04')) {
                if (_.isEmpty(mstDealcoCd)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(
                            msgTxt.MSG_00047,
                            '공유담보거래처를'
                        )
                    )
                    return false
                }
            } else if (_.isEmpty(mrtgSetAmt)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '담보설정금액')
                )
                return false
            } else if (_.isEmpty(setBasisDesc)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '설정근거')
                )
                return false
            } else {
                return true
            }
        },
        getJsonData(save, type) {
            let rows = this.$refs.gridCltInfo.dataProvider.getStateRows(type)

            for (let idx = 0; idx < rows.length; idx++) {
                let data = this.$refs.gridCltInfo.dataProvider.getJsonRow(
                    rows[idx]
                )

                let crdtTypCd = _.isEmpty(data.crdtTypCd) ? '' : data.crdtTypCd
                let grtInstCd = _.isEmpty(data.grtInstCd) ? '' : data.grtInstCd
                let dealCoNmMst = _.isEmpty(data.dealCoNmMst)
                    ? ''
                    : data.dealCoNmMst
                let mstDealcoCd = _.isEmpty(data.mstDealcoCd)
                    ? ''
                    : data.mstDealcoCd
                let mrtgSetAmt = _.isEmpty(data.mrtgSetAmt)
                    ? ''
                    : data.mrtgSetAmt
                let mrtgAmt = _.isEmpty(data.mrtgAmt) ? '' : data.mrtgAmt
                let mrtgBlc = _.isEmpty(data.mrtgBlc) ? '' : data.mrtgBlc
                let cmmsAmt = _.isEmpty(data.cmmsAmt) ? '' : data.cmmsAmt
                let crdRmks = _.isEmpty(data.crdRmks) ? '' : data.crdRmks
                let setDt = _.isEmpty(data.setDt) ? '' : data.setDt
                let expirDt = _.isEmpty(data.expirDt) ? '' : data.expirDt
                let expirDt1 = _.isEmpty(data.expirDt1) ? '' : data.expirDt1
                let setBasisDesc = _.isEmpty(data.setBasisDesc)
                    ? ''
                    : data.setBasisDesc
                let __rowState = type

                data.crdtTypCd = crdtTypCd
                data.grtInstCd = grtInstCd
                data.dealCoNmMst = dealCoNmMst
                data.mstDealcoCd = mstDealcoCd
                data.mrtgSetAmt = mrtgSetAmt
                data.mrtgAmt = mrtgAmt
                data.mrtgBlc = mrtgBlc
                data.cmmsAmt = cmmsAmt
                data.crdRmks = crdRmks
                data.setDt = setDt
                data.expirDt = expirDt
                data.expirDt1 = expirDt1
                data.setBasisDesc = setBasisDesc
                data.__rowState = __rowState
                save.push(data)
            }
        },
        tempSave() {
            if (this.isDisabledAdd) return false

            if (!this.cltInfoValidation()) {
                return false
            }
            this.showTcComConfirm('입력저장 하시겠습니까?').then((confirm) => {
                if (!confirm) return false

                const values = {
                    crdtTypCd: this.cltInfo.crdtTypCd,
                    grtInstCd: this.cltInfo.grtInstCd,
                    dealCoNmMst: this.cltInfo.dealCoNmMst,
                    mstDealcoCd: this.cltInfo.mstDealcoCd,
                    mrtgSetAmt: this.cltInfo.mrtgSetAmt,
                    mrtgAmt: this.cltInfo.mrtgAmt,
                    mrtgBlc: this.cltInfo.mrtgBlc,
                    cmmsAmt: this.cltInfo.cmmsAmt,
                    crdRmks: this.cltInfo.crdRmks,
                    setDt: this.cltInfo.setDt,
                    expirDt: this.cltInfo.expirDt,
                    expirDt1: this.cltInfo.expirDt1,
                    setBasisDesc: this.cltInfo.setBasisDesc,
                    __rowState: 'created',
                }
                console.log('values', values)
                this.$refs.gridCltInfo.dataProvider.updateRow(
                    this.clickIndex,
                    values
                )
                this.$refs.gridCltInfo.gridView.commit()

                /*
                let save = []
                let setData = ['created', 'updated']

                setData.forEach((key) => {
                    this.getJsonData(save, key)
                })
                */
                let rows = this.$refs.gridCltInfo.dataProvider.getJsonRows()
                let newRows = []
                rows.forEach((v) => {
                    if (!_.isEmpty(v.modUserId)) {
                        // 수정사용자가 존재하면 update
                        v.__rowState = 'updated'
                    } else {
                        // 없으면 신규
                        v.__rowState = 'created'
                    }
                    newRows.push(v)
                })

                //this.storeSet('basPrmDealcoDtlCrdList', save)
                this.storeSet('basPrmDealcoDtlCrdList', newRows)
            })
        },
        //===================== 담보거래처팝업관련 methods ================================
        // 담보거래처 조회 후 1건이면 TextField에 바로 설정하고 아니면 담보거래처 팝업 오픈
        getCtlDealcosList() {
            let searchParam = {}
            searchParam['dealcoNm'] = this.cltInfo.dealCoNmMst
            searchParam['dealcoCd'] = this.cltInfo.mstDealcoCd

            bacBcoCtlDealcosApi.getDealcosList(searchParam).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 담보거래처 정보가 1건이면 TextField에 바로 설정
                // 검색된 담보거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 담보거래처 팝업 오픈
                if (!_.isEmpty(res)) {
                    this.cltInfo.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.cltInfo.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.cltSearchFrom.dealcoNm = this.cltInfo.dealCoNmMst
                    this.cltSearchFrom.dealcoCd = this.cltInfo.mstDealcoCd
                    this.cltSearchFrom.orgCd = this.orgInfo.orgCd
                    this.cltSearchFrom.orgNm = this.orgInfo.orgNm
                    this.cltSearchFrom.orgLvl = this.orgInfo.orgLvl
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 담보거래처 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            let isDisable = this.isDisabledAdd
                ? this.isDisabledAdd
                : !this.isDataBtnCrdDeal

            if (isDisable) return false

            // 담보거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 담보거래처명이 빈값이 아니면 담보거래처 정보 조회
            // 그 이외는 담보거래처 팝업 오픈
            if (!_.isEmpty(this.cltInfo.dealCoNmMst)) {
                this.getDealcosList()
            } else {
                this.cltSearchFrom.dealcoNm = this.cltInfo.dealCoNmMst
                this.cltSearchFrom.dealcoCd = this.cltInfo.mstDealcoCd
                this.cltSearchFrom.orgCd = this.orgInfo.orgCd
                this.cltSearchFrom.orgNm = this.orgInfo.orgNm
                this.cltSearchFrom.orgLvl = this.orgInfo.orgLvl
                this.showBasBcoDealcos = true
            }
        },
        // 담보거래처 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 담보거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 담보거래처명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.cltInfo.dealCoNmMst)) {
                this.showTcComAlert('담보거래처명 입력해주세요.')
                return false
            }
            // 담보거래처 정보 조회
            this.getCtlDealcosList()
        },
        // 담보거래처 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 담보거래처 코드 초기화
            this.cltInfo.mstDealcoCd = ''
            let params = { ...this.cltInfo }
            this.storeSet(this.storeKey, params)
        },
        // 담보거래처 팝업 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            this.cltInfo.dealCoNmMst = _.get(returnData, 'dealcoNm')
            this.cltInfo.mstDealcoCd = _.get(returnData, 'dealcoCd')
            let params = { ...this.cltInfo }
            this.storeSet(this.storeKey, params)
        },
        //===================== //담보거래처팝업관련 methods ================================
    },
    watch: {
        basPrmDealcoDtlCrdVo: {
            handler: function (values) {
                let detailData = this.cltInfo // 데이터 Set

                _.forEach(Object.keys(detailData), (key) => {
                    if (!_.isEmpty(key)) {
                        // 기본정보셋팅
                        let value = values[key]
                        //let isValue = false
                        //let currentDate = moment(new Date()).format('YYYY-MM-DD')
                        if (
                            _.isEqual(value, undefined) ||
                            _.isEqual(value, null) ||
                            _.isEqual(value, '')
                        ) {
                            if (typeof detailData[key] === 'object') {
                                value = []
                            } else {
                                value = ''
                            }
                        } else {
                            //isValue = true
                        }

                        // 필터정보셋팅
                        detailData[key] = value
                    }
                })

                let param = { ...detailData }
                if (!_.isEmpty(param['setDt'])) {
                    param['setDt'] = moment(param['setDt']).format('YYYY-MM-DD')
                }
                if (!_.isEmpty(param['expirDt'])) {
                    param['expirDt'] = moment(param['expirDt']).format(
                        'YYYY-MM-DD'
                    )
                }
                this.storeSet('cltInfoDataOld', param)
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        basPrmDealcoDtlCrdList1: {
            handler: function (values) {
                if (!_.isEmpty(values) && this.isGridCltInfo1) {
                    clearTimeout(this.clickStatus)
                    this.clickStatus = setTimeout(() => {
                        this.initGridCltInfo()
                    }, 200)
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
