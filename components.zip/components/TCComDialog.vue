<!-----------------------------------------------
 * 업무그룹명: Button 컴포넌트
 * 서브업무명: Button 공통함수
 * 설명: Button 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.04.14
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <v-dialog
        v-model="activeOpen"
        :max-width="size"
        scrollable
        persistent
        @input="emitInput"
    >
        <slot name="content" />
    </v-dialog>
</template>

<script>
export default {
    inheritAttrs: false,
    name: 'TCComDialog',
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        //팝업 넓이
        size: { type: [String, Number], required: false },
    },
    data() {
        return {}
    },
    computed: {
        cSize() {
            var res = '100%'
            if (this.size != null) {
                res = this.size + '%'
            }
            return res
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    // props 동적제어
    watch: {},
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {},
        emitInput(value) {
            this.$emit('input', value)
        },
        // emitOkClick() {
        //     this.activeOpen = true
        //     this.$emit('ok-click')
        // },
        // emitNoClick() {
        //     this.activeOpen = false
        //     this.emitInput(this.activeOpen)
        //     this.$emit('no-click')
        // },
        // 팝업오픈여부 셋팅
        // setValueChange(value) {
        //     this.emitInput(value)
        // },
        // closeBtn() {
        //     this.activeOpen = false
        // },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
