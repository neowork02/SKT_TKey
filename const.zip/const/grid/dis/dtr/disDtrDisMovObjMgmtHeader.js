import { ValueType } from 'realgrid'

export const DisDtrDisMovObjMgmtGRID_LAYOUT = [
    'reqOrgNm',
    'reqDealSktCd',
    'reqDealcoCd',
    'reqDealcoNm',
    'sktChnlCd',
    'prodCd',
    'prodNm',
    'colorNm',
    'disQty',
    'asgnStNm',
    {
        name: '재고이동',
        direction: 'horizontal',
        items: [
            {
                name: '배정',
                direction: 'horizontal',
                items: ['asgnReqQty', 'asgnBtn'],
            },
            {
                name: '확정',
                direction: 'horizontal',
                items: ['asgnFixQty'],
            },
            {
                name: '이동',
                direction: 'horizontal',
                items: ['movOutQty', 'movOutBtn'],
            },
        ],
    },
    'modUserNm',
]

export const DisDtrDisMovObjMgmtGRID_HEADER = {
    fields: [
        {
            fieldName: 'reqOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnReqQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asgnBtn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnFixQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'movOutQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'movOutBtn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnOrignReqQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'reqStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnFixQtyOrg',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'reqOrgNm',
            fieldName: 'reqOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
            editable: false,
            width: '400',
        },
        {
            name: 'reqDealSktCd',
            fieldName: 'reqDealSktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            editable: false,
            width: '100',
        },
        {
            name: 'reqDealcoCd',
            fieldName: 'reqDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
            editable: false,
            width: '100',
        },
        {
            name: 'reqDealcoNm',
            fieldName: 'reqDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처',
                showTooltip: false,
            },
            editable: false,
            width: '150',
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채널',
                showTooltip: false,
            },
            editable: false,
            width: '150',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
            editable: false,
            width: '100',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
            editable: false,
            width: '150',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
            editable: false,
            width: '100',
        },
        {
            name: 'disQty',
            fieldName: 'disQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유재고',
                showTooltip: false,
            },
            editable: false,
            width: '100',
        },
        {
            name: 'asgnStNm',
            fieldName: 'asgnStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상태',
                showTooltip: false,
            },
            footer: {
                text: '합계',
            },
            editable: false,
            width: '100',
        },
        {
            name: 'asgnReqQty',
            fieldName: 'asgnReqQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            editor: {
                type: 'number',
            },
            editable: true,
            styleCallback: function (grid, dataCell) {
                var asgnStCd = grid.getValue(
                    dataCell.index.itemIndex,
                    'asgnStCd'
                )
                var ret = {}
                if (asgnStCd === '04') {
                    ret.editable = false
                }
                return ret
            },
            numberFormat: '#,##0',
            width: '100',
        },
        {
            name: 'asgnBtn',
            fieldName: 'asgnBtn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '확인',
                showTooltip: false,
            },
            renderer: {
                type: 'button',
            },
            editable: false,
            width: '100',
        },
        {
            name: 'asgnFixQty',
            fieldName: 'asgnFixQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            editable: false,
            numberFormat: '#,##0',
            width: '100',
        },
        {
            name: 'movOutQty',
            fieldName: 'movOutQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            editable: false,
            numberFormat: '#,##0',
            width: '100',
        },
        {
            name: 'movOutBtn',
            fieldName: 'movOutBtn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동',
                showTooltip: false,
            },
            renderer: {
                type: 'button',
            },
            editable: false,
            width: '100',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
            editable: false,
            width: '100',
        },
        {
            name: 'asgnSeq',
            fieldName: 'asgnSeq',
            visible: false,
            type: 'data',
        },
        {
            name: 'asgnStCd',
            fieldName: 'asgnStCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'outMgmtNo',
            fieldName: 'outMgmtNo',
            visible: false,
            type: 'data',
        },
        {
            name: 'asgnOrignReqQty',
            fieldName: 'asgnOrignReqQty',
            visible: false,
            type: 'data',
        },
        {
            name: 'reqStCd',
            fieldName: 'reqStCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'asgnFixQtyOrg',
            fieldName: 'asgnFixQtyOrg',
            visible: false,
            type: 'data',
        },
    ],
}
