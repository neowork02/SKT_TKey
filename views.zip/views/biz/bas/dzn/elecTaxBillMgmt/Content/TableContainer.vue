<template lang="">
    <div class="gridWrap">
        <TCRealGridHeader
            id="elecTaxBillMgmtGridHeader1"
            ref="elecTaxBillMgmtGridHeader1"
            gridTitle="전자세금계산서목록"
            :gridObj="gridObj"
            :isPageRows="true"
            :isExceldown="true"
            :isNextPage="true"
            :isPageCnt="true"
            @excelDownBtn="excelDownBtn"
        />
        <TCRealGrid
            id="elecTaxBillMgmtGrid1"
            ref="elecTaxBillMgmtGrid1"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
        <TCComPaging
            :totalPage="paging1.totalPageCnt"
            :apiFunc="pageMove"
            :rowCnt="paging1.pageSize"
            @input="pageSizeChange"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/dzn/elecTaxBillMgmt/helpers'
import { CommonGrid } from '@/utils'
import { M_HEADER } from '@/const/grid/bas/dzn/basDznElecTaxBillMgmtHeader'
import CommonMsg from '@/utils/CommonMsg'
// eslint-disable-next-line no-unused-vars
import { msgTxt } from '@/const/msg.Properties.js'
import moment from 'moment'

export default {
    components: {},
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '420px', //그리드 높이 조절
            },
            view: M_HEADER,
            layout: [
                'pagingSeq',
                'ymdWrite',
                'no',
                'fgFinal',
                'fgIo',
                'fgPc',
                'ynTurn',
                'ynIss',
                'cmpTaxSt',
                'newOrgId',
                'errMsg',
                'sell',
                'buy',
            ],
        }
    },
    mounted() {
        //체크바
        // this.$refs.elecTaxBillMgmtGrid1.gridView.setCheckBar({
        //     visible: true,
        // })
        this.gridObj = this.$refs.elecTaxBillMgmtGrid1
        this.gridHeaderObj = this.$refs.elecTaxBillMgmtGridHeader1
        this.gridObj.gridView.setColumnLayout(this.layout)

        /*
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         */
        // this.$refs.elecTaxBillMgmtGrid1.setGridState(true, false, false)
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, true, false, false)
        //this.gridObj.setGridState()
    },
    computed: {
        ...serviceComputed,
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
    },
    methods: {
        ...serviceMethods,
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 9999, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging',
                value: { ...this.paging, pageSize: pageSize },
            })
            if (this.paging1.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        excelDownBtn: function () {
            this.gridHeaderObj.exportGrid(
                `전자세금계산서목록_${moment(new Date()).format(
                    'YYYYMMDDHHmmss'
                )}.xls`
            )
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            //Grid Row 가져올때 페이지정보 Setting
            console.log(
                '🚀 ~ file: TableContainer.vue ~ line 129 ~ SetPaging ~ paging',
                this.paging
            )
            this.gridHeaderObj.setPageCount(this.paging) //TCRealGridHeader 계산식이 좀 이상함??
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        resultList1(val, oldVal) {
            //console.log('resultList1 watched: ', val, oldVal, this.pageSize)
            this.$refs.elecTaxBillMgmtGrid1.setRows(this.resultList)

            this.gridObj.setRows(this.resultList)
        },
        // eslint-disable-next-line no-unused-vars
        paging1(val, oldVal) {
            //console.log('paging1 watched: ', val, oldVal)
            this.SetPaging()
        },
    },
}
</script>
