import { ValueType } from 'realgrid'

export let GRID_INFO = {
    fields: [
        {
            fieldName: 'cempPolTypeNm', //정책유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cempPayId', //정산항목ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cempPolId', //정책ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cempPolNo', //정책코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cempPolNm', //정책명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cempPolYm', //정책년월
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cempPolOrgCd', //정책주관
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cempPlanUserId', //정책기획자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cempUseYn', //사용여부
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'cempPolTypeNm',
            fieldName: 'cempPolTypeNm',
            width: '130',
            type: 'data',
            header: {
                text: '정책유형',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'cempPayId',
            fieldName: 'cempPayId',
            width: '130',
            type: 'data',
            header: {
                text: '정산항목ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'cempPolId',
            fieldName: 'cempPolId',
            width: '130',
            type: 'data',
            header: {
                text: '정책ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'cempPolNo',
            fieldName: 'cempPolNo',
            width: '150',
            type: 'data',
            header: {
                text: '정책코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'cempPolNm',
            fieldName: 'cempPolNm',
            width: '330',
            type: 'data',
            header: {
                text: '정책명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'cempPolYm',
            fieldName: 'cempPolYm',
            width: '100',
            type: 'data',
            header: {
                text: '정책년월',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'cempPolOrgCd',
            fieldName: 'cempPolOrgCd',
            width: '100',
            type: 'data',
            header: {
                text: '정책주관',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'cempPlanUserId',
            fieldName: 'cempPlanUserId',
            width: '100',
            type: 'data',
            header: {
                text: '정책기획자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'cempUseYn',
            fieldName: 'cempUseYn',
            width: '60',
            type: 'data',
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}
