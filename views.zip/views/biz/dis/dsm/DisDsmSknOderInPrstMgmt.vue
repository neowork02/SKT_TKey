<!-----------------------------------------------
 * 업무그룹명: 재고관리현황
 * 서브업무명: SKN주문-입고현황관리
 * 설명: SKN주문-입고현황을 조회한다.
 * 작성자: P179890
 * 작성일: 2022.04.04
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>SKN주문-입고 현황관리</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left"></li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="주문일자"
                        :calType="calType"
                        v-model="setDate"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="대리점"
                        :objAuth="this.objAuth"
                        v-model="reqParam.agencyNm"
                        :codeVal="reqParam.agencyCd"
                        :disabledAfter="true"
                        :disabled="agencyDisabled"
                        :eRequired="true"
                        @enterKey="onAgencyIconClick"
                        @appendIconClick="onAgencyIconClick"
                        @input="onAgencyInput"
                    >
                    </TCComInputSearchText>
                    <BasBcoAgencysPopup
                        v-if="showBcoAgencys"
                        :parentParam="reqParam"
                        :rows="resultAgencyRows"
                        :dialogShow.sync="showBcoAgencys"
                        @confirm="onAgencyReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- //Search_div -->

        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="목록"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.exportGridBtn"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisDsmSknOderInPrstMgmts"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <!-- //gridWrap -->
    </div>
</template>

<!--style scoped>
</style-->
<script>
import { DisDsmSknOderInPrstMgmt_GRID_HEADER } from '@/const/grid/dis/dsm/disDsmSknOderInPrstMgmtHeader.js'
import restApi from '@/api/biz/dis/dsm/disDsmSknOderInPrstMgmt.js'
import attachedFileApi from '@/api/common/attachedFile'
import { CommonGrid, CommonUtil, CommonMsg } from '@/utils'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
//====================대리점팝업====================
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
//====================//대리점팝업====================

export default {
    name: 'DisDsmSknOderInPrstMgmt',
    mixins: [CommonMixin],
    components: { BasBcoAgencysPopup },
    data() {
        return {
            //====================대리점팝업관련====================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
            agencyDisabled: false,
            alertBodyTxt: '',
            alertHeadTxt: 'SKN주문-입고 현황관리',
            view: DisDsmSknOderInPrstMgmt_GRID_HEADER,
            gridData: {},
            calType: 'DP',
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            searchForms: {},
            indicatorOpt: { sort: 'ASC' },
            rowCnt: 15,
            gridStyle: {
                height: '415px', //그리드 높이 조절
            },
            reqParam: {
                // 요청파라미터
                startDt: '', // 주문시작일자
                endDt: '', // 주문종료일자
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
                agencyTypCd: '', // 대리점유형코드
            },
        }
    },
    watch: {},
    computed: {
        setDate: {
            get() {
                return [this.reqParam.startDt, this.reqParam.endDt]
            },
            set(val) {
                this.reqParam.startDt = val[0]
                this.reqParam.endDt = val[1]
                return val
            },
        },
    },
    created() {
        // 화면 default설정
        this.gridData = this.gridSetData()
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(true)
        this.init()
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.startDt = moment(new Date()).format('YYYY-MM-01') // 주문시작일
            this.reqParam.endDt = moment(new Date()).format('YYYY-MM-DD') // 주문종료일

            // 소속 대리점이 존재하는지 체크하여 대리점 셋팅
            // if (!_.isEmpty(this.userInfo['sktAgencyCd'])) {
            //     this.reqParam['agencyCd'] = this.userInfo['sktAgencyCd']
            //     this.reqParam['agencyNm'] = this.userInfo['sktAgencyNm']
            //     this.agencyDisabled = true
            // } else {
            this.agencyDisabled = false
            // }
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
            this.gridData.totalPage = 0
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/disDsmSknOderInPrstMgmtExcels',
                this.reqParam
            )
        },
        //조회 버튼 이벤트
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            //첫 조회시 표시할 행의 갯수
            this.searchForms = { ...this.reqParam }
            this.searchForms.pageSize = this.rowCnt
            this.searchForms.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getDisDsmSknOderInPrstMgmts(this.searchForms.pageNum)
        },
        getDisDsmSknOderInPrstMgmts(page) {
            this.searchForms.pageNum = page
            // SKN주문-입고현황 리스트 조회
            restApi
                .getDisDsmSknOderInPrstMgmts(this.searchForms)
                .then((res) => {
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator(
                        res.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수

                    //Grid Row 가져올때 총건수 Setting
                    this.gridHeaderObj.setPageCount(res.pagingDto)
                })
        },
        clearPage() {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            // this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
            this.init()
        },
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        isValidChk() {
            // validation 체크
            if (_.isEmpty(this.reqParam.agencyCd)) {
                this.showTcComAlert(
                    '대리점을 검색하신 후 조회 하시기 바랍니다.'
                )
                return false
            }
            if (_.isEmpty(this.reqParam.startDt)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '주문시작일'))
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.startDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }

            if (_.isEmpty(this.reqParam.endDt)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '주문종료일'))
                return false
            }

            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.endDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }

            if (
                this.reqParam.startDt.substr(0, 7) !==
                this.reqParam.endDt.substr(0, 7)
            ) {
                this.openAlert('시작일자와 종료일자를 동일한 월로 지정하세요.')
                return false
            }

            if (
                this.reqParam.startDt.replaceAll('-', '') >
                this.reqParam.endDt.replaceAll('-', '')
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_01026'))
                return false
            }
            return true
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //===================== 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getAgencyList() {
            basBcoAgencysApi.getAgencyList(this.reqParam).then((res) => {
                // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.agencyCd = _.get(res[0], 'agencyCd')
                    this.reqParam.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultAgencyRows = res
                    this.showBcoAgencys = true
                }
            })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.reqParam.agencyNm)) {
                this.getAgencyList()
            } else {
                this.showBcoAgencys = true
            }
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(returnData) {
            this.reqParam.agencyCd = _.get(returnData, 'agencyCd')
            this.reqParam.agencyNm = _.get(returnData, 'agencyNm')
        },
        onAgencyInput() {
            this.reqParam.agencyCd = ''
        },
        //===================== //대리점팝업관련 methods ================================
    },
}
</script>
