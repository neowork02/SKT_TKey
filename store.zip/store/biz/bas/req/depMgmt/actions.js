import api from '@/api/biz/bas/req/basReqDocMgmt'
import types from './mutation-types'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    // eslint-disable-next-line no-unused-vars
    async getBasReqDocMgmtDetails_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getBasReqDocMgmtDetails_ ', searchParams)
        await api.getBasReqDocMgmtDetails_({ searchParams }).then((data) => {
            console.log('🚀 ~ getBasReqDocMgmtDetails_ ~ .then ~ data', data)
            resultData = data
        })
        return resultData
    },
    async getBasReqDocMgmtList_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum
        console.log(
            '🚀 ~ file: actions.js ~ line 87 ~ searchParams',
            searchParams
        )
        await api
            .getBasReqDocMgmtList_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ getBasReqDocMgmtList_ ~ .then ~ data',
                    data
                )
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: data.pagingDto,
                    })
                    let body = data.gridList
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: body,
                    })
                } else {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: state.initPaging,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: [],
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })
        const _sleep = (delay) =>
            new Promise((resolve) => setTimeout(resolve, delay))
        const timer = async () => {
            await _sleep(200)
        }
        await timer()

        return resultData
    },
    // eslint-disable-next-line no-unused-vars
    async saveDocMgmt_({ state, commit }, { saveRows }) {
        console.log('🚀 ~ file: actions.js ~ saveDocMgmt_ ~ saveRows', saveRows)
        let result = 0
        await api
            .saveDocMgmt_(saveRows)
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ saveDocMgmt_~ .then ~ data',
                    data
                )
                result = data
            })
            .catch((error) => {
                throw error
            })
        // const _sleep = (delay) =>
        //     new Promise((resolve) => setTimeout(resolve, delay))
        // const timer = async () => {
        //     await _sleep(1000)
        // }
        // await timer()
        return result
    },
}
