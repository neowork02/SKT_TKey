/*****************************************
 * 업무그룹명: 판매관리
 * 서브업무명: T상품판매
 * 설명: 판매관리-T상품판매-T판매-T판매_P임대등록(SALSEL00200) 그리드 헤더
 * 작성자: P179234
 * 작성일: 2022.07.11
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'suplSvcClCdNm',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT, //서비스
        },
        {
            fieldName: 'idmLmtCd',
            dataType: ValueType.TEXT, //유치기한
        },
        {
            fieldName: 'svcStaDt',
            dataType: ValueType.TEXT, //가입일
        },
        {
            fieldName: 'svcEndDt',
            dataType: ValueType.TEXT, //해지일
        },
        {
            fieldName: 'prMnyYn',
            dataType: ValueType.TEXT, //고객부담금
        },
    ],
    columns: [
        {
            name: 'suplSvcClCdNm',
            fieldName: 'suplSvcClCdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구분',
                showTooltip: false,
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스',
                showTooltip: false,
            },
        },
        {
            name: 'idmLmtCd',
            fieldName: 'idmLmtCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '유치기한',
                showTooltip: false,
            },
        },
        {
            name: 'svcStaDt',
            fieldName: 'svcStaDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '가입일',
                showTooltip: false,
            },
        },
        {
            name: 'svcEndDt',
            fieldName: 'svcEndDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '해지일',
                showTooltip: false,
            },
        },
        {
            name: 'prMnyYn',
            fieldName: 'prMnyYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '고객부담금',
                showTooltip: false,
            },
        },
    ],
}
