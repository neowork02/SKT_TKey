import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        // {
        //     fieldName: 'pagingSeq',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgeh',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'postDeptNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stell',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dutyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'jikchCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpstyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dayClsYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dayClsCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cashGapYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cashGapCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payGapYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payGapCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cashOverYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cashOverCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'spayYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'notPayCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndConfimReqYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndConfimReqCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'deptCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpstyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dutyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repMblPhonNo',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        // {
        //     name: 'pagingSeq',
        //     fieldName: 'pagingSeq',
        //     header: {
        //         text: 'No.',
        //     },
        // },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            header: {
                text: '조직코드',
            },
            editable: false,
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    //ret.editable = true

                    //조직코드 입력 유형 변경 행추가 때만 입력가능
                    let agencyCd1 = grid._view.columnByName('orgNm')
                    agencyCd1.editable = false
                    agencyCd1.button = 'action'
                    agencyCd1.buttonVisibility = 'default'
                } else {
                    let agencyCd1 = grid._view.columnByName('orgNm')
                    agencyCd1.editable = false
                    agencyCd1.button = 'none'
                    agencyCd1.buttonVisibility = ''
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: {
                text: '조직명',
            },
            width: 200,
            editable: false,
        },
        {
            name: 'orgeh',
            fieldName: 'orgeh',
            header: {
                text: '부서코드',
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true
                } else {
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'postDeptNm',
            fieldName: 'postDeptNm',
            header: {
                text: '소속부서명',
            },
            editable: false,
            width: 200,
        },
        {
            name: 'stell',
            fieldName: 'stell',
            header: {
                text: '직무코드',
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true
                } else {
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'dutyNm',
            fieldName: 'dutyNm',
            header: {
                text: '직무명',
            },
            editable: false,
            width: 100,
        },
        {
            name: 'jikchCd',
            fieldName: 'jikchCd',
            header: {
                text: '직책코드',
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true
                } else {
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'rpstyNm',
            fieldName: 'rpstyNm',
            header: {
                text: '직책명',
            },
            editable: false,
        },
        {
            name: 'dayClsYn',
            fieldName: 'dayClsYn',
            header: {
                text: '전송대상', //'일마감전송여부',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'dayClsCnt',
            fieldName: 'dayClsCnt',
            header: {
                text: '전송결과', //'일마감전송수',
            },
            editable: false,
        },
        {
            name: 'cashGapYn',
            fieldName: 'cashGapYn',
            header: {
                text: '전송대상', //'현금입금확정여부',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'cashGapCnt',
            fieldName: 'cashGapCnt',
            header: {
                text: '전송결과', //'현금입금확정수',
            },
            editable: false,
        },
        {
            name: 'payGapYn',
            fieldName: 'payGapYn',
            header: {
                text: '전송대상', //'수납차이전송여부',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'payGapCnt',
            fieldName: 'payGapCnt',
            header: {
                text: '전송결과', //'수납차이전송수',
            },
            editable: false,
        },
        {
            name: 'cashOverYn',
            fieldName: 'cashOverYn',
            header: {
                text: '전송대상', //'현금과다보유여부',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'cashOverCnt',
            fieldName: 'cashOverCnt',
            header: {
                text: '전송결과', //'현금과다보유수',
            },
            editable: false,
        },
        {
            name: 'spayYn',
            fieldName: 'spayYn',
            header: {
                text: '전송대상', //'분리납부여부',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'notPayCnt',
            fieldName: 'notPayCnt',
            header: {
                text: '전송결과', //'분리납부수',
            },
            editable: false,
        },
        {
            name: 'dealEndConfimReqYn',
            fieldName: 'dealEndConfimReqYn',
            header: {
                text: '전송대상', //'거래종료확인서전송여부',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'dealEndConfimReqCnt',
            fieldName: 'dealEndConfimReqCnt',
            header: {
                text: '전송결과', //'거래종료확인서전송',
            },
            editable: false,
        },
        {
            name: 'deptCd',
            fieldName: 'deptCd',
            header: {
                text: '소속부서코드',
            },
            visible: false,
        },
        {
            name: 'rpstyCd',
            fieldName: 'rpstyCd',
            header: {
                text: '직책코드',
            },
            visible: false,
        },
        {
            name: 'dutyCd',
            fieldName: 'dutyCd',
            header: {
                text: '직무코드',
            },
            visible: false,
        },
        {
            name: 'userCd',
            fieldName: 'userCd',
            header: {
                text: '사원번호',
            },
            editable: false,
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            header: {
                text: '사용자명',
            },
            editable: false,
        },
        {
            name: 'repMblPhonNo',
            fieldName: 'repMblPhonNo',
            header: {
                text: '대표이동전화번호',
            },
            editable: false,
        },
    ],
}
