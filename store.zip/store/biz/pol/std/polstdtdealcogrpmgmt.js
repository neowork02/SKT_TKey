/**************************************************************************************************************
 * 가상데이터 선언 영역
 **************************************************************************************************************/
import send from '@/api/axios-tdcs'
import _ from 'lodash'

export default {
    namespaced: true,
    state: {
        // 목록검색조건
        dsCondition: {
            list: {
                polYm: '', // 조회년월
                polOrgCd: '', // 조직ID
                polOrgNm: '', // 조직명
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
                modUserId: '', // 작성자ID
                modUserNm: '', // 작성자
                polOperDealcoNm: '', // 정책운영자
                polOperDealcoCd: '', // 정책운영자코드
                polSubjCd: '', // 정책주관코드
                polGrpCd: '', // 정책그룹코드
                polKndCd: '', // 정책분류코드
                polTypCd: '', // 정책유형코드
                vatCd: '', // 부가세코드
                histYn: '', // 이력포함
                idPolNm: '', // 정책ID/명
            },
            detail: {
                ictId: '', // 정책ID
                ictTs: '', // 정책차수
            },
        },
        // 인센티브정책목록
        dsPolIctList: [],

        dsUseYnItems: [], // 사용여부 리스트
        // 사용여부(그리드) 리스트
        dsUseYnGridItems: {
            values: [],
            labels: [],
        },

        // 거래처그룹구분 리스트
        dsDealcoGrpClCdItems: [],
        // 거래처그룹구분(그리드) 리스트
        dsDealcoGrpClCdGridItems: {
            values: [],
            labels: [],
        },

        // 거래처유형 리스트
        dsDealcoClCd2Items: [],
        // 거래처유형(그리드) 리스트
        dsDealcoClCd2GridItems: {
            values: [],
            labels: [],
        },

        // 거래처구분 리스트
        dsDealcoClCd1Items: [],
        // 거래처구분(그리드) 리스트
        dsDealcoClCd1GridItems: {
            values: [],
            labels: [],
        },
    },

    mutations: {
        setInit(state, payload) {
            console.log('setInit[mutations]::::', payload)
            _.forEach(payload, (item) => {
                if (item.commCdId == 'USE_YN') {
                    state.dsUseYnItems.push(item)
                    state.dsUseYnGridItems['values'].push(item.commCdVal)
                    state.dsUseYnGridItems['labels'].push(item.commCdValNm)
                } else if (item.commCdId == 'DEAL_CO_GRP') {
                    state.dsDealcoGrpClCdItems.push(item)
                    state.dsDealcoGrpClCdGridItems['values'].push(
                        item.commCdVal
                    )
                    state.dsDealcoGrpClCdGridItems['labels'].push(
                        item.commCdValNm
                    )
                } else if (item.commCdId == 'ZBAS_C_00110') {
                    state.dsDealcoClCd2Items.push(item)
                    state.dsDealcoClCd2GridItems['values'].push(item.commCdVal)
                    state.dsDealcoClCd2GridItems['labels'].push(
                        item.commCdValNm
                    )
                } else if (item.commCdId == 'ZBAS_C_00240') {
                    state.dsDealcoClCd1Items.push(item)
                    state.dsDealcoClCd1GridItems['values'].push(item.commCdVal)
                    state.dsDealcoClCd1GridItems['labels'].push(
                        item.commCdValNm
                    )
                }
            })
        },
        setDsCondition(state, payload) {
            state.dsCondition = {
                ...state.dsCondition,
                ...payload,
            }
        },
        setPolIctList(state, payload) {
            state.dsPolIctList = payload
        },
        setDsPolIctList(state, payload) {
            state.dsPolIctList = payload
        },
        setDsUseYnItems(state, payload) {
            state.dsUseYnItems = payload
        },
    },
    actions: {
        async getInit({ commit }, payload) {
            console.log('getInit::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'post',
                    url: '/api/v1/backend/pol/com/getCommCdMgmtList',
                    data: payload,
                })
                    .then((res) => {
                        console.log('getInit[then]', res)
                        commit('setInit', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
        async getPolIctList({ commit }, payload) {
            console.log('getPolIctList::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'get',
                    url: '/api/v1/backend/pol/ict/getPolIctList',
                    params: payload,
                })
                    .then((res) => {
                        console.log('getPolIctList[then]', res)
                        commit('setPolIctList', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
    },
    getters: {
        //
    },
}
