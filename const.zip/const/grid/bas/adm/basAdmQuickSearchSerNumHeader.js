import { ValueType } from 'realgrid'

export const BAS_ADM_QUICK_SER_NUM_HEADER = {
    fields: [
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'MfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badYnNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lastInoutDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fstInFixDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lastInoutDtlClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orglastInoutDtlClCdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'authYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            header: {
                text: '상품구분',
            },
            editable: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            header: {
                text: '상품코드',
            },
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            header: {
                text: '상품명',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            header: {
                text: '색상',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            header: {
                text: '일련번호',
            },
            editable: false,
        },
        {
            name: 'MfactNm',
            fieldName: 'MfactNm',
            header: {
                text: '제조사',
            },
            editable: false,
        },
        {
            name: 'badYnNm',
            fieldName: 'badYnNm',
            header: {
                text: '불량여부',
            },
            editable: false,
        },

        {
            name: 'disStNm',
            fieldName: 'disStNm',
            header: {
                text: '재고상태',
            },
            editable: false,
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            header: {
                text: '보유처',
            },
            editable: false,
        },
        {
            name: 'lastInoutDt',
            fieldName: 'lastInoutDt',
            header: {
                text: '최종입출고일자',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editable: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: {
                text: '조직',
            },
            editable: false,
        },
        {
            name: 'fstInFixDt',
            fieldName: 'fstInFixDt',
            header: {
                text: '입고일자',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editable: false,
        },
        {
            name: 'lastInoutDtlClNm',
            fieldName: 'lastInoutDtlClNm',
            header: {
                text: '최종수불',
            },
            editable: false,
        },
    ],
}
