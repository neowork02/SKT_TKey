<template>
    <div
        class="treeWrap bas"
        id="ordTreev"
        :style="{ cursor: loadingCursor ? 'progress' : 'default' }"
    >
        <v-treeview
            ref="treeOrg"
            :items="items"
            activatable
            @update:active="selectChange"
            :active.sync="active"
            return-object
            :search="search"
            open-all
            :key="triggerRendor"
            color="treepoint"
            dense
            expand-icon="none"
            :open.sync="openNodes"
        >
            <!--
        
            @update:open="onOpen"

            open-on-click
            dense
            expand-icon="mdi-chevron-down"
            selection-type="independent"
            v-model="selection"
            ref="tree"

            :filter="filter"
            selectable
            on-icon="mdi-bookmark"
            off-icon="mdi-bookmark-outline"
            indeterminate-icon="mdi-bookmark-minus"
            -->
            <!-- :open.sync="open"         -->
            <!-- expand-icon="mdi-plus-box-outline" 
                    group="node"
                    ghost-class="ghost"
            -->
            <template v-slot:prepend="{ item, open }">
                <draggable
                    :list="items"
                    :id="item.id"
                    :data-parentId="item.parent"
                    @start="checkStart"
                    @end="checkEnd"
                    v-bind="dragOptions"
                >
                    <!-- 
                        @dblclick="dblClick(item)"
                    -->
                    <v-card
                        name="orgCard1"
                        @contextmenu="showContext($event, item)"
                        @click="click1($event, item)"
                        @dblclick="dblClick(item)"
                    >
                        <div class="tree-inner">
                            <div class="formWrap">
                                <v-btn
                                    text
                                    :ripple="false"
                                    class="ma-0 pa-0"
                                    @click="toggleTreeview($event, item)"
                                >
                                    <!--button icon-->
                                    <v-icon
                                        v-if="
                                            item.children &&
                                            item.children.length > 0
                                        "
                                    >
                                        {{
                                            open
                                                ? 'mdi-folder-open'
                                                : 'mdi-folder'
                                        }}
                                    </v-icon>
                                    <v-icon v-else>
                                        {{
                                            'mdi-checkbox-blank-circle-outline'
                                        }}
                                    </v-icon>
                                    {{
                                        item.name + ' ' + '(' + item.orgCd + ')'
                                    }}
                                </v-btn>
                                <v-row
                                    v-if="
                                        item.name == '새조직' ||
                                        item.name == '' ||
                                        item.name == renameItemName
                                    "
                                    name="newOrg"
                                    :ref="'row_' + item.id"
                                    :id="'row_' + item.id"
                                    align="center"
                                    justify="start"
                                    class="col1"
                                >
                                    <span class="classAddOrg">
                                        <v-text-field
                                            id="txtAddOrg"
                                            medium
                                            :label="item.name"
                                            solo
                                            v-model="itemName"
                                            dense
                                            autofocus
                                            single-line
                                            hide-details
                                            filled
                                            flat
                                            @keyup.enter="renameChild(item)"
                                            @focus="txtEditing(item)"
                                        >
                                        </v-text-field>
                                        <!-- <TCComInput
                                            labelName=""
                                            :value="itemName"
                                        /> -->
                                    </span>
                                    <span class="btnChk">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_tree btn_ty04"
                                            eAttr="ico_treeCheck"
                                            @click="renameChild(item)"
                                        >
                                        </TCComButton>
                                    </span>
                                    <span
                                        class="btnDel"
                                        v-if="
                                            item.name != '' &&
                                            item.name == renameItemName
                                        "
                                    >
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_tree btn_ty04"
                                            eAttr="ico_treeDel"
                                            @click="cancelRename"
                                        >
                                        </TCComButton
                                    ></span>
                                </v-row>
                                <v-row
                                    v-else
                                    :ref="'row_' + item.id"
                                    :id="'row_' + item.id"
                                    align="center"
                                    justify="start"
                                    class="col1"
                                >
                                    <span class="orgCheckbox">
                                        <v-checkbox
                                            v-model="item.useChecked"
                                            @click="checkClick($event, item)"
                                            @change="checkChange($event, item)"
                                        />
                                    </span>
                                    <!--직접 버튼으로 순서변경시 -->
                                    <!-- <span class="btnChk">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_tree btn_ty04"
                                            eAttr="ico_exelup"
                                            @click="upMoveChild($event, item)"
                                        >
                                        </TCComButton>
                                    </span>
                                    <span class="btnChk">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_tree btn_ty04"
                                            eAttr="ico_exeldown"
                                            @click="downMoveChild($event, item)"
                                        >
                                        </TCComButton>
                                    </span> -->
                                    <!--직접 버튼으로 순서변경시 END -->
                                    <!-- <span
                                        class="btnPlus"
                                        v-if="item.depth <= 3"
                                    >
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_tree btn_ty04"
                                            eAttr="ico_treePlus"
                                            @click="addChild(item)"
                                        >
                                        </TCComButton>
                                    </span>
                                    <span class="btnDel">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_tree btn_ty04"
                                            eAttr="ico_treeDel"
                                            @click="removeChild(item)"
                                        >
                                        </TCComButton
                                    ></span> -->
                                </v-row>
                            </div>
                        </div>
                    </v-card>
                </draggable>
            </template>
            <template v-slot:label="{}">
                <!-- default 표시를 막기 위해 empty template 처리함 -->
                <!-- <div class="v-treeview-node__label">{{item.name}}</div> -->
            </template>
        </v-treeview>
        <!-- for context menu begin
            :attach="active.length > 0 ? '#row_'+active[0].id : '#row_1'"
        -->
        <div id="orgMenu1">
            <v-menu
                v-model="showMenu"
                :position-x="x"
                :position-y="y"
                absolute
                offset-y
            >
                <v-list>
                    <v-list-item
                        name="orgList1"
                        v-for="menuItem in menuItems"
                        :key="menuItem"
                        @click="contextClickAction(menuItem)"
                        :disabled="
                            (selectContext && menuItem == '조직이동') ||
                            (!selectContext && menuItem == '조직붙여넣기') ||
                            (!selectContext && menuItem == '조직선택취소') ||
                            (selectContext && menuItem == '명칭변경') ||
                            active.length == 0
                        "
                    >
                        <v-list-item-title
                            ><span class="orgList1Title">{{ menuItem }}</span>
                        </v-list-item-title>
                    </v-list-item>
                </v-list>
            </v-menu>
        </div>
        <!-- for context menu end -->
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/ogm/orgMgmt/helpers'
//import TCComDraggableTree from '@/components/TCComDraggableTree.vue'
//import TreeviewDrag from './TreeviewDrag.vue'
import _ from 'lodash'
import { msgTxt } from '@/const/msg.Properties.js'
import draggable from 'vuedraggable'
import CommonMixin from '@/mixins'
export default {
    mixins: [CommonMixin],
    components: {
        //TCComDraggableTree,
        //TreeviewDrag,
        draggable,
    },
    data() {
        return {
            objAuth: {},
            title: 'BasOgmOrgMgmtTreeviewCont',
            items: [],
            delRows: [],
            activatable: true,
            //selection: [],
            //selectedItem: '',
            //----------------------
            renameItemName: '',
            itemName: '',
            open: true,
            search: null,
            deleteSearch: 0,
            caseSensitive: false,
            selection: [], // selectable 옵션선택시 사용
            selected: '',
            active: [], // activatable 옵션선택시 사용
            nextId: 3000,
            selectedItem: '',
            ancestors: [],
            newItems: [],
            focusNodeName: '',
            triggerRendor: 0,
            //for context menu begin--------------
            showMenu: false,
            x: 0,
            y: 0,
            menuItems: ['조직이동', '조직붙여넣기', '조직선택취소'], //, '명칭변경'],
            selectContext: false,
            selectFrom: '', //조직이동 선택시 active[]
            selectTo: '', //조직붙여넣기 선택시 active[]
            lastScrollPosition: 0,
            x1: 0,
            y1: 0,
            clickedRow: '',
            //for context menu end --------------
            loadingCursor: false,
            expandAllFlag: true,
            txtFocused: false,
            itemEditing: '',
            openNodes: [],
        }
    },
    created() {
        //document.addEventListener('scroll', this.onScroll, true) //for context menu
    },
    beforeDestroy() {
        //document.removeEventListener('scroll', this.onScroll) //for context menu
    },
    async mounted() {
        //const el = document.getElementsByClassName('orgbox1')[0]
        const el = document.getElementById('ordTreev')
        console.log(el)
        el.onscroll = this.onScroll
    },
    computed: {
        ...serviceComputed,
        dragOptions() {
            return {
                animation: 0,
                group: 'node',
                disabled: true,
                ghostClass: 'ghost',
            }
        },
        resultListOrg1: {
            get() {
                return this.resultListOrg
            },
        },
        searchOrg1: {
            get() {
                return this.searchOrg
            },
        },
        saveOrgAction1: {
            get() {
                return this.saveOrgAction
            },
        },
        refeshDealco1: {
            get() {
                return this.refeshDealco
            },
        },
        actOrg1: {
            get() {
                return this.actOrg
            },
        },
        currentOrg1: {
            get() {
                return this.currentOrg
            },
        },
        flatDataCalc() {
            //db api 전달을 위한 평탄 데이타 생성
            let flat = []
            const leng1 = this.items.length
            for (let index = 0; index < leng1; index++) {
                const element = this.items[index]
                this.flatten(element, 0, 'id', flat, (root) => ({ ...root }))
            }
            flat.forEach(function (v) {
                delete v.children
            })
            return flat
        },
    },
    methods: {
        ...serviceMethods,
        txtEditing(e) {
            console.log('text edit !!!!!!!!!!', e)
            this.txtFocused = true
            this.itemEditing = e
        },
        toggleTreeview(e, item) {
            if (this.txtFocused) {
                console.log('txtediting now.. prevent item toggleTreeview')
                e.stopPropagation()
                e.preventDefault()
                return
            }
            this.expandAllFlag = false
            e.preventDefault()
            console.log('openIds', e)
            // this.openIds.length
            //     ? (this.openIds = [])
            //     : this.items.forEach((element) => this.openIds.push(element.id))
            let x1 = e.clientX
            let y1 = e.clientY
            let btn1 = document.elementFromPoint(x1, y1)
            console.log('openIds tag', btn1, e.path[0].tagName)

            if (e.path[0].tagName == 'I') {
                this.$nextTick(() => {
                    try {
                        //document.elementFromPoint(x1 - 20, y1).click() //간접클릭 방식은 미스클릭의 버그가 있어 수정함

                        //직접 노드 오픈처리 방식
                        if (this.openNodes.indexOf(item) === -1) {
                            this.openNodes.push(item)
                        } else {
                            const openNodes1 = this.openNodes.filter((ele) => {
                                return ele.id !== item.id
                            })
                            this.openNodes = openNodes1
                        }
                    } catch (error) {
                        console.log('toggleTreeview light error click null')
                    }
                })
            }
            if (item.id == this.clickedRow.id) e.stopPropagation()
        },
        async initDealcoStore() {
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
            await this.defaultAssign_({
                key: 'resultListAll',
                value: [],
            })
            await this.defaultAssign_({
                key: 'saveDataAdd',
                value: [],
            })
            await this.defaultAssign_({
                key: 'saveDataDel',
                value: [],
            })
            await this.defaultAssign_({
                key: 'currentOrg',
                value: '',
            })
        },
        //for context menu begin--------------
        onScroll() {
            console.log('onScroll')
            const currentScrollPosition =
                window.pageYOffset || document.documentElement.scrollTop
            if (currentScrollPosition < 0) {
                return
            }
            if (this.showMenu == true)
                this.showMenu = currentScrollPosition < this.lastScrollPosition
            this.lastScrollPosition = currentScrollPosition
        },
        async contextClickAction(m) {
            console.log('clicked context:', m)
            if (m == '명칭변경') {
                this.renameItemName = this.active[0].name
                this.itemName = this.renameItemName
            } else if (m == '조직이동') {
                this.selectContext = true
                this.selectFrom = this.active[0]
            } else if (m == '조직선택취소') {
                this.selectContext = false
                this.selectFrom = ''
            } else if (m == '조직붙여넣기') {
                this.selectContext = false
                this.selectTo = this.active[0]
                this.showMenu = false
                console.log('clicked 붙여넣기:', this.selectFrom, this.selectTo)

                if (this.selectFrom.id != this.selectTo.id) {
                    let evt = {
                        from: { ...this.selectFrom },
                        to: { ...this.selectTo },
                    }
                    setTimeout(() => {
                        this.checkStart(evt)
                        this.checkEnd(evt)
                    }, 100)
                }
            }
        },
        click1(e, item) {
            if (this.txtFocused) {
                console.log('txtediting now.. prevent item click1')
                e.stopPropagation()
                e.preventDefault()
                return
            }
            console.log('click1', e, item)
            this.x1 = e.clientX
            this.y1 = e.clientY
            this.clickedRow = this.clone(item)

            this.loadingCursor = false

            // this.$nextTick(() => {
            //     this.dblClick(item)
            // })
        },
        showContext(e, item) {
            console.log('show context')
            e.preventDefault()
            this.showMenu = false
            this.x = e.clientX
            this.y = e.clientY
            //let id1 = document.elementFromPoint(this.x, this.y).id //id가 안잡힐때가 종종 있음. 확인 로직 필요.
            let activeId = this.active.length > 0 ? this.active[0].id : ''

            this.$nextTick(() => {
                console.log(
                    'context show click cond:',
                    item.id,
                    this.clickedRow.id,
                    activeId
                )
                if (
                    'row_' + this.clickedRow.id != item.id &&
                    'row_' + activeId != item.id
                ) {
                    document.elementFromPoint(this.x, this.y).click()
                }
                this.showMenu = true
            })
        },
        //for context menu end--------------
        async selectChange(node) {
            //편집중에 다른 아이템 ACTIVE 시 입력 취소
            if (this.txtFocused) {
                if (node.length > 0 && node[0].id !== this.itemEditing.id) {
                    console.log(
                        'txtediting now.. cancel editing.. selectChange'
                    )
                    this.cancelRename()
                }
                return
            }

            this.renameItemName = ''
            this.itemName = ''

            console.log('selectChange active: ', node)
            await this.initDealcoStore() //조직 선택/클릭시 관련 저장변수 초기화

            this.active = []

            if (node.length > 0) {
                this.clickedRow = this.clone(node[0])
                this.active.push(this.findTreeItem(this.items, node[0].id))
                console.log('select row', node[0], this.active)

                this.selectedItem = this.clone(node[0])
                await this.defaultAssign_({
                    key: 'currentOrg',
                    value: _.clone(this.selectedItem),
                })

                // 무조건 조회시 조직관련 마우스 액션과 겹쳐져서 사이드 이펙트 로 인해 일단 막아둠.
                // 매장조회는 별도 버튼을 마련하여 처리 계획.
                // let param1 = { orgCd: this.selectedItem.orgCd }
                // await this.getBasOgmOrgMgmtStores_({
                //     param: param1,
                // })
                // await this.getBasOgmOrgMgmtStores2_({
                //     param: param1,
                // })
            } else {
                this.$nextTick(() => {
                    //let id1 = document.elementFromPoint(this.x1, this.y1).id
                    //if(id1 != '') document.elementFromPoint(this.x1, this.y1).click()
                    document.elementFromPoint(this.x1, this.y1).click()
                })
            }
        },
        async addChild(itemPar) {
            this.loadingCursor = true
            //this.triggerRendor++ //for rerender v-treeview

            //this.$nextTick
            console.log('add item:start')
            setTimeout(() => {
                //새조직 생성하고 있는 것이 있으면 추가 생성 방지
                if (this.findIdByName(this.items, '') !== undefined) {
                    setTimeout(() => {
                        this.focusNode('')
                    }, 200)
                    return
                }

                //let item = this.findIdByName(this.items, itemPar.name)
                let item = this.findTreeItem(this.items, itemPar.id)
                if (!item.children) {
                    this.$set(item, 'children', [])
                }
                this.itemName = ''

                const id = this.nextId++
                //const name = `${item.name} (${item.children.length})${id}`;
                const name = ``
                let item1 = {
                    rowState: 'created', //'deleted',
                    id,
                    name,
                    parent: item.id,
                    orgCd: id + '',
                    supOrgCd: item.orgCd,
                    aplyStaDt: _.cloneDeep(this.searchParams).aplyStaDt,
                    orgNm: name,
                    orgClCd: item.depth,
                    //lvOrgCd: 'D000060000',
                    //lvOrgCd1: 'D000060001',
                    //lvOrgCd2: 'D000060003',
                    //lvOrgCd3: null,
                    effOrgYn: 'Y',
                    deptCd: null,
                    deptNm: null,
                    hrSoskNm: null,
                    rmks: null,
                    slNetCd: null,
                    orgLvl: item.depth,
                    //orgBizClCd: '0',
                    //sortSeq: '1',
                    //userId: null,
                    //saleChnlCd: '1',
                    ccCd: '0',
                    ssupOrgCd: item.supOrgCd,
                    aplyEndDt: '99991231',
                    dealcoCd: null,
                    hstSeq: null,
                    dealcoNm: null,
                    oldOrgCd: null,
                    sktAgencyCd: null,
                    sktSubCd: null,
                    depth: item.depth + 1,
                    useYn: 'Y',
                    useChecked: true,
                }

                item.children.unshift(_.cloneDeep(item1))
                this.$refs.treeOrg.updateVnodeState(item.id)

                let arr1 = []
                arr1.push(item1)
                console.log('add item:', item1)
                this.active = arr1
                this.newItems.push(item1)

                //this.$refs.treeOrg.updateAll(true)
                //this.$set(this, 'treeOrg', Object.assign({}, this.items))
                this.triggerRendor++ //for rerender v-treeview

                this.loadingCursor = false
            }, 100)
        },
        cancelRename() {
            this.txtFocused = false
            this.itemEditing = ''

            this.itemName = ''
            this.renameItemName = ''
            this.triggerRendor++ //for rerender v-treeview
        },
        renameChild(item) {
            this.txtFocused = false
            this.itemEditing = ''

            const oldName = item.name
            this.$set(item, 'name', this.itemName)
            this.$set(item, 'orgNm', this.itemName)
            if (item.rowState != 'created')
                this.$set(item, 'rowState', 'updated')

            this.itemName = ''
            this.renameItemName = ''

            //this.$refs.treeOrg.updateAll(true)
            this.triggerRendor++ //for rerender v-treeview

            //신규 생성시 부모들 파악하기
            this.ancestors = []
            this.findParent(this.items, item.id)
            console.log('조상들:', this.ancestors.map((x) => x.name).join(',')) //부모,조부모,증조부모 순서

            if (oldName == '') {
                this.$nextTick(() => {
                    console.log('rename & focus', this.ancestors[0].name)
                    setTimeout(() => {
                        this.focusNode(this.ancestors[0].name, false, true)
                    }, 500)
                })
            }
        },
        async removeChild(item) {
            if (item.children && item.children.length > 0) {
                const confirm = await this.showTcComConfirm(
                    '하위조직이 있습니다.\n 조직삭제를 계속 하시겠습니까?'
                )

                if (!confirm) {
                    this.showTcComSnackbar('조직삭제가 취소되었습니다.')
                    return
                }
            } else if (this.resultList.length > 0) {
                const confirm = await this.showTcComConfirm(
                    '소속매장이 있습니다.\n 조직삭제를 계속 하시겠습니까?'
                )

                if (!confirm) {
                    this.showTcComSnackbar('조직삭제가 취소되었습니다.')
                    return
                }
            } else {
                const confirm = await this.showTcComConfirm(
                    '조직삭제를 계속 하시겠습니까?'
                )

                if (!confirm) {
                    this.showTcComSnackbar('조직삭제가 취소되었습니다.')
                    return
                }
            }

            this.$set(item, 'name', 'deleted')
            this.deleteSearch = this.deleteSearch + 1
            if (item.rowState != 'created') this.delRows.push(this.clone(item))
            this.defaultAssign_({
                key: 'currentOrg',
                value: '',
            })

            //부모들 파악하기
            this.ancestors = []
            this.findParent(this.items, item.id)
            console.log('조상들:', this.ancestors.map((x) => x.name).join(',')) //부모,조부모,증조부모 순서

            this.$nextTick(() => {
                console.log('delete & focus', this.ancestors[0].name)
                setTimeout(() => {
                    this.focusNode(this.ancestors[0].name, false, true)
                }, 500)
            })
        },
        //조직순서 변경 begin ----------------------------------
        swapElementPosition(arr, indexFrom, indexTo) {
            console.log('swapElementPosition', indexFrom, indexTo)
            const swappedIndices = ([arr[indexFrom], arr[indexTo]] = [
                arr[indexTo],
                arr[indexFrom],
            ])
            arr.forEach((aV, aVIndex) => {
                if (swappedIndices.indexOf(aV) === -1) {
                    swappedIndices[aVIndex] = aV
                }
            })
            return swappedIndices.filter((sI) => sI != null)
        },
        upMoveChild(e, item) {
            if (!_.isEmpty(e)) {
                e.stopPropagation()
                e.preventDefault()
            }
            console.log('upMoveChild', item)
            let parent = this.findTreeItem(this.items, item.parent)
            const pos1 = parent.children.indexOf(item)
            const leng1 = parent.children.length
            console.log('upMoveChild position', pos1)
            if (_.isEmpty(item.sortSeq)) {
                this.showTcComSnackbar('순서정보가 없어 순서변경 불가 입니다.')
                return
            }
            if (item.orgLvl != '3') {
                this.showTcComSnackbar('3레벨 조직만 순서변경 가능합니다.')
                return
            }
            if (leng1 == 1) {
                this.showTcComSnackbar('최상위 입니다.')
                return
            }
            if (pos1 == 0) {
                this.showTcComSnackbar('최상위 입니다.')
                return
            }
            if (_.isEmpty(parent.children[pos1 - 1].sortSeq)) {
                this.showTcComSnackbar(
                    `순서정보가 없어 순서변경 불가 입니다.(${
                        parent.children[pos1 - 1].name
                    })`
                )
                return
            }
            const sortSeq1 = parent.children[pos1].sortSeq
            parent.children[pos1].sortSeq = parent.children[pos1 - 1].sortSeq
            parent.children[pos1 - 1].sortSeq = sortSeq1
            parent.children = this.swapElementPosition(
                parent.children,
                pos1 == 1 ? 0 : pos1,
                pos1 == 1 ? 1 : pos1 - 1
            )
        },
        downMoveChild(e, item) {
            if (!_.isEmpty(e)) {
                e.stopPropagation()
                e.preventDefault()
            }
            console.log('downMoveChild', item)
            let parent = this.findTreeItem(this.items, item.parent)
            const pos1 = parent.children.indexOf(item)
            const leng1 = parent.children.length
            console.log('downMoveChild position', pos1)
            if (_.isEmpty(item.sortSeq)) {
                this.showTcComSnackbar('순서정보가 없어 순서변경 불가 입니다.')
                return
            }
            if (item.orgLvl != '3') {
                this.showTcComSnackbar('3레벨 조직만 순서변경 가능합니다.')
                return
            }
            if (leng1 == 1) {
                this.showTcComSnackbar('최하위 입니다.')
                return
            }
            if (pos1 + 1 == leng1) {
                this.showTcComSnackbar('최하위 입니다.')
                return
            }
            if (_.isEmpty(parent.children[pos1 + 1].sortSeq)) {
                this.showTcComSnackbar(
                    `순서정보가 없어 순서변경 불가 입니다.(${
                        parent.children[pos1 - 1].name
                    })`
                )
                return
            }
            const sortSeq1 = parent.children[pos1].sortSeq
            parent.children[pos1].sortSeq = parent.children[pos1 + 1].sortSeq
            parent.children[pos1 + 1].sortSeq = sortSeq1
            parent.children = this.swapElementPosition(
                parent.children,
                pos1,
                pos1 + 1
            )
        },
        //조직순서 변경 end ----------------------------------
        //사용여부 체크박스 begin ----------------------------------
        recursivelyUpdateChildrenProperties(node, func, param) {
            if (
                typeof func !== 'function' ||
                !Object.prototype.hasOwnProperty.call(node, 'children') ||
                node.children.length < 1
            )
                return
            const newNodeChildren = node.children.map((child) => {
                const newChild = func(node, child, param)
                return {
                    ...child,
                    ...newChild,
                    children: recurseChildren(
                        newChild,
                        newChild.children,
                        func,
                        param
                    ),
                }
            })
            function recurseChildren(parent, children, func, param) {
                if (!children) return
                const newChildren = children.map((child) => {
                    const newChild = func(parent, child, param)
                    if (
                        Object.prototype.hasOwnProperty.call(
                            child,
                            'children'
                        ) &&
                        child.children.length > 0
                    ) {
                        return {
                            ...child,
                            ...newChild,
                            children: recurseChildren(
                                newChild,
                                newChild.children,
                                func,
                                param
                            ),
                        }
                    }
                    return {
                        ...child,
                        ...newChild,
                    }
                })
                return newChildren
            }
            return newNodeChildren
        },
        setUseChecked(parentNode, child) {
            return {
                ...child,
                useChecked: parentNode.useChecked,
            }
        },
        checkChange(e, item) {
            console.log('checkChange 0---', e, item)
            if (item.parent !== null) {
                const parent1 = this.findItem(item.parent, this.items)
                if (!parent1.useChecked) {
                    this.$nextTick(() => {
                        item.useChecked = parent1.useChecked
                    })
                    this.showTcComSnackbar('상위조직이 [사용안함] 상태입니다.')
                    return
                }
            }
            const useCheckedChildren = this.recursivelyUpdateChildrenProperties(
                item,
                this.setUseChecked
            )
            if (useCheckedChildren !== undefined)
                item['children'] = useCheckedChildren
            console.log('checkChange 1---', e, item, useCheckedChildren)
        },
        checkClick(e, item) {
            console.log('checkClick', item.useChecked, e, item)
            //checkbox 가 treeview node click(click1()) 보다 우선함
            //하단 click event 전달 불필요와 여러번 클릭되는 현상 방지
            e.stopPropagation()
            e.preventDefault()
        },
        //사용여부 체크박스 end ----------------------------------
        findItem(id, items = null) {
            if (!items) {
                items = this.items
            }

            return items.reduce((acc, item) => {
                if (acc) {
                    return acc
                }

                if (item.id === id) {
                    return item
                }

                if (item.children) {
                    return this.findItem(id, item.children)
                }

                return acc
            }, null)
        },
        depthDecorator(array, depth = 1, parent = null) {
            return array.map((child) =>
                Object.assign(_.cloneDeep(child), {
                    depth,
                    parent,
                    children: this.depthDecorator(
                        child.children || [],
                        depth + 1,
                        child.id
                    ),
                })
            )
        },
        onOpen() {
            //event
            //console.log('🚀 ~ open treeview', event)

            //treeview open시 첫 focus node 설정시
            if (this.focusNodeName != '') {
                this.focusNode(this.focusNodeName)
                this.focusNodeName = ''
            }
        },
        onFocusCall(event) {
            console.log('🚀 ~ on call', event, this.$refs.row_1)
            this.focusNode('경영기획팀')
        },
        async focusNode(nodename, search = false, noscroll = false) {
            let id1 = this.findIdByName(this.items, nodename, search)
            if (!id1) return
            console.log(
                'focusNode',
                nodename,
                id1.id,
                this.$refs['row_' + id1.id]
            )
            if (this.$refs['row_' + id1.id]) {
                this.$refs['row_' + id1.id].click()
                console.log('this.selected', this.selected) //selected 작동한다. @update:active="selectChange" 이벤트도 동작한다.
                //해당 row 위치로 스크롤 뷰 에 나타나게 움직이게 한다.
                // document
                //     .getElementById(this.$refs['row_' + id1.id].id)
                //     .scrollIntoView({
                //         behavior: 'smooth',
                //         block: 'center', //start || center || end || nearest
                //         inline: 'nearest', //start || center || end || nearest
                //     })

                if (!noscroll) {
                    //bug fix
                    let elementDiv = document.getElementById('ordTreev')
                    elementDiv.scrollTop = 0
                    let element = document.getElementById(
                        this.$refs['row_' + id1.id].id
                    )
                    elementDiv.scrollTo({
                        top: element.getBoundingClientRect().top - 400,
                        behavior: 'smooth',
                    })
                }
            }
        },
        flatFilter(nestedProp, compareKey, compareId, arr) {
            return arr.filter((o) => {
                const keep = o[compareKey] != compareId
                if (keep && o[nestedProp]) {
                    o[nestedProp] = this.flatFilter(
                        nestedProp,
                        compareKey,
                        compareId,
                        o[nestedProp]
                    )
                }
                return keep
            })
        },
        flatten(root, depth = 0, key = 'id', flat = [], pick = () => {}) {
            flat.push({
                [key]: root[key],
                depth: depth++,
                ...pick(root, depth, key, flat),
            })

            if (Array.isArray(root.children)) {
                root.children.forEach((child) =>
                    this.flatten(child, depth, key, flat, pick)
                )
            }
        },
        findIdByName: function (items, name, search = false) {
            if (!items) {
                return
            }
            const leng1 = items.length
            for (let i = 0; i < leng1; i++) {
                let item = items[i]
                // Test current object
                if (item.name == name) {
                    return item
                }
                if (search && item.name.indexOf(name) !== -1) {
                    return item
                }
                // Test children recursively
                const child = this.findIdByName(item.children, name, search)
                if (child) {
                    return child
                }
            }
        },
        findTreeItem: function (items, id) {
            if (!items) {
                return
            }
            const leng1 = items.length
            for (let i = 0; i < leng1; i++) {
                let item = items[i]
                // Test current object
                if (item.id == id) {
                    return item
                }
                // Test children recursively
                const child = this.findTreeItem(item.children, id)
                if (child) {
                    return child
                }
            }
        },
        findParent: function (items, id) {
            if (!items || !id) {
                return null
            }
            const leng1 = items.length
            for (let i = 0; i < leng1; i++) {
                let item = items[i]
                // Test current object
                if (item.id == id) {
                    return item
                }
                // Test children recursively
                const child = this.findParent(item.children, id)
                if (child) {
                    this.ancestors.push(item)
                    return child
                }
            }
        },
        checkStart: function (evt) {
            let self = this
            self.active = []
            self.active.push(self.findTreeItem(self.items, evt.from.id))
            console.log('checkStart', this.active[0].parent, evt.from.id, evt)
        },
        checkEnd: function (evt) {
            this.loadingCursor = true

            setTimeout(() => {
                let self = this
                let itemSelected = self.active[0]
                let fromParent = itemSelected.parent
                    ? self.findTreeItem(self.items, itemSelected.parent)
                    : null
                let toParent = self.findTreeItem(self.items, evt.to.id)

                //새로운 아이템은 움직임 무효
                if (itemSelected.name == '' || itemSelected.name == '새조직') {
                    console.log(
                        '부모',
                        this.findParent(self.items, itemSelected.id)
                    )
                    this.showTcComAlert(
                        '명칭이 정해지지 않은 노드는 옮길수 없습니다.'
                    )
                    return false
                }

                //현재부모 에게 움직임 무효
                if (itemSelected.parent == toParent.id) {
                    this.loadingCursor = false
                    return false
                }
                //같은 부모 안에서 움직임음 무효.
                //if(itemSelected.parent == toParent.parent) return false

                //부모가 될 노드에 자식노드가 원래 없다면 무효.
                //자식노드가 없는 곳에 옮기려면 가짜 자식 노드를 [+]버튼으로 만든후 필요한 노드를 이동후 가짜 노드를 지우면 된다.
                if (!toParent.children || toParent.children.length == 0)
                    return false

                console.log('checkEnd', itemSelected, fromParent, toParent)

                let objFrom = fromParent ? fromParent.children : self.items
                objFrom.splice(objFrom.indexOf(itemSelected), 1)

                if (toParent.id === itemSelected.id) {
                    itemSelected.parent = null
                    if (itemSelected.rowState != 'created')
                        itemSelected.rowState = 'updated'
                    self.items.push(itemSelected)
                } else {
                    itemSelected.parent = toParent.id
                    if (itemSelected.rowState != 'created')
                        itemSelected.rowState = 'updated'

                    //이동할 조직으로 소속 변경
                    itemSelected['supOrgCd'] = toParent.orgCd
                    itemSelected['ssupOrgCd'] = toParent.supOrgCd

                    //if(!toParent.children) toParent.children = [] //자식노드가 없으면 만들기
                    if (toParent.children) toParent.children.push(itemSelected) //자식노드가 원래 있는 경우 이동
                }
                //self.saveDatas(itemSelected)
                //   self.active = [];

                //this.$refs.treeOrg.updateAll(true)
                this.triggerRendor++ //for rerender v-treeview

                //이동 후 부모 파악하기
                this.ancestors = []
                this.findParent(this.items, itemSelected.id)
                console.log(
                    itemSelected.name + '(바뀐 조상들):',
                    this.ancestors.map((x) => x.name).join(',')
                ) //부모,조부모,증조부모 순서

                this.loadingCursor = false
                this.$nextTick(() => {
                    console.log('move & focus', this.ancestors[0].name)
                    setTimeout(() => {
                        this.focusNode(this.ancestors[0].name, false, true)
                    }, 500)
                })
            })

            return false
        },
        convertHierarchical(array, parentProp, childrenProp) {
            let map = {}
            const leng1 = array.length
            for (let i = 0; i < leng1; i++) {
                let obj = _.clone(array[i])
                obj.children = []

                map[obj[childrenProp]] = obj

                let parent = obj[parentProp] || '-'
                if (!map[parent]) {
                    map[parent] = {
                        children: [],
                    }
                }

                map[parent].children.push(obj)
            }

            for (let prop in map) {
                if (map[prop].children.length === 0) {
                    delete map[prop].children
                }
            }

            return map['-'].children
        },
        clone(obj) {
            if (null == obj || 'object' != typeof obj) return obj
            let copy = Object.create(null)
            for (let attr in obj) {
                if (obj.hasOwnProperty.call(obj, attr)) copy[attr] = obj[attr]
            }
            return copy
        },
        validationCheck() {
            return true
        },
        async saveData() {
            let saveRows = []

            let data1 = this.flatDataCalc.filter(
                (o) =>
                    o.rowState == 'created' ||
                    o.rowState == 'updated' ||
                    o.sortSeq != o.oldSortSeq ||
                    o.useChecked != (o.useYn === 'Y' ? true : false)
            )
            for (let i = 0; i < data1.length; i++) {
                saveRows.push({
                    ...data1[i],
                    rowState:
                        data1[i].rowState == 'readed'
                            ? 'updated'
                            : data1[i].rowState,
                    useYn: data1[i].useChecked ? 'Y' : 'N',
                })
            }
            for (let i = 0; i < this.delRows.length; i++) {
                saveRows.push({
                    ...this.delRows[i],
                    rowState: 'deleted',
                    opDt: this.searchParams.aplyStaDt,
                })
            }

            if (!saveRows.length) {
                this.showTcComAlert(msgTxt.MSG_01002)
                return false
            }

            console.log('org crud api call', saveRows)

            let res1 = await this.saveOrgMgmt_({ saveRows })
            if (res1 === 1) {
                //정상등록시 다시 조회
                this.$emit('Refresh', '')
            }
        },
        async dblClick(item) {
            console.log('dblclick:', item.name, item.rowState)
            if (item.rowState != 'created') await this.searchDealco(item)
        },
        async searchDealco(item) {
            if (item.orgCd) {
                let param1 = {
                    orgCd: item.orgCd,
                    aplyStaDt: this.searchParams.aplyStaDt,
                }
                await this.getBasOgmOrgMgmtStores_({
                    param: param1,
                })
                await this.getBasOgmOrgMgmtStores2_({
                    param: param1,
                })
            }
        },
        async focusInit() {
            await this.focusNode('')
            this.active = []
            let elementDiv = document.getElementById('ordTreev')
            elementDiv.scrollTop = 0
            console.log('focusInit', this.$refs['row_1'])
            if (this.$refs['row_1'] !== undefined) {
                console.log('focusInit smooth')
                let element = document.getElementById(this.$refs['row_1'].id)
                elementDiv.scrollTo({
                    top: element.getBoundingClientRect().top - 400,
                    behavior: 'smooth',
                })
            }
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        actOrg1(val, oldVal) {
            if (val.length > 1) {
                console.log('actOrg1', val)
                if (val == 'add') {
                    console.log(
                        'find item',
                        this.currentOrg1,
                        this.findItem(this.currentOrg1.id)
                    )
                    const curr1 = _.clone(this.currentOrg1, true)
                    const item1 = _.clone(this.findItem(curr1.id), true)
                    this.addChild(item1)
                    this.defaultAssign_({
                        key: 'actOrg',
                        value: '',
                    })
                } else if (val == 'del') {
                    console.log(
                        'find item',
                        this.currentOrg1,
                        this.findItem(this.currentOrg1.id)
                    )
                    const curr1 = _.clone(this.currentOrg1)
                    this.removeChild(this.findItem(curr1.id), true)
                    this.defaultAssign_({
                        key: 'actOrg',
                        value: '',
                    })
                } else if (val == 'rename') {
                    console.log('rename item', this.currentOrg1)
                    this.contextClickAction('명칭변경')
                    this.defaultAssign_({
                        key: 'actOrg',
                        value: '',
                    })
                } else if (val == 'moveFrom') {
                    console.log('moveFrom item', this.currentOrg1)
                    this.contextClickAction('조직이동')
                } else if (val == 'moveTo') {
                    console.log('moveTo item', this.currentOrg1)
                    this.contextClickAction('조직붙여넣기')
                    this.defaultAssign_({
                        key: 'actOrg',
                        value: '',
                    })
                } else if (val == 'moveCancel') {
                    console.log('moveCancel item', this.currentOrg1)
                    this.contextClickAction('조직선택취소')
                    this.defaultAssign_({
                        key: 'actOrg',
                        value: '',
                    })
                } else if (val == 'moveUp') {
                    console.log('moveUp item', this.currentOrg1)
                    let item1 = this.findTreeItem(
                        this.items,
                        this.currentOrg1.id
                    )
                    this.upMoveChild(null, item1)
                    this.defaultAssign_({
                        key: 'actOrg',
                        value: '',
                    })
                } else if (val == 'moveDown') {
                    console.log('moveDown item', this.currentOrg1)
                    let item1 = this.findTreeItem(
                        this.items,
                        this.currentOrg1.id
                    )
                    this.downMoveChild(null, item1)
                    this.defaultAssign_({
                        key: 'actOrg',
                        value: '',
                    })
                }
            }
        },
        // eslint-disable-next-line no-unused-vars
        async searchOrg1(val, oldVal) {
            const val1 = _.clone(val)
            console.log('searchOrg1', val)
            if (val.length > 1) {
                await this.defaultAssign_({
                    key: 'resultList',
                    value: [],
                })
                await this.defaultAssign_({
                    key: 'resultListAll',
                    value: [],
                })
                await this.defaultAssign_({
                    key: 'currentOrg',
                    value: '',
                })

                if (this.expandAllFlag == false) {
                    this.expandAllFlag = true
                    this.$refs.treeOrg.updateAll(true)
                }

                //focus init
                await this.focusInit()
                setTimeout(() => {
                    this.focusNode(val1, true)
                }, 200)
                await this.defaultAssign_({
                    key: 'searchOrg',
                    value: '',
                })
            }
        },
        // eslint-disable-next-line no-unused-vars
        resultListOrg1(val, oldVal) {
            this.items = []
            this.active = []
            this.initDealcoStore()
            this.triggerRendor++ //for rerender v-treeview

            const val1 = _.cloneDeep(val)
            let body = val1
                //.filter((item) => item.type == 'I')
                .map((object, index) => ({
                    ...object,
                    id: index,
                    name: object.orgNm,
                    rowState: 'readed',
                    oldSortSeq: object.sortSeq,
                    useChecked: object.useYn === 'Y' ? true : false,
                }))
            this.delRows = []
            if (body.length > 0) {
                let data1 = this.convertHierarchical(body, 'supOrgCd', 'orgCd')
                console.log('convertHierarchical', body, data1)
                this.items = this.depthDecorator(data1)
                //treeview open시 첫 focus node 설정시
                this.focusNodeName = this.items[0].name
            } else {
                this.items = []
            }
            this.$refs.treeOrg.updateAll(true)
            this.triggerRendor++ //for rerender v-treeview
            console.log('resultListOrg1 watch')
            if (body.length > 0) {
                this.$nextTick(() => {
                    setTimeout(() => {
                        let elementDiv = document.getElementById('ordTreev')
                        elementDiv.scrollTop = 0

                        // this.defaultAssign_({
                        //     key: 'searchOrg',
                        //     value: body[0].orgNm,
                        // })
                        // OR
                        // this.focusInit()
                        console.log('open nodes', this.openNodes)
                    }, 500)
                })
            }

            //db api 전달을 위한 평탄 데이타 생성 ------------------------------
            //console.log('create flat', this.flatDataCalc)
        },
        async saveOrgAction1(val, oldVal) {
            if (val == true) {
                console.log('saveOrgAction1: ', val, oldVal)
                if (this.validationCheck()) {
                    await this.saveData()
                } else {
                    console.log('validation false')
                }

                //에러든 정상종료든 완료되면 flag처리
                await this.defaultAssign_({
                    key: 'saveOrgDone',
                    value: true,
                })
            }
        },
        async refeshDealco1(val, oldVal) {
            if (val == true) {
                console.log('refeshDealco1: ', val, oldVal)
                await this.searchDealco(this.currentOrg1)

                //초기화
                await this.defaultAssign_({
                    key: 'refeshDealco',
                    value: false,
                })
            }
        },
        // for treeview action :FROM -------------------------------------------------
        triggerRendor(val, oldVal) {
            console.log('triggerRendor', val, oldVal)
        },
        newItems(val, oldVal) {
            console.log('newItems ', val, oldVal)
            //depth re-calc
            this.items = this.depthDecorator(this.items)
            //console.log('create flat', this.flatDataCalc)
        },
        // eslint-disable-next-line no-unused-vars
        deleteSearch: function (val) {
            this.items = this.flatFilter(
                'children',
                'name',
                'deleted',
                this.items
            )
            this.items = this.depthDecorator(this.items)

            //this.$refs.treeOrg.updateAll(true)
            this.triggerRendor++ //for rerender v-treeview
        },
        active: function (val) {
            console.log('active:', val[0])
        },
        // for treeview action :TO -------------------------------------------------
    },
}
</script>

<style>
.orgbox1 {
    height: 625px;
    overflow-y: scroll;
    border: 1px solid #ccc;
    border-radius: 1px;
}
div[id='ordTreev'] {
    height: 558px !important;
    overflow-y: scroll;
    border: 1px solid #ccc;
    border-radius: 1px;
}
div[name='orgCard1'] {
    background-color: transparent !important;
    box-shadow: none !important;
}
/* .classAddOrg {
    border: 1px solid #ccc;
    max-height: 20px !important;
    margin-top: -16px !important;
    background-color: #ccc !important;
} */
/* .col1a {
    margin-top: 1px;
    margin-left: -15px !important;
    padding-left: 0px !important;
} */
.ghost {
    opacity: 0.5;
    background: #c8ebfb;
    visibility: hidden;
}

div[name='newOrg'] span > div {
    margin-top: -16px !important;
    max-width: 210px !important;
    max-height: 20px !important;
}
div[name='newOrg'] > span > div > div > div.v-input__slot {
    width: 200px;
    background-color: #f9f9f9 !important;
    max-height: 20px !important;
}

div[name='orgList1'] {
    min-height: 25px !important;
}

.orgList1Title {
    font-size: 14px !important;
}
.orgCheckbox {
    margin-top: 7px !important;
}
</style>
