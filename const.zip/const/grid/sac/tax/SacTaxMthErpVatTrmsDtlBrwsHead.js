import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'orgNm', //	 조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', //	 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', //	 정산처 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accPlc', //	 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accPlcNm', //	 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zbudat', //	귀속일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zifdate', // 전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxClNm', //	 전송구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ztrusr', //  전송자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zcnt', //  건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zconfirm', //  확정여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zconfirmNm', //  확정여부명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zconfdat', //  확정일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zconfusr', //  확정자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zdele', //  취소여부 << -- 삭제표시?
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errlog', //  Error Log
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zitem', //	zitem
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chk', //	chk
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', //
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            header: '조직명',
        },
        {
            name: 'accShopCd',
            fieldName: 'accShopCd',
            type: 'data',
            header: '정산처매장코드',
        },
        {
            name: 'accPlc',
            fieldName: 'accPlc',
            type: 'data',
            header: '정산처',
        },
        {
            name: 'accPlcNm',
            fieldName: 'accPlcNm',
            type: 'data',
            header: '정산처명',
        },
        {
            name: 'zbudat',
            fieldName: 'zbudat',
            type: 'data',
            header: '귀속일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'zifdate',
            fieldName: 'zifdate',
            type: 'data',
            width: '150',
            header: '전송일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'taxClNm',
            fieldName: 'taxClNm',
            type: 'data',
            width: '150',
            header: '전송구분',
        },
        {
            name: 'ztrusr',
            fieldName: 'ztrusr',
            type: 'data',
            header: '전송자',
        },
        {
            name: 'zcnt',
            fieldName: 'zcnt',
            type: 'data',
            header: 'ITEM건수',
        },
        {
            name: 'zconfirm',
            fieldName: 'zconfirm',
            type: 'data',
            header: '확정여부',
        },
        {
            name: 'zconfirmNm',
            fieldName: 'zconfirmNm',
            type: 'data',
            header: '확정여부',
        },
        {
            name: 'zconfdat',
            fieldName: 'zconfdat',
            type: 'data',
            header: '확정일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'zconfusr',
            fieldName: 'zconfusr',
            type: 'data',
            header: '확정자',
        },
        {
            name: 'zdele',
            fieldName: 'zdele',
            type: 'data',
            header: '취소여부',
        },
        {
            name: 'errlog',
            fieldName: 'errlog',
            type: 'data',
            header: 'Error Log',
        },
    ],
    layout: [
        'orgCd',
        'orgNm',
        'accShopCd',
        'accPlc',
        'accPlcNm',
        'zbudat',
        'zifdate',
        'taxClNm',
        'ztrusr',
        'zcnt',
        'zconfirmNm',
        'zconfdat',
        'zconfusr',
        'zdele',
        'errlog',
    ],
}

export const DTL_HEADER = {
    fields: [
        {
            fieldName: 'zitem', // 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'name1', // 상호명
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'kfrepre', // 대표자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'kftbus', // 업태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'kftind', // 업종
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hwbas', // 공급가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'hwste', //  세액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ztotamt', // 합계금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ztaxno', //  세금계산서번호
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'zitem',
            fieldName: 'zitem',
            type: 'data',
            width: '100',
            header: '순번',
        },
        {
            name: 'name1',
            fieldName: 'name1',
            type: 'data',
            width: '200',
            header: '상호명',
        },
        {
            name: 'kfrepre',
            fieldName: 'kfrepre',
            type: 'data',
            width: '200',
            header: '대표자명',
        },
        {
            name: 'kftbus',
            fieldName: 'kftbus',
            type: 'data',
            width: '200',
            header: '업태',
        },
        {
            name: 'kftind',
            fieldName: 'kftind',
            type: 'data',
            width: '200',
            header: '업종',
        },
        {
            name: 'hwbas',
            fieldName: 'hwbas',
            type: 'data',
            width: '100',
            header: '공급가',
            numberFormat: '#,##0',
        },
        {
            name: 'hwste',
            fieldName: 'hwste',
            type: 'data',
            width: '100',
            header: '세액',
            numberFormat: '#,##0',
        },
        {
            name: 'ztotamt',
            fieldName: 'ztotamt',
            type: 'data',
            width: '100',
            header: '합계금액',
            numberFormat: '#,##0',
        },
        {
            name: 'ztaxno',
            fieldName: 'ztaxno',
            type: 'data',
            width: '100',
            header: '세금계산서번호',
        },
    ],
}
