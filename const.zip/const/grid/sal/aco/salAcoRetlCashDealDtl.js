import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, //조직트리
        },
        {
            fieldName: 'bizChrgOrgNm',
            dataType: ValueType.TEXT, // 사업담당명
        },
        {
            fieldName: 'teamOrgNm',
            dataType: ValueType.TEXT, // 영업팀명
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 영업파트
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 영업파트명
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 대리점코드
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT, // 매장명
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT, // 매장유형
        },
        {
            fieldName: 'dealcoClNm1',
            dataType: ValueType.TEXT, // 매장유형
        },
        {
            fieldName: 'dealEndDt',
            dataType: ValueType.TEXT, // 거래종료일
        },
        {
            fieldName: 'payReqNm',
            dataType: ValueType.TEXT, //  수납의뢰처
        },
        {
            fieldName: 'clsDt',
            dataType: 'datetime', // 매출일자
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'saleDtm',
            dataType: 'datetime', // 개통일자
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'bondItmCd',
            dataType: ValueType.TEXT, // 채권구분
        },
        {
            fieldName: 'bondItmNm',
            dataType: ValueType.TEXT, // 채권구분
        },
        {
            fieldName: 'trClNm',
            dataType: ValueType.TEXT, // 발생구분
        },
        {
            fieldName: 'saleAmt',
            dataType: ValueType.NUMBER, // 금액
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, // 비고
        },
    ],
    columns: [
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',

            styles: {
                textAlignment: 'center',
            },
            header: '대리점코드',
        },
        {
            name: 'bizChrgOrgNm',
            fieldName: 'bizChrgOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '사업담당',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'teamOrgNm',
            fieldName: 'teamOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '영업팀',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '영업파트',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '영업파트',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '매장명',
                showTooltip: false,
            },
            footer: {
                text: '계',
            },
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '매장유형',
                showTooltip: false,
            },
            footer: {
                text: '계',
            },
            visible: false,
        },
        {
            name: 'dealcoClNm1',
            fieldName: 'dealcoClNm1',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '매장유형',
                showTooltip: false,
            },
            footer: {
                text: '계',
            },
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '거래종료일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'payReqNm',
            fieldName: 'payReqNm',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '수납의뢰처',
                showTooltip: false,
            },
        },
        {
            name: 'clsDt',
            fieldName: 'clsDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매출일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'bondItmCd',
            fieldName: 'bondItmCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채권구분',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'bondItmNm',
            fieldName: 'bondItmNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채권구분',
                showTooltip: false,
            },
        },
        {
            name: 'trClNm',
            fieldName: 'trClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '발생구분',
                showTooltip: false,
            },
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: ' 금액',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
        },
    ],
}
