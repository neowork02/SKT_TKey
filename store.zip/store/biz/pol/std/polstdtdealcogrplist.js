/**************************************************************************************************************
 * 가상데이터 선언 영역
 **************************************************************************************************************/
import send from '@/api/axios-tdcs'
// import _ from 'lodash'

export default {
    namespaced: true,
    state: {
        // 목록검색조건
        dsCondition: {
            dealcoGrpNm: '', // 거래처그룹명
            useYn: '', // 사용여부
            modUserId: '', // 사용자ID
            modUserNm: '', // 사용자명
        },
        // 거래처그룹목록
        dsPolDealCoGrpList: [],
    },

    mutations: {
        setDsCondition(state, payload) {
            state.dsCondition = {
                ...state.dsCondition,
                ...payload,
            }
        },
        setPolDealCoGrpList(state, payload) {
            state.dsPolDealCoGrpList = payload
        },
        setDsPolDealCoGrpList(state, payload) {
            state.dsPolDealCoGrpList = payload
        },
    },
    actions: {
        async getPolDealCoGrpList({ commit }, payload) {
            console.log('getPolTDealCoGrpList::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'get',
                    url: '/api/v1/backend/pol/std/getPolTdealcoGrpList',
                    params: payload,
                })
                    .then((res) => {
                        console.log('getPolDealCoGrpList[then]', res)
                        commit('setPolDealCoGrpList', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
    },
    getters: {
        //
    },
}
