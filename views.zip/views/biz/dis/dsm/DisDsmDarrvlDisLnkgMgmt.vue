<!-----------------------------------------------
 * 업무그룹명: 바로도착Master관리>바로도착 재고 연동관리
 * 서브업무명: 바로도착 재고 연동관리
 * 설명: 바로도착 재고 연동관리
 * 작성자: P179237
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>바로도착 재고 연동관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    eClass="btn_ty"
                    :eOutlined="true"
                    :objAuth="objAuth"
                    @click="btnExcelUpload"
                    >엑셀업로드</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="cfSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="cfNew"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="cfDelete"
                    :objAuth="this.objAuth"
                >
                    삭제
                </TCComButton>
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComMultiComboBox
                        codeId="ZBAS_C_00820"
                        labelName="권역"
                        v-model="dsCondition.rgnCdList"
                        :objAuth="objAuth"
                    ></TCComMultiComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="dsCondition.prodCd"
                        :codeVal.sync="dsCondition.prodNm"
                        labelName="모델"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onProdsEnterKey"
                        @appendIconClick="onProdsIconClick"
                        @input="onProdsInput"
                    />
                    <BasBcoProdsPopup
                        v-if="basBcoProdsShow"
                        :parentParam="dsCondition"
                        :rows="resultProdsRows"
                        :dialogShow.sync="basBcoProdsShow"
                        @confirm="onProdsReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="dsCondition.prodNm"
                        labelName="모델명"
                        @enterKey="cfSearch"
                    >
                    </TCComInput>
                </div>
            </div>
        </div>
        <!-- //Search_div -->

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="바로도착 재고 연동관리"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getPagingData"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <DisDsmDarrvlDisLnkgRgst
            v-if="showPopup === true"
            ref="popup"
            :dialogShow.sync="showPopup"
            :popupParams.sync="popupParams"
            @confirm="onReturnDisDsmDarrvlDisLnkgRgst"
        />
        <DisDsmDarrvlDisLnkgXlsUpld
            ref="popup"
            v-if="showDisDsmDarrvlDisLnkgXlsUpld === true"
            :dialogShow.sync="showDisDsmDarrvlDisLnkgXlsUpld"
            :parentParam="popupParamsXlsUpld"
            @confirm="onReturnDisDsmDarrvlDisLnkgXlsUpld"
        />
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil, CommonGrid } from '@/utils'
import _ from 'lodash'
import { SacCommon } from '@/views/biz/sac/js'

import { G_HEADER } from '@/const/grid/dis/dsm/disDsmDarrvlDisLnkgMgmtHead'

import api from '@/api/biz/dis/dsm/disDsmDarrvlDisLnkgMgmt'

import attachedFileApi from '@/api/common/attachedFile'

import DisDsmDarrvlDisLnkgRgst from '@/views/biz/dis/dsm/DisDsmDarrvlDisLnkgRgst.vue'
import DisDsmDarrvlDisLnkgXlsUpld from '@/views/biz/dis/dsm/DisDsmDarrvlDisLnkgXlsUpld.vue'

//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================

export default {
    name: 'DisDsmDarrvlDisLnkgMgmt',
    mixins: [CommonMixin],
    components: {
        DisDsmDarrvlDisLnkgRgst,
        DisDsmDarrvlDisLnkgXlsUpld,
        BasBcoProdsPopup,
    },
    data() {
        return {
            indicatorOpt: { sort: 'ASC' },
            dsCondition: { prodCd: '', prodNm: '' },
            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},
            view: G_HEADER,
            dsResult: [],

            objAuth: {}, // ?????

            deleteRows: [], // 삭제대상 rows

            //popup
            popupParams: {},
            showPopup: false,
            //엑셀업로드 popup
            popupParamsXlsUpld: {},
            showDisDsmDarrvlDisLnkgXlsUpld: false,
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            //====================//상품팝업관련==================
            // paging
            rowCnt: 15, // 표시할 행의 갯수
            //조회 파라미터
            reqParams: {},
        }
    },
    created() {
        this.gridData = this.GridSetData()
    },
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 초기값 세팅
        this.fInit()
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            this.gridObj.setGridState(true, false, true)
            this.gridData = this.GridSetData()
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 폼 초기화
        fInit: function () {
            // this.dsCondition.strdDt = SacCommon.getToday()
        },
        cfSearch: function () {
            this.dsResult = []
            this.gridObj.setRows([])

            this.dsCondition.pageSize = this.rowCnt
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getPagingData(1)
        },
        getPagingData: function (pageNum) {
            this.dsCondition.pageNum = pageNum
            const formData = this.getDsCondition()

            // 페이징 조회
            api.getRgnRstProdLists(formData).then((resultData) => {
                if (resultData) {
                    this.dsResult = resultData.gridList
                    this.gridObj.setRows(this.dsResult)
                    // 페이징 관련
                    this.gridObj.setGridIndicator(
                        resultData.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.GridSetData() //초기화
                    this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
            })
        },

        // 조회조건 가져오기
        getDsCondition: function () {
            // testdata
            // this.dsCondition.rgnCd = '1001,1002'
            //testdata
            this.dsCondition.rgnCd = _.toString(this.dsCondition.rgnCdList)

            const reqData = SacCommon.objectRemovedArray(this.dsCondition)

            // 엑셀다운로드
            this.reqParams = reqData

            const formData = {
                dsCondition: {
                    ...reqData,
                },
            }
            return formData
        },

        // 초기화
        clearPage() {
            CommonUtil.clearPage(this, 'dsCondition', this.gridObj)
        },
        // 신규
        cfNew: function () {
            //this.popupParams = { ...this.dsCondition }
            this.showPopup = true
        },
        // 삭제
        cfDelete: function () {
            this.deleteRows = []
            const rows = this.gridObj.gridView.getCheckedRows(true)
            if (_.isEmpty(rows) || rows.length == 0) {
                this.showTcComAlert('삭제할 데이터가 없습니다.')
                return false
            }
            for (let i in rows) {
                const idx = rows[i]
                const jsonRow = this.gridObj.dataProvider.getJsonRow(idx)
                this.deleteRows.push(jsonRow)
            }

            this.reqRgnRstProdDels()
        },
        async reqRgnRstProdDels() {
            const confirm = await this.showTcComConfirm('삭제 하시겠습니까?')
            if (confirm) {
                const formData = {
                    dsCondition: {
                        rowDatas: this.deleteRows,
                    },
                }
                console.log('삭제 data =============>', formData)
                await api.reqRgnRstProdDels(formData).then((resultData) => {
                    console.log('resultData ==============', resultData)
                    this.cfSearch()
                })
            }
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //Grid ExcelDown
        onClickDownload: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/rgnRstProdListsExcelDown',
                this.reqParams
            )
        },

        onReturnDisDsmDarrvlDisLnkgRgst: function (retVal) {
            if (retVal) {
                // 화면재조회
                this.cfSearch()
            }
        },

        // 엑셀업로드 버튼
        btnExcelUpload: function () {
            this.showDisDsmDarrvlDisLnkgXlsUpld = true
        },

        // 엑셀업로드 종료 후
        onReturnDisDsmDarrvlDisLnkgXlsUpld: function (retVal) {
            if (retVal) {
                // 화면 재조회
                this.cfSearch()
            }
        },

        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            const formData = {
                prodCd: this.dsCondition.prodCd,
                prodNm: this.dsCondition.prodNm,
            }
            basBcoProdsApi.getProdsList(formData).then((res) => {
                console.log('getProdsList : ', res)
                if (res === undefined) return
                if (res.length === 1) {
                    this.dsCondition.prodCd = _.get(res[0], 'prodCd')
                    this.dsCondition.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.dsCondition.prodCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsCondition.prodCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.dsCondition.prodNm = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.prodCd = _.get(retrunData, 'prodCd')
            this.dsCondition.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
