import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = {
    /*엑셀업로드 그리드용 columns*/
    columns1: [
        {
            fieldName: 'accDealcoCd',
            header: { text: '정산처' },
            width: '100',
        },
        {
            fieldName: 'accDealcoNm',
            header: { text: '정산처명' },
            width: '180',
        },
        {
            fieldName: 'saleDealcoCd',
            header: { text: '판매처' },
            width: '100',
        },
        {
            fieldName: 'saleDealcoNm',
            header: { text: '판매처명' },
            width: '180',
        },
        {
            fieldName: 'accMtchClCd',
            header: { text: '(숨김)수수료구분코드' },
            width: '180',
            visible: false,
        },
        {
            fieldName: 'accMtchClNm',
            header: { text: '수수료구분' },
            width: '180',
        },
        {
            fieldName: 'accMtchItmNm',
            header: { text: '수수료설명' },
            styleName: 'left-column',
            width: '200',
        },
        {
            fieldName: 'accMtchAmt',
            header: { text: '금액' },
            width: '100',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'saleDt',
            header: { text: '판매일' },
            width: '100',
        },
        {
            fieldName: 'custNm',
            header: { text: '고객명' },
            width: '100',
        },
        {
            fieldName: 'custNo',
            header: { text: '고객번호' },
            width: '150',
        },
        {
            fieldName: 'svcMgmtNum',
            header: { text: '서비스관리번호' },
            width: '100',
        },
        {
            fieldName: 'rmks',
            header: { text: '비고' },
            width: '150',
            styleName: 'left-column',
        },
    ],
    /*오류데이터 그리드용 columns*/
    columns2: [
        {
            fieldName: 'accDealcoCd',
            header: { text: '정산처' },
            width: '100',
        },
        {
            fieldName: 'accDealcoNm',
            header: { text: '정산처명' },
            width: '200',
        },
        {
            fieldName: 'amt',
            header: { text: '금액' },
            width: '100',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'errMsg',
            header: { text: '오류내역' },
            width: '1000',
            styleName: 'left-column',
        },
    ],
}

const GRID_HEADER = {}

/*엑셀업로드 그리드용 columns*/
GRID_HEADER.columns1 = gridMetaUtil.adjustColumns(GRID_META.columns1)
GRID_HEADER.fields1 = gridMetaUtil.adjustFields(GRID_META.columns1)

/*오류데이터 그리드용 columns*/
GRID_HEADER.columns2 = gridMetaUtil.adjustColumns(GRID_META.columns2)
GRID_HEADER.fields2 = gridMetaUtil.adjustFields(GRID_META.columns2)

/*엑셀양식다운로드 그리드용 columns*/
GRID_HEADER.columns3 = gridMetaUtil.adjustColumns(GRID_META.columns1)
GRID_HEADER.fields3 = gridMetaUtil.adjustFields(GRID_META.columns1)

export { GRID_HEADER }
