import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'uuid',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'itDocNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqTitle',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDtl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserEmail',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'devClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expEndDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDocId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvDtl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rejOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rejDtl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rejUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'vrfSnro',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'devTestYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'piTestYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'depSchdDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'depDt',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'reqOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqMblPhonNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rejUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rejOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNmMsk',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: 'true',
                falseValues: 'false',
            },
            width: 30,
            editable: true,
        },
        {
            name: 'reqDt',
            fieldName: 'reqDt',
            header: {
                text: '요청일자',
                excelName: '요청일자',
            },
            editable: false,
            visible: true,
            width: '150',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'uuid',
            fieldName: 'uuid',
            header: {
                text: 'uuid',
                excelName: 'uuid',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'reqClCd',
            fieldName: 'reqClCd',
            header: {
                text: '요청구분',
                excelName: '요청구분',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'itDocNo',
            fieldName: 'itDocNo',
            header: {
                text: 'IT지원요청서',
                excelName: 'IT지원요청서',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'reqTitle',
            fieldName: 'reqTitle',
            header: {
                text: '요건명',
                excelName: '요건명',
            },
            editable: false,
            visible: true,
            width: '300',
        },
        {
            name: 'reqDtl',
            fieldName: 'reqDtl',
            header: {
                text: '요건상세',
                excelName: '요건상세',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'reqUserId',
            fieldName: 'reqUserId',
            header: {
                text: '요청자',
                excelName: '요청자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'reqUserNm',
            fieldName: 'reqUserNm',
            header: {
                text: '요청자명',
                excelName: '요청자명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'reqOrgCd',
            fieldName: 'reqOrgCd',
            header: {
                text: '요청자조직',
                excelName: '요청자조직',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'reqUserEmail',
            fieldName: 'reqUserEmail',
            header: {
                text: '요청자메일',
                excelName: '요청자메일',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'devClCd',
            fieldName: 'devClCd',
            header: {
                text: '개발담당자',
                excelName: '개발담당자',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'expEndDt',
            fieldName: 'expEndDt',
            header: {
                text: '완료예상일자',
                excelName: '완료예상일자',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'reqStNm',
            fieldName: 'reqStNm',
            header: {
                text: '진행상태',
                excelName: '진행상태',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'reqDocId',
            fieldName: 'reqDocId',
            header: {
                text: '요구사항첨부문서Id',
                excelName: '요구사항첨부문서Id',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'aprvOrgCd',
            fieldName: 'aprvOrgCd',
            header: {
                text: '승인조직',
                excelName: '승인조직',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'aprvDtl',
            fieldName: 'aprvDtl',
            header: {
                text: '고려사항/제한조건',
                excelName: '고려사항/제한조건',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'aprvUserId',
            fieldName: 'aprvUserId',
            header: {
                text: '승인자',
                excelName: '승인자',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'rejOrgCd',
            fieldName: 'rejOrgCd',
            header: {
                text: '반려조직',
                excelName: '반려조직',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'rejDtl',
            fieldName: 'rejDtl',
            header: {
                text: '반려사유',
                excelName: '반려사유',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'rejUserId',
            fieldName: 'rejUserId',
            header: {
                text: '반려자',
                excelName: '반려자',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'vrfSnro',
            fieldName: 'vrfSnro',
            header: {
                text: '검증시나리오',
                excelName: '검증시나리오',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'devTestYn',
            fieldName: 'devTestYn',
            header: {
                text: '1차테스트여부',
                excelName: '1차테스트여부',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'piTestYn',
            fieldName: 'piTestYn',
            header: {
                text: '2차테스트여부',
                excelName: '2차테스트여부',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'depSchdDt',
            fieldName: 'depSchdDt',
            header: {
                text: '배포예정일자',
                excelName: '배포예정일자',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'depDt',
            fieldName: 'depDt',
            header: {
                text: '배포완료일자',
                excelName: '배포완료일자',
            },
            editable: false,
            visible: false,
            width: '150',
        },

        {
            name: 'reqOrgNm',
            fieldName: 'reqOrgNm',
            header: {
                text: '요청자조직명',
                excelName: '요청자조직명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'reqMblPhonNo',
            fieldName: 'reqMblPhonNo',
            header: {
                text: '요청자핸드폰번호',
                excelName: '요청자핸드폰번호',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'aprvUserNm',
            fieldName: 'aprvUserNm',
            header: {
                text: '승인자명',
                excelName: '승인자명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'aprvOrgNm',
            fieldName: 'aprvOrgNm',
            header: {
                text: '승인조직명',
                excelName: '승인조직명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'rejUserNm',
            fieldName: 'rejUserNm',
            header: {
                text: '반려자명',
                excelName: '반려자명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'rejOrgNm',
            fieldName: 'rejOrgNm',
            header: {
                text: '반려조직명',
                excelName: '반려조직명',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'reqUserNmMsk',
            fieldName: 'reqUserNmMsk',
            header: {
                text: '요청자명', //'요청자명마스킹',
                excelName: '요청자명', //'요청자명마스킹',
            },
            editable: false,
            visible: true,
            width: '150',
        },
    ],
}
