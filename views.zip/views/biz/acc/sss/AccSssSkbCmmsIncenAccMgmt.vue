<!-----------------------------------------------
 * 업무그룹명: SKB수수료/인센티브정산관리
 * 서브업무명: SKB수수료/인센티브정산관리
 * 설명: SKB수수료/인센티브정산관리 조회,삭제,확정,취소 한다.
 * 작성자: P180190
 * 작성일: 2022.06.13
------------------------------------------------>
<template>
    <div class="content">
        <h1>SKB수수료/인센티브정산관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="excelDel"
                    :disabled="exDelDisabled"
                    >엑셀 업로드 데이타 삭제</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="init()"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSave"
                    :disabled="onSaveDis"
                    >확정</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onDele"
                    :disabled="onDelDis"
                    >삭제</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        @change="onAccym()"
                        v-model="searchFormData.accYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="WIRE_ACC_CL_CD"
                        labelName="구분"
                        v-model="searchFormData.srchWireAccClCd"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :eRequired="true"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchOrgAgencyParam.agencyNm"
                        :codeVal.sync="searchOrgAgencyParam.agencyCd"
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOrgAgencyEnterKey"
                        @appendIconClick="onOrgAgencyIconClick"
                        @input="onOrgAgencyInput"
                    />
                    <BasBcoOrgAgencysPopup
                        v-if="showBcoOrgAgencys"
                        :parentParam="searchOrgAgencyParam"
                        :rows="resultOrgAgencyRows"
                        :dialogShow.sync="showBcoOrgAgencys"
                        @confirm="onOrgAgencyReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="상품"
                        :itemList="srchProdClCdItems"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-model="searchFormData.srchProdClCd"
                    ></TCComComboBox>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="SKB수수료/인센티브 정산 목록"
                :isPageCnt="true"
                :isExcelup="true"
                :isExceldown="true"
                :gridObj="this.gridObj"
                @excelDownBtn="this.downloadExcelAll"
                @excelUploadBtn="openExcelUploadPopup()"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <!-- Excell upload popup 영역 -->
            <AccSssSkbCmmsIncenAccXls
                v-if="popup.adjustExcel.showBool === true"
                ref="adjustExcel"
                :dialogShow.sync="popup.adjustExcel.showBool"
                :popupParams.sync="popupParams"
                @confirm="onReAccSssSkbCmmsIncenAccXls"
            />
            <!-- //popup 영역 -->
            <AccSssSkbCmmsIncenAccDtl
                v-if="popup.adjustDtl.showBool === true"
                ref="popup"
                :dialogShow.sync="popup.adjustDtl.showBool"
                :popupParams.sync="popupParams"
            />
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
// import commonApi from '@/api/common/prototype'
import { CommonGrid, CommonUtil } from '@/utils'
import moment from 'moment'
import AccSssSkbCmmsIncenAccDtl from '@/views/biz/acc/sss/AccSssSkbCmmsIncenAccDtl'
import AccSssSkbCmmsIncenAccXls from '@/views/biz/acc/sss/AccSssSkbCmmsIncenAccXls'
//====================조직별대리점팝업====================
import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
//====================//조직별대리점팝업====================
import sktCmmApi from '@/api/biz/acc/sss/AccSssSkbCmmsIncenAccMgmt'
import { GRID_HEADER } from '@/const/grid/acc/sss/AccSssSkbCmmsIncenAccMgmtGrid'
import CommonMixin from '@/mixins'
export default {
    name: 'AccSssSkbCmmsIncenAccMgmt',
    components: {
        BasBcoOrgAgencysPopup,
        AccSssSkbCmmsIncenAccDtl,
        AccSssSkbCmmsIncenAccXls,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,

            //Grid
            objAuth: {},
            gridData: this.gridSetData(this.rowCnt),
            gridObj: {},
            gridHeaderObj: {},

            /*그리드 스타일*/
            gridStyle: {
                height: '430px', //그리드 높이 조절
            },
            // 버튼 비활성화
            exDelDisabled: false,
            onSaveDis: false,
            onDelDis: false,

            searchForms: {},
            rowData: '',
            rowCnt: 15,
            confirmList: [],

            //요청 파라미터
            searchFormData: {
                srchWireAccClCd: '',
                srchAgencyCd: '',
                srchProdClCd: '',
                srchAccYm: '',
                accYm: moment(new Date()).format('YYYY-MM'),
                accYm_: moment(new Date()).format('YYYY-MM'),
            },
            //처리구분
            srchProdClCdItems: [
                {
                    commCdVal: 'A',
                    commCdValNm: 'SKT',
                },
                {
                    commCdVal: 'B',
                    commCdValNm: 'T-Broad',
                },
            ],

            /* popup영역 */
            //====================조직별대리점팝업관련====================
            showBcoOrgAgencys: false, // 조직별대리점 팝업 오픈 여부
            searchOrgAgencyParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultOrgAgencyRows: [], // 조직별대리점 팝업 오픈 여부
            //====================//조직별대리점팝업관련==================

            popupParams: {},
            dtlParam: {},
            popup: {
                adjustExcel: {
                    showBool: false,
                },
                adjustDtl: {
                    showBool: false,
                },
            },
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, true, true)
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: '번호',
        })
        //미전송 일때만 check 가능하게
        this.$refs.grid.gridView.setCheckableExpression(
            "values['erpTrnsYn'] = '미전송'",
            true
        )
        this.$refs.grid.gridView.displayOptions.selectionStyle = 'rows'
        this.$refs.grid.gridView.onCellDblClicked = this.onCellDblClicked

        //그리드 row클릭시 ERP전송에 따른 버튼 제어
        //as-is에 존재하나 전송 완료건 체크가 불가하여 해당 로직 필요없음.
        // this.gridObj.gridView.onItemChecked = (grid, clickData) => {
        //     this.onSaveDis = false
        //     this.onDelDis = false
        //     if (
        //         grid.getValue(clickData.itemIndex, 'erpTrnsYn') == '전송'
        //     ) {
        //         this.onSaveDis = true
        //         this.onDelDis = true
        //     }
        // }
    },
    computed: {},
    watch: {},
    methods: {
        // 초기화
        init: function () {
            this.initParam()
            this.initParamFrom()
            this.$refs.grid.setRows([])
            this.searchOrgAgencyParam = {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            }
            this.resultOrgAgencyRows = []
        },
        initParam: function () {
            this.searchForms = {
                srchAccYm: moment(new Date()).format('YYYY-MM'),
                accYm: '',
                srchDedtTypNm: '',
                srchAgencyCd: '',
                srchProdClCd: '',
                srchWireAccClCd: '',
            }
        },
        initParamFrom: function () {
            this.searchFormData = {
                accYm_: moment(new Date()).format('YYYY-MM'),
                srchOrgCd: '',
                srchDedtTypNm: '',
                srchProdClCd: '',
                srchWireAccClCd: '',
                srchAccYm: '',
            }
        },

        // 입력한 정산월이 당월 정산대상월보다 작을경우
        // 액셀업로드데이터 삭제버튼 Disable ::::: excelDel()
        onAccym: function () {
            if (
                this.searchFormData.accYm_ <
                moment().add(-1, 'M').format('YYYY-MM')
            ) {
                this.exDelDisabled = true
            } else {
                this.exDelDisabled = false
            }
        },

        gridSetData: function (rowCnt) {
            return new CommonGrid(0, rowCnt, '', '')
        },

        //===================== //내부거래처(거래종료확인) methods ================================

        //===================== //내부거래처(권한조직) methods ================================

        //===================== 조직별 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getOrgAgencyList() {
            basBcoOrgAgencysApi
                .getOrgAgencyList(this.searchOrgAgencyParam)
                .then((res) => {
                    console.log('getOrgAgencyList then : ', res)
                    // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                    // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                    if (res.length === 1) {
                        this.searchOrgAgencyParam.agencyCd = _.get(
                            res[0],
                            'agencyCd'
                        )
                        this.searchOrgAgencyParam.agencyNm = _.get(
                            res[0],
                            'agencyNm'
                        )
                    } else {
                        this.resultOrgAgencyRows = res
                        this.showBcoOrgAgencys = true
                    }
                })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onOrgAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.searchOrgAgencyParam.agencyNm)) {
                this.getOrgAgencyList()
            } else {
                this.showBcoOrgAgencys = true
                // }
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onOrgAgencyEnterKey() {
            this.resultOrgAgencyRows = []
            if (_.isEmpty(this.searchOrgAgencyParam.agencyNm)) {
                this.showBcoOrgAgencys = true
            }
            this.getOrgAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onOrgAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.searchOrgAgencyParam.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onOrgAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchOrgAgencyParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.searchOrgAgencyParam.agencyNm = _.get(retrunData, 'agencyNm')
        },
        //===================== //조직별대리점팝업관련 methods ================================

        //================================================
        // 전체 조회 :::: getSkbCmmsIncenAccList
        //================================================
        onSearch: function () {
            const srchAccYm = this.searchFormData.accYm_
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
            } else {
                this.searchFormData.srchAccYm = CommonUtil.onlyNumber(
                    this.searchFormData.accYm_
                )
                this.searchForms = { ...this.searchFormData }
                this.searchForms.srchAgencyCd =
                    this.searchOrgAgencyParam.agencyCd
                this.getSkbCmmsIncenAccList(this.searchForms)
                console.log('전체리스트조회 ::::::: 시작')
            }
        },
        async getSkbCmmsIncenAccList() {
            await sktCmmApi
                .getSkbCmmsIncenAccList(this.searchForms)
                .then((res) => {
                    if (res) {
                        console.log('전체리스트조회 ::::::: ', res)
                        this.confirmList = res
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator()
                        this.gridData = this.gridSetData()
                        console.log('전체리스트조회 ::::::: 끝')
                        this.searchForms = {}
                    } else {
                        this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                    }
                })
        },
        //================================================
        // 선택한 row 확정 :::: fixSkbCmmsIncenAcc
        //================================================
        onSave: function () {
            var confirmList = this.$refs.grid.gridView.getCheckedItems(true)
            if (confirmList == null || confirmList.length == 0) {
                this.showTcComAlert('선택된 대리점이 없습니다.')
                return
            } else {
                for (var i = 0; i < confirmList.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(confirmList[i])
                    console.log(row)
                    // 이미 확정처리가 되어 있는 건 :: fix_yn
                    if (row['fixYn'] == '확정') {
                        console.log(row['fixYn'])
                        this.showTcComAlert(
                            row['agencyNm'] +
                                '은(는) 확정처리 완료된 대리점입니다.'
                        )
                        return
                    }
                    if (row['erpTrnsYn'] == '전송') {
                        this.showTcComAlert(
                            row['agencyNm'] + '은(는) 전송 완료된 대리점입니다.'
                        )
                        return
                    }
                } // 선택한 row로 API 호출
                // list 초기화
                this.searchForms.confirmList = []
                this.searchForms.accYm = CommonUtil.onlyNumber(
                    this.searchFormData.accYm_
                )
                for (i = 0; i < confirmList.length; i++) {
                    var rowData = this.$refs.grid.gridView.getValues(
                        confirmList[i]
                    )
                    this.searchForms.confirmList.push({
                        // accYm: this.searchFormData.accYm, // 정산월
                        agencyCd: rowData.agencyCd, // 대리점
                        wireAccClCd: rowData.wireAccClCd, // 유선 정산구분코드
                        prodClCd: rowData.prodClCd, // 상품구분코드
                    })
                }
                console.log('선택리스트확정 ::::::: 시작')
                sktCmmApi
                    .fixSkbCmmsIncenAcc(this.searchForms)
                    .then((resultData) => {
                        if (resultData == undefined) {
                            this.showTcComAlert('확정 처리실패하였습니다.')
                            return
                        } else {
                            console.log(rowData + '선택리스트확정 ::::::: 종료')
                            this.showTcComAlert('확정 처리되었습니다.')
                            this.onSearch()
                        }
                    })
            }
        },
        //================================================
        // 선택한 row (삭제)확정 취소 :::cancelFixSkbCmmsIncenAcc
        //================================================
        onDele: function () {
            var confirmList = this.$refs.grid.gridView.getCheckedItems(true)
            if (confirmList == null || confirmList.length == 0) {
                this.showTcComAlert('선택된 대리점이 없습니다.')
                return
            }
            for (var i = 0; i < confirmList.length; i++) {
                var row = this.$refs.grid.gridView.getValues(confirmList[i])
                // 선택된 대리점중 확정이 완료된 건이 포함되어있는지 체크 ::: fixYn
                if (row['fixYn'] == '미확정') {
                    console.log(row['fixYn'])
                    this.showTcComAlert(
                        row['agencyNm'] + '은(는) 확정처리된 대리점이 아닙니다.'
                    )
                    return
                }
                if (row['erpTrnsYn'] == '전송') {
                    this.showTcComAlert(
                        row['agencyNm'] + '은(는) 전송 완료된 대리점입니다.'
                    )
                    return
                }
            }
            this.searchForms.confirmList = []
            this.searchForms.accYm = CommonUtil.onlyNumber(
                this.searchFormData.accYm_
            )
            this.showTcComConfirm('확정 취소 처리 하시겠습니까?').then(
                (confirm) => {
                    console.log('showTcComConfirm confirm: ', confirm)
                    if (confirm) {
                        var rowData = {}
                        for (i = 0; i < confirmList.length; i++) {
                            rowData = this.$refs.grid.gridView.getValues(
                                confirmList[i]
                            )
                            this.searchForms.confirmList.push({
                                accYm: rowData.accYm, // 정산월
                                agencyCd: rowData.agencyCd, // 대리점
                                wireAccClCd: rowData.wireAccClCd, // 유선 정산구분코드
                                prodClCd: rowData.prodClCd, // 상품구분코드
                            })
                        }
                        sktCmmApi
                            .cancelFixSkbCmmsIncenAcc(this.searchForms)
                            .then(() => {
                                console.log('선택리스트확정취소 ::::::: 시작')
                                this.showTcComAlert('확정취소 처리되었습니다.')
                                console.log('선택리스트확정취소 ::::::: 끝')
                                this.onSearch()
                            })
                    }
                }
            )
        },
        //================================================
        // 선택한 row excel 업로드 데이터 삭제 :::deleteSkbCmmsIncenExcelUpload
        //================================================
        excelDel: function () {
            var confirmList = this.gridObj.dataProvider.getRows(0, -1)
            if (confirmList == null || confirmList.length < 0) {
                this.showTcComAlert('삭제대상 데이터가 없습니다.')
                return
            }
            this.showTcComConfirm(
                this.searchFormData.accYm_ +
                    '월 업로드 데이터를 삭제하시겠습니까?'
            ).then((confirm) => {
                if (confirm) {
                    this.searchForms.confirmList = []
                    this.searchForms.accYm = CommonUtil.onlyNumber(
                        this.searchFormData.accYm_
                    )
                    // 확정처리된 대리점 찾기 fieldRow
                    var fieldRow = this.gridObj.dataProvider.getFieldValues(
                        'fixYn',
                        0,
                        -1
                    )
                    console.log('fieldRow::' + fieldRow)
                    for (var i = 0; i < confirmList.length; i++) {
                        if (fieldRow[i] == '확정') {
                            this.showTcComAlert(
                                '확정처리된 대리점이 있습니다. 확정취소후 삭제하십시오.'
                            )
                            return
                        }
                    }
                    sktCmmApi
                        .deleteSkbCmmsIncenExcelUpload(this.searchForms)
                        .then((res) => {
                            if (res) {
                                this.showTcComAlert('삭제처리되었습니다.')
                                this.onSearch()
                            }
                        })
                }
            })
        },

        //================================================
        // 상세 페이지 POPUP
        //================================================
        onCellDblClicked() {
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                this.popup.adjustDtl.showBool = true
                this.popup.adjustDtl.popupParams = rowData
                var rowData = grid.getValues(clickData.itemIndex)
                this.popupParams.accYm_ = this.searchFormData.srchAccYm
                this.popupParams.agencyNm = rowData.agencyNm
                this.popupParams.agencyCd = rowData.agencyCd
                this.popupParams.wireAccClNm = rowData.wireAccClNm
                this.popupParams.wireAccClCd = rowData.wireAccClCd
                this.popupParams.prodClNm = rowData.prodClNm
                this.popupParams.prodClCd = rowData.prodClCd
            }
        },

        //================================================
        // EXCEL UPLOAD POPUP 열기
        //================================================
        openExcelUploadPopup: function () {
            this.popupParams.accYm_ = this.searchFormData.accYm_
            this.popup.adjustExcel.showBool = true
        },
        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcelAll: function () {
            this.searchFormData.srchAccYm = CommonUtil.onlyNumber(
                this.searchFormData.accYm_
            )
            this.searchFormData.srchAgencyCd =
                this.searchOrgAgencyParam.agencyCd
            sktCmmApi
                .downloadSkbCmmsIncenAccListExcel(this.searchFormData)
                .then((res) => {
                    console.log('엑셀다운로드 ::::::: ', res)
                    this.gridSetData(res)
                })
                .catch((err) => {
                    console.log('엑셀다운로드 실패', err)
                })
        },
        // 팝업 닫으면 부모페이지 재조회
        onReAccSssSkbCmmsIncenAccXls(retVal) {
            if (retVal) {
                console.log('retrunData: ', retVal)
                this.onSearch()
            }
        },
    },
}
</script>
