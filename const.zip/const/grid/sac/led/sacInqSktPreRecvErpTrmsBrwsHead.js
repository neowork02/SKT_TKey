import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'agencyNm', // 대리점
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'crncyCd', // 통화유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cashDpstClNm', // 예수금구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pdayBamt', // 전일잔액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'hqRmtAmt', // 본사송금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdayBamt', // 당일잔액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'erpAmt', // erp전송금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'erpTrmsItmCd', // erp전송구분 코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsItmNm', // erp전송구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsDtm', // erp전송일시
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            width: '200',
            header: '대리점',
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: '대리점코드',
        },
        {
            name: 'crncyCd',
            fieldName: 'crncyCd',
            type: 'data',
            header: '통화유형',
        },
        {
            name: 'cashDpstClNm',
            fieldName: 'cashDpstClNm',
            type: 'data',
            header: '예수금구분',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'pdayBamt',
            fieldName: 'pdayBamt',
            type: 'data',
            numberFormat: '#,##0',
            header: '전일잔액',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'hqRmtAmt',
            fieldName: 'hqRmtAmt',
            type: 'data',
            numberFormat: '#,##0',
            header: '본사송금액',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tdayBamt',
            fieldName: 'tdayBamt',
            type: 'data',
            numberFormat: '#,##0',
            header: '당일잔액',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'erpAmt',
            fieldName: 'erpAmt',
            type: 'data',
            numberFormat: '#,##0',
            header: 'erp전송금액',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'erpTrmsItmNm',
            fieldName: 'erpTrmsItmNm',
            type: 'data',
            header: 'erp전송구분',
        },
        {
            name: 'erpTrmsDtm',
            fieldName: 'erpTrmsDtm',
            type: 'data',
            width: '150',
            header: 'erp전송일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
    ],
}
