<!-----------------------------------------------
 * 업무그룹명: 기준정보 > 기타거래처관리
 * 서브업무명: 기타거래처관리
 * 설명: 기타거래처관리 CRUD
 * 작성자: P180291
 * 작성일: 2022.08.12
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>기타거래처관리</h1>
        <!-- // Tit -->
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/etcDealcoMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/adm/etcDealcoMgmt'
export default {
    name: 'BasAdmEtcDealcoMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (!this.$store.hasModule('bas.adm.etcDealcoMgmtStore')) {
            this.$store.registerModule('bas.adm.etcDealcoMgmtStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.adm.etcDealcoMgmtStore')) {
            this.$store.unregisterModule('bas.adm.etcDealcoMgmtStore')
        }
    },
    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>
