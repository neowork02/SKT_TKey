<script>
export default {
    data() {
        return {
            //  조직, 매출구분, 수납구분, 입금여부 선택가능여부(BO매출관리Tab만가능)
            boSearchOrgNmDisable: false,
            boSearchSaleClCdDisable: true,
            boSearchPayClCdDisable: false,
            boSearchDpstYnDisable: true,

            //  입금여부(BO매출관리Tab) / 결제구분(Pg입금Tab) Label변경
            searchDpstYnLabel: '입금여부',

            //  조회구분 Combo값. Tab별로 다름
            searchClCdCombo: [],
            boSearchClCd: [
                {
                    commCdVal: '1',
                    commCdValNm: '매출일자',
                },
                // {
                //     commCdVal: '2',
                //     commCdValNm: '지급(예정)일자',
                // },
                {
                    commCdVal: '3',
                    commCdValNm: '주문일자',
                },
                {
                    commCdVal: '4',
                    commCdValNm: '출고일자',
                },
            ],
            pgSearchClCd: [
                {
                    commCdVal: '0',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '지급(예정)일자',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '거래일시',
                },
                {
                    commCdVal: '3',
                    commCdValNm: '처리일시',
                },
            ],

            //  입금여부 / 결제구분 Combo. Tab별 Label 및 데이터 다름
            SearchDpstYnCombo: [],
            boSearchDpstYn: [
                {
                    commCdVal: '0',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '확인',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '미확인',
                },
            ],
            pgSearchDpstYn: [
                {
                    commCdVal: '0',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '신용카드',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '계좌이체',
                },
            ],

            //  검색대상 Combo. Tab별 데이터 다름
            searchObjCombo: [],
            boSearchObjClCd: [
                {
                    commCdVal: '0',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '주문ID',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '서비스관리번호',
                },
                {
                    commCdVal: '3',
                    commCdValNm: '주문번호',
                },
                {
                    commCdVal: '4',
                    commCdValNm: '수납관리번호',
                },
            ],
            pgSearchObjClCd: [
                {
                    commCdVal: '0',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '가맹점거래번호',
                },
            ],
        }
    },
}
</script>
