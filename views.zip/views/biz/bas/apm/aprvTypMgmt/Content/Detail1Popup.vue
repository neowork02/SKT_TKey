<template>
    <TCComDialog :dialogShow.sync="activeOpen1" size="600px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">승인유형관리 상세</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="parentParam1.aprvTypNm"
                                    labelName="승인유형명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComComboBox
                                    v-model="parentParam1.reqMenuNo"
                                    labelName="요청화면"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :itemList="menus"
                                    itemText="menuNm"
                                    itemValue="menuNo"
                                    :eRequired="true"
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComComboBox
                                    v-model="parentParam1.reqAuthCd"
                                    labelName="요청화면속성"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :itemList="auths"
                                    itemText="authNm"
                                    itemValue="authCd"
                                    :eRequired="true"
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComComboBox
                                    v-model="parentParam1.aprvMenuNo"
                                    labelName="승인화면"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :itemList="menus"
                                    itemText="menuNm"
                                    itemValue="menuNo"
                                    :eRequired="true"
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComComboBox
                                    v-model="parentParam1.aprvAuthCd"
                                    labelName="승인화면속성"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :itemList="auths"
                                    itemText="authNm"
                                    itemValue="authCd"
                                    :eRequired="true"
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="parentParam1.aprvApiUrl"
                                    labelName="승인API"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="500"
                                    :eRequired="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div
                            class="searchform"
                            v-for="(item, idx) in addTitles"
                            v-bind:key="idx"
                        >
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="parentParam1[item]"
                                    :labelName="'추가정보' + [idx + 1]"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="500"
                                    :eRequired="false"
                                ></TCComInput>
                            </div>
                        </div>
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/apm/aprvTypMgmt/helpers'
import moment from 'moment'
import _ from 'lodash'
import CommonMixin from '@/mixins'

export default {
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: {
            type: Object,
            default: () => {},
            required: false,
        },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            objAuth: {},
            searchParam: {
                // agencyRgstCl: '', // 대리점등록구분
                // agencyTyp: '', // 대리점유형
                // agencyPtn: '', // 대리점구분코드
                // orgCd: '', // 대리점코드
                // orgNm: '', // 대리점명
                searchDateModel: '', // 조회기준일(v-model)
                searchDate: '', // 조회기준일
            },
            parentParam1: {
                aprvTypCd: '', //승인유형코드
                aprvTypNm: '', //승인유형명
                reqMenuNo: '', //요청화면번호
                reqAuthCd: '', //요청화면속성코드
                aprvMenuNo: '', //승인화면번호
                aprvAuthCd: '', //승인화면속성코드
                aprvApiUrl: '', //승인API
                aprvDtlInfo01: '', // 추가정보01
                aprvDtlInfo02: '', // 추가정보02
                aprvDtlInfo03: '', // 추가정보03
                aprvDtlInfo04: '', // 추가정보04
                aprvDtlInfo05: '', // 추가정보05
                aprvDtlInfo06: '', // 추가정보06
                aprvDtlInfo07: '', // 추가정보07
                aprvDtlInfo08: '', // 추가정보08
                aprvDtlInfo09: '', // 추가정보09
                aprvDtlInfo10: '', // 추가정보10
                aprvDtlInfo11: '', // 추가정보11
                aprvDtlInfo12: '', // 추가정보12
                aprvDtlInfo13: '', // 추가정보13
                aprvDtlInfo14: '', // 추가정보14
                aprvDtlInfo15: '', // 추가정보15
                aprvDtlInfo16: '', // 추가정보16
                aprvDtlInfo17: '', // 추가정보17
                aprvDtlInfo18: '', // 추가정보18
                aprvDtlInfo19: '', // 추가정보19
                aprvDtlInfo20: '', // 추가정보20
                aprvDtlInfo21: '', // 추가정보21
                aprvDtlInfo22: '', // 추가정보22
                aprvDtlInfo23: '', // 추가정보23
                aprvDtlInfo24: '', // 추가정보24
                aprvDtlInfo25: '', // 추가정보25
                aprvDtlInfo26: '', // 추가정보26
                aprvDtlInfo27: '', // 추가정보27
                aprvDtlInfo28: '', // 추가정보28
                aprvDtlInfo29: '', // 추가정보29
                aprvDtlInfo30: '', // 추가정보30
            },
            initParentParam1: {
                aprvTypCd: '', //승인유형코드
                aprvTypNm: '', //승인유형명
                reqMenuNo: '', //요청화면번호
                reqAuthCd: '', //요청화면속성코드
                aprvMenuNo: '', //승인화면번호
                aprvAuthCd: '', //승인화면속성코드
                aprvApiUrl: '', //승인API
                aprvDtlInfo01: '', // 추가정보01
                aprvDtlInfo02: '', // 추가정보02
                aprvDtlInfo03: '', // 추가정보03
                aprvDtlInfo04: '', // 추가정보04
                aprvDtlInfo05: '', // 추가정보05
                aprvDtlInfo06: '', // 추가정보06
                aprvDtlInfo07: '', // 추가정보07
                aprvDtlInfo08: '', // 추가정보08
                aprvDtlInfo09: '', // 추가정보09
                aprvDtlInfo10: '', // 추가정보10
                aprvDtlInfo11: '', // 추가정보11
                aprvDtlInfo12: '', // 추가정보12
                aprvDtlInfo13: '', // 추가정보13
                aprvDtlInfo14: '', // 추가정보14
                aprvDtlInfo15: '', // 추가정보15
                aprvDtlInfo16: '', // 추가정보16
                aprvDtlInfo17: '', // 추가정보17
                aprvDtlInfo18: '', // 추가정보18
                aprvDtlInfo19: '', // 추가정보19
                aprvDtlInfo20: '', // 추가정보20
                aprvDtlInfo21: '', // 추가정보21
                aprvDtlInfo22: '', // 추가정보22
                aprvDtlInfo23: '', // 추가정보23
                aprvDtlInfo24: '', // 추가정보24
                aprvDtlInfo25: '', // 추가정보25
                aprvDtlInfo26: '', // 추가정보26
                aprvDtlInfo27: '', // 추가정보27
                aprvDtlInfo28: '', // 추가정보28
                aprvDtlInfo29: '', // 추가정보29
                aprvDtlInfo30: '', // 추가정보30
            },
            addTitles: [
                'aprvDtlInfo01', // 추가정보01
                'aprvDtlInfo02', // 추가정보02
                'aprvDtlInfo03', // 추가정보03
                'aprvDtlInfo04', // 추가정보04
                'aprvDtlInfo05', // 추가정보05
                'aprvDtlInfo06', // 추가정보06
                'aprvDtlInfo07', // 추가정보07
                'aprvDtlInfo08', // 추가정보08
                'aprvDtlInfo09', // 추가정보09
                'aprvDtlInfo10', // 추가정보10
                'aprvDtlInfo11', // 추가정보11
                'aprvDtlInfo12', // 추가정보12
                'aprvDtlInfo13', // 추가정보13
                'aprvDtlInfo14', // 추가정보14
                'aprvDtlInfo15', // 추가정보15
                'aprvDtlInfo16', // 추가정보16
                'aprvDtlInfo17', // 추가정보17
                'aprvDtlInfo18', // 추가정보18
                'aprvDtlInfo19', // 추가정보19
                'aprvDtlInfo20', // 추가정보20
                'aprvDtlInfo21', // 추가정보21
                'aprvDtlInfo22', // 추가정보22
                'aprvDtlInfo23', // 추가정보23
                'aprvDtlInfo24', // 추가정보24
                'aprvDtlInfo25', // 추가정보25
                'aprvDtlInfo26', // 추가정보26
                'aprvDtlInfo27', // 추가정보27
                'aprvDtlInfo28', // 추가정보28
                'aprvDtlInfo29', // 추가정보29
                'aprvDtlInfo30', // 추가정보30
            ],
            menus: [],
            auths: [],
        }
    },
    created() {
        this.init()
    },
    mounted() {},
    computed: {
        ...serviceComputed,
        activeOpen1: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        ...serviceMethods,
        async init() {
            //this.gridData = this.gridSetData()
            this.searchParam.searchDateModel = moment().format('YYYY-MM-DD')

            const res1 = await this.getBasApmAprvTypMgmtMenus_({
                param: {},
            })
            this.menus = res1
            const res2 = await this.getBasApmAprvTypMgmtAuths_({
                param: {},
            })

            this.auths = res2
        },
        async onConfirm() {
            if (this.parentParam1.aprvTypNm.trim() === '') {
                this.showTcComAlert('승인유형명을 입력하세요.')
                return
            }
            if (this.parentParam1.reqMenuNo === '') {
                this.showTcComAlert('요청화면을 선택하세요.')
                return
            }
            if (this.parentParam1.reqAuthCd === '') {
                this.showTcComAlert('요청화면속성을 선택하세요.')
                return
            }
            if (this.parentParam1.aprvMenuNo === '') {
                this.showTcComAlert('승인화면을 선택하세요.')
                return
            }
            if (this.parentParam1.aprvAuthCd === '') {
                this.showTcComAlert('승인화면속성을 선택하세요.')
                return
            }
            if (this.parentParam1.aprvApiUrl.trim() === '') {
                this.showTcComAlert('승인API를 입력하세요.')
                return
            }
            if (this.parentParam1.aprvTypCd == '') {
                this.parentParam1.rowState = 'created'
            } else {
                this.parentParam1.rowState = 'updated'
            }
            console.log('save popup param', JSON.stringify(this.parentParam1))
            let saveRows = []
            saveRows.push(this.parentParam1)
            let res1 = await this.saveAprvTypMgmt_({ saveRows })
            if (res1 == 1) {
                this.toasting_({
                    message: '정상처리 되었습니다.',
                })
            }

            this.$emit('confirm', this.parentParam1)
            this.onClose()
        },
        onClose() {
            this.activeOpen1 = false
        },
        onSearch() {
            this.getAgencyList()
        },
        onEnterKey() {},
    },
    watch: {
        parentParam: {
            handler: function (value) {
                //this.searchParam.orgNm = value['orgNm']
                if (value == null) {
                    console.log('receive popup param null new')
                    this.parentParam1 = _.clone(this.initParentParam1)
                } else {
                    let val1 = _.clone(value)
                    console.log('receive popup param', val1)
                    this.parentParam1 = val1
                    // this.parentParam1.reservedDtm = moment(
                    //     val1.reservedDtm,
                    //     'YYYYMMDDHHmmss'
                    // ).format('YYYY-MM-DD HH:mm:ss')
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>
