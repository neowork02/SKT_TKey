/*****************************************
* 업무 그룹명 : 대리점별운영부가서비스관리
* 서브 업무명 : 대리점별운영부가서비스관리
* 설 명 : 상품목록 Grid 헤더 정보
* 작 성 자 : 김태훈
* 작 성 일 : 2022.10.12
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* ---------------------------------------
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const WIRELESS_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'basAmt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wireProdClNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'origin',
            fieldName: 'origin',
            header: {
                text: 'origin',
            },
            visible: false,
        },
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'suplSvcClNm',
            fieldName: 'suplSvcClNm',
            header: {
                text: '부가상품구분',
            },
            editable: false,
        },
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            header: {
                text: '상품코드',
            },
            editable: false,
            button: 'action',
            buttonVisibility: 'always',
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            header: {
                text: '상품명',
            },
            editable: false,
        },
        {
            name: 'prodStNm',
            fieldName: 'prodStNm',
            header: {
                text: '상품상태',
            },
            editable: false,
        },
        {
            name: 'basAmt',
            fieldName: 'basAmt',
            header: {
                text: '기본료',
            },
            editable: false,
        },
        {
            name: 'wireProdClNm',
            fieldName: 'wireProdClNm',
            header: {
                text: '유선상품구분',
            },
            editable: false,
            visible: false,
        },
    ],
}
/*
export const WIRE_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'detailType',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'origin',
            fieldName: 'origin',
            header: {
                text: 'origin',
            },
            visible: false,
        },
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'suplSvcClNm',
            fieldName: 'suplSvcClNm',
            header: {
                text: '부가상품구분',
            },
        },
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            header: {
                text: '상품코드',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            header: {
                text: '상품명',
            },
        },
        {
            name: 'prodStNm',
            fieldName: 'prodStNm',
            header: {
                text: '상품상태',
            },
        },
        {
            name: 'detailType',
            fieldName: 'detailType',
            header: {
                text: '상세유형',
            },
        },
    ],
}
*/
