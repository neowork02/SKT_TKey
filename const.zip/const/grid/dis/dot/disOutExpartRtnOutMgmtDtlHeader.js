import { ValueType } from 'realgrid'

export const DisOutExpartRtnOutMgmtDtl_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mdlClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'amt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchTyp',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCdOrg',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCdOrg',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outSeq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outQty',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'mdlClCd',
            fieldName: 'mdlClCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
            footer: {
                text: '합계',
            },
            width: '120',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            styleName: 'right-column',
            header: {
                text: '단가',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'amt',
            fieldName: 'amt',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            styleName: 'right-column',
            header: {
                text: '금액',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            visible: false,
            type: 'data',
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'prchTyp',
            fieldName: 'prchTyp',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCdOrg',
            fieldName: 'colorCdOrg',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCdOrg',
            fieldName: 'prodCdOrg',
            visible: false,
            type: 'data',
        },
        {
            name: 'outSeq',
            fieldName: 'outSeq',
            visible: false,
            type: 'data',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            visible: false,
            type: 'data',
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            visible: false,
            type: 'data',
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            visible: false,
            type: 'data',
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'outQty',
            fieldName: 'outQty',
            visible: false,
            type: 'data',
        },
    ],
}
