import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'indexKey',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'checkBox',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'shopCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'shopNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'adjtYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: '__rowState',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'checkBox',
            fieldName: 'checkBox',
            type: 'data',
            width: '50',
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: '0',
            },
            header: {
                text: '삭제',
            },
        },
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            styleName: 'left-column',
            header: {
                text: '조직',
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            header: {
                text: '대리점',
            },
            visible: false,
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            header: {
                text: '서브점',
            },
            visible: false,
        },
        {
            name: 'shopCd',
            fieldName: 'shopCd',
            header: {
                text: '매장',
            },
        },
        {
            name: 'shopNm',
            fieldName: 'shopNm',
            styleName: 'left-column',
            header: {
                text: '매장명',
            },
            editable: false,
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            header: {
                text: '구분',
            },
            // sortable: true,
            lookupDisplay: true,
            // editable: false,
            labels: ['조직', '거래처'],
            values: ['1', '2'],
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            button: 'action',
            buttonVisibility: 'always',
            header: {
                text: '조직/거래처',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: {
                text: '조직/거래처명',
            },
        },
        {
            name: 'adjtYn',
            fieldName: 'adjtYn',
            header: {
                text: '위탁수수료조정여부',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: ['N', 'Y'],
                labels: ['N', 'Y'],
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '처리일시',
            },
        },
    ],
}
