import { ValueType } from 'realgrid'

export const GRID_QUICK_SERIAL_HEADER = {
    fields: [
        {
            fieldName: 'name',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'telNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sosok',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'name',
            fieldName: 'name',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: ' 이름',
            },
        },
        {
            name: 'telNum',
            fieldName: 'telNum',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전화번호',
            },
        },
        {
            name: 'sosok',
            fieldName: 'sosok',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '소속조직',
            },
        },
    ],
}
