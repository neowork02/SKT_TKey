<template>
    <TCComDialog :dialogShow.sync="activeOpen1" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">위수탁거래처SMS수신인 선택</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <ul class="btn_area top">
                        <!-- <li class="left">
                            <v-btn outlined class="btn_ty">삭제</v-btn>
                        </li> -->
                        <li class="right">
                            <div class="rightBox">
                                <TCComButton
                                    color="btn2"
                                    eClass="btn_ty01"
                                    :objAuth="objAuth"
                                    @click="initBtn"
                                >
                                    초기화
                                </TCComButton>
                                <TCComButton
                                    color="btn2"
                                    eClass="btn_ty01"
                                    :objAuth="objAuth"
                                    @click="searchBtn"
                                >
                                    조회
                                </TCComButton>
                                <TCComButton
                                    color="btn2"
                                    eClass="btn_ty01"
                                    :objAuth="objAuth"
                                    @click="saveBtn"
                                >
                                    저장
                                </TCComButton>
                                <TCComButton
                                    color="btn2"
                                    eClass="btn_ty01"
                                    :objAuth="objAuth"
                                    @click="onClose"
                                >
                                    닫기
                                </TCComButton>
                            </div>
                        </li>
                    </ul>
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="parentParam1.orgNm"
                                    labelName="조직명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="50"
                                    :disabled="true"
                                ></TCComInput>
                                <!-- <TCComComboBox
                                    v-model="parentParam1.opTypCd"
                                    codeId="ZBAS_ONDMND_OP_TYP_CD"
                                    labelName="업무유형"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :disabled="true"
                                ></TCComComboBox> -->
                            </div>
                            <div class="formitem div4">
                                <!-- <TCComDatePicker
                                    v-model="parentParam1.rgstDt"
                                    labelName="등록일자"
                                    :objAuth="objAuth"
                                    :disabled="true"
                                ></TCComDatePicker> -->
                            </div>
                            <div class="formitem div4"></div>
                            <div class="formitem div4"></div>
                        </div>
                    </div>
                    <div class="contBoth">
                        <table-container />
                    </div>
                    <!-- <div id="detail2" class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="execCondDesc"
                                    labelName="조회조건"
                                    class="boxtype"
                                    :rows="3"
                                    :maxlength="1000"
                                    :readonly="true"
                                ></TCComTextArea>
                            </div>
                        </div>
                    </div> -->

                    <!-- Bottom BTN Group -->
                    <!-- <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div> -->
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
                <BasBcoAuthOrgTreesPopup
                    v-if="showBcoAuthOrgTrees"
                    :parentParam="popupParam"
                    :rows="resultAuthOrgTreeRows"
                    :dialogShow.sync="showBcoAuthOrgTrees"
                    @confirm="onAuthOrgTreeReturnData"
                />
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/cmu/smsStrdMgmt/dealcoBondSmsStrdMgmt/helpers'
// eslint-disable-next-line no-unused-vars
import { CommonGrid, CommonUtil } from '@/utils'
// eslint-disable-next-line no-unused-vars
import commonApi from '@/api/common/commonCode'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
import _ from 'lodash'
import CommonMixin from '@/mixins'
import TableContainer from './SelectUser1Popup/TableContainer.vue'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
//====================//내부조직팝업(권한)팝업====================

export default {
    mixins: [CommonMixin],
    components: {
        TableContainer,
        BasBcoAuthOrgTreesPopup,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            searchParam: {
                searchDateModel: '', // 조회기준일(v-model)
                searchDate: '', // 조회기준일
            },
            formSearchParams: {
                orgCd: '', // 조직코드
                orgId: '', // 조직코드
                orgLvl: '', // 조직코드
                orgNm: '', // 대리점명
            },
            parentParam1: {},
            condArr: [],
            execCondDesc: '',
            includeOrgCond: false,
            includeOrg: {},
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            popupParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
        }
    },
    computed: {
        ...serviceComputed,
        activeOpen1: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        resultList1: {
            get() {
                return this.resultUserList
            },
        },
        userListSave1: {
            get() {
                return this.userListSave
            },
        },
    },
    created() {
        this.init()
    },
    async mounted() {},
    methods: {
        ...serviceMethods,
        init() {
            //this.searchParam.searchDateModel = moment().format('YYYY-MM-DD')
        },
        async initBtn() {
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 122 ~ data ',
                this.$data
            )
            //await this.initData()
            this.searchBtn() //이화면은 초기화가 다시 조회처리

            //CommonUtil.clearPage(this.$router)
        },
        async searchBtn() {
            // let fromDt = new Date(this.clsDt[0])
            // let toDt = new Date(this.clsDt[1])
            // if (fromDt > toDt) {
            //     this.showAlert_({
            //         title: '세금계산서일자 오류',
            //         message: '시작일자가 마지막일자 보다 큽니다.',
            //     })
            //     return
            // }
            // if (
            //     moment(fromDt).format('YYYY-MM') !=
            //     moment(toDt).format('YYYY-MM')
            // ) {
            //     this.showAlert_({
            //         title: '세금계산서일자 오류',
            //         message: '같은 월 검색만 됩니다.',
            //     })
            //     return
            // }
            // this.formSearchParams.clsDt = this.clsDt.replace(/-/g, '')
            // await this.defaultAssign_({ key: 'paging', value: this.initPaging })
            // console.log(
            //     '🚀 ~ file: SearchContainer.vue ~ line 197 ~ searchBtn ~ this.formSearchParams',
            //     this.formSearchParams
            // )
            // await this.defaultAssign_({
            //     key: 'searchParams',
            //     value: this.formSearchParams,
            // })
            await this.searchData()
        },
        async searchData() {
            let data = await this.getBasCmuDealcoBondSmsStrdMgmtUsers_({
                param: { orgCd: this.parentParam1.orgCd },
            })
            console.log('popup1', data, this.parentParam1)
            let inConds = []
            let inx = 1
            data.forEach((r) => {
                inConds.push({
                    ...r,
                    pagingSeq: inx++,
                })
            })

            await this.defaultAssign_({
                key: 'resultUserList',
                value: inConds,
            })
        },
        async saveBtn() {
            await this.defaultAssign_({
                key: 'userListSave',
                value: 'run',
            })
        },
        async onConfirm() {
            // const current = this.gridObj.gridView.getCurrent()
            // if (current.dataRow === -1) {
            //     return
            // }
            // const jsonData = this.gridObj.dataProvider.getJsonRow(
            //     current.dataRow
            // )
            //this.$emit('confirm', jsonData)

            // if (this.parentParam1.opTypCd === '') {
            //     this.showTcComAlert('업무유형을 선택하세요.')
            //     return
            // }

            let saveRows = []
            if (this.resultUserSaveList.length > 0) {
                this.resultUserSaveList.forEach((r) => {
                    saveRows.push({ ...r, rowState: 'updated' })
                })
                await this.defaultAssign_({
                    key: 'resultUserSaveList',
                    value: [],
                })
            } else {
                this.showTcComAlert('저장할 수정 건이 없습니다.')
                return
            }
            let res1 = await this.saveDealcoBondSmsStrdMgmt_({ saveRows })
            if (res1 == 1) {
                this.toasting_({
                    message: '정상처리 되었습니다.',
                })
            }

            this.$emit('confirm', {})
            this.onClose()
        },

        onClose() {
            this.parentParam1 = {}
            this.activeOpen1 = false
        },

        // onSearch() {
        //     this.getAgencyList()
        // },

        onEnterKey() {
            //this.onSearch()
        },
        //====================내부조직팝업(권한)팝업관련====================
        searchCommon(flag) {
            // TODO 공통팝업 호출
            if (flag === 'mfact') {
                alert('제조사')
            } else if (flag === 'org') {
                //alert('조직')
                if (this.formSearchParams.orgNm == '') {
                    this.formSearchParams.orgId = ''
                }
                this.resultAuthOrgTreeRows = []
                this.showBcoAuthOrgTrees = true
            } else if (flag === 'prod') {
                alert('모델')
            } else if (flag === 'outPlc') {
                alert('보유처')
            }
        },
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.formSearchParams.orgCd = ''
            this.formSearchParams.orgId = ''
            this.formSearchParams.orgLvl = ''
            this.inputEvent()
        },
        onAuthOrgTreeReturnData(retrunData) {
            console.log('popup retrunData: ', retrunData)
            this.formSearchParams.orgNm = retrunData.orgNm
            this.formSearchParams.orgCd = retrunData.orgCd
            this.formSearchParams.orgId = retrunData.orgCd
            this.formSearchParams.orgLvl = retrunData.orgLvl
        },
        //====================내부조직팝업(권한)팝업관련====================
    },
    watch: {
        parentParam: {
            handler: async function (value) {
                this.parentParam1 = _.clone(value)
                await this.searchData()
            },
            deep: false, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        resultList1: {
            // eslint-disable-next-line no-unused-vars
            handler: function (value) {
                //
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        // eslint-disable-next-line no-unused-vars
        async userListSave1(val, oldVal) {
            if (val == 'done') {
                await this.defaultAssign_({
                    key: 'userListSave',
                    value: '',
                })
                await this.onConfirm()
            }
        },
    },
}
</script>

<style>
#detail1,
#detail2 {
    background-color: #ffffff !important;
}
#detail1_1 {
    width: 45% !important;
}
#detail1_c {
    width: 10% !important;
    text-align: center !important;
}
#detail1_2 {
    width: 45% !important;
}
</style>
