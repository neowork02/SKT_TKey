import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'NO',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'zipCd',
            dataType: ValueType.TEXT, //우편번호
        },
        {
            fieldName: 'siDoNm',
            dataType: ValueType.TEXT, //시도
        },
        {
            fieldName: 'siGunGuNm',
            dataType: ValueType.TEXT, //시군구
        },
        {
            fieldName: 'streetNm',
            dataType: ValueType.TEXT, //도로명
        },
        {
            fieldName: 'rdongNm',
            dataType: ValueType.TEXT, //권역행정동명
        },
        {
            fieldName: 'rgnCd',
            dataType: ValueType.TEXT, //권역코드
        },
        {
            fieldName: 'rgnNm',
            dataType: ValueType.TEXT, //권역명
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //dflag
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'NO',
            type: 'data',
            width: '40',
            editable: false,
            styleName: 'center-column',
            numberFormat: '##0',
            header: {
                text: 'No',
            },
        },
        {
            name: 'zipCd',
            fieldName: 'zipCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '우편번호',
            },
        },
        {
            name: 'siDoNm',
            fieldName: 'siDoNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '시도',
            },
        },
        {
            name: 'siGunGuNm',
            fieldName: 'siGunGuNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '시군구',
            },
        },
        {
            name: 'streetNm',
            fieldName: 'streetNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '도로명',
            },
        },
        {
            name: 'rdongNm',
            fieldName: 'rdongNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '행정동명',
            },
        },
        {
            name: 'rgnCd',
            fieldName: 'rgnCd',
            type: 'data',
            width: '80',
            editable: false,
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '권역코드',
            },
        },
        {
            name: 'rgnNm',
            fieldName: 'rgnNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '권역명',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '200',
            editable: false,
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '오류메시지',
            },
        },
    ],
    //엑셀업로드 그리드용 columns
    columns2: [
        {
            name: 'zipCd',
            fieldName: 'zipCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '우편번호',
                showTooltip: false,
            },
        },
        {
            name: 'siDoNm',
            fieldName: 'siDoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시도',
                showTooltip: false,
            },
        },
        {
            name: 'siGunGuNm',
            fieldName: 'siGunGuNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시군구',
                showTooltip: false,
            },
        },
        {
            name: 'streetNm',
            fieldName: 'streetNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '도로명',
                showTooltip: false,
            },
        },
        {
            name: 'rdongNm',
            fieldName: 'rdongNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '행정동명',
                showTooltip: false,
            },
        },
        {
            name: 'rgnCd',
            fieldName: 'rgnCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '권역코드',
                showTooltip: false,
            },
        },
    ],
}
