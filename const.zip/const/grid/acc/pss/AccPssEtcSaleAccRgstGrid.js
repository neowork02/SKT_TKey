import { ValueType } from 'realgrid'
export const GRID_POP_HEADER = {
    fields: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accYm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMM',
        },
        {
            fieldName: 'accAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'arClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arSeq',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            width: '105',
            styles: { textAlignment: 'center' },
            header: { text: '정산처' },
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            width: '105',
            styles: { textAlignment: 'center' },
            header: { text: '정산처' },
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            width: '150',
            styles: { textAlignment: 'center' },
            header: { text: '정산처명' },
        },
        {
            name: 'accYm',
            fieldName: 'accYm',
            type: 'data',
            width: '150',
            styles: { textAlignment: 'center' },
            header: { text: '정산월' },
            datetimeFormat: 'yyyy-MM',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'accAmt',
            fieldName: 'accAmt',
            type: 'data',
            width: '150',
            numberFormat: '#,###,###,##0',
            header: {
                text: '공급가',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
            },
        },
        {
            name: 'arClCd',
            fieldName: 'arClCd',
            type: 'data',
            width: '105',
            styles: { textAlignment: 'center' },
            header: { text: '상품구분' },
            visible: false,
        },
        {
            name: 'arSeq',
            fieldName: 'arSeq',
            type: 'data',
            width: '105',
            styles: { textAlignment: 'center' },
            header: { text: '매출순서' },
            visible: false,
        },
    ],
}
