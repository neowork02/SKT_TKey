import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'fixYnNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suprtShopDtlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'shopCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyYm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prnRpaySchdAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'imptIntAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rpaySchdAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'trmsDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixDt',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'asmptTrmsYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asmptPstngDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asmptTrmsYnNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixPstngDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixTrmsYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixTrmsYnNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'fixYnNm',
            fieldName: 'fixYnNm',
            type: 'data',
            header: { text: '확정여부' },
            width: '150',
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점코드' },
            width: '150',
        },

        {
            name: 'suprtShopDtlCd',
            fieldName: 'suprtShopDtlCd',
            type: 'data',
            header: { text: '지원구분' },
            width: '150',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            header: { text: '매장' },
            width: '150',
        },
        {
            name: 'shopCd',
            fieldName: 'shopCd',
            type: 'data',
            header: { text: '매장코드' },
            width: '150',
        },

        {
            name: 'aplyYm',
            fieldName: 'aplyYm',
            type: 'data',
            header: { text: '청구년월' },
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'prnRpaySchdAmt',
            fieldName: 'prnRpaySchdAmt',
            type: 'data',
            header: { text: '원금상환 예정액' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'imptIntAmt',
            fieldName: 'imptIntAmt',
            type: 'data',
            header: { text: '수입이자/부가세' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'rpaySchdAmt',
            fieldName: 'rpaySchdAmt',
            type: 'data',
            header: { text: '상환예정액' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },

        {
            name: 'trmsDt',
            fieldName: 'trmsDt',
            type: 'data',
            header: { text: 'swing전송일' },
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'fixUserNm',
            fieldName: 'fixUserNm',
            type: 'data',
            header: { text: '처리자' },
            width: '150',
        },
        {
            name: 'fixDt',
            fieldName: 'fixDt',
            type: 'data',
            header: { text: '처리일' },
            width: '150',
            datetimeFormat: 'yyyy-MM-dd',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'asmptTrmsYn',
            fieldName: 'asmptTrmsYn',
            type: 'data',
            header: { text: '추정전표 전송여부코드' },
            width: '150',
            visible: false,
        },
        {
            name: 'asmptPstngDt',
            fieldName: 'asmptPstngDt',
            type: 'data',
            header: { text: '추정전표 전기월' },
            width: '150',
            visible: false,
        },
        {
            name: 'asmptTrmsYnNm',
            fieldName: 'asmptTrmsYnNm',
            type: 'data',
            header: { text: '추정전표 전송여부' },
            width: '150',
        },
        {
            name: 'fixPstngDt',
            fieldName: 'fixPstngDt',
            type: 'data',
            header: { text: '확정전표 전기일자' },
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'fixTrmsYn',
            fieldName: 'fixTrmsYn',
            type: 'data',
            header: { text: '확정전표 전송여부코드' },
            width: '150',
            visible: false,
        },
        {
            name: 'fixTrmsYnNm',
            fieldName: 'fixTrmsYnNm',
            type: 'data',
            header: { text: '확정전표 전송여부' },
            width: '150',
        },
    ],
}
