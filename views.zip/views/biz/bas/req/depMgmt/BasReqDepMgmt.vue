<!-----------------------------------------------
 * 업무그룹명: 기본정보
 * 서브업무명: 기타
 * 설명: 기본정보-기타-SOR배포관리
 * 작성자: P180392
 * 작성일: 2022.10.20
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>SOR배포관리</h1>
        <!-- // Tit -->
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/depMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/req/depMgmt'

export default {
    name: 'BasReqDepMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (this.$store.hasModule('bas.req.depMgmtStore') != true) {
            this.$store.registerModule('bas.req.depMgmtStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.req.depMgmtStore') == true) {
            this.$store.unregisterModule('bas.req.depMgmtStore')
        }
    },

    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>
