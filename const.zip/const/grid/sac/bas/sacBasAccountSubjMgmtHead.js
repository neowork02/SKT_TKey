import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'accountCd', // 계정과목코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accountNm', // 계정과목명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accountAbbrNm', // 약칭
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo1', // 추가정보1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo2', // 추가정보2
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo3', // 추가정보3
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo4', // 추가정보4
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo5', // 추가정보5
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // 수정횟수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn', // 삭제여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId', // 입력자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm', // 입력일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 수정자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 수정일시
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'accountCd',
            fieldName: 'accountCd',
            type: 'data',
            header: '계정과목코드',
        },
        {
            name: 'accountNm',
            fieldName: 'accountNm',
            type: 'data',
            header: '계정과목명',
        },
        {
            name: 'accountAbbrNm',
            fieldName: 'accountAbbrNm',
            type: 'data',
            header: '약칭',
        },
        {
            name: 'addInfo1',
            fieldName: 'addInfo1',
            type: 'data',
            header: '참고1',
        },
        {
            name: 'addInfo2',
            fieldName: 'addInfo2',
            type: 'data',
            header: '참고2',
        },
        {
            name: 'addInfo3',
            fieldName: 'addInfo3',
            type: 'data',
            header: '참고3',
        },
        {
            name: 'addInfo4',
            fieldName: 'addInfo4',
            type: 'data',
            header: '참고4',
        },
        {
            name: 'addInfo5',
            fieldName: 'addInfo5',
            type: 'data',
            header: '참고5',
        },
    ],
}
