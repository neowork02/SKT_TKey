import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'biMapping',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hrMapping',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'portalUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effUserYn',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'rpsty_nm',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'attcClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'attcClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'entDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'retirDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'm_bu_nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizChrgOrgCdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'm_sen_nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ptOrgCdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'out_org_nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repMblPhonNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wphonNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lastLogin',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'happy_sms1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'happy_sms2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'happy_sms3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accSmsYn1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accSmsYn2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'biMapping',
            fieldName: 'biMapping',
            editable: false,
            header: {
                text: 'BI매핑',
            },
        },
        {
            name: 'hrMapping',
            fieldName: 'hrMapping',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'HR매핑',
            },
        },
        {
            name: 'userId',
            fieldName: 'userId',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용자 ID',
            },
        },
        {
            name: 'sktId',
            fieldName: 'sktId',
            editable: false,
            header: {
                text: 'Swing ID',
            },
        },
        {
            name: 'portalUserId',
            fieldName: 'portalUserId',
            editable: false,
            header: {
                text: '통합LOGIN ID',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            editable: false,
            header: {
                text: '성명',
            },
        },
        {
            name: 'effUserYn',
            fieldName: 'effUserYn',
            editable: false,
            header: {
                text: '유효사용자여부',
            },
        },
        // {
        //     name: 'userClCd',
        //     fieldName: 'userClCd',
        //     editable: false,
        //     header: {
        //         text: '직책',
        //     },
        // },
        {
            name: 'attcClNm',
            fieldName: 'attcClNm',
            editable: false,
            header: {
                text: '소속유형',
            },
        },
        {
            name: 'userStCd',
            fieldName: 'userStCd',
            editable: false,
            header: {
                text: '사용자상태',
            },
        },
        {
            name: 'userCd',
            fieldName: 'userCd',
            header: {
                text: '사용자사번',
            },
        },
        {
            name: 'userGrpNm',
            fieldName: 'userGrpNm',
            editable: false,
            header: {
                text: '권한그룹',
            },
        },
        // {
        //     name: 'orgNm',
        //     fieldName: 'orgNm',
        //     editable: false,
        //     header: {
        //         text: '관리조직',
        //     },
        //     visible: false,
        // },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            editable: false,
            header: {
                text: '조직',
            },
            width: '400',
            styleName: 'left-column',
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            editable: false,
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            editable: false,
            header: {
                text: '근무지코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            editable: false,
            header: {
                text: '근무지',
            },
        },
        {
            name: 'entDt',
            fieldName: 'entDt',
            editable: false,
            header: {
                text: '입사일',
            },
        },
        {
            name: 'retirDt',
            fieldName: 'retirDt',
            editable: false,
            header: {
                text: '퇴사일',
            },
        },
        {
            name: 'bizDivOrgCdNm',
            fieldName: 'bizDivOrgCdNm',
            editable: false,
            header: {
                text: '실/사업부',
            },
        },
        /*
        {
            name: 'bizChrgOrgCdNm',
            fieldName: 'bizChrgOrgCdNm',
            editable: false,
            header: {
                text: '사업담당',
            },
        },
        {
            name: 'teamOrgCdNm',
            fieldName: 'teamOrgCdNm',
            editable: false,
            header: {
                text: '팀/센터',
            },
        },
        {
            name: 'ptOrgCdNm',
            fieldName: 'ptOrgCdNm',
            editable: false,
            header: {
                text: 'PT',
            },
        },
        
        {
            name: 'out_org_nm',
            fieldName: 'out_org_nm',
            editable: false,
            header: {
                text: '외부조직',
            },
        },
        */
        {
            name: 'repMblPhonNo',
            fieldName: 'repMblPhonNo',
            editable: false,
            width: '120',
            header: {
                text: 'Swing 무선전화',
            },
        },
        {
            name: 'mblPhonNo',
            fieldName: 'mblPhonNo',
            editable: false,
            width: '120',
            header: {
                text: '사용자 무선전화',
            },
        },
        {
            name: 'wphonNo',
            fieldName: 'wphonNo',
            editable: false,
            width: '120',
            header: {
                text: '유선전화',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            editable: false,
            width: '200',
            header: {
                text: '처리일시',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            editable: false,
            header: {
                text: '처리자(ID)',
            },
        },
        {
            name: 'lastLogin',
            fieldName: 'lastLogin',
            editable: false,
            header: {
                text: '최근 접속일',
            },
        },
        // {
        //     name: 'mblPhonNo',
        //     fieldName: 'mblPhonNo',
        //     editable: false,
        //     header: {
        //         text: '정책/재고SMS1',
        //     },
        // },
        // {
        //     name: 'mblPhonNo2',
        //     fieldName: 'mblPhonNo2',
        //     editable: false,
        //     header: {
        //         text: '정책/재고SMS2',
        //     },
        // },
        // {
        //     name: 'mblPhonNo3',
        //     fieldName: 'mblPhonNo3',
        //     editable: false,
        //     header: {
        //         text: '정책/재고SMS3',
        //     },
        // },
        // {
        //     name: 'happy_sms1',
        //     fieldName: 'happy_sms1',
        //     editable: false,
        //     header: {
        //         text: 'Happy SMS1',
        //     },
        // },
        // {
        //     name: 'happy_sms2',
        //     fieldName: 'happy_sms2',
        //     editable: false,
        //     header: {
        //         text: 'Happy SMS2',
        //     },
        // },
        // {
        //     name: 'happy_sms3',
        //     fieldName: 'happy_sms3',
        //     editable: false,
        //     header: {
        //         text: 'Happy SMS3',
        //     },
        // },
        // {
        //     name: 'accSmsYn1',
        //     fieldName: 'accSmsYn1',
        //     editable: false,
        //     header: {
        //         text: '입금/정산SMS1',
        //     },
        // },
        // {
        //     name: 'accSmsYn2',
        //     fieldName: 'accSmsYn2',
        //     editable: false,
        //     header: {
        //         text: '입금/정산SMS2',
        //     },
        // },
    ],
}
export const HEADER2 = {
    fields: [
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'portalUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userStCdat',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userStCdatNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        // {
        //     name: 'portalUserId',
        //     fieldName: 'portalUserId',
        //     editable: false,
        //     header: {
        //         text: '통합LOGIN ID.',
        //     },
        // },
        {
            name: 'userId',
            fieldName: 'userId',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용자ID',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '성명',
            },
        },
        {
            name: 'userGrpNm',
            fieldName: 'userGrpNm',
            editable: false,
            header: {
                text: '권한그룹',
            },
        },
        {
            name: 'sktOrgNm',
            fieldName: 'sktOrgNm',
            editable: false,
            header: {
                text: '소속조직',
            },
        },
        {
            name: 'userStCdatNm',
            fieldName: 'userStCdatNm',
            editable: false,
            header: {
                text: '사용자 상태',
            },
        },
    ],
}
