import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'hldPlcSktCd',
            dataType: ValueType.TEXT, // 보유처매장코드
        },
        {
            fieldName: 'hldPlcCd',
            dataType: ValueType.TEXT, //보유처코드
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, //보유처명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'lastInoutDtlClNm',
            dataType: ValueType.TEXT, //티키타카최종이력
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'svcHstYn',
            dataType: ValueType.TEXT, //개통여부
        },
        {
            fieldName: 'svcDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //개통일자
        },
        {
            fieldName: 'svcAgencyCd',
            dataType: ValueType.TEXT, //개통처대리점코드
        },
        {
            fieldName: 'svcAgencyNm',
            dataType: ValueType.TEXT, //개통처대리점
        },
        {
            fieldName: 'svcPlcSktCd',
            dataType: ValueType.TEXT, //개통처매장코드
        },
        {
            fieldName: 'svcPlcCd',
            dataType: ValueType.TEXT, //개통처코드
        },
        {
            fieldName: 'svcPlcNm',
            dataType: ValueType.TEXT, //개통처명
        },
        {
            fieldName: 'opDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //처리일시
        },
        {
            fieldName: 'fstInAgencyCd',
            dataType: ValueType.TEXT, //최초입고대리점코드
        },
        {
            fieldName: 'fstInAgencyNm',
            dataType: ValueType.TEXT, //최초입고대리점
        },
    ],
    columns: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점명',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcSktCd',
            fieldName: 'hldPlcSktCd',
            type: 'data',

            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcCd',
            fieldName: 'hldPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처명',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'lastInoutDtlClNm',
            fieldName: 'lastInoutDtlClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '티키타카최종이력',
                showTooltip: false,
            },
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량여부',
                showTooltip: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'svcHstYn',
            fieldName: 'svcHstYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통여부',
                showTooltip: false,
            },
        },
        {
            name: 'svcDt',
            fieldName: 'svcDt',
            header: {
                text: '개통일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'svcPlcSktCd',
            fieldName: 'svcPlcSktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'svcAgencyCd',
            fieldName: 'svcAgencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통처대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'svcAgencyNm',
            fieldName: 'svcAgencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통처대리점명',
                showTooltip: false,
            },
        },
        {
            name: 'svcPlcCd',
            fieldName: 'svcPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통처코드',
                showTooltip: false,
            },
        },
        {
            name: 'svcPlcNm',
            fieldName: 'svcPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통처명',
                showTooltip: false,
            },
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'fstInAgencyCd',
            fieldName: 'fstInAgencyCd',
            type: 'data',
            width: '110',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초입고대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'fstInAgencyNm',
            fieldName: 'fstInAgencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초입고대리점',
                showTooltip: false,
            },
        },
    ],
}
