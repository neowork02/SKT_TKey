import { ValueType } from 'realgrid'

export const GRID_INFO_LEFT = {
    fields: [
        {
            fieldName: 'prcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcDesc',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'prcNm',
            fieldName: 'prcNm',
            type: 'data',
            width: '150',
            header: {
                text: '기본료그룹',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'prcDesc',
            fieldName: 'prcDesc',
            type: 'data',
            width: '150',
            header: {
                text: '기본료',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_LEFT_FEE = {
    fields: [
        {
            fieldName: 'prcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'prcCd',
            fieldName: 'prcCd',
            type: 'data',
            width: '150',
            header: {
                text: '요금제ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prcNm',
            fieldName: 'prcNm',
            type: 'data',
            width: '150',
            header: {
                text: '요금제명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_RIGHT = {
    fields: [
        {
            fieldName: 'prcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'feeCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'prcCd',
            fieldName: 'prcCd',
            type: 'data',
            width: '200',
            header: {
                text: '요금제그룹(ID)',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prcNm',
            fieldName: 'prcNm',
            type: 'data',
            width: '200',
            header: {
                text: '요금제그룹(ID)명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_RIGHT_FEE = {
    fields: [
        {
            fieldName: 'prcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'feeCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'prcCd',
            fieldName: 'prcCd',
            type: 'data',
            width: '200',
            header: {
                text: '요금제그룹(ID)',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prcNm',
            fieldName: 'prcNm',
            type: 'data',
            width: '200',
            header: {
                text: '요금제그룹(ID)명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}
