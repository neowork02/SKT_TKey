<!-----------------------------------------------
 * 업무그룹명: SKT인센티브정산관리/SKT인센티브관리
 * 서브업무명: SKT인센티브정산관리/SKT인센티브관리
 * 설명: SKT인센티브정산관리/SKT인센티브관리 조회,삭제,확정,취소 한다.
 * 작성자: P180190
 * 작성일: 2022.06.13
------------------------------------------------>
<template>
    <div class="content">
        <h1>SKT인센티브정산관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="approvalReq"
                    :disabled="approvalBtnDis"
                    v-show="onConfrimDisplay"
                    >승인요청</TCComButton
                >
                <!-- <TCComButton
                    eClass="btn_ty03"
                    :objAuth="objAuth"
                    @click="approvalReq"
                    :disabled="approvalBtnDis"
                    :style="showBtn"
                    >승인요청</TCComButton
                > -->
            </li>
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="init()"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSave"
                    :disabled="onSaveDis"
                    :style="showBtn"
                    >확정</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onDele"
                    :disabled="onDelDis"
                    :style="showBtn"
                    >삭제</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <!-- <div class="formitem div4">
                    <TCComComboBox
                        labelName="조회구분"
                        :itemList="tabListItems"
                        :objAuth="objAuth"
                        :eRequired="true"
                        v-model="searchFormData.srchTab"
                    ></TCComComboBox>
                </div> -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        v-model="accYm_"
                        :objAuth="objAuth"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchOrgAgencyParam.agencyNm"
                        :codeVal.sync="searchOrgAgencyParam.agencyCd"
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOrgAgencyEnterKey"
                        @appendIconClick="onOrgAgencyIconClick"
                        @input="onOrgAgencyInput"
                    />
                    <BasBcoOrgAgencysPopup
                        v-if="showBcoOrgAgencys"
                        :parentParam="searchOrgAgencyParam"
                        :rows="resultOrgAgencyRows"
                        :dialogShow.sync="showBcoOrgAgencys"
                        @confirm="onOrgAgencyReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComRadioBox
                        v-if="showSrchType"
                        v-model="searchFormData.srchType"
                        labelName="조회구분"
                        :itemList="srchTypeItmes"
                        :objAuth="objAuth"
                        @change="srchTypeChng"
                    ></TCComRadioBox>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCComTab
                :tab.sync="tab.tabSync1"
                :items="items"
                :itemName="itemName"
                :objAuth="objAuth"
                sliderSize="8"
                @change="onActiveTabChange"
                @click="onActiveTabClick"
                :cKey="0"
            >
                <template #Template1>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader"
                            ref="gridHeader"
                            gridTitle="인센티브정산 목록"
                            :isPageCnt="true"
                            :isExceldown="true"
                            :gridObj="gridObj"
                            @excelDownBtn="downloadExcelAll(1)"
                        >
                            <template #gridElementArea>
                                <TCComDatePicker
                                    labelName="확정일"
                                    calType="D"
                                    class="btn_noline btn_ty04"
                                    v-model="confirmDate_"
                                />
                            </template>
                        </TCRealGridHeader>
                        <TCRealGrid
                            id="grid"
                            ref="grid"
                            :fields="view.fields"
                            :columns="view.columns"
                            :styles="gridStyle"
                        />
                    </div>
                </template>
                <template #Template2>
                    <div class="contBoth">
                        <div class="div2_8 cont2 left">
                            <TCRealGridHeader
                                id="gridHeader1"
                                ref="gridHeader1"
                                gridTitle="SKT 인센티브 현황"
                                :gridObj="gridObj1"
                                :isNextPage="true"
                                :isExceldown="true"
                                :style="dtlGridStyle"
                                @excelDownBtn="downloadExcelAll(2)"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid1"
                                ref="grid1"
                                :fields="view1.fields"
                                :columns="view1.columns"
                                :style="dtlGridStyleGird"
                                @hook:mounted="tabGridMounted1"
                            />
                            <TCComPaging
                                :totalPage="gridData1.totalPage"
                                :apiFunc="getIncenList"
                                :rowCnt="rowCnt1"
                                :style="dtlGridStyle"
                                @input="chgRowCnt1"
                            />
                        </div>
                        <div class="div2_8 cont1 right">
                            <TCRealGridHeader
                                id="gridHeader3"
                                ref="gridHeader3"
                                gridTitle="영업월별 인센티브 합계"
                                :gridObj="gridObj3"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid3"
                                ref="grid3"
                                :fields="view3.fields"
                                :columns="view3.columns"
                                :style="subGridStyle3"
                                @hook:mounted="tabGridMounted3"
                            />
                            <TCRealGridHeader
                                id="gridHeader4"
                                ref="gridHeader4"
                                gridTitle="제외금액(본사C/W)"
                                :gridObj="gridObj4"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid4"
                                ref="grid4"
                                :fields="view4.fields"
                                :columns="view4.columns"
                                :style="subGridStyle4"
                                @hook:mounted="tabGridMounted4"
                            />
                            <TCRealGridHeader
                                id="gridHeader5"
                                ref="gridHeader5"
                                gridTitle="T-약정금액"
                                :gridObj="gridObj5"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid5"
                                ref="grid5"
                                :fields="view5.fields"
                                :columns="view5.columns"
                                :style="subGridStyle5"
                                @hook:mounted="tabGridMounted5"
                            />
                        </div>
                        <div class="div2_8 cont2 left">
                            <TCRealGridHeader
                                id="gridHeader2"
                                ref="gridHeader2"
                                gridTitle="SKT 인센티브 현황(소계)"
                                :gridObj="gridObj2"
                                :isPageRows="true"
                                :isNextPage="true"
                                :isPageCnt="true"
                                :isExceldown="true"
                                :style="subGridStyle"
                                @excelDownBtn="downloadExcelAll(2)"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid2"
                                ref="grid2"
                                :fields="view2.fields"
                                :columns="view2.columns"
                                :style="subGridStyleGrid"
                                @hook:mounted="tabGridMounted2"
                            />
                            <TCComPaging
                                :totalPage="gridData2.totalPage"
                                :apiFunc="getIncenSummary"
                                :rowCnt="rowCnt2"
                                :style="subGridPagStyle"
                                @input="chgRowCnt2"
                            />
                        </div>
                    </div>
                </template>
            </TCComTab>
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
// import commonApi from '@/api/common/prototype'
import { CommonGrid, CommonUtil } from '@/utils'
import moment from 'moment'
import { AccUtil } from '@/views/biz/acc'
//====================조직별대리점팝업====================
import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
//====================//조직별대리점팝업====================
import sktIncenAccApi from '@/api/biz/acc/sss/AccSssIncenAccMgmt'
import {
    GRID_HEADER,
    GRID_HEADER_DTL,
    GRID_HEADER_SUB,
    GRID_HEADER_SUB1,
    GRID_HEADER_SUB2,
    GRID_HEADER_SUB3,
} from '@/const/grid/acc/sss/AccSssIncenAccMgmtGrid'
import CommonMixin from '@/mixins'
export default {
    name: 'AccSssSkbCmmsIncenAccMgmt',
    components: {
        BasBcoOrgAgencysPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,
            view1: GRID_HEADER_DTL,
            view2: GRID_HEADER_SUB,
            view3: GRID_HEADER_SUB1,
            view4: GRID_HEADER_SUB2,
            view5: GRID_HEADER_SUB3,

            //Grid
            objAuth: {},
            tabDefault: {},
            gridData1: {},
            gridData2: {},
            gridObj: {},
            gridHeaderObj: {},
            gridObj1: {},
            gridHeaderObj1: {},
            gridObj2: {},
            gridHeaderObj2: {},
            gridObj3: {},
            gridHeaderObj3: {},
            gridObj4: {},
            gridHeaderObj4: {},
            gridObj5: {},
            gridHeaderObj5: {},

            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            subGridStyle: {
                display: 'none',
            },
            subGridStyleGrid: {
                display: 'none',
                height: '500px',
            },

            dtlGridStyle: {
                display: 'block',
            },
            dtlGridStyleGird: {
                display: 'block',
                height: '500px',
            },
            subGridStyle3: {
                height: '140px',
            },
            subGridStyle4: {
                height: '120px',
            },
            subGridStyle5: {
                height: '140px',
            },
            showBtn: {
                display: 'inline-block',
            },
            subGridPagStyle: {
                display: 'none',
            },

            // 버튼 비활성화
            approvalBtnDis: false,
            onSaveDis: true,
            onDelDis: true,
            showSrchType: false,

            onConfrimDisplay: true,
            searchForms: {},

            //tab
            tab: {
                nowIndex: 0,
                tabSync1: 0,
            },
            //조회 조건 tab, radio
            items: ['Template1', 'Template2'],
            itemName: ['인센티브 정산목록', '그룹항목별 정산목록'],

            confirmDate_: moment(this.accYm_)
                .endOf('month')
                .format('YYYY-MM-DD'),
            accYm_: moment(new Date()).format('YYYY-MM'),

            searchFormData: {
                srchAccYm: '',
                accYm: moment(new Date()).format('YYYY-MM'),
                confirmDate: moment(new Date()).format('YYYY-MM-DD'),
                srchAgencyCd: '',
                srchType: 'A',
                srchTab: 'A',
            },
            pageSize: '',
            pageNum: 1,
            rowData: '',
            rowCnt1: 15,
            rowCnt2: 15,
            onDelDisCnt: 0,
            onSaveDisCnt: 0,

            //조회구분 Radio BTN
            tabListItems: [
                {
                    commCdVal: 'A',
                    commCdValNm: '인센티브 정산목록',
                },
                {
                    commCdVal: 'B',
                    commCdValNm: '그룹항목별 정산목록',
                },
            ],

            srchTypeItmes: [
                {
                    commCdVal: 'A',
                    commCdValNm: '세부유형',
                },
                {
                    commCdVal: 'B',
                    commCdValNm: '소계',
                },
            ],

            /* popup영역 */
            //====================조직별대리점팝업관련====================
            showBcoOrgAgencys: false, // 조직별대리점 팝업 오픈 여부
            searchOrgAgencyParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultOrgAgencyRows: [], // 조직별대리점 팝업 오픈 여부
            //====================//조직별대리점팝업관련==================

            popupParams: {},
            dtlParam: {},
            popup: {},
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, true, true)
        this.$refs.grid.gridView.setColumnLayout(this.view.layout) //그리드 Header Layout 세팅하기
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: '번호',
        })
        this.$refs.grid.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.onItemChecked = this.onItemChecked
        this.gridObj.gridView.onItemAllChecked = this.onItemAllChecked

        //  PS&M사용자일 경우 승인요청버튼 보임
        if (this.orgInfo.orgCdLvl0 == 'O00000') {
            this.onConfrimDisplay = true
        } else {
            this.onConfrimDisplay = false
        }
    },
    computed: {},
    watch: {},
    created() {
        this.gridData1 = this.gridSetData1(this.rowCnt)
        this.gridData2 = this.gridSetData2(this.rowCnt)
    },
    methods: {
        // 초기화
        init: function () {
            this.initSearch()
            this.confirmDate_ = moment(this.accYm_)
                .endOf('month')
                .format('YYYY-MM-DD')
            this.accYm_ = moment(new Date()).format('YYYY-MM')
            this.searchOrgAgencyParam = {}
            this.searchForms = {}
            this.$refs.grid.setRows([])
            this.$refs.grid1.setRows([])
            this.$refs.grid2.setRows([])
            this.$refs.grid3.setRows([])
            this.$refs.grid4.setRows([])
            this.$refs.grid5.setRows([])
            this.onDelDisCnt = 0
            this.onSaveDisCnt = 0
            this.onDelDis = true
            this.onSaveDis = true
            this.tab = {
                tabSync1: 0,
            }
            this.gridData1.totalPage = 0 // 이전페이지정보 초기화
            this.gridData2.totalPage = 0
        },
        initSearch: function () {
            this.searchFormData = {
                srchAccYm: '',
                accYm: moment(new Date()).format('YYYY-MM'),
                confirmDate: moment(new Date()).format('YYYY-MM-DD'),
                srchAgencyCd: '',
                srchType: 'A',
                srchTab: 'A',
            }
        },

        gridSetData1(rowCnt1) {
            return new CommonGrid(0, rowCnt1, '', '')
        },
        gridSetData2(rowCnt2) {
            return new CommonGrid(0, rowCnt2, '', '')
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt1(val) {
            this.rowCnt1 = val
            this.onSearch()
        },
        chgRowCnt2(val) {
            this.rowCnt2 = val
            this.onSearch()
        },
        //헤더 전체 체크 여부 콜백
        //헤더체크[allChecked] : 확정여부(fixYn) 값에 따른 확정/삭제 버튼 속성변경
        onItemAllChecked: function (grid, checked) {
            if (this.onSaveDisCnt > 0 && checked == true) {
                this.onSaveDisCnt = 0
                this.onDelDisCnt = 0
            }
            if (this.onDelDisCnt > 0 && checked == true) {
                this.onSaveDisCnt = 0
                this.onDelDisCnt = 0
            }
            var transListsCount = this.$refs.grid.gridView.getItemCount()
            for (var j = 0; j < transListsCount; j++) {
                var rowData2 = this.$refs.grid.gridView.getValues(j)
                //전체 체크시
                if (checked) {
                    if (rowData2.fixYn != 'Y') {
                        this.onSaveDisCnt++
                    }
                    if (rowData2.fixYn == 'Y') {
                        this.onDelDisCnt++
                    }
                }
                if (checked == false) {
                    if (rowData2.fixYn != 'Y') {
                        this.onSaveDisCnt--
                    }
                    if (rowData2.fixYn == 'Y') {
                        this.onDelDisCnt--
                    }
                }
            }
            if (this.onSaveDisCnt > 0 && this.onDelDisCnt == 0) {
                this.onSaveDis = false
                this.onDelDis = true
            } else if (this.onDelDisCnt > 0 && this.onSaveDisCnt == 0) {
                this.onSaveDis = true
                this.onDelDis = false
            } else {
                this.onDelDis = true
                this.onSaveDis = true
            }
        },
        //그리드 체크 여부 콜백
        //그리드 체크 : 확정여부(fixYn) 값에 따른 확정/삭제 속성변경
        onItemChecked: function (grid, itemindex, checked) {
            var rowData1 = this.$refs.grid.gridView.getValues(itemindex)
            if (checked) {
                if (rowData1.fixYn != 'Y') {
                    this.onSaveDisCnt++
                }
                if (rowData1.fixYn == 'Y') {
                    this.onDelDisCnt++
                }
            }
            if (checked == false) {
                if (rowData1.fixYn != 'Y') {
                    this.onSaveDisCnt--
                }
                if (rowData1.fixYn == 'Y') {
                    this.onDelDisCnt--
                }
            }
            if (this.onSaveDisCnt > 0 && this.onDelDisCnt == 0) {
                this.onSaveDis = false
                this.onDelDis = true
            } else if (this.onDelDisCnt > 0 && this.onSaveDisCnt == 0) {
                this.onSaveDis = true
                this.onDelDis = false
            } else {
                this.onDelDis = true
                this.onSaveDis = true
            }
        },

        //tab 클릭으로 인한 이벤트 처리
        onActiveTabChange(tabIdx) {
            this.tab.nowIndex = tabIdx
            if (tabIdx == 0) {
                this.showSrchType = false
                this.searchFormData.srchTab = 'A'
                this.showBtn.display = 'inline-block'
            }
            if (tabIdx == 1) {
                this.showSrchType = true
                this.searchFormData.srchTab = 'B'
                this.showBtn.display = 'none'
            }
        },
        onActiveTabClick(tabIdx) {
            console.log('onActiveTabClick: ', tabIdx)
        },

        // ComboBox 선택으로 tab 변경시 이벤트 처리
        srchTabChng(comboIdx) {
            if (comboIdx == 'A') {
                this.tab.tabSync1 = 0
                this.showSrchType = false
                this.showBtn.display = 'inline-block'
            }
            if (comboIdx == 'B') {
                this.tab.tabSync1 = 1
                this.showSrchType = true
                this.showBtn.display = 'none'
            }
        },
        srchTypeChng() {
            if (this.searchFormData.srchType == 'A') {
                this.subGridStyle.display = 'none'
                this.subGridStyleGrid.display = 'none'
                this.dtlGridStyle.display = 'block'
                this.dtlGridStyleGird.display = 'block'
            }

            if (this.searchFormData.srchType == 'B') {
                this.dtlGridStyle.display = 'none'
                this.dtlGridStyleGird.display = 'none'
                this.subGridStyle.display = 'block'
                this.subGridStyleGrid.display = 'block'
            }
        },

        tabGridMounted1() {
            this.gridHeaderObj1 = this.$refs.gridHeader1
            this.gridObj1 = this.$refs.grid1
            this.gridObj1.setGridState(false, false, false, true) //footer 나오게
            this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj1.gridView.setColumnLayout(this.view1.layout)
        },
        tabGridMounted2() {
            this.gridHeaderObj2 = this.$refs.gridHeader2
            this.gridObj2 = this.$refs.grid2
            this.gridObj2.setGridState(false, false, false, true) //footer 나오게
            this.gridObj2.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj2.gridView.setColumnLayout(this.view2.layout)
        },
        tabGridMounted3() {
            this.gridHeaderObj3 = this.$refs.gridHeader3
            this.gridObj3 = this.$refs.grid3
            this.gridObj3.setGridState(false, false, false, true) //footer 나오게
            this.gridObj3.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        },
        tabGridMounted4() {
            this.gridHeaderObj4 = this.$refs.gridHeader4
            this.gridObj4 = this.$refs.grid4
            this.gridObj4.setGridState(false, false, false, true) //footer 나오게
            this.gridObj4.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        },
        tabGridMounted5() {
            this.gridHeaderObj5 = this.$refs.gridHeader5
            this.gridObj5 = this.$refs.grid5
            this.gridObj5.setGridState(false, false, false, false) //footer 나오게
            this.$refs.grid5.gridView.setColumnLayout(this.view5.layout5) //그리드 Header Layout 세팅하기
            this.gridObj5.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            // this.gridObj5.gridView.setColumnProperty('title1', 'mergeRule', {
            //     criteria: 'value',
            // })
        },
        //===================== //내부거래처(거래종료확인) methods ================================

        //===================== //내부거래처(권한조직) methods ================================

        //===================== 조직별 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getOrgAgencyList() {
            basBcoOrgAgencysApi
                .getOrgAgencyList(this.searchOrgAgencyParam)
                .then((res) => {
                    console.log('getOrgAgencyList then : ', res)
                    // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                    // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                    if (res.length === 1) {
                        this.searchOrgAgencyParam.agencyCd = _.get(
                            res[0],
                            'agencyCd'
                        )
                        this.searchOrgAgencyParam.agencyNm = _.get(
                            res[0],
                            'agencyNm'
                        )
                    } else {
                        this.resultOrgAgencyRows = res
                        this.showBcoOrgAgencys = true
                    }
                })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onOrgAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            // if (!_.isEmpty(this.searchOrgAgencyParam.agencyNm)) {
            //     this.getOrgAgencyList()
            // } else {
            this.showBcoOrgAgencys = true
            // }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onOrgAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            // if (_.isEmpty(this.searchOrgAgencyParam.agencyNm)) {
            //     this.showTcComAlert('대리점명을 입력해주세요.')
            //     return
            // }
            // 대리점 정보 조회
            // this.getOrgAgencyList()
            this.showBcoOrgAgencys = true
        },
        // 대리점 TextField Input 이벤트 처리
        onOrgAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.searchOrgAgencyParam.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onOrgAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchOrgAgencyParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.searchOrgAgencyParam.agencyNm = _.get(retrunData, 'agencyNm')
        },
        //===================== //조직별대리점팝업관련 methods ================================

        //================================================
        // 전체 조회 :::: getIncenAccList
        //================================================
        onSearch: function () {
            const srchAccYm = this.accYm_
            this.confirmDate_ = moment(this.accYm_)
                .endOf('month')
                .format('YYYY-MM-DD')
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
            } else {
                this.searchFormData.srchAccYm = CommonUtil.onlyNumber(
                    this.accYm_
                )
                this.searchFormData.pageSize = this.rowCnt1
                this.searchForms = { ...this.searchFormData }
                this.searchForms.srchAgencyCd =
                    this.searchOrgAgencyParam.agencyCd
                if (this.tab.tabSync1 == 0) {
                    this.getIncenAccList()
                    console.log('인센티브 정산목록 조회 ::::: START')
                }
                if (
                    this.tab.tabSync1 == 1 &&
                    // this.searchFormData.srchTab == 'B' &&
                    this.searchFormData.srchType == 'A'
                ) {
                    this.getIncenList(this.searchForms.pageNum)
                    console.log(
                        '그룹항목별 정산목록(세부유형) 조회 ::::: START'
                    )
                    this.getIncenSumByGroupItem()
                    this.getAgrmtAmt()
                }
                if (
                    this.tab.tabSync1 == 1 &&
                    // this.searchFormData.srchTab == 'B' &&
                    this.searchFormData.srchType == 'B'
                ) {
                    this.getIncenSummary(this.searchForms.pageNum)
                    console.log('그룹항목별 정산목록(소계) 조회 ::::: START')
                    this.getIncenSumByGroupItem()
                    this.getAgrmtAmt()
                }
                // this.onDelDis = true
                // this.onSaveDis = true
            }
        },
        async getIncenAccList() {
            await sktIncenAccApi
                .getIncenAccList(this.searchForms)
                .then((res) => {
                    if (res != undefined) {
                        console.log('전체리스트조회 ::::::: ' + res)
                        this.list = res
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator(res)
                        this.gridHeaderObj.setPageCount(res)
                        this.gridObj.gridView.checkAll(false)
                        this.onSaveDisCnt = 0
                        this.onDelDisCnt = 0
                        console.log('전체리스트조회 ::::::: END')
                    } else {
                        this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                    }
                })
        },
        // 그룹항목별 정산목록 _ 세부유형
        async getIncenList(page) {
            this.searchForms.pageNum = page
            await sktIncenAccApi.getIncenList(this.searchForms).then((res) => {
                if (res != undefined) {
                    console.log()
                    this.gridObj1.setRows(res.gridList)
                    this.gridObj1.setGridIndicator(res.pagingDto)
                    this.gridData1 = this.gridSetData1()
                    this.gridData1.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj1.setPageCount(res.pagingDto)
                    console.log('그룹항목별 정산목록(세부유형) 조회 END')
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },
        // 그룹항목별 정산목록 _ 소계
        async getIncenSummary(page) {
            this.searchForms.pageNum = page
            await sktIncenAccApi
                .getIncenSummary(this.searchForms)
                .then((res) => {
                    if (res != undefined) {
                        console.log()
                        this.gridObj2.setRows(res.gridList)
                        this.gridObj2.setGridIndicator(res.pagingDto)
                        this.gridData2 = this.gridSetData2()
                        // this.gridData2.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                        this.gridHeaderObj2.setPageCount(res.pagingDto)
                        console.log('그룹항목별 정산목록(소계) 조회 END')
                    } else {
                        this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                    }
                })
        },
        // 영업월별 인센티브 합계
        async getIncenSumByGroupItem() {
            await sktIncenAccApi
                .getIncenSumByGroupItem(this.searchForms)
                .then((res) => {
                    console.log(
                        '그룹항목별 정산목록(영업별 인센티브 합계) 조회 START'
                    )
                    if (res != undefined) {
                        console.log(res.gridList)
                        this.gridObj3.setRows(res.gridList)
                        this.gridObj3.setGridIndicator(res)
                        console.log(
                            '그룹항목별 정산목록(영업별 인센티브 합계) 조회 END'
                        )
                    } else {
                        this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                    }
                })
        },
        // 제외금액(본사/CW) - PS&M에서 현재 상태를 보고 결정 예정
        // async 제외금액(본사/CW)() {
        //     await sktIncenAccApi
        //         .제외금액(본사/CW)(this.searchForms)
        //         .then((res) => {
        //             console.log(
        //                 '그룹항목별 정산목록(제외금액(본사/CW)) 조회 START'
        //             )
        //             if (res != undefined) {
        //                 console.log(res.gridList)
        //                 this.gridObj4.setRows(res.gridList)
        //                 this.gridObj4.setGridIndicator(res)
        //                 this.gridHeaderObj4.setPageCount(res)
        //                 console.log(
        //                     '그룹항목별 정산목록(제외금액(본사/CW)) 조회 END'
        //                 )
        //             } else {
        //                 this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
        //             }
        //         })
        // },
        async getAgrmtAmt() {
            await sktIncenAccApi.getAgrmtAmt(this.searchForms).then((res) => {
                console.log('그룹항목별 정산목록(T-약정금액 ) 조회 START')
                if (res != undefined) {
                    console.log(res.gridList)
                    this.gridObj5.setRows(res.gridList)
                    this.gridObj5.dataProvider.setValue(2, 'title1', '')
                    this.gridObj5.dataProvider.setValue(3, 'title1', '')
                    this.gridObj5.setGridIndicator(res)
                    console.log('그룹항목별 정산목록(T-약정금액 ) 조회 END')
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },

        //================================================
        // 선택한 row 확정 :::: fixIncenAccList
        //================================================
        onSave: function () {
            this.searchForms.list = []
            this.searchForms.accYm = CommonUtil.onlyNumber(this.accYm_)
            this.searchForms.confirmDate = CommonUtil.onlyNumber(
                this.confirmDate_
            )
            var list = this.$refs.grid.gridView.getCheckedItems(true)
            if (list == null || list.length == 0) {
                this.showTcComAlert('선택된 대리점이 없습니다.')
                return
            } else {
                for (var i = 0; i < list.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(list[i])
                    // 이미 확정처리가 되어 있는 건 :: fix_yn
                    if (row['fixYn'] == 'Y') {
                        this.showTcComAlert(
                            '확정이 완료된 대리점이 포함되어 있습니다.'
                        )
                        return
                    }

                    if (row['aplyPrcPrc'] == 0) {
                        this.showTcComAlert(
                            'Swing에서 전송된 인센티브 데이터가 없습니다.'
                        )
                        return
                    }
                    this.searchForms.list.push({
                        agencyCd: row.agencyCd, // 대리점
                        accAmt: row.accAmt, // 추정 인센티브 금액
                    })
                }
                console.log(
                    '확정_fixIncenAccList ::::::: Start' + this.searchForms
                )
                sktIncenAccApi
                    .fixIncenAccList(this.searchForms)
                    .then((resultData) => {
                        if (resultData == undefined) {
                            this.showTcComAlert('확정 처리실패하였습니다.')
                            return
                        } else {
                            console.log(
                                row + '확정_fixIncenAccList ::::::: END'
                            )
                            this.showTcComAlert('확정 처리되었습니다.')
                            this.onSearch()
                        }
                    })
            }
        },
        //================================================
        // 선택한 row (삭제) :::deleteIncenAccList
        //================================================
        onDele: function () {
            this.searchForms.accYm = CommonUtil.onlyNumber(this.accYm_)
            this.searchForms.confirmDate = CommonUtil.onlyNumber(
                this.confirmDate_
            )
            var list = this.$refs.grid.gridView.getCheckedItems(true)
            if (list == null || list.length == 0) {
                this.showTcComAlert('선택된 대리점이 없습니다.')
                return
            }
            this.searchForms.list = []
            for (var i = 0; i < list.length; i++) {
                var row = this.$refs.grid.gridView.getValues(list[i])
                // 선택된 대리점중 확정이 완료된 건이 포함되어있는지 체크 ::: fixYn
                if (row['fixYn'] != 'Y') {
                    console.log(row['fixYn'])
                    this.showTcComAlert(
                        '삭제할 이력이 없는 항목이 포함되어 있습니다.'
                    )
                    return
                } else {
                    this.searchForms.list.push({
                        agencyCd: row.agencyCd,
                        accDealcoCd: '10001',
                    })
                }
            }

            this.showTcComConfirm('정산 내역을 삭제하시겠습니까?').then(
                (confirm) => {
                    if (confirm) {
                        sktIncenAccApi
                            .deleteIncenAccList(this.searchForms)
                            .then((resultData) => {
                                if (resultData != undefined) {
                                    console.log(
                                        '선택리스트삭제 ::::::: Start',
                                        this.searchForms
                                    )
                                    this.showTcComAlert('삭제 처리되었습니다.')
                                    console.log('선택리스트확정취소 :::::::END')
                                    this.onSearch()
                                } else {
                                    this.showTcComAlert(
                                        '삭제 처리실패하였습니다.'
                                    )
                                }
                            })
                    }
                }
            )
        },
        //================================================
        // 승인요청 :::requestEaprv
        //================================================
        approvalReq: function () {
            this.searchForms.accYm = CommonUtil.onlyNumber(this.accYm_)
            this.searchForms.confirmDate = CommonUtil.onlyNumber(
                this.confirmDate_
            )
            var list = this.$refs.grid.gridView.getCheckedItems(true)
            if (list == null || list.length == 0) {
                this.showTcComAlert(
                    '승인요청 대상 대리점을 선택 후 재처리하십시오.'
                )
                return
            }
            this.searchForms.list = []
            for (var i = 0; i < list.length; i++) {
                var row = this.$refs.grid.gridView.getValues(list[i])
                // row.prcsDtm = AccUtil.dateToFormat(
                //     new Date(row.prcsDtm),
                //     'YYYYMMDD'
                // )
                row.sktTrmsDtm = AccUtil.dateToFormat(
                    new Date(row.sktTrmsDtm),
                    'YYYYMMDD'
                )

                if (row['confirmYn'] == '미확정') {
                    this.showTcComAlert(
                        '미확정 대리점이 있습니다.[' +
                            row['agencyCd'] +
                            '(' +
                            row['agencyNm'] +
                            ')]' +
                            '\n승인요청은 확정후에 가능합니다.'
                    )
                    return
                }
                if (
                    row['aprvStatCd'] == '01' || // 요청중
                    row['aprvStatCd'] == 'C' || // 승인완료
                    row['aprvStatCd'] == 'P' || // 진행중
                    row['aprvStatCd'] == 'RD' // 준비중
                ) {
                    this.showTcComAlert(
                        '승인이 진행중이거나 완료된 대리점이 있습니다.\n[' +
                            row['agencyCd'] +
                            '(' +
                            row['agencyNm'] +
                            ')]'
                    )
                    return
                } else {
                    row.accDealcoCd = '10001'
                    this.searchForms.list.push(row)
                }
            }
            console.log(this.searchForms)
            sktIncenAccApi.requestEaprv(this.searchForms).then((resultData) => {
                if (resultData != undefined) {
                    this.showTcComAlert('승인요청 처리되었습니다.')
                    this.onSearch()
                } else {
                    this.showTcComAlert('승인요청 처리실패하였습니다.')
                }
            })
        },
        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcelAll: function (index) {
            this.searchFormData.srchAccYm = CommonUtil.onlyNumber(this.accYm_)
            this.searchFormData.srchAgencyCd =
                this.searchOrgAgencyParam.agencyCd
            if (index == '1') {
                sktIncenAccApi.downloadIncenAccListExcel(this.searchFormData)
            }
            if (index == '2') {
                sktIncenAccApi.downloadIncenListExcel(this.searchFormData)
            }
        },
    },
}
</script>
