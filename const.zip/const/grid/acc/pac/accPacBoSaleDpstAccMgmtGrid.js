import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = {
    columnsBo: [
        {
            fieldName: 'pagingSeq',
            header: { text: '번호' },
            width: '45',
        },
        {
            fieldName: 'ordId',
            header: { text: '주문ID' },
            width: '150',
        },
        {
            fieldName: 'webOrdNo',
            header: { text: '주문번호' },
            width: '150',
        },
        {
            fieldName: 'ordAcptDtm',
            header: { text: '주문일자' },
            width: '150',
            dataType: ValueType.DATETIME,
            fieldDatetimeFormat: 'yyyyMMdd',
            columnDatetimeFormat: 'yyyy-MM-dd',
        },
        {
            fieldName: 'ordClNm',
            header: { text: '주문진행상태' },
            width: '150',
        },
        {
            fieldName: 'saleChgDtm',
            header: { text: '출고일자' },
            width: '150',
            dataType: ValueType.DATETIME,
            fieldDatetimeFormat: 'yyyyMMdd',
            columnDatetimeFormat: 'yyyy-MM-dd',
        },
        {
            fieldName: 'saleTypNm',
            header: { text: '매출구분' },
            width: '150',
        },
        {
            fieldName: 'orgTree',
            header: { text: '조직' },
            styleName: 'left-column',
            width: '400',
        },
        // {
        //     fieldName: 'bizChrgOrgNm',
        //     header: { text: '사업담당' },
        //     styleName: 'left-column',
        //     width: '150',
        // },
        // {
        //     fieldName: 'teamOrgNm',
        //     header: { text: '팀' },
        //     styleName: 'left-column',
        //     width: '150',
        // },
        {
            fieldName: 'saleDealcoCd',
            header: { text: '판매처코드' },
            styleName: 'left-column',
            width: '100',
        },
        {
            fieldName: 'saleDealcoNm',
            header: { text: '판매처명' },
            styleName: 'left-column',
            width: '150',
        },
        {
            fieldName: 'sktCd',
            header: { text: '매장코드' },
            width: '100',
        },
        {
            fieldName: 'svcMgmtNum',
            header: { text: '서비스관리번호' },
            width: '150',
        },
        {
            fieldName: 'gnrlPaymentNo',
            header: { text: '수납관리번호' },
            width: '150',
        },
        // {
        //     fieldName: 'occrDtm',
        //     header: { text: '매출일자' },
        //     width: '150',
        //     dataType: ValueType.DATETIME,
        //     fieldDatetimeFormat: 'yyyyMMdd',
        //     columnDatetimeFormat: 'yyyy-MM-dd',
        // },
        {
            fieldName: 'occrAmt',
            header: { text: '매출 금액' },
            width: '150',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
            styleName: 'right-column',
        },
        {
            fieldName: 'payMthdNm',
            styles: { textAlignment: 'left' },
            header: { text: '수납구분' },
            width: '150',
        },
        // {
        //     fieldName: 'col01',
        //     header: { text: '거래상태' },
        //     width: '150',
        // },
        // {
        //     fieldName: 'col02',
        //     header: { text: '거래일시' },
        //     width: '150',
        //     dataType: ValueType.DATETIME,
        //     fieldDatetimeFormat: 'yyyyMMDD',
        //     columnDatetimeFormat: 'yyyy-MM-DD',
        // },
        // {
        //     fieldName: 'col03',
        //     header: { text: '지급(예정)일' },
        //     width: '150',
        //     dataType: ValueType.DATETIME,
        //     fieldDatetimeFormat: 'yyyyMMDD',
        //     columnDatetimeFormat: 'yyyy-MM-DD',
        // },
        // {
        //     fieldName: 'col04',
        //     header: { text: '결제기관' },
        //     width: '150',
        // },
        // {
        //     fieldName: 'col05',
        //     header: { text: '승인번호' },
        //     width: '150',
        // },
        // {
        //     fieldName: 'col06',
        //     header: { text: '거래금액' },
        //     width: '150',
        //     dataType: ValueType.NUMBER,
        //     numberFormat: '#,###,###,##0',
        // },
        // {
        //     fieldName: 'col07',
        //     header: { text: '수수료' },
        //     width: '150',
        //     dataType: ValueType.NUMBER,
        //     numberFormat: '#,###,###,##0',
        // },
        // {
        //     fieldName: 'col08',
        //     header: { text: '정산(예정)금액' },
        //     width: '150',
        //     dataType: ValueType.NUMBER,
        //     numberFormat: '#,###,###,##0',
        // },
        {
            fieldName: 'prodNm',
            header: { text: '상품명' },
            styleName: 'left-column',
            width: '150',
        },
        // {
        //     fieldName: 'prodNo',
        //     header: { text: '상품 일련번호' },
        //     width: '150',
        // },
        // {
        //     fieldName: 'usimNm',
        //     header: { text: 'USIM명' },
        //     width: '150',
        // },
        // {
        //     fieldName: 'usimNo',
        //     header: { text: 'USIM일련번호' },
        //     width: '150',
        // },
        // {
        //     fieldName: 'col09',
        //     header: { text: '구매자' },
        //     width: '150',
        // },
        // {
        //     fieldName: 'col10',
        //     header: { text: '가상계좌 입금액' },
        //     width: '150',
        //     numberFormat: '#,###,###,##0',
        //     styles: {
        //         textAlignment: 'far',
        //     },
        // },
        // {
        //     fieldName: 'col11',
        //     header: { text: '입금여부' },
        //     width: '150',
        // },
        // {
        //     fieldName: 'col12',
        //     header: { text: '입금 일자' },
        //     width: '150',
        //     dataType: ValueType.DATETIME,
        //     fieldDatetimeFormat: 'yyyyMMDD',
        //     columnDatetimeFormat: 'yyyy-MM-DD',
        // },
        // {
        //     fieldName: 'col13',
        //     header: { text: '입금 금액' },
        //     width: '150',
        //     numberFormat: '#,###,###,##0',
        //     styles: {
        //         textAlignment: 'far',
        //     },
        // },
        // {
        //     fieldName: 'col14',
        //     header: { text: '처리자ID' },
        //     width: '150',
        // },
        // {
        //     fieldName: 'col15',
        //     header: { text: '처리자명' },
        //     width: '150',
        // },
        // {
        //     fieldName: 'col16',
        //     header: { text: '처리일시' },
        //     width: '150',
        //     dataType: ValueType.DATETIME,
        //     fieldDatetimeFormat: 'yyyyMMDD',
        //     columnDatetimeFormat: 'yyyy-MM-DD',
        // },
        // {
        //     fieldName: 'col17',
        //     header: { text: '비고' },
        //     width: '150',
        // },
    ],
    columnsPg: [
        {
            fieldName: 'pagingSeq',
            header: { text: '번호' },
            width: '45',
        },
        {
            fieldName: 'settlMthdNm',
            header: { text: '결제수단' },
            width: '150',
        },
        {
            fieldName: 'joinbrDealNo',
            header: { text: '가맹점거래번호' },
            width: '150',
        },
        {
            fieldName: 'dealClNm',
            header: { text: '거래구분' },
            width: '150',
        },
        {
            fieldName: 'dealDtm',
            header: { text: '거래일시' },
            width: '150',
            dataType: ValueType.DATETIME,
            fieldDatetimeFormat: 'yyyyMMddHHmmss',
            columnDatetimeFormat: 'yyyy-MM-dd HH:mm:ss',
        },
        {
            fieldName: 'prchCoNm',
            header: { text: '결제기관' },
            width: '150',
        },
        {
            fieldName: 'aprvAmt',
            header: { text: '승인금액' },
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
            styleName: 'right-column',
        },
        {
            fieldName: 'aprvNo',
            header: { text: '승인번호' },
            width: '150',
        },
        {
            fieldName: 'dpstSchdDt',
            header: { text: '입금예정일자' },
            width: '150',
            dataType: ValueType.DATETIME,
            fieldDatetimeFormat: 'yyyyMMdd',
            columnDatetimeFormat: 'yyyy-MM-dd',
        },
        {
            fieldName: 'cmmsAmt',
            header: { text: '수수료' },
            width: '150',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
            styleName: 'right-column',
        },
        {
            fieldName: 'dpstSchdAmt',
            header: { text: '입금예정액' },
            width: '150',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
            styleName: 'right-column',
        },
        {
            fieldName: 'ordrNm',
            header: { text: '주문자명' },
            width: '150',
        },
        {
            fieldName: 'ordProd',
            header: { text: '주문상품' },
            width: '150',
        },
        {
            fieldName: 'modUserNm',
            header: { text: '처리자' },
            width: '150',
        },
        {
            fieldName: 'modDtm',
            header: { text: '처리일시' },
            width: '150',
            dataType: ValueType.DATETIME,
            columnDatetimeFormat: 'yyyy-MM-dd HH:mm:ss',
        },
    ],
}

const GRID_HEADER = {}

/* BO매출 관리 Tab */
GRID_HEADER.columnsBo = gridMetaUtil.adjustColumns(GRID_META.columnsBo)
GRID_HEADER.fieldsBo = gridMetaUtil.adjustFields(GRID_META.columnsBo)

/* PG(퍼스트페이)입금 Tab */
GRID_HEADER.columnsPg = gridMetaUtil.adjustColumns(GRID_META.columnsPg)
GRID_HEADER.fieldsPg = gridMetaUtil.adjustFields(GRID_META.columnsPg)

export { GRID_HEADER }
