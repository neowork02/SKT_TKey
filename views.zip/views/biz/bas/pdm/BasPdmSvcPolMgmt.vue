<!-----------------------------------------------
 * 업무 그룹명 : 상품관리>사용자부가정책관리
 * 서브 업무명 : 사용자부가정책관리
 * 설 명 : 부가정책을 조회한다.
 * 작 성 자 : P180182
 * 작 성 일 : 2022.10.05
 * Copyright ⓒ SK TELECOM. All Right Reserved
 ------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>사용자 부가 정책 관리</h1>
        <!-- //Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left"></li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="iniBtn"
                    :objAuth="objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="newBtn"
                    :objAuth="objAuth"
                >
                    신규
                </TCComButton>
            </li>
        </ul>
        <!-- //Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="M"
                        v-model="brwsYm"
                        labelName="조회년월"
                        :objAuth="objAuth"
                        :eRequired="true"
                        value-format="YYYY-MM"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="reqParam.suplSvcNm"
                        labelName="부가정책명"
                        :objAuth="objAuth"
                        @enterKey="searchBtn"
                    ></TCComInput>
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="reqParam.useYn"
                        labelName="사용여부"
                        :objAuth="objAuth"
                        :itemList="useYnList"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-3 -->
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- //Search_div -->

        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="부가 정책 목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @excelDownBtn="excelDownBtn"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="gridHeader.fields"
                :columns="gridHeader.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getSvcPolMgmtList"
                :gridObj="gridObj"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            />
        </div>
        <!-- //gridWrap -->

        <!-- Popup -->
        <DtlPopup
            v-if="showDtlPopup"
            ref="popup"
            :dialogShow.sync="showDtlPopup"
            :parentParam="popupParam"
            @close="searchBtn"
        />
        <!-- Popup -->
    </div>
</template>
<script>
import { GRID_HEADER } from '@/const/grid/bas/pdm/basPdmSvcPolMgmtHeader.js'
import DtlPopup from './BasPdmSvcPolMgmtDtlPopup'
import restApi from '@/api/biz/bas/pdm/basPdmSvcPolMgmt.js'
import attachedFileApi from '@/api/common/attachedFile'
import { CommonGrid, CommonUtil } from '@/utils'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'BasPdmSvcPolMgmt',
    mixins: [CommonMixin],
    components: { DtlPopup },
    data() {
        return {
            gridHeader: GRID_HEADER,
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            rowCnt: 15,
            searchForms: {},
            reqParam: {
                // 요청파라미터
                brwsYm: '', // 조회년월
                suplSvcNm: '', // 부가서비스명
                useYn: '', // 사용여부
            },
            popupParam: {},
            brwsYm: '',
            showDtlPopup: false,
            useYnList: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
        }
    },
    watch: {},
    computed: {},
    created() {
        this.gridData = this.gridSetData(this.rowCnt)
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(true)
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked

        this.defaultSet()
    },
    methods: {
        // 화면 default 설정
        defaultSet() {
            this.brwsYm = moment(new Date()).format('YYYY-MM')
        },
        // Grid Init
        gridSetData(rowCnt) {
            return new CommonGrid(0, rowCnt, '', '')
        },
        // 페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        // 초기화 버튼 이벤트
        iniBtn() {
            this.gridData = this.gridSetData(this.rowCnt)
            this.gridObj.gridInit()
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })

            CommonUtil.clearPage(this, 'reqParam')
            this.defaultSet()
        },
        // 조회 버튼 이벤트
        searchBtn() {
            this.reqParam.brwsYm = this.brwsYm.replace(/-/gi, '')

            // validation 체크
            if (!this.isValidChk()) return false

            // 첫 조회시 표시할 행의 갯수
            this.searchForms = { ...this.reqParam }
            this.searchForms.pageSize = this.rowCnt
            this.searchForms.pageNum = 1 // 첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getSvcPolMgmtList(this.searchForms.pageNum)
        },
        // 서비스정책관리 조회
        getSvcPolMgmtList(page) {
            this.searchForms.pageNum = page

            restApi.getSvcPolMgmtList(this.searchForms).then((res) => {
                this.gridObj.setRows(res.gridList)
                this.gridObj.setGridIndicator(res.pagingDto, this.indicatorOpt) // 순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData(this.rowCnt) // 초기화
                this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj.setPageCount(res.pagingDto) // Grid Row 가져올때 페이지정보 Setting
            })
        },
        // 신규 버튼 이벤트
        newBtn() {
            this.popupParam = {}

            // 팝업열기
            this.showDtlPopup = true
        },
        // Validation 체크
        isValidChk() {
            if (_.isEmpty(this.reqParam.brwsYm)) {
                this.showTcComAlert('조회년월을 선택해 주십시오.')
                return false
            }
            return true
        },
        // Grid ExcelDown
        excelDownBtn() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-max/resource/bas/pdm/svc-pol-mgmt-xls-dload',
                this.reqParam
            )
        },
        // 부가정책 그리드 데이터 선택 이벤트
        onCellDblClicked(grid, clickData) {
            // 그리드 선택 데이터
            if (clickData.dataRow == undefined) return

            this.popupParam = grid.getValues(clickData.itemIndex)

            // 팝업열기
            this.showDtlPopup = true
        },
    },
}
</script>
