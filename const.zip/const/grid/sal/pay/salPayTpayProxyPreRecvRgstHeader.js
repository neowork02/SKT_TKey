/*****************************************
 * 업무그룹명: 판매관리
 * 서브업무명: T수납대행관리
 * 설 명 : 판매관리-T수납대행 예수금등록 Grid 헤더
 * 작성자: P179234
 * 작성일: 2022.08.05
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'payDtm', // 처리일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyCd', // SKT대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', // SKT서브점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubNm', // SKT서브점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payReqNm', // 수납의뢰처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payReqPlcCd', // 수납의뢰처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mskCustNm', // 마스킹고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNm', // 고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mskSvcNum', // 마스킹개통번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNum', // 개통번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', // 서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payObjAmt', // 수납대상금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'settlWayCd', // SKT결제수단코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlWayNm', // SKT결제수단
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'revItmCd', // SKT매출항목코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'revItmNm', // SKT매출항목명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procUserId', // 처리사용자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procNm', // 처리사용자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payClCd', // 수납구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opDt', // 전문일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opTm', // 처리시간
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq', // 전문순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prprcYn', // 예수금여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wcktDealTypCd', // SKT청구거래유형코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1Nm', // 거래처구분1명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1', // 거래처구분코드1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'chk',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            styleName: 'multi-line-css',
            header: {
                text: '처리일자',
                showTooltip: false,
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT대리점코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT서브점코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sktSubNm',
            fieldName: 'sktSubNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT서브점명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payReqNm',
            fieldName: 'payReqNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납의뢰처명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payReqPlcCd',
            fieldName: 'payReqPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납의뢰처코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'mskCustNm',
            fieldName: 'mskCustNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '고객명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '고객명',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'mskSvcNum',
            fieldName: 'mskSvcNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통번호',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통번호',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payObjAmt',
            fieldName: 'payObjAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '수납대상금액',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'settlWayCd',
            fieldName: 'settlWayCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT결제수단코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'settlWayNm',
            fieldName: 'settlWayNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT결제수단',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'revItmCd',
            fieldName: 'revItmCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT매출항목코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'revItmNm',
            fieldName: 'revItmNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT매출항목',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'procUserId',
            fieldName: 'procUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리사용자ID',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'procNm',
            fieldName: 'procNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리사용자명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payClCd',
            fieldName: 'payClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납구분코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전문일자',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'opTm',
            fieldName: 'opTm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리시간',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전문순번',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'prprcYn',
            fieldName: 'prprcYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '예수금여부',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'wcktDealTypCd',
            fieldName: 'wcktDealTypCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT청구거래유형코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분코드1',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'dealcoClCd1Nm',
            fieldName: 'dealcoClCd1Nm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분1명',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
    ],
}
