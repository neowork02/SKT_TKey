import { ValueType } from 'realgrid'

export const DisIioSaleRtnMgmtDtl_GRID_HEADER = {
    fields: [
        {
            fieldName: 'inPlcNm',
            dataType: ValueType.TEXT, // 출고처
        },
        {
            fieldName: 'inSktCd',
            dataType: ValueType.TEXT, // 출고처매장코드
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, // 제조사
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'inPrac',
            dataType: ValueType.NUMBER, // 단가
        },
        {
            fieldName: 'amt',
            dataType: ValueType.NUMBER, // 금액
        },
        {
            fieldName: 'outMgmtNo',
            dataType: ValueType.TEXT, // 출고관리번호
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT, // 제조사코드
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.NUMBER, //수량
        },
        {
            fieldName: 'inPlcId',
            dataType: ValueType.TEXT, //입고처코드
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, //수정횟수
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'outSktCd',
            dataType: ValueType.TEXT, // 입고처매장코드
        },
        {
            fieldName: 'outPlcId',
            dataType: ValueType.TEXT, // 입고처코드
        },
        {
            fieldName: 'outPlcNm',
            dataType: ValueType.TEXT, // 입고처
        },
    ],
    columns: [
        {
            name: 'inSktCd',
            fieldName: 'inSktCd',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcId',
            fieldName: 'inPlcId',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcNm',
            fieldName: 'inPlcNm',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처',
                showTooltip: false,
            },
        },
        {
            name: 'outSktCd',
            fieldName: 'outSktCd',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcId',
            fieldName: 'outPlcId',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcNm',
            fieldName: 'outPlcNm',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'inPrac',
            fieldName: 'inPrac',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'amt',
            fieldName: 'amt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'outMgmtNo',
            fieldName: 'outMgmtNo',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            type: 'data',
            visible: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            type: 'data',
            visible: false,
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            type: 'data',
            visible: false,
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            type: 'data',
            visible: false,
        },
        {
            name: 'inPlcId',
            fieldName: 'inPlcId',
            type: 'data',
            visible: false,
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
        },
    ],
}
