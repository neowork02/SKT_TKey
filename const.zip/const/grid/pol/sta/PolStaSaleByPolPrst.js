import { ValueType } from 'realgrid'

export const GRID_POL_LIST = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'polTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polId',
            dataType: ValueType.TEXT,
        },
        /* {
            fieldName: 'polTs',
            dataType: ValueType.TEXT,
        },
        */
        {
            fieldName: 'polTsNm',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'polOperNm',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'polSubjNm',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'polNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDtm',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMddhhmmss',
        },
        {
            fieldName: 'aplyEndDtm',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMddhhmmss',
        },
        {
            fieldName: 'dpstSchdYm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktIctBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactIctBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktIctFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactIctFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktIctVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactIctVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktIctServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactIctServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktIctFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactIctFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictSum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsSum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gubun',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polTyp',
            dataType: ValueType.TEXT,
        },
        /*
        {
            fieldName: 'polOperCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polSubjCd',
            dataType: ValueType.TEXT,
        },
        
        {
            fieldName: 'polTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polGrpCd',
            dataType: ValueType.TEXT,
        },
        */
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polTypNm',
            fieldName: 'polTypNm',
            type: 'data',
            width: '140',
            header: {
                text: '정책유형',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polId',
            fieldName: 'polId',
            type: 'data',
            width: '100',
            header: {
                text: '정책ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polTsNm',
            fieldName: 'polTsNm',
            type: 'data',
            width: '60',
            header: {
                text: '차수',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        // {
        //     name: 'polOperNm',
        //     fieldName: 'polOperNm',
        //     type: 'data',
        //     width: '100',
        //     header: {
        //         text: '정책운영사',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     editable: false,
        // },
        {
            name: 'polSubjNm',
            fieldName: 'polSubjNm',
            type: 'data',
            width: '100',
            header: {
                text: '정책주관',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },

        {
            name: 'polNm',
            fieldName: 'polNm',
            type: 'data',
            width: '400',
            header: {
                text: '정책명칭',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'aplyStaDtm',
            fieldName: 'aplyStaDtm',
            type: 'data',
            width: '150',
            header: {
                text: '적용시작일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editable: false,
        },
        {
            name: 'aplyEndDtm',
            fieldName: 'aplyEndDtm',
            type: 'data',
            width: '150',
            header: {
                text: '적용종료일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editable: false,
        },
        {
            name: 'dpstSchdYm',
            fieldName: 'dpstSchdYm',
            type: 'data',
            width: '100',
            header: {
                text: '입금예정월',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'sktIctBase',
            fieldName: 'sktIctBase',
            type: 'data',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'mfactIctBase',
            fieldName: 'mfactIctBase',
            type: 'data',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        //그룹헤더 요금제정책 'sktIctFee', 'mfactIctFee'
        {
            name: 'sktIctFee',
            fieldName: 'sktIctFee',
            type: 'data',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'mfactIctFee',
            fieldName: 'mfactIctFee',
            type: 'data',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        //그룹헤더 VAS정책 'sktIctVas','mfactIctVas'
        {
            name: 'sktIctVas',
            fieldName: 'sktIctVas',
            type: 'data',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'mfactIctVas',
            fieldName: 'mfactIctVas',
            type: 'data',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        //그룹헤더 서비스별단가정책 'sktIctServ', 'mfactIctServ'
        {
            name: 'sktIctServ',
            fieldName: 'sktIctServ',
            type: 'data',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'mfactIctServ',
            fieldName: 'mfactIctServ',
            type: 'data',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        //그룹헤더 파일업로드정책 'sktIctFile','mfactIctFile'
        {
            name: 'sktIctFile',
            fieldName: 'sktIctFile',
            type: 'data',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'mfactIctFile',
            fieldName: 'mfactIctFile',
            type: 'data',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'ictSum',
            fieldName: 'ictSum',
            type: 'data',
            header: {
                text: '합계', //인센티브합계
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'ictCnt',
            fieldName: 'ictCnt',
            type: 'data',
            header: {
                text: '인센티브건수', //인센티브수
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsBase',
            fieldName: 'cmmsBase',
            type: 'data',
            header: {
                text: '기본단가',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsFee',
            fieldName: 'cmmsFee',
            type: 'data',
            header: {
                text: '요금제',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsVas',
            fieldName: 'cmmsVas',
            type: 'data',
            header: {
                text: '부가서비스',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsServ',
            fieldName: 'cmmsServ',
            type: 'data',
            header: {
                text: '서비스별',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsFile',
            fieldName: 'cmmsFile',
            type: 'data',
            header: {
                text: '파일업로드',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },

        {
            name: 'cmmsSum',
            fieldName: 'cmmsSum',
            type: 'data',
            header: {
                text: '수수료', //수수료합계
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsCnt',
            fieldName: 'cmmsCnt',
            type: 'data',
            header: {
                text: '수수료건수', //수수료건수
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'gubun',
            fieldName: 'gubun',
            type: 'data',
            width: '80',
            header: {
                text: '정책구분',
                showTooltip: false,
            },
            styleName: 'center-column',
        },
        {
            name: 'polTyp',
            fieldName: 'polTyp',
            type: 'data',
            width: '80',
            header: {
                text: '정책구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            visible: false,
        },
    ],

    layout: [
        'rowNum',
        'gubun',
        'polTypNm',
        'polId',
        'polTsNm',
        //'polOperNm',
        'polSubjNm',
        'polNm',
        'aplyStaDtm',
        'aplyEndDtm',
        'dpstSchdYm',
        {
            name: '기본단가',
            header: { visible: true, text: '기본단가' },
            direction: 'horizontal',
            items: ['sktIctBase', 'mfactIctBase'],
        },
        {
            name: '요금제',
            header: { visible: true, text: '요금제' },
            direction: 'horizontal',
            items: ['sktIctFee', 'mfactIctFee'],
        },
        {
            name: 'VAS',
            header: { visible: true, text: 'VAS' },
            direction: 'horizontal',
            items: ['sktIctVas', 'mfactIctVas'],
        },
        {
            name: '서비스별단가정책',
            header: { visible: true, text: '서비스별단가정책' },
            direction: 'horizontal',
            items: ['sktIctServ', 'mfactIctServ'],
        },
        {
            name: '파일업로드',
            header: { visible: true, text: '파일업로드' },
            direction: 'horizontal',
            items: ['sktIctFile', 'mfactIctFile'],
        },
        'ictSum',
        'ictCnt',
        {
            name: '수수료정책',
            header: { visible: true, text: '수수료정책' },
            direction: 'horizontal',
            items: ['cmmsBase', 'cmmsFee', 'cmmsVas', 'cmmsServ', 'cmmsFile'],
        },
        'cmmsSum',
        'cmmsCnt',
    ],
}

export const GRID_POL_DETAIL1 = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodDistbNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'newIct',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'newCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mnpIct',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mnpCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'chgIct',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'chgCnt',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prodDistbNm',
            fieldName: 'prodDistbNm',
            type: 'data',
            width: '80',
            header: {
                text: '상품분류',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '100',
            header: {
                text: '모델',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'petNm',
            fieldName: 'petNm',
            type: 'data',
            width: '80',
            header: {
                text: '팻네임',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'newIct',
            fieldName: 'newIct',
            type: 'data',
            header: {
                text: '금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'newCnt',
            fieldName: 'newCnt',
            type: 'data',
            header: {
                text: '건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'mnpIct',
            fieldName: 'mnpIct',
            type: 'data',
            header: {
                text: '금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'mnpCnt',
            fieldName: 'mnpCnt',
            type: 'data',
            header: {
                text: '건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'chgIct',
            fieldName: 'chgIct',
            type: 'data',
            header: {
                text: '금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'chgCnt',
            fieldName: 'chgCnt',
            type: 'data',
            header: {
                text: '건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],

    layout: [
        'prodDistbNm',
        'prodNm',
        'petNm',
        {
            name: '신규',
            header: { visible: true, text: '신규' },
            direction: 'horizontal',
            items: ['newCnt', 'newIct'],
        },
        {
            name: 'MNP',
            header: { visible: true, text: 'MNP' },
            direction: 'horizontal',
            items: ['mnpCnt', 'mnpIct'],
        },
        {
            name: '기변',
            header: { visible: true, text: '기변' },
            direction: 'horizontal',
            items: ['chgCnt', 'chgIct'],
        },
    ],
}

export const GRID_POL_DETAIL2 = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodDistbNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'newCms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'newCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mnpCms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mnpCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'chgCms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'chgCnt',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prodDistbNm',
            fieldName: 'prodDistbNm',
            type: 'data',
            width: '80',
            header: {
                text: '상품분류',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '100',
            header: {
                text: '모델',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'petNm',
            fieldName: 'petNm',
            type: 'data',
            width: '80',
            header: {
                text: '팻네임',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'newCms',
            fieldName: 'newCms',
            type: 'data',
            header: {
                text: '금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'newCnt',
            fieldName: 'newCnt',
            type: 'data',
            header: {
                text: '건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'mnpCms',
            fieldName: 'mnpCms',
            type: 'data',
            header: {
                text: '금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'mnpCnt',
            fieldName: 'mnpCnt',
            type: 'data',
            header: {
                text: '건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'chgCms',
            fieldName: 'chgCms',
            type: 'data',
            header: {
                text: '금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'chgCnt',
            fieldName: 'chgCnt',
            type: 'data',
            header: {
                text: '건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],

    layout: [
        'rowNum',
        'prodDistbNm',
        'prodNm',
        'petNm',
        {
            name: '신규',
            header: { visible: true, text: '신규' },
            direction: 'horizontal',
            items: ['newCnt', 'newCms'],
        },
        {
            name: 'MNP',
            header: { visible: true, text: 'MNP' },
            direction: 'horizontal',
            items: ['mnpCnt', 'mnpCms'],
        },
        {
            name: '기변',
            header: { visible: true, text: '기변' },
            direction: 'horizontal',
            items: ['chgCnt', 'chgCms'],
        },
    ],
}

export const GRID_SALE_LIST = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cntrctMgmtNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgHstCl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'iniSaleNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pkgSaleNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'svcDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'saleDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'uscanAcptDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'dfaxAcptDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'ukeyFcodeCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeyAgencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeySubCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeySubNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgUkeyChannelCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeyChnlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcChgrgId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcChgrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleOrg',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'salePlc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'salePlcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stlPlc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stlPlcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgr',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chrgrNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNm',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'frgClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNumView',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dsNetNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agrmtPrdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtlTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prepadeClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prepadeTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mdlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlCondNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'allotPrdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplPrcplnNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addSuplPrcplnNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addSuplSvcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addSuplPolNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixCrdtPrchsPrc',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'allotAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cashAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'agrmtAstamt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'agree',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'retentionAgrmtAstamt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsAdj',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'preDcAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tecoDcAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cardDcAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'freeclubDcAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'phoneSafeAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktIctBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactIctBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktIctFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactIctFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktIctVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactIctVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktIctServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactIctServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktIctFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactIctFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictSum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsSum',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'cntrctMgmtNum',
            fieldName: 'cntrctMgmtNum',
            type: 'data',
            width: '60',
            header: {
                text: '계약관리번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            width: '60',
            header: {
                text: '판매관리번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'gnrlSaleChgSeq',
            fieldName: 'gnrlSaleChgSeq',
            type: 'data',
            width: '60',
            header: {
                text: '변경순번',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleStCd',
            fieldName: 'saleStCd',
            type: 'data',
            width: '60',
            header: {
                text: '판매상태',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'svcTypCd',
            fieldName: 'svcTypCd',
            type: 'data',
            width: '60',
            header: {
                text: '개통유형',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleChgHstCl',
            fieldName: 'saleChgHstCl',
            type: 'data',
            width: '80',
            header: {
                text: '판매변경이력',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'iniSaleNo',
            fieldName: 'iniSaleNo',
            type: 'data',
            width: '80',
            header: {
                text: '원_일반판매번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'pkgSaleNo',
            fieldName: 'pkgSaleNo',
            type: 'data',
            width: '80',
            header: {
                text: '패키지주문번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            width: '80',
            header: {
                text: '판매변경일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            editable: false,
        },
        {
            name: 'svcDtm',
            fieldName: 'svcDtm',
            type: 'data',
            width: '80',
            header: {
                text: '개통일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            editable: false,
        },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            width: '80',
            header: {
                text: '변경일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            editable: false,
        },
        {
            name: 'uscanAcptDtm',
            fieldName: 'uscanAcptDtm',
            type: 'data',
            width: '80',
            header: {
                text: 'U-scan개통일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            editable: false,
        },
        {
            name: 'dfaxAcptDtm',
            fieldName: 'dfaxAcptDtm',
            type: 'data',
            width: '80',
            header: {
                text: 'fax접수일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            editable: false,
        },
        {
            name: 'ukeyFcodeCd',
            fieldName: 'ukeyFcodeCd',
            type: 'data',
            width: '80',
            header: {
                text: 'Swing\nF코드',
                styleName: 'multi-line-css',
            },
            styleName: 'center-column',
            editable: false,
        },
        /* 개통정보 그룹헤더 'ukeyAgencyCd', 'agencyNm','ukeySubCd','ukeySubNm','orgUkeyChannelCd','ukeyChnlNm','svcChgrgId','svcChgrgNm' */
        {
            name: 'ukeyAgencyCd',
            fieldName: 'ukeyAgencyCd',
            type: 'data',
            width: '80',
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            width: '80',
            header: {
                text: '대리점명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'ukeySubCd',
            fieldName: 'ukeySubCd',
            type: 'data',
            width: '80',
            header: {
                text: '서브점코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'ukeySubNm',
            fieldName: 'ukeySubNm',
            type: 'data',
            width: '80',
            header: {
                text: '서브점명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'orgUkeyChannelCd',
            fieldName: 'orgUkeyChannelCd',
            type: 'data',
            width: '80',
            header: {
                text: 'Swing채널코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'ukeyChnlNm',
            fieldName: 'ukeyChnlNm',
            type: 'data',
            width: '80',
            header: {
                text: 'Swing채널명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'svcChgrgId',
            fieldName: 'svcChgrgId',
            type: 'data',
            width: '80',
            header: {
                text: '개통담당자ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'svcChgrgNm',
            fieldName: 'svcChgrgNm',
            type: 'data',
            width: '80',
            header: {
                text: '개통담당자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        //판매처정보그룹헤더 'saleOrg','saleOrgNm','salePlc',  'salePlcNm', 'stlPlc','stlPlcNm','saleChrgr', 'chrgrNm','saleChgrgNm', 'saleChnlCd','saleChnlNm'
        {
            name: 'saleOrg',
            fieldName: 'saleOrg',
            type: 'data',
            width: '80',
            header: {
                text: '매출조직',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleOrgNm',
            fieldName: 'saleOrgNm',
            type: 'data',
            width: '80',
            header: {
                text: '매출조직명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'salePlc',
            fieldName: 'salePlc',
            type: 'data',
            width: '80',
            header: {
                text: '판매처코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'salePlcNm',
            fieldName: 'salePlcNm',
            type: 'data',
            width: '80',
            header: {
                text: '판매처명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'stlPlc',
            fieldName: 'stlPlc',
            type: 'data',
            width: '80',
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'stlPlcNm',
            fieldName: 'stlPlcNm',
            type: 'data',
            width: '80',
            header: {
                text: '정산처명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleChrgr',
            fieldName: 'saleChrgr',
            type: 'data',
            width: '80',
            header: {
                text: '영업담당자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'chrgrNm',
            fieldName: 'chrgrNm',
            type: 'data',
            width: '80',
            header: {
                text: '영업담당자명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleChgrgNm',
            fieldName: 'saleChgrgNm',
            type: 'data',
            width: '80',
            header: {
                text: '판매담당자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleChnlCd',
            fieldName: 'saleChnlCd',
            type: 'data',
            width: '80',
            header: {
                text: '영업채널코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleChnlNm',
            fieldName: 'saleChnlNm',
            type: 'data',
            width: '80',
            header: {
                text: '영업채널명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        // 고객정보 그룹헤더 'svcMgmtNum','saleAprvNum','custClNm','custNm',ageRngNm', 'frgClNm','svcNumView'
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            width: '80',
            header: {
                text: '서비스\n관리번호',
                styleName: 'multi-line-css',
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleAprvNum',
            fieldName: 'saleAprvNum',
            type: 'data',
            width: '80',
            header: {
                text: '영업승인번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'custClNm',
            fieldName: 'custClNm',
            type: 'data',
            width: '80',
            header: {
                text: '고객구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            width: '80',
            header: {
                text: '고객명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },

        {
            name: 'frgClNm',
            fieldName: 'frgClNm',
            type: 'data',
            width: '80',
            header: {
                text: '외국인구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'svcNumView',
            fieldName: 'svcNumView',
            type: 'data',
            width: '80',
            header: {
                text: '개통번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        //가입정보 그룹헤더 'dsNetNm', 'agrmtPrdNm','saleDtlTypNm','prepadeClNm','prepadeTypNm'
        {
            name: 'dsNetNm',
            fieldName: 'dsNetNm',
            type: 'data',
            width: '80',
            header: {
                text: '약정조건',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'agrmtPrdNm',
            fieldName: 'agrmtPrdNm',
            type: 'data',
            width: '80',
            header: {
                text: '약정기간',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleDtlTypNm',
            fieldName: 'saleDtlTypNm',
            type: 'data',
            width: '80',
            header: {
                text: '판매유형',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prepadeClNm',
            fieldName: 'prepadeClNm',
            type: 'data',
            width: '80',
            header: {
                text: '가입구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prepadeTypNm',
            fieldName: 'prepadeTypNm',
            type: 'data',
            width: '80',
            header: {
                text: '선후불유형',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '80',
            header: {
                text: '상품구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'mdlNm',
            fieldName: 'mdlNm',
            type: 'data',
            width: '80',
            header: {
                text: '상품모델',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '80',
            header: {
                text: '모델색상',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '80',
            header: {
                text: '상품일련번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'disClNm',
            fieldName: 'disClNm',
            type: 'data',
            width: '80',
            header: {
                text: '모델재고구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'settlCondNm',
            fieldName: 'settlCondNm',
            type: 'data',
            width: '80',
            header: {
                text: '모델결제조건',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'allotPrdNm',
            fieldName: 'allotPrdNm',
            type: 'data',
            width: '80',
            header: {
                text: '모델할부기간',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplPrcplnNm',
            fieldName: 'suplPrcplnNm',
            type: 'data',
            width: '100',
            header: {
                text: '요금제',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'addSuplPrcplnNm',
            fieldName: 'addSuplPrcplnNm',
            type: 'data',
            width: '100',
            header: {
                text: '부가요금제',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'addSuplSvcNm',
            fieldName: 'addSuplSvcNm',
            type: 'data',
            width: '100',
            header: {
                text: '부가서비스',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'addSuplPolNm',
            fieldName: 'addSuplPolNm',
            type: 'data',
            width: '100',
            header: {
                text: '부가정책',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'fixCrdtPrchsPrc',
            fieldName: 'fixCrdtPrchsPrc',
            type: 'data',
            header: {
                text: '확정여신매입가',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'allotAmt',
            fieldName: 'allotAmt',
            type: 'data',
            header: {
                text: '할부매출',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cashAmt',
            fieldName: 'cashAmt',
            type: 'data',
            header: {
                text: '현금매출',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'agrmtAstamt',
            fieldName: 'agrmtAstamt',
            type: 'data',
            header: {
                text: '고객지원금',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'agree',
            fieldName: 'agree',
            type: 'data',
            header: {
                text: '약정지원금',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'retentionAgrmtAstamt',
            fieldName: 'retentionAgrmtAstamt',
            type: 'data',
            header: {
                text: '대리점밴드',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsAdj',
            fieldName: 'cmmsAdj',
            type: 'data',
            header: {
                text: '프리할부선납',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        // 추가할인 그룹헤더 'preDcAmt','tecoDcAmt', 'cardDcAmt','freeclubDcAmt'
        {
            name: 'preDcAmt',
            fieldName: 'preDcAmt',
            type: 'data',
            header: {
                text: '착한폰기변LIGHT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'tecoDcAmt',
            fieldName: 'tecoDcAmt',
            type: 'data',
            header: {
                text: 'T-ECO',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cardDcAmt',
            fieldName: 'cardDcAmt',
            type: 'data',
            header: {
                text: '세이브카드',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'freeclubDcAmt',
            fieldName: 'freeclubDcAmt',
            type: 'data',
            header: {
                text: '프리클럽',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'phoneSafeAmt',
            fieldName: 'phoneSafeAmt',
            type: 'data',
            header: {
                text: '폰세이프금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        //'phoneSafeAmt', 'sktIctBase',
        //  'mfactIctBase', 'sktIctFee', 'mfactIctFee', 'sktIctVas','mfactIctVas',
        //    'sktIctServ', 'mfactIctServ','sktIctFile','mfactIctFile','ictSum',
        //그룹헤더 기본단가정책 'sktIctBase', 'mfactIctBase'
        {
            name: 'sktIctBase',
            fieldName: 'sktIctBase',
            type: 'data',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'mfactIctBase',
            fieldName: 'mfactIctBase',
            type: 'data',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        //그룹헤더 요금제정책 'sktIctFee', 'mfactIctFee'
        {
            name: 'sktIctFee',
            fieldName: 'sktIctFee',
            type: 'data',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'mfactIctFee',
            fieldName: 'mfactIctFee',
            type: 'data',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        //그룹헤더 VAS정책 'sktIctVas','mfactIctVas'
        {
            name: 'sktIctVas',
            fieldName: 'sktIctVas',
            type: 'data',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'mfactIctVas',
            fieldName: 'mfactIctVas',
            type: 'data',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        //그룹헤더 서비스별단가정책 'sktIctServ', 'mfactIctServ'
        {
            name: 'sktIctServ',
            fieldName: 'sktIctServ',
            type: 'data',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'mfactIctServ',
            fieldName: 'mfactIctServ',
            type: 'data',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        //그룹헤더 파일업로드정책 'sktIctFile','mfactIctFile'
        {
            name: 'sktIctFile',
            fieldName: 'sktIctFile',
            type: 'data',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'mfactIctFile',
            fieldName: 'mfactIctFile',
            type: 'data',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'ictSum',
            fieldName: 'ictSum',
            type: 'data',
            header: {
                text: '합계', //인센티브합계
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        //그룹헤더 판매수수료 'cmmsBase', 'cmmsFee', 'cmmsVas', 'cmmsServ', 'cmmsFile','cmmsSum'
        {
            name: 'cmmsBase',
            fieldName: 'cmmsBase',
            type: 'data',
            header: {
                text: '기본단가',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsFee',
            fieldName: 'cmmsFee',
            type: 'data',
            header: {
                text: '요금제',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsVas',
            fieldName: 'cmmsVas',
            type: 'data',
            header: {
                text: 'VAS',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsServ',
            fieldName: 'cmmsServ',
            type: 'data',
            header: {
                text: '서비스별단가',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsFile',
            fieldName: 'cmmsFile',
            type: 'data',
            header: {
                text: '파일업로드',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'cmmsSum',
            fieldName: 'cmmsSum',
            type: 'data',
            header: {
                text: '합계',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
    ],

    layout: [
        'rowNum',
        'cntrctMgmtNum',
        'gnrlSaleNo',
        'gnrlSaleChgSeq',
        'saleStCd',
        'svcTypCd',
        'saleChgHstCl',
        'iniSaleNo',
        'pkgSaleNo',
        'saleChgDtm',
        'svcDtm',
        'saleDtm',
        'uscanAcptDtm',
        'dfaxAcptDtm',
        'ukeyFcodeCd',
        {
            name: '개통정보',
            direction: 'horizontal',
            items: [
                'ukeyAgencyCd',
                'agencyNm',
                'ukeySubCd',
                'ukeySubNm',
                'orgUkeyChannelCd',
                'ukeyChnlNm',
                'svcChgrgId',
                'svcChgrgNm',
            ],
        },
        {
            name: '판매처정보',
            direction: 'horizontal',
            items: [
                'saleOrg',
                'saleOrgNm',
                'salePlc',
                'salePlcNm',
                'stlPlc',
                'stlPlcNm',
                'saleChrgr',
                'chrgrNm',
                'saleChgrgNm',
                'saleChnlCd',
                'saleChnlNm',
            ],
        },
        {
            name: '고객정보',
            direction: 'horizontal',
            items: [
                'svcMgmtNum',
                'saleAprvNum',
                'custClNm',
                'custNm',
                'frgClNm',
                'svcNumView',
            ],
        },
        {
            name: '가입정보',
            direction: 'horizontal',
            items: [
                'dsNetNm',
                'agrmtPrdNm',
                'saleDtlTypNm',
                'prepadeClNm',
                'prepadeTypNm',
            ],
        },
        'prodClNm',
        'mdlNm',
        'colorNm',
        'serNum',
        'disClNm',
        'settlCondNm',
        'allotPrdNm',
        'suplPrcplnNm',
        'addSuplPrcplnNm',
        'addSuplSvcNm',
        'addSuplPolNm',
        'fixCrdtPrchsPrc',
        'allotAmt',
        'cashAmt',
        'agrmtAstamt',
        'agree',
        'retentionAgrmtAstamt',
        'cmmsAdj',
        {
            name: '추가할인',
            direction: 'horizontal',
            items: ['preDcAmt', 'tecoDcAmt', 'cardDcAmt', 'freeclubDcAmt'],
        },
        'phoneSafeAmt',
        {
            name: '기본단가인센티브',
            direction: 'horizontal',
            items: ['sktIctBase', 'mfactIctBase'],
        },
        {
            name: '요금제인센티브',
            direction: 'horizontal',
            items: ['sktIctFee', 'mfactIctFee'],
        },
        {
            name: 'VAS인센티브',
            direction: 'horizontal',
            items: ['sktIctVas', 'mfactIctVas'],
        },
        {
            name: '서비스별인센티브',
            direction: 'horizontal',
            items: ['sktIctServ', 'mfactIctServ'],
        },
        {
            name: '파일업로드인센티브',
            direction: 'horizontal',
            items: ['sktIctFile', 'mfactIctFile'],
        },
        'ictSum',
        {
            name: '판매수수료',
            direction: 'horizontal',
            items: [
                'cmmsBase',
                'cmmsFee',
                'cmmsVas',
                'cmmsServ',
                'cmmsFile',
                'cmmsSum',
            ],
        },
    ],
}
