/*****************************************
* 업무 그룹명 : ADMIN>기준정보 Swing I/F관리
* 서브 업무명 : 기준정보 Swing I/F관리
* 설 명 : 기준정보 Swing I/F관리 Grid 헤더 정보
* 작 성 자 : 이호준
* 작 성 일 : 2022.08.19
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 이호준  / 2022.08.19
* 변경사유/내역 : 
* ---------------------------------------
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const PROD_CODE_GRID_HEADER = {
    fields: [
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, // 번호
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'prodId',
            dataType: ValueType.TEXT, // 상품ID
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'wrcellClCd',
            dataType: ValueType.TEXT, // 유무선코드
        },
        {
            fieldName: 'wrcellclNm',
            dataType: ValueType.TEXT, // 유무선구분
        },
        {
            fieldName: 'svcProdCd',
            dataType: ValueType.TEXT, // 상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
        {
            fieldName: 'prodStCd',
            dataType: ValueType.TEXT, // 상품상태
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT, // 출시일
        },
        {
            fieldName: 'scrbStopDt',
            dataType: ValueType.TEXT, // 가입중단일
        },
        {
            fieldName: 'wdrlDt',
            dataType: ValueType.TEXT, // 퇴출일
        },
        {
            fieldName: 'combProdYn',
            dataType: ValueType.TEXT, // 결합상품
        },
        {
            fieldName: 'aplyYn',
            dataType: ValueType.TEXT, // 반영여부
        },
        {
            fieldName: 'exist',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'existNm',
            dataType: ValueType.TEXT, // 신규수정구분
        },
        {
            fieldName: 'basFeeAmt',
            dataType: ValueType.TEXT, // 기본료
        },
    ],

    columns: [
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '번호',
            },
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
            },
        },
        {
            name: 'prodId',
            fieldName: 'prodId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품ID',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styleName: 'left-column',
            width: 130,
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '상품명',
            },
        },
        {
            name: 'wrcellClCd',
            fieldName: 'wrcellClCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '유무선구분코드',
            },
        },
        {
            name: 'wrcellclNm',
            fieldName: 'wrcellclNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '유무선구분',
            },
        },
        {
            name: 'svcProdCd',
            fieldName: 'svcProdCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분코드',
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분명',
            },
        },
        {
            name: 'prodStCd',
            fieldName: 'prodStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품상태',
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출시일',
            },
        },
        {
            name: 'scrbStopDt',
            fieldName: 'scrbStopDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '가입중단일',
            },
        },
        {
            name: 'wdrlDt',
            fieldName: 'wdrlDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '퇴출일',
            },
        },
        {
            name: 'combProdYn',
            fieldName: 'combProdYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '결합상품',
            },
        },
        {
            name: 'aplyYn',
            fieldName: 'aplyYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반영여부',
            },
        },
        {
            name: 'exist',
            fieldName: 'exist',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '신규수정구분코드',
            },
        },
        {
            name: 'existNm',
            fieldName: 'existNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구분',
            },
        },
        {
            name: 'basFeeAmt',
            fieldName: 'basFeeAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '기본료',
            },
        },
    ],

    layout: [],
}

export const MDL_DMG_GRID_HEADER = {
    fields: [
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, // 번호
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT, // 생산업체코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 단말기모델명
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, // 상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 단말기 모델코드
        },
        {
            fieldName: 'linkColorCnt',
            dataType: ValueType.TEXT, // 연결색상건수
        },
        {
            fieldName: 'linkColorCd',
            dataType: ValueType.TEXT, // 연결색상코드
        },
        {
            fieldName: 'linkColorNm',
            dataType: ValueType.TEXT, // 연결색상명
        },
        {
            fieldName: 'dstrbEqpYn',
            dataType: ValueType.TEXT, // 유통단말기여부
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT, // 출시일
        },
        {
            fieldName: 'endDt',
            dataType: ValueType.TEXT, // 단종일
        },
        {
            fieldName: 'aplyYn',
            dataType: ValueType.TEXT, // 반영여부
        },
        {
            fieldName: 'exist',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'existNm',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'esimEqpYn',
            dataType: ValueType.TEXT, // eSIM 모델여부
        },
        {
            fieldName: 'dualSimEqpYn',
            dataType: ValueType.TEXT, // 듀얼심 단말여부
        },
        {
            fieldName: 'rgstClCd',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT, // 구분
        },
    ],
    columns: [
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '번호',
            },
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
            },
        },
        {
            name: 'mfactCd',
            fieldName: 'mfactCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '생산업체코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            styleName: 'left-column',
            width: 180,
            header: {
                text: '단말기모델명',
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분명',
            },
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기모델코드',
            },
        },
        {
            name: 'linkColorCnt',
            fieldName: 'linkColorCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '연결색상건수',
            },
        },
        {
            name: 'linkColorCd',
            fieldName: 'linkColorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '연결색상코드',
            },
        },
        {
            name: 'linkColorNm',
            fieldName: 'linkColorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '연결색상명',
            },
        },
        {
            name: 'dstrbEqpYn',
            fieldName: 'dstrbEqpYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '유통단말기여부',
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출시일',
            },
        },
        {
            name: 'endDt',
            fieldName: 'endDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단종일',
            },
        },
        {
            name: 'aplyYn',
            fieldName: 'aplyYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반영여부',
            },
        },
        {
            name: 'exist',
            fieldName: 'exist',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '신규수정구분코드',
            },
        },
        {
            name: 'existNm',
            fieldName: 'existNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구분',
            },
        },
        {
            name: 'esimEqpYn',
            fieldName: 'esimEqpYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'eSIM모델여부',
            },
        },
        {
            name: 'dualSimEqpYn',
            fieldName: 'dualSimEqpYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '듀얼심단말여부',
            },
        },
        {
            name: 'rgstClCd',
            fieldName: 'rgstClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록구분코드',
            },
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분여부',
            },
        },
    ],
    layout: [],
}

export const SKT_ID_GRID_HEADER = {
    fields: [
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, // 번호
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'subOrgCd',
            dataType: ValueType.TEXT, // 서브조직코드
        },
        {
            fieldName: 'loginUserId',
            dataType: ValueType.TEXT, // 로그인 ID
        },
        {
            fieldName: 'sktIdNm',
            dataType: ValueType.TEXT, // SKT ID명
        },
        {
            fieldName: 'sktId',
            dataType: ValueType.TEXT, // SKT ID
        },
        {
            fieldName: 'aplyYn',
            dataType: ValueType.TEXT, // 반영여부
        },
    ],
    columns: [
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '번호',
            },
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직코드',
            },
        },
        {
            name: 'subOrgCd',
            fieldName: 'subOrgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서브조직코드',
            },
        },
        {
            name: 'loginUserId',
            fieldName: 'loginUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '로그인 ID',
            },
        },
        {
            name: 'sktIdNm',
            fieldName: 'sktIdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT ID명',
            },
        },
        {
            name: 'sktId',
            fieldName: 'sktId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT ID',
            },
        },
        {
            name: 'aplyYn',
            fieldName: 'aplyYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반영여부',
            },
        },
    ],
    layout: [],
}
