<template>
    <div class="content">
        <h1>BO 매출/입금 정산관리</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onReset"
                    :objAuth="objAuth"
                    :disabled="button.disabled.reset"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="objAuth"
                    :disabled="button.disabled.search"
                    >조회</TCComButton
                >
                <!-- <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave"
                    :objAuth="objAuth"
                    :disabled="button.disabled.save"
                    >저장</TCComButton
                > -->
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="조회구분"
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        :eRequired="true"
                        :itemList="searchClCdCombo"
                        v-model="searchParams.searchClCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="조회일자"
                        calType="DP"
                        :eRequired="true"
                        v-model="searchParams.searchYmd"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchParams.searchOrgNm"
                        :codeVal.sync="searchParams.searchOrgCd"
                        labelName="조직"
                        placeholder="선택해주세요"
                        :eRequired="true"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="boSearchOrgNmDisable"
                        @appendIconClick="onOrgTreeIconClick"
                        @input="onOrgTreeInput"
                    />
                    <BasBcoOrgTreesPopup
                        v-if="showBcoOrgTrees"
                        :parentParam="searchParams"
                        :rows="resultOrgTreeRows"
                        :dialogShow.sync="showBcoOrgTrees"
                        @confirm="onOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <!-- 쿼리에서는 실제로 매출구분을 사용하지 않음 -->
                    <TCComComboBox
                        labelName="매출구분"
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        :itemList="[
                            { commCdVal: '01', commCdValNm: 'T판매' },
                            { commCdVal: '02', commCdValNm: '일반상품판매' },
                        ]"
                        :disabled="boSearchSaleClCdDisable"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-model="searchParams.searchSaleClCd"
                    ></TCComComboBox>
                </div>
                <!-- <div class="formitem div4"></div> -->
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="수납구분"
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        :itemList="[
                            { commCdVal: 'PM06', commCdValNm: 'PG' },
                            { commCdVal: 'PM01', commCdValNm: '현금' },
                        ]"
                        :disabled="boSearchPayClCdDisable"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-model="searchParams.searchPayClCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <!-- BO매출일 경우입금여부를 사용하지 않음 -->
                    <TCComComboBox
                        :labelName="searchDpstYnLabel"
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        :itemList="SearchDpstYnCombo"
                        :disabled="boSearchDpstYnDisable"
                        v-model="searchParams.searchDpstYn"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="검색대상"
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        :itemList="searchObjCombo"
                        v-model="searchParams.searchObjClCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="searchParams.searchObjKey"
                        :objAuth="this.objAuth"
                    ></TCComInput>
                </div>
            </div>
        </div>
        <!-- //Search_div -->

        <!-- gridWrap -->
        <div class="gridWrap">
            <TCComTab
                :tab.sync="tab.tabSync1"
                :items="['boTab', 'pgTab']"
                :itemName="['BO매출 관리', 'PG(퍼스트페이) 입금']"
                @change="onActiveTabClick"
                sliderSize="8"
            >
                <template #boTab>
                    <TCRealGridHeader
                        id="gridHeaderBo"
                        ref="gridHeaderBo"
                        :gridObj="gridObjBo"
                        gridTitle="BO매출 관리"
                        :isPageRows="true"
                        :isNextPage="false"
                        :isPageCnt="true"
                        :isExceldown="true"
                        @excelDownBtn="exportExcelDown"
                    />
                    <TCRealGrid
                        id="gridBo"
                        ref="gridBo"
                        :fields="view.fieldsBo"
                        :columns="view.columnsBo"
                        :styles="gridStyle"
                    />
                    <TCComPaging
                        :totalPage="gridBoData.totalPage"
                        :gridObj="gridObjBo"
                        :apiFunc="getBoSaleList"
                        :rowCnt="rowCntBo"
                        @input="chgRowCntBo"
                    />
                </template>
                <template #pgTab>
                    <TCRealGridHeader
                        id="gridHeaderPg"
                        ref="gridHeaderPg"
                        :gridObj="gridObjPg"
                        gridTitle="PG(퍼스트페이) 입금"
                        :isExceldown="true"
                        :isExcelup="true"
                        :isPageRows="true"
                        :isNextPage="false"
                        :isPageCnt="true"
                        @excelDownBtn="exportExcelDown"
                        @excelUploadBtn="excelUploadPopup"
                    />
                    <TCRealGrid
                        id="gridPg"
                        ref="gridPg"
                        :fields="view.fieldsPg"
                        :columns="view.columnsPg"
                        :styles="gridStyle"
                        @hook:mounted="tabGridMounted"
                    />
                    <TCComPaging
                        :totalPage="gridPgData.totalPage"
                        :gridObj="gridObjPg"
                        :apiFunc="getPgDpstList"
                        :rowCnt="rowCntPg"
                        @input="chgRowCntPg"
                    />
                </template>
            </TCComTab>
        </div>
        <!-- //gridWrap -->

        <!-- 엑셀업로드 팝업 -->
        <AccPacBoSaleDpstAccMgmtExcelPopup
            v-if="showBoolExcelPopup === true"
            ref="popup"
            :dialogShow.sync="showBoolExcelPopup"
        />
    </div>
</template>

<script>
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
import pacApi from '@/api/biz/acc/pac'
import { CommonUtil, CommonGrid } from '@/utils'
import BoSaleDpstCode from '@/components/biz/AccPacBoSaleDpstAccMgmtCode'
import AccPacBoSaleDpstAccMgmtExcelPopup from '@/views/biz/acc/pac/AccPacBoSaleDpstAccMgmtExcelPopup'
import { GRID_HEADER } from '@/const/grid/acc/pac/accPacBoSaleDpstAccMgmtGrid'

//  내부조직팝업(전체)
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
import basBcoOrgTreesApi from '@/api/biz/bas/bco/basBcoOrgTrees'
//  내부조직팝업(전체)

export default {
    name: 'AccPacBoSaleDpstAccMgmt',
    title: 'BO 매출/입금 정산관리',
    mixins: [BoSaleDpstCode, CommonMixin],
    components: {
        AccPacBoSaleDpstAccMgmtExcelPopup,
        BasBcoOrgTreesPopup,
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            showBoolExcelPopup: false,
            listBo: [],
            listPg: [],
            gridObjBo: {},
            gridObjPg: {},
            gridHeaderObjBo: {},
            gridHeaderObjPg: {},
            gridBoData: this.gridSetDataBo(),
            gridPgData: this.gridSetDataPg(),
            rowCntBo: 15,
            rowCntPg: 15,
            tab: {
                nowIndex: 0,
                tabSync1: 0,
            },
            button: {
                disabled: {
                    reset: false,
                    search: false,
                    // save: false,
                },
            },
            /*그리드 스타일*/
            gridStyle: {
                height: '300px', //그리드 높이 조절
            },
            searchClCdArr: ['1', '0'],
            searchParams: {
                searchPageType: 'BO-TAB',
                searchYmd: [
                    moment(new Date()).format('YYYY-MM-DD'),
                    moment(new Date()).format('YYYY-MM-DD'),
                ],
                searchCoClOrgCd: '',
                searchClCd: '1',
                searchStartYmd: moment(new Date()).format('YYYY-MM-DD'),
                searchEndYmd: moment(new Date()).format('YYYY-MM-DD'),
                searchOrgCd: '',
                searchOrgNm: '',
                searchOrgLvl: '',
                searchSaleClCd: '',
                searchPayClCd: '',
                searchDpstYn: '0',
                searchObjClCd: '0',
                searchObjKey: '',
                pageSize: 15,
                pageNum: 1,
            },

            showAlertBool: false,
            alertBodyText: '',

            //  내부조직팝업(전체)
            showBcoOrgTrees: false,
            resultOrgTreeRows: [],
            //  내부조직팝업(전체)
        }
    },
    watch: {
        'searchParams.searchClCd'(newVal) {
            this.searchClCdArr[this.tab.nowIndex] = newVal
        },
    },
    mounted() {
        //  bo매출관리 / pg입금 Tab선택에 따른 Control
        this.searchClCdCombo = this.boSearchClCd /* 조회구분 */
        this.searchObjCombo = this.boSearchObjClCd /* 검색대상 */
        this.SearchDpstYnCombo = this.boSearchDpstYn /* 입금여부 */
        this.searchDpstYnLabel = '입금여부'
        this.boSearchClCdVisible = false
        this.boSearchSaleClCdDisable = true //매출구분은 실제로 사용안되는 조회조건임
        this.boSearchPayClCdDisable = false
        this.boSearchOrgNmDisable = false
        this.button.disabled.reset = false
        this.button.disabled.search = false
        this.button.disabled.save = false

        console.log('orgInfo', this.orgInfo) //조직정보

        this.initGrid()
    },
    methods: {
        /* 그리드 설정 */
        initGrid() {
            this.gridObjBo = this.$refs.gridBo
            this.gridHeaderObjBo = this.$refs.gridHeaderBo

            this.gridObjBo.setGridState(false)
            // this.gridObjBo.gridView.setRowIndicator({
            //     visible: true,
            //     headText: '번호',
            // })
            this.gridObjBo.gridView.displayOptions.selectionStyle = 'rows'
        },
        //초기화버튼 클릭
        onReset() {
            console.log('초기화 함수호출')
            CommonUtil.clearPage(this.$router) // 초기화 함수
        },
        // 내부조직팝업(전체) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(전체) 팝업 오픈
        getOrgTreeList() {
            basBcoOrgTreesApi.getOrgTreeList(this.searchParams).then((res) => {
                console.log('getOrgTreeList then : ', res)
                // 검색된 내부조직팝업(전체) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(전체) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(전체) 팝업 오픈
                if (res.length === 1) {
                    this.searchParams.searchOrgCd = _.get(res[0], 'orgCd')
                    this.searchParams.searchOrgNm = _.get(res[0], 'orgNm')
                    this.searchParams.searchOrgLvl = _.get(res[0], 'orgLvl')
                } else {
                    this.resultOrgTreeRows = res
                    this.showBcoOrgTrees = true
                }
            })
        },
        // 내부조직팝업(전체) TextField 돋보기 Icon 이벤트 처리
        onOrgTreeIconClick() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이 아니면 내부조직팝업(전체) 정보 조회
            // 그 이외는 내부조직팝업(전체) 팝업 오픈
            if (!_.isEmpty(this.searchParams.orgNm)) {
                this.getOrgTreeList()
            } else {
                this.showBcoOrgTrees = true
            }
        },
        // 내부조직팝업(전체) TextField Input 이벤트 처리
        onOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(전체) 코드 초기화
            this.searchParams.searchOrgCd = ''
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParams.searchOrgCd = _.get(retrunData, 'orgCd')
            this.searchParams.searchOrgNm = _.get(retrunData, 'orgNm')
            this.searchParams.searchOrgLvl = _.get(retrunData, 'orgLvl')
        },
        //  내부조직팝업(전체)팝업

        setParamJson() {
            this.paramJson = _.cloneDeep(this.searchParams)

            // 조회일자 세팅
            if (!_.isEmpty(this.paramJson.searchYmd)) {
                this.paramJson.searchStartYmd = this.paramJson.searchYmd[0]
                this.paramJson.searchEndYmd = this.paramJson.searchYmd[1]
                if (!_.isEmpty(this.paramJson.searchStartYmd)) {
                    this.paramJson.searchStartYmd =
                        this.paramJson.searchStartYmd.replace(/-/g, '')
                }
                if (!_.isEmpty(this.paramJson.searchEndYmd)) {
                    this.paramJson.searchEndYmd =
                        this.paramJson.searchEndYmd.replace(/-/g, '')
                }
            }

            // 조회일자 searchYmd 배열 제거
            delete this.paramJson['searchYmd']

            return this.paramJson
        },
        onSearchValidate() {
            if (_.isEmpty(this.searchParams.searchClCd)) {
                this.showTcComAlert('조회구분을 선택하십시오.')
                return false
            }

            if (
                _.isEmpty(this.searchParams.searchStartYmd) ||
                _.isEmpty(this.searchParams.searchEndYmd)
            ) {
                this.showTcComAlert('조회일자를 선택하십시오.')
                return false
            }

            if (this.tab.nowIndex == 0) {
                if (_.isEmpty(this.searchParams.searchOrgCd)) {
                    this.showTcComAlert('조직을 선택하십시오.')
                    return false
                }
            }

            return true
        },
        onSearch() {
            // 조회조건 Validation 체크
            if (this.onSearchValidate() == false) {
                return
            }

            //  회사구분조직코드, Login 사용자ID
            this.searchParams.searchCoClOrgCd = this.orgInfo.orgCdLvl0

            // this.gridBoData.totalPage = 0
            // this.gridPgData.totalPage = 0
            this.searchParams.pageNum = 1

            if (this.tab.nowIndex == 0) {
                this.searchParams.pageSize = this.rowCntBo
                this.getBoSaleList()
            } else if (this.tab.nowIndex == 1) {
                this.searchParams.pageSize = this.rowCntPg
                this.getPgDpstList()
            }
        },
        async getBoSaleList() {
            await pacApi
                .getAccPacBoSaleDpstAccMgmtList(this.setParamJson())
                .then((resultData) => {
                    this.gridObjBo.setRows(resultData.gridList)
                    this.gridObjBo.setGridIndicator(resultData.pagingVo)

                    this.gridBoData = this.gridSetDataBo()
                    this.gridBoData.totalPage = resultData.pagingVo.totalPageCnt // 총페이지수
                    this.gridHeaderObjBo.setPageCount(resultData.pagingVo)
                })
        },
        async getPgDpstList() {
            await pacApi
                .getAccPacBoSaleDpstAccMgmtList(this.setParamJson())
                .then((resultData) => {
                    this.gridObjPg.setRows(resultData.gridList)
                    this.gridObjPg.setGridIndicator(resultData.pagingVo) //순번이 필요한경우 계산하는 함수

                    this.gridPgData = this.gridSetDataPg()
                    this.gridPgData.totalPage = resultData.pagingVo.totalPageCnt // 총페이지수
                    this.gridHeaderObjPg.setPageCount(resultData.pagingVo)
                })
        },
        // onSave() {},
        exportExcelDown: function () {
            // 조회조건 Validation 체크
            if (this.onSearchValidate() == false) {
                return
            }

            var listCount = 0
            if (this.tab.nowIndex == 0) {
                listCount = this.gridObjBo.dataProvider.getRowCount()
            } else {
                listCount = this.gridObjPg.dataProvider.getRowCount()
            }

            if (listCount == 0) {
                this.showTcComAlert('출력할 데이터가 없습니다.')
                return
            }

            pacApi.downloadExcel(this.setParamJson()).then(() => {
                this.showTcComAlert('엑셀파일이 다운로드되었습니다.')
            })
        },
        onActiveTabClick(tabIndex) {
            this.tab.nowIndex = tabIndex
            this.searchParams.searchClCd = this.searchClCdArr[tabIndex]
            this.button.disabled.reset = false
            this.button.disabled.search = false

            if (tabIndex == 0) {
                this.searchParams.searchPageType = 'BO-TAB'
                this.searchObjCombo = this.boSearchObjClCd
                this.searchClCdCombo = this.boSearchClCd
                this.SearchDpstYnCombo = this.boSearchDpstYn
                this.searchDpstYnLabel = '입금여부'
                this.boSearchSaleClCdDisable = false
                this.boSearchPayClCdDisable = false
                this.boSearchOrgNmDisable = false
                this.boSearchDpstYnDisable = true
                this.button.disabled.save = true
            } else if (tabIndex == 1) {
                this.searchParams.searchPageType = 'PG-TAB'
                this.searchObjCombo = this.pgSearchObjClCd
                this.searchClCdCombo = this.pgSearchClCd
                this.SearchDpstYnCombo = this.pgSearchDpstYn
                this.searchDpstYnLabel = '결제구분'
                this.boSearchSaleClCdDisable = true
                this.boSearchPayClCdDisable = true
                this.boSearchOrgNmDisable = true
                this.boSearchDpstYnDisable = false
                this.button.disabled.save = false
            }
        },
        tabGridMounted() {
            this.gridObjPg = this.$refs.gridPg
            this.gridHeaderObjPg = this.$refs.gridHeaderPg
            this.gridObjPg.setGridState(false)

            // this.gridObjPg.gridView.setRowIndicator({
            //     visible: true,
            //     headText: '번호',
            // })
            this.gridObjPg.gridView.displayOptions.selectionStyle = 'rows'
        },
        excelUploadPopup() {
            this.showBoolExcelPopup = true
        },
        getRefsObj(namespace) {
            return this.$refs[namespace]
        },
        gridSetDataBo() {
            return new CommonGrid(0, this.rowCntBo, '', '')
        },
        gridSetDataPg() {
            return new CommonGrid(0, this.rowCntPg, '', '')
        },
        //페이지 표시 행의수 변경처리
        chgRowCntBo(val) {
            this.rowCntBo = val
        },
        chgRowCntPg(val) {
            this.rowCntPg = val
        },
    },
}
</script>

<style scoped>
.grid {
    height: 330px;
}
</style>
