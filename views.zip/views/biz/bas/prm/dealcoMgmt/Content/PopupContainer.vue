<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">
                    {{ title }}
                </p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Top BTN -->
                    <ul class="btn_area top pop">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :disabled="isDealStatus1"
                                @click="updateMgmtDealStatus"
                                >거래상태변경</TCComButton
                            >
                            <DealStatusPopup
                                v-if="showDealStatusPopup"
                                :parentParam="searchParam"
                                :rows="resultDealStatusRows"
                                :dialogShow.sync="showDealStatusPopup"
                            />
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                @click="btn_select_Onclick"
                                >영업담당자변경</TCComButton
                            >
                            <BasBcoUserSaleChrgrsPopup
                                v-if="showBcoSaleChrgr"
                                :parentParam="userSaleParam"
                                :rows="resultSaleChrgrRows"
                                :dialogShow.sync="showBcoSaleChrgr"
                                @confirm="anconSaleChrgrReturnData"
                            />
                            <NewEffStaDtmPopup
                                v-if="showNewEffStaDtm"
                                :rows="resultNewEffStaDtmRows"
                                :dialogShow.sync="showNewEffStaDtm"
                            />
                        </li>
                    </ul>
                    <!-- // Top BTN -->
                    <!-- 신규정보 -->
                    <NewInfoContainer />

                    <!-- 기본정보 -->
                    <StrdInfoContainer />

                    <!-- 추가정보 -->
                    <EtcAddInfoContainer />

                    <!-- 사업자정보 -->
                    <BizRgstInfoContainer />

                    <!-- 계좌정보 -->
                    <AcntInfoContainer />

                    <!-- 담보정보 -->
                    <CltInfoContainer />

                    <!-- 배송지정보 -->
                    <DlvDealcoInfoContainer />

                    <!-- Bottom BTN Group -->
                    <!-- Bottom -->
                    <!--                    <BottomContainer />-->
                    <div class="btn_area_bottom">
                        <TCComButton
                            v-if="isSave"
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="save"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dealcoMgmt/helpers'
import CommonMixin from '@/mixins'
import _ from 'lodash'

//====================사용자팝업====================
import BasBcoUserSaleChrgrsPopup from '@/components/common/BasBcoUserSaleChrgrsPopup'
//====================//사용자팝업====================

//====================사용자팝업====================
import NewEffStaDtmPopup from './Detail/NewEffStaDtmPopupContainer'
//====================//사용자팝업====================

import DealStatusPopup from './Detail/DealStatusPopupContainer'
//==================== 상세정보 ====================
import NewInfoContainer from './Detail/NewInfoContainer.vue' // 기본정보
import StrdInfoContainer from './Detail/StrdInfoContainer.vue' // 기준정보
import EtcAddInfoContainer from './Detail/EtcAddInfoContainer.vue' // 물류창고/직영점/하부망 추가정보
import BizRgstInfoContainer from './Detail/BizRgstInfoContainer.vue' // 사업자등록정보
import AcntInfoContainer from './Detail/AcntInfoContainer.vue' // 계좌정보
import CltInfoContainer from './Detail/CltInfoContainer.vue' // 담보
import DlvDealcoInfoContainer from './Detail/DlvDealcoInfoContainer.vue'
import CommonUtil from '@/utils/CommonUtil'
import { msgTxt } from '@/const/msg.Properties'
import moment from 'moment'
// import { CommonMsg } from '@/utils'

//==================== //상세정보 ====================

export default {
    name: 'PopupContainer',
    components: {
        NewInfoContainer, // 기본정보
        StrdInfoContainer, // 기준정보
        EtcAddInfoContainer, // 물류창고/직영점/하부망 추가정보
        BizRgstInfoContainer, // 사업자등록정보
        AcntInfoContainer, // 계좌정보
        CltInfoContainer, // 담보
        DlvDealcoInfoContainer, // 배송지
        DealStatusPopup, // 거래상태변경
        BasBcoUserSaleChrgrsPopup, // 사용자팝업
        NewEffStaDtmPopup,
    },
    mixins: [CommonMixin],
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            showAddressRgst: false,

            //====================거래상태변경====================
            showDealStatusPopup: false,
            searchParam: {
                dealcoCd: '', // 거래처코드
                normalYn: '', // 거래정상
                payStopYn: '', // 수납정지
                outStopYn: '', // 출고정지
                saleStopYn: '', // 판매정지
                sttlEndYn: '', // 정산정지
                drwStopYn: '', // 출금정지
                ifYn: '',
                sktAgencyCd: '',
                sktSubCd: '',
                sktChnlCd: '',
                hstSeq: '',
            },
            resultDealStatusRows: [],
            //====================//거래상태변경==================
            isDealStatus1: true,
            title: '',
            gridStyle: {
                height: '170px', //그리드 높이 조절
            },
            dealcoClList: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처구분
            isSave: true,
            suType: 'save',
            earvYn: 'N',
            isSlCmYn: '9', // 예금주 검증결과
            isSlCmChk: '9', // 예금주 검증완료
            custEditYn: '0',
            dealcoClCd1: '',
            dealcoClCd2: '',
            dealcoClCd3: '',
            isCheckEarv: false,
            //====================사용자팝업(영업담당자)관련======================
            showBcoSaleChrgr: false,
            searchSaleChrgrParam: {},
            userSaleParam: {
                orgCd: '',
                orgLvl: '',
                orgNm: '',
            },
            resultSaleChrgrRows: [],
            //================================================================
            // =========================적용시작일자팝업=========================
            showNewEffStaDtm: false,
            resultNewEffStaDtmRows: [],
            //================================================================
        }
    },
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        _earvImsi3: {
            get() {
                return this.earvImsi3
            },
        },
        _earvImsi4: {
            get() {
                return this.earvImsi4
            },
        },
        _addMgmtDealCoImsi: {
            get() {
                return this.addMgmtDealCoImsi
            },
        },
        _newEffStaDtm: {
            get() {
                return this.newEffStaDtmParam
            },
        },
        initParam: {
            get() {
                return this.initParams
            },
        },
        reqParam: {
            get() {
                return this.reqParams
            },
        },
        dealcoClList1: {
            get() {
                return this.dealcoClList
            },
        },
        initList1: {
            get() {
                return this.initList
            },
        },
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
        ////////////////// 공통코드 조회
        dealCoGrp: {
            get() {
                return this.DEAL_CO_GRP // 거래처그룹
            },
        },
        zbasC00240: {
            get() {
                return this.ZBAS_C_00240 // 거래처구분
            },
        },
        zbasC00510: {
            get() {
                return this.ZBAS_C_00510 // 거래처유형 (판매점구분)
            },
        },
        zbasC00570: {
            get() {
                return this.ZBAS_C_00570 // 거래처유형 (직영점구분)
            },
        },
        zbasC00530: {
            get() {
                return this.ZBAS_C_00530 // 거래처분류
            },
        },
        zbasC00590: {
            get() {
                return this.ZBAS_C_00590 // 거래처분류 (직영점2차점 거래처분류)
            },
        },
        zbasC00110: {
            get() {
                return this.ZBAS_C_00110 // 전자결재 진행여부
            },
        },
        zbasC00130: {
            get() {
                return this.ZBAS_C_00130 // 전자결재 진행여부
            },
        },
        zbasC00120: {
            get() {
                return this.ZBAS_C_00120 // 전자결재 진행여부
            },
        },
        zbasC00400: {
            get() {
                return this.ZBAS_C_00400 //
            },
        },
        zbasC00710: {
            get() {
                return this.ZBAS_C_00710 //
            },
        },
        zbasC00230: {
            get() {
                return this.ZBAS_C_00230 //
            },
        },
        spClsBizClCd: {
            get() {
                return this.SP_CLS_BIZ_CL_CD // 전자결재 진행여부
            },
        },
        comYn: {
            get() {
                return this.COM_YN // 전자결재 진행여부
            },
        },
        emailAcc: {
            get() {
                return this.EMAIL_ACC // 이메일
            },
        },
        taxPrdCd: {
            get() {
                return this.TAX_PRD_CD
            },
        },
        ////////////////// 공통코드 조회

        newInfoData1: {
            get() {
                return this.newInfoData
            },
        }, // 신규정보

        strdInfoData1: {
            get() {
                return this.strdInfoData
            },
        }, // 기준정보

        bizRgstInfoData1: {
            get() {
                return this.bizRgstInfoData
            },
        }, // 사업자등록정보

        dlvDealcoInfoData1: {
            get() {
                return this.dlvDealcoInfoData
            },
        }, // 배송지

        etcAddInfoData1: {
            get() {
                return this.etcAddInfoData
            },
        }, // 물류창고/직영점/하부망 추가정보

        acntInfoData1: {
            get() {
                return this.acntInfoData
            },
        }, // 계좌정보

        cltInfoData1: {
            get() {
                return this.cltInfoData
            },
        }, // 담보정보

        agencyAddInfoData1: {
            get() {
                return this.agencyAddInfoData
            },
        }, // 대리점 추가정보
    },
    async mounted() {
        await this.init() // 초기화
        this.gridSetting()
    },
    methods: {
        ...serviceMethods,

        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        async isDisabled(key, isDisabled) {
            await this.defaultAssign_({
                key: key,
                value: isDisabled,
            })
        },
        gridSetting() {
            let isGridStrdInfo = false // 기준정보
            let isGridEtcAddInfo = false // 추가정보
            let isGridBizRgstInfo = false // 사업자등록정보
            let isGridAcntInfo = false // 계좌정보
            let isGridCltInfo = false // 담보
            let isGridDlvDealcoInfo = false // 배송지

            this.storeSet('isGridStrdInfo', isGridStrdInfo)
            this.storeSet('isGridEtcAddInfo', isGridEtcAddInfo)
            this.storeSet('isGridBizRgstInfo', isGridBizRgstInfo)
            this.storeSet('isGridAcntInfo', isGridAcntInfo)
            this.storeSet('isGridCltInfo', isGridCltInfo)
            this.storeSet('isGridDlvDealcoInfo', isGridDlvDealcoInfo)
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },

        async init() {
            await this.loading(true)
            let isNew = true
            if (!_.isEmpty(this.parentParam)) {
                let param = { ...this.parentParam }
                this.title = '거래처상세'
                if (_.isEqual(param.ifYn, 'Y')) {
                    this.title = '거래처등록'
                }
                await this.defaultAssign_({
                    key: 'reqParams',
                    value: param,
                })

                if (this.parentParam.isHst) {
                    // 거래처이력
                    this.isSave = false
                    await this.getBasPrmDealcoDtlEtcList()
                } else {
                    // 거래처상세
                    await this.getBasPrmDealcoDtlNewList()
                    // 조직이관중 거래처조회
                    await this.getChgOrgReg()
                    this.isDealStatus1 = false
                }
            } else {
                this.title = '거래처등록'
                isNew = false
            }
            let initPIsNew = {}
            initPIsNew.pIsNew = isNew
            await this.defaultAssign_({
                key: 'initParams',
                value: initPIsNew,
            })

            this.initData()
        },
        updateMgmtDealStatus() {
            this.searchParam.dealcoCd = this.basPrmDealcoDtlVo.dealcoCd
            this.searchParam.normalYn = this.basPrmDealcoDtlVo.normalYn // 거래정상
            this.searchParam.payStopYn = this.basPrmDealcoDtlVo.payStopYn // 수납정지
            this.searchParam.outStopYn = this.basPrmDealcoDtlVo.outStopYn // 출고정지
            this.searchParam.saleStopYn = this.basPrmDealcoDtlVo.saleStopYn // 판매정지
            this.searchParam.sttlEndYn = this.basPrmDealcoDtlVo.sttlEndYn // 정산정지
            this.searchParam.drwStopYn = this.basPrmDealcoDtlVo.drwStopYn // 출금정지
            this.searchParam.dealEndYn = this.basPrmDealcoDtlVo.dealEndYn // 거래종료
            this.searchParam.hstSeq = this.basPrmDealcoDtlVo.hstSeq
            this.searchParam.modDtm = this.basPrmDealcoDtlVo.modDtm
            this.searchParam.modUserId = this.basPrmDealcoDtlVo.modUserId
            this.showDealStatusPopup = true // 거래처팝업 OPEN
            /*
this.updateMgmtDealStatus_()
.then((data) => {
if (_.isEmpty(data)) {
this.showTcComAlert('등록실패')
}
})
.catch((error) => {
Promise.reject(error)
})
.finally(() => {
console.log('🚀 ~ file: PopupContainer.vue ~ finally')
})

*/
        },

        async changeInfoSave() {
            await this.showTcComConfirm(
                '변경 정보는 현 시간부터 적용됩니다.\n\n변경하시겠습니까?'
            ).then((confirm) => {
                if (!confirm) return false
                if (confirm) {
                    this.electronicPayment()
                }
            })
        },
        async realDateDealcoDate() {
            await this.showTcComConfirm(
                '거래개시일을 실제 거래일자로 입력하셨으면 확인을 \n\n아닐 경우 취소를 클릭 하신 후 재입력 하세요.'
            ).then((confirm) => {
                if (!confirm) return false
                if (confirm) {
                    this.electronicPayment()
                }
            })
        },
        async bizAlert() {
            let bizNoCnt = this.bizInfo[0]['bizNoCount'] // 사업자등록번호COUNT
            console.log('bizNoCnt ->', bizNoCnt)
            if (!_.isEqual(bizNoCnt, '0')) {
                await this.showTcComConfirm(
                    '사업자번호가 중복된 거래처가 존재합니다. \r\n 진행하시겠습니까?'
                ).then((confirm) => {
                    if (!confirm) return false
                    if (confirm) {
                        this.bizAlertRepMblPhonNo()
                    }
                })
            } else {
                await this.bizAlertRepMblPhonNo()
            }
        },
        async bizAlertRepMblPhonNo() {
            let repMblPhonNoCnt = this.bizInfo[0]['repMblPhonNoCount'] // 대표이동전화번호COUNT
            console.log('repMblPhonNoCnt ->', repMblPhonNoCnt)
            if (!_.isEqual(repMblPhonNoCnt, '0')) {
                await this.showTcComConfirm(
                    '대표이동전화번호가 중복된 거래처가 존재합니다. \r\n 진행하시겠습니까?'
                ).then((confirm) => {
                    if (!confirm) return false
                    if (confirm) {
                        this.bizAlertEmail()
                    }
                })
            } else {
                await this.bizAlertEmail()
            }
        },
        async bizAlertEmail() {
            let emailCnt = this.bizInfo[0]['emailCount'] // 이메일COUNT
            console.log('emailCnt ->', emailCnt)
            if (!_.isEqual(emailCnt, '0')) {
                await this.showTcComConfirm(
                    '세금계산서 Email이 중복된 거래처가 존재합니다. \r\n 진행하시겠습니까?'
                ).then((confirm) => {
                    if (!confirm) {
                        console.log('전자결재 false')
                        return false
                    }
                    if (confirm) {
                        // this.saveConfirm()
                        this.getChgOrgRegDealco()
                    }
                })
            } else {
                this.getChgOrgRegDealco()
            }
        },
        // 신규등록
        imsiSave() {
            this.addMgmtDealCoImsi_()
                .then((data) => {
                    if (data === 1) {
                        this.showTcComAlert(
                            '임시저장완료\\n전자결재승인시 반영됩니다.'
                        )
                        this.searchDataNewLst()
                        this.closeBtn()
                    } else {
                        this.showTcComAlert('등록실패')
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                })
        },
        //변경/변경&담보갱생/해지 임시저장 - 전자결재
        imsiSave3() {
            this.earvImsi3_()
                .then((data) => {
                    if (data === 1) {
                        this.showTcComAlert(
                            '임시저장완료\\n전자결재승인시 반영됩니다.'
                        )
                        this.searchDataNewLst()
                        this.closeBtn()
                    } else {
                        this.showTcComAlert('등록실패')
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                })
        },
        //담보갱신 임시저장 - 전자결재
        imsiSave4() {
            this.earvImsi4_()
                .then((data) => {
                    if (data === 1) {
                        this.showTcComAlert(
                            '임시저장완료\\n전자결재승인시 반영됩니다.'
                        )
                        this.searchDataNewLst()
                        this.closeBtn()
                    } else {
                        this.showTcComAlert('등록실패')
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                })
        },

        setParams() {
            let reqParams = {}
            let reqClCd = 'U'
            let dealEndYn = 'N'
            let normalYn = 'N'
            if (this.initParam.pIsNew && _.isEqual(this.reqParam.ifYn, 'N')) {
                this.suType = 'update'
                //if (_.isEqual(this.basPrmDealcoDtlVo.dealEndYn, 'Y')) {
                if (this.strdInfoData.dealStatus[0] == 5) {
                    // 종료인 경우
                    reqClCd = 'N'
                    dealEndYn = 'Y'
                    this.storeSet('isDealStatus', true) // 거래종료
                } else {
                    normalYn = 'Y'
                    this.storeSet('isDealStatus', false)
                }
            } else {
                this.suType = 'save'
                reqClCd = 'I'
                normalYn = 'Y'
            }

            reqParams['regClCd'] = reqClCd
            let dealEndYnOrg = this.basPrmDealcoDtlVo.dealEndYnOrg
            reqParams['dealEndYnOrg'] = _.isEmpty(dealEndYnOrg)
                ? 'N'
                : dealEndYnOrg
            let dealCoCl2Org = this.basPrmDealcoDtlVo.orgDealcoClCd2
            reqParams['dealCoCl2Org'] = _.isEmpty(dealCoCl2Org)
                ? '2'
                : dealCoCl2Org

            if (this.initParam.pIsNew) {
                reqParams['dealEndDt'] = moment(
                    this.strdInfoData1.dealEndDt
                ).format('YYYY-MM-DD')

                reqParams['dealStaDt'] = moment(
                    this.strdInfoData1.dealStaDt
                ).format('YYYY-MM-DD')
            }

            if (_.isEmpty(this.strdInfoData1.dealStaDt)) {
                reqParams['dealStaDt'] = moment(new Date()).format('YYYY-MM-DD')
            }

            // 기본정보 또는 추가정보 또는 배송지정보 또는 담보정보가 변경된 경우
            if (
                this.isStrdInfo ||
                this.isEtcAddInfo ||
                this.isDlvDealcoInfo ||
                this.isCltInfo ||
                _.isEqual(this.etcAddInfoData1.dealcoClCd2, '3') // 3차점
            ) {
                reqParams['custEditYn'] = '1'
            } else {
                reqParams['custEditYn'] = this.custEditYn
            }

            // 계좌정보 체크 계좌정보 container에서 체크한다.
            /*
if (this.isDisabledGridAcntInfo) {
return false
}
*/
            // 실무담당연락처, 이름, 사업장 연락처 만 변경된경우는 거래처새로 생성하지 않고 UPDATE 한다.
            if (this.initParam.pIsNew && _.isEqual(this.reqParam.ifYn, 'N')) {
                if (_.isEmpty(this._newEffStaDtm)) {
                    let isUptBizRgst = false
                    let checkKeys = [
                        'repUserNm', // 대표자명
                        'repMblPhonNo', // 대표이동전화
                        'telNo', // 대표전화
                    ]

                    checkKeys.some((key) => {
                        // 개인정보, 추가정보, 담보, 배송지가 하나라도 변경될 시 적용일자 팝업 노출
                        if (
                            !_.isEmpty(this.bizRgstInfoDataOld) &&
                            !_.isEqual(
                                this.bizRgstInfoDataOld[key],
                                this.bizRgstInfoData[key]
                            ) &&
                            !this.isCltInfo &&
                            !this.isDlvDealcoInfo &&
                            !this.isEtcAddInfo
                        ) {
                            isUptBizRgst = true
                            //return true
                        } else {
                            isUptBizRgst = false
                        }
                    })
                    reqParams['dealcoInsertYn'] = isUptBizRgst ? 'N' : 'Y'

                    if (!isUptBizRgst) {
                        this.getNewEffStaDtmPop()
                    }
                } else {
                    reqParams['dealcoInsertYn'] = 'Y'
                    reqParams['newEffStaDtm'] = this._newEffStaDtm
                }
            }
            if (_.isEqual(this.isSlCmYn, 'Y')) {
                reqParams['slcmVerify'] = this.isSlCmYn
                // reqParams['slcmDfryDepoCheck'] = this.isSlCmYn
            }

            this.setNewInfoData(reqParams)
            this.setStrdInfoData(reqParams)
            this.setBizRgstInfoData(reqParams)
            this.setDlvDealcoInfoData(reqParams)
            this.setEtcAddInfoData(reqParams)
            this.setAcntInfoData(reqParams)
            this.setCltInfoData(reqParams)

            // this.setAgencyAddInfoData(reqParams)

            reqParams['dealcoCd'] = this.searchParam.dealcoCd
            reqParams['hstSeq'] = this.searchParam.hstSeq

            let sendDtCd = ''
            if (!_.isEmpty(this.sendDtCd)) {
                sendDtCd = this.sendDtCd
            }
            reqParams['sendDtCd'] = sendDtCd
            reqParams['normalYn'] = normalYn
            reqParams['dealEndYn'] = dealEndYn
            // 리스트정보 셋팅
            let data1 = {}
            Object.keys(reqParams).forEach((item) => {
                this.setDealcCustMaster(data1, reqParams, item) // 판매회계정보LIST
            })

            if (this.isGridCltInfo && !_.isEmpty(this.basPrmDealcoDtlCrdList)) {
                this.setDealcoCrd(reqParams) // 담보정보LIST
            }
            if (
                this.isGridDlvDealcoInfo &&
                !_.isEmpty(this.basPrmDealcoDtlDlvList)
            ) {
                this.setDealcoDlv(reqParams) // 배송정보LIST
            }

            if (
                this.isGridAcntInfo
                // && !_.isEmpty(this.basPrmDealcoImagAccList)
            ) {
                this.setDealcoImagAcc(reqParams) // 계좌정보LIST
            }

            // 수정인 경우 거래처 변경여부LIST
            if (this.initParam.pIsNew && _.isEqual(this.reqParam.ifYn, 'N')) {
                // 수정
                let custEdit = {}
                custEdit.custEditYn = _.isEmpty(reqParams['custEditYn'])
                    ? '0'
                    : reqParams['custEditYn']
                custEdit.dealcoInsertYn = reqParams['dealcoInsertYn']
                custEdit.newEffStaDtm = reqParams['newEffStaDtm']

                let custList = []
                custList.push(custEdit)
                reqParams['basPrmDealcoCustEditCkDto'] = custList
            }
            // 파라미터 추가 셋팅
            reqParams['newOrgCd'] = this.etcAddInfoData1.orgCd
            reqParams['orgCd2'] = this.etcAddInfoData1.bizChrgOrgCd
            reqParams['orgCd3'] = this.etcAddInfoData1.teamOrgCd

            // 계좌정보 예금주조회
            reqParams['slcmChk'] = _.isEmpty(this.acntInfoData1.slcmChk)
                ? 'N'
                : this.acntInfoData1.slcmChk
            reqParams['slcmDfryDepoCheck'] = _.isEmpty(
                this.acntInfoData1.slcmDfryDepoCheck
            )
                ? 'N'
                : this.acntInfoData1.slcmDfryDepoCheck

            reqParams['isSlCmYn'] = this.isSlCmYn
            reqParams['isSlCmChk'] = this.isSlCmChk

            console.log('reqParams->', reqParams)
            this.storeSet('params', reqParams)
        },
        saveConfirm() {
            this.showTcComConfirm('저장 하시겠습니까?').then((confirm) => {
                if (!confirm) return false

                //this.setReqParams()

                if (
                    this.initParam.pIsNew &&
                    _.isEqual(this.reqParam.ifYn, 'N')
                ) {
                    // 수정
                    this.dealcoMgmtUpdate()
                } else {
                    // 등록
                    this.dealcoMgmtInsert()
                }
            })
        },
        electronicPayment() {
            //거래처그룹 '직영매장', 거래처구분 '직영점' 아닐때 체크
            if (
                _.isEqual(this.params.dealcoGrpCd, 'AY') &&
                _.isEqual(this.params.dealcoClCd1, 'A2')
            ) {
                // this.saveConfirm()
                this.getChgOrgRegDealco()
            } else {
                this.bizAlert()
            }
        },
        checkBizInfo() {
            this.checkBizInfo_()
                .then((data) => {
                    if (_.isEmpty(data)) {
                        this.showTcComAlert(
                            '사업자번호/대표이동전화/세금계산서Email 중복체크 오류'
                        )
                    } else {
                        console.log(
                            '사업자번호/대표이동전화/세금계산서Email 중복체크 조회 성공'
                        )
                        //this.showTcComAlert('조회성공')
                    }
                    console.log('checkBizInfo data ->', data)
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                })
        },
        dealcoMgmtUpdate() {
            this.dealcoMgmtUpdate_()
                .then((data) => {
                    if (data === 1) {
                        this.showTcComAlert('등록완료')
                        this.searchDataNewLst()
                        this.closeBtn()
                    } else {
                        this.showTcComAlert('등록실패')
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                })
        },
        dealcoMgmtInsert() {
            this.dealcoMgmtInsert_()
                .then((data) => {
                    if (data === 1) {
                        this.showTcComAlert('등록완료')
                        this.searchDataNewLst()
                        this.closeBtn()
                    } else {
                        this.showTcComAlert('등록실패')
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                })
        },
        async getBasPrmDealcoDtlNewList() {
            //await this.loading(true)
            this.getBasPrmDealcoDtlNewList_()
                .then((data) => {
                    if (_.isEmpty(data)) {
                        this.showTcComAlert(msgTxt.MSG_00039.replace(/%s/g, ''))
                    }
                    // this.initIsDisabled(false)

                    this.getDealcoClList() // 거래처 유형 조회
                    this.changeDealcoCl2(this.basPrmDealcoDtlVo.dealcoClCd2)
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                    //this.loading(false)
                })
        },

        async getChgOrgReg() {
            //await this.loading(true)
            this.getChgOrgReg_()
                .then((data) => {
                    if (_.isEmpty(data)) {
                        console.log('조직이관 데이터가 존재하지 않습니다.')
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                    //this.loading(false)
                })
        },

        async getBasPrmDealcoDtlEtcList() {
            this.getBasPrmDealcoDtlEtcList_()
                .then((data) => {
                    if (_.isEmpty(data)) {
                        this.showTcComAlert(msgTxt.MSG_00039.replace(/%s/g, ''))
                    }
                    // this.initIsDisabled(false)
                    this.changeDealcoCl2(this.etcAddInfoData1.dealcoClCd2)
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                    //this.loading(false)
                })
        },

        disableDataList(isValue) {
            const isDisableDataList = [
                'isDisabledDataUKey',
                'isDisabledDataStlPlc',
                'isDisabledDataDisHldPlc',
                'isDisabledDataStlPlcChk',
                'isDisabledDataDisHldPlcChk',
                'isDisabledDataSknDelvYn',
                'isDisabledDataExcYn',
                'isDisabledDataBankCdYn',
            ]

            _.forEach(isDisableDataList, (data) => {
                this.isDisabled(data, !isValue)
            })
        },

        disableDataBankList(isValue) {
            const isDisableDataBankList = [
                'isDisabledDataBankCd1',
                'isDisabledDataBankCd2',
                'isDisabledDataBankCd3',
                'isDisabledDataBankCd4',
                'isDisabledDataBankCd5',
                'isDisabledDataBankCd6',
            ]

            _.forEach(isDisableDataBankList, (data) => {
                this.isDisabled(data, !isValue)
            })
        },

        disableDataDealcoClList(isValue) {
            const isDisableDataDealcoClList = [
                'isDisabledDataDealcoCl1_1',
                'isDisabledDataDealcoCl2_1',
                'isDisabledDataDealcoCl3_1',
                'isDisabledDataMaDirectYn_1',
                'isDisabledDataSisYn_1',
            ]

            _.forEach(isDisableDataDealcoClList, (data) => {
                this.isDisabled(data, !isValue)
            })
        },

        initIsDisabled(isValue) {
            this.disableDataList(isValue)
            this.disableDataBankList(isValue)
            this.disableDataDealcoClList(isValue)
        },

        initData() {
            let basPrmDealco = [
                'dealcoCl2List_1', //
                'dealcoCl3List_1', //
                'basPrmDealcoDtlCardList', // 카드단말기
                'basPrmDealcoDtlCardListDel', // 카드단말기
                'basPrmDealcoDtlCrdList', // 담보
                'basPrmDealcoDtlDlvList', // 배송지
                'basPrmDealcoImagAccList', // 계좌정보
                'basPrmDealcoImagAccListDel', // 삭제된 계좌정보
                'basPrmDealcoImagAccListNew', // 추가된 계좌정보
                'basPrmDealcoDtlListVo', // 거래처상세
                'basPrmDealcoDtlCmListVo', // 사업자등록정보
                'basPrmDealcoDtlCardListVo', // 카드단말기
                'basPrmDealcoDtlCrdListVo', // 담보
                'basPrmDealcoDtlDlvListVo', // 배송지
                'basPrmDealcoDtlChrgrListVo', // 영업담당자
                'basPrmDealcoDtlEarvCntListVo', // 전자결재 진행여부
                'basPrmDealcoImagAccListVo', // 가상계좌
                'getdealcoCd', // 거래처  신규거래처 코드 조회
                'getMibiYn', // 서류미비상태체크
                'checkDis', // 서류미비상태체크
                'accHldChk', // accHldChk  정산처재고보유처체크
                'getRequestCrdAdd', // requestCrdAdd 신규 전자결재 요청
                'getRequestCrdAdd4', //rquestCrdAdd4 담보갱신 전자결재 요청
                'getRequestCrdAdd6', //requestCrdAdd6 해지 전자결재 요청
                'getRequestCrdAdd3', //getRequestCrdAdd3 전자결재 요청 상제조회  변경
                'getRequestCrdAdd5', //getRequestCrdAdd5 전자결재 요청 상제조회 담보N담보갱신
                'getRequestCrdAdd7', //getRequestCrdAdd7 전자결재 요청 상제조회  신규 재품의
                'crdAddParams',
                'params',
            ] // 상세db정보
            _.forEach(basPrmDealco, (item) => {
                this.defaultAssign_({
                    key: item,
                    value: [],
                })
            })

            this.defaultAssign_({
                key: 'reqParams',
                value: this.initParam.pIsNew ? this.parentParam : [],
            })

            let infoData = [
                'dlvDealcoInfoData', // 배송지정보
                'newInfoData', // 신규정보
                'strdInfoData', // 기준정보
                'etcAddInfoData', // 물류창고/직영점/하부망 추가정보
                'acntInfoData', // 계좌정보
                'cltInfoData', // 담보정보
                'agencyAddInfoData', // 대리점 추가정보
                'bizRgstInfoData', // 사업자등록정보
                'strdInfoDataOld', // 기준정보 변경전
                'bizRgstInfoDataOld', // 사업자등록정보 변경전
                'dlvDealcoInfoDataOld', // 배송지 변경전
                'etcAddInfoDataOld', // 추가정보 변경전
                'cltInfoDataOld', // 담보정보 변경전
                'acntInfoDataOld', // 계좌정보 변경전
                'paramAgencyCd', // 배송지 코드발급 파라미터
            ] // 상세정보 param

            _.forEach(infoData, (item) => {
                this.defaultAssign_({
                    key: item,
                    value: {},
                })
            })

            this.storeSet('isGridStrdInfo', true)
            this.storeSet('isGridEtcAddInfo', true)
            this.storeSet('isGridBizRgstInfo', true)
            this.storeSet('isGridAcntInfo', true)
            this.storeSet('isGridCltInfo', true)
            this.storeSet('isGridDlvDealcoInfo', true)

            this.storeSet('isStrdInfo', false) // 기준정보변경여부
            this.storeSet('isBizRgst', false) // 사업자등록정보변경여부
            this.storeSet('isDlvDealcoInfo', false) // 배송지 변경여부
            this.storeSet('isCltInfo', false) // 담보정보 변경여부
            this.storeSet('isEtcAddInfo', false) // 추가정보 변경여부
            this.storeSet('isAcntInfo', false) // 계좌정보 변경여부

            this.defaultAssign_({
                key: 'sendDtCd',
                value: [],
            })

            this.defaultAssign_({
                key: 'bizParams',
                value: [],
            })

            this.defaultAssign_({
                key: 'bizInfo',
                value: [],
            })

            this.defaultAssign_({
                key: 'chgOrgRegDealco',
                value: '',
            })

            // 배송지코드
            this.defaultAssign_({
                key: 'getSknDlvDealcoCd',
                value: '',
            })

            // 저장 후 처리
            this.defaultAssign_({
                key: 'addMgmtDealCoImsi',
                value: '',
            })

            this.defaultAssign_({
                key: 'earvImsi3',
                value: '',
            })
            this.defaultAssign_({
                key: 'earvImsi4',
                value: '',
            })
            this.defaultAssign_({
                key: 'newEffStaDtmParam',
                value: '',
            })

            this.userSaleParam = {
                orgCd: this.orgInfo.orgCd,
                orgLvl: this.orgInfo.orgLvl,
                orgNm: this.orgInfo.orgNm,
            }
            //this.initIsDisabled(true)
            this.storeSet('isDealStatus', false) // 거래종료
            this.loading(false)
        },

        //////////////////////////// [저장 관련 함수] //////////////////////////////
        validation() {
            //출금활성화/출금계좌등록/변경,변경&담보갱신,거래종료품의시 출금계좌 체크
            if (!this.getEarvYn()) {
                console.log(
                    '출금활성화/출금계좌등록/변경,변경&담보갱신,거래종료품의시 출금계좌 체크 false'
                )
                return false
            }
            // 기준정보 체크
            //if (this.isGridStrdInfo && !this.strdInfoValidation()) {
            if (!this.strdInfoValidation()) {
                console.log('기본정보 false')
                return false
            }

            // 추가정보 체크
            if (this.isGridEtcAddInfo && !this.addInfoValidation()) {
                console.log('추가정보 false')
                return false
            }

            // 사업자등록정보 체크
            if (this.isGridBizRgstInfo && !this.bizInfoValidation()) {
                console.log('사업자등록정보 false')
                return false
            }

            // 계좌정보 체크
            if (this.isGridAcntInfo && !this.acntInfoValidation()) {
                console.log('계좌정보 false')
                return false
            }
            /*
//  담보 체크
if (this.isGridCltInfo && !this.cltInfoValidation()) {
    console.log('담보 false')
    return false
}

if (this.isGridDlvDealcoInfo1 && !this.dlvDealcoInfoValidation()) {
    console.log('배송지정보 false')
    return false
}
*/
            return true
        },
        setNewInfoData(reqParams) {
            _.forEach(Object.keys(this.newInfoData1), (item) => {
                reqParams[item] = this.typeOfString(this.newInfoData1[item])
            }) // 신규정보
        },
        setStrdInfoData(reqParams) {
            _.forEach(Object.keys(this.strdInfoData1), (item) => {
                let value = this.typeOfString(this.strdInfoData1[item])
                if (
                    (_.isEqual(item, 'dealStaDt') && !_.isEmpty(value)) ||
                    (_.isEqual(item, 'dealEndDt') && !_.isEmpty(value))
                ) {
                    reqParams[item] = value.replace(/-/g, '')
                    // } else if (_.isEqual(item, 'dealStatus')) {
                    //     let dealEndYnOrg = this.basPrmDealcoDtlVo.dealEndYnOrg
                    //     reqParams['dealEndYnOrg'] = _.isEmpty(dealEndYnOrg)
                    //         ? 'N'
                    //         : dealEndYnOrg
                } else {
                    reqParams[item] = value
                }
            }) // 기준정보
        },
        setBizRgstInfoData(reqParams) {
            _.forEach(Object.keys(this.bizRgstInfoData1), (item) => {
                let value = this.typeOfString(this.bizRgstInfoData1[item])
                if (_.isEqual(item, 'visitStaDt')) {
                    reqParams['visitStaDt'] = value[0].replace(/-/g, '')
                    reqParams['visitEndDt'] = value[1].replace(/-/g, '')
                } else {
                    reqParams[item] = value
                }
            }) // 사업자등록정보
        },
        setDlvDealcoInfoData(reqParams) {
            _.forEach(Object.keys(this.dlvDealcoInfoData1), (item) => {
                reqParams[item] = this.typeOfString(
                    this.dlvDealcoInfoData1[item]
                )
            }) // 배송지
        },
        setEtcAddInfoData(reqParams) {
            _.forEach(Object.keys(this.etcAddInfoData1), (item) => {
                let value = this.typeOfString(this.etcAddInfoData1[item])
                if (
                    _.isEqual(item, 'accDealcoChk') ||
                    _.isEqual(item, 'hldDealcoChk') ||
                    _.isEqual(item, 'sknDelvYn') ||
                    _.isEqual(item, 'excYn')
                ) {
                    reqParams[item] = _.isEmpty(value[0]) ? 'N' : value[0]
                } else {
                    reqParams[item] = value
                }
            }) // 물류창고/직영점/하부망 추가정보
        },
        setAcntInfoData(reqParams) {
            _.forEach(Object.keys(this.acntInfoData1), (item) => {
                reqParams[item] = this.typeOfString(this.acntInfoData1[item])
            }) // 계좌정보
        },
        setCltInfoData(reqParams) {
            _.forEach(Object.keys(this.cltInfoData1), (item) => {
                reqParams[item] = this.typeOfString(this.cltInfoData1[item])
            }) // 담보정보
        },
        setAgencyAddInfoData(reqParams) {
            _.forEach(Object.keys(this.agencyAddInfoData1), (item) => {
                reqParams[item] = this.typeOfString(
                    this.agencyAddInfoData1[item]
                )
            }) // 대리점 추가정보
        },
        // 추가정보체크
        addInfoValidation() {
            const orgCd = this.params.orgCd
            const sktAgencyCd = this.params.sktAgencyCd
            const dealcoGrpCd = this.params.dealcoGrpCd
            const dealcoClCd2 = this.params.dealcoClCd2
            const dealcoClCd3 = this.params.dealcoClCd3
            const accDealcoCd = this.params.accDealcoCd
            const hldDealcoCd = this.params.hldDealcoCd
            const sktChnlCd = this.params.sktChnlCd
            const sktSubCd = this.params.sktSubCd
            const accDealcoChk = this.params.accDealcoChk
            const hldDealcoChk = this.params.hldDealcoChk

            console.log(' ======================================== ')
            console.log('orgCd -> ', orgCd)
            console.log('sktAgencyCd -> ', sktAgencyCd)
            console.log('dealcoGrpCd -> ', dealcoGrpCd)
            console.log('dealcoClCd2 -> ', dealcoClCd2)
            console.log('dealcoClCd3 -> ', dealcoClCd3)
            console.log('accDealcoCd -> ', accDealcoCd)
            console.log('hldDealcoCd -> ', hldDealcoCd)
            console.log('sktChnlCd -> ', sktChnlCd)
            console.log('sktSubCd -> ', sktSubCd)
            console.log('accDealcoChk -> ', accDealcoChk)
            console.log('hldDealcoChk -> ', hldDealcoChk)
            if (_.isEmpty(orgCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '소속조직을')
                )
                return false
            } else if (_.isEmpty(sktAgencyCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, 'Swing대리점')
                )
                return false
            } else if (_.isEmpty(sktChnlCd) && _.isEqual(dealcoGrpCd, 'YY')) {
                // 하부망인 경우
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, 'SwingP코드')
                )
                return false
            } else if (_.isEmpty(sktSubCd) && _.isEqual(dealcoGrpCd, 'AY')) {
                // 직영매장인 경우
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, 'Swing서브점')
                )
                return false

                /*
} else if (_.isEmpty(dealcoClCd2)) {
if (!this.isDisabledDataDealcoCl2_1) {
    this.showTcComAlert(
        CommonUtil.replaceMsg(msgTxt.MSG_00047, '거래처유형을')
    )
    return false
}
} else if (_.isEmpty(dealcoClCd3)) {
if (!this.isDisabledDataDealcoCl3_1) {
    this.showTcComAlert(
        CommonUtil.replaceMsg(msgTxt.MSG_00047, '거래처분류를')
    )
    return false
}
return false

 */
            } else if (
                !_.isEqual(this.params.dealcoClCd2, '3') &&
                _.isEmpty(accDealcoCd) &&
                _.isEqual(accDealcoChk, 'N')
            ) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '정산처를')
                )
                return false
            } else if (
                !_.isEqual(this.params.dealcoClCd2, '3') &&
                _.isEmpty(hldDealcoCd) &&
                _.isEqual(hldDealcoChk, 'N')
            ) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '재고보유처를')
                )
                return false
            } else {
                return true
            }
        },
        // 물류창고/직영점/하부망 체크
        addInfoValidation2() {
            const dealcoGrpCd = this.etcAddInfoData1.dealcoGrpCd
            //const dealcoClCd1 = this.etcAddInfoData1.dealcoClCd1
            const dealcoClCd2 = this.etcAddInfoData1.dealcoClCd2
            const dealcoClCd3 = this.etcAddInfoData1.dealcoClCd3

            const orgCd = this.etcAddInfoData1.orgCd
            const sktAgencyCd = this.etcAddInfoData1.sktAgencyCd
            //const sktSubCd = this.etcAddInfoData1.sktSubCd

            //---------------------------------------------------------------------------------------
            // 거래처유형 필수 체크
            // 거래처그룹 : 하부망(YY), 물류창고(ZZ),
            //              직영매장(AY)+거래처구분_직영점(A2), 직영매장(AY)+거래처구분_직영점2(A6)
            //---------------------------------------------------------------------------------------
            if (
                _.isEqual(dealcoGrpCd, 'YY') ||
                _.isEqual(dealcoGrpCd, 'ZZ') ||
                _.isEqual(dealcoGrpCd, 'AY')
            ) {
                if (_.isEmpty(dealcoClCd2)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(msgTxt.MSG_00047, '거래처 유형을')
                    )
                    return false
                }
            }

            //---------------------------------------------------------------------------------------
            // 거래처분류 필수 체크
            // 거래처그룹 : 하부망(YY),
            //              직영매장(AY)+거래처구분_직영점(A2), 직영매장(AY)+거래처구분_직영점2(A6)
            //---------------------------------------------------------------------------------------
            if (_.isEqual(dealcoGrpCd, 'YY') || _.isEqual(dealcoGrpCd, 'AY')) {
                if (_.isEmpty(dealcoClCd3)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(msgTxt.MSG_00047, '거래처 분류를')
                    )
                    return false
                }
            }

            //---------------------------------------------------------------------------------------
            // 소속조직, 소속대리점, UKEY대리점, UKEY서브점 필수 체크
            // 거래처그룹 : 하부망(YY), 물류창고(ZZ), 직영매장(AY)
            //---------------------------------------------------------------------------------------
            if (
                _.isEqual(dealcoGrpCd, 'YY') ||
                _.isEqual(dealcoGrpCd, 'ZZ') ||
                _.isEqual(dealcoGrpCd, 'AY')
            ) {
                if (_.isEmpty(orgCd)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(msgTxt.MSG_00047, '소속조직을')
                    )
                    return false
                }

                if (_.isEmpty(sktAgencyCd)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(
                            msgTxt.MSG_00047,
                            'Swing 대리점을'
                        )
                    )
                    return false
                }
                /*
if (_.isEmpty(sktSubCd)) {
this.showTcComAlert(
CommonUtil.replaceMsg(
msgTxt.MSG_00047,
'Swing 서브점을'
)
)
return false
}
*/
                //---------------------------------------------------------------------------------------
                // 하부망(YY) , 직영매장(AY)
                // 2차점인경우 체크박스가 체크되어 있으면 정산처, 보유처에 자기의 거래처 코드 셋팅(자바에서) 하고
                //    체크 안된경우 정산처, 보유처 코드 필수체크.
                // 3차점인경우 정산처, 보유처 코드 필수체크. 정산처, 재고보유처의 코드가 자기자신의 거래처코드면 안됨.
                //---------------------------------------------------------------------------------------
                if (
                    _.isEqual(dealcoGrpCd, 'YY') ||
                    _.isEqual(dealcoGrpCd, 'AY')
                ) {
                    /*
const accDealcoCd = this.etcAddInfoData1.accDealcoCd // 정산처
const accDealcoChk = this.etcAddInfoData1.accDealcoChk // 정산처
const hldDealcoCd = this.etcAddInfoData1.hldDealcoCd // 재고보유처
const hldDealcoChk = this.etcAddInfoData1.hldDealcoChk // 재고보유처
const email = this.bizRgstInfoData1.email1 // email

*/
                    //const emailAcc = this.searchParams.emailAcc // email
                    // 2차점 체크
                    /*
if (this.getCl1Addinfo4()) {
if (_.isEmpty(accDealcoCd) && !accDealcoChk) {
this.showTcComAlert('정산처를 체크하십시오.')
return false
}
if (_.isEmpty(hldDealcoCd) && !hldDealcoChk) {
this.showTcComAlert('재고보유처를 체크하십시오.')
return false
}

if (_.isEmpty(email)) {
this.showTcComAlert(
'세금계산서 Email를 입력하십시오'
)
return false
}
}
*/
                    // 2차첨이 아닌것 체크
                    /*
if (_.isEqual(dealcoClCd2, '3')) {
if (_.isEmpty(accDealcoCd)) {
this.showTcComAlert('정산처를 선택하십시오.')
return false
}
if (_.isEmpty(hldDealcoCd)) {
this.showTcComAlert('재고보유처를 선택하십시오.')
return false
}
if (_.isEqual(orgCd, accDealcoCd)) {
this.showTcComAlert(
'3차점인 경우 정산처는 자기 자신이 될 수 없습니다.'
)
return false
}
if (_.isEqual(orgCd, hldDealcoCd)) {
this.showTcComAlert(
'3차점인 경우 재고보유처는 자기 자신이 될 수 없습니다.'
)
return false
}
}
*/
                }
            }

            /*TODO 거래처분류가 정산처이면 거래처=정산처=재고보유처
if (
sDealCoGrp == 'AY' &&
strAddInfoYn == 'N' &&
ds_detail.GetColumn(0, 'DEAL_CO_CL3') == '1' &&
(ds_detail.GetColumn(0, 'DEAL_CO_CD') !=
ds_detail.GetColumn(0, 'STL_PLC') ||
ds_detail.GetColumn(0, 'DEAL_CO_CD') !=
ds_detail.GetColumn(0, 'DIS_HLD_PLC'))
) {
alert('거래처와 정산처, 재고보유처가 동일해야 합니다.')
return false
}
*/
            return true
        },

        // 기준정보 체크
        strdInfoValidation() {
            const dealcoRgstClCd = this.params.dealcoRgstClCd
            const dealcoGrpCd = this.params.dealcoGrpCd
            const dealcoClCd1 = this.params.dealcoClCd1
            const dealcoNm = this.params.dealcoNm
            const dealStaDt = this.params.dealStaDt
            const dealEndDt = this.params.dealEndDt
            const signZipCd = this.params.signZipCd
            console.log(' ======================================== ')
            console.log('dealcoRgstClCd ->', dealcoRgstClCd)
            console.log('dealcoGrpCd ->', dealcoGrpCd)
            console.log('dealcoClCd1 ->', dealcoClCd1)
            console.log('dealcoNm ->', dealcoNm)
            console.log('dealStaDt ->', dealStaDt)
            console.log('dealEndDt ->', dealEndDt)
            console.log('signZipCd ->', signZipCd)

            if (_.isEmpty(dealcoRgstClCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '등록구분을')
                )
                return false
            } else if (_.isEmpty(dealcoGrpCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '거래처그룹을')
                )
                return false
            } else if (_.isEmpty(dealcoClCd1)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '거래처구분을')
                )
                return false
            } else if (_.isEmpty(dealcoNm)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '거래처명')
                )
                return false
            } else if (_.isEmpty(dealStaDt)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '시작일')
                )
                return false
            } else if (_.isEmpty(dealEndDt)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '종료일')
                )
                return false
            } else if (
                !_.isEmpty(dealEndDt) &&
                this.compareDate(dealStaDt, dealEndDt)
            ) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00095, '종료일', '시작일')
                )
                return false
            } else if (_.isEmpty(signZipCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '주소')
                )
                return false
                /*
} else if (
_.isEqual(this.params.dealcoGrpCd, 'AX') && // 대리점
this.isDisabledDataUKey // Swing 대리점이 활성화 되어 있는 경우
) {
if (_.isEmpty(this.params.dealcoCd)) {
this.showTcComAlert(
'거래처그룹이 대리점인 경우 소속조직을 선택하십시오.'
)
return false
}
if (_.isEmpty(this.params.sktAgencyCd)) {
this.showTcComAlert(
'거래처그룹이 대리점인 경우 Swing 대리점을 선택하십시오.'
)
return false
}

*/
            } else {
                return true
            }
        },
        // 사업자등록정보 체크
        bizInfoValidation() {
            const perBizClCd = this.params.perBizClCd
            const bizNo = this.params.bizNo
            const repUserNm = this.params.repUserNm
            const bizConNm = this.params.bizConNm
            const typOfBizNm = this.params.typOfBizNm
            const taxTypCd = this.params.taxTypCd
            const tradeNm = this.params.tradeNm
            const telNo = this.params.telNo
            const email1 = this.params.email1
            const email3 = this.params.email3
            const taxPrdCd = this.params.taxPrdCd
            console.log(' ======================================== ')
            console.log('perBizClCd ->', perBizClCd)
            console.log('bizNo ->', bizNo)
            console.log('repUserNm ->', repUserNm)
            console.log('bizConNm ->', bizConNm)
            console.log('typOfBizNm ->', typOfBizNm)
            console.log('taxTypCd ->', taxTypCd)
            console.log('tradeNm ->', tradeNm)
            console.log('telNo ->', telNo)
            console.log('email1 ->', email1)
            console.log('email3 ->', email3)
            console.log('taxPrdCd ->', taxPrdCd)

            if (_.isEmpty(perBizClCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '사업자구분을')
                )
                return false
            } else if (_.isEmpty(bizNo)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '사업자번호')
                )
                return false
            } else if (_.isEmpty(repUserNm)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '대표자명')
                )
                return false
            } else if (_.isEmpty(bizConNm)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '업태')
                )
                return false
            } else if (_.isEmpty(typOfBizNm)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '종목')
                )
                return false
            } else if (_.isEmpty(taxTypCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '과세구분을')
                )
                return false
            } else if (_.isEmpty(tradeNm)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '상호')
                )
                return false
            } else if (_.isEmpty(telNo)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '대표전화')
                )
                return false
            } else if (_.isEmpty(email1) && _.isEmpty(email3)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '이메일')
                )
                return false
            } else if (_.isEmpty(taxPrdCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(
                        msgTxt.MSG_00047,
                        '세금계산서발행주기를'
                    )
                )
                return false
            } else {
                return true
            }
        },
        // 사업자등록정보 체크
        bizInfoValidation2() {
            const dealcoClCd1 = this.params.dealcoClCd1
            const sPerBizCl = this.params.perBizClCd
            const sBizNum = this.params.bizNo
            const typOfBizNm = this.params.typOfBizNm

            if (_.isEmpty(sPerBizCl)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '사업자등록정보를')
                )
                return false
            }
            if (_.isEqual(sPerBizCl, '1')) {
                if (_.isEmpty(sBizNum)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(msgTxt.MSG_00083, '주민등록번호')
                    )
                    return false
                }
                let bResult = false
                if (sBizNum.length > 0) {
                    if (_.isEqual(dealcoClCd1, 'C1')) {
                        // G채널 TODO 체크로직 확인
                        //bResult = this.uf_isRegNo2(sBizNum)
                    } else {
                        // TODO 체크로직 확인
                        //bResult = this.uf_isRegNo2(sBizNum)
                    }
                    bResult = true

                    if (!bResult) {
                        this.showTcComAlert(msgTxt.MSG_01013)
                        return false
                    }
                }

                if (!_.isEqual(dealcoClCd1, 'MA')) {
                    this.showTcComAlert(
                        '사업자 구분 개인의 경우 거래처분 MA만 선택 가능합니다.'
                    )
                    return false
                }
            } else if (_.isEqual(sPerBizCl, '2')) {
                if (_.isEmpty(sBizNum)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(msgTxt.MSG_00083, '사업자번호')
                    )
                    return false
                }
                let bResult = false
                if (sBizNum.length > 0) {
                    // TODO 체크로직 확인
                    // bResult = this.uf_isBizNo(sBizNum)
                    bResult = true
                    if (!bResult) {
                        this.showTcComAlert(
                            CommonUtil.replaceMsg(
                                msgTxt.MSG_00083,
                                '사업자번호'
                            )
                        )
                        return false
                    }
                }
            }

            if (typOfBizNm.length > 30) {
                this.showTcComAlert(
                    '종목은 30byte를 초과 할 수 없습니다.\\n\\n한글 1자는 2byte\\n영문/특수 1자는 1byte'
                )
                // alert("종목은 30byte를 초과 할 수 없습니다.\n\n한글 1자는 2byte\n영문/특수 1자는 1byte");
                return false
            }
            /*
TODO 일마감 확인 거래종료일

if(cf_getClsStatus("D",div_baseinfo.cal_dealEndDt.value,"SLS")){
alert("거래종료일은 일마감 이후로 설정가능합니다.\n최종 일마감일자는 ["+gds_closeInfo.GetColumn(0,"LAST_CLS_DTM")+"] 입니다.");

return false;
}
*/

            return true
        },
        // 계좌정보 체크
        acntInfoValidation() {
            const slcmDfryBankCd = this.params.slcmDfryBankCd
            const slcmDfryAccNo = this.params.slcmDfryAccNo
            const slcmDfryDepo = this.params.slcmDfryDepo
            // const vrfDpstrNm = this.params.vrfDpstrNm
            // const isSlCmYn = this.params.isSlCmYn
            // const vrfDpstrYn = this.params.vrfDpstrYn
            console.log(' ======================================== ')
            console.log('slcmDfryBankCd ->', slcmDfryBankCd)
            console.log('slcmDfryAccNo ->', slcmDfryAccNo)
            console.log('slcmDfryDepo ->', slcmDfryDepo)
            // console.log('vrfDpstrNm ->', vrfDpstrNm)
            // console.log('isSlCmYn ->', isSlCmYn)
            // console.log('vrfDpstrYn ->', vrfDpstrYn)

            if (
                _.isEqual(this.params.dealcoGrpCd, 'AY') || // 직영매장
                _.isEqual(this.params.dealcoClCd2, '3') // 3차점
            ) {
                return true
            }
            if (_.isEmpty(slcmDfryBankCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '출금은행을')
                )
                return false
            } else if (_.isEmpty(slcmDfryAccNo)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '출금계좌')
                )
                return false
            } else if (_.isEmpty(slcmDfryDepo)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '출금예금주')
                )
                return false
                // } else if (_.isEmpty(vrfDpstrNm)) {
                //     this.showTcComAlert('출금계좌 조회를 눌러주세요.')
                //     return false
                // } else if (_.isEmpty(isSlCmYn) || _.isEmpty(vrfDpstrYn)) {
                //     this.showTcComAlert('예금주 승인을 눌러주세요.')
                //     return false
            } else {
                return true
            }
        },
        cltInfoValidation() {
            const crdtTypCd = this.params.crdtTypCd
            const grtInstCd = this.params.grtInstCd
            const mstDealcoCd = this.params.mstDealcoCd
            const mrtgSetAmt = this.params.mrtgSetAmt
            const setBasisDesc = this.params.setBasisDesc
            console.log(' ======================================== ')
            console.log('crdtTypCd ->', crdtTypCd)
            console.log('grtInstCd ->', grtInstCd)
            console.log('mstDealcoCd ->', mstDealcoCd)
            console.log('mrtgSetAmt ->', mrtgSetAmt)
            console.log('setBasisDesc ->', setBasisDesc)

            if (_.isEmpty(crdtTypCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '여신유형을')
                )
                return false
            } else if (_.isEmpty(grtInstCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '보증기관을')
                )
                return false
            }
            // 여신유형이 공유담보이면서 보증기관이 공유담보거래처인 경우
            else if (_.isEqual(crdtTypCd, '04') && _.isEqual(crdtTypCd, '04')) {
                if (_.isEmpty(mstDealcoCd)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(
                            msgTxt.MSG_00047,
                            '공유담보거래처를'
                        )
                    )
                    return false
                }
            } else if (_.isEmpty(mrtgSetAmt)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '담보설정금액')
                )
                return false
            } else if (_.isEmpty(setBasisDesc)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '설정근거')
                )
                return false
            } else {
                return true
            }
        },
        // 담보 체크
        cltInfoValidation2() {
            const crdtTypCd = this.params.crdtTypCd // 여신유형
            const grtInstCd = this.params.grtInstCd // 보증기관
            const mstDealcoCd = this.params.mstDealcoCd // 공유담보거래처
            const mrtgSetAmt = this.params.mrtgSetAmt // 담보설정금액
            const setBasisDesc = this.params.setBasisDesc // 설정근거
            if (_.isEmpty(crdtTypCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '여신유형')
                )
                return false
            } else if (_.isEmpty(grtInstCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '보증기관')
                )
                return false
            } else if (_.isEmpty(mstDealcoCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '공유담보거래처')
                )
                return false
            } else if (_.isEmpty(mrtgSetAmt)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '담보설정금액')
                )
                return false
            } else if (_.isEmpty(setBasisDesc)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '설정근거')
                )
                return false
            } else {
                return true
            }
        },

        // 배송지정보 체크
        dlvDealcoInfoValidation() {
            const sknDelvDealcdNm = this.params.sknDelvDealcdNm
            const sknDlvSktAgencyCd = this.params.sknDlvSktAgencyCd
            const sknDlvSktSubCd = this.params.sknDlvSktSubCd
            const sknDlvPwdNo = this.params.sknDlvPwdNo
            const sknDlvChrgrUserId = this.params.sknDlvChrgrUserId
            const sknDlvMblPhonNo = this.params.sknDlvMblPhonNo
            const sknDlvAplyStaDt = this.params.sknDlvAplyStaDt
            const sknDlvUseYn = this.params.sknDlvUseYn
            console.log(' ======================================== ')
            console.log('sknDelvDealcdNm ->', sknDelvDealcdNm)
            console.log('sknDlvSktAgencyCd ->', sknDlvSktAgencyCd)
            console.log('sknDlvSktSubCd ->', sknDlvSktSubCd)
            console.log('sknDlvPwdNo ->', sknDlvPwdNo)
            console.log('sknDlvChrgrUserId ->', sknDlvChrgrUserId)
            console.log('sknDlvMblPhonNo ->', sknDlvMblPhonNo)
            console.log('sknDlvAplyStaDt ->', sknDlvAplyStaDt)
            console.log('sknDlvUseYn ->', sknDlvUseYn)

            if (_.isEmpty(sknDelvDealcdNm)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '배송지명')
                )
                return false
            } else if (_.isEmpty(sknDlvSktAgencyCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '배송대리점을')
                )
                return false
            } else if (_.isEmpty(sknDlvSktSubCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(
                        msgTxt.MSG_00083,
                        '배송대리점서브코드'
                    )
                )
                return false
            } else if (_.isEmpty(sknDlvPwdNo)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '직배송인증번호')
                )
                return false
            } else if (_.isEmpty(sknDlvChrgrUserId)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '수취담당명')
                )
                return false
            } else if (_.isEmpty(sknDlvMblPhonNo)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '수취담담연락처')
                )
                return false
            } else if (_.isEmpty(sknDlvAplyStaDt)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '적용시작일')
                )
                return false
            } else if (_.isEmpty(sknDlvUseYn)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '사용여부를')
                )
                return false
            } else {
                return true
            }
        },

        // 출금계좌 체크
        getEarvYn() {
            const dealCoCl1 = this.params.dealcoClCd1
            const dealCoCl2 = this.params.dealcoClCd2
            const dealCoCl3 = this.params.dealcoClCd3

            console.log('출금계좌체크')
            console.log('dealCoCl1 ->', dealCoCl1)
            console.log('dealCoCl2 ->', dealCoCl2)
            console.log('dealCoCl3 ->', dealCoCl3)
            if (
                _.isEqual(dealCoCl1, 'A2') ||
                _.isEqual(dealCoCl1, 'A3') ||
                _.isEqual(dealCoCl1, 'AC') ||
                _.isEqual(dealCoCl1, 'AD') ||
                _.isEqual(dealCoCl1, 'AE') ||
                _.isEqual(dealCoCl1, 'B1') ||
                _.isEqual(dealCoCl1, 'B2') ||
                _.isEqual(dealCoCl1, 'E1') ||
                _.isEqual(dealCoCl1, 'M1') ||
                (_.isEqual(dealCoCl1, 'M2') && _.isEqual(dealCoCl2, '2'))
            ) {
                this.earvYn = 'Y'
            } else if (
                (_.isEqual(dealCoCl1, 'A6') || _.isEqual(dealCoCl1, 'A7')) &&
                (_.isEqual(dealCoCl2, '1') || _.isEqual(dealCoCl2, '2')) &&
                (_.isEqual(dealCoCl3, '1') || _.isEqual(dealCoCl3, '2'))
            ) {
                this.earvYn = 'Y'
            } else if (
                _.isEqual(dealCoCl1, 'AF') &&
                _.isEqual(dealCoCl2, '1') &&
                (_.isEqual(dealCoCl3, '1') || _.isEqual(dealCoCl3, '2'))
            ) {
                this.earvYn = 'Y'
            } else if (_.isEqual(dealCoCl1, 'D1')) {
                this.earvYn = 'Y'
            } else {
                this.earvYn = 'N'
            }

            let save = 0
            if (_.isEqual(this.earvYn, 'Y') && _.isEqual(this.isSlCmYn, '9')) {
                if (
                    !_.isEmpty(this.newInfoData1) &&
                    !this.isStrdInfo && // 기본정보
                    !this.isCltInfo && // 담보정보
                    !this.isDlvDealcoInfo // 배송지정보
                ) {
                    save = 1
                }

                // 계약해지 : 6
                if (_.isEqual(this.params.dealEndYn, 'Y')) {
                    save = 1
                    this.isSlCmChk = 'Y'
                } else {
                    // 변경 : 3
                    if (!this.isCltInfo && _.isEqual(this.earvYn, 'Y')) {
                        save = 1
                    }

                    //변경 & 담보갱신:5
                    if (this.isCltInfo && _.isEqual(this.earvYn, 'Y')) {
                        save = 1
                    }

                    console.log('save ->', save)
                    if (
                        _.isEqual(this.acntInfoData1.slcmChk, 'Y') &&
                        (!_.isEmpty(this.acntInfoData1.slcmDfryBankCd) ||
                            !_.isEmpty(this.acntInfoData1.slcmDfryAccNo) ||
                            !_.isEmpty(this.acntInfoData1.slcmDfryDepo)) &&
                        save === 1
                    ) {
                        // this.showTcComAlert(
                        //     '현재 기준 예금주 검증이 필요합니다.'
                        // )
                        // return false
                    }
                }

                //출금정보가 없으면 예금주 검증 불필요
                if (
                    _.isEmpty(this.acntInfoData1.slcmDfryBankCd) &&
                    _.isEmpty(this.acntInfoData1.slcmDfryAccNo) &&
                    _.isEmpty(this.acntInfoData1.slcmDfryDepo)
                ) {
                    this.isSlCmYn = '9'
                    this.isSlCmChk = 'Y'
                }
                //
                // if (_.isEqual(this.isSlCmChk, 'N')) {
                //     this.showTcComAlert('예금주 검증이 완료되지 않았습니다.')
                //      return false
                // }

                if (_.isEqual(this.acntInfoData1.isSlCmYn, '2')) {
                    this.isSlCmYn = '2'
                    this.isSlCmChk = 'Y'
                }

                console.log('==============')
            }
            return true
        },

        // 전자결재 전송대상 판단
        checkEarvType() {
            console.log('전자결재 전송대상 -> ', this.earvYn)
            if (_.isEqual(this.params.dealcoClCd2, '3')) {
                this.earvYn = 'N'
            }
            if (_.isEqual(this.earvYn, 'Y')) {
                //대표자명,상호,출금계좌,도로명주소
                // 사업자등록정보 변경여부 this.isBizRgst

                this.isDisabled('isDisabledDataEarvYn', false) // 품의기안 활성화
                // const earvType = this.params.earvType

                // if (_.isEmpty(earvType)) {
                //     this.showTcComAlert(
                //         CommonUtil.replaceMsg(msgTxt.MSG_00047, '첨부서류를')
                //     )
                //     return false
                // }

                // 변경_서류첨부 체크
                if (_.isEqual(this.params.earvType[0], '20')) {
                    if (
                        !this.isBizRgst && // 사업자정보
                        !this.isAcntInfo && // 계좌정보
                        !this.isCltInfo && // 담보정보
                        !this.isDlvDealcoInfo // 배송지
                    ) {
                        this.showTcComAlert('품의기안(변경) 대상입니다.')
                        this.storeSet('earvStType', '3')
                        return false
                    } else {
                        this.showTcComAlert(
                            '변경 데이터가 있을때, 변경_서류첨부 기능을 사용 할 수 없습니다.'
                        )

                        let newInfo = { ...this.newInfoData1 }
                        newInfo['earvType'] = [] // 초기화
                        this.storeSet('newInfoData', newInfo)
                        return false
                    }
                }

                // 신규_서류첨부 체크
                if (_.isEqual(this.params.earvType[0], '10')) {
                    this.showTcComAlert('품의기안(신규_재품의) 대상입니다.')
                    this.storeSet('earvStType', '7')
                    return false
                }

                // 신규계약 : 2
                if (_.isEmpty(this.params.dealcoCd)) {
                    this.showTcComAlert('품의기안(신규계약) 대상입니다.')
                    this.storeSet('earvStType', '2')
                    return false
                }

                //계약해지:6
                if (this.isDealStatus) {
                    this.showTcComAlert('품의기안(계약해지) 대상입니다.')
                    this.storeSet('earvStType', '6')
                    return false
                } else {
                    //변경:3
                    if (
                        !this.isCltInfo && // 담보정보 변경X
                        (this.isBizRgst || this.isAcntInfo) // 사업자정보 변경 O 또는 계좌정보 변경 O
                    ) {
                        this.showTcComAlert('품의기안(변경) 대상입니다.')
                        this.storeSet('earvStType', '3')
                        return false
                    }

                    //담보갱신:4
                    if (
                        this.isCltInfo && // 담보정보 변경 O
                        !this.isBizRgst &&
                        !this.isAcntInfo // 사업자정보 변경 X
                    ) {
                        this.showTcComAlert('품의기안(담보갱신) 대상입니다.')
                        this.storeSet('earvStType', '4')
                        return false
                    }

                    //변경 & 담보갱신:5
                    if (
                        this.isCltInfo && // 담보정보 변경 O
                        (this.isBizRgst || this.isAcntInfo) // 사업자정보 변경 O 또는 계좌정보 변경 O
                    ) {
                        this.showTcComAlert(
                            '품의기안(변경&담보갱신) 대상입니다.'
                        )
                        this.storeSet('earvStType', '5')
                        return false
                    }
                }
                return true
            } else {
                this.isDisabled('isDisabledDataEarvYn', true) // 품의기안 비활성화
                return true
            }

            // if (this.isCheckEarv) return true
        },
        getChgOrgRegDealco() {
            if (!_.isEmpty(this.chgOrgRegDealco)) {
                this.showTcComAlert(
                    '조직이관 요청에 등록 후\n아직 이관되지 않은 거래처는 변경 불가합니다.'
                )
                return false
            }

            // 전자결재 전송대상인지 판단
            if (!this.checkEarvType()) {
                console.log('전자결재 전송대상이 아님')
                this.isCheckEarv = true
                return false
            } else {
                console.log('전자결재 로직 처리 후 저장로직')
                this.saveConfirm()
            }

            // 품의기안이 비활성화 일때만 저장로직처리
            /*
if (this.isCheckEarv) {
    console.log('전자결재 로직 처리 후 저장로직')
    this.saveConfirm()
}

*/
        },
        save() {
            // 전자결재승인여부 확인
            console.log(
                'this.basPrmDealcoDtlEarvCntVo ->',
                this.basPrmDealcoDtlEarvCntVo
            )
            if (!_.isEmpty(this.basPrmDealcoDtlEarvCntVo)) {
                if (
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.deal, '0') ||
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.dlv, '0') ||
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.crd, '0') ||
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.cust, '0')
                ) {
                    this.showTcComAlert('전자결재 승인 대기중입니다.')
                    return false
                }
            }

            if (this.newInfoData1.earvType[0] === undefined) {
                if (this.isBizRgst || this.isAcntInfo) {
                    this.custEditYn = '9'
                }
                if (
                    _.isEqual(this.custEditYn, '0') &&
                    !this.isCltInfo && // 담보정보 변경여부
                    !this.isDlvDealcoInfo // 배송지 변경여부
                ) {
                    // this.showTcComAlert(CommonMsg.getMessage('MSG_00133')) // 변경사항이 없습니다
                    // return false
                }
            } else {
                this.custEditYn = '0'
            }

            this.setParams() // 파라미터셋팅

            let bizParam = []
            bizParam['dealcoCd'] = this.params.dealcoCd
            bizParam['bizNo'] = this.params.bizNo
            bizParam['repMblPhonNo'] = this.params.repMblPhonNo
            bizParam['email1'] = this.params.email1
            bizParam['email2'] = this.params.email2
            this.storeSet('bizParams', bizParam)

            // 사업자번호/대표이동전화/세금계산서Email 중복체크 API 조회
            if (_.isEmpty(this.bizInfo)) {
                this.checkBizInfo()
            }

            // validation check
            if (!this.validation()) {
                return false
            }
            if (!this.showNewEffStaDtm) {
                if (
                    this.initParam.pIsNew &&
                    _.isEqual(this.reqParam.ifYn, 'N')
                ) {
                    this.changeInfoSave()
                } else {
                    this.realDateDealcoDate()
                }
            }
        },

        setDealcCustMaster(data1, reqParams, item) {
            let keys = [
                'dealcoCd',
                'hstSeq',
                'dealcoNm',
                'addr',
                'dtlAddr',
                'zipCd',
                'telNo',
                'regNo',
                'bizNo',
                'repUserNm',
                'typOfBizNm',
                'bizConNm',
                'drwAccNo',
                'dpstrNm',
                'orgCd',
                'sktAgencyCd',
                'sktSubCd',
                'sktChnlCd',
                'insDtm',
                'insUserId',
                'regClCd',
                'trmsStCd',
                'delYn',
                'custClCd',
                'newZipCd',
                'siDoNm',
                'siGunGuNm',
                'eupMyunDongNm',
                'streetNm',
                'ldongNm',
                'siGunGuBldnNm',
                'newDtlAddr',
                'vrfDpstrYn',
                'vrfDpstrNm',
                'modUserId',
                'wgs84XCodnVal',
                'wgs84YCodnVal',
            ]

            _.forEach(keys, (key) => {
                if (_.isEqual(key, item)) {
                    data1[key] =
                        reqParams[key] === 'undefined' ? '' : reqParams[key]
                }
            })

            data1['slcmDfryBankCd'] = this.acntInfoData1.slcmDfryBankCd // 출금은행코드
            data1['drwAccNo'] = this.acntInfoData1.slcmDfryAccNo // 출금계좌번호
            data1['dpstrNm'] = this.acntInfoData1.slcmDfryDepo // 출금계좌예금주명(사용자입력)
            //data1['vrfDpstrYn'] = this.acntInfoData1.isSlCmYn // 출금계좌예금주명일치여부코드(일치 =1  / 불일치 9 / 불일치지만 진행 2 isSlCmYn)
            data1['vrfDpstrYn'] = this.isSlCmYn // 출금계좌예금주명일치여부코드(일치 =1  / 불일치 9 / 불일치지만 진행 2 isSlCmYn)
            data1['vrfDpstrNm'] = this.acntInfoData1.vrfDpstrNm // 출금계좌예금주명(SAP)

            let data = [data1]
            reqParams['basPrmDealcCustMasterDto'] = data
        },
        setDealcoCrd(reqParams) {
            let data = []
            _.forEach(this.basPrmDealcoDtlCrdList, (item) => {
                //if (!_.isEmpty(item.__rowState)) {
                let obj = {}
                let setDt = item.setDt
                let expirDt = item.expirDt
                if (!_.isEmpty(setDt)) {
                    setDt = setDt.replace(/-/g, '')
                } else {
                    setDt = ''
                }
                if (!_.isEmpty(expirDt)) {
                    expirDt = expirDt.replace(/-/g, '')
                } else {
                    expirDt = ''
                }
                obj.setDt = setDt
                obj.mrtgSetAmt = item.mrtgSetAmt
                obj.dealcoCd = item.dealcoCd
                obj.serNo = item.serNo
                obj.hstSeq = item.hstSeq
                obj.crdRmks = item.crdRmks
                obj.delYn = item.delYn
                obj.updCnt = item.updCnt
                obj.insDtm = item.insDtm
                obj.insUserId = item.insUserId
                obj.crdtTypCd = item.crdtTypCd
                obj.grtInstCd = item.grtInstCd
                obj.expirDt = expirDt
                obj.setBasisDesc = item.setBasisDesc
                obj.cmmsAmt = item.cmmsAmt
                obj.modUserId = item.modUserId
                obj.modDtm = item.modDtm
                obj.mstDealcoCd = item.mstDealcoCd
                obj.mrtgAmt = item.mrtgAmt
                obj.__rowState = _.isEmpty(item.__rowState)
                    ? 'updated'
                    : item.__rowState
                obj.earv = _.isEmpty(item.__rowState) ? 'N' : 'Y'
                data.push(obj)
                // }
            })

            if (!_.isEmpty(this.basPrmDealcoDtlCrdListDel)) {
                _.forEach(this.basPrmDealcoDtlCrdListDel, (item) => {
                    if (!_.isEmpty(item.__rowState)) {
                        let obj = {}
                        let setDt = item.setDt
                        let expirDt = item.expirDt
                        if (!_.isEmpty(setDt)) {
                            setDt = setDt.replace(/-/g, '')
                        } else {
                            setDt = ''
                        }
                        if (!_.isEmpty(expirDt)) {
                            expirDt = expirDt.replace(/-/g, '')
                        } else {
                            expirDt = ''
                        }
                        obj.setDt = setDt
                        obj.mrtgSetAmt = item.mrtgSetAmt
                        obj.dealcoCd = item.dealcoCd
                        obj.serNo = item.serNo
                        obj.hstSeq = item.hstSeq
                        obj.crdRmks = item.crdRmks
                        obj.delYn = item.delYn
                        obj.updCnt = item.updCnt
                        obj.insDtm = item.insDtm
                        obj.insUserId = item.insUserId
                        obj.crdtTypCd = item.crdtTypCd
                        obj.grtInstCd = item.grtInstCd
                        obj.expirDt = expirDt
                        obj.setBasisDesc = item.setBasisDesc
                        obj.cmmsAmt = item.cmmsAmt
                        obj.modUserId = item.modUserId
                        obj.modDtm = item.modDtm
                        obj.mstDealcoCd = item.mstDealcoCd
                        obj.mrtgAmt = item.mrtgAmt
                        obj.__rowState = item.__rowState
                        data.push(obj)
                    }
                })
            }

            if (!_.isEmpty(data)) {
                reqParams['basPrmDealcoCrdDto'] = data
            }
        },
        setDealcoDlv(reqParams) {
            let data = []

            _.forEach(this.basPrmDealcoDtlDlvList, (item) => {
                if (!_.isEmpty(item.__rowState)) {
                    let obj = {}
                    let sknDlvAplyStaDt = item.aplyStaDt

                    if (!_.isEmpty(sknDlvAplyStaDt)) {
                        sknDlvAplyStaDt = sknDlvAplyStaDt.replace(/-/g, '')
                    } else {
                        sknDlvAplyStaDt = ''
                    }
                    obj.sknDlvDealcoCd = item.sknDlvDealcoCd
                    obj.rcvSknDlvDealcoCd = item.rcvSknDlvDealcoCd
                    obj.sktSubCd = item.sktSubCd
                    obj.dealcoCd = item.dealcoCd
                    obj.hstSeq = item.hstSeq
                    obj.sknDelvDealcdNm = item.sknDelvDealcdNm
                    obj.sktAgencyCd = item.sktAgencyCd
                    obj.sknDlvSktAgencyCd = item.sknDlvSktAgencyCd
                    obj.newSubCd = item.newSubCd
                    obj.postSubCd = item.postSubCd
                    obj.sknDelvZipCd1 = item.sknDelvZipCd1
                    obj.sknDelvZipCd2 = item.sknDelvZipCd2
                    obj.sknDelvAddr = item.sknDelvAddr
                    obj.sknDelvDtlAddr = item.sknDelvDtlAddr
                    obj.sknDelvChrgrUserId = item.sknDelvChrgrUserId
                    obj.phon1 = item.phon1
                    obj.phon2 = item.phon2
                    obj.phon3 = item.phon3
                    obj.aplyStaDt = sknDlvAplyStaDt
                    obj.useYn = item.sknDlvUseYn
                    obj.dlvRmks = item.sknDlvRmks
                    obj.sknDlvRmks = item.sknDlvRmks
                    obj.updCnt = item.updCnt
                    obj.insDtm = item.insDtm
                    obj.insUserId = item.insUserId
                    obj.modDtm = item.modDtm
                    obj.modUserId = item.modUserId
                    obj.sknDlvSktSubCd = item.sknDlvSktSubCd
                    obj.sendStCd = item.sendStCd
                    obj.sknDlvZipCd = item.sknDlvZipCd
                    obj.siDoNm = item.siDoNm
                    obj.siGunGuNm = item.siGunGuNm
                    obj.eupMyunDongNm = item.eupMyunDongNm
                    obj.streetNm = item.streetNm
                    obj.ldongNm = item.ldongNm
                    obj.siGunGuBldnNm = item.siGunGuBldnNm
                    obj.newDtlAddr = item.newDtlAddr
                    obj.sendTypeCd = item.sendTypeCd
                    obj.orgCdLvl0 = item.orgCdLvl0
                    obj.sendDtCd = item.sendDtCd
                    obj.sknDlvPwdNo = item.sknDlvPwdNo
                    obj.sknDlvClCd = item.sknDlvClCd
                    obj.sknDelvZipCd = item.sknDelvZipCd
                    obj.sknDlvChrgrUserId = item.sknDlvChrgrUserId
                    obj.sknDlvMblPhonNo = item.sknDlvMblPhonNo
                    obj.sknDlvUseYn = item.useYn
                    obj.__rowState = item.__rowState

                    data.push(obj)
                }
            })

            if (!_.isEmpty(this.basPrmDealcoDtlDlvListDel)) {
                _.forEach(this.basPrmDealcoDtlDlvListDel, (item) => {
                    if (!_.isEmpty(item.__rowState)) {
                        let obj = {}
                        let sknDlvAplyStaDt = item.aplyStaDt

                        if (!_.isEmpty(sknDlvAplyStaDt)) {
                            sknDlvAplyStaDt = sknDlvAplyStaDt.replace(/-/g, '')
                        } else {
                            sknDlvAplyStaDt = ''
                        }

                        obj.sknDlvDealcoCd = item.sknDlvDealcoCd
                        obj.rcvSknDlvDealcoCd = item.rcvSknDlvDealcoCd
                        obj.sktSubCd = item.sktSubCd
                        obj.dealcoCd = item.dealcoCd
                        obj.hstSeq = item.hstSeq
                        obj.sknDelvDealcdNm = item.sknDelvDealcdNm
                        obj.sktAgencyCd = item.sktAgencyCd
                        obj.sknDlvSktAgencyCd = item.sknDlvSktAgencyCd
                        obj.newSubCd = item.newSubCd
                        obj.postSubCd = item.postSubCd
                        obj.sknDelvZipCd1 = item.sknDelvZipCd1
                        obj.sknDelvZipCd2 = item.sknDelvZipCd2
                        obj.sknDelvAddr = item.sknDelvAddr
                        obj.sknDelvDtlAddr = item.sknDelvDtlAddr
                        obj.sknDelvChrgrUserId = item.sknDelvChrgrUserId
                        obj.phon1 = item.phon1
                        obj.phon2 = item.phon2
                        obj.phon3 = item.phon3
                        obj.aplyStaDt = sknDlvAplyStaDt
                        obj.useYn = item.sknDlvUseYn
                        obj.dlvRmks = item.sknDlvRmks
                        obj.updCnt = item.updCnt
                        obj.insDtm = item.insDtm
                        obj.insUserId = item.insUserId
                        obj.modDtm = item.modDtm
                        obj.modUserId = item.modUserId
                        obj.sknDlvSktSubCd = item.sknDlvSktSubCd
                        obj.sendStCd = item.sendStCd
                        obj.sknDlvZipCd = item.sknDlvZipCd
                        obj.siDoNm = item.siDoNm
                        obj.siGunGuNm = item.siGunGuNm
                        obj.eupMyunDongNm = item.eupMyunDongNm
                        obj.streetNm = item.streetNm
                        obj.ldongNm = item.ldongNm
                        obj.siGunGuBldnNm = item.siGunGuBldnNm
                        obj.newDtlAddr = item.newDtlAddr
                        obj.sendTypeCd = item.sendTypeCd
                        obj.orgCdLvl0 = item.orgCdLvl0
                        obj.sendDtCd = item.sendDtCd
                        obj.sknDlvPwdNo = item.sknDlvPwdNo
                        obj.sknDlvClCd = item.sknDlvClCd
                        obj.sknDelvZipCd = item.sknDelvZipCd
                        obj.sknDlvChrgrUserId = item.sknDlvChrgrUserId
                        obj.sknDlvMblPhonNo = item.sknDlvMblPhonNo
                        obj.sknDlvUseYn = item.useYn
                        obj.__rowState = 'deleted'
                        data.push(obj)
                    }
                })
            }

            if (!_.isEmpty(data)) {
                reqParams['basPrmDealcoDlvDto'] = data
                reqParams['basPrmDealcoDlvSaveDto'] = data
            }
        },
        setDealcoImagAcc(reqParams) {
            let accList = []

            // 출금계좌 셋팅
            let slcmDfry = {}
            slcmDfry.acntClCd = '03'
            // slcmDfry.bankCd = reqParams['slcmDfryBankCd']
            // slcmDfry.acntNo = reqParams['slcmDfryAccNo']
            // slcmDfry.depoNm = reqParams['slcmDfryDepo']
            slcmDfry.bankCd = this.acntInfoData1.slcmDfryBankCd
            slcmDfry.acntNo = this.acntInfoData1.slcmDfryAccNo
            slcmDfry.depoNm = this.acntInfoData1.slcmDfryDepo
            slcmDfry.__rowState = 'created'
            accList.push(slcmDfry)

            _.forEach(this.basPrmDealcoImagAccList, (item) => {
                let rowState = _.isEmpty(item.__rowState)
                    ? 'created'
                    : item.__rowState
                //if (!_.isEmpty(item.__rowState)) {
                if (!_.isEqual(item.acntClCd, '03')) {
                    let obj = {}
                    obj.acntClCd = item.acntClCd
                    obj.bankCd = item.bankCd
                    obj.acntNo = item.acntNo
                    obj.cmsCd = item.cmsCd
                    obj.depoNm = item.depoNm
                    obj.modUserId = item.modUserId
                    obj.__rowState = rowState
                    accList.push(obj)
                }
                //}
            })

            // 삭제계좌
            if (!_.isEmpty(this.basPrmDealcoImagAccListDel)) {
                _.forEach(this.basPrmDealcoImagAccListDel, (item) => {
                    if (!_.isEmpty(item.__rowState)) {
                        let obj = {}
                        obj.acntClCd = item.acntClCd
                        obj.bankCd = item.bankCd
                        obj.acntNo = item.acntNo
                        obj.cmsCd = item.cmsCd
                        obj.depoNm = item.depoNm
                        obj.modUserId = item.modUserId
                        obj.__rowState = item.__rowState
                        accList.push(obj)
                    }
                })
            }

            if (!_.isEmpty(accList)) {
                reqParams['basPrmDealcoImagAccDto'] = accList
            }
        },

        //////////////////////////// [저장 관련 함수] //////////////////////////////

        clear() {},
        //팝업닫기
        closeBtn: function () {
            this.initData()
            this.activeOpen = false
        },
        compareDate(startDt, endDt) {
            return new Date(startDt) > new Date(endDt)
        },
        getCl1Addinfo4() {
            const dealcoGrpCd = this.etcAddInfoData1.dealcoGrpCd
            const dealcoClCd2 = this.etcAddInfoData1.dealcoClCd2
            const dealcoClCd3 = this.etcAddInfoData1.dealcoClCd3
            if (
                _.isEqual(dealcoGrpCd, 'YY') && // 그룹이 하부망
                _.isEqual(dealcoClCd2, '2') // 유형이 2 면 2차점
            ) {
                return true
            } else if (
                _.isEqual(dealcoGrpCd, 'AY') && // 그룹이 직영매장
                _.isEqual(dealcoClCd3, 'Y') // ADD_INFO_04 = Y
            ) {
                return true
            } else {
                return false
            }
        },
        // 거래처구분 조회
        getDealcoClList() {
            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]

            /**
             * addInfo1
             * 3X : 매입처
             * 2X : 제조사
             */
            _.forEach(this.zbasC00240, (data) => {
                if (
                    _.isEqual(data.addInfo1, this.etcAddInfoData1.dealcoGrpCd)
                ) {
                    let isDataUkey
                    if (
                        _.isEqual(data.addInfo1, '3X') ||
                        _.isEqual(data.addInfo1, '2X')
                    ) {
                        isDataUkey = false
                    } else {
                        let strdInfoParams = {}
                        strdInfoParams.mfactDealcoCd = '' // U.Key제조사 코드
                        strdInfoParams.sortSeq = '' // 제조사 정렬순서
                        this.storeSet('strdInfo', strdInfoParams)
                        isDataUkey = true
                    }

                    this.isDisabled('isDisabledDataUKey', isDataUkey) // ukey 제조사코드
                    defaultData.push(data)
                }
            })

            this.dealcoClList = defaultData
            this.storeSet('dealcoClList_1', defaultData)
            // this.isDisabled('isDisabledDataDealcoCl2_1', true)
            // this.isDisabled('isDisabledDataDealcoCl3_1', true)
            this.storeSet('dealcoCl2List_1', this.initList1) // 초기화
        },
        // 거래처구분 Change 이벤트
        changeDealcoCl2(code) {
            // 거래처유형 코드 구하기
            this.getDealcoCl2Data(code)
            this.getDealcoCl2DataList() // 거래처 유형 조회

            // 거래처분류 조회
            this.getDealcoCl3DataList() // 거래처 분류 조회
        },
        // 거래처 유형 코드조회
        getDealcoCl2Data(code) {
            let dealcoGrpCd = ''
            let addInfoYn = ''

            _.forEach(this.dealcoClList, (data) => {
                if (_.isEqual(code, data.commCdVal)) {
                    dealcoGrpCd = data.addInfo1
                    addInfoYn = data.addInfo4
                }
            })

            if (_.isEmpty(dealcoGrpCd)) {
                dealcoGrpCd = this.etcAddInfoData1.dealcoGrpCd
            }

            /**
             * dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */
            let etcAddInfoParams = {}
            let dealcoClCd2Code = ''
            //let isDataDealcoClCd2 = false
            let isDataSisYn = false
            let isDataMaDirectYn = false

            if (_.isEqual(dealcoGrpCd, 'AY')) {
                if (_.isEqual(addInfoYn, 'Y')) {
                    dealcoClCd2Code = this.zbasC00110
                } else if (_.isEqual(addInfoYn, 'N')) {
                    dealcoClCd2Code = this.zbasC00570
                }
                if (
                    _.isEqual(code, 'A2') ||
                    _.isEqual(code, 'B1') ||
                    _.isEqual(code, 'AD') ||
                    _.isEqual(code, 'AE')
                ) {
                    isDataSisYn = true
                } else {
                    isDataSisYn = false
                }
            } else if (_.isEqual(dealcoGrpCd, 'YY')) {
                dealcoClCd2Code = this.zbasC00110
                if (_.isEqual(code, 'M1') || _.isEqual(code, 'M2')) {
                    // MA || B&C MA
                    isDataMaDirectYn = false
                } else {
                    isDataMaDirectYn = true
                    etcAddInfoParams.maDirectYn = '' // 직접운영 여부 초기화
                }
            } else if (_.isEqual(dealcoGrpCd, 'ZZ')) {
                dealcoClCd2Code = this.zbasC00110
            } else {
                //isDataDealcoClCd2 = true
                isDataSisYn = false
            }
            this.isDisabled('isDisabledDataMaDirectYn_1', isDataMaDirectYn)
            this.isDisabled('isDisabledDataSisYn_1', isDataSisYn)
            //this.isDisabled('isDisabledDataDealcoCl2_1', isDataDealcoClCd2)

            this.storeSet('dealcoCl2CodeData', dealcoClCd2Code)

            etcAddInfoParams.dealcoClCd2 = '' // 거래처유형 초기화
            this.storeSet('etcAddInfo', etcAddInfoParams)
        },
        // 거래처유형 조회
        getDealcoCl2DataList() {
            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]
            if (_.isEmpty(this.dealcoCl2CodeData)) {
                this.storeSet('dealcoCl2List_1', defaultData)
                this.isDisabled('isDisabledDataBankCdYn', true) // 출금계좌 off
            }

            /**
             * basPrmDealcoDtlVo.dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */
            _.forEach(this.dealcoCl2CodeData, (data) => {
                if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'AY')) {
                    if (
                        _.isEqual(
                            data.addInfo1,
                            'Y' || _.isEmpty(data.addInfo1)
                        ) &&
                        _.isEqual(data.commCdId, 'ZBAS_C_00110')
                    ) {
                        defaultData.push(data)
                    } else if (_.isEqual(data.commCdId, 'ZBAS_C_00570')) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'YY')) {
                    if (
                        _.isEqual(
                            data.addInfo2,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'ZZ')) {
                    if (
                        _.isEqual(
                            data.addInfo3,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                }
            })

            this.storeSet('dealcoCl2List_1', defaultData)
            this.isDisabled('isDisabledDataBankCdYn', true) // 출금계좌 off
        },

        // 거래처분류 조회
        getDealcoCl3DataList() {
            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]

            /**
             * basPrmDealcoDtlVo.dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */

            _.forEach(this.zbasC00530, (data) => {
                if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'AY')) {
                    if (
                        _.isEqual(
                            data.addInfo1,
                            'Y' || _.isEmpty(data.addInfo1)
                        ) &&
                        _.isEqual(data.commCdId, 'ZBAS_C_00110')
                    ) {
                        defaultData.push(data)
                    } else if (_.isEqual(data.commCdId, 'ZBAS_C_00570')) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'YY')) {
                    if (
                        _.isEqual(
                            data.addInfo2,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'ZZ')) {
                    if (
                        _.isEqual(
                            data.addInfo3,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                }
            })

            if (defaultData.length > 1 && _.isEmpty(defaultData[1].commCdVal)) {
                this.isDisabled('isDisabledDataDealcoCl3_1', true) // 거래처구분 off
                this.isDisabled('isDisabledDataBankCdYn', true) // 출금계좌 off
            }
            this.storeSet('dealcoCl3List_1', defaultData)
        },
        typeOfString(value) {
            if (typeof value === 'object') {
                if (_.isEmpty(value)) {
                    value = ''
                }
            }
            return value
        },
        //===================== 적용시작일자팝업 관련 methods ================================
        getNewEffStaDtmPop() {
            this.showNewEffStaDtm = true
        },
        //===================== // 적용시작일자팝업 관련 methods ================================
        //===================== 사용자팝업(영업담당자)관련 methods ================================
        // 사용자 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 사용자 팝업 오픈
        getSaleChrgrPopList() {
            this.showBcoSaleChrgr = true
        },
        // 사용자 TextField 돋보기 Icon 이벤트 처리
        async btn_select_Onclick() {
            if (!this.initParam.pIsNew) {
                this.showTcComAlert('상세에서만 가능합니다.')
                return false
            }
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultSaleChrgrRows = []
            // 검색조건 사용자명이 빈값이 아니면 사용자 정보 조회
            // 그 이외는 사용자 팝업 오픈

            if (this.strdInfoData.dealStatus[0] != 5) {
                // 거래종료가 아닌 경우만
                this.getSaleChrgrPopList()
            } else {
                this.showTcComAlert(
                    '거래처 적용 종료일자가9999-12-31 인\n거래처만 선택 가능합니다 '
                )
            }
        },

        // 사용자 팝업 리턴 이벤트 처리
        async anconSaleChrgrReturnData(returnData) {
            console.log('returnData: ', returnData)
            //this.searchSaleChrgrParam.userId = _.get(retrunData, 'userId')
            //this.searchSaleChrgrParam.userNm = _.get(retrunData, 'userNm')
            //this.searchSaleChrgrParam.orgNm = _.get(retrunData, 'orgNmTree')

            let params = { ...this.etcAddInfo }
            const userNm = _.get(returnData, 'userNm')
            const userId = _.get(returnData, 'userId')
            if (!_.isEmpty(userNm) && !_.isEmpty(userId)) {
                params.saleChrgr = userNm + '(' + userId + ')'
                params.userNm = userNm
                params.userId = userId
                params.__rowState = 'created'
                params.dealcoCd = this.basPrmDealcoDtlVo.dealcoCd
                await this.storeSet('basPrmDealcoDtlChrgrListVo', params)
            }
        },
        //===================== //사용자팝업(영업담당자)관련 methods ================================
        async searchDataNewLst() {
            await this.loading(true)
            let data1
            await this.getBasPrmDealcoMgmtNewLst_()
                .then((data) => {
                    data1 = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    this.loading(false)
                    if (data1.gridList === null) {
                        this.showTcComAlert(
                            msgTxt.MSG_00039.replace(/%s/g, '거래처 목록')
                        )
                    }
                })
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                if (!_.isEmpty(value)) {
                    this.searchParam.dealcoCd =
                        value['dealcoCd'] === undefined ? '' : value['dealcoCd']
                    this.searchParam.hstSeq =
                        value['hstSeq'] === undefined ? '' : value['hstSeq']
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        strdInfoData1: {
            handler: function (value) {
                let isGridStrdInfo = false // 기본정보
                let isGridEtcAddInfo = false // 추가정보
                let isGridBizRgstInfo = false // 사용자등록정보
                let isGridAcntInfo = false // 계좌정보
                let isGridCltInfo = false // 담보
                let isGridDlvDealcoInfo = false // 배송지
                if (!_.isEmpty(value)) {
                    // dealcoRgstClCd 거래처등록구분
                    // dealcoGrpCd 거래처그룹
                    // dealcoClCd1 거래처구분

                    if (
                        _.isEqual(value.dealcoRgstClCd, 'DC') && // 매장공통
                        _.isEqual(value.dealcoGrpCd, 'AY') && // 직영매장
                        (_.isEqual(value.dealcoClCd1, 'A2') || // 직영점
                            _.isEqual(value.dealcoClCd1, 'A6') || // 직영위탁
                            _.isEqual(value.dealcoClCd1, 'A7') || // 자영위탁직영
                            _.isEqual(value.dealcoClCd1, 'B1')) // 온라인직영
                    ) {
                        isGridStrdInfo = true // 기본정보
                        isGridEtcAddInfo = true // 추가정보
                        isGridBizRgstInfo = true // 사용자등록정보
                        isGridAcntInfo = true // 계좌정보
                        isGridCltInfo = true // 담보
                        isGridDlvDealcoInfo = true // 배송지
                        if (
                            _.isEqual(value.dealcoClCd1, 'A2') || // 직영점
                            _.isEqual(value.dealcoClCd1, 'B1') // 온라인직영
                        ) {
                            isGridCltInfo = false // 담보
                        }

                        if (_.isEqual(value.dealcoClCd1, 'B1')) {
                            // 온라인직영
                            isGridDlvDealcoInfo = false // 배송지
                        }
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'DC') && // 매장공통
                        _.isEqual(value.dealcoGrpCd, 'YY') // 하부망
                    ) {
                        isGridStrdInfo = true // 기본정보
                        isGridEtcAddInfo = true // 추가정보
                        isGridBizRgstInfo = true // 사용자등록정보
                        isGridAcntInfo = true // 계좌정보
                        isGridCltInfo = true // 담보
                        isGridDlvDealcoInfo = true // 배송지
                        if (_.isEqual(value.dealcoClCd1, 'B2')) {
                            // 온라인판매점
                            isGridDlvDealcoInfo = false // 배송지
                        }
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'DC') && // 매장공통
                        _.isEqual(value.dealcoGrpCd, '8X') && // 대형유통
                        (_.isEqual(value.dealcoClCd1, 'AE') || // 대형유통망직영
                            _.isEqual(value.dealcoClCd1, 'AF')) // 대영유통망위탁
                    ) {
                        isGridStrdInfo = true // 기본정보
                        isGridEtcAddInfo = true // 추가정보
                        isGridBizRgstInfo = true // 사용자등록정보
                        isGridAcntInfo = true // 계좌정보
                        isGridCltInfo = true // 담보
                        isGridDlvDealcoInfo = true // 배송지
                        if (_.isEqual(value.dealcoClCd1, 'AE')) {
                            // 대형유통망직영
                            isGridCltInfo = false // 담보
                        }
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'DS') && // 매장개별
                        _.isEqual(value.dealcoGrpCd, 'XZ') && // 기타(1)
                        (_.isEqual(value.dealcoClCd1, '81') || // 특판처
                            _.isEqual(value.dealcoClCd1, 'A9') || // 오입금환불
                            _.isEqual(value.dealcoClCd1, 'XZ')) // 기타거래처(1)
                    ) {
                        isGridStrdInfo = true // 기본정보
                        isGridEtcAddInfo = true // 추가정보
                        isGridBizRgstInfo = true // 사용자등록정보
                        isGridAcntInfo = true // 계좌정보
                        isGridCltInfo = true // 담보
                        isGridDlvDealcoInfo = true // 배송지
                        if (
                            _.isEqual(value.dealcoClCd1, '81') || // 특판처
                            _.isEqual(value.dealcoClCd1, 'A9') // 오입금환불
                        ) {
                            isGridBizRgstInfo = false // 사용자등록정보
                            isGridAcntInfo = false // 계좌정보
                            isGridCltInfo = false // 담보
                            isGridDlvDealcoInfo = false // 배송지
                        }
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'DS') && // 매장개별
                        _.isEqual(value.dealcoGrpCd, 'ZZ') && // 물류창고
                        (_.isEqual(value.dealcoClCd1, 'Z1') || // 물류창고
                            _.isEqual(value.dealcoClCd1, 'Z2')) // 위탁물류창고
                    ) {
                        isGridStrdInfo = true // 기본정보
                        isGridEtcAddInfo = true // 추가정보
                        isGridBizRgstInfo = false // 사용자등록정보
                        isGridAcntInfo = false // 계좌정보
                        isGridCltInfo = false // 담보
                        isGridDlvDealcoInfo = true // 배송지
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'EC') && // 기타공용
                        _.isEqual(value.dealcoGrpCd, '2X') && // 제조사
                        _.isEqual(value.dealcoClCd1, '20') // 제조사
                    ) {
                        isGridStrdInfo = true // 기본정보
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'EC') && // 기타공용
                        _.isEqual(value.dealcoGrpCd, '7X') && // 금융사
                        (_.isEqual(value.dealcoClCd1, '70') || // 카드사
                            _.isEqual(value.dealcoClCd1, '83') || // VAN사
                            _.isEqual(value.dealcoClCd1, '71')) // 은행
                    ) {
                        isGridStrdInfo = true // 기본정보
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'ES') && // 기타개별
                        _.isEqual(value.dealcoGrpCd, 'XX') && // 기타
                        (_.isEqual(value.dealcoClCd1, '30') || // 매입처
                            _.isEqual(value.dealcoClCd1, 'XX')) // 기타거래터(2)
                    ) {
                        isGridStrdInfo = true // 기본정보
                    }
                }

                if (!_.isEqual(this.orgInfo.orgCdLvl0, 'O00000')) {
                    // PS&M인 경우 담보노출
                    isGridCltInfo = false // 담보
                }

                this.storeSet('isGridStrdInfo', isGridStrdInfo) // 기본정보
                this.storeSet('isGridEtcAddInfo', isGridEtcAddInfo) // 추가정보
                this.storeSet('isGridBizRgstInfo', isGridBizRgstInfo) // 사용자등록정보
                this.storeSet('isGridAcntInfo', isGridAcntInfo) // 계좌정보
                this.storeSet('isGridCltInfo', isGridCltInfo) // 담보
                this.storeSet('isGridDlvDealcoInfo', isGridDlvDealcoInfo) // 배송지

                this.dealcoClCd1 = value.dealcoGrpCd
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        etcAddInfoData1: {
            handler: function (value) {
                const dealCoCl1 = this.dealcoClCd1
                const dealCoCl2 = value.dealcoClCd2
                const dealCoCl3 = value.dealcoClCd3

                //거래처유형이 3차점이면 거래처유형 비활성화 (요건 - 00002292)
                if (
                    (_.isEqual(dealCoCl1, 'A2') ||
                        _.isEqual(dealCoCl1, 'B1') ||
                        _.isEqual(dealCoCl1, 'AD') ||
                        _.isEqual(dealCoCl1, 'AE') ||
                        _.isEqual(dealCoCl1, 'A3') ||
                        _.isEqual(dealCoCl1, 'B2') ||
                        _.isEqual(dealCoCl1, 'D1') ||
                        _.isEqual(dealCoCl1, 'M1') ||
                        _.isEqual(dealCoCl1, 'E1') ||
                        _.isEqual(dealCoCl1, 'M2') ||
                        _.isEqual(dealCoCl1, 'AC')) &&
                    _.isEqual(dealCoCl2, '3')
                ) {
                    this.isDisabled('isDisabledDataDealcoCl2_1', true)
                } else {
                    this.isDisabled('isDisabledDataDealcoCl1_1', true)
                    this.isDisabled('isDisabledDataDealcoCl2_1', true)
                }

                if (
                    this.isDisabledDataDealcoCl2_1 &&
                    _.isEqual(this.reqParam.ifYn, 'Y') &&
                    (_.isEmpty(this.strdInfoData1.dealcoCd) ||
                        _.isEmpty(dealCoCl2))
                ) {
                    this.isDisabled('isDisabledDataDealcoCl2_1', false)
                }

                // 전자결재
                if (
                    (_.isEqual(dealCoCl1, 'A2') ||
                        _.isEqual(dealCoCl1, 'A3') ||
                        _.isEqual(dealCoCl1, 'AC') ||
                        _.isEqual(dealCoCl1, 'AD') ||
                        _.isEqual(dealCoCl1, 'AE') ||
                        _.isEqual(dealCoCl1, 'B1') ||
                        _.isEqual(dealCoCl1, 'B2') ||
                        _.isEqual(dealCoCl1, 'E1') ||
                        _.isEqual(dealCoCl1, 'M1') ||
                        _.isEqual(dealCoCl1, 'M2')) &&
                    _.isEqual(dealCoCl2, '2')
                ) {
                    this.earvYn = 'Y'
                } else if (
                    (_.isEqual(dealCoCl1, 'A6') ||
                        _.isEqual(dealCoCl1, 'A7')) &&
                    (_.isEqual(dealCoCl2, '1') || _.isEqual(dealCoCl2, '2')) &&
                    (_.isEqual(dealCoCl3, '1') || _.isEqual(dealCoCl3, '2'))
                ) {
                    this.earvYn = 'Y'
                } else if (
                    _.isEqual(dealCoCl1, 'AF') &&
                    _.isEqual(dealCoCl2, '1') &&
                    (_.isEqual(dealCoCl3, '1') || _.isEqual(dealCoCl3, '2'))
                ) {
                    this.earvYn = 'Y'
                } else {
                    this.earvYn = 'N'
                }
                this.storeSet(
                    'isDisabledDataEarvYn',
                    _.isEqual(this.earvYn, 'N') ? true : false
                )
            },
            deep: true,
            immediate: true,
        },
        _addMgmtDealCoImsi: {
            handler: function (values) {
                console.log('_addMgmtDealCoImsi ->', values)
                if (!_.isEmpty(values)) {
                    // 거래처코드가 존재하면
                    this.imsiSave()
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        _earvImsi3: {
            handler: function (values) {
                if (!_.isEmpty(values)) {
                    let param = { ...this.params }
                    if (!_.isEqual(values, '6')) {
                        param.mibiYn = values
                    }
                    this.storeSet('params', param)
                    this.imsiSave3()
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        _earvImsi4: {
            handler: function (values) {
                if (!_.isEmpty(values)) {
                    let param = { ...this.params }
                    if (!_.isEqual(values, '6')) {
                        param.mibiYn = values
                    }
                    this.storeSet('params', param)
                    this.imsiSave4()
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        _newEffStaDtm: {
            handler: function (values) {
                if (!_.isEmpty(values)) {
                    this.save()
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>
