<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 재고이동대상관리
 * 설명: 재고이동대상관리를 조회, 등록한다.
 * 작성자: P179229
 * 작성일: 2022.07.15
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>재고이동대상관리</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="this.objAuth"
                >
                    완료
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="listBtn"
                    :objAuth="this.objAuth"
                >
                    목록
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="재고이동대상관리 내역"
                :gridObj="this.gridObj"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
            />
        </div>
        <!-- //gridWrap -->
        <!-- popup -->
        <DisDtrDisMovReqMovPopup
            v-if="showDisDtrDisMovReqMovDtl === true"
            ref="popup"
            :dialogShow.sync="showDisDtrDisMovReqMovDtl"
            :dtlData.sync="dtlParam"
        />
        <!-- // popup -->
    </div>
</template>

<script>
import { CommonGrid } from '@/utils'
import {
    DisDtrDisMovObjMgmtGRID_HEADER,
    DisDtrDisMovObjMgmtGRID_LAYOUT,
} from '@/const/grid/dis/dtr/disDtrDisMovObjMgmtHeader'
import disDtrDisMovObjMgmtApi from '@/api/biz/dis/dtr/disDtrMovObjMgmt'
import DisDtrDisMovReqMovPopup from './DisDtrDisMovReqMovPopup'
import CommonMixin from '@/mixins'
import store from '@/store'
import _ from 'lodash'

export default {
    name: 'DisDtrDisMovObjMgmt',
    mixins: [CommonMixin],
    components: { DisDtrDisMovReqMovPopup },
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: DisDtrDisMovObjMgmtGRID_HEADER,
            listSearch: {},
            showDisDtrDisMovReqMovDtl: false,
            dtlParam: {},
            reqParam: {},
        }
    },
    computed: {},
    created() {
        // 화면 default설정
        this.defaultSet()
    },
    mounted() {
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.setColumnLayout(DisDtrDisMovObjMgmtGRID_LAYOUT)
        //버튼클릭
        this.gridObj.gridView.onCellItemClicked = this.onCellItemClicked
        // 리스트 검색조건
        this.listSearch = this.$route.params.search
        this.reqParam = this.$route.params.datas
        // 재고이동대상 목록조회
        this.getDisDtrDisMovObjMgmtLists()
    },
    methods: {
        defaultSet() {
            this.gridData = this.gridSetData()
        },
        gridSetData: function () {
            // CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(-1, 10, '', '')
        },
        //재고이동대상 목록 조회
        getDisDtrDisMovObjMgmtLists: function () {
            disDtrDisMovObjMgmtApi
                .getDisDtrDisMovObjMgmtLists(this.reqParam)
                .then((res) => {
                    //Get Row Data
                    this.gridObj.setRows(res.disDtrDisMovObjMgmtListVo)
                    //버튼세팅
                    this.setProcessBtn()
                    //수량 keyIn
                    this.gridObj.gridView.setCurrent({
                        itemIndex: 0,
                        fieldName: 'asgnReqQty',
                    })
                    this.gridObj.gridView.showEditor()
                    store.dispatch('setApiLoading', false)
                })
        },
        setProcessBtn() {
            const rowCount = this.gridObj.dataProvider.getRowCount()
            for (var i = 0; i < rowCount; i++) {
                let row = this.gridObj.dataProvider.getJsonRow(i)
                if (
                    _.get(row, 'reqStCd') !== '05' &&
                    _.get(row, 'asgnStCd') !== '02' &&
                    _.get(row, 'asgnStCd') !== '03' &&
                    _.get(row, 'asgnStCd') !== '04'
                ) {
                    this.gridObj.gridView.setValue(i, 'asgnBtn', '확인')
                }
                if (
                    _.get(row, 'asgnStCd') === '02' ||
                    _.get(row, 'asgnStCd') === '04'
                ) {
                    this.gridObj.gridView.setValue(i, 'movOutBtn', '이동')
                }
            }
            this.gridObj.gridView.commit()
        },
        onCellItemClicked(grid, index, clickData) {
            this.gridObj.gridView.commit()
            let current = this.gridObj.gridView.getCurrent()
            const rowData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow,
                true
            )
            if (clickData.fieldName === 'asgnBtn') {
                this.savePrc('asgn', rowData, current.dataRow)
            } else if (clickData.fieldName === 'movOutBtn') {
                this.savePrc('mov', rowData, current.dataRow)
            }
        },
        savePrc(type, rowData, index) {
            if (type === 'asgn') {
                if (!this.isValidChk(rowData, index)) {
                    const rowCount = this.gridObj.dataProvider.getRowCount()
                    for (var i = 0; i < rowCount; i++) {
                        let row = this.gridObj.dataProvider.getJsonRow(i)
                        this.gridObj.gridView.setValue(
                            i,
                            'asgnReqQty',
                            _.get(row, 'asgnOrignReqQty')
                        )
                    }
                    this.gridObj.gridView.setCurrent({
                        itemIndex: index,
                        fieldName: 'asgnReqQty',
                    })
                    this.gridObj.gridView.showEditor()
                } else {
                    let confirmStr = '저장 하시겠습니까?'
                    if (
                        _.get(rowData, 'asgnStCd') === '02' ||
                        _.get(rowData, 'asgnStCd') === '03'
                    ) {
                        confirmStr =
                            '이미 확정, 거부한 상태입니다. 재요청 하시겠습니까?'
                    }
                    this.showTcComConfirm(confirmStr).then((confirm) => {
                        if (confirm) {
                            let saveData = Object.assign({}, rowData)
                            saveData.reqMgmtNo = this.reqParam.reqMgmtNo
                            disDtrDisMovObjMgmtApi
                                .saveDisDtrDisMovObjAsgn(saveData)
                                .then((res) => {
                                    // 정상등록
                                    store.dispatch('setApiLoading', true)
                                    if (res === 1) {
                                        setTimeout(() => {
                                            this.getDisDtrDisMovObjMgmtLists()
                                        }, 2000)
                                    }
                                })
                        }
                    })
                }
            } else if (type === 'mov') {
                this.dtlParam.reqMgmtNo = this.reqParam.reqMgmtNo
                this.dtlParam.asgnSeq = _.get(rowData, 'asgnSeq')
                this.showDisDtrDisMovReqMovDtl = true
            }
        },
        isValidChk(rowData, index) {
            if (_.get(rowData, 'asgnReqQty') === undefined) {
                this.showTcComAlert('배정수량을 입력해 주십시오..')
                return false
            }
            if (
                _.isEmpty(_.get(rowData, 'asgnStCd')) &&
                _.get(rowData, 'asgnReqQty') == 0
            ) {
                this.showTcComAlert('배정수량을 입력해 주십시오...')
                return false
            }
            if (_.get(rowData, 'asgnReqQty') > _.get(rowData, 'disQty')) {
                this.showTcComAlert('보유재고 이하로만 배정할수 있습니다.')
                return false
            }
            const allData = this.gridObj.dataProvider.getJsonRows(0, -1)
            let asgnReqQtyTotal = _.get(rowData, 'asgnReqQty')
            allData.forEach((data, i) => {
                if (i !== index) {
                    var row = this.gridObj.dataProvider.getJsonRow(i)
                    if (_.get(row, 'asgnStCd') !== '03') {
                        asgnReqQtyTotal += _.get(row, 'asgnOrignReqQty')
                    }
                }
            })
            if (asgnReqQtyTotal > this.reqParam.reqQty) {
                this.showTcComAlert(
                    '총 ' +
                        this.reqParam.reqQty +
                        '개 이하로만 배정할수 있습니다.'
                )
                return false
            }
            return true
        },
        //목록
        saveBtn() {
            this.showTcComConfirm('재고이동 완료처리 하시겠습니까?').then(
                (confirm) => {
                    if (confirm) {
                        //완료처리
                        this.reqParam.reqStCd = '05'
                        disDtrDisMovObjMgmtApi
                            .saveDisDtrDisMovReqStCd(this.reqParam)
                            .then((res) => {
                                // 정상등록
                                if (res === 1) {
                                    this.listBtn()
                                }
                            })
                    }
                }
            )
        },
        //목록
        listBtn() {
            this.$router.push({
                name: '/dis/dtr/DisDtrDisMovReqPrst',
                params: { search: this.listSearch },
            })
        },
    },
}
</script>
