import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        //사용여부 추가 20221004
        {
            fieldName: 'trmsItmCd', // 전송항목
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmNm', // 전송항목코드명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accTypCd', // 전표유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accTypNm', // 전표유형명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq', // No
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'firtKey', // 전기키
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'firtKeyNm', // 전기키명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'specGlCd', // 특별 GL
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'crdrClCd', // 차/대
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'crdrClNm', // 차/대
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'invFirtKey', // 역전기키
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'invFirtKeyNm', // 역전기키명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'invSpecGlCd', // 역특별 GL
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'glAccountCd', // GL 계정
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'glAccountNm', // 계정내역
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // 수정횟수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn', // 사용여부
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'trmsItmCd',
            fieldName: 'trmsItmCd',
            type: 'data',
            width: '100',
            header: '전송항목',
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'trmsItmNm',
            fieldName: 'trmsItmNm',
            type: 'data',
            width: '200',
            header: '전송항목코드명',
            mergeRule: {
                criteria: 'value["trmsItmCd"] + value',
            },
        },
        {
            name: 'accTypNm',
            fieldName: 'accTypNm',
            type: 'data',
            header: '전표유형',
            mergeRule: {
                criteria: 'value["trmsItmCd"] +value["trmsItmNm"] + value',
            },
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            header: 'No',
        },
        {
            name: 'firtKeyNm',
            fieldName: 'firtKeyNm',
            type: 'data',
            header: '전기키',
        },
        {
            name: 'specGlCd',
            fieldName: 'specGlCd',
            type: 'data',
            header: '특별 GL',
        },
        {
            name: 'crdrClNm',
            fieldName: 'crdrClNm',
            type: 'data',
            header: '차/대',
        },
        {
            name: 'invFirtKeyNm',
            fieldName: 'invFirtKeyNm',
            type: 'data',
            header: '역전기키',
        },
        {
            name: 'invSpecGlCd',
            fieldName: 'invSpecGlCd',
            type: 'data',
            header: '역특별 GL',
        },
        {
            name: 'glAccountCd',
            fieldName: 'glAccountCd',
            type: 'data',
            header: 'GL 계정',
        },
        {
            name: 'glAccountNm',
            fieldName: 'glAccountNm',
            type: 'data',
            header: '계정내역',
        },
        {
            name: 'delYn',
            fieldName: 'delYn',
            type: 'data',
            header: '사용여부',
        },
    ],
}
