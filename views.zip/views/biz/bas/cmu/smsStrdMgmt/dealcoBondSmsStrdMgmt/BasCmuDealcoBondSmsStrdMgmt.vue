<!-----------------------------------------------
 * 업무그룹명: 기준정보>기타
 * 서브업무명: SMS기준관리-위탁거래처채권SMS기준관리
 * 설명: SMS기준관리-위탁거래처채권SMS기준관리 조회/입력/수정 한다.
 * 작성자: P180392
 * 작성일: 2022.08.04
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <!-- <div class="content"> -->
    <div>
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/cmu/smsStrdMgmt/dealcoBondSmsStrdMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/cmu/smsStrdMgmt/dealcoBondSmsStrdMgmt'

export default {
    name: 'BasCmuDealcoBondSmsStrdMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (
            this.$store.hasModule('bas.cmu.dealcoBondSmsStrdMgmtStore') != true
        ) {
            this.$store.registerModule(
                'bas.cmu.dealcoBondSmsStrdMgmtStore',
                store
            )
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (
            this.$store.hasModule('bas.cmu.dealcoBondSmsStrdMgmtStore') == true
        ) {
            this.$store.unregisterModule('bas.cmu.dealcoBondSmsStrdMgmtStore')
        }
    },

    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>

<style></style>
