<template>
    <TCComDialog :dialogShow.sync="showRegPopup" size="700px">
        <template #content>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
            <div class="layerPop overflow-y-auto long">
                <div class="layerCont">
                    <p class="popTitle mt30">부가상품 등록</p>
                    <div class="fl_left wd43p">
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridStoreHeader"
                                ref="gridStoreHeader"
                                gridTitle="선택 부가상품"
                                :gridObj="gridObj1"
                            />
                            <TCRealGrid
                                id="gridStore"
                                ref="gridStore"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                    </div>

                    <div class="fl_left btn_ds">
                        <div class="div5_5 cont3">
                            <ul class="btnOrder">
                                <li>
                                    <TCComButton
                                        :Vuetify="false"
                                        color=""
                                        eClass="btnOrderleft"
                                        @click="onLeft"
                                    >
                                    </TCComButton>
                                </li>
                                <li>
                                    <TCComButton
                                        :Vuetify="false"
                                        color=""
                                        eClass="btnOrderright"
                                        @click="onRight"
                                    >
                                    </TCComButton>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="fl_left wd43p">
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridStoreListHeader"
                                ref="gridStoreListHeader"
                                gridTitle="전체 부가상품"
                                :gridObj="gridObj"
                            />
                            <TCRealGrid
                                id="gridStoreList"
                                ref="gridStoreList"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                    </div>

                    <!--layerCont-->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { FileUtil } from '@/utils'
import * as XLSX from 'xlsx'
import CommonMixin from '@/mixins'
import { LIST_HEADER } from '@/const/grid/bas/pdm/basPdmAgnSvcRegHeader'
import API from '@/api/biz/bas/pdm/basPdmAgnSvcReg'
import CommonUtil from '@/utils/CommonUtil.js'
import _ from 'lodash'
export default {
    name: 'BasPdmAgnSvcReg',
    mixins: [CommonMixin],
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
        // 유무선 구분 탭 인덱스
        parentTabIndex: { type: Number },

        // parentParam: { type: Object, default: () => [], required: false },
    },
    data() {
        return {
            gridObj: {},
            gridData: {},
            gridHeaderObj: {},
            gridObj1: {},
            gridData1: {},
            gridHeaderObj1: {},
            objAuth: {},
            forms: {
                bbsTypeCd: '',
            },
            gridList: [],
            showAlertBool: false,
            headerText: '',
            alertBodyText: '',
            view: LIST_HEADER,
            showBool: false,
            files: null,

            // 저장 관련
            saveList: [],
        }
    },
    computed: {
        showRegPopup: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },

    watch: {
        // parentParam: {
        //     handler: function (value) {
        //         console.log('parentParam', value)
        //         this.parentParam = value
        //     },
        //     deep: true, // 속성 내부까지 감시
        //     immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        // },
    },

    created() {},
    mounted() {
        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.gridStoreList
        this.gridHeaderObj = this.$refs.gridStoreListHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, false, true, false)

        this.gridObj1 = this.$refs.gridStore
        this.gridHeaderObj1 = this.$refs.gridStoreHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj1.setGridState(false, false, true, false)
        this.initGrid()

        if (this.parentTabIndex === 0) {
            this.getAllSvcList()
        } else {
            this.getAllTkpList()
        }
    },
    methods: {
        init: function () {
            this.gridData = this.gridSetData()
        },
        async onClick() {
            this.showBool = true
        },
        initGrid() {
            // 그리드 이벤트 처리
            if (!this.rows.length) {
                this.onLeft()
            } else {
                this.onRight()
            }
        },
        getAllSvcList() {
            console.log('getAllSvcList start...')
            API.getAllSvcList().then((res) => {
                console.log('res : ', res)
                this.gridList = res
                this.gridObj.setRows(this.gridList)
                let pageInfo = {}
                pageInfo.type = 'noPaging' //페이징이 없는경우
                pageInfo.totalDataCnt = this.gridObj.dataProvider.getRowCount()
                this.gridObj.setGridIndicator(pageInfo)
            })
        },
        getAllTkpList() {
            console.log('getAllTkpList start...')
            API.getAllTkpList().then((res) => {
                console.log('res : ', res)
                this.gridList = res
                this.gridObj.setRows(this.gridList)
                let pageInfo = {}
                pageInfo.type = 'noPaging' //페이징이 없는경우
                pageInfo.totalDataCnt = this.gridObj.dataProvider.getRowCount()
                this.gridObj.setGridIndicator(pageInfo)
            })
        },
        onClose() {
            this.showRegPopup = false
        },
        onLeft() {
            //체크된
            let chkRow = this.gridObj.gridView.getCheckedRows(true)
            //체크된 행 이동
            for (var i = 0; i < chkRow.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(chkRow[i])
                //그리드에 표시
                this.gridObj1.dataProvider.insertRow(0, row)
            }
            this.gridObj.dataProvider.removeRows(chkRow)
        },
        onRight() {
            let chkRow = this.gridObj1.gridView.getCheckedRows(true)
            //체크된 행 이동
            for (var i = 0; i < chkRow.length; i++) {
                let row = this.gridObj1.dataProvider.getJsonRow(chkRow[i])
                //그리드에 표시
                this.gridObj.dataProvider.addRow(row)
            }
            this.gridObj1.dataProvider.removeRows(chkRow)
        },
        onConfirm() {
            // const jsonData = this.gridObj1.dataProvider.getJsonRows()
            // this.$emit('confirm', jsonData)
            console.log('개발중...')
            this.showTcComAlert('This is Test Alert')
            this.onClose()
        },
        onExcelUpload() {
            this.$refs.fileExcelTemplate.clearFileInputValue()
            this.gridObj1.dataProvider.clearRows()
            this.$refs.fileExcelTemplate.fileInputClick()
        },
        onFilesChange(files) {
            this.excelUploadFile(files)
        },
        excelUploadFile(files) {
            const f = files
            if (!_.isUndefined(f) && !_.isNull(f)) {
                const reader = new FileReader()

                reader.onload = (e) => {
                    const data = e.target.result
                    // Array Buffer인 경우 base64로 변환 처리
                    const arr = FileUtil.arrayBufferFixdata(data)
                    const workbook = XLSX.read(FileUtil.encodeBase64(arr), {
                        type: 'base64',
                        cellText: true,
                        cellDates: true,
                    })
                    // 워크북 처리(1줄 헤더 포함 처리)
                    this.processWorkbook(workbook)
                }
                reader.readAsArrayBuffer(f)
            }
        },

        // 워크북 처리(1줄 헤더 포함 처리)
        processWorkbook(wb) {
            const output = FileUtil.excelTojson(wb)
            const sheetNames = Object.keys(output)

            if (sheetNames.length) {
                const colsObj = output[sheetNames][0]
                if (colsObj) {
                    const data = output[sheetNames]
                    let lists = this.gridList
                    let arrayIdx = []
                    console.log('processWorkbook: ', data)
                    if (CommonUtil.checkJsonStrDocSecurity(data)) {
                        this.showTcComAlert(
                            '문서보안 엑셀 파일입니다.\n확인 후 다시 업로드해주세요.'
                        )
                        return
                    }

                    data.map((item) => {
                        for (let idx = 0; idx < this.gridList.length; idx++) {
                            if (lists[idx].dealcoCd == Object.values(item)) {
                                this.gridObj1.dataProvider.insertRow(
                                    0,
                                    lists[idx]
                                )
                                //console.log('1111111111', lists[idx])
                                arrayIdx.push(idx)
                            }
                        }
                    })
                    this.gridObj.dataProvider.removeRows(arrayIdx)
                }
            }
        },
    },
}
</script>
<style scoped>
.fl_left {
    display: block;
    float: left;
}
.wd40p {
    width: 40%;
}
.wd43p {
    width: 43%;
}
.btn_ds {
    width: 13%;
    height: 60px;
    position: relative;
    margin-top: 25%;
}
.left {
    float: left;
}

.right {
    float: right;
}
</style>
