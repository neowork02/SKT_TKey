export const TEST_DATA_SACBAS00400 = [
    {
        orgNm: '조직1',
        orgCd: '00001',
        accClNm: '카드',
        effStaDt: '2022-03-24',
        effEndDt: '2022-04-24',
        bankNm: '국민은행',
        acntNo: '10020',
        orgLevel: 1,
        accSeq: 1,
        accCl: '01',
    },
    {
        orgNm: '조직2',
        orgCd: '00002',
        accClNm: '카드',
        effStaDt: '2022-03-24',
        effEndDt: '2022-04-24',
        bankNm: '우리은행',
        acntNo: '11024',
        orgLevel: 2,
        accSeq: 2,
        accCl: '01',
    },
]

export const TEST_DATA_SACBAS00100 = [
    {
        trmsClCd: 'S01',
        trmsClNm: '전송항목코드명',
        accTypCd: 'K5',
        seq: '023',
        firtKey: '40',
        specGlCd: '',
        crdrClCd: '1',
        invFirtKey: '50',
        invSpecGlCd: '',
        glAcntCd: '627100',
        glAcntNm: '계정내역',
    },
    {
        trmsClCd: 'S01',
        trmsClNm: '전송항목코드명',
        accTypCd: 'K5',
        seq: '024',
        firtKey: '40',
        specGlCd: '',
        crdrClCd: '1',
        invFirtKey: '50',
        invSpecGlCd: '',
        glAcntCd: '201000',
        glAcntNm: '계정내역',
    },
    {
        trmsClCd: 'S01',
        trmsClNm: '전송항목코드명',
        accTypCd: 'K5',
        seq: '025',
        firtKey: '40',
        specGlCd: '',
        crdrClCd: '2',
        invFirtKey: '50',
        invSpecGlCd: '',
        glAcntCd: '623100',
        glAcntNm: '계정내역',
    },
    {
        trmsClCd: 'B26',
        trmsClNm: '전송항목코드명',
        accTypCd: 'T3',
        seq: '001',
        firtKey: '01',
        specGlCd: '',
        crdrClCd: '1',
        invFirtKey: '11',
        invSpecGlCd: '',
        glAcntCd: '500101',
        glAcntNm: '계정내역',
    },
    {
        trmsClCd: 'B26',
        trmsClNm: '전송항목코드명',
        accTypCd: 'T3',
        seq: '002',
        firtKey: '01',
        specGlCd: '',
        crdrClCd: '1',
        invFirtKey: '11',
        invSpecGlCd: '',
        glAcntCd: '500103',
        glAcntNm: '계정내역',
    },
    {
        trmsClCd: 'B26',
        trmsClNm: '전송항목코드명',
        accTypCd: 'T3',
        seq: '003',
        firtKey: '01',
        specGlCd: '',
        crdrClCd: '1',
        invFirtKey: '11',
        invSpecGlCd: '',
        glAcntCd: '200400',
        glAcntNm: '계정내역',
    },
]

export const TEST_DATA_SACBAS01100_ORG = [
    {
        orgNm2: '영업본부',
        orgCd2: 'AA140',
        orgNm3: '영업팁',
        orgCd3: '00011',
        clCd: 'XY',
        ukeyAgencyCd: 'D94100',
        ukeyAgencyNm: 'ukeyAgencyNm',
        seq: 'seq',
        ukeySubCd: 'DDDD',
        tCode: 'T33021',
        effStaDt: '20210701',
        effEndDt: '99991231',
        dChk: 'dChk',
    },
    {
        orgNm2: '영업본부',
        orgCd2: 'AA1190',
        orgNm3: '영업팁',
        orgCd3: '00011',
        clCd: 'AY',
        ukeyAgencyCd: 'D93100',
        ukeyAgencyNm: 'ukeyAgencyNm',
        seq: 'seq',
        ukeySubCd: 'DDDD',
        tCode: 'BBB',
        effStaDt: '20210707',
        effEndDt: '99991231',
        dChk: 'dChk',
    },
]

export const TEST_DATA_SACBAS01100_DEAL = [
    {
        orgNm2: '영업본부',
        orgCd2: 'AA1190',
        orgNm3: '영업팁',
        orgCd3: '00011',
        newOrgCd: 'AC1143',
        newOrgNm: 'newOrgNm',
        dealCoGrp: 'YY',
        dealCoClCd: '',
        dealCoClNm: '',
        dealStaDt: '',
        dealEndDt: '99991231',
        dealCoCd: 'A169231',
        dealCoNm: '우진텔레콤개인',
        ukeyAgencyCd: 'D93100',
        ukeySubCd: 'DDDD',
        effStaDt: '20210707',
        effEndDt: '99991231',
        tCode: 'BBB',
    },
    {
        orgNm2: '영업본부',
        orgCd2: 'AA1190',
        orgNm3: '영업팀',
        orgCd3: '00011',
        newOrgCd: 'AA1143',
        newOrgNm: 'newOrgNm',
        dealCoGrp: 'YY',
        dealCoClCd: '',
        dealCoClNm: '',
        dealStaDt: '',
        dealEndDt: '99991231',
        dealCoCd: 'A169314',
        dealCoNm: 'UB통신할부 개인',
        ukeyAgencyCd: 'D00148',
        ukeySubCd: 'DDDD',
        effStaDt: '20210707',
        effEndDt: '99991231',
        tCode: 'BBB',
    },
]

export const TEST_DATA_SACBAS00300 = [
    {
        accountCd: '100000',
        accountNm: '현금-원화',
        accountAbbrNm: '현금-원화',
        addInfo1: '11',
        addInfo2: '22',
        addInfo3: '33',
        addInfo4: '44',
        addInfo5: '55',
        updCnt: '1',
        delYn: 'N',
    },
]

export const TEST_DATA_SACLED01300 = [
    {
        orgNm2: '수도권유통1본부',
        orgNm3: '강남소매팀',
        newOrgNm: '강남소매(PT)',
        saleDealcoCd: '80473',
        saleDealcoNm: '강남지점',
        feesAmt1st: '직영점',
        chag1StAmt: '269760',
        sale1StAmt: '2574140',
        pedi1StAmt: '2612240',
        pcpg1StAmt: '0',
        pamtAmt1st: '0',
        saleSum1StAmt: '0',
        feesAmt2nd: '1980',
        chag2NdAmt: '1980',
        sale2NdAmt: '1591960',
        pedi2NdAmt: '1763950',
        pcpg2NdAmt: '0',
        pamtAmt2nd: '0',
        saleSum2NdAmt: '0',
        etcSaleAmt: '770',
        bondBamt: '770',
        updCnt: '0',
        delYn: 'N',
    },
]

export const TEST_DATA_SACINQ01800 = [
    {
        agencyNm: '대리점이름',
        agencyCd: '대리점코드',
        crncyCd: '통화유형',
        cashDpstClCd: '예수금구분',
        pdayBamt: '1763950',
        hqRmpAmt: '1591960',
        tdayBamt: '1980',
        erpRmtAmt: '269760',
        erpTrmsClCd: 'erp전송구분',
        erpTrmsDtm: '20200418',
    },
]

export const TEST_DATA_TAXCUS00400 = [
    {
        orgId2Nm: '사업담당',
        orgIdNm: '영업팀',
        cfmCnt: '2',
        cfmAmt: '2000',
        othCnt: '3',
        othAmt: '3000',
    },
]

export const TEST_DATA_SACLED00500 = [
    {
        chk: '',
        trmsDt: '202201',
        orgNm: '인천도매팀',
        orgCd: '111', // ---
        trmsItmNm: '판매회계추정',
        trmsItmCd: 'S01', // ---
        trmsAmt: '25716794',
        totCnt: '1',
        tranTryCnt: '0',
        tranCnt: '1',
        tranErrCnt: '0',
        tranNotCnt: '0',
    },
    {
        chk: '',
        trmsDt: '202201',
        orgNm: '북부도매팀',
        orgCd: '222', // ---
        trmsItmNm: '판매회계추정',
        trmsItmCd: 'S01', // ---
        trmsAmt: '539778508',
        totCnt: '1',
        tranTryCnt: '0',
        tranCnt: '0',
        tranErrCnt: '0',
        tranNotCnt: '1',
    },
]

export const TEST_DATA_SACLED00600 = [
    {
        chk: '',
        chkable: '1',
        trmsDt: '202205',
        orgNm: '인천도매팀',
        accDealcoCd: '정산처코드',
        accDealcoNm: '정산처',
        trmsItmNm: '전송구분',
        trmsAmt: '2100456',
        trmsReqYn: 'Y',
        trmsReqDtm: '20220505',
        trmsYn: '1',
        trmsDtm: '20220506',
        rmks: '비고',
    },
    {
        chk: '',
        trmsDt: '202205',
        orgNm: '인천도매팀2',
        accDealcoCd: '정산처코드2',
        accDealcoNm: '정산처2',
        trmsItmNm: '전송구분2',
        trmsAmt: '21004560',
        trmsReqYn: 'N',
        trmsReqDtm: '',
        trmsYn: 'N',
        trmsDtm: '',
        rmks: '비고',
    },
]

export const TEST_DATA_SACLED01200 = [
    {
        chk: '',
        orgNm: '조직명',
        dealCoCd: '거래처코드1',
        dealCoNm: '거래처명',
        trmsItmCd: 'B12',
        trmsItmNm: '[B12]카드매출발생',
        trmsReqItemNm: '미처리',
        reqUserId: '마감요청자',
        reqDtm: '22020102034420',
        rmks: '비고',
        trmsReqClCd: '0',
    },
    {
        chk: '',
        orgNm: '조직명2',
        trmsItmCd: 'B17',
        trmsItmNm: '락해제-현금',
        trmsReqItemNm: '미처리',
        reqUserId: '',
        reqDtm: '',
        rmks: '',
        trmsReqClCd: '1',
    },
    {
        chk: '',
        orgNm: '조직명3',
        dealCoCd: '거래처코드3',
        dealCoNm: '거래처명',
        trmsItmCd: 'B27',
        trmsItmNm: '잡이익',
        trmsReqItemNm: '미처리',
        reqUserId: '마감요청자',
        reqDtm: '22021130032020',
        rmks: '비고',
        trmsReqClCd: '0',
    },
]

export const TEST_DATA_SACTAX00100 = [
    {
        chk: '',
        orgNm: '동부도매팀', //조직명
        orgCd: 'AA1100',
        orglvl: '3',
        taxClNm: '매출세금계산서(정발행)', // 구분
        taxClCd: '50',
        splyPrc: '32814000', // 공급가액
        vatAmt: '3281400', // 부가세액
        totAmt: '36095400', // 합계

        totalCnt: '164', // 전체건수
        tranTry: '0', // 전송요청건수
        tranCnt: '164', // 전송건수
        tranErr: '0', // 전송오류건수
        tranNot: '0', // 미전송건수
    },
    {
        chk: '',
        orgNm: '대구도매팀', //조직명
        orgCd: 'AA2200',
        orglvl: '3',
        taxClNm: '매출세금계산서(정발행)', // 구분
        taxClCd: '50',
        splyPrc: '28903636', // 공급가액
        vatAmt: '2890364', // 부가세액
        totAmt: '31794000', // 합계

        totalCnt: '163', // 전체건수
        tranTry: '0', // 전송요청건수
        tranCnt: '162', // 전송건수
        tranErr: '0', // 전송오류건수
        tranNot: '1', // 미전송건수
    },
]

export const TEST_DATA_SACTAX00200 = [
    {
        orgNm: '중부도매팀',
        dealcoClCd: '100000',
        dealcoClNm: '우리동네 핸드폰',
        bizNo: '8360800439',
        taxClNm: '매출세금계산서(정발행)',
        splyPrc: '70000',
        vatAmt: '7000',
        totAmt: '77000',
        dealEndYn: 'N',
        trmsReqYn: 'Y',
        trmsReqDtm: '20220117111401',
        reqUserId: '홍**동',
        trmsYn: '전송 성공',
        trmsDtm: '20220117123351',
        rmks: '',
    },
    {
        orgNm: '중부도매팀',
        dealcoClCd: '100009',
        dealcoClNm: '우리동네 핸드폰',
        bizNo: '5090363196',
        taxClNm: '매출세금계산서(정발행)',
        splyPrc: '210000',
        vatAmt: '21000',
        totAmt: '231000',
        dealEndYn: 'N',
        trmsReqYn: 'N',
        trmsReqDtm: '',
        reqUserId: '',
        trmsYn: '',
        trmsDtm: '',
        rmks: '',
    },
]

export const TEST_DATA_SACTAX00400 = [
    {
        chk: '',
        orgNm: '조직',
        accPlc: '정산처',
        accPlcNm: '정산처명',
        zbudat: '귀속일자',
        zifdate: '전송일시',
        zgubun: '전송구분',
        ztrusr: '전송자',
        zcnt: '0',
        zconfirm: '1',
        zdele: 'N',
        zitem: 'zitem',
    },
    {
        chk: '',
        orgNm: '조직2',
        accPlc: '정산처2',
        accPlcNm: '정산처명2',
        zbudat: '귀속일자2',
        zifdate: '전송일시2',
        zgubun: '전송구분2',
        ztrusr: '전송자2',
        zcnt: '2',
        zconfirm: '2',
        zdele: 'N',
        zitem: 'zitem2',
    },
    {
        chk: '',
        orgNm: '조직3',
        accPlc: '정산처3',
        accPlcNm: '정산처명3',
        zbudat: '귀속일자3',
        zifdate: '전송일시3',
        zgubun: '전송구분3',
        ztrusr: '전송자3',
        zcnt: '3',
        zconfirm: '7',
        zdele: 'Y',
        zitem: 'zitem3',
    },
]

export const TEST_DATA_SACSAP01030 = [
    {
        chk: '',
        adjStCd: 'CFM',
        saleQty: '1',
        saleAmt: '1234000',
        splyPrc: '1200',
        vatAmt: '123400',
    },
    {
        chk: '',
        adjStCd: 'TMP',
        saleQty: '10',
        saleAmt: '2234000',
        splyPrc: '2200',
        vatAmt: '223400',
    },
    {
        chk: '',
        adjStCd: 'TEST',
        saleQty: '2',
        saleAmt: '200000',
        splyPrc: '1000',
        vatAmt: '20000',
    },
]

export const TEST_DATA_SACSAP01020 = [
    {
        saleDtm: '20211201', // 판매일
        wrtDt: '20211202', // 전기일
        evdDt: '20211203', // 증빙일
        refId: 'TE117194052', // refId
        saleClNm: '추정',
        saleClCd: '', // 판매구분코드
        saleChnlNm: '소매',
        saleChnlCd: '', // 영업채널코드
        refSeq: '1',
        accDealcoNm: 'SK텔레콤(주)',
        accDealcoCd: '10001', // 정산처코드
        saleDealcoNm: '역삼역점',
        saleDealcoCd: '57553', // 판매처코드
        arClNm: '상품매출-T할부 USIM',
        arClCd: '0001',
        arSeq: '1',
        saleQty: '10',
        saleAmt: '2500',
        splyPrc: '2000',
        vatAmt: '200',
    },
    {
        saleDtm: '20211201',
        wrtDt: '20211202',
        evdDt: '20211203',
        refId: 'NA002055376',
        refSeq: '1',
        accDealcoNm: '역삼역점',
        accDealcoCd: '57553',
        saleDealcoNm: '역삼역점',
        saleDealcoCd: '57553',
        arClNm: '상품매출-단말기',
        arClCd: '0002',
        arSeq: '2',
    },
]
export const TEST_DETAIL_DATA_SACSAP01020 = [
    {
        trClNm: '정상',
        arClNm: '상품매출-T할부 USIM',
        arClCd: '0001',
        saleQty: '-1',
        splyPrc: '-6090',
        vatAmt: '-609',
        wrtDt: '20211202',
        evdDt: '20211203',
    },
    {
        trClNm: '정상',
        arClNm: '상품매출-T할부 USIM',
        arClCd: '0001',
        saleQty: '1',
        splyPrc: '6090',
        vatAmt: '609',
        wrtDt: '20211202',
        evdDt: '20211203',
    },
]
