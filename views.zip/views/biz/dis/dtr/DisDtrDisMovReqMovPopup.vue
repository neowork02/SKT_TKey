<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 재고이동요청(출고) 이동
 * 설명: 재고이동요청 이동을 처리한다.
 * 작성자: P179229
 * 작성일: 2022.07.22
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">재고이동</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.asgnDealcoNm"
                                    :readonly="true"
                                    labelName="출고처"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.reqDealcoNm"
                                    :readonly="true"
                                    labelName="입고처"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInputSearchText
                                    v-model="reqParam.prodCd"
                                    :codeVal.sync="reqParam.prodNm"
                                    labelName="모델"
                                    :readonlyAfter="true"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.colorNm"
                                    labelName="색상"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.mfactNm"
                                    labelName="제조사"
                                    :readonly="true"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.petNm"
                                    labelName="펫네임"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    codeId="ZDIS_C_00662"
                                    labelName="개봉상태"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.reqClCd"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    :itemList="chkData"
                                    labelName="대표모델"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.repProdYn"
                                />
                            </div>
                            <div class="formitem div1">
                                <TCComRadioBox
                                    :itemList="chkData"
                                    labelName="색상무관"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.colorUnrelYn"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.qckSvcCoNm"
                                    labelName="퀵서비스 업체명"
                                    :readonly="true"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.qckSvcTelNo"
                                    :readonly="true"
                                    labelName="퀵서비스 연락처"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.asgnReqQty"
                                    labelName="요청수량"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                    </div>
                    <!-- // Search_div -->

                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="popupGridHeader"
                            ref="popupGridHeader"
                            gridTitle="재고이동대상"
                            :gridObj="gridObj"
                        />
                        <TCRealGrid
                            id="popupGrid"
                            ref="popupGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>
                    <!-- //gridWrap -->
                    <!-- Close BTN-->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            v-show="reqParam.asgnStCd === '02'"
                            @click="saveBtn"
                        >
                            이동
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty01"
                            @click="closeBtn"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="closeBtn()"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import disDtrDisMovObjMgmtApi from '@/api/biz/dis/dtr/disDtrMovObjMgmt'
import { DisDtrDisMovReqMovPopupGRID_HEADER } from '@/const/grid/dis/dtr/disDtrDisMovReqMovPopupHeader'
import CommonMixin from '@/mixins'

export default {
    name: 'DisDtrDisMovReqMovPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: DisDtrDisMovReqMovPopupGRID_HEADER,
            reqParam: this.dtlData,
            chkData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
        }
    },
    created() {},
    mounted() {
        this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.popupGridHeader
        this.gridObj.setGridState(false, false, false)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        //요청정보 조회
        this.getDisDtrDisMovReqMovDtl()
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        defaultSet() {
            this.gridData = this.gridSetData()
        },
        gridSetData: function () {
            // CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(-1, 10, '', '')
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        //요청상세조회
        getDisDtrDisMovReqMovDtl() {
            disDtrDisMovObjMgmtApi
                .getDisDtrDisMovReqMovDtl(this.reqParam)
                .then((res) => {
                    this.reqParam = Object.assign(
                        {},
                        res.disDtrDisMovReqMovDtlVo
                    )
                    //Get Row Data
                    this.gridObj.setRows(res.disDtrDisMovReqMovVo)
                })
        },
        //이동
        saveBtn() {
            let saveData = Object.assign({}, this.reqParam)
            let chkData = []
            this.gridObj.gridView.commit()
            const rowCount = this.gridObj.dataProvider.getRowCount()
            for (var i = 0; i < rowCount; i++) {
                var rowData = this.gridObj.dataProvider.getJsonRow(i)
                chkData.push(rowData)
            }
            this.showTcComConfirm('이동을 하시겠습니까?').then((confirm) => {
                if (confirm) {
                    saveData.serNumList = chkData
                    disDtrDisMovObjMgmtApi
                        .saveDisDtrDisMovReqMov(saveData)
                        .then((res) => {
                            // 정상
                            if (res === 1) {
                                this.getDisDtrDisMovReqMovDtl()
                                this.$parent.getDisDtrDisMovObjMgmtLists()
                            }
                        })
                }
            })
        },
    },
}
</script>
