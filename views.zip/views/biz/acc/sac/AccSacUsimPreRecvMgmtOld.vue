<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 신품자급 USIM후불예수금 기준관리
 * 설명: 조회, 저장
 * 작성자: P180190
 * 작성일: 2022.08.01
------------------------------------------------>
<template>
    <div class="content">
        <h1>신품자급 USIM후불예수금 기준관리</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="init()"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSave"
                    >저장</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        placeholder="입력해주세요"
                        :eRequired="true"
                        :disabled="false"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :codeVal.sync="reqParam.srchOrgCd"
                        v-model="reqParam.orgNm"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="reqParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="신품자급 USIM후불예수금 기준관리"
                :gridObj="gridObj"
                :isAddRow="true"
                :isDelRow="true"
                :isExceldown="true"
                :isPageCnt="true"
                :isNextPage="true"
                :isPageRows="true"
                @addRowBtn="gridAddRowBtn"
                @chkDelRowBtn="gridDelRowBtn"
                @excelDownBtn="downloadExcelAll"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :gridObj="gridObj"
                :columns="view.columns"
                :styles="gridStyle"
                :editable="true"
            />
            <!-- <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getUsimPayList"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            /> -->
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
import { CommonUtil } from '@/utils'
import { msgTxt } from '@/const/msg.Properties.js'
import usimPreApi from '@/api/biz/acc/sac/AccSacUsimPreRecvMgmt'
import { GRID_HEADER } from '@/const/grid/acc/sac/AccSacUsimPreRecvMgmtGrid'
import CommonMixin from '@/mixins'
//  내부조직팝업(권한)
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
import moment from 'moment'
//  //내부조직팝업(권한)
export default {
    name: 'AccSacUsimPreRecvMgmt',
    title: '신품자급 USIM후불예수금 기준관리',
    components: {
        BasBcoAuthOrgTreesPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,

            //Grid
            objAuth: {},
            tabDefault: {},
            // gridData: {},
            gridObj: {},
            gridHeaderObj: {},

            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            reqParam: {
                srchOrgCd: '', // 조직코드
                srchCoClOrgCd: '', // 조직명
                srchOrgLvl: '', // 조직레벨
                // basMth: '', //기준일자
                // orgLvl: '', //조직level
                // orgCdLvl0: '', //레벨0조직코드
            },
            // 행추가 기본 json
            defaultJson: {
                ssupOrgNm: '',
                supOrgNm: '',
                orgCd: '',
                orgNm: '',
                usimPayYn: '',
                aplyStaDt: '',
                aplyEndDt: '',
            },
            // 업데이트 요청 파람
            param: {
                srchCoClOrgCd: '',
                usimPayList: [],
            },
            //요청 파라미터
            searchForms: {
                srchOrgCd: '',
                srchCoClOrgCd: '',
                srchOrgLvl: '',
            },

            //행 추가 입력된 데이터 리스트
            gridDatas: [],
            changedDatas: [],

            //기존 그리드 데이터 리스트
            oldGridList: [],

            // rowCnt: 15,

            //  내부조직팝업(권한)
            showBcoAuthOrgTrees: false,
            resultAuthOrgTreeRows: [],
            //  내부조직팝업(권한)

            //row cnt
            gridLastIndex: 0,
            nowGridIndex: 0,
            gridRows: 0,

            newAplyEndDt: '',
        }
    },
    mounted() {
        // 그리드 세팅
        this.gridObj = this.$refs.grid
        this.gridObj.setGridState(false, true, false, false)
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridHeaderObj = this.$refs.gridHeader

        //상위공통코드 그리드 클릭이벤트
        this.gridObj.gridView.onCellButtonClicked = (grid, clickData) => {
            //선택한그리드
            this.selectDataRow = clickData.dataRow
            //빈곳클릭시작업없음
            if (undefined == this.selectDataRow) {
                return
            }

            if ('orgNm' == clickData.fieldName) {
                this.onAuthGridOrgTreeIconClick()
            }
            this.selectBdataRow = clickData.dataRow
        }

        this.init()
    },
    computed: {},
    watch: {},
    created() {
        // this.gridData = this.gridSetData()
    },
    methods: {
        // 초기화
        init() {
            this.$refs.grid.setRows([])
            // 조직 초기화
            if (!_.isEmpty(this.orgInfo['orgCd'])) {
                this.reqParam.srchOrgCd = this.orgInfo['orgCd']
                this.reqParam.orgNm = this.orgInfo['orgNm']
                this.reqParam.srchOrgLvl = this.orgInfo['orgLvl']
                this.reqParam.srchCoClOrgCd = this.orgInfo['orgCdLvl0']
                console.log('orgInfo:::::', this.orgInfo)
            }
            // 현재 그리드 cnt 초기화
            this.nowGridIndex = 0
            this.gridLastIndex = 0
            // param 초기화
            this.param = {}
            // 수정 초기화
            this.gridObj.gridView.commit()
        },

        // gridSetData(rowCnt) {
        //     return new CommonGrid(0, rowCnt, '', '')
        // },

        //페이지 표시 행의수 변경처리
        // chgRowCnt(val) {
        //     this.rowCnt = val
        // },

        //================================================
        // 전체 조회 :::::::getUsimPayList
        //================================================
        async onSearch() {
            this.changedDatas.saveRows = []
            this.changedDatas = this.gridObj.setModifyData(this.changedDatas)
            console.log('this.gridData.saveRows : ', this.changedDatas.saveRows)

            if (this.changedDatas.saveRows.length > 0) {
                //변경/추가 된 내용이 있으면 confirm 확인
                const confirm = await this.showTcComConfirm(msgTxt.MSG_00168)
                if (confirm) {
                    this.onSearchData()
                } else {
                    return
                }
            } else {
                this.onSearchData()
            }
        },
        onSearchData: function () {
            //조회 조직 입력 확인
            const orgCd = this.reqParam.srchOrgCd
            if (_.isEmpty(orgCd)) {
                this.showTcComAlert('조직을 입력하십시오.')
                return
            }
            this.searchForms = { ...this.reqParam }
            this.getUsimPayList()
            console.log('전체조회 ::::::: 시작', this.searchForms)
        },

        getUsimPayList() {
            usimPreApi.getUsimPayList(this.searchForms).then((res) => {
                if (res) {
                    console.log('전체리스트조회 ::::::: ', res)
                    this.gridObj.dataProvider.clearRows()
                    this.gridObj.dataProvider.beginUpdate()
                    this.gridObj.setRows(res.gridList)
                    this.oldGridList = res.gridList
                    this.gridObj.dataProvider.endUpdate()
                    // this.gridObj.setGridIndicator(res.pagingDto)
                    // this.gridData = this.gridSetData()
                    // console.log(this.gridData)
                    // this.gridHeaderObj.setPageCount(res.pagingDto)
                    // console.log('pagingDto', res.pagingDto)
                    console.log('전체리스트조회 ::::::: 끝')
                    // 조회된 데이터의 length
                    this.gridRows = res.gridList.length
                    console.log(':::::::총 건수' + this.gridRows + '건:::::::')
                    // 고정
                    this.gridIndex = this.gridObj.dataProvider.getRowCount()
                    // 동적으로 변경될 rowcnt
                    this.nowGridIndex = this.gridObj.dataProvider.getRowCount()
                    // this.gridData.totalPage = res.pagingDto.totalPageCnt
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },

        //================================================
        // 행추가
        //================================================
        gridAddRowBtn: function () {
            this.gridObj.gridView.commit()
            //조회된 결과값이 없을시 행추가 방지
            if (this.nowGridIndex == 0) {
                return
            }
            // 행추가 되면 해당 위치로 focused 하기
            let focuscell = this.gridObj.gridView.getCurrent()
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
            // row cnt 변경
            this.gridRows = this.gridHeaderObj.addRow(this.gridRows)
            this.nowGridIndex = this.gridObj.dataProvider.getRowCount()
            this.gridLastIndex = this.gridObj.dataProvider.getRowCount() - 1
            //행추가 기본값 세팅하기
            this.defaultJson = {}
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'ssupOrgNm',
                this.defaultJson.ssupOrgNm
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'supOrgNm',
                this.defaultJson.supOrgNm
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'orgNm',
                this.defaultJson.orgNm
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'usimPayYn',
                this.defaultJson.usimPayYn
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'aplyStaDt',
                this.defaultJson.aplyStaDt
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'aplyEndDt',
                this.defaultJson.aplyEndDt
            )
            this.gridObj.gridView.getSelectedRows(-1)
            this.gridObj.gridView.commit()
        },
        //================================================
        // 행삭제
        //================================================
        gridDelRowBtn: function () {
            // 조회된 데이터 행삭제 방지
            if (
                this.gridIndex == this.nowGridIndex ||
                this.gridLastIndex == 0
            ) {
                return
            }

            this.gridObj.dataProvider.removeRow(this.gridLastIndex)
            this.nowGridIndex = this.gridObj.dataProvider.getRowCount()
            this.gridLastIndex = this.gridObj.dataProvider.getRowCount() - 1
        },
        //================================================
        // insert/udate validation
        //================================================
        AplyDtChk() {
            this.gridDatas = []
            this.gridObj.gridView.commit()
            //변경된 행 데이터 가져오기
            this.gridDatas = this.gridObj.setModifyData(this.gridDatas)
            this.param.usimPayList = this.gridDatas.saveRows
            // 변경 여부 확인
            if (_.isEmpty(this.param.usimPayList)) {
                this.showTcComAlert(msgTxt.MSG_01002)
                return false
            }
            for (var i = 0; i < this.param.usimPayList.length; i++) {
                if (_.isEmpty(this.param.usimPayList[i].orgCd)) {
                    this.showTcComAlert(
                        msgTxt.MSG_01002 + '\n 조직을 선택해 주세요.'
                    )
                    return false
                }
                // USIM 후불예수금 적용
                if (
                    this.param.usimPayList[i].usimPayYn == 1 &&
                    (this.param.usimPayList[i].__rowState == 'created' ||
                        this.param.usimPayList[i].__rowState == 'updated')
                ) {
                    this.param.usimPayList[i].aplyStaDt = moment(
                        new Date()
                    ).format('YYYY-MM-DD')
                    if (this.param.usimPayList[i].aplyEndDt == undefined) {
                        this.param.usimPayList[i].aplyEndDt = '99991231'
                        this.newAplyEndDt = this.param.usimPayList[i].aplyEndDt
                    }
                    if (this.param.usimPayList[i].aplyEndDt != undefined) {
                        this.param.usimPayList[i].aplyEndDt = '99991231'
                    }
                    console.log(
                        ':::::' +
                            this.param.usimPayList[i].__rowState +
                            ' 로직 처리:::::'
                    )
                    // ****USIM 후불예수금 적용 Y일경우 시작/종료일자 체크*****
                    // 시작/종료일자 입력 여부 확인
                    if (
                        this.param.usimPayList[i].usimPayYn == 1 &&
                        this.param.usimPayList[i].aplyStaDt == undefined
                    ) {
                        this.showTcComAlert(
                            '적용시작일자/적용종료일자를 입력하십시오.'
                        )
                        return false
                    }
                    // 시작일자가 종료일자 보다 큰지 체크
                    if (
                        this.newAplyEndDt != undefined &&
                        CommonUtil.onlyNumber(
                            this.param.usimPayList[i].aplyStaDt
                        ) > this.param.usimPayList[i].aplyEndDt
                    ) {
                        this.showTcComAlert(
                            this.param.usimPayList[i].orgNm +
                                '의 적용시작일자가 적용종료일자보다 큽니다.'
                        )
                        return false
                    }
                    //if 행추가(created)
                    if (this.param.usimPayList[i].__rowState == 'created') {
                        // 새로 입력된 종료일자
                        this.param.usimPayList[i].aplyEndDt = '99991231'

                        // 행추가인 경우 기존에 입력된 동일한 PT의 적용시작/종료일자 중복 여부를 체크
                        for (var j = 0; j < this.oldGridList.length; j++) {
                            if (
                                this.param.usimPayList[i].orgCd ==
                                this.oldGridList[j].orgCd
                            ) {
                                // 기존 입력된 종료일자
                                var oldAplyEndDt
                                if (
                                    CommonUtil.onlyNumber(
                                        this.oldGridList[j].aplyEndDt
                                    ) > 0
                                ) {
                                    oldAplyEndDt = CommonUtil.onlyNumber(
                                        this.oldGridList[j].aplyEndDt
                                    )
                                } else {
                                    oldAplyEndDt = '99991231'
                                }

                                // 새로 입력된 시작일자가 기존 입력된 시작일자보다 작거나
                                // 새로 입력된 시작일자가 기존 입력된 시작/종료일자 구간이면 입력불가
                                if (
                                    CommonUtil.onlyNumber(
                                        this.param.usimPayList[i].aplyStaDt
                                    ) < this.oldGridList[j].aplyStaDt
                                ) {
                                    this.showTcComAlert(
                                        this.param.usimPayList[i].orgNm +
                                            '적용시작일자가 기존에 입력된 시작일자보다 작습니다.'
                                    )
                                    return false
                                }
                                if (
                                    CommonUtil.onlyNumber(
                                        this.param.usimPayList[i].aplyStaDt
                                    ) >= this.oldGridList[j].aplyStaDt &&
                                    CommonUtil.onlyNumber(
                                        this.param.usimPayList[i].aplyStaDt
                                    ) <= oldAplyEndDt
                                ) {
                                    this.showTcComAlert(
                                        this.param.usimPayList[i].orgNm +
                                            '적용시작일자가 기존에 입력된 시작/종료일자 구간입니다.'
                                    )
                                    return false
                                }
                                // 새로 입력된 종료일자가 기존 입력된 시작일자보다 작거나
                                // 새로 입력된 종료일자가 기존 입력된 시작/종료일자 구간이면 입력불가
                                if (
                                    this.newAplyEndDt <
                                    CommonUtil.onlyNumber(
                                        this.oldGridList[j].aplyStaDt
                                    )
                                ) {
                                    this.showTcComAlert(
                                        this.param.usimPayList[i].orgNm +
                                            '종료일자가 기존에 입력된 시작일자보다 작습니다다.'
                                    )
                                    return false
                                }
                                if (
                                    this.newAplyEndDt >=
                                        CommonUtil.onlyNumber(
                                            this.oldGridList[j].aplyStaDt
                                        ) &&
                                    this.newAplyEndDt <= oldAplyEndDt
                                ) {
                                    this.showTcComAlert(
                                        this.param.usimPayList[i].orgNm +
                                            '종료일자가 기존에 입력된 시작/종료일자 구간입니다.'
                                    )
                                    return false
                                }
                            }
                        }
                    }
                    console.log(
                        ':::::' +
                            this.param.usimPayList[i].__rowState +
                            ' 로직 처리 종료:::::'
                    )
                } else {
                    this.param.usimPayList[i].aplyEndDt = moment(
                        new Date()
                    ).format('YYYY-MM-DD')
                }
            }
        },

        //================================================
        // 저장:::::::::saveUsimPay
        //================================================
        onSave() {
            // 시작/종료일자 체크
            if (this.AplyDtChk() == false) {
                return
            }
            this.saveUsimPay()
        },
        saveUsimPay() {
            usimPreApi.saveUsimPay(this.param).then((res) => {
                if (res) {
                    console.log('저장완료 :::::::')
                    this.changedDatas.saveRows = []
                    this.onSearchData()
                } else {
                    console.log('저장실패 :::::::')
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },

        //================================================
        // EXCEL DOWNLOAD
        //================================================
        downloadExcelAll: function () {
            usimPreApi.downloadUsimPayListExcel(this.searchForms)
            console.log('엑셀다운로드 :::::::')
        },

        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.reqParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.srchOrgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.srchOrgLvl = _.get(res[0], 'vLevel')
                        this.reqParam.srchCoClOrgCd = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        onAuthGridOrgTreeIconClick() {
            this.resultAuthOrgTreeRows = []
            // this.getAuthOrgTreeList()
            this.showBcoAuthOrgTrees = true
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.srchOrgCd = ''
            this.reqParam.srchOrgLvl = ''
            this.reqParam.srchCoClOrgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리

        onAuthOrgTreeReturnData(returnData) {
            // 행추가 -> 조직검색 버튼 클릭시 추가된 그리드에 조직정보 세팅
            if (this.gridLastIndex <= this.nowGridIndex) {
                console.log('returnData: ', returnData)
                this.defaultJson.ssupOrgNm = _.get(returnData, 'orgNmLvl1')
                this.defaultJson.supOrgNm = _.get(returnData, 'orgNmLvl2')
                this.defaultJson.orgNm = _.get(returnData, 'orgNm')
                this.defaultJson.orgCd = _.get(returnData, 'orgCd')
                let selectedRow = this.gridObj.gridView.getSelectedRows()
                this.gridObj.gridView.setValue(
                    selectedRow[0],
                    'ssupOrgNm',
                    this.defaultJson.ssupOrgNm
                )
                this.gridObj.gridView.setValue(
                    selectedRow[0],
                    'supOrgNm',
                    this.defaultJson.supOrgNm
                )
                this.gridObj.gridView.setValue(
                    selectedRow[0],
                    'orgNm',
                    this.defaultJson.orgNm
                )
                this.gridObj.gridView.setValue(
                    selectedRow[0],
                    'orgCd',
                    this.defaultJson.orgCd
                )
            } else console.log('returnData: ', returnData)
            this.reqParam.srchOrgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.srchOrgLvl = _.get(returnData, 'orgLvl')
            this.reqParam.srchCoClOrgCd = _.get(returnData, 'orgCdLvl0')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
    },
}
</script>
