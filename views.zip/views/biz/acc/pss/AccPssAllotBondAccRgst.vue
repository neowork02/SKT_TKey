<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">할부채권정산등록</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Top BTN -->
                    <ul class="btn_area pop">
                        <li class="right">
                            <!--  <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="clearBtn"
                                :objAuth="objAuth"
                            >
                                초기화
                            </TCComButton> -->
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="saveBtn"
                                :objAuth="objAuth"
                                :disabled="disabledBtnSave"
                            >
                                확정
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="delBtn"
                                :objAuth="objAuth"
                                :disabled="disabledBtnDel"
                            >
                                삭제
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="closeBtn"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton>
                        </li>
                    </ul>
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                    <!-- // Top BTN -->
                    <div class="contBoth">
                        <div class="searchLayer_wrap">
                            <!-- Search_line 1 -->
                            <div class="searchform">
                                <!-- item 1-1 -->
                                <div class="formitem div3">
                                    <TCComInput
                                        labelName="대리점"
                                        :disabled="true"
                                        v-model="searchFormData.sktAgencyNm"
                                        :disabledAfter="true"
                                    >
                                    </TCComInput>
                                </div>
                                <!-- //item 1-1 -->
                                <!-- item 1-2 -->
                                <div class="formitem div3">
                                    <TCComDatePicker
                                        labelName="정산월"
                                        calType="M"
                                        eClass="div2"
                                        v-model="searchFormData.accYm"
                                        :disabled="true"
                                    >
                                    </TCComDatePicker>
                                </div>
                                <div class="formitem div3">
                                    <TCComInput
                                        labelName="정산처"
                                        :objAuth="objAuth"
                                        v-model="searchFormData.accDealcoCd"
                                        :disabled="true"
                                    >
                                    </TCComInput>
                                </div>
                                <!-- // item 1-2 -->
                            </div>
                        </div>
                        <!-- //Search_div -->
                    </div>
                    <div class="gridWrap">
                        <!-- SubTit -->
                        <TCRealGridHeader
                            id="popupGridHeader1"
                            ref="popupGridHeader1"
                            gridTitle="할부채권 정산 내역"
                            :isExceldown="true"
                            :gridObj="gridObj"
                            :gridHeaderObj="gridHeaderObj"
                            @excelDownBtn="exportAllotBondAccDtl"
                        >
                            <template #gridElementArea>
                                <TCComDatePicker
                                    labelName="확정일자"
                                    calType="D"
                                    eClass="div2"
                                    v-model="searchFormData.wrtDt"
                                >
                                </TCComDatePicker>
                            </template>
                        </TCRealGridHeader>
                        <!-- @isExceldown="this.exportGridBtn" -->
                        <!-- // SubTit -->
                        <!-- gridWrap -->
                        <TCRealGrid
                            id="popupGrid1"
                            ref="popupGrid1"
                            :fields="view.fields"
                            :columns="view.columns"
                            :gridObj="gridObj"
                            :styles="gridStyle"
                        />
                    </div>
                    <div class="formitem div2">
                        <TCRealGridHeader
                            id="popupGridHeader2"
                            ref="popupGridHeader2"
                            gridTitle="할부채권 공제 내역"
                            :gridHeaderObj="gridHeaderObj2"
                            :gridObj="gridObj"
                        />
                        <div class="gridWrap">
                            <TCRealGrid
                                id="popupGrid2"
                                ref="popupGrid2"
                                :fields="view2.fields"
                                :columns="view2.columns"
                                :gridObj="gridObj2"
                                :styles="gridStyle2"
                            />
                        </div>
                    </div>
                    <!-- //gridWrap -->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
//import Prototype2Popup from './prototype2Popup'
import {
    GRID_POP_HEADER,
    GRID_POP_HEADER2,
} from '@/const/grid/acc/pss/AccPssAllotBondAccRgstGrid'
import moment from 'moment'
import pssApi from '@/api/biz/acc/pss'
//  세션정보
import CommonMixin from '@/mixins'
export default {
    name: 'accPssAllotBondAccRgst',
    mixins: [CommonMixin],
    props: {
        //parmas
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: true, required: false },
    },
    data() {
        return {
            //Paging Class init
            gridObj: {},
            gridHeaderObj: {},
            gridObj2: {},
            gridHeaderObj2: {},
            gridStyle: {
                height: '600px',
            },
            gridStyle2: {
                height: '110px',
            },

            objAuth: {},
            list: [],
            list2: [],
            listRgsts: [],
            listSkn: [],
            saveAmt: '',
            ukeySubCd: '',
            view: GRID_POP_HEADER,
            view2: GRID_POP_HEADER2,
            localPersistent: true,
            disabledBtnDel: false,
            disabledBtnSave: false,
            searchFormData: {
                accYm: moment(new Date()).format('YYYY-MM'), // 정산월
                sktAgencyCd: '', //
                sktAgencyNm: '',
                accDealcoCd: '',
                wrtDt: moment(new Date()).format('YYYY-MM-DD'),
            },
        }
    },
    created() {},
    mounted() {
        this.searchFormData.sktAgencyCd = this.popupParams.sktAgencyCd
        this.searchFormData.sktAgencyNm = this.popupParams.sktAgencyNm
        this.searchFormData.accDealcoCd = this.popupParams.accDealcoCd
        this.searchFormData.accYm = this.popupParams.accYm
        this.searchFormData.wrtDt = moment(this.popupParams.accYm)
            .endOf('month')
            .format('YYYY-MM-DD')
        this.searchFormData.erpFixYn = this.popupParams.erpFixYn
        this.searchFormData.fixYn = this.popupParams.fixYn
        /****************** Grid **********************/
        this.gridObj = this.$refs.popupGrid1
        this.gridHeaderObj = this.$refs.popupGridHeader1
        this.gridObj2 = this.$refs.popupGrid2
        this.gridHeaderObj2 = this.$refs.popupGridHeader2
        this.gridObj.setRows()
        this.gridObj2.setRows()
        /* this.gridObj.setGridState()*/
        this.gridObj.setGridState(false, false, false, true)
        this.gridObj2.setGridState(false, false, false, true)
        this.fInit()
        /****************** Event **********************/
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        GridSetData() {},
        //초기화 버튼 이벤트
        closeBtn: function () {
            this.activeOpen = false
            this.$emit('close')
        },
        exportAllotBondAccDtl: function () {
            for (var i = 0; i < 2; i++) {
                if (i == 0) {
                    //  할부채권 정산내역 엑셀다운로드
                    pssApi.downloadAllogBondAccDtlExcel(this.searchFormData)
                } else {
                    //  할부채권 공제내역 엑셀다운로드
                    pssApi.downloadAllogBondDeductDtlExcel(this.searchFormData)
                }
            }
        },
        fInit: function () {
            this.dsDetail = []
            this.dsDetail.push({
                sktAgencyCd: this.popupParams.sktAgencyCd,
                sktAgencyNm: this.popupParams.sktAgencyNm,
                accDealcoCd: this.popupParams.accDealcoCd,
                accYm: this.popupParams.accYm,
                wrtDt: this.popupParams.wrtDt,
                seq: this.popupParams.seq,
                erpFixYn: this.popupParams.erpFixYn,
                fixYn: this.popupParams.fixYn,
            })
            this.fSearch()
        },
        fSearch: function () {
            if (this.searchFormData.sktAgencyCd == '') {
                return
            }
            pssApi
                .accPssAllotBondAccRgsts(this.searchFormData)
                .then((resultData) => {
                    this.list = resultData.listRgsts
                    this.list2 = resultData.listSkn
                    this.$refs.popupGrid1.setRows(this.list)
                    this.$refs.popupGrid2.setRows(this.list2)
                    this.ukeySubCd = resultData.ukeySubCd

                    if (this.popupParams.erpFixYn == 'Y') {
                        this.showTcComAlert(
                            'ERP전송이 완료되었습니다. 저장/삭제 할수 없습니다.'
                        )

                        this.disabledBtnSave = true
                        this.disabledBtnDel = true
                    } else if (this.popupParams.fixYn == 'Y') {
                        this.disabledBtnSave = true
                        this.disabledBtnDel = false
                        this.showTcComAlert('확정 완료되었습니다.')
                    } else {
                        this.disabledBtnSave = false
                        this.disabledBtnDel = true
                        // this.disabledBtnSave = true
                    }
                })
        },
        saveBtn: function () {
            pssApi
                .accPssAllotBondAccInsert(this.searchFormData)
                .then((resultData) => {
                    if (resultData) {
                        this.showTcComAlert('확정되었습니다.')
                        this.closeBtn()
                    }
                })
        },
        delBtn: function () {
            pssApi
                .delAccPssAllotBondAccRgst(this.searchFormData)
                .then((resultData) => {
                    if (resultData) {
                        this.showTcComAlert('삭제되었습니다.')
                        this.closeBtn()
                    }
                })
        },
    },
}
</script>
