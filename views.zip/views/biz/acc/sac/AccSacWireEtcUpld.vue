<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccSacWireEtcUpld.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <AccHeadline title="유선)기타업로드" />

        <AccSearchField
            ref="accSearchField"
            divideCellCount="3"
            :offset="[
                'btn-left-downloadForm',
                'btn-right-reset',
                'btn-right-view',
                'btn-right-save',
                'btn-right-delete',
                'search-brws',
                'search-orgCd',
                '!search-accDealcoCd',
            ]"
            :initValue="initValue"
            :popupParamOrgCd="popupParamOrgCd"
            :popupParamDealcoCd="popupParamDealcoCd"
            @changeBrws="changeBrws"
            @changeOrgCd="changeOrgCd"
            @downloadForm="downloadForm"
            @reset="resetForm"
            @view="viewForm"
            @save="saveForm"
            @delete="deleteForm"
        />

        <AccGridTable
            ref="accGridTable"
            title="유선 기타업로드 목록"
            class="accGridTable"
            isColumnNo
            isEditable
            isCheckbox
            :isExcelupParse="true"
            :offset="['btn-excelDownload']"
            :gridMeta="GRID_HEADER"
            :data="formGetSmarts.data"
            :pagingInfo="formGetSmarts.pagingInfo"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/sac/smarts-excel-download`,
                query: formGetSmarts.query,
            }"
            @movePage="movePage"
            @changePageSize="changePageSize"
            @excelUpParseloadBtn="excelUpParseloadBtn"
        >
            <template #gridElementLeftArea>
                <span class="infoTxt color-red"
                    >( * 표시된 항목만 업로드 대상입니다.) ※ 금액구분코드 :
                    스마트팩:S01, 성과보상A:S02, 성과보상B:S03, 판촉물:S04</span
                >
            </template>
        </AccGridTable>
        <v-file-input
            id="excelUpload"
            ref="excelUpload"
            label="엑셀업로드 파일선택(숨김)"
            style="display: none"
            @change="onChangeExcelFile"
        ></v-file-input>
    </div>
</template>
<style lang="scss" scoped></style>
<script>
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import {
    getTodayDate,
    distanceDate,
    errorHandle,
    // gridMetaUtil,
} from '@/utils/accUtil'

import AccHeadline from '@/components/biz/common/acc/AccHeadline'
import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import sacApi from '@/api/biz/acc/sac'
import attachApi from '@/api/common/attachedFile'

import {
    GRID_HEADER,
    MOCK_DATA,
} from '@/const/grid/acc/sac/AccSacWireEtcUpldGrid'

export default {
    name: 'AccSacWireEtcUpld',
    mixins: [CommonMixin, accMixin],
    components: {
        AccHeadline,
        AccSearchField,
        AccGridTable,
    },
    data() {
        return {
            GRID_HEADER,

            initValue: {
                brws: [
                    `${getTodayDate('YYYY-MM')}-01`,
                    getTodayDate('YYYY-MM-DD'),
                ],
                pageSize: 15,
                pageNum: 1,
            },

            popupParamOrgCd: {
                basMth: '',
            },

            popupParamDealcoCd: {},

            formGetSmarts: {
                query: {
                    useYn: '',
                },
                data: [],
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formPostXlsSmarts: {
                data: [],
                query: {},
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formDeleteSmarts: {
                query: {},
            },
        }
    },

    computed: {},

    created() {
        this.initPage()
        console.log(sacApi, MOCK_DATA)
    },
    methods: {
        initPage() {},

        resetForm() {
            this.formGetSmarts.data = []
            this.accSearchField.changeBrws([
                moment().startOf('month').format('YYYY-MM-DD'),
                moment().format('YYYY-MM-DD'),
            ])
            this.changeOrgCd({ orgCd: '', orgNm: '', orgLvl: '' })
        },

        viewForm(query) {
            if (distanceDate(query.brwsTo, query.brwsFr) < -30) {
                return this.showTcComAlert(
                    `조회기간은 30일 이내에서만 조회 가능합니다`
                )
            }

            if (distanceDate(query.brwsFr, query.brwsTo) > 0) {
                return this.showTcComAlert(`조회기간 입력이 잘못되었습니다`)
            }

            if (!query.orgCd) {
                return this.showTcComAlert(`조직을 선택해 주세요.`)
            }

            Object.assign(this.formGetSmarts.query, query)
            return this.getSmarts()
        },

        saveForm() {
            this.gridView.commit()

            const rows = this.accGridTable.getChangedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`수정된 항목이 없습니다.`)
            } else {
                const invalidList = []
                rows.forEach((row) => {
                    if (!row.wrtDt) {
                        invalidList.push({
                            msg: `전기일 데이터에 오류가 있습니다`,
                            list: row,
                        })
                    }

                    if (!row.salePlc) {
                        invalidList.push({
                            msg: `판매처 데이터에 오류가 있습니다`,
                            list: row,
                        })
                    }

                    if (!row.amtCd) {
                        invalidList.push({
                            msg: `금액구분코드에 오류가 있습니다`,
                            list: row,
                        })
                    }

                    if (!row.smrtPackAmt) {
                        invalidList.push({
                            msg: `스마트팩금액 데이터에 오류가 있습니다`,
                            list: row,
                        })
                    }
                })

                if (invalidList.length) {
                    invalidList.forEach((arr) => this.showTcComAlert(arr.msg))
                } else {
                    this.formPostXlsSmarts.query =
                        this.accSearchField.getQuery()
                    this.formPostXlsSmarts.query.listSave = rows
                    this.postXlsSmarts().then(this.getSmarts)
                }
            }
        },

        async deleteForm() {
            this.gridView.commit()

            const rows = this.accGridTable.getCheckedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                if (
                    await this.showTcComConfirm(
                        '선택한 데이터를 삭제하시겠습니까?'
                    )
                ) {
                    // 신규추가 데이터는 서버통신 없이 삭제한다
                    const savedRow = rows.filter(
                        (row) => row.status != 'created'
                    )

                    const createdRow = rows.filter(
                        (row) => row.status == 'created'
                    )

                    const removeRowIdx = []

                    if (createdRow.length) {
                        createdRow.forEach((row) => {
                            removeRowIdx.push(row.dataRow)
                        })
                    }

                    if (savedRow.length) {
                        this.formDeleteSmarts.query.listDelete = rows
                        this.deleteXlsSmarts().then(() => {
                            savedRow.forEach((row) => {
                                removeRowIdx.push(row.dataRow)
                            })

                            this.accGridTable.removeRowData(removeRowIdx)
                        })
                    } else {
                        this.accGridTable.removeRowData(removeRowIdx)
                    }
                } else {
                    this.showTcComAlert('삭제가 취소되었습니다.')
                }
            }
        },

        downloadForm() {
            attachApi.downloadSampleFile('406')
        },

        movePage(query) {
            Object.assign(this.formGetSmarts.query, query)
            this.getSmarts()
        },

        changePageSize(query) {
            this.accSearchField.setQuery(query)
            // Object.assign(this.formGetSmarts.query, query)
        },

        getSmarts() {
            // this.formGetSmarts.data = [...MOCK_DATA.resultGridDto.gridList]
            // this.formGetSmarts.pagingInfo = MOCK_DATA.resultGridDto.pagingDto

            // return Promise.resolve()
            return sacApi
                .getSmarts(this.formGetSmarts.query)
                .then((res) => {
                    this.formGetSmarts.data = [...res.resultGridDto.gridList]
                    this.formGetSmarts.pagingInfo = res.resultGridDto.pagingDto
                })
                .catch(errorHandle)
        },

        postXlsSmarts() {
            return sacApi
                .postXlsSmarts(this.formPostXlsSmarts.query)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
                .catch(errorHandle)
        },

        deleteXlsSmarts() {
            return sacApi
                .deleteXlsSmarts(this.formDeleteSmarts.query)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                    return this.getSmarts()
                })
                .catch(errorHandle)
        },

        changeBrws(date) {
            this.popupParamOrgCd.basMth = moment(date[1]).format('YYYY-MM')
            this.popupParamDealcoCd.basDay = date[1] // payEndDtm
        },

        changeOrgCd(query) {
            const { orgCd, orgNm, orgLvl } = query

            this.popupParamDealcoCd.orgLvl = orgLvl
            this.popupParamDealcoCd.orgCd = orgCd
            this.popupParamDealcoCd.orgNm = orgNm

            this.popupParamOrgCd.orgCd = orgCd
            this.popupParamOrgCd.orgNm = orgNm
        },
        // 엑셀 파일오픈
        excelUpParseloadBtn() {
            const query = this.accSearchField.getQuery()
            if (!query.orgCd) {
                this.showTcComAlert(`조직을 선택해 주세요.`)
                return false
            }
            document.getElementById('excelUpload').click()
        },

        // 엑셀로드 콜백
        onChangeExcelFile(files) {
            if (!_.isUndefined(files) && !_.isNull(files)) {
                const formData = new FormData()
                formData.append('files', files)
                sacApi.getParseExcelSmartsTcip(formData).then((res) => {
                    const query = this.accSearchField.getQuery()
                    console.log('KYJ xls ==> ', query)
                    const rows = res
                    query.listSave = rows
                    sacApi.postSmartsForXls(query).then((res) => {
                        if (res && res.listSave.length) {
                            this.formGetSmarts.data = res.listSave

                            const indexor = []
                            this.formGetSmarts.data.forEach((row, idx) =>
                                indexor.push(idx)
                            )

                            this.$nextTick(() =>
                                this.accGridTable.setRowStateInIdx(
                                    indexor,
                                    'created'
                                )
                            )
                        }
                    })
                })
                // 파일선택 inputbox의 값 제거
                document.getElementById('excelUpload').value = ''
            }
        },
    },
}
</script>
