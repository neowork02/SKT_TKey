import { ValueType } from 'realgrid'

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'fixYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: '__rowState',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'verifyYn',
            dataType: ValueType.TEXT,
            // displayCallback: filter.grid.verifyYn,
        },
        {
            fieldName: 'accMth',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'orgNm2',
        //     editable: false,
        //     header: { text: '사업담당' },
        //     type: 'data',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'orgNm3',
        //     editable: false,
        //     header: { text: '영업팀' },
        //     type: 'data',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'orgNm4',
        //     editable: false,
        //     header: { text: '영업파트' },
        //     type: 'data',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoCl1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeyChannelCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'saleCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bondAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'taxBilStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'normalYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'normalNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expireDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expObjYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expMaxAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'forceAprvYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expDueDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            fieldName: 'fixYn',
            visible: false,
        },
        {
            fieldName: '__rowState',
            visible: false,
        },
        {
            fieldName: 'verifyYn',
            editable: false,
            header: { text: '검증상태' },
            type: 'data',
            // displayCallback: filter.grid.verifyYn,
        },
        {
            fieldName: 'accMth',
            editable: false,
            header: { text: '정산월' },
            type: 'data',
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        // {
        //     fieldName: 'orgNm2',
        //     editable: false,
        //     header: { text: '사업담당' },
        //     type: 'data',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'orgNm3',
        //     editable: false,
        //     header: { text: '영업팀' },
        //     type: 'data',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'orgNm4',
        //     editable: false,
        //     header: { text: '영업파트' },
        //     type: 'data',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'orgTree',
            editable: false,
            header: { text: '조직' },
            type: 'data',
        },
        {
            fieldName: 'accDealcoCd',
            editable: false,
            header: { text: '정산처코드' },
            type: 'data',
        },
        {
            fieldName: 'accDealcoNm',
            editable: false,
            header: { text: '정산처명' },
            type: 'data',
        },
        {
            fieldName: 'sktCd',
            editable: false,
            header: { text: '매장코드' },
            type: 'data',
        },
        {
            fieldName: 'dealCoCl1',
            header: { text: '거래처구분코드' },
            visible: false,
        },
        {
            fieldName: 'dealCoClNm',
            editable: false,
            header: { text: '거래처구분' },
            type: 'data',
        },
        {
            fieldName: 'ukeyChannelCd',
            editable: false,
            header: { text: 'P코드' },
            type: 'data',
        },
        {
            fieldName: 'userId',
            editable: false,
            header: { text: '영업담당' },
            type: 'data',
        },

        {
            fieldName: 'saleCnt',
            editable: false,
            header: { text: '익월실적(1일~10일)' },
            type: 'data',
        },
        {
            fieldName: 'accAmt',
            editable: false,
            header: { text: '당월통합판매수수료' },
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
        },
        {
            fieldName: 'bondAmt',
            editable: false,
            header: { text: '채권상계금액' },
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
        },
        {
            fieldName: 'taxBilStNm',
            editable: false,
            header: { text: '전자계산서승인' },
            type: 'data',
        },
        {
            fieldName: 'normalYn',
            header: { text: '거래상태코드' },
            visible: false,
        },
        {
            fieldName: 'normalNm',
            editable: false,
            header: { text: '거래상태' },
            type: 'data',
        },
        {
            fieldName: 'expireDt',
            editable: false,
            header: { text: '담보만료일' },
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            fieldName: 'expObjYn',
            editable: false,
            header: { text: '지출대상여부' },
            type: 'data',
            displayCallback: (grid, index, value) => {
                if (value == 'Y') return '대상'
            },
        },
        {
            fieldName: 'expMaxAmt',
            editable: false,
            header: { text: '지출가능최대금액' },
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
        },
        {
            fieldName: 'forceAprvYn',
            editable: false,
            header: { text: '강제승인여부' },
            type: 'data',
            displayCallback: (grid, index, value) => {
                if (value == 'Y') return '강제승인'
            },
        },
        {
            fieldName: 'expDueDt',
            editable: false,
            header: { text: '지출예정일' },
            type: 'data',
            fieldDatetimeFormat: 'yyyyMMdd',
            columnDatetimeFormat: 'yyyy-MM-dd',
        },
        {
            fieldName: 'modUserNm',
            editable: false,
            header: { text: '처리자' },
            type: 'data',
        },
        {
            fieldName: 'modDtm',
            editable: false,
            header: { text: '처리일시' },
            type: 'data',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}
