<template>
    <span :class="spanClass">
        <v-switch
            v-model="dValue"
            inset
            :disabled="disabled"
            :readonly="readonly"
            :value="onValue"
            :rules="getRules"
            :true-value="trueValue"
            :false-value="falseValue"
            @change="emitChange"
            @click="emitClick"
        ></v-switch>
    </span>
</template>

<script>
export default {
    inheritAttrs: false,
    name: 'TCComSwitch',
    components: {},
    props: {
        // 입력값,양방향 바인딩
        value: { type: [String, Boolean], required: false },
        // value 설정
        onValue: { type: Object, default: () => {}, required: false },
        //필수입력여부
        eRequired: { type: Boolean, default: false, required: false },
        // true value 값 설정
        trueValue: { type: [String, Boolean], default: true, required: false },
        // false value 값 설정
        falseValue: {
            type: [String, Boolean],
            default: false,
            required: false,
        },
        // disabled
        disabled: { type: Boolean, default: false, required: false },
        // readonly
        readonly: { type: Boolean, default: false, required: false },
        // 함수, 부울 및 문자열의 혼합 배열을 사용할 수 있습니다.
        // 함수는 입력값을 인수로 전달하며 true/false 또는 오류 메시지를 포함하는 문자열을 반환해야 합니다.
        // 함수가 false를 반환하거나(또는 배열의 모든 값에 포함됨) 문자열인 경우 입력 필드가 오류 상태가 됩니다.
        rules: { required: false },
        // span class
        spanClass: {
            type: String,
            default: 'iteminput-type2',
            required: false,
        },
    },

    data() {
        return {
            dValue: '',
        }
    },
    computed: {
        getRules() {
            let rules = []
            if (this.rules) {
                rules = this.rules
            }
            return rules
        },
    },
    // props 동적 제어
    watch: {
        value: function () {
            this.dValue = this.value
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.dValue = this.value
        },
        emitInput(value) {
            this.$emit('input', value)
        },
        emitChange(value) {
            this.emitInput(value)
            this.$emit('change', value)
        },
        emitClick(ev) {
            this.$emit('click', ev)
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
