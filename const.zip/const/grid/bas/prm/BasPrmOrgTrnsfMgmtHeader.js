import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'reqYm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktDealCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errorLog',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'reqYm',
            fieldName: 'reqYm',
            type: 'data',
            editable: false,
            header: {
                text: '요청년월',
            },
            width: '30',
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            editable: false,
            header: {
                text: '거래처코드',
            },
            width: '30',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            editable: false,
            header: {
                text: '거래처명',
            },
        },
        {
            name: 'sktDealCd',
            fieldName: 'sktDealCd',
            editable: false,
            header: {
                text: '매장명',
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            editable: false,
            header: {
                text: '조직ID',
            },
            width: '30',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            editable: false,
            header: {
                text: '조직명',
            },
        },
        // {
        //     name: 'procStCd',
        //     fieldName: 'procStCd',
        //     editable: false,
        //     header: {
        //         text: '처리상태코드',
        //     },
        //     width: '30',
        // },
        {
            name: 'procStNm',
            fieldName: 'procStNm',
            editable: false,
            header: {
                text: '처리상태',
            },
            width: '30',
        },
        {
            name: 'errorLog',
            fieldName: 'errorLog',
            editable: false,
            header: {
                text: '에러로그',
            },
        },
    ],
}
