import { ValueType } from 'realgrid'

export const DisDsmSknOderInPrstMgmt_GRID_HEADER = {
    fields: [
        {
            fieldName: 'sknOutDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //SKN 매출일
        },
        {
            fieldName: 'inoutDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //T.key+ 입고일
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'dealCoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealCoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'dealSt',
            dataType: ValueType.TEXT, //거래상태
        },
        {
            fieldName: 'sknDelvPlcCd',
            dataType: ValueType.TEXT, //배송지코드
        },
        {
            fieldName: 'sknDelvPlcNm',
            dataType: ValueType.TEXT, //배송지명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.NUMBER, //입고(입고수량)
        },
        {
            fieldName: 'inCodeD',
            dataType: ValueType.NUMBER, //입고취소수량
        },
        {
            fieldName: 'sknTypNm',
            dataType: ValueType.TEXT, //입고수불유형
        },
    ],
    columns: [
        {
            name: 'sknOutDt',
            fieldName: 'sknOutDt',
            header: {
                text: 'SKN 매출일',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'inoutDt',
            fieldName: 'inoutDt',
            header: {
                text: '입고일',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '대리점명',
                showTooltip: false,
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoCd',
            fieldName: 'dealCoCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoNm',
            fieldName: 'dealCoNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처',
                showTooltip: false,
            },
        },
        {
            name: 'dealSt',
            fieldName: 'dealSt',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래상태',
                showTooltip: false,
            },
        },
        {
            name: 'sknDelvPlcCd',
            fieldName: 'sknDelvPlcCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배송지코드',
                showTooltip: false,
            },
        },
        {
            name: 'sknDelvPlcNm',
            fieldName: 'sknDelvPlcNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '배송지명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '입고수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'inCodeD',
            fieldName: 'inCodeD',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '입고취소수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'sknTypNm',
            fieldName: 'sknTypNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '입고수불유형',
                showTooltip: false,
            },
        },
    ],
}
