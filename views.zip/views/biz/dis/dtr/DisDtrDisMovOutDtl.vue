<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 재고이동출고 상세(등록)[DISDTR00200]
 * 설명: 재고이동출고 상세를 조회, 등록한다.
 * 작성자: P179229
 * 작성일: 2022.05.31
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>재고이동출고등록</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="addProdPop"
                    v-show="addProd"
                    >상품입력</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    v-show="addProd"
                    @click="addDisProdPop"
                    >재고상품입력</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    v-show="addProd"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    v-show="!addProd"
                    @click="deleteBtn"
                    :objAuth="this.objAuth"
                >
                    삭제
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="listBtn"
                    :objAuth="this.objAuth"
                >
                    목록
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="출고일"
                        calType="D"
                        v-model="setDate"
                        :eRequired="true"
                        :disabled="!addProd"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="masterParam.outOrgNm"
                        :codeVal.sync="masterParam.outOrgCd"
                        labelName="출고조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :eRequired="true"
                        :disabled="orgDisabled"
                        @enterKey="onOutAuthOrgTreeEnterKey"
                        @appendIconClick="onOutAuthOrgTreeIconClick"
                        @input="onOutAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showOutBcoAuthOrgTrees"
                        :parentParam="searchOutAuthOrgTreesForm"
                        :rows="resultOutAuthOrgTreeRows"
                        :dialogShow.sync="showOutBcoAuthOrgTrees"
                        @confirm="onOutAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="masterParam.outDealcoNm"
                        :codeVal.sync="masterParam.outDealcoCd"
                        labelName="출고처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :eRequired="true"
                        :disabled="dealcoDisabled"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchDealcosForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        labelName="여신잔액"
                        :objAuth="this.objAuth"
                        v-model="crdtLimit"
                        :disabled="true"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="masterParam.inOrgNm"
                        :codeVal.sync="masterParam.inOrgCd"
                        labelName="입고조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :disabled="orgDisabled2"
                        :objAuth="objAuth"
                        :eRequired="true"
                        @enterKey="onOrgTreeIconClick"
                        @appendIconClick="onOrgTreeIconClick"
                        @input="onOrgTreeInput"
                    />
                    <BasBcoOrgTreesPopup
                        v-if="showBcoOrgTrees"
                        :parentParam="searchInAuthOrgTreesForm"
                        :rows="resultOrgTreeRows"
                        :dialogShow.sync="showBcoOrgTrees"
                        @confirm="onOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="masterParam.inDealcoNm"
                        :codeVal.sync="masterParam.inDealcoCd"
                        placeholder="입력해주세요"
                        labelName="입고처"
                        :disabledAfter="true"
                        :disabled="dealcoDisabled2"
                        :objAuth="objAuth"
                        :eRequired="true"
                        @enterKey="onInrDealcosEnterKey"
                        @appendIconClick="onInrDealcosIconClick"
                        @input="onInrDealcosInput"
                    />
                    <BasBcoInrDealcosDissPopup
                        v-if="showbasBcoInrDealcos"
                        :parentParam="searchInrDealcosForm"
                        :rows="resultInrDealcosRows"
                        :dialogShow.sync="showbasBcoInrDealcos"
                        @confirm="onInrDealcosReturnData"
                    />
                </div>
            </div>
        </div>
        <!-- // Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="재고이동출고 내역"
                :gridObj="this.gridObj"
                :isExcelup="false"
                :isExceldown="!addProd"
                :isDelRow="true"
                @chkDelRowBtn="gridchkDelRowBtn"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div>
        <!-- //gridWrap -->
        <!-- textareaLayer_wrap -->
        <div class="textareaLayer_wrap">
            <!-- :disabled="true" -->
            <TCComTextArea
                v-model="masterParam.rmks"
                labelName="비고"
                class="boxtype"
                :maxLength="30"
            ></TCComTextArea>
        </div>
        <!-- //textareaLayer_wrap -->
        <!-- popup -->
        <DisDcoProdInsOutPopup
            v-if="showAddProdPop === true"
            :dialogShow.sync="showAddProdPop"
            :addProdData.sync="addProdPopParam"
            @returnVal="returnProdList"
        />
        <DisDcoProdInsDisSrchPopup
            v-if="showDisProdPop === true"
            :dialogShow.sync="showDisProdPop"
            :params="disProdParam"
            :prodOrgList="prodOrgList"
            @addDisProdList="returnProdList"
        />
        <!-- // popup -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { DisDtrDisMovOutDtlGRID_HEADER } from '@/const/grid/dis/dtr/disDtrDisMovOutDtlHeader'
import disDtrDisMovOutDtlApi from '@/api/biz/dis/dtr/disDtrMovOutDtl'
import attachedFileApi from '@/api/common/attachedFile'
import iioApi from '@/api/biz/dis/iio/disIioSaleOutMgmtDtl'
import DisDcoProdInsOutPopup from '@/views/biz/dis/dco/DisDcoProdInsOutPopup'
import DisDcoProdInsDisSrchPopup from '@/views/biz/dis/dco/DisDcoProdInsDisSrchPopup'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부조직팝업(전체)팝업====================
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
import basBcoOrgTreesApi from '@/api/biz/bas/bco/basBcoOrgTrees'
//====================//내부조직팝업(전체)팝업====================
//====================내부거래처-전체조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-전체조직==================
//====================내부조직팝업(권한)팝업====================
import BasBcoInrDealcosDissPopup from '@/components/common/BasBcoInrDealcosDissPopup'
import BasBcoInrDealcosDissApi from '@/api/biz/bas/bco/BasBcoInrDealcos'
//====================//내부조직팝업(권한)팝업====================
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'DisDtrDisMovOutDtl',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoInrDealcosDissPopup,
        DisDcoProdInsOutPopup,
        BasBcoDealcosPop,
        DisDcoProdInsDisSrchPopup,
        BasBcoOrgTreesPopup,
    },
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: DisDtrDisMovOutDtlGRID_HEADER,
            //====================출고 내부조직팝업(권한)팝업관련====================
            orgDisabled: false,
            showOutBcoAuthOrgTrees: false, // 출고 내부조직팝업(권한) 팝업 오픈 여부
            searchOutAuthOrgTreesForm: {
                orgCd: '', //출고조직id
                orgNm: '', //출고조직명
            },
            resultOutAuthOrgTreeRows: [], // 출고 내부조직팝업(권한) 팝업 오픈 여부
            //====================//출고 내부조직팝업(권한)팝업관련==================
            //====================입고 내부조직팝업(권한)팝업관련====================
            orgDisabled2: false,
            showBcoOrgTrees: false,
            searchInAuthOrgTreesForm: {
                orgCd: '', //입고조직id
                orgNm: '', //입고조직명
            },
            resultOrgTreeRows: [], // 입고 내부조직팝업(권한) 팝업 오픈 여부
            //====================//입고 내부조직팝업(권한)팝업관련==================
            //====================내부거래처-전체조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchDealcosForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
            },
            resultDealcoRows: [],
            //====================//내부거래처-전체조직==================
            //====================입고 내부거래처-재고전용 팝업관련====================
            dealcoDisabled2: false,
            showbasBcoInrDealcos: false, // 입고 내부거래처-재고전용 팝업 오픈 여부
            searchInrDealcosForm: {
                dealcoCd: '', // 입고 거래처코드
                dealcoNm: '',
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
            },
            resultInrDealcosRows: [], // 입고 내부거래처-재고전용 팝업 오픈 여부
            //====================//입고 내부거래처-재고전용 팝업관련==================
            fromDt: '',
            listSearch: {},
            addProd: true,
            dtlData: {},
            searchParam: {},
            masterParam: {
                procFlag: '', //처리구분
                outSchdDt: '', //출고일
                outOrgCd: '', //출고조직id
                outOrgNm: '', //출고조직명
                outOrgLvl: '', //출고조직level
                outDealcoCd: '', // 출고처
                outDealcoNm: '', // 출고처명
                inOrgCd: '', //입고조직id
                inOrgNm: '', //입고조직명
                inOrgLvl: '', //입고조직level
                inDealcoCd: '', // 입고처
                inDealcoNm: '', // 입고처명
                rmks: '', // 비고
            },
            prodSerNumParam: {},
            crdtLimit: 0, // 여신잔액
            showAddProdPop: false, // 상품입력팝업 호출 값
            showDisProdPop: false, // 재고상품입력팝업 호출 값
            addProdPopParam: {},
            deleleGridData: [],
        }
    },
    computed: {
        setDate: {
            get() {
                return this.fromDt
            },
            set(val) {
                this.masterParam.outSchdDt = CommonUtil.replaceDash(val)
                this.searchDealcosForm.basDay = CommonUtil.getDayFormat(
                    val,
                    'YYYYMMDD'
                )
                this.searchInrDealcosForm.basDay = CommonUtil.getDayFormat(
                    val,
                    'YYYYMMDD'
                )
                this.searchOutAuthOrgTreesForm.basMth = CommonUtil.getDayFormat(
                    val,
                    'YYYYMM'
                )
                this.searchInAuthOrgTreesForm.basMth = CommonUtil.getDayFormat(
                    val,
                    'YYYYMM'
                )
                return val
            },
        },
    },
    created() {
        // 화면 default설정
        this.defaultSet()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, true, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        // 리스트 검색조건
        this.listSearch = this.$route.params.search
        this.dtlData = this.$route.params.datas
        // 상세
        if (!_.isEmpty(this.dtlData)) {
            //재고이동출고 마스터/상세조회
            this.searchParam.outMgmtNo = this.dtlData.outMgmtNo
            this.masterParam = this.dtlData
            this.getDisDtrDisMovOutDtlLists()
            this.addProd = false
        } else {
            this.masterParam = { ...this.listSearch }
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                if (this.userInfo['attcClCd'] == '4') {
                    this.dealcoDisabled = true
                    this.orgDisabled = true
                }
            }
            if (!_.isEmpty(this.masterParam.inDealcoCd)) {
                // 여신잔액조회
                this.getCrdtLimit()
            }
        }
    },
    methods: {
        defaultSet() {
            this.gridData = this.gridSetData()
            //검색영역
            this.fromDt = moment(new Date()).format('YYYY-MM-DD') // 출고일
        },
        gridSetData: function () {
            // CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(-1, 10, '', '')
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'masterParam')
        },
        //상품입력팝업 호출
        addProdPop: function () {
            // validation
            if (!this.isMasterParamValidChk()) {
                return false
            }
            this.addProdPopParam = {
                aplyDt: this.masterParam.outSchdDt,
                outPlcId: this.masterParam.outDealcoCd,
                inOutClCd: '301', //이동출고(301)
                parentList: this.gridObj.dataProvider.getJsonRows(0, -1),
            }
            this.showAddProdPop = true
        },
        // 재고상품입력팝업 호출
        addDisProdPop() {
            if (!this.isMasterParamValidChk()) {
                return false
            }
            this.disProdParam = {
                outPlcId: this.masterParam.outDealcoCd, // 출고처ID
                outPlcNm: this.masterParam.outDealcoNm, // 출고처명
                outSchdDt: this.masterParam.outSchdDt, // 출고일
            }
            this.prodOrgList = this.gridObj.dataProvider.getJsonRows(0, -1)
            this.showDisProdPop = true
        },
        //상품입력 callback
        returnProdList(returnVal) {
            let chk = false
            this.gridObj.gridView.commit()
            if (returnVal.length > 0) {
                returnVal.forEach((data) => {
                    if (this.chkAddProdList(data)) {
                        data.prodClCd = data.prodCl
                        data.eqpClCd = data.mdlClCd
                        data.eqpClNm = data.mdlClNm
                        data.disStCd = data.disSt
                        data.mfactCd = data.mfactId
                        data.barCdType = data.barCdTyp
                        if (data['outQty'] == null) {
                            data['outQty'] = data['qty']
                        }
                        // 상품 append
                        this.gridObj.dataProvider.insertRow(
                            this.gridObj.gridView.getItemCount(),
                            data
                        )
                    } else {
                        chk = true
                    }
                })
            }
            if (chk) {
                this.showTcComAlert(
                    '중복된 일련번호를 제외하고 추가하였습니다.'
                )
            }
        },
        //상품입력 일련번호 중복체크
        chkAddProdList(data) {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.gridObj.dataProvider.getJsonRow(i)
                    if (
                        _.get(row, 'prodCd') === data.prodCd &&
                        _.get(row, 'serNum') === data.serNum
                    ) {
                        return false
                    }
                }
            }
            return true
        },
        //저장
        saveBtn: function () {
            // validation
            if (!this.isMasterParamValidChk()) {
                return false
            }
            var addInnData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(addInnData)) {
                this.showTcComAlert('상품은 반드시 한개이상 등록해야 합니다.')
                return
            }
            let saveData = {}
            if (this.addProd) {
                // 단가합계
                const totalPrc = this.gridObj.gridView.getSummary(
                    'unitPrc',
                    'sum'
                )
                if (this.crdtLimit < totalPrc) {
                    this.showTcComAlert('입고처의 여신잔액을 초과하였습니다.')
                    return
                }
                //출고일 체크
                if (
                    moment(new Date()).format('YYYYMMDD').substr(0, 6) >
                    this.masterParam.outSchdDt.substr(0, 6)
                ) {
                    this.showTcComAlert('현재월 이전으로는 입력이 불가합니다.')
                    return
                }
                if (
                    this.masterParam.outSchdDt >
                    moment().add(30, 'days').format('YYYYMMDD')
                ) {
                    this.showTcComAlert(
                        '출고일(은)는 현재일자보다 + 30일 이상 일자는 선택 할 수 없습니다'
                    )
                    return
                }
                this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                    if (confirm) {
                        //신규등록
                        saveData = { ...this.masterParam }
                        saveData.serNumList = addInnData
                        disDtrDisMovOutDtlApi
                            .addDisDtrDisMovOutDtl(saveData)
                            .then((res) => {
                                // 정상등록
                                if (!_.isEmpty(res)) {
                                    setTimeout(() => {
                                        this.gridData = this.gridSetData() //초기화
                                        this.searchParam.outMgmtNo = res
                                        this.masterParam.outMgmtNo = res
                                        this.getDisDtrDisMovOutDtlLists()
                                    }, 2000)

                                    this.listBtn()
                                }
                            })
                    }
                })
            } else {
                //부분삭제
                if (_.isEmpty(this.deleleGridData)) {
                    this.showTcComAlert('삭제된 내용이 없습니다.')
                } else {
                    this.showTcComConfirm('저장하시겠습니까?').then(
                        (confirm) => {
                            if (confirm) {
                                //상세 DATA 에서 addInnData Filter
                                saveData = { ...this.masterParam }
                                saveData.serNumList = this.deleleGridData
                                disDtrDisMovOutDtlApi
                                    .deleteDisDtrDisMovOutDtl(saveData)
                                    .then((res) => {
                                        // 정상삭제
                                        if (res === 1) {
                                            setTimeout(() => {
                                                this.gridData =
                                                    this.gridSetData() //초기화
                                                this.getDisDtrDisMovOutDtlLists()
                                            }, 2000)
                                        }
                                    })
                            }
                        }
                    )
                }
            }
        },
        //삭제
        deleteBtn: function () {
            this.showTcComConfirm('전체 삭제하시겠습니까?').then((confirm) => {
                if (confirm) {
                    this.masterParam.procFlag = 'AD'
                    let saveData = {}
                    saveData = { ...this.masterParam }
                    saveData.serNumList = this.prodSerNumParam
                    disDtrDisMovOutDtlApi
                        .deleteDisDtrDisMovOutDtl(saveData)
                        .then((res) => {
                            // 정상삭제
                            if (res === 1) {
                                setTimeout(() => {
                                    this.listBtn()
                                }, 2000)

                                this.listBtn()
                            }
                        })
                }
            })
        },
        //엑셀다운로드
        onClickDownload() {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dtr/disDtrDisMovOutDtlExcelList',
                this.masterParam
            )
        },
        //목록
        listBtn() {
            this.$router.push({
                name: '/dis/dtr/DisDtrDisMovOut',
                params: { search: this.listSearch },
            })
        },
        // 여신잔액 조회
        getCrdtLimit() {
            const param = {}
            if (!_.isEmpty(this.masterParam.inDealcoCd)) {
                param.dealCoCd = this.masterParam.inDealcoCd

                iioApi.getCrdtLimit(param).then((res) => {
                    this.crdtLimit = res.result.crdtLimit
                })
            }
        },
        //재고이동출고 목록 조회
        getDisDtrDisMovOutDtlLists: function () {
            disDtrDisMovOutDtlApi
                .getDisDtrDisMovOutDtlLists(this.searchParam)
                .then((res) => {
                    //Get Row Data
                    this.gridObj.setRows(res.disDtrDisMovOutProdListVo)
                    this.prodSerNumParam = res.disDtrDisMovOutProdListVo
                    this.addProd = false
                    this.orgDisabled = true
                    this.dealcoDisabled = true
                    // 여신잔액조회
                    this.getCrdtLimit()
                })
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            this.gridObj.gridView.commit()
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
            this.deleleGridData = this.gridData.delRows
        },
        isMasterParamValidChk() {
            if (_.isEmpty(this.masterParam.outSchdDt)) {
                this.showTcComAlert('출고일자를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.outOrgCd)) {
                this.showTcComAlert('출고조직(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.outDealcoCd)) {
                this.showTcComAlert('출고처(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.inOrgCd)) {
                this.showTcComAlert('입고조직(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.inDealcoCd)) {
                this.showTcComAlert('입고처(을)를 입력해 주십시오.')
                return false
            }
            if (this.masterParam.outDealcoCd == this.masterParam.inDealcoCd) {
                this.showTcComAlert('출고처와 입고처가 동일합니다.')
                return false
            }
            if (
                !_.isEmpty(this.masterParam.rmks) &&
                this.masterParam.rmks.length > 30
            ) {
                this.showTcComAlert('비고는 30자 이상 입력할 수 없습니다.')
                return false
            }
            return true
        },
        //===================== 출고 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getOutAuthOrgTreeList() {
            this.searchOutAuthOrgTreesForm.orgCd = this.masterParam.outOrgCd
            this.searchOutAuthOrgTreesForm.orgNm = this.masterParam.outOrgNm
            this.searchOutAuthOrgTreesForm.orgLvl = this.masterParam.outOrgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchOutAuthOrgTreesForm)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.masterParam.outOrgCd = _.get(res[0], 'orgCd')
                        this.masterParam.outOrgNm = _.get(res[0], 'orgNm')
                        this.masterParam.outOrgLvl = _.get(res[0], 'orgLvl')
                        this.masterParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultOutAuthOrgTreeRows = res
                        this.showOutBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onOutAuthOrgTreeIconClick() {
            if (!this.addProd) return
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.masterParam.outOrgNm)) {
                this.getOutAuthOrgTreeList()
            } else {
                this.showOutBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onOutAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultOutAuthOrgTreeRows = []
            // 내부조직팝업(권한) 정보 조회
            this.getOutAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onOutAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.masterParam.outOrgCd = ''
            this.masterParam.outOrgLvl = ''
            this.masterParam.outOrgCdLvl0 = ''
            this.masterParam.outDealcoCd = ''
            this.masterParam.outDealcoNm = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onOutAuthOrgTreeReturnData(retrunData) {
            this.masterParam.outOrgCd = _.get(retrunData, 'orgCd')
            this.masterParam.outOrgNm = _.get(retrunData, 'orgNm')
            this.masterParam.outOrgLvl = _.get(retrunData, 'orgLvl')
            this.masterParam.outOrgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
            this.masterParam.outDealcoCd = ''
            this.masterParam.outDealcoNm = ''
        },
        //===================== //출고 내부조직팝업(권한)팝업관련 methods ================================
        //===================== 입고 내부조직팝업(전체)팝업관련 methods ================================
        // 내부조직팝업(전체) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(전체) 팝업 오픈
        getOrgTreeList() {
            this.searchInAuthOrgTreesForm.orgCd = this.masterParam.inOrgCd
            this.searchInAuthOrgTreesForm.orgNm = this.masterParam.inOrgNm
            this.searchInAuthOrgTreesForm.orgLvl = this.masterParam.inOrgLvl
            basBcoOrgTreesApi.getOrgTreeList(this.reqParam).then((res) => {
                // 검색된 내부조직팝업(전체) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(전체) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(전체) 팝업 오픈
                if (res.length === 1) {
                    this.masterParam.inOrgCd = _.get(res[0], 'orgCd')
                    this.masterParam.inOrgNm = _.get(res[0], 'orgNm')
                    this.masterParam.inOrgLvl = _.get(res[0], 'orgLvl')
                } else {
                    this.resultOrgTreeRows = res
                    this.showBcoOrgTrees = true
                }
            })
        },
        // 내부조직팝업(전체) TextField 돋보기 Icon 이벤트 처리
        onOrgTreeIconClick() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이 아니면 내부조직팝업(전체) 정보 조회
            // 그 이외는 내부조직팝업(전체) 팝업 오픈
            if (!_.isEmpty(this.masterParam.inOrgNm)) {
                this.getOrgTreeList()
            } else {
                this.showBcoOrgTrees = true
            }
        },
        // 내부조직팝업(전체) TextField Input 이벤트 처리
        onOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(전체) 코드 초기화
            this.masterParam.inOrgCd = ''
            this.masterParam.inOrgLvl = ''
            this.masterParam.inOrgCdLvl0 = ''
            this.masterParam.inDealcoCd = ''
            this.masterParam.inDealcoNm = ''
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onOrgTreeReturnData(retrunData) {
            this.masterParam.inOrgCd = _.get(retrunData, 'orgCd')
            this.masterParam.inOrgNm = _.get(retrunData, 'orgNm')
            this.masterParam.inOrgLvl = _.get(retrunData, 'orgLvl')
            this.masterParam.inOrgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
            this.masterParam.inDealcoCd = ''
            this.masterParam.inDealcoNm = ''
        },
        //===================== //입고 내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcosForm)
                .then((res) => {
                    // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                    if (res.length === 1) {
                        this.masterParam.outDealcoCd = _.get(res[0], 'dealcoCd')
                        this.masterParam.outDealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultDealcoRows = res
                        this.showBasBcoDealcos = true
                    }
                })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            if (!this.addProd) return
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (_.isEmpty(this.masterParam.outOrgCd)) {
                this.showTcComAlert('출고조직을 선택하세요')
                return
            }
            this.searchDealcosForm.orgCd = this.masterParam.outOrgCd
            this.searchDealcosForm.orgNm = this.masterParam.outOrgNm
            this.searchDealcosForm.orgLvl = this.masterParam.outOrgLvl
            this.searchDealcosForm.dealcoCd = this.masterParam.outDealcoCd
            this.searchDealcosForm.dealcoNm = this.masterParam.outDealcoNm
            // 팝업오픈
            this.showBasBcoDealcos = true
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.masterParam.outOrgCd)) {
                this.showTcComAlert('출고조직을 선택하세요')
                return
            }
            this.searchDealcosForm.orgCd = this.masterParam.outOrgCd
            this.searchDealcosForm.orgNm = this.masterParam.outOrgNm
            this.searchDealcosForm.orgLvl = this.masterParam.outOrgLvl
            this.searchDealcosForm.dealcoCd = this.masterParam.outDealcoCd
            this.searchDealcosForm.dealcoNm = this.masterParam.outDealcoNm
            if (_.isEmpty(this.masterParam.outDealcoNm)) {
                // 팝업오픈
                this.showBasBcoDealcos = true
            } else {
                // 내부거래처-전체조직 정보 조회
                this.getDealcosList()
            }
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.masterParam.outDealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            this.masterParam.outDealcoCd = _.get(retrunData, 'dealcoCd')
            this.masterParam.outDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-전체조직팝업관련 methods ================================
        //===================== 입고 내부거래처-재고전용 팝업관련 methods ================================
        // 내부거래처-재고전용 팝업관련 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-재고전용 팝업 오픈
        getInInrDealcosList() {
            BasBcoInrDealcosDissApi.getList(this.searchInrDealcosForm).then(
                (res) => {
                    // 검색된 내부거래처-재고전용 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-재고전용 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-재고전용 팝업 오픈
                    if (res.length === 1) {
                        this.masterParam.inDealcoCd = _.get(res[0], 'dealcoCd')
                        this.masterParam.inDealcoNm = _.get(res[0], 'dealcoNm')
                        this.getCrdtLimit() //여신잔액조회
                    } else {
                        this.resultInInrDealcoRows = res
                        this.showbasBcoInrDealcos = true
                    }
                }
            )
        },
        // 내부거래처 팝업 TextField 돋보기 Icon 이벤트 처리
        onInrDealcosIconClick() {
            if (!this.addProd) return
            // 내부거래처팝업 Row 설정 Prop 변수 초기화
            this.resultInInrDealcoRows = []
            // 검색조건 dealCoCd이 빈값이면 팝업오픈
            if (_.isEmpty(this.masterParam.inOrgCd)) {
                this.showTcComAlert('입고조직을 선택하세요')
                return
            }
            this.searchInrDealcosForm.orgCd = this.masterParam.inOrgCd
            this.searchInrDealcosForm.orgNm = this.masterParam.inOrgNm
            this.searchInrDealcosForm.orgLvl = this.masterParam.inOrgLvl
            this.searchInrDealcosForm.dealcoCd = this.masterParam.inDealcoCd
            this.searchInrDealcosForm.dealcoNm = this.masterParam.inDealcoNm
            // 팝업오픈
            this.showbasBcoInrDealcos = true
        },
        // 내부거래처-재고전용 TextField 엔터키 이벤트 처리
        onInrDealcosEnterKey() {
            // 내부거래처-재고전용 팝업 Row 설정 Prop 변수 초기화
            this.resultInInrDealcoRows = []
            // 검색조건 내부거래처-재고전용 명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.masterParam.inOrgCd)) {
                this.showTcComAlert('입고조직을 선택하세요')
                return
            }
            this.searchInrDealcosForm.orgCd = this.masterParam.inOrgCd
            this.searchInrDealcosForm.orgNm = this.masterParam.inOrgNm
            this.searchInrDealcosForm.orgLvl = this.masterParam.inOrgLvl
            this.searchInrDealcosForm.dealcoCd = this.masterParam.inDealcoCd
            this.searchInrDealcosForm.dealcoNm = this.masterParam.inDealcoNm
            if (_.isEmpty(this.masterParam.inDealcoNm)) {
                // 팝업오픈
                this.showbasBcoInrDealcos = true
            } else {
                // 내부거래처-재고전용 정보 조회
                this.getInInrDealcosList()
            }
        },
        // 내부거래처-재고전용 TextField Input 이벤트 처리
        onInrDealcosInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.masterParam.inDealcoCd = ''
        },
        // 내부거래처-재고전용 팝업 리턴 이벤트 처리
        onInrDealcosReturnData(retrunData) {
            this.masterParam.inDealcoCd = _.get(retrunData, 'dealcoCd')
            this.masterParam.inDealcoNm = _.get(retrunData, 'dealcoNm')
            this.getCrdtLimit() //여신잔액조회
        },
        //===================== //입고 내부거래처-재고전용 팝업관련 methods ================================
    },
}
</script>
