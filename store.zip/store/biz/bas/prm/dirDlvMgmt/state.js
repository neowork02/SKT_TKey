export default {
    //alert message
    loadingShow: false,

    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 30,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 30,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },

    //paging
    paging_2: {
        pageNum: 1, //fix
        pageSize: 30,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging_2: {
        pageNum: 1, //fix
        pageSize: 30,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    refreshPaging: '',
    dialogShows: { type: Boolean, default: false, required: false },

    initList: [
        {
            commCdVal: '',
            commCdValNm: '전체',
        },
    ],

    screenGb: '', // 화면구분
    auth: '', // 권한설정

    // data
    isDisabledDataEarvYn: true, // TODO 전자결재전송대상
    /**
     * earvStType : 전자결재전송
     * 1 : 전자결재전송대상
     * 2 : 신규
     * 3 : 변경
     * 4 : 담보갱신
     * 5 : 변경&담보갱신
     * 6 : 해지
     */
    earvStType: '1',
    isDealStatus: false, // 거래종료여부

    // grid true : off / false : on
    isDisabledDataUKey: false, // ukey 제조사코드
    isDisabledDataStlPlc: false, // 정산처
    isDisabledDataDisHldPlc: false, // 재고보유처
    isDisabledDataStlPlcChk: false, // 정산처
    isDisabledDataDisHldPlcChk: false, // 재고보유처
    isDisabledDataSknDelvYn: false, // skn 직배송여부
    isDisabledDataExcYn: false, // 전속점여부
    isDisabledDataBankCdYn: false, // 출금계좌여부
    isDisabledDataBtnCrdDeal: false, // 공유담보거래처

    isDisabledDataBankCd1: false,
    isDisabledDataBankCd2: false,
    isDisabledDataBankCd3: false,
    isDisabledDataBankCd4: false,
    isDisabledDataBankCd5: false,
    isDisabledDataBankCd6: false,

    isDisabledDataDealcoCl1_1: false, // 거래처구분
    isDisabledDataDealcoCl2_1: false, // 거래처유형
    isDisabledDataDealcoCl3_1: false, // 거래처분류
    isDisabledDataMaDirectYn_1: false, //
    isDisabledDataSisYn_1: false, //

    saveAction: false,
    saveDoneA: false,
    saveDoneB: false,

    commDropDown: {},

    commCdIds: [],
    resultList: [],
    resultList_2: [],
    detailData: {},
    reqParams: {
        dealcoCd: '',
        hstSeq: '',
    },
    params: {},
    acntParams: {},

    dealcoClList_1: [
        {
            commCdVal: '',
            commCdValNm: '전체',
        },
    ],
    dealcoCl2List_1: [
        {
            commCdVal: '',
            commCdValNm: '전체',
        },
    ], // 거래처유형리스트
    dealcoCl3List_1: [
        {
            commCdVal: '',
            commCdValNm: '전체',
        },
    ], // 거래처분류리스트
    initParams: {
        pIsNew: true, // true : 수정 / false 신규
    },

    searchParams: {},
    basPrmDealcoDtlCardList: [], // 카드단말기
    basPrmDealcoDtlCrdList: [], // 담보
    basPrmDealcoDtlDlvList: [], // 배송지
    basPrmDealcoImagAccList: [], // 계좌정보

    basPrmDealcoDtlListVo: {}, // 거래처상세
    basPrmDealcoDtlCmListVo: {}, // 사업자등록정보
    basPrmDealcoDtlCardListVo: {}, // 카드단말기
    basPrmDealcoDtlCrdListVo: {}, // 담보
    basPrmDealcoDtlDlvListVo: {}, // 배송지
    basPrmDealcoDtlChrgrListVo: {}, // 영업담당자
    basPrmDealcoDtlEarvCntListVo: {}, // 전자결재 진행여부
    basPrmDealcoImagAccListVo: {}, // 매장별가상계좌

    // 공통코드
    DEALCO_RGST_CL_CD: [], // 거래처등록구분
    DEAL_CO_GRP: [], // 거래처그룹
    ZBAS_C_00240: [], // 거래처구분
    ZBAS_C_00510: [], // 거래처유형 (판매점구분)
    ZBAS_C_00570: [], // 거래처유형 (직영점구분)
    ZBAS_C_00530: [], // 거래처분류
    ZBAS_C_00590: [], // 거래처분류 (직영점2차점 거래처분류)
    ZBAS_C_00110: [], // 거래처분류
    ZBAS_C_00130: [], // 영업그룹
    ZBAS_C_00120: [], //
    ZBAS_C_00400: [], //
    ZBAS_C_00710: [], //
    ZBAS_C_00230: [], //
    ZBAS_C_00410: [], //
    ZBAS_C_00420: [], //
    ZBAS_C_00200: [], //
    SP_CLS_BIZ_CL_CD: [], //
    COM_YN: [], //
    EMAIL_ACC: [], //
    TAX_PRD_CD: [], //
    CRD_TYP: [], //
    ACNT_CL_CD: [], //
    SKN_WHOUSE_CD: [],

    newInfoData: {}, // 신규정보
    strdInfoData: {}, // 기준정보
    bizRgstInfoData: {}, // 사업자등록정보
    dlvDealcoInfoData: {}, // 배송지
    etcAddInfoData: {}, // 물류창고/직영점/하부망 추가정보
    acntInfoData: {}, // 계좌정보
    cltInfoData: {}, // 담보정보
    agencyAddInfoData: {}, // 대리점 추가정보

    isGridStrdInfo: false, // 기본정보 그리드 true : 활성화, false : 비활성화
    isGridEtcAddInfo: false, // 추가정보 그리드 true : 활성화, false : 비활성화
    isGridBizRgstInfo: false, // 사용자등록정보 그리드 true : 활성화, false : 비활성화
    isGridAcntInfo: false, // 계좌정보 그리드 true : 활성화, false : 비활성화
    isGridCltInfo: false, // 담보 그리드 true : 활성화, false : 비활성화
    isGridDlvDealcoInfo: false, // 배송지 그리드 true : 활성화, false : 비활성화
}
