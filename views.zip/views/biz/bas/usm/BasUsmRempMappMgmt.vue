<template>
    <div class="content">
        <TCComAlert
            v-model="showAlertBool"
            :headerText="headerText"
            :bodyText="alertBodyText"
        ></TCComAlert>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="btn_Mapping_OnClick"
                    :objAuth="this.objAuth"
                >
                    사용자매핑
                </TCComButton>
                <BasUsmSaleBrPtlUserMapping
                    v-if="showUsmMapp"
                    :parentParam="div_condition"
                    :rows="resultSaleBrPtlUserMappingRows"
                    :dialogShow.sync="showUsmMapp"
                />
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="btn_NewUser_OnClick"
                    :objAuth="this.objAuth"
                >
                    사용자등록
                </TCComButton>
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchOrgAgencyParam.agencyNm"
                        :codeVal.sync="searchOrgAgencyParam.agencyCd"
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOrgAgencyEnterKey"
                        @appendIconClick="onOrgAgencyIconClick"
                        @input="onOrgAgencyInput"
                    />
                    <BasBcoOrgAgencysPopup
                        v-if="showBcoOrgAgencys"
                        :parentParam="searchOrgAgencyParam"
                        :rows="resultOrgAgencyRows"
                        :dialogShow.sync="showBcoOrgAgencys"
                        @confirm="onOrgAgencyReturnData"
                    />
                </div>

                <div class="formitem div4">
                    <TCComInput
                        v-model="div_condition.edt_UserNm"
                        :eRequired="false"
                        labelName="이름"
                        :objAuth="objAuth"
                    >
                    </TCComInput>
                </div>

                <div class="formitem div4">
                    <TCComInput
                        v-model="div_condition.edt_PortalId"
                        :eRequired="false"
                        labelName="통합ID"
                        :objAuth="objAuth"
                    >
                    </TCComInput>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :editable="true"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div>
    </div>
</template>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
import { HEADER } from '@/const/grid/bas/usm/basUsmRempMappMgmtHeader'
import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import BasUsmSaleBrPtlUserMapping from '@/views/biz/bas/usm/BasUsmSaleBrPtlUserMapping'
import API from '@/api/biz/bas/usm/basUsmRempMappMgmt'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
import _ from 'lodash'

export default {
    name: 'BasUsmRempMappMgmt',
    props: {},
    components: {
        // 임시 --> 대리점 팝업으로 바꿔야함
        BasBcoOrgAgencysPopup,
        BasUsmSaleBrPtlUserMapping,
    },
    // props: {
    //     // 팝업오픈 여부
    //     dialogShow: { type: Boolean, default: false, required: false },
    //     // 부모 파라미터 정보
    //     parentParam: { type: Object, default: () => {}, required: false },
    //     // row 정보
    //     rows: { type: Array, default: () => [], required: false },
    // },

    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: HEADER,

            selectedItem: '',

            //====================조직별대리점팝업관련====================
            showBcoOrgAgencys: false, // 대리점팝업(권한) 팝업 오픈 여부
            searchOrgAgencyParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultOrgAgencyRows: [],
            //====================메인조회관련================
            div_condition: {
                cdiv_agencyByOrg: '', //대리점
                cdiv_agencyByOrgNm: '',
                edt_UserNm: '', //이름
                edt_PortalId: '', //통합ID
                //====================대리점팝업(권한)팝업관련 데이터 메인조회 데이터로 셋팅
                // agencyCd: this.searchOrgAgencyParam.agencyCd, // 대리점코드
                // agencyNm: this.searchOrgAgencyParam.agencyNm, // 대리점명
            },

            // 조회조건
            reqParam: {
                cdiv_agencyByOrg: '', //대리점
                cdiv_agencyByOrgNm: '',
                edt_UserNm: '', //이름
                edt_PortalId: '', //통합ID
            },

            showAlertBool: false,
            alertBodyText: '',
            headerText: '',

            ds_PsMapping: [],
            resultSaleBrPtlUserMappingRows: [],
            showUsmMapp: false,
        }
    },

    // computed: {
    //     activeOpen: {
    //         get() {
    //             return this.dialogShow
    //         },
    //         set(value) {
    //             this.$emit('update:dialogShow', value)
    //         },
    //     },
    // },

    // watch: {
    //     parentParam: {
    //         handler: function (value) {
    //             this.div_condition.edt_UserNm = value['edt_UserNm']
    //         },
    //         deep: true, // 속성 내부까지 감시
    //         immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
    //     },
    // },

    created() {
        this.init()
    },

    async mounted() {
        this.gridObj = this.$refs.grid1

        this.initGrid()
    },

    methods: {
        async init() {
            this.gridData = this.GridSetData()
        },

        async initGrid() {
            // this.gridHeaderObj = this.$refs.gridHeader1
            this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            this.gridObj.setGridState()

            CommonMsg.$_log('init 함수호출')
            // this.gridData = this.GridSetData()
            this.gridObj.setRows(this.rows)
            // this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            //     const jsonData = this.gridObj.dataProvider.getJsonRow(
            //         clickData.dataRow
            //     )
            //     this.$emit('confirm', jsonData)
            //     this.onClose()
            // }
        },

        //GridSet Init
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수),
            return new CommonGrid(-1, -1, 10, 0, '')
        },

        onInput(node) {
            console.log('input: ', node)
        },
        onActive(node) {
            console.log('active: ', node)
            if (node.length > 0) {
                this.selectedItem = _.clone(node[0])
            }
        },
        onOpen(node) {
            console.log('open: ', node)
        },

        //조회 이벤트
        getList: function () {
            console.log('this.div_condition : ', this.div_condition)
            API.getPsMappingUser(this.div_condition).then((resultData) => {
                console.log('resultData : ', resultData.length)
                this.ds_PsMapping = resultData
                // INDEX 셋팅
                if (resultData.length > 0) {
                    for (let index = 0; index < resultData.length; index++) {
                        resultData[index].NO = index + 1
                    }
                } else if (resultData.length === 0) {
                    alert('데이터가 없습니다')
                }
                // Get Row Data
                this.gridObj.setRows(resultData)

                console.log('조회완료')
            })
        },

        //===================== 조직별 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getOrgAgencyList() {
            basBcoOrgAgencysApi
                .getOrgAgencyList(this.searchOrgAgencyParam)
                .then((res) => {
                    console.log('getOrgAgencyList then : ', res)
                    // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                    // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                    if (res.length === 1) {
                        this.searchOrgAgencyParam.agencyCd = _.get(
                            res[0],
                            'agencyCd'
                        )
                        this.searchOrgAgencyParam.agencyNm = _.get(
                            res[0],
                            'agencyNm'
                        )
                    } else {
                        this.resultOrgAgencyRows = res
                        this.showBcoOrgAgencys = true
                    }
                })
        },

        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onOrgAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.searchOrgAgencyParam.agencyNm)) {
                this.getOrgAgencyList()
            } else {
                this.showBcoOrgAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onOrgAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchOrgAgencyParam.agencyNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '대리점명을 입력해주세요.'
                return
            }
            // 대리점 정보 조회
            this.getOrgAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onOrgAgencyInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchOrgAgencyParam.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onOrgAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchOrgAgencyParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.searchOrgAgencyParam.agencyNm = _.get(retrunData, 'agencyNm')
        },
        ///////////////////////////////////////////////////////////////////////////////////////////
        validationCheckSearch() {
            if (
                !this.div_condition.edt_UserNm ||
                this.div_condition.edt_UserNm.length < 2
            ) {
                alert('이름을 2자리 이상 입력해 주십시요.')
                document.getElementById('edt_UserNm').focus()
                return false
            }
            return true
        },

        // 조회
        onSearch() {
            if (!this.validationCheckSearch()) {
                return
            }
            this.getList()
        },

        // 초기화
        onResetPage() {
            CommonUtil.clearPage(this.$router)
        },

        // // 사용자매핑
        // onMapp() {
        //     console.log('onMapp: ')
        // },
        // // 사용자등록
        // onRegister() {
        //     console.log('onRegister: ')
        // },

        // 사용자매핑
        btn_Mapping_OnClick() {
            console.log('onRegister: ')
            // 대리점팝업 Row 설정 Prop 변수 초기화
            this.resultSaleBrPtlUserMappingRows = []
            // let selUser = 0
            // let selRow = 0

            // for (let i = 0; i < this.ds_PsMapping.length; i++) {
            //     if (this.ds_PsMapping.chk == true) {
            //         selUser++
            //         selRow = i
            //     }
            // }

            // if (selUser == 0) {
            //     alert(
            //         '사용자 Mapping을 원하는 자료를 선택하여 주시기 바랍니다.'
            //     )
            //     return
            // }

            // if (selUser > 1) {
            //     alert('한명의 사용자만 선택하여 주시기 바랍니다.')
            //     return
            // }

            // let sSelectUser =
            //     this.ds_PsMapping[selRow].loginId +
            //     ' / ' +
            //     this.ds_PsMapping[selRow].hanNm
            // if (
            //     confirm(
            //         '선택된 [' +
            //             sSelectUser +
            //             '] 사용자에 대한 Mapping 처리를 진행하시겠습니까?'
            //     )
            // ) {
            this.showUsmMapp = true
            // }
        },

        // 사용자등록
        btn_NewUser_OnClick() {
            alert('사용자등록화면 추후 작업예정')
            console.log('onMapp: ')
        },

        onEnterKey() {
            this.onSearch()
        },

        //Grid ExcelDown
        onExportGrid: function () {
            this.gridHeaderObj.exportGrid('정직원매핑관리.xls')
        },
    },
}
</script>
<style>
.box1 {
    height: 400px;
    overflow-y: scroll;
}
</style>
