<template>
    <div>
        <ul class="btn_area upper">
            <li class="right">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="onClickDownload"
                    :objAuth="this.objAuth"
                >
                    엑셀다운로드
                </TCComButton>
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="saveOrgBtn"
                    :objAuth="this.objAuth"
                >
                    조직저장
                </TCComButton>
                <div
                    :class="
                        this.isEmptyCurrentOrg1 ? 'disableddiv' : 'normaldiv'
                    "
                >
                    <TCComButton
                        :eOutlined="true"
                        eClass="btn_ty"
                        @click="actAddOrg"
                        :objAuth="this.objAuth"
                        :disabled="!this.enableAddOrg1"
                    >
                        조직추가
                    </TCComButton>
                    <TCComButton
                        :eOutlined="true"
                        eClass="btn_ty"
                        @click="actDelOrg"
                        :objAuth="this.objAuth"
                        :disabled="!this.enableDelOrg1"
                    >
                        조직삭제
                    </TCComButton>
                    <TCComButton
                        :eOutlined="true"
                        eClass="btn_ty"
                        @click="actRenameOrg"
                        :objAuth="this.objAuth"
                        :disabled="!this.enableRenameOrg1"
                    >
                        조직변경
                    </TCComButton>
                    <TCComButton
                        :eOutlined="true"
                        eClass="btn_ty"
                        @click="actMoveUp"
                        :objAuth="this.objAuth"
                        :disabled="!this.enableMoveUpDown1"
                    >
                        순서위로
                    </TCComButton>
                    <TCComButton
                        :eOutlined="true"
                        eClass="btn_ty"
                        @click="actMoveDown"
                        :objAuth="this.objAuth"
                        :disabled="!this.enableMoveUpDown1"
                    >
                        순서아래로
                    </TCComButton>
                    <!--
                    <TCComButton
                        :eOutlined="true"
                        eClass="btn_ty"
                        @click="actMoveFromOrg"
                        :objAuth="this.objAuth"
                        :disabled="!this.enableMoveFromOrg1"
                    >
                        조직이동(From)
                    </TCComButton>
                    <TCComButton
                        :eOutlined="true"
                        eClass="btn_ty"
                        @click="actMoveToOrg"
                        :objAuth="this.objAuth"
                        :disabled="!this.enableMoveToOrg1"
                    >
                        조직이동(To)
                    </TCComButton>
                    <TCComButton
                        :eOutlined="true"
                        eClass="btn_ty"
                        @click="actMoveCancelOrg"
                        :objAuth="this.objAuth"
                        :disabled="!this.enableMoveToOrg1"
                    >
                        이동선택취소
                    </TCComButton>
                    -->
                    <!-- <TCComButton
                        color="btn2"
                        eClass="btn_ty01"
                        @click="saveOrgBtnIn"
                        :objAuth="this.objAuth"
                    >
                        조직저장
                    </TCComButton> -->
                </div>
            </li>
        </ul>
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/ogm/orgMgmt/helpers'
import attachedFileApi from '@/api/common/attachedFile'
import _ from 'lodash'
export default {
    components: {},
    data() {
        return {
            objAuth: {},
            showFlag: false,
            title: 'BasOgmOrgMgmtButtonCont',
            status: 1,
            isReadOnly: false,
            form: {},
        }
    },
    created() {},
    computed: {
        ...serviceComputed,
        isEmptyCurrentOrg1: {
            get() {
                return _.isEmpty(this.currentOrg)
            },
        },
        enableAddOrg1: {
            get() {
                let enable1 = false
                if (
                    !_.isEmpty(this.currentOrg) &&
                    _.isEmpty(this.actOrg) &&
                    this.currentOrg.depth <= 3
                ) {
                    enable1 = true
                }
                return enable1
            },
        },
        enableDelOrg1: {
            get() {
                let enable1 = false
                if (
                    !_.isEmpty(this.currentOrg) &&
                    _.isEmpty(this.actOrg) &&
                    this.currentOrg.depth >= 2
                ) {
                    enable1 = true
                }
                return enable1
            },
        },
        enableRenameOrg1: {
            get() {
                let enable1 = false
                if (
                    !_.isEmpty(this.currentOrg) &&
                    _.isEmpty(this.actOrg) &&
                    this.currentOrg.depth >= 2
                ) {
                    enable1 = true
                }
                return enable1
            },
        },
        enableMoveFromOrg1: {
            get() {
                let enable1 = false
                if (!_.isEmpty(this.currentOrg) && _.isEmpty(this.actOrg)) {
                    enable1 = true
                }
                return enable1
            },
        },
        enableMoveToOrg1: {
            get() {
                let enable1 = false
                if (!_.isEmpty(this.currentOrg) && this.actOrg == 'moveFrom') {
                    enable1 = true
                }
                return enable1
            },
        },
        enableMoveUpDown1: {
            get() {
                let enable1 = false
                if (
                    !_.isEmpty(this.currentOrg) &&
                    _.isEmpty(this.actOrg) &&
                    this.currentOrg.orgLvl == '3'
                ) {
                    enable1 = true
                }
                return enable1
            },
        },
        params: {
            get() {
                return this.searchParams
            },
        },
        resultListOrg1: {
            get() {
                return this.resultListOrg
            },
        },
    },
    methods: {
        ...serviceMethods,
        async actAddOrg() {
            console.log('actAddOrg')
            await this.defaultAssign_({
                key: 'actOrg',
                value: 'add',
            })
        },
        async actDelOrg() {
            console.log('actDelOrg')
            await this.defaultAssign_({
                key: 'actOrg',
                value: 'del',
            })
        },
        async actRenameOrg() {
            console.log('actRenameOrg')
            await this.defaultAssign_({
                key: 'actOrg',
                value: 'rename',
            })
        },
        async actMoveFromOrg() {
            console.log('actMoveFromOrg')
            await this.defaultAssign_({
                key: 'actOrg',
                value: 'moveFrom',
            })
        },
        async actMoveToOrg() {
            console.log('actMoveToOrg')
            await this.defaultAssign_({
                key: 'actOrg',
                value: 'moveTo',
            })
        },
        async actMoveCancelOrg() {
            console.log('actMoveCancelOrg')
            await this.defaultAssign_({
                key: 'actOrg',
                value: 'moveCancel',
            })
        },
        async saveOrgBtn() {
            await this.defaultAssign_({
                key: 'beforeSaveOrgAction',
                value: true,
            })
        },
        async actMoveUp() {
            console.log('actMoveUp')
            await this.defaultAssign_({
                key: 'actOrg',
                value: 'moveUp',
            })
        },
        async actMoveDown() {
            console.log('actMoveDown')
            await this.defaultAssign_({
                key: 'actOrg',
                value: 'moveDown',
            })
        },

        //엑셀다운로드
        async onClickDownload() {
            // const rowCount = this.gridObj1.dataProvider.getRowCount()

            if (this.resultListOrg1.length == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            await attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/ogm/orgMgmtExcelList',
                {
                    orgCd: this.params.orgCd ? this.params.orgCd : '',
                    aplyStaDt: this.params.aplyStaDt
                        ? this.params.aplyStaDt
                        : '',
                    orgCdLvl0: this.params.orgCdLvl0
                        ? this.params.orgCdLvl0
                        : '',
                    orgLvlCd: this.params.orgLvlCd ? this.params.orgLvlCd : '',
                }
            )
        },
    },
}
</script>

<style>
.normaldiv {
    float: right;
    padding-left: 4px;
}
.disableddiv {
    float: right;
    padding-left: 4px;
    pointer-events: none;
    opacity: 0.4;
}
</style>
