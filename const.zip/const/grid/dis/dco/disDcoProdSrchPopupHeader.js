import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분명
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT, //단말기구분코드
        },
        {
            fieldName: 'eqpClNm',
            dataType: ValueType.TEXT, //단말기구분명
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT, //제조사코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //모델코드
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.TEXT, //단가
        },
        {
            fieldName: 'sktOperYn',
            dataType: ValueType.TEXT, //SKT운영여부
        },
        {
            fieldName: 'prodChrticCd1',
            dataType: ValueType.TEXT, //상품특성코드1
        },
        {
            fieldName: 'prodChrticCd2',
            dataType: ValueType.TEXT, //상품특성코드2
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT, //출시일자
        },
        {
            fieldName: 'endDt',
            dataType: ValueType.TEXT, //단종일자
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT, //사용여부
        },
        {
            fieldName: 'useStopDt',
            dataType: ValueType.TEXT, //사용중지일자
        },
        {
            fieldName: 'rgstClCd',
            dataType: ValueType.TEXT, //등록구분코드
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT, //삭제여부
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, //수정횟수
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT, //입력일시
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT, //입력사용자ID
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, //수정일시
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, //수정사용자ID
        },
        {
            fieldName: 'cashPrchsPrc',
            dataType: ValueType.TEXT, //최초등록출고가격
        },
        {
            fieldName: 'barCdTypCd',
            dataType: ValueType.TEXT, //바코드유형코드
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.TEXT, //바코드유형코드
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT, //펫명
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'eqpClNm',
            fieldName: 'eqpClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분명',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'mfactCd',
            fieldName: 'mfactCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
        },
        {
            name: 'sktOperYn',
            fieldName: 'sktOperYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT운영여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'prodChrticCd1',
            fieldName: 'prodChrticCd1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품특성코드1',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'prodChrticCd2',
            fieldName: 'prodChrticCd2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품특성코드2',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출시일자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'endDt',
            fieldName: 'endDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단종일자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'useStopDt',
            fieldName: 'useStopDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용중지일자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'rgstClCd',
            fieldName: 'rgstClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'delYn',
            fieldName: 'delYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '삭제여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수정횟수',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입력일시',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입력사용자ID',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수정일시',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수정사용자ID',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'cashPrchsPrc',
            fieldName: 'cashPrchsPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초등록출고가격',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'barCdTypCd',
            fieldName: 'barCdTypCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '바코드유형코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '종료일련번호',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'petNm',
            fieldName: 'petNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '펫명',
                showTooltip: false,
            },
            visible: false,
        },
    ],
}
