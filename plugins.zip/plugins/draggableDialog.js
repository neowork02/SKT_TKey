import Vue from 'vue'

const dialogSelector = '.v-dialog.v-dialog--active'
const DraggableDialogs = {
    closestDialog(e) {
        if (e.button !== 0) {
            return
        }

        let dialog
        ;['popTitle'].forEach((className) => {
            if (e.target.classList.contains(className)) {
                dialog = e.target.closest(dialogSelector)
            }
        })
        ;['popTitle noDraggable'].forEach((className) => {
            if (e.target.classList.value === className) {
                dialog = false
            }
        })

        return dialog
    },
    install(Vue) {
        Vue.prototype.$draggableDialogs = () => {
            const container = {}
            document.addEventListener('mousedown', (e) => {
                const closestDialog = this.closestDialog(e)
                // const closestDialog = e.target.closest(dialogSelector)
                if (closestDialog) {
                    container.el = closestDialog
                    container.mouseStartX = e.clientX
                    container.mouseStartY = e.clientY
                    container.elStartX =
                        container.el.getBoundingClientRect().left
                    container.elStartY =
                        container.el.getBoundingClientRect().top
                    container.el.style.position = 'fixed'
                    container.el.style.margin = 0
                    container.oldTransition = container.el.style.transition
                    container.el.style.transition = 'none'
                }
            })
            document.addEventListener('mousemove', (e) => {
                if (!container.el) return
                container.el.style.left =
                    Math.min(
                        Math.max(
                            container.elStartX +
                                e.clientX -
                                container.mouseStartX,
                            0
                        ),
                        window.innerWidth -
                            container.el.getBoundingClientRect().width
                    ) + 'px'
                container.el.style.top =
                    Math.min(
                        Math.max(
                            container.elStartY +
                                e.clientY -
                                container.mouseStartY,
                            0
                        ),
                        window.innerHeight -
                            container.el.getBoundingClientRect().height
                    ) + 'px'
            })
            document.addEventListener('mouseup', () => {
                if (!container.el) return
                container.el.style.transition = container.oldTransition
                container.el = undefined
            })
            setInterval(() => {
                const dialog = document.querySelector(dialogSelector)
                if (!dialog) return
                const styleLeft = parseInt(dialog.style.left)
                const styleTop = parseInt(dialog.style.top)
                const boundingWidth = dialog.getBoundingClientRect().width
                const boundingHeight = dialog.getBoundingClientRect().height

                const left = Math.min(
                    styleLeft,
                    window.innerWidth - boundingWidth
                )
                const top = Math.min(
                    styleTop,
                    window.innerHeight - boundingHeight
                )

                // let borderLeft = 0
                // let borderTop = 0
                // if (styleLeft > window.innerWidth) {
                //     borderLeft = left / 2
                // }

                // if (styleTop + boundingHeight > window.innerHeight) {
                //     borderTop = (window.innerHeight - boundingHeight) / 2
                // }

                // dialog.style.left = left - borderLeft + 'px'
                // dialog.style.top = top - borderTop + 'px'

                dialog.style.left = left + 'px'
                dialog.style.top = top + 'px'
            }, 500)
        }
        // Dialog 드래그 이벤트 제거하는 함수 (필요시 사용)
        Vue.prototype.$removeEventDraggableDialogs = () => {
            document.removeEventListener('mousedown', function () {})
            document.removeEventListener('mousemove', function () {})
            document.removeEventListener('mouseup', function () {})
        }
        // Dialog 위치 브라우저 중앙으로 오게하는 함수 (필요시 사용)
        Vue.prototype.$initDraggableDialogs = () => {
            const dialog = document.querySelector(dialogSelector)
            const boundingWidth = dialog.getBoundingClientRect().width
            const boundingHeight = dialog.getBoundingClientRect().height
            dialog.style.left = window.innerWidth / 2 - boundingWidth / 2 + 'px'
            dialog.style.top =
                window.innerHeight / 2 - boundingHeight / 2 + 'px'
        }
    },
}

Vue.use(DraggableDialogs)
