import { ValueType } from 'realgrid'

export const GRID_LAYOUT = [
    'NO',
    'orgNm',
    'chrgrNm',
    'dealcoClNm',
    'dealSktCd',
    'hldDealcoCd',
    'hldDealcoNm',
    'prodClNm',
    'prodCd',
    'prodNm',
    'colorCd',
    'colorNm',
    {
        name: '수량',
        direction: 'horizontal',
        items: ['disQty', 'availQty', 'navailQty'],
    },
]

export const DETAIL_GRID_LAYOUT = [
    'NO',
    'orgNm',
    'chrgrNm',
    'dealcoClNm',
    'saleGrpClNm',
    'dealSktCd',
    'hldDealcoCd',
    'hldDealcoNm',
    'sktChnlCd',
    'mfactNm',
    'prodClNm',
    'prodCd',
    'prodNm',
    'colorCd',
    'colorNm',
    'serNum',
    'disAmt',
    'fixCrdtPrc',
    'disCmpDt',
    'disCmpAmt',
    'unitPrc',
    'fstPrchsDealcoNm',
    'fstInFixDt',
    'fstInDealSktCd',
    'fstInDealcoCd',
    'fstInDealcoNm',
    'prchTypNm',
    'fstInOrgNm',
    'disPrd',
    'movInDt',
    'disHldPrd',
    'demoYn',
    'openYn',
    'badYnNm',
    'badOpDt',
    'disStNm',
    'disFlag',
    'fstInAgencyNm',
    'dlvStNm',
    'boxNo1',
    'boxNo2',
    'rmks',
]

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, // 레벨0조직코드
        },
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT, // 레벨1조직코드
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, // 레벨2조직코드
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT, // 레벨3조직코드
        },
        {
            fieldName: 'chrgrId',
            dataType: ValueType.TEXT, // 담당자ID
        },
        {
            fieldName: 'chrgrNm',
            dataType: ValueType.TEXT, // 담당자명
        },
        {
            fieldName: 'dealcoClCd',
            dataType: ValueType.TEXT, // 거래처구분코드
        },
        {
            fieldName: 'dealcoClNm',
            dataType: ValueType.TEXT, // 거래처구분명
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, // 보유처명
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, // 상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT, // 재고상태코드
        },
        {
            fieldName: 'disQty',
            dataType: ValueType.NUMBER, // 재고수량
        },
        {
            fieldName: 'availQty',
            dataType: ValueType.NUMBER, // 가용수량
        },
        {
            fieldName: 'navailQty',
            dataType: ValueType.NUMBER, // 비가용수량
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '조직',
            },
        },
        {
            name: 'chrgrNm',
            fieldName: 'chrgrNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '영업담당',
            },
        },
        {
            name: 'dealcoClNm',
            fieldName: 'dealcoClNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '거래처구분',
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '보유처매장코드',
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '보유처코드',
            },
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '보유처',
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '모델코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '모델',
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '색상코드',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '색상',
            },
        },
        {
            name: 'disQty',
            fieldName: 'disQty',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '합계',
            },
        },
        {
            name: 'availQty',
            fieldName: 'availQty',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '가용',
            },
        },
        {
            name: 'navailQty',
            fieldName: 'navailQty',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '비가용',
            },
        },
    ],
}

export const DETAIL_GRID_HEADER = {
    fields: [
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'chrgrNm',
            dataType: ValueType.TEXT, // 담당자명
        },
        {
            fieldName: 'dealcoClNm',
            dataType: ValueType.TEXT, // 거래처구분명
        },
        {
            fieldName: 'saleGrpClNm',
            dataType: ValueType.TEXT, // 영업그룹구분명
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, // 보유처명
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT, // SKT채널코드
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, // 제조사명
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'disAmt',
            dataType: ValueType.NUMBER, // 재고금액
        },
        {
            fieldName: 'fixCrdtPrc',
            dataType: ValueType.NUMBER, // 확정여신가격
        },
        {
            fieldName: 'disCmpDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 재고보상일자
        },
        {
            fieldName: 'disCmpAmt',
            dataType: ValueType.NUMBER, // 재고보상금액
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER, // 단가
        },
        {
            fieldName: 'fstPrchsDealcoNm',
            dataType: ValueType.TEXT, // 최초매입처명
        },
        {
            fieldName: 'fstInFixDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 최초입고확정일자
        },
        {
            fieldName: 'fstInDealSktCd',
            dataType: ValueType.TEXT, // 최초입고매장코드
        },
        {
            fieldName: 'fstInDealcoCd',
            dataType: ValueType.TEXT, // 최초입고처코드
        },
        {
            fieldName: 'fstInDealcoNm',
            dataType: ValueType.TEXT, // 최초입고처명
        },
        {
            fieldName: 'prchTypNm',
            dataType: ValueType.TEXT, // 구매유형명
        },
        {
            fieldName: 'fstInOrgNm',
            dataType: ValueType.TEXT, // 최초입고조직명
        },
        {
            fieldName: 'disPrd',
            dataType: ValueType.NUMBER, // 재고기간
        },
        {
            fieldName: 'movInDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 이동입고일자
        },
        {
            fieldName: 'disHldPrd',
            dataType: ValueType.NUMBER, // 재고보유기간
        },
        {
            fieldName: 'demoYn',
            dataType: ValueType.TEXT, // 시연여부
        },
        {
            fieldName: 'openYn',
            dataType: ValueType.TEXT, // 개봉여부
        },
        {
            fieldName: 'badYnNm',
            dataType: ValueType.TEXT, // 불량여부명
        },
        {
            fieldName: 'badOpDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 불량처리일자
        },
        {
            fieldName: 'disStNm',
            dataType: ValueType.TEXT, // 재고상태명
        },
        {
            fieldName: 'disFlag',
            dataType: ValueType.TEXT, // 재고구분
        },
        {
            fieldName: 'fstInAgencyNm',
            dataType: ValueType.TEXT, // 최초입고대리점명
        },
        {
            fieldName: 'dlvStNm',
            dataType: ValueType.TEXT, // 배송상태명
        },
        {
            fieldName: 'boxNo1',
            dataType: ValueType.TEXT, // 박스번호1
        },
        {
            fieldName: 'boxNo2',
            dataType: ValueType.TEXT, // 박스번호2
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, // 비고
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '조직',
            },
        },
        {
            name: 'chrgrNm',
            fieldName: 'chrgrNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '영업담당',
            },
        },
        {
            name: 'dealcoClNm',
            fieldName: 'dealcoClNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '거래처구분',
            },
        },
        {
            name: 'saleGrpClNm',
            fieldName: 'saleGrpClNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '영업그룹',
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '보유처매장코드',
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '보유처코드',
            },
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '보유처',
            },
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '채널코드',
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '제조사',
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '모델코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '모델',
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '색상코드',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '색상',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'disAmt',
            fieldName: 'disAmt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '최초매입가',
            },
        },
        {
            name: 'fixCrdtPrc',
            fieldName: 'fixCrdtPrc',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '여신매입가',
            },
        },
        {
            name: 'disCmpDt',
            fieldName: 'disCmpDt',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '재고보상일자',
            },
        },
        {
            name: 'disCmpAmt',
            fieldName: 'disCmpAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '재고보상금액',
            },
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '단가',
            },
        },
        {
            name: 'fstPrchsDealcoNm',
            fieldName: 'fstPrchsDealcoNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '매입처',
            },
        },
        {
            name: 'fstInFixDt',
            fieldName: 'fstInFixDt',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '입고일자',
            },
        },
        {
            name: 'fstInDealSktCd',
            fieldName: 'fstInDealSktCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '입고처매장코드',
            },
        },
        {
            name: 'fstInDealcoCd',
            fieldName: 'fstInDealcoCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '입고처코드',
            },
        },
        {
            name: 'fstInDealcoNm',
            fieldName: 'fstInDealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '입고처',
            },
        },
        {
            name: 'prchTypNm',
            fieldName: 'prchTypNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '구매유형',
            },
        },
        {
            name: 'fstInOrgNm',
            fieldName: 'fstInOrgNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '구매조직',
            },
        },
        {
            name: 'disPrd',
            fieldName: 'disPrd',
            type: 'data',
            width: '60',
            styleName: 'center-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '재고기간',
            },
        },
        {
            name: 'movInDt',
            fieldName: 'movInDt',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '이동일자',
            },
        },
        {
            name: 'disHldPrd',
            fieldName: 'disHldPrd',
            type: 'data',
            width: '60',
            styleName: 'center-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '보유기간',
            },
        },
        {
            name: 'demoYn',
            fieldName: 'demoYn',
            type: 'data',
            width: '90',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '시연재고여부',
            },
        },
        {
            name: 'openYn',
            fieldName: 'openYn',
            type: 'data',
            width: '60',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '개봉구분',
            },
        },
        {
            name: 'badYnNm',
            fieldName: 'badYnNm',
            type: 'data',
            width: '60',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '불량여부',
            },
        },
        {
            name: 'badOpDt',
            fieldName: 'badOpDt',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '불량등록일',
            },
        },
        {
            name: 'disStNm',
            fieldName: 'disStNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '재고상태',
            },
        },
        {
            name: 'disFlag',
            fieldName: 'disFlag',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '재고구분',
            },
        },
        {
            name: 'fstInAgencyNm',
            fieldName: 'fstInAgencyNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '최초입고대리점',
            },
        },
        {
            name: 'dlvStNm',
            fieldName: 'dlvStNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '배송구분',
            },
        },
        {
            name: 'boxNo1',
            fieldName: 'boxNo1',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '박스번호',
            },
        },
        {
            name: 'boxNo2',
            fieldName: 'boxNo2',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '개별번호',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '비고',
            },
        },
    ],
}
