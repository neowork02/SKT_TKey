/*****************************************
 * 업무그룹명: 판매관리
 * 서브업무명: T상품판매
 * 설명: 판매관리-T상품판매-T판매-T판매_스마트홈판매(SALSEL00500) 그리드 헤더
 * 작성자: P179234
 * 작성일: 2022.06.27
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'disClNm',
            dataType: ValueType.TEXT, //재고구분
        },
        {
            fieldName: 'iotTypNm',
            dataType: ValueType.TEXT, //기기유형
        },
        {
            fieldName: 'astAmt',
            dataType: ValueType.TEXT, //보조금
        },
        {
            fieldName: 'saleChgDtm',
            dataType: ValueType.TEXT, //매출일자
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
    ],
    columns: [
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'disClNm',
            fieldName: 'disClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고구분',
                showTooltip: false,
            },
        },
        {
            name: 'iotTypNm',
            fieldName: 'iotTypNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '기기유형',
                showTooltip: false,
            },
        },
        {
            name: 'astAmt',
            fieldName: 'astAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '보조금',
                showTooltip: false,
            },
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매출일자',
                showTooltip: false,
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'iotSvcNm',
            dataType: ValueType.TEXT, //약정상품
        },
    ],
    columns: [
        {
            name: 'iotSvcNm',
            fieldName: 'iotSvcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '약정상품',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_HEADER3 = {
    fields: [
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'fixPrc',
            dataType: ValueType.TEXT, //확정여신가
        },
        {
            fieldName: 'astAmt',
            dataType: ValueType.TEXT, //보조금
        },
        {
            fieldName: 'eqpPreDcAmt',
            dataType: ValueType.TEXT, //선할인금액
        },
        {
            fieldName: 'saleAmt',
            dataType: ValueType.TEXT, //수납대상금액
        },
        {
            fieldName: 'money',
            dataType: ValueType.TEXT, //고객부담금
        },
    ],
    columns: [
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'fixPrc',
            fieldName: 'fixPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '확정여신가',
                showTooltip: false,
            },
        },
        {
            name: 'astAmt',
            fieldName: 'astAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '보조금',
                showTooltip: false,
            },
        },
        {
            name: 'eqpPreDcAmt',
            fieldName: 'eqpPreDcAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '선할인금액',
                showTooltip: false,
            },
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '수납대상금액',
                showTooltip: false,
            },
        },
        {
            name: 'money',
            fieldName: 'money',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '고객부담금',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_HEADER4 = {
    fields: [
        {
            fieldName: 'payAmt',
            dataType: ValueType.NUMBER, //수납금액
        },
        {
            fieldName: 'payMthdCd',
            dataType: ValueType.TEXT, //수납방법
        },
        {
            fieldName: 'cardAprvNo',
            dataType: ValueType.TEXT, //카드승인번호
        },
        {
            fieldName: 'cardCoCd',
            dataType: ValueType.TEXT, //카드사
        },
        {
            fieldName: 'unpayBamt',
            dataType: ValueType.NUMBER, //미수납잔액
        },
        {
            fieldName: 'ediYn',
            dataType: ValueType.TEXT, //수납구분
        },
        {
            fieldName: 'issueSignType',
            dataType: ValueType.TEXT, //현금영수증 발행구분
        },
        {
            fieldName: 'statConf',
            dataType: ValueType.TEXT, ///현금영수증 발행번호
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'tmpUnbay',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'payAmt',
            fieldName: 'payAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '수납금액',
                showTooltip: false,
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const ediYn = grid.getValue(itemIndex, 'ediYn') ?? ''
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''
                const payAmt = dataCell.value ?? 0

                if (ediYn === 'Y') {
                    ret.editable = true
                }
                if (payMthdCd === 'PM03') {
                    ret.editable = false
                }
                if (payAmt < 0) {
                    ret.editable = false
                } else {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'payMthdCd',
            fieldName: 'payMthdCd',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            editable: true,
            header: {
                text: '수납방법',
            },
            // styleCallback(grid, dataCell) {
            //     const ret = { editable: false }
            //     const itemIndex = dataCell.index.itemIndex
            //     const ediYn = grid.getValue(itemIndex, 'ediYn') ?? ''

            //     if (ediYn === 'Y') {
            //         ret.editable = true
            //     } else {
            //         ret.editable = false
            //     }

            //     return ret
            // },
        },
        {
            name: 'cardAprvNo',
            fieldName: 'cardAprvNo',
            type: 'data',
            width: '100',
            header: {
                text: '카드승인번호',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const ediYn = grid.getValue(itemIndex, 'ediYn') ?? ''
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                if (ediYn === 'Y') {
                    ret.editable = true
                } else {
                    ret.editable = false
                }

                if (payMthdCd === 'PM04') {
                    ret.editable = true
                } else {
                    ret.editable = false
                }

                return ret
            },
        },
        {
            name: 'cardCoCd',
            fieldName: 'cardCoCd',
            type: 'data',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '카드사',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const ediYn = grid.getValue(itemIndex, 'ediYn') ?? ''
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                if (ediYn === 'Y') {
                    ret.editable = true
                } else {
                    ret.editable = false
                }

                if (payMthdCd === 'PM04') {
                    ret.editable = true
                } else {
                    ret.editable = false
                }

                return ret
            },
        },
        {
            name: 'unpayBamt',
            fieldName: 'unpayBamt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            editable: false,
            header: {
                text: '미수납잔액',
            },
        },
        {
            name: 'ediYn',
            fieldName: 'ediYn',
            type: 'data',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            editable: true,
            header: {
                text: '수납구분',
            },
        },
        {
            name: 'issueSignType',
            fieldName: 'issueSignType',
            type: 'data',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '발행구분',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                if (payMthdCd === 'PM01') {
                    ret.editable = true
                } else {
                    ret.editable = false
                }

                return ret
            },
        },
        {
            name: 'statConf',
            fieldName: 'statConf',
            type: 'data',
            width: '100',
            header: {
                text: '발행번호',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                if (payMthdCd === 'PM01') {
                    ret.editable = true
                } else {
                    ret.editable = false
                }

                return ret
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
        },
        {
            name: 'tmpUnbay',
            fieldName: 'tmpUnbay',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '미수납',
                showTooltip: false,
            },
            visible: false,
        },
    ],
    layout: [
        'payAmt',
        'payMthdCd',
        'cardAprvNo',
        'cardCoCd',
        'unpayBamt',
        'ediYn',
        {
            name: '현금영수증',
            direction: 'horizontal',
            items: ['issueSignType', 'statConf'],
            header: {
                text: '상품구분',
            },
        },
        'rmks',
        'tmpUnbay',
    ],
}

export const GRID_HEADER_CARD = {
    fields: [
        {
            fieldName: 'trmsDtm',
            dataType: ValueType.TEXT, //거래일시
        },
        {
            fieldName: 'cardEqpNo',
            dataType: ValueType.TEXT, //CAT ID
        },
        {
            fieldName: 'dealSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvDt',
            dataType: ValueType.TEXT, //승인일자
        },
        {
            fieldName: 'aprvNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'joinbrNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealClCd',
            dataType: ValueType.TEXT, //거래구분
        },
        {
            fieldName: 'dealAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tax',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'istmtPrd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'isueCoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'isuecoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchCoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchCoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cardRpsCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNmView',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpsCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpsMsgDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cnclDtm',
            dataType: ValueType.TEXT, //취소일자
        },
        {
            fieldName: 'payOpDt',
            dataType: ValueType.TEXT, //수납일자
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, //변경일시
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //내부거래처[거래처명]
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, //서비스관리번호
        },
        {
            fieldName: 'prodSaleNo',
            dataType: ValueType.TEXT, //판매관리번호
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cntrctMgmtNum',
            dataType: ValueType.TEXT, //계약관리번호
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 파트[조직명]
        },
        {
            fieldName: 'teamOrgNm',
            dataType: ValueType.TEXT, // 사업팀[팀조직명]
        },
        {
            fieldName: 'bizChrgOrgNm',
            dataType: ValueType.TEXT, //사업담당[조직명]
        },
        {
            fieldName: 'cardOpStCd',
            dataType: ValueType.TEXT, //처리상태
        },
    ],
    columns: [
        {
            name: 'bizChrgOrgNm',
            fieldName: 'bizChrgOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '담당',
            },
        },
        {
            name: 'teamOrgNm',
            fieldName: 'teamOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '팀',
                showTooltip: false,
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '파트',
                showTooltip: false,
            },
        },

        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '내부거래처',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'cardEqpNo',
            fieldName: 'cardEqpNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'CAT ID',
                showTooltip: false,
            },
        },
        {
            name: 'trmsDtm',
            fieldName: 'trmsDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래일시',
                showTooltip: false,
            },
        },
        {
            name: 'dealClCd',
            fieldName: 'dealClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래구분',
                showTooltip: false,
            },
        },
        {
            name: 'cardOpStCd',
            fieldName: 'cardOpStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리상태',
                showTooltip: false,
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '변경일자',
                showTooltip: false,
            },
        },
        {
            name: 'aprvDt',
            fieldName: 'aprvDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '승인일자',
                showTooltip: false,
            },
        },
        {
            name: 'cnclDtm',
            fieldName: 'cnclDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '취소일자',
                showTooltip: false,
            },
        },
        {
            name: 'payOpDt',
            fieldName: 'payOpDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납일자',
                showTooltip: false,
            },
        },
        {
            name: 'prodSaleNo',
            fieldName: 'prodSaleNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'cntrctMgmtNum',
            fieldName: 'cntrctMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '계약관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'isuecoNm',
            fieldName: 'isuecoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '카드사명',
                showTooltip: false,
            },
        },
        {
            name: 'refNo',
            fieldName: 'refNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '레퍼런스번호',
                showTooltip: false,
            },
        },
        {
            name: 'aprvNo',
            fieldName: 'aprvNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '승인번호',
                showTooltip: false,
            },
        },
        {
            name: 'dealAmt',
            fieldName: 'dealAmt',
            type: 'data',
            styles: {
                textAlignment: 'right',
            },
            header: {
                text: '승인금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'istmtPrd',
            fieldName: 'istmtPrd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '할부개월',
                showTooltip: false,
            },
        },
        {
            name: 'rpsMsg',
            fieldName: 'rpsMsg',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '응답메세지',
                showTooltip: false,
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
    ],
}
