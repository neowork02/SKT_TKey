<template>
    <TCComDialog :dialogShow.sync="activeOpenDialog" size="1100px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">SKT 대리점/서브점/판매점팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div5">
                                <TCComComboBox
                                    v-model="searchParam.sktOrgClCd"
                                    :itemList="sktOrgClCdList"
                                    itemText="text"
                                    itemValue="value"
                                    labelName="거래처구분"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :disabled="isDisabledSktOrgClCd"
                                    :eRequired="true"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div5">
                                <TCComInput
                                    v-model="searchParam.sktOrgCd"
                                    labelName="대리점코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :disabled="isDisableSktOrgCd"
                                ></TCComInput>
                            </div>
                            <div class="formitem div5">
                                <TCComInput
                                    v-model="searchParam.orgNm"
                                    labelName="거래처명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :disabled="isDisabledOrgNm"
                                ></TCComInput>
                            </div>
                            <div class="formitem div5">
                                <TCComInput
                                    v-model="searchParam.sktSubCdNm"
                                    labelName="서브코드/명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div5">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- // input -->
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">거래처 목록</h4>
                        </div>
                        <!-- // SubTit  -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="agencyGrid"
                                ref="agencyGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                                @hook:mounted="gridMounted"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { BAS_BCO_AGENCYS_HEADER } from '@/const/grid/bas/bco/basBcoTbasDealIfHeader'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoTbasDealIfPop'
import commonApi from '@/api/common/commonCode'
//import moment from 'moment'
//import commonMsg from '@/utils/CommonMsg'
import CommonMixin from '@/mixins'
// import _ from 'lodash'

export default {
    name: 'BasBcoTbasDealIfPop',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: BAS_BCO_AGENCYS_HEADER,
            headerText: '',
            searchParam: {
                sktOrgClCd: '', // 조직구분
                sktOrgCd: '', // 대리점코드
                orgNm: '', // 조직명
                sktSubCdNm: '', // 서브점코드
            },
            isDisableSktOrgCd: false,
            isDisabledSktOrgClCd: false,
            isDisabledOrgNm: false,
            sktOrgClCdList: [
                { value: '05', text: '대리점' },
                { value: '06', text: '직영점' },
                { value: '07', text: '판매점' },
            ],
        }
    },
    computed: {
        activeOpenDialog: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('### watch parentParam')
                this.searchParam.sktOrgClCd =
                    value['sktOrgClCd'] == undefined ? '' : value['sktOrgClCd']
                this.searchParam.sktOrgCd =
                    value['sktOrgCd'] == undefined ? '' : value['sktOrgCd']
                this.searchParam.orgNm =
                    value['orgNm'] == undefined ? '' : value['orgNm']
                this.searchParam.sktSubCdNm =
                    value['sktSubCd'] == undefined ? '' : value['sktSubCd']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        console.log('### created')
        this.init()
    },
    mounted() {
        console.log('### mounted')
        this.gridObj = this.$refs.agencyGrid // Grid Object 설정
        this.initGrid()
    },
    methods: {
        async init() {
            console.log('### init')
            console.log(
                'this.searchParam.sktOrgClCd : ' + this.searchParam.sktOrgClCd
            )
            if (this.searchParam.sktOrgClCd !== '') {
                this.isDisabledSktOrgClCd = true
            }
            if (this.searchParam.sktOrgCd !== '') {
                this.isDisableSktOrgCd = true
            }
            if (this.searchParam.orgNm !== '') {
                // 20221109 : 황대리 요청으로 주석처리
                // this.isDisabledOrgNm = true
            }

            this.gridData = this.gridSetData()

            if (this.searchParam.sktOrgClCd !== '') {
                this.onSearch()
            }
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async initGrid() {
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false)
            //const commAgencyPtn = await this.getCommCodeList('AGENCY_PTN')
            //const commAgencyTyp = await this.getCommCodeList('AGENCY_TYP')

            // 조직 구분 lOV
            this.gridObj.gridView.columnByName('sktOrgClCd').values =
                CommonUtil.convListToGridLovValues(this.sktOrgClCdList, 'value')
            this.gridObj.gridView.columnByName('sktOrgClCd').labels =
                CommonUtil.convListToGridLovLabels(this.sktOrgClCdList, 'text')
            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },

        gridMounted() {
            console.log('gridMounted')
        },

        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        getTbasDealIfPop() {
            basBcoAgencysApi.getTbasDealIfPop(this.searchParam).then((res) => {
                console.log('getTbasDealIfPop then : ', res)
                this.gridObj.setRows(res)
            })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('대리점을 선택해주세요.', {
                    header: '대리점 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenDialog = false
        },

        onSearch() {
            console.log('this.sktOrgCd : ' + this.sktOrgCd)
            if (this.searchParam.sktOrgClCd === '') {
                this.showTcComAlert('조직구분은 필수 조건 항목입니다.', {
                    header: '조직구분 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })

                return
            } else {
                if (
                    this.searchParam.sktOrgClCd === '06' ||
                    this.searchParam.sktOrgClCd === '07'
                ) {
                    if (this.searchParam.sktOrgCd === '') {
                        var cdNm = '대리점 코드'
                        if (this.searchParam.sktOrgClCd === '07') {
                            cdNm = '채널 코드'
                        }

                        this.showTcComAlert(
                            '서브점 조회시 ' +
                                cdNm +
                                '는 필수 조건 항목입니다.',
                            {
                                size: '500',
                                confirmLabel: 'OK',
                            }
                        )

                        return
                    }
                }
            }
            this.getTbasDealIfPop()
        },

        onEnterKey() {
            this.onSearch()
        },
    },
}
</script>
