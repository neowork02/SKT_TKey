<!-----------------------------------------------
 * 업무그룹명: 분실,도난단말기 관리현황
 * 서브업무명: 분실,도난단말기 상태변경
 * 설명: 분실,도난단말기 상태변경 업데이트한다.
 * 작성자: P179234
 * 작성일: 2022.06.24
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">분실,도난단말기 상태변경</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="처리일"
                                    calType="D"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.opDt"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :codeVal.sync="reqParam.orgCd"
                                    :disabledAfter="true"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.orgNm"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="reqParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComComboBox
                                    :eRequired="true"
                                    labelName="RISK중분류"
                                    codeId="ZDIS_C_00171"
                                    ref="prchTypComboBox"
                                    :objAuth="objAuth"
                                    :addBlankItem="true"
                                    :blankItemText="'선택'"
                                    blankItemValue=""
                                    v-model="reqParam.riskMclCd"
                                    :filterFunc="filterFuncRiskMclCd"
                                />
                            </div>
                        </div>
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridLossRobberyProdMgmtCancelHeader"
                                ref="gridLossRobberyProdMgmtCancelHeader"
                                gridTitle="분실,도난단말기 상태변경"
                                :gridObj="gridObj"
                                :isPageRows="false"
                                :isExceldown="false"
                                :isExcelup="false"
                                :isNextPage="false"
                                :isPageCnt="false"
                                :isDelRow="true"
                                @chkDelRowBtn="gridchkDelRowBtn"
                            />
                            <TCRealGrid
                                id="gridLossRobberyProdMgmtCancel"
                                ref="gridLossRobberyProdMgmtCancel"
                                :fields="gridSet.fields"
                                :columns="gridSet.columns"
                                :styles="gridStyle"
                            />
                        </div>
                    </div>
                    <div class="textareaLayer_wrap">
                        <TCComTextArea
                            labelName="비고"
                            class="boxtype"
                            v-model="reqParam.rmks"
                        ></TCComTextArea>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="save"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 콜백 서비스 아이디
------------------------------------------------>
<script>
import { CommonGrid, CommonUtil } from '@/utils'
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
import disBeqLossRobberyProdApi from '@/api/biz/dis/beq/disBeqLossRobberyProdMgmt.js'
import { GRID_HEADER } from '@/const/grid/dis/beq/disBeqLossRobberyProdMgmtHeader.js'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'DisBeqLossRobberyProdMgmtChanging',
    mixins: [CommonMixin],
    components: { BasBcoAuthOrgTreesPopup },
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        lossRobberyProd: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
                this.$emit('update:addBadProd', value)
            },
        },
    },
    data() {
        return {
            objAuth: {},
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '300px',
            },
            gridSet: GRID_HEADER,
            calType5: 'DP',
            showBcoOrgAgencys: false,
            showBcoAuthOrgTrees: false,
            rowCnt: 15,
            searchForms: {},
            reqParam: {
                riskMclCd: '',
                orgCd: this.lossRobberyProd.orgCd,
                orgNm: this.lossRobberyProd.orgNm,
                inDealcoCd: '',
                opDt: this.getToday(),
                serNum: '',
                prodClCd: '',
                prodClNm: '',
                prodCd: '',
                prodNm: '',
                chrgrUserId: '',
                crdtPrchsPrc: '',
                mfactId: '',
                mfactNm: '',
                colorCd: '',
                colorNm: '',
                realPrchsPrc: '',
                riskStNm: '',
                place: '',
                rmks: '',
            },
            itemList1: [],
            opDt: [],
            prod: this.lossRobberyProd.dataList,
        }
    },
    mounted() {
        this.initParam()
        this.setGrid()
        console.log(this.prod)
    },
    methods: {
        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                riskMclCd: '',
                orgCd: this.lossRobberyProd.orgCd,
                orgNm: this.lossRobberyProd.orgNm,
                inDealcoCd: '',
                opDt: this.getToday(),
                serNum: '',
                prodClCd: '',
                prodClNm: '',
                prodCd: '',
                prodNm: '',
                chrgrUserId: '',
                crdtPrchsPrc: '',
                mfactId: '',
                mfactNm: '',
                colorCd: '',
                colorNm: '',
                realPrchsPrc: '',
                riskStNm: '',
                place: '',
                rmks: '',
            }
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.gridLossRobberyProdMgmtCancel
            this.gridHeaderObj = this.$refs.gridLossRobberyProdMgmtCancelHeader
            this.gridObj.setGridState(false)
            this.gridObj.gridView.setRowIndicator({ visible: true })
            this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
            this.gridObj.setRows(this.prod)
        },
        gridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        // delete row click
        gridchkDelRowBtn() {
            this.gridObj.gridView.commit()
            const row = this.gridObj.gridView.getCurrent()
            this.gridObj.dataProvider.removeRow(row.dataRow)
        },
        /* 불량기기 검색 */
        async search() {
            this.searchForms = { ...this.reqParam }
            await disBeqLossRobberyProdApi
                .getDisProdInfo(this.searchForms)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        if (res.gridList.length === 0) {
                            this.showTcComAlert('상품 검색 정보가 없습니다.')
                        } else {
                            this.reqParam = Object.assign(
                                {},
                                this.reqParam,
                                res.gridList[0]
                            )
                            console.log(this.reqParam)
                        }
                    } else {
                        this.showTcComAlert(
                            '불량기기 검색 정보를 불러오지 못했습니다.'
                        )
                    }
                })
        },
        /* 불량기기 상태해제 저장 */
        async save() {
            this.searchForms = {}
            const checked = this.check(this.reqParam)
            if (_.isEmpty(checked)) return
            this.searchForms = { ...checked }
            this.searchForms.opDt = CommonUtil.onlyNumber(this.searchForms.opDt)
            this.gridData.totalPage = 0
            this.searchForms.pageSize = this.rowCnt
            this.searchForms.pageNum = 1

            const rowsAll = this.gridObj.dataProvider.getJsonRows(0, -1)
            _.forEach(rowsAll, (item) => {
                Object.assign(item, this.reqParam)
            })

            console.log('rowsAll================', rowsAll)

            const formData = {
                rowDatas: rowsAll,
            }
            await disBeqLossRobberyProdApi
                .disBeqLossRobberyProdChanging(formData)
                .then(() => {
                    // 팝업종료
                    this.$emit('confirm', true)
                    this.activeOpen = false
                    // if (res === 'success') {
                    //     this.getDisInnAutoCnsgSet(this.searchForms.pageNum)
                    // }
                    // else {
                    //     this.showTcComAlert('배정대상 저장에 실패하였습니다.')
                    // }
                })
        },
        /* 불량기기 상태해제 저장시 조건 체크 */
        check(data) {
            const returnData =
                data.orgCd === ''
                    ? this.showTcComAlert('조직 정보가 없습니다.')
                    : data.riskMclCd === ''
                    ? this.showTcComAlert('RISK중분류 정보가 없습니다.')
                    : data.opDt === ''
                    ? this.showTcComAlert('등록일자 정보가 없습니다.')
                    : data.rmks === ''
                    ? this.showTcComAlert('비고 정보가 없습니다.')
                    : data

            if (!returnData) return ''
            if (
                returnData &&
                !(returnData.riskMclCd == '02' || returnData.riskMclCd == '03')
            ) {
                this.showTcComAlert('RISK중분류를 확인 하십시오.')
                return ''
            } else {
                return returnData
            }
        },
        filterFuncRiskMclCd(items) {
            return items.filter(
                (item) => item['commCdVal'] == '02' || item['commCdVal'] == '03'
            )
        },
        /* 내부조직팝업 */
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.reqParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        /* 내부조직팝업 - Icon 이벤트 처리 */
        onAuthOrgTreeIconClick() {
            this.resultAuthOrgTreeRows = []
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        /* 내부조직팝업 - TextField 엔터키 이벤트 처리 */
        onAuthOrgTreeEnterKey() {
            this.resultAuthOrgTreeRows = []
            // if (_.isEmpty(this.reqParam.orgNm)) {
            //     this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
            //     return
            // }
            this.getAuthOrgTreeList()
        },
        /* 내부조직팝업 - TextField Input 이벤트 이벤트 처리 */
        onAuthOrgTreeInput() {
            this.reqParam.orgCd = ''
        },
        /* 내부조직팝업 - 팝업 리턴 이벤트 이벤트 처리 */
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
        },
        /* 조직별 대리점팝업 */
        getOrgAgencyList() {
            basBcoOrgAgencysApi.getOrgAgencyList(this.reqParam).then((res) => {
                console.log('getOrgAgencyList then : ', res)
                if (res.length === 1) {
                    this.reqParam.agencyCd = _.get(res[0], 'agencyCd')
                    this.reqParam.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultOrgAgencyRows = res
                    this.showBcoOrgAgencys = true
                }
            })
        },
        /* 조직별 대리점팝업 - 돋보기 Icon 이벤트 */
        onOrgAgencyIconClick() {
            this.resultOrgAgencyRows = []
            if (!_.isEmpty(this.reqParam.agencyNm)) {
                this.getOrgAgencyList()
            } else {
                this.showBcoOrgAgencys = true
            }
        },
        /* 조직별 대리점팝업 - 엔터키 이벤트 */
        onOrgAgencyEnterKey() {
            this.resultOrgAgencyRows = []
            if (_.isEmpty(this.reqParam.agencyNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '대리점명을 입력해주세요.'
                return
            }
            this.getOrgAgencyList()
        },
        /* 조직별 대리점팝업 - Input 이벤트 */
        onOrgAgencyInput() {
            this.reqParam.agencyCd = ''
        },
        /* 조직별 대리점팝업 - 리턴 이벤트 */
        onOrgAgencyReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.reqParam.hldDealcoCd = _.get(returnData, 'agencyCd')
            this.reqParam.hldDealcoNm = _.get(returnData, 'agencyNm')
        },
        closeBtn() {
            this.activeOpen = false
        },
        /* 현재일자 확인(yyyy-mm-dd)*/
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
    },
}
</script>
