<!-----------------------------------------------
 * 업무그룹명: 재고관리현황>상품이력조회
 * 서브업무명: 상품이력조회
 * 설명: 상품이력조회
 * 작성자: P179237
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<!--
TO-DO
ds_disProdInfo 공통 제공 추후 수정 필요 *
-->
<template>
    <div class="content">
        <h1>상품이력조회</h1>
        <ul class="btn_area top">
            <li class="right"></li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        v-model="dsCondition.serNum"
                        labelName="일련번호"
                        @enterKey="cfSearch"
                    >
                    </TCComInput>
                </div>
                <!-- item 1-3 :오른쪽 정렬 버튼 영역 -->
                <div class="formitem div4">
                    <div class="rightArea btn">
                        <span class="inner">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_s btn_ty03"
                                eAttr="ico_verification"
                                labelName="조회"
                                @click="cfSearch"
                            />
                        </span>
                    </div>
                </div>
                <!-- //item 1-3 :오른쪽 정렬 버튼 영역 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform pt-4 vline">
                <div class="formitem div4">
                    <TCComInput
                        labelName="제조사"
                        v-model="dsProdInfo.mfactNm"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="색상"
                        v-model="dsProdInfo.colorNm"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="불량여부"
                        v-model="dsProdInfo.badYnNm"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="재고상태"
                        v-model="dsProdInfo.disStNm"
                        :disabled="true"
                    />
                </div>
            </div>
            <!-- //Search_line 2 -->
            <!-- Search_line 3 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        labelName="모델"
                        v-model="dsProdInfo.prodNm"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="현보유처"
                        v-model="dsProdInfo.hldDealcoNm"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="현조직"
                        v-model="dsProdInfo.hldOrgNm"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="모델코드"
                        v-model="dsProdInfo.prodCd"
                        :disabled="true"
                    />
                </div>
            </div>
            <!-- //Search_line 3 -->
            <!-- Search_line 4 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        labelName="매입단가"
                        v-model="dsProdInfo.disAmt"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="매입조직"
                        v-model="dsProdInfo.prchsOrgNm"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="구매유형"
                        v-model="dsProdInfo.prchTypNm"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="시연재고"
                        v-model="dsProdInfo.demoYn"
                        :disabled="true"
                    />
                </div>
            </div>
            <!-- //Search_line 4 -->
            <!-- Search_line 5 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        labelName="개봉여부"
                        v-model="dsProdInfo.openYnNm"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4_6"></div>
            </div>
            <!-- //Search_line 5 -->
        </div>
        <!-- //Search_div -->
        <div class="textareaLayer_wrap">
            <!-- :disabled="true" -->
            <TCComTextArea
                v-model="dsProdInfo.rmks"
                labelName=" 비고"
                class="boxtype"
                :maxLength="50"
            ></TCComTextArea>
        </div>
        <div class="btn_area_bottom">
            <TCComButton
                eClass="btn_ty02_point"
                :eLarge="true"
                @click="btnSaveOnClick"
                >저장</TCComButton
            >
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="상품이력조회"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
            />
            <!-- <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getPagingData"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            /> -->
        </div>
        <!-- 입고 -->
        <DisDsmProdHstInDtlPopup
            v-if="showPopupIn === true"
            ref="popup"
            :dialogShow.sync="showPopupIn"
            :popupParams.sync="popupParamsIn"
        />
        <!-- 출고 -->
        <DisDsmProdHstOutDtlPopup
            v-if="showPopupOut === true"
            ref="popup"
            :dialogShow.sync="showPopupOut"
            :popupParams.sync="popupParamsOut"
        />
        <!-- 판매 -->
        <DisDsmProdHstSaleInOutDtlPopup
            v-if="showPopupSaleInOut === true"
            ref="popup"
            :dialogShow.sync="showPopupSaleInOut"
            :popupParams.sync="popupParamsSaleInOut"
        />
        <!-- 재고이동 -->
        <DisDsmProdHstMovDtlPopup
            v-if="showPopupMov === true"
            ref="popup"
            :dialogShow.sync="showPopupMov"
            :popupParams.sync="popupParamsMov"
        />
        <!-- 재고상품 리스트 조회 -->
        <DisDsmProdHstBrwsSerNumPopup
            v-if="showPopupSerNum === true"
            ref="popup"
            :dialogShow.sync="showPopupSerNum"
            :popupParams.sync="popupParamsSerNum"
            @confirm="onReturnDisDsmProdHstBrwsSerNum"
        />
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonMsg, CommonGrid } from '@/utils' // CommonUtil,
import _ from 'lodash'

import { G_HEADER } from '@/const/grid/dis/dsm/disDsmProdHstBrwsHead'

import api from '@/api/biz/dis/dsm/disDsmProdHstBrws'
import attachedFileApi from '@/api/common/attachedFile'

import DisDsmProdHstInDtlPopup from '@/views/biz/dis/dsm/DisDsmProdHstInDtlPopup.vue'
import DisDsmProdHstOutDtlPopup from '@/views/biz/dis/dsm/DisDsmProdHstOutDtlPopup.vue'
import DisDsmProdHstSaleInOutDtlPopup from '@/views/biz/dis/dsm/DisDsmProdHstSaleInOutDtlPopup.vue'
import DisDsmProdHstMovDtlPopup from '@/views/biz/dis/dsm/DisDsmProdHstMovDtlPopup.vue'
import DisDsmProdHstBrwsSerNumPopup from '@/views/biz/dis/dsm/DisDsmProdHstBrwsSerNumPopup'

export default {
    name: 'DisDsmProdHstBrws',
    mixins: [CommonMixin],
    components: {
        DisDsmProdHstInDtlPopup,
        DisDsmProdHstOutDtlPopup,
        DisDsmProdHstSaleInOutDtlPopup,
        DisDsmProdHstMovDtlPopup,
        DisDsmProdHstBrwsSerNumPopup,
    },
    data() {
        return {
            indicatorOpt: { sort: 'ASC' },
            dsCondition: { serNum: '' }, // <<<<  테스트데이터 0234650

            dsProdInfo: {
                mfactNm: '',
                colorNm: '',
                colorCd: '',
                badYn: '',
                disStNm: '',
                prodNm: '',
                hldDealcoNm: '',
                hldOrgNm: '',
                prodCd: '',
                disAmt: '',
                prchsOrgNm: '',
                prchTypNm: '',
                demoYn: '',
                openYnNm: '',
                rmks: '',
            },

            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},
            view: G_HEADER,
            dsResult: [],

            objAuth: {}, // ?????
            // paging
            rowCnt: 15, // 표시할 행의 갯수

            // popup
            popupParamsIn: {},
            showPopupIn: false,
            popupParamsOut: {},
            showPopupOut: false,
            popupParamsSaleInOut: {},
            showPopupSaleInOut: false,
            popupParamsMov: {},
            showPopupMov: false,
            popupParamsSerNum: {},
            showPopupSerNum: false,

            //조회 파라미터
            reqParams: {},
        }
    },
    beforeRouteUpdate(to) {
        console.log('to: ', to)

        //alert(this.$route.fullPath)
        this.fInit(to)
    },
    created() {
        this.gridData = this.GridSetData()
    },
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 초기값 세팅
        this.fInit()
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            this.gridObj.setGridState(true)
            this.gridData = this.GridSetData()

            // 그리드 셀 클릭 이벤트
            this.gridObj.gridView.onCellClicked = (grid, clickData) => {
                if ('data' === clickData.cellType) {
                    const jsonRow = this.gridObj.dataProvider.getJsonRow(
                        clickData.dataRow
                    )

                    console.log('jsonRow.inoutClCd  >>>> ', jsonRow.inoutClCd)
                    console.log(
                        'jsonRow.inoutDtlClCd  >>>> ',
                        jsonRow.inoutDtlClCd
                    )
                    if (_.isEmpty(jsonRow.inoutClCd)) {
                        return
                    }

                    // this.popupParamsSaleInOut = jsonRow
                    // this.popupParamsSaleInOut.FV_WORK_CL = 'HST_SALE_OUT'
                    // this.showPopupSaleInOut = true

                    if ('100' == jsonRow.inoutClCd) {
                        if (
                            '104' == jsonRow.inoutDtlClCd ||
                            '105' == jsonRow.inoutDtlClCd
                        ) {
                            this.popupParamsSaleInOut = jsonRow
                            this.popupParamsSaleInOut.FV_WORK_CL = 'HST_SALE_IN'
                            this.showPopupSaleInOut = true
                        } else {
                            this.popupParamsIn = jsonRow
                            this.popupParamsIn.FV_WORK_CL = 'HST_IN'
                            this.showPopupIn = true
                        }
                    }
                    if ('200' == jsonRow.inoutClCd) {
                        if (
                            '204' == jsonRow.inoutDtlClCd ||
                            '205' == jsonRow.inoutDtlClCd
                        ) {
                            this.popupParamsSaleInOut = jsonRow
                            this.popupParamsSaleInOut.FV_WORK_CL =
                                'HST_SALE_OUT'
                            this.showPopupSaleInOut = true
                        } else {
                            this.popupParamsOut = jsonRow
                            this.popupParamsOut.FV_WORK_CL = 'HST_OUT'
                            this.showPopupOut = true
                        }
                    }
                    if ('300' == jsonRow.inoutClCd) {
                        this.popupParamsMov = jsonRow
                        this.popupParamsMov.FV_WORK_CL = 'HST_MOV'
                        this.showPopupMov = true
                    }
                    if ('004' == jsonRow.inoutClCd) {
                        this.popupParamsIn = jsonRow
                        this.popupParamsIn.FV_WORK_CL = 'HST_IN_SCHD'
                        this.showPopupIn = true
                    }
                    if ('005' == jsonRow.inoutClCd) {
                        this.popupParamsOut = jsonRow
                        this.popupParamsOut.FV_WORK_CL = 'HST_OUT_SCHD'
                        this.showPopupOut = true
                    }
                    if ('006' == jsonRow.inoutClCd) {
                        this.popupParamsMov = jsonRow
                        this.popupParamsMov.FV_WORK_CL = 'HST_MOV_SCHD'
                        this.showPopupMov = true
                    }
                }
            }
        },

        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        fInit: function (to) {
            // alert(this.$route.params.search)
            const router = to ?? this.$route
            if (router.params.search) {
                this.dsCondition.serNum = router.params.search
                this.cfSearch()
            }
        },
        // 비고저장
        btnSaveOnClick: function () {
            if (this.fCheckCondition()) {
                // 비고 저장
                const formData = {
                    dsCondition: {
                        rowData: {
                            prodCd: this.dsProdInfo.prodCd,
                            colorCd: this.dsProdInfo.colorCd,
                            rmks: this.dsProdInfo.rmks,
                            serNum: this.dsCondition.serNum,
                        },
                    },
                }
                console.log(formData)
                api.getProdHstRmksSave(formData).then(() => {
                    //상품이력조회
                    this.getProdInfo()
                })
            }
        },
        cfSearch: function () {
            this.dsProdInfo = {
                mfactNm: '',
                colorNm: '',
                colorCd: '',
                badYn: '',
                disStNm: '',
                prodNm: '',
                hldDealcoNm: '',
                hldOrgNm: '',
                prodCd: '',
                disAmt: '',
                prchsOrgNm: '',
                prchTypNm: '',
                demoYn: '',
                openYnNm: '',
                rmks: '',
            }
            if (this.fCheckCondition()) {
                this.dsResult = []
                this.gridObj.setRows([])

                this.dsCondition.pageSize = this.rowCnt
                this.gridData.totalPage = 0 // 이전페이지정보 초기화

                // ds_disProdInfo 조회 후 - 일련번호로 조회
                const formData = {
                    dsCondition: {
                        ...this.dsCondition, // serNum
                    },
                }

                const snLength = _.size(this.dsCondition.serNum)
                console.log('sernumber length >>>> ', snLength)
                if (
                    7 == snLength ||
                    8 == snLength ||
                    10 == snLength ||
                    11 == snLength ||
                    12 == snLength
                ) {
                    // 재고상품정보조회
                    api.getProdHstDisList(formData).then((resultData) => {
                        if (resultData) {
                            console.log(
                                'getProdHstDisList >>>>>>>>>> ',
                                resultData
                            )
                            if (resultData && resultData.length > 1) {
                                this.popupParamsSerNum.serNum =
                                    this.dsCondition.serNum
                                this.popupParamsSerNum.api = 'prodHst'
                                this.showPopupSerNum = true
                            } else if (resultData && resultData.length == 1) {
                                this.dsCondition.prodCd = resultData[0].prodCd
                                this.dsCondition.colorCd = resultData[0].colorCd
                                this.getProdInfo()
                            }
                            // this.dsCondition.prodCd = 'A06H' // <<<< 테스트 데이터
                            // this.dsCondition.colorCd = '10' //<<<< 테스트 데이터
                            // // ds_prodInfo 조회 - disprodinfo 결과값으로 prodinfo 조회
                            // this.getProdInfo()
                            //this.getPagingData(1)
                        }
                    })
                } else {
                    // 바코드조회
                    // api url 변경해서 추가하기 *****
                    api.getProdInfoBarCode(formData).then((resultData) => {
                        console.log('dsProdInfo<<<<<<<<<<<<< ', resultData)
                        if (resultData) {
                            this.dsProdInfo = resultData
                            //this.getPagingData(1)
                            this.getProdHsts()
                        }
                    })
                }
            }
        },
        onReturnDisDsmProdHstBrwsSerNum: function (retVal) {
            if (retVal.flag) {
                this.dsCondition.prodCd = retVal.data.prodCd
                this.dsCondition.colorCd = retVal.data.colorCd
                this.dsCondition.serNum = retVal.data.serNum
                this.getProdInfo()
            }
        },
        getProdInfo: function () {
            this.dsProdInfo = {}
            // this.dsCondition.prodCd = 'A06H' // <<<< 테스트 데이터
            // this.dsCondition.colorCd = '10' //<<<< 테스트 데이터

            //ds_disProdInfo
            const formData = {
                dsCondition: {
                    ...this.dsCondition,
                    // hldPlcId: '',
                },
            }

            // 재고상품정보조회
            api.getProdInfo(formData).then((resultData) => {
                console.log('dsProdInfo<<<<<<<<<<<<< ', resultData)
                if (resultData) {
                    this.dsProdInfo = resultData
                    //this.getPagingData(1)
                    this.getProdHsts()
                }
            })
        },
        getProdHsts: function () {
            const formData = this.getDsCondition()
            api.getProdHsts(formData).then((resultData) => {
                if (resultData) {
                    this.gridObj.setRows(resultData)
                    //페이지 정보
                    let pageInfo = {}
                    pageInfo.type = 'noPaging' //페이징이 없는경우
                    pageInfo.totalDataCnt =
                        this.gridObj.dataProvider.getRowCount() // 총건수
                    this.gridObj.setGridIndicator(pageInfo, this.indicatorOpt) //순번 셋팅
                }
            })
        },

        getPagingData: function (pageNum) {
            this.dsCondition.pageNum = pageNum
            const formData = this.getDsCondition()

            // 페이징 조회
            api.getProdHsts(formData).then((resultData) => {
                if (resultData) {
                    this.dsResult = resultData.gridList
                    this.gridObj.setRows(this.dsResult)
                    // 페이징 관련
                    this.gridObj.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.GridSetData() //초기화
                    this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
            })
        },
        // 조회조건 가져오기
        getDsCondition: function () {
            // 엑셀다운로드
            this.reqParams = this.dsCondition

            const formData = {
                dsCondition: {
                    ...this.dsCondition,
                },
            }
            return formData
        },
        fCheckCondition: function () {
            if (_.isEmpty(this.dsCondition.serNum)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '일련번호')
                )
                return false
            }
            if (this.dsCondition.serNum.length < 4) {
                this.showTcComAlert('일련번호는 4자리이상 입력해야 합니다.')
                return false
            }
            return true
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //Grid ExcelDown
        onClickDownload: function () {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/prodHstsExcelDown',
                this.reqParams
            )
        },
    },
}
</script>
