<template>
    <div>
        <ul class="btn_area top">
            <!-- <li class="left">
                <v-btn outlined class="btn_ty">삭제</v-btn>
            </li> -->
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="newBtn"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
                <!-- <TCComButton
                        color="btn2"
                        eClass="btn_ty01"
                        @click="saveBtn"
                        :objAuth="this.objAuth"
                    >
                        저장
                    </TCComButton> -->
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="menuGrpCd"
                        codeId="ZADM_C_00010"
                        labelName="업무구분"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :objAuth="objAuth"
                    ></TCComComboBox>
                    <!-- <TCComDatePicker
                        v-model="schdDt"
                        :calType="calType5"
                        labelName="세금계산서일자"
                    >
                    </TCComDatePicker> -->
                </div>
                <div class="formitem div4"></div>
                <div class="formitem div4"></div>
                <div class="formitem div4">
                    <!-- <TCComInputSearchText
                        labelName="전송조직"
                        :appendIconClass="''"
                        @appendIconClick="searchCommon('org')"
                        :objAuth="this.objAuth"
                        v-model="formSearchParams.orgNm"
                        :codeVal.sync="formSearchParams.orgCd"
                        :disabledAfter="true"
                        @input="onAuthOrgTreeInput"
                    /> -->
                    <!-- 
                    <TCComInputSearchText
                        labelName="대리점"
                        :appendIconClass="''"
                        @appendIconClick="searchCommon('agency')"
                        :objAuth="this.objAuth"
                        v-model="agencyNm"
                        :codeVal="formSearchParams.agencyCd"
                        :disabledAfter="true"
                    /> -->
                    <!-- 숫자 입력
                    <TCComInput
                        v-model="formSearchParams.userNm"
                        labelName="채번"
                        :size="150"
                        :maxlength="100"
                        :objAuth="this.objAuth"
                        inputRuleType="N"
                        @input="inputEvent()"
                    /> -->
                    <!-- <TCComInput
                        v-model="formSearchParams.userNm"
                        labelName="사용자"
                        :size="150"
                        :maxlength="100"
                        :objAuth="this.objAuth"
                        @input="inputEvent()"
                    /> -->
                </div>
            </div>
        </div>
        <!-- <BasBcoAuthOrgTreesPopup
            v-if="showBcoAuthOrgTrees"
            :parentParam="popupParam"
            :rows="resultAuthOrgTreeRows"
            :dialogShow.sync="showBcoAuthOrgTrees"
            @confirm="onAuthOrgTreeReturnData"
        /> -->
        <Detail1Popup
            v-if="showPopup1"
            :parentParam="searchPopup1"
            :rows="resultPopup1Rows"
            :dialogShow.sync="showPopup1"
            @confirm="onPopup1ReturnData"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/apm/aprvTypMgmt/helpers'
// eslint-disable-next-line no-unused-vars

import _ from 'lodash'

import { msgTxt } from '@/const/msg.Properties.js'
//====================내부조직팝업(권한)팝업====================
//import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
//====================//내부조직팝업(권한)팝업====================
//====================팝업1 팝업====================
import Detail1Popup from './Detail1Popup'
//====================//팝업1 팝업====================

export default {
    components: {
        //TCComComboBox,
        //BasBcoAuthOrgTreesPopup,
        Detail1Popup,
    },
    async created() {
        await this.initControls()
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            menuGrpCd: '',
            //calType5: 'DP', //'M' //'DP'
            //schdDt: [],
            // ds_usedCd: [
            //     {
            //         commCdVal: '1',
            //         commCdValNm: 'SMS',
            //     },
            //     {
            //         commCdVal: '2',
            //         commCdValNm: 'LMS',
            //     },
            // ],
            //clsDt: '',
            //agencyNm: '',
            //effUseYn: '',
            formSearchParams: {
                menuGrpCd: '', //업무구분
            },
            //====================내부조직팝업(권한)팝업관련====================
            // showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            // popupParam: {
            //     orgCd: '', // 내부조직팝업(권한)코드
            //     orgNm: '', // 내부조직팝업(권한)명
            // },
            // resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================팝업1 팝업관련====================
            showPopup1: false, // 팝업1 팝업 오픈 여부
            searchPopup1: {},
            resultPopup1Rows: [], // 팝업1 팝업 오픈 여부
            //====================//팝업1 팝업관련==================
        }
    },
    async mounted() {
        //화면초기 로딩시 바로 검색
        //this.searchBtn()
    },
    computed: {
        ...serviceComputed,
        commCdIds1: {
            get() {
                return this.commCdIds
            },
            //set(value) {},
        },
        saveDone1: {
            get() {
                return this.saveDoneA && this.saveDoneB
            },
            //set(value) {},
        },
    },
    methods: {
        ...serviceMethods,
        async initControls() {
            //this.defaultAssign_({ key: 'plantCd', value: this.user.plantCd }); //watch call searchList()
        },
        async initData() {
            // let today = moment(new Date()).format('YYYY-MM-01')
            // let today1 = moment(new Date()).format('YYYY-MM-DD')
            // this.schdDt = [today, today1]
            //this.clsDt = today
            //this.formSearchParams.clsDt = moment(new Date()).format('YYYYMMDD') //조회년월
            this.menuGrpCd = '' //조직
            this.formSearchParams.menuGrpCd = '' //조직

            // this.formSearchParams.fromDt = moment(new Date()).format('YYYYMM01')
            // this.formSearchParams.toDt = moment(new Date()).format('YYYYMMDD')

            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
        },
        // searchCommon(flag) {
        //     // TODO 공통팝업 호출
        //     if (flag === 'mfact') {
        //         alert('제조사')
        //     } else if (flag === 'org') {
        //         //alert('조직')
        //         if (this.formSearchParams.orgNm == '') {
        //             this.formSearchParams.orgId = ''
        //         }
        //         this.resultAuthOrgTreeRows = []
        //         this.showBcoAuthOrgTrees = true
        //     } else if (flag === 'prod') {
        //         alert('모델')
        //     } else if (flag === 'outPlc') {
        //         alert('보유처')
        //     }
        // },
        async initBtn() {
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 122 ~ data ',
                this.$data
            )
            await this.initData()
            //this.searchBtn() //이화면은 초기화가 다시 조회처리

            //CommonUtil.clearPage(this.$router)
        },
        async searchBtn() {
            // let fromDt = new Date(this.schdDt[0])
            // let toDt = new Date(this.schdDt[1])
            // if (fromDt > toDt) {
            //     this.showAlert_({
            //         title: '전송일자 오류',
            //         message: '시작일자가 마지막일자 보다 큽니다.',
            //     })
            //     return
            // }
            // if (
            //     moment(fromDt).format('YYYY-MM') !=
            //     moment(toDt).format('YYYY-MM')
            // ) {
            //     this.showAlert_({
            //         title: '전송일자 오류',
            //         message: '같은 월 검색만 됩니다.',
            //     })
            //     return
            // }
            //this.formSearchParams.clsDt = this.clsDt.replace(/-/g, '')
            //this.formSearchParams.fromDt = this.schdDt[0].replace(/-/g, '')
            //this.formSearchParams.toDt = this.schdDt[1].replace(/-/g, '')

            this.formSearchParams.menuGrpCd = this.menuGrpCd
            await this.defaultAssign_({ key: 'paging', value: this.initPaging })
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 197 ~ searchBtn ~ this.formSearchParams',
                this.formSearchParams
            )
            let par1 = _.clone(this.formSearchParams)
            await this.defaultAssign_({
                key: 'searchParams',
                value: par1,
            })
            await this.searchData()
        },
        async searchData() {
            let data1
            this.loading(true)
            await this.getBasApmAprvTypMgmtList_()
                .then((data) => {
                    data1 = data
                    // console.log(
                    //     '🚀 ~ file: SearchContent.vue ~ line 51 ~ searchData ~ data',
                    //     data
                    // )
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    //console.log('🚀 ~ file: SearchContent.vue ~ finally')
                    this.loading(false)
                    if (data1 !== undefined && data1.gridList.length == 0) {
                        this.toasting_({
                            message: msgTxt.MSG_00039.replace(/%s/g, ''),
                        })
                    }
                })
        },
        async newBtn() {
            //this.formSearchParams.clsDt = this.clsDt.replace(/-/g, '')

            this.resultPopup1Rows = []
            this.showPopup1 = true
            this.searchPopup1 = null
        },
        async saveBtn() {
            //this.formSearchParams.clsDt = this.clsDt.replace(/-/g, '')
            //this.formSearchParams.fromDt = this.schdDt[0].replace(/-/g, '')
            //this.formSearchParams.toDt = this.schdDt[1].replace(/-/g, '')

            //console.log('🚀 ~ file: saveBtn~ line 122 ~ data ', this.$data)
            await this.defaultAssign_({
                key: 'saveAction',
                value: true,
            })
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        async inputEvent() {
            // if (
            //     this.formSearchParams.orgNm == '' &&
            //     this.formSearchParams.userNm == ''
            // ) {
            //     await this.setUnFiltering_()
            // } else {
            //     let pass = {
            //         orgNm: this.formSearchParams.orgNm,
            //         userNm: this.formSearchParams.userNm,
            //     }
            //     await this.setFiltering_(pass)
            // }
        },
        // //====================내부조직팝업(권한)팝업관련====================
        // onAuthOrgTreeInput() {
        //     // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
        //     this.formSearchParams.orgCd = ''
        //     this.formSearchParams.orgId = ''
        //     this.formSearchParams.orgLvl = ''
        //     this.inputEvent()
        // },
        // onAuthOrgTreeReturnData(retrunData) {
        //     console.log('popup retrunData: ', retrunData)
        //     this.formSearchParams.orgNm = retrunData.orgNm
        //     this.formSearchParams.orgCd = retrunData.orgCd
        //     this.formSearchParams.orgId = retrunData.orgCd
        //     this.formSearchParams.orgLvl = retrunData.orgLvl
        // },
        // //====================내부조직팝업(권한)팝업관련====================
        // 팝업1 팝업 리턴 이벤트 처리
        async onPopup1ReturnData(returnData) {
            console.log('returnData new: ', returnData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     returnData.orgCd
            // )
            //저장후 다시 조회 하는 경우
            //this.$emit('Refresh')
            await this.searchData()
            console.log('returnData new: searchData ')
        },
    },
    watch: {
        async saveDone1(val, oldVal) {
            if (val == true) {
                console.log('saveDone1: ', val, oldVal)
                //saveAction 작업들이 모두 완료 되면 default 상태로 변환
                await this.defaultAssign_({
                    key: 'saveAction',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: false,
                })
            }
        },
    },
}
</script>
<style>
.boxhidden {
    opacity: 0;
    max-height: 1px;
}
.rightBox {
    display: flex;
    flex-direction: row;
    gap: 0.5em;
    height: 35px;
}
.rightBox .iteminput {
    width: 150px !important;
    flex-direction: row;
    flex-grow: 1;
    flex-shrink: 1;
}
.rightBox .v-input__slot {
    width: 140px !important;
    flex-direction: row;
    flex-grow: 1;
    flex-shrink: 1;
}
</style>
