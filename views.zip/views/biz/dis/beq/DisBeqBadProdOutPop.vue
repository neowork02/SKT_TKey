<!-----------------------------------------------
 * 업무그룹명: 불량기기관리현황
 * 서브업무명: 불량해제등록
 * 설명: 불량해제등록 업데이트한다.
 * 작성자: P179234
 * 작성일: 2022.06.7
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">불량해제등록</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="해제일자"
                                    calType="D"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.badCnclDt"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="일련번호"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.serNum"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="상품구분"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.prodClNm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="모델"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.prodNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="등록자"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.oprNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="보유처"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.hldPlcNm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="제조사"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.mfactNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="색상"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.colorNm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    labelName="해제사유"
                                    :rows="5"
                                    v-model="badCnclRsn"
                                />
                            </div>
                        </div>
                        <div class="btn_area_bottom">
                            <TCComButton
                                :eLarge="true"
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                @click="save()"
                            >
                                저장
                            </TCComButton>
                            <TCComButton
                                :eLarge="true"
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                @click="closeBtn()"
                            >
                                닫기
                            </TCComButton>
                        </div>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 콜백 서비스 아이디
 * 4 불량기기 내역 조회하여 해제 정보 체크
------------------------------------------------>
<script>
import { CommonMsg, CommonBizClosing } from '@/utils'
import disBeqBadProdApi from '@/api/biz/dis/beq/disBeqBadProdMgmt.js'
import CommonMixin from '@/mixins'

import _ from 'lodash'
import { SacCommon } from '@/views/biz/sac/js'

export default {
    name: 'BadProdOutPop',
    mixins: [CommonMixin],
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        badProdDataOut: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
        mainSearchForms: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    data() {
        return {
            objAuth: {},
            badProd: this.badProdDataOut,
            searchForms: this.mainSearchForms,
            editable: false,
            badCnclDt: '',
            badCnclRsn: '',
            param: {
                badCnclDt: '',
                badCnclRsn: '',
                prodCd: '',
                colorCd: '',
                serNum: '',
                rgstSeq: '',
            },
            dsBadEquiYn: {},
        }
    },

    mounted() {
        this.initData()
    },
    watch: {
        badCnclDt: {
            handler: function (value) {
                console.log(value)
                this.editable = value === '' ? false : true
            },
            deep: true,
            immediate: true,
        },
    },
    methods: {
        initData() {
            if (_.isEmpty(this.badProd.badCnclDt)) {
                this.badProd.badCnclDt = SacCommon.getToday()
            }
        },
        editBadProd() {
            this.activeOpen = false
            // console.log(this.badProd)
        },
        /* 불량기기해제 */
        async save() {
            if (await this.fCheckCondition()) {
                this.updateBadProdConfirm()
            }
        },
        /* 불량기기해제 */
        async updateBadProdConfirm() {
            const confirm = await this.showTcComConfirm(
                CommonMsg.getMessage('MSG_00063', '불량해제등록을')
            )
            if (confirm) {
                this.param = {
                    badCnclDt: SacCommon.onlyNumber(this.badProd.badCnclDt), //CommonUtil.onlyNumber(this.badCnclDt),
                    badCnclRsn: this.badCnclRsn,
                    prodCd: this.badProd.prodCd,
                    colorCd: this.badProd.colorCd,
                    serNum: this.badProd.serNum,
                    rgstSeq: this.badProd.rgstSeq,
                }
                const list = []
                list.push(this.param)
                const formData = { rowDatas: list }
                await disBeqBadProdApi.updateBadProdCncls(formData).then(() => {
                    this.$emit('confirm', true)
                    this.activeOpen = false
                })
            }
        },
        async fCheckCondition() {
            await this.fGetBadEquipYn()

            if (_.isEmpty(this.badProd.badCnclDt)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '해제일자')
                )
                return false
            }
            if (
                SacCommon.onlyNumber(this.badProd.badCnclDt) <
                SacCommon.onlyNumber(this.badProd.opDt)
            ) {
                this.showTcComAlert(
                    '불량해제일자는 불량등록일자[' +
                        this.badProd.opDt +
                        ']보다 과거로 등록할 수 없습니다.'
                )
                return false
            }

            if (!this.cfGetClsStatus()) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00185', ''))
                return false
            }

            if (
                !this.dsBadEquiYn ||
                (this.dsBadEquiYn && _.isEmpty(this.dsBadEquiYn.badStCd))
            ) {
                this.showTcComAlert('불량해제 된 상태입니다.')
                return false
            }

            return true
        },
        // 불량기기내역 조회
        async fGetBadEquipYn() {
            const params = {
                prodCd: this.badProd.prodCd,
                colorCd: this.badProd.colorCd,
                serNum: this.badProd.serNum,
                rgstSeq: this.badProd.rgstSeq,
            }
            // testdata
            // const params = {
            //     prodCd: 'A1AK',
            //     prodNm: '',
            //     colorCd: '10',
            //     serNum: '2207079',
            // }
            // testdata
            // console.log('불량해제 체크 파라미터 ==== >>> ', this.badProd)
            await disBeqBadProdApi.getBadProdYn(params).then((res) => {
                this.dsBadEquiYn = res
            })
        },

        // 마감월 체크
        async cfGetClsStatus() {
            const clsStatus = await CommonBizClosing.getClsStatus(
                'D',
                SacCommon.removeHyphen(this.badProd.badCnclDt),
                'STK',
                this.searchForms.orgCd
            )
            if (clsStatus && 'CLS' == clsStatus.clsStCd) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00185', ''))
                return false
            }
            return true
        },

        closeBtn() {
            this.activeOpen = false
        },
    },
}
</script>
