<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="500px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">첨부파일</p>
                <div class="layerCont">
                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="fileAddPopupGridHeader"
                            ref="fileAddPopupGridHeader"
                            gridTitle="파일첨부"
                            :gridObj="fileGridObj"
                            :isDelRow="true"
                            :isFileInput="true"
                            @fileChange="onFileChange"
                            @chkDelRowBtn="onSelDelRow"
                        />
                        <TCRealGrid
                            id="fileAddPopupGrid"
                            ref="fileAddPopupGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                            @hook:mounted="gridMounted"
                        />
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty01"
                            :objAuth="objAuth"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<style></style>
<script>
import { CommonGrid, FileUtil } from '@/utils'
import { fileAddHeader } from '@/const/grid/common/commonHeader'
import CommonMixin from '@/mixins'
import attachedFileApi from '@/api/common/attachedFile'
import _ from 'lodash'
export default {
    name: 'AttachedFileAddPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        fileList: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Grid Class init
            gridData: this.gridSetData(),
            fileGridObj: {},
            fileGridHeaderObj: {},
            view: fileAddHeader,
            toggleActive: false,
            objAuth: {},
            //각각 엘리먼트 컴포넌트 v-model
            searchForms: {},
            rowCnt: 100,
            fileListArr: [],
        }
    },
    created() {
        this.init()
    },
    mounted() {
        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.fileGridObj = this.$refs.fileAddPopupGrid
        this.fileGridHeaderObj = this.$refs.fileAddPopupGridHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        //Default false
        this.fileGridObj.setGridState(false)
        this.fileGridObj.gridView.setRowIndicator({ visible: true }) //인디케이터 사용여부

        this.fileGridObj.gridView.onCellItemClicked = (
            grid,
            index,
            clickData
        ) => {
            if (clickData.type == 'link') {
                this.downloadFileParam = {
                    screenId: grid.getValue(index.dataRow, 'screenId'),
                    docId: grid.getValue(index.dataRow, 'docId'),
                    filePathNm: grid.getValue(index.dataRow, 'filePathNm'),
                    fileNm: grid.getValue(index.dataRow, 'name'),
                    fileType: grid.getValue(index.dataRow, 'fileType'),
                }
                this.downloadFile()
                return false
            }
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        fileList: {
            handler: function () {
                //등록된 파일이 있는경우
                if (_.size(this.fileList) > 0) {
                    setTimeout(() => {
                        this.setFileList(this.fileList)
                    }, 400)
                }
            },
            deep: true,
            immediate: true,
        },
    },
    methods: {
        init: function () {
            this.gridData = this.gridSetData()
            this.fileListArr = []
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        gridMounted: function () {
            // if (this.fileList.length > 0) {
            //     this.fileGridObj = this.$refs.fileAddGrid1
            //     this.fileGridHeaderObj = this.$refs.fileAddGridHeader1
            //     console.log('this.fileGridObj', this.fileGridObj)
            //     this.onFileChange(this.fileList)
            // }
        },
        downloadFile() {
            attachedFileApi.downLoadFile(
                '/api/v1/backend/resource/common/file-download',
                this.downloadFileParam
            )
        },
        onFileChange(fileAdd) {
            //Validation File Type
            let fileType = {
                maxSize: 1024 * 1024 * 15,
                totalMaxSize: 1024 * 1024 * 30,
                mimeTypes: null,
                fileExts: [
                    'xls',
                    'xlsx',
                    'ppt',
                    'pptx',
                    'doc',
                    'docx',
                    'hwp',
                    'jpg',
                    'gif',
                    'bmp',
                    'pdf',
                    'png',
                    'jpeg',
                ],
            }
            let gridFileInfo = [] //그리드에 표시될 데이터 배열변수
            let gridFileObj = {} //그리드에 표시될 데이터 Object 임시변수
            let fileInfoObj = {}
            // this.fileListArr = [] // 초기화

            fileAdd.forEach((item) => {
                gridFileObj = {}
                fileInfoObj = {}
                gridFileObj.name = item.name
                gridFileObj.size = item.size
                fileInfoObj = item

                //Validation Check
                let fileValid = FileUtil.vFileValid(
                    gridFileInfo,
                    item,
                    fileType
                )

                if (fileValid == true) {
                    //그리드 내에 동일한 파일명 검사
                    if (
                        this.fileGridObj.dataProvider
                            .getJsonRows(0, -1)
                            .filter((e) => e.name === item.name).length > 0
                    ) {
                        this.showTcComAlert('동일한 파일명이 존재합니다.')
                    } else {
                        this.fileListArr.push({
                            file: fileInfoObj,
                            __rowState: 'created',
                        })
                        gridFileInfo.push(gridFileObj)
                    }
                    //Validation Error Msg
                } else {
                    this.showTcComAlert(fileValid.warnningMessage)
                }
            })

            //그리드에 표시
            this.fileGridObj.dataProvider.fillJsonData(gridFileInfo, {
                fillMode: 'append',
            })
        },

        setFileList(fileList) {
            let gridFileInfo = [] //그리드에 표시될 데이터 배열변수
            let gridFileObj = {} //그리드에 표시될 데이터 Object 임시변수
            let fileInfoObj = {}
            // this.fileListArr = [] // 초기화

            fileList.forEach((item) => {
                gridFileObj = {}
                fileInfoObj = {}
                gridFileObj.name = item.name
                gridFileObj.size = item.size
                gridFileObj.screenId = item.screenId ?? ''
                gridFileObj.docId = item.docId ?? ''
                gridFileObj.filePathNm = item.filePathNm ?? ''
                gridFileObj.fileType = item.fileType ?? ''
                fileInfoObj = item

                if (_.isEmpty(item.docId)) {
                    this.fileListArr.push({
                        file: fileInfoObj,
                        __rowState: 'created',
                    })
                }
                gridFileInfo.push(gridFileObj)
            })

            //그리드에 표시
            this.fileGridObj.dataProvider.setRows(gridFileInfo)
        },

        onSelDelRow() {
            const current = this.fileGridObj.gridView.getCurrent()
            const jsonRow = this.fileGridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            const findIndex = _.findIndex(this.fileListArr, (item) => {
                return item.file.name === jsonRow.name
            })
            if (findIndex > -1) {
                this.fileListArr.splice(findIndex, 1)
            }
            this.gridData = this.fileGridHeaderObj.focusDelRow(this.gridData)
        },

        onConfirm() {
            const fileInfo = {
                addFile: this.fileListArr,
                delFile: this.gridData._delRows,
            }
            this.$emit('confirm', fileInfo)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },
    },
}
</script>
