'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: '__rowState',
        dataType: ValueType.TEXT,
        visible: false,
    },
    // {
    //     fieldName: 'orgNm3',
    //     editable: false,
    //     header: { text: '팀' },
    //     type: 'data',
    //     dataType: ValueType.TEXT,
    // },
    // {
    //     fieldName: 'orgNm4',
    //     editable: false,
    //     header: { text: 'PT' },
    //     type: 'data',
    //     dataType: ValueType.TEXT,
    // },
    {
        fieldName: 'orgTree',
        editable: false,
        header: { text: '조직' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'svcDt',
        editable: false,
        header: { text: '매출일' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'clNm',
        editable: false,
        header: { text: '구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accPlc',
        editable: false,
        header: { text: '정산처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accPlcNm',
        editable: false,
        header: { text: '정산처명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'salePlc',
        editable: false,
        header: { text: '판매처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'salePlcNm',
        editable: false,
        header: { text: '판매처명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeyChannelCd',
        editable: false,
        header: { text: 'P코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'saleChrgrNm',
        editable: false,
        header: { text: '영업담당자' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'eqpMdlNm',
        editable: false,
        header: { text: '모델' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'eqpSerNum',
        editable: false,
        header: { text: '일련번호' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accAmt',
        editable: false,
        header: { text: '매입계산서금액' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'rmks',
        editable: false,
        header: { text: '기타' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = [
    // 'orgNm3',
    // 'orgNm4',
    'orgTree',
    'svcDt',
    'clNm',
    {
        name: 'sellerInfo',
        header: { text: '판매정보' },
        direction: 'horizontal',
        items: ['accPlc', 'accPlcNm', 'salePlc', 'salePlcNm', 'ukeyChannelCd'],
    },
    'saleChrgrNm',
    {
        name: 'deviceInfo',
        header: { text: '단말기/USIM정보' },
        direction: 'horizontal',
        items: ['eqpMdlNm', 'eqpSerNum'],
    },
    'accAmt',
    'rmks',
]
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {
    adpayMgmtVoList: [],
}

export { GRID_HEADER, MOCK_DATA }
