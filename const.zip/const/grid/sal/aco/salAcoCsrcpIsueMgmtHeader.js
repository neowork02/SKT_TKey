/*****************************************
 * 업무그룹명: 판매관리
 * 서브업무명: 일정산
 * 설명: 판매관리-일정산-현금영수증발행관리 그리드 헤더
 * 작성자: P179234
 * 작성일: 2022.08.09
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'chkable',
            dataType: ValueType.TEXT, //체크가능유무
        },
        {
            fieldName: 'issueProcStNm',
            dataType: ValueType.TEXT, //현금영수증진행상태
        },
        {
            fieldName: 'issueProcSt',
            dataType: ValueType.TEXT, //현금영수증진행상태
        },
        {
            fieldName: 'aprvNum',
            dataType: ValueType.TEXT, //현금영수증승인번호
        },
        {
            fieldName: 'saleChgSeq',
            dataType: ValueType.TEXT, //판매구분
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, //조직트리
        },
        {
            fieldName: 'orgId2Nm',
            dataType: ValueType.TEXT, //사업담당
        },
        {
            fieldName: 'orgId2',
            dataType: ValueType.TEXT, //사업담당
        },
        {
            fieldName: 'orgId3Nm',
            dataType: ValueType.TEXT, //영업팀
        },
        {
            fieldName: 'orgId3',
            dataType: ValueType.TEXT, //영업팀
        },
        {
            fieldName: 'newOrgIdNm',
            dataType: ValueType.TEXT, //영업센터
        },
        {
            fieldName: 'newOrgId',
            dataType: ValueType.TEXT, //영업센터
        },
        {
            fieldName: 'ukeyAgencyCd',
            dataType: ValueType.TEXT, //D코드
        },
        {
            fieldName: 'ukeyAgencyNm',
            dataType: ValueType.TEXT, //대리점
        },
        {
            fieldName: 'ukeySubCd',
            dataType: ValueType.TEXT, //서브코드
        },
        {
            fieldName: 'ukeySubNm',
            dataType: ValueType.TEXT, //서브점명
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'dealCoCd',
            dataType: ValueType.TEXT, //판매처코드
        },
        {
            fieldName: 'dealCoNm',
            dataType: ValueType.TEXT, //판매처명
        },
        {
            fieldName: 'stlPlcCd',
            dataType: ValueType.TEXT, //정산처코드
        },
        {
            fieldName: 'stlPlcNm',
            dataType: ValueType.TEXT, //정산처
        },
        {
            fieldName: 'svcDtm',
            dataType: ValueType.TEXT, //최초개통일시
        },
        {
            fieldName: 'saleDtm',
            dataType: ValueType.TEXT, //Swing처리일시
        },
        {
            fieldName: 'saleChgDtm',
            dataType: ValueType.TEXT, //매출일시
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, //수납처리일시
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, //서비스관리번호
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, //판매관리번호
        },
        {
            fieldName: 'settlCond',
            dataType: ValueType.TEXT, //단말기결제조건
        },
        {
            fieldName: 'mdlCd',
            dataType: ValueType.TEXT, //모델명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'allotSale',
            dataType: ValueType.NUMBER, //할부
        },
        {
            fieldName: 'advanceDc',
            dataType: ValueType.NUMBER, //선할인
        },
        {
            fieldName: 'swingCashAmt',
            dataType: ValueType.NUMBER, //Swing현금매출
        },
        {
            fieldName: 'psppCard',
            dataType: ValueType.NUMBER, //PSPP현금매출(카드)
        },
        {
            fieldName: 'psppCash',
            dataType: ValueType.NUMBER, //PSPP현금매출(현금)
        },
        {
            fieldName: 'tkeypCard',
            dataType: ValueType.NUMBER, //T.Key+현금매출(카드)
        },
        {
            fieldName: 'tkeypCash',
            dataType: ValueType.NUMBER, //T.Key+현금매출(현금)
        },
        {
            fieldName: 'totAmt',
            dataType: ValueType.NUMBER, //현금영수증발행금액
        },
        {
            fieldName: 'dcAmt',
            dataType: ValueType.NUMBER, //할인금액
        },
        {
            fieldName: 'gnrlCmms',
            dataType: ValueType.NUMBER, //판매수수료
        },
        {
            fieldName: 'polPassYn',
            dataType: ValueType.TEXT, //적정성여부
        },
        {
            fieldName: 'polValeYn',
            dataType: ValueType.TEXT, //적정성검증여부
        },
        {
            fieldName: 'issueSignType',
            dataType: ValueType.TEXT, //현금영수증발행구분
        },
        {
            fieldName: 'statConfMask',
            dataType: ValueType.TEXT, //현금영수증발행정보
        },
        {
            fieldName: 'ntsTrnsfDt',
            dataType: ValueType.TEXT, //발행일
        },
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, //차수
        },
        {
            fieldName: 'polValeDt',
            dataType: ValueType.TEXT, //검증일
        },
        {
            fieldName: 'salGubn',
            dataType: ValueType.TEXT, //판매구분
        },
        {
            fieldName: 'statConf', // 현금영수증발행정보
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trnsfDt', // 발행일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoCl1', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cash2Amt', // CASH2금액
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chkable',
            fieldName: 'chkable',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '체크가능',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'issueProcStNm',
            fieldName: 'issueProcStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증진행상태',
                showTooltip: false,
            },
        },
        {
            name: 'issueProcSt',
            fieldName: 'issueProcSt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증진행상태',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'aprvNum',
            fieldName: 'aprvNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증승인번호',
                showTooltip: false,
            },
        },
        {
            name: 'saleChgSeq',
            fieldName: 'saleChgSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매구분',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
        },
        {
            name: 'orgId2Nm',
            fieldName: 'orgId2Nm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgId2',
            fieldName: 'orgId2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgId3Nm',
            fieldName: 'orgId3Nm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업팀',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgId3',
            fieldName: 'orgId3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업팀',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'newOrgIdNm',
            fieldName: 'newOrgIdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전문영업센터',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'newOrgId',
            fieldName: 'newOrgId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전문영업센터',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'ukeyAgencyCd',
            fieldName: 'ukeyAgencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'D코드',
                showTooltip: false,
            },
        },
        {
            name: 'ukeyAgencyNm',
            fieldName: 'ukeyAgencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점',
                showTooltip: false,
            },
        },
        {
            name: 'ukeySubCd',
            fieldName: 'ukeySubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서브코드',
                showTooltip: false,
            },
        },
        {
            name: 'ukeySubNm',
            fieldName: 'ukeySubNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서브점명',
                showTooltip: false,
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',

            styleName: 'center-column',
            header: '매장코드',
        },
        {
            name: 'dealCoCd',
            fieldName: 'dealCoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoNm',
            fieldName: 'dealCoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매처명',
                showTooltip: false,
            },
        },
        {
            name: 'stlPlcCd',
            fieldName: 'stlPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
        },
        {
            name: 'stlPlcNm',
            fieldName: 'stlPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처',
                showTooltip: false,
            },
        },
        {
            name: 'svcDtm',
            fieldName: 'svcDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초개통일시',
                showTooltip: false,
            },
        },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing처리일시',
                showTooltip: false,
            },
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매출일시',
                showTooltip: false,
            },
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납처리일시',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'settlCond',
            fieldName: 'settlCond',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기결제조건',
                showTooltip: false,
            },
        },
        {
            name: 'mdlCd',
            fieldName: 'mdlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'allotSale',
            fieldName: 'allotSale',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '할부',
                showTooltip: false,
            },
        },
        {
            name: 'advanceDc',
            fieldName: 'advanceDc',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '선할인',
                showTooltip: false,
            },
        },
        {
            name: 'swingCashAmt',
            fieldName: 'swingCashAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'Swing현금매출',
                showTooltip: false,
            },
        },
        {
            name: 'psppCard',
            fieldName: 'psppCard',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'PSPP현금매출(카드)',
                showTooltip: false,
            },
        },
        {
            name: 'psppCash',
            fieldName: 'psppCash',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'PSPP현금매출(현금)',
                showTooltip: false,
            },
        },
        {
            name: 'tkeypCard',
            fieldName: 'tkeypCard',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'T.Key+현금매출(카드)',
                showTooltip: false,
            },
        },
        {
            name: 'tkeypCash',
            fieldName: 'tkeypCash',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'T.Key+현금매출(현금)',
                showTooltip: false,
            },
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '현금영수증발행금액',
                showTooltip: false,
            },
        },
        {
            name: 'dcAmt',
            fieldName: 'dcAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '할인금액',
                showTooltip: false,
            },
        },
        {
            name: 'gnrlCmms',
            fieldName: 'gnrlCmms',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '판매수수료',
                showTooltip: false,
            },
        },
        {
            name: 'polPassYn',
            fieldName: 'polPassYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '적정성여부',
                showTooltip: false,
            },
        },
        {
            name: 'polValeYn',
            fieldName: 'polValeYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '적정성검증여부',
                showTooltip: false,
            },
        },
        {
            name: 'issueSignType',
            fieldName: 'issueSignType',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '현금영수증발행구분',
                showTooltip: false,
            },
        },
        {
            name: 'statConfMask',
            fieldName: 'statConfMask',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증발행정보',
                showTooltip: false,
            },
        },
        {
            name: 'ntsTrnsfDt',
            fieldName: 'ntsTrnsfDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '발행일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '차수',
                showTooltip: false,
            },
        },
        {
            name: 'polValeDt',
            fieldName: 'polValeDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '검증일',
                showTooltip: false,
            },
            textFormat:
                '([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'salGubn',
            fieldName: 'salGubn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매구분',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'statConf',
            fieldName: 'statConf',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증발행정보',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'trnsfDt',
            fieldName: 'trnsfDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '발행일',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'dealCoCl1',
            fieldName: 'dealCoCl1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'cash2Amt',
            fieldName: 'cash2Amt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'CASH2금액',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'chk',
                showTooltip: false,
            },
            visible: false,
        },
    ],
}

export const GRID_HEADER_DTL = {
    fields: [
        {
            fieldName: 'chkable',
            dataType: ValueType.TEXT, //체크가능유무
        },
        {
            fieldName: 'issueProcStNm',
            dataType: ValueType.TEXT, //현금영수증진행상태
        },
        {
            fieldName: 'issueProcSt',
            dataType: ValueType.TEXT, //현금영수증진행상태
        },
        {
            fieldName: 'aprvNum',
            dataType: ValueType.TEXT, //현금영수증승인번호
        },
        {
            fieldName: 'orgAprvNum',
            dataType: ValueType.TEXT, //원현금영수증승인번호
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, //조직트리
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'orgId2Nm',
            dataType: ValueType.TEXT, //사업담당
        },
        {
            fieldName: 'orgId2',
            dataType: ValueType.TEXT, //사업담당
        },
        {
            fieldName: 'orgId3Nm',
            dataType: ValueType.TEXT, //팀
        },
        {
            fieldName: 'orgId3',
            dataType: ValueType.TEXT, //팀
        },
        {
            fieldName: 'newOrgIdNm',
            dataType: ValueType.TEXT, //PT
        },
        {
            fieldName: 'newOrgId',
            dataType: ValueType.TEXT, //PT
        },
        {
            fieldName: 'stlPlcNm',
            dataType: ValueType.TEXT, //정산처
        },
        {
            fieldName: 'ukeyAgencyNm',
            dataType: ValueType.TEXT, //대리점
        },
        {
            fieldName: 'ukeySubCd',
            dataType: ValueType.TEXT, //서브코드
        },
        {
            fieldName: 'svcDtm',
            dataType: ValueType.TEXT, //최초개통일시
        },
        {
            fieldName: 'saleDtm',
            dataType: ValueType.TEXT, //Swing처리일시
        },
        {
            fieldName: 'saleChgDtm',
            dataType: ValueType.TEXT, //매출일시
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, //수납처리일시
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, //서비스관리번호
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, //판매관리번호
        },
        {
            fieldName: 'settlCond',
            dataType: ValueType.TEXT, //단말기결제조건
        },
        {
            fieldName: 'mdlCd',
            dataType: ValueType.TEXT, //모델명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'allotSale',
            dataType: ValueType.NUMBER, //할부
        },
        {
            fieldName: 'advanceDc',
            dataType: ValueType.NUMBER, //선할인
        },
        {
            fieldName: 'swingCashAmt',
            dataType: ValueType.NUMBER, //Swing현금매출
        },
        {
            fieldName: 'psppCard',
            dataType: ValueType.NUMBER, //PSPP현금매출(카드)
        },
        {
            fieldName: 'psppCash',
            dataType: ValueType.NUMBER, //PSPP현금매출(현금)
        },
        {
            fieldName: 'tkeypCard',
            dataType: ValueType.NUMBER, //T.Key+현금매출(카드)
        },
        {
            fieldName: 'tkeypCash',
            dataType: ValueType.NUMBER, //T.Key+현금매출(현금)
        },
        {
            fieldName: 'totAmt',
            dataType: ValueType.NUMBER, //현금영수증발행금액
        },
        {
            fieldName: 'dcAmt',
            dataType: ValueType.NUMBER, //할인금액
        },
        {
            fieldName: 'gnrlCmms',
            dataType: ValueType.NUMBER, //판매수수료
        },
        {
            fieldName: 'polPassYn',
            dataType: ValueType.TEXT, //적정성여부
        },
        {
            fieldName: 'polValeYn',
            dataType: ValueType.TEXT, //적정성검증여부
        },
        {
            fieldName: 'issueSignType',
            dataType: ValueType.TEXT, //현금영수증발행구분
        },
        {
            fieldName: 'statConfMask',
            dataType: ValueType.TEXT, //현금영수증발행정보
        },
        {
            fieldName: 'statConf',
            dataType: ValueType.TEXT, //현금영수증발행정보
        },
        {
            fieldName: 'ntsTrnsfDt',
            dataType: ValueType.TEXT, //발행일
        },
        {
            fieldName: 'inputSysCl',
            dataType: ValueType.TEXT, //입력구분
        },
        {
            fieldName: 'issueStat',
            dataType: ValueType.TEXT, //오류내용
        },
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stlPlcCd',
            dataType: ValueType.TEXT, // 정산처코드
        },
        {
            fieldName: 'bizNum',
            dataType: ValueType.TEXT, // 사업자번호
        },
        {
            fieldName: 'fixCrdtPrchsPrc',
            dataType: ValueType.TEXT, // 확정여신가
        },
        {
            fieldName: 'trnsfDt',
            dataType: ValueType.TEXT, // 발행일
        },
        {
            fieldName: 'signYn',
            dataType: ValueType.TEXT, // 기명여부
        },
    ],
    columns: [
        {
            name: 'chkable',
            fieldName: 'chkable',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '체크가능',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'issueProcStNm',
            fieldName: 'issueProcStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증진행상태',
                showTooltip: false,
            },
        },
        {
            name: 'issueProcSt',
            fieldName: 'issueProcSt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증진행상태',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'aprvNum',
            fieldName: 'aprvNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증승인번호',
                showTooltip: false,
            },
        },
        {
            name: 'orgAprvNum',
            fieldName: 'orgAprvNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '원현금영수증승인번호',
                showTooltip: false,
            },
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styleName: 'center-column',
            header: '매장코드',
        },
        {
            name: 'orgId2Nm',
            fieldName: 'orgId2Nm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgId2',
            fieldName: 'orgId2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgId3Nm',
            fieldName: 'orgId3Nm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '팀',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgId3',
            fieldName: 'orgId3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '팀',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'newOrgIdNm',
            fieldName: 'newOrgIdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'PT',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'newOrgId',
            fieldName: 'newOrgId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'PT',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'stlPlcNm',
            fieldName: 'stlPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처',
                showTooltip: false,
            },
        },
        {
            name: 'ukeyAgencyNm',
            fieldName: 'ukeyAgencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점',
                showTooltip: false,
            },
        },
        {
            name: 'ukeySubCd',
            fieldName: 'ukeySubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서브코드',
                showTooltip: false,
            },
        },
        {
            name: 'svcDtm',
            fieldName: 'svcDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초개통일시',
                showTooltip: false,
            },
        },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing처리일시',
                showTooltip: false,
            },
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매출일시',
                showTooltip: false,
            },
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납처리일시',
                showTooltip: false,
            },
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'settlCond',
            fieldName: 'settlCond',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기결제조건',
                showTooltip: false,
            },
        },
        {
            name: 'mdlCd',
            fieldName: 'mdlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'allotSale',
            fieldName: 'allotSale',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '할부',
                showTooltip: false,
            },
        },
        {
            name: 'advanceDc',
            fieldName: 'advanceDc',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '선할인',
                showTooltip: false,
            },
        },
        {
            name: 'swingCashAmt',
            fieldName: 'swingCashAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'Swing현금매출',
                showTooltip: false,
            },
        },
        {
            name: 'psppCard',
            fieldName: 'psppCard',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'PSPP현금매출(카드)',
                showTooltip: false,
            },
        },
        {
            name: 'psppCash',
            fieldName: 'psppCash',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'PSPP현금매출(현금)',
                showTooltip: false,
            },
        },
        {
            name: 'tkeypCard',
            fieldName: 'tkeypCard',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'T.Key+현금매출(카드)',
                showTooltip: false,
            },
        },
        {
            name: 'tkeypCash',
            fieldName: 'tkeypCash',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'T.Key+현금매출(현금)',
                showTooltip: false,
            },
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '현금영수증발행금액',
                showTooltip: false,
            },
        },
        {
            name: 'dcAmt',
            fieldName: 'dcAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '할인금액',
                showTooltip: false,
            },
        },
        {
            name: 'gnrlCmms',
            fieldName: 'gnrlCmms',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '판매수수료',
                showTooltip: false,
            },
        },
        {
            name: 'polPassYn',
            fieldName: 'polPassYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '적정성여부',
                showTooltip: false,
            },
        },
        {
            name: 'polValeYn',
            fieldName: 'polValeYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '적정성검증여부',
                showTooltip: false,
            },
        },
        {
            name: 'issueSignType',
            fieldName: 'issueSignType',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '현금영수증발행구분',
                showTooltip: false,
            },
        },
        {
            name: 'statConfMask',
            fieldName: 'statConfMask',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증발행정보',
                showTooltip: false,
            },
        },
        {
            name: 'statConf',
            fieldName: 'statConf',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'statConf',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'ntsTrnsfDt',
            fieldName: 'ntsTrnsfDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '발행일',
                showTooltip: false,
            },
        },
        {
            name: 'inputSysCl',
            fieldName: 'inputSysCl',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입력구분',
                showTooltip: false,
            },
        },
        {
            name: 'issueStat',
            fieldName: 'issueStat',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류내용',
                showTooltip: false,
            },
        },
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채크',
                showTooltip: false,
            },
            visible: false,
        },
    ],
}

export const GRID_HEADER_ADQ_MGMT = {
    fields: [
        {
            fieldName: 'aprvNum',
            dataType: ValueType.TEXT, //현금영수증승인번호
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, //판매관리번호
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, //서비스관리번호
        },
        {
            fieldName: 'allotSale',
            dataType: ValueType.TEXT, //할부
        },
        {
            fieldName: 'advanceDc',
            dataType: ValueType.TEXT, //선할인
        },
        {
            fieldName: 'swingCashAmt',
            dataType: ValueType.TEXT, //Swing현금매출
        },
        {
            fieldName: 'psppCard',
            dataType: ValueType.TEXT, //PSPP현금매출(카드)
        },
        {
            fieldName: 'psppCash',
            dataType: ValueType.TEXT, //PSPP현금매출(현금)
        },
        {
            fieldName: 'tkeypCard',
            dataType: ValueType.TEXT, //T.Key+현금매출(카드)
        },
        {
            fieldName: 'tkeypCash',
            dataType: ValueType.TEXT, //T.Key+현금매출(현금)
        },
        {
            fieldName: 'totAmt',
            dataType: ValueType.TEXT, //현금영수증발행금액
        },
        {
            fieldName: 'dcAmt',
            dataType: ValueType.TEXT, //할인금액
        },
        {
            fieldName: 'gnrlCmms',
            dataType: ValueType.TEXT, //판매수수료
        },
        {
            fieldName: 'polPassYn',
            dataType: ValueType.TEXT, //적정성여부
        },
        {
            fieldName: 'polValeYn',
            dataType: ValueType.TEXT, //적정성검증결과
        },
        {
            fieldName: 'errDesc1',
            dataType: ValueType.TEXT, //조정중복
        },
        {
            fieldName: 'errDesc2',
            dataType: ValueType.TEXT, //조정비대상
        },
        {
            fieldName: 'errDesc3',
            dataType: ValueType.TEXT, //할인금액
        },
        {
            fieldName: 'errDesc4',
            dataType: ValueType.TEXT, //월마감
        },
        {
            fieldName: 'errDesc5',
            dataType: ValueType.TEXT, //적정성확인
        },
        {
            fieldName: 'chk',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'aprvNum',
            fieldName: 'aprvNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증승인번호',
                showTooltip: false,
            },
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'allotSale',
            fieldName: 'allotSale',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '할부',
                showTooltip: false,
            },
        },
        {
            name: 'advanceDc',
            fieldName: 'advanceDc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '선할인',
                showTooltip: false,
            },
        },
        {
            name: 'swingCashAmt',
            fieldName: 'swingCashAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing현금매출',
                showTooltip: false,
            },
        },
        {
            name: 'psppCard',
            fieldName: 'psppCard',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'PSPP현금매출(카드)',
                showTooltip: false,
            },
        },
        {
            name: 'psppCash',
            fieldName: 'psppCash',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'PSPP현금매출(현금)',
                showTooltip: false,
            },
        },
        {
            name: 'tkeypCard',
            fieldName: 'tkeypCard',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'T.Key+현금매출(카드)',
                showTooltip: false,
            },
        },
        {
            name: 'tkeypCash',
            fieldName: 'tkeypCash',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'T.Key+현금매출(현금)',
                showTooltip: false,
            },
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증발행금액',
                showTooltip: false,
            },
        },
        {
            name: 'dcAmt',
            fieldName: 'dcAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '할인금액',
                showTooltip: false,
            },
        },
        {
            name: 'gnrlCmms',
            fieldName: 'gnrlCmms',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매수수료',
                showTooltip: false,
            },
        },
        {
            name: 'polPassYn',
            fieldName: 'polPassYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '적정성여부',
                showTooltip: false,
            },
        },
        {
            name: 'polValeYn',
            fieldName: 'polValeYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '적정성검증결과',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc1',
            fieldName: 'errDesc1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조정중복',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc2',
            fieldName: 'errDesc2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조정비대상',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc3',
            fieldName: 'errDesc3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '할인금액',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc4',
            fieldName: 'errDesc4',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '월마감',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc5',
            fieldName: 'errDesc5',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '적정성확인',
                showTooltip: false,
            },
        },
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채크',
                showTooltip: false,
            },
            visible: false,
        },
    ],
    gridLayout: [
        'aprvNum',
        'gnrlSaleNo',
        'svcMgmtNum',
        'allotSale',
        'advanceDc',
        'swingCashAmt',
        'psppCard',
        'psppCash',
        'tkeypCard',
        'tkeypCash',
        'totAmt',
        'dcAmt',
        'gnrlCmms',
        'polPassYn',
        'polValeYn',
        {
            name: '오류검증대상여부',
            direction: 'horizontal',
            items: ['errDesc1', 'errDesc2', 'errDesc3', 'errDesc4', 'errDesc5'],
        },
    ],
}

export const GRID_HEADER_ADQ_MGMT_EXCEL = {
    fields: [
        {
            fieldName: 'aprvNum',
            dataType: ValueType.TEXT, //현금영수증승인번호
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, //판매관리번호
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, //서비스관리번호
        },
        {
            fieldName: 'allotSale',
            dataType: ValueType.TEXT, //할부
        },
        {
            fieldName: 'advanceDc',
            dataType: ValueType.TEXT, //선할인
        },
        {
            fieldName: 'swingCashAmt',
            dataType: ValueType.TEXT, //Swing현금매출
        },
        {
            fieldName: 'psppCard',
            dataType: ValueType.TEXT, //PSPP현금매출(카드)
        },
        {
            fieldName: 'psppCash',
            dataType: ValueType.TEXT, //PSPP현금매출(현금)
        },
        {
            fieldName: 'tkeypCard',
            dataType: ValueType.TEXT, //T.Key+현금매출(카드)
        },
        {
            fieldName: 'tkeypCash',
            dataType: ValueType.TEXT, //T.Key+현금매출(현금)
        },
        {
            fieldName: 'totAmt',
            dataType: ValueType.TEXT, //현금영수증발행금액
        },
        {
            fieldName: 'dcAmt',
            dataType: ValueType.TEXT, //할인금액
        },
        {
            fieldName: 'gnrlCmms',
            dataType: ValueType.TEXT, //판매수수료
        },
        {
            fieldName: 'polPassYn',
            dataType: ValueType.TEXT, //적정성여부
        },
        {
            fieldName: 'polValeYn',
            dataType: ValueType.TEXT, //적정성검증결과
        },
    ],
    columns: [
        {
            name: 'aprvNum',
            fieldName: 'aprvNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증승인번호',
                showTooltip: false,
            },
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'allotSale',
            fieldName: 'allotSale',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '할부',
                showTooltip: false,
            },
        },
        {
            name: 'advanceDc',
            fieldName: 'advanceDc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '선할인',
                showTooltip: false,
            },
        },
        {
            name: 'swingCashAmt',
            fieldName: 'swingCashAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing현금매출',
                showTooltip: false,
            },
        },
        {
            name: 'psppCard',
            fieldName: 'psppCard',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'PSPP현금매출(카드)',
                showTooltip: false,
            },
        },
        {
            name: 'psppCash',
            fieldName: 'psppCash',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'PSPP현금매출(현금)',
                showTooltip: false,
            },
        },
        {
            name: 'tkeypCard',
            fieldName: 'tkeypCard',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'T.Key+현금매출(카드)',
                showTooltip: false,
            },
        },
        {
            name: 'tkeypCash',
            fieldName: 'tkeypCash',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'T.Key+현금매출(현금)',
                showTooltip: false,
            },
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현금영수증발행금액',
                showTooltip: false,
            },
        },
        {
            name: 'dcAmt',
            fieldName: 'dcAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '할인금액',
                showTooltip: false,
            },
        },
        {
            name: 'gnrlCmms',
            fieldName: 'gnrlCmms',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매수수료',
                showTooltip: false,
            },
        },
        {
            name: 'polPassYn',
            fieldName: 'polPassYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '적정성여부',
                showTooltip: false,
            },
        },
        {
            name: 'polValeYn',
            fieldName: 'polValeYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '적정성검증결과',
                showTooltip: false,
            },
        },
    ],
}
