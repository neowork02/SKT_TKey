import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('bas.cmu.dealcoSaleChrgrSmsMgmtStore', Object.keys(state)),
    ...mapGetters('bas.cmu.dealcoSaleChrgrSmsMgmtStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('bas.cmu.dealcoSaleChrgrSmsMgmtStore', Object.keys(actions)),
    ...mapMutations(
        'bas.cmu.dealcoSaleChrgrSmsMgmtStore',
        Object.keys(mutations)
    ),
}
