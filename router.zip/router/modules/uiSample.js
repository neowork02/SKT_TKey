import Vue from 'vue'
import VueRouter from 'vue-router'
import TBaseLayout from '@/views/ui-sample/layout/TBaseLayout'

Vue.use(VueRouter)

const routes = [
    {
        path: '/ui-sample/addrPopup',
        name: '/ui-sample/addrPopup',
        component: () =>
            import('@/views/ui-sample/addrPopup.vue') /* 퍼블파일1 */,
        meta: {
            menuNm: 'addr',
            menuNo: '0',
            screenId: 'ADDR0000',
        },
    },
    {
        path: '/ui-sample',
        component: TBaseLayout,
        redirect: '/ui-sample/ContComInput',
        meta: {
            breadcrumb: 'ui-sample',
            key: 'TDCS.ui-sample',
        },

        children: [
            {
                path: 'ContComInput',
                component: () =>
                    import('@/views/ui-sample/layout/ContComInput.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComInput',
                    key: 'TDCS.ui-sample.ContComInput',
                },
            },
            {
                path: 'ContComButton',
                component: () =>
                    import('@/views/ui-sample/layout/ContComButton.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComButton',
                    key: 'TDCS.ui-sample.ContComButton',
                },
            },
            {
                path: 'ContComComboBox',
                component: () =>
                    import('@/views/ui-sample/layout/ContComComboBox.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComComboBox',
                    key: 'TDCS.ui-sample.ContComComboBox',
                },
            },
            {
                path: 'ContComMultiComboBox',
                component: () =>
                    import('@/views/ui-sample/layout/ContComMultiComboBox.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComMultiComboBox',
                    key: 'TDCS.ui-sample.ContComMultiComboBox',
                },
            },
            {
                path: 'ContComCheckBox',
                component: () =>
                    import('@/views/ui-sample/layout/ContComCheckBox.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComCheckBox',
                    key: 'TDCS.ui-sample.ContComCheckBox',
                },
            },
            {
                path: 'ContComRadioBox',
                component: () =>
                    import('@/views/ui-sample/layout/ContComRadioBox.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComRadioBox',
                    key: 'TDCS.ui-sample.ContComRadioBox',
                },
            },
            {
                path: 'ContComAlert',
                component: () =>
                    import('@/views/ui-sample/layout/ContComAlert.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComAlert',
                    key: 'TDCS.ui-sample.ContComAlert',
                },
            },
            {
                path: 'ContComDialog',
                component: () =>
                    import('@/views/ui-sample/layout/ContComDialog.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComDialog',
                    key: 'TDCS.ui-sample.ContComDialog',
                },
            },
            {
                path: 'ContComDatePicker',
                component: () =>
                    import('@/views/ui-sample/layout/ContComDatePicker.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComDatePicker',
                    key: 'TDCS.ui-sample.ContComDatePicker',
                },
            },
            {
                path: 'ContComGrid',
                component: () =>
                    import('@/views/ui-sample/layout/ContComGrid.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComGrid',
                    key: 'TDCS.ui-sample.ContComGrid',
                },
            },
            {
                path: 'ContComDefaultGrid',
                component: () =>
                    import('@/views/ui-sample/layout/ContComDefaultGrid.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComDefaultGrid',
                    key: 'TDCS.ui-sample.ContComDefaultGrid',
                },
            },
            {
                path: 'ContComPaging',
                component: () =>
                    import('@/views/ui-sample/layout/ContComPaging.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComPaging',
                    key: 'TDCS.ui-sample.ContComPaging',
                },
            },

            {
                path: 'ContComTab',
                component: () =>
                    import('@/views/ui-sample/layout/ContComTab.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComTab',
                    key: 'TDCS.ui-sample.ContComTab',
                },
            },
            {
                path: 'ContComTreeview',
                component: () =>
                    import('@/views/ui-sample/layout/ContComTreeview.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComTreeview',
                    key: 'TDCS.ui-sample.ContComTreeview',
                },
            },
            {
                path: 'ContComLabel',
                component: () =>
                    import('@/views/ui-sample/layout/ContComLabel.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComLabel',
                    key: 'TDCS.ui-sample.ContComLabel',
                },
            },
            {
                path: 'ContComSwitch',
                component: () =>
                    import('@/views/ui-sample/layout/ContComSwitch.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComSwitch',
                    key: 'TDCS.ui-sample.ContComSwitch',
                },
            },
            {
                path: 'ContComTextArea',
                component: () =>
                    import('@/views/ui-sample/layout/ContComTextArea.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComTextArea',
                    key: 'TDCS.ui-sample.ContComTextArea',
                },
            },
            {
                path: 'ContComFileInput',
                component: () =>
                    import('@/views/ui-sample/layout/ContComFileInput.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComFileInput',
                    key: 'TDCS.ui-sample.ContComFileInput',
                },
            },
            {
                path: 'ContComUtils',
                component: () =>
                    import('@/views/ui-sample/layout/ContComUtils.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComUtils',
                    key: 'TDCS.ui-sample.ContComUtils',
                },
            },
            {
                path: 'ContComForm',
                component: () =>
                    import('@/views/ui-sample/layout/ContComForm.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComForm',
                    key: 'TDCS.ui-sample.ContComForm',
                },
            },
            {
                path: 'ContComPopup',
                component: () =>
                    import('@/views/ui-sample/layout/ContComPopup.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComPopup',
                    key: 'TDCS.ui-sample.ContComPopup',
                },
            },
            {
                path: 'ContBasPopup',
                component: () =>
                    import('@/views/ui-sample/layout/ContBasPopup.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContBasPopup',
                    key: 'TDCS.ui-sample.ContBasPopup',
                },
            },
            {
                path: 'ContComBizClosing',
                component: () =>
                    import('@/views/ui-sample/layout/ContComBizClosing.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComBizClosing',
                    key: 'TDCS.ui-sample.ContComBizClosing',
                },
            },
            {
                path: 'RealReport',
                component: () =>
                    import(
                        '@/views/ui-sample/layout/realReport/RealReport.vue'
                    ),
                meta: {
                    breadcrumb: 'ui-sample.RealReport',
                    key: 'TDCS.ui-sample.RealReport',
                },
            },
            {
                path: 'ContComExcelGrid',
                component: () =>
                    import('@/views/ui-sample/layout/ContComExcelGrid.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContComExcelGrid',
                    key: 'TDCS.ui-sample.ContComExcelGrid',
                },
            },
            {
                path: 'TestPage',
                component: () =>
                    import('@/views/ui-sample/layout/TestPage.vue'),
                meta: {
                    breadcrumb: 'ui-sample.TestPage',
                    key: 'TDCS.ui-sample.TestPage',
                },
            },
            {
                path: 'Highcharts',
                component: () =>
                    import('@/views/ui-sample/layout/Highcharts.vue'),
                meta: {
                    breadcrumb: 'ui-sample.Highcharts',
                    key: 'TDCS.ui-sample.Highcharts',
                },
            },
            {
                path: 'ContStoreSample',
                component: () =>
                    import('@/views/ui-sample/layout/ContStoreSample.vue'),
                meta: {
                    breadcrumb: 'ui-sample.ContStoreSample',
                    key: 'TDCS.ui-sample.ContStoreSample',
                },
            },
        ],
    },
]

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch((err) => {
        if (err.name !== 'NavigationDuplicated') throw err
    })
}

export default routes
