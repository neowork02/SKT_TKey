<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 통합판매수수료정산관리
 * 소스 ID : AccSacIntgSaleCmmsAccMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.04.05
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- 업무명 -->
        <h1>통합판매수수료정산관리</h1>

        <!-- 사용버튼 -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    :disabled="isButtonDisabled"
                    eClass="btn_ty"
                    @click="clickGiftTaxInvoice"
                    >종이세금계산서수취</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    :disabled="isButtonDisabled"
                    eClass="btn_ty"
                    @click="clickGiftTaxCancel"
                    >종이세금계산서취소</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    :disabled="isButtonDisabled"
                    eClass="btn_ty"
                    @click="clickSettlementCarryOver"
                    >정산이월</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    :disabled="isButtonDisabled"
                    eClass="btn_ty"
                    @click="clickExcludingVAT"
                    >부가세제외</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    :disabled="isButtonDisabled"
                    eClass="btn_ty"
                    @click="clickExcludingVATCancel"
                    >부가세제외취소</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    @click="screenInit"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    @click="searchList"
                    >조회</TCComButton
                >
            </li>
        </ul>

        <!-- 조회 Key 입력 구성 -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="M"
                        labelName="정산월"
                        :value="searchKeyData.accYm_"
                        :eRequired="true"
                        @change="changeAccYm"
                    />
                </div>

                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchKeyData.orgNm"
                        :codeVal.sync="searchKeyData.orgCd"
                        labelName="조직"
                        placeholder=""
                        :eRequired="true"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="popupBasParams"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>

                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchKeyData.accDealcoNm"
                        :codeVal.sync="searchKeyData.accDealcoCd"
                        labelName="정산처"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="popupBasParams"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>

                <div class="formitem div4">
                    <!-- <div class="formitem formitem--bondClCd div2"> -->
                    <TCComComboBox
                        itemText="label"
                        itemValue="value"
                        labelName="채권상계기간 설정"
                        labelClass="line2"
                        blankItemText="선택없음"
                        blankItemValue="0"
                        :addBlankItem="true"
                        :itemList="[
                            {
                                value: '1',
                                label: '수납+매출-입금+오입금',
                            },
                            {
                                value: '2',
                                label: '수납-입금+오입금',
                            },
                        ]"
                        :objAuth="objAuth"
                        v-model="searchKeyData.bondYn"
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="세금계산서상태"
                        codeId="TAX_BIL_ST_CD"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        v-model="searchKeyData.taxTypClCd"
                    ></TCComComboBox>
                </div>

                <div class="formitem div4">
                    <TCComComboBox
                        codeId="TAX_TYP_CL_CD"
                        labelName="과세유형"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-model="searchKeyData.taxTypClCd"
                    ></TCComComboBox>
                </div>

                <div class="formitem div4">
                    <TCComComboBox
                        codeId="SP_CLS_BIZ_CL_CD"
                        labelName="휴폐업상태"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-model="searchKeyData.spClsBizClCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComDatePicker
                        v-model="searchKeyData.bond"
                        calType="DP"
                        :disabled="searchKeyData.bondYn == 0"
                        @change="changeBond"
                        labelName="조회일자"
                    />
                </div>
            </div>
        </div>

        <!-- GRID정의 -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                class="gridHeader"
                gridTitle="정산목록"
                :gridObj="gridObj"
                :isExceldown="true"
                :isFileAdd="true"
                @excelDownBtn="downloadIntgSaleCmmsList"
                @fileBtnClick="fileBtnClick"
            >
                <template #gridElementLeftArea>
                    <span class="infoTxt color-red"
                        >종이세금계산서수취, 종이세금계산서취소는 선택한 행 한
                        건씩 처리됩니다.(체크박스 사용하지 않음)
                    </span>
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grdList"
                ref="grdList"
                :styles="gridStyle"
                :fields="view.fields"
                :columns="view.columns"
            />
            <AttachedFileAddPopup
                v-if="fileAddShow"
                ref="fileAddPopup"
                :dialogShow.sync="fileAddShow"
                :fileList="fileList"
                @confirm="onReturnfiles"
            />
        </div>

        <!-- 수수료 보드 -->
        <div class="searchLayer_wrap type03 mt20">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4_2">
                    <span class="itemtit solo">위탁점별평균수수료 :</span>
                </div>
                <div class="formitem div4_1">
                    <TCComInput
                        labelName="위탁점 수"
                        :readonly="true"
                        :textReverse="true"
                        v-model="dealCnt"
                    />
                </div>
                <div class="formitem div4_1">
                    <TCComInput
                        labelName="무선평균수수료"
                        :readonly="true"
                        :textReverse="true"
                        v-model="tAvrgCmms"
                    />
                </div>
                <div class="formitem div4_1">
                    <TCComInput
                        labelName="유선평균수수료"
                        :readonly="true"
                        :textReverse="true"
                        v-model="bAvgrCmms"
                    />
                </div>
            </div>
        </div>

        <!-- 발행요청 - 거래처 세금계산서 발행(TAXPRM00220), 타전산발행관리(TAXPRM00230) - 타전산 매출세금계산서 발행 내역 -->
        <TaxPrmDealcoOthItTaxBillIsueInfoIns
            v-if="infoInsShowPopup === true"
            ref="popup"
            :dialogShow.sync="infoInsShowPopup"
            :popupParams.sync="infoInsPopupParams"
            @confirm="onReturnTaxPrmDealcoOthItTaxBillIsueInfoIns"
        />
    </div>
</template>
<style></style>

<script>
import moment from 'moment'
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import { AccUtil } from '@/views/biz/acc'

import _ from 'lodash'
import intgApi from '@/api/biz/acc/sac/AccSacIntgSaleCmmsAccMgmtApi'
import commonApi from '@/api/common/commonCode'
import attachedFileApi from '@/api/common/attachedFile'
import {
    GRID_HEADER,
    // MOCK_DATA,
} from '@/const/grid/acc/sac/AccSacIntgSaleCmmsAccMgmt'

//  내부조직팝업(권한)
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'

//  내부거래처-전체조직
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'

// 파일첨부
import AttachedFileAddPopup from '@/components/common/AttachedFileAddPopup'

import TaxPrmDealcoOthItTaxBillIsueInfoIns from '@/views/biz/tax/prm/TaxPrmDealcoOthItTaxBillIsueInfoIns'

export default {
    name: 'AccSacIntgSaleCmmsAccMgmt',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
        AttachedFileAddPopup,
        TaxPrmDealcoOthItTaxBillIsueInfoIns,
    },
    data() {
        return {
            objAuth: {},
            list: [],
            view: GRID_HEADER,
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '300px', //그리드 높이 조절
            },
            searchKeyData: {
                accYm_: moment(new Date()).format('YYYY-MM'),
                accYm: moment(new Date()).format('YYYYMM'),
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                accDealcoCd: '',
                accDealcoNm: '',
                bondYn: '0',
                bondClsDtFrom: '',
                bondClsDtTo: '',
                slCl: 'N/A',
                taxBilStCd: '',
                taxTypClCd: '',
                spClsBizClCd: '',
                searchCoClOrgCd: '',
                docId: '',
            },

            dealCnt: '', // 위탁점수
            tAvrgCmms: '', // 무선평균수수료
            bAvgrCmms: '', // 유선평균수수료

            basBcoDealcoShow: false,

            //  내부조직팝업(권한)팝업
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                vLevel: '3', // 디스플레이제한레벨
                all: 'N', // 전체선택가능여부
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //  내부조직팝업(권한)팝업

            //  종이세금산서수취, 종이세금계산서취소, 정산이월,
            //  부가세제외, 부가세제외취소 버튼 권한여부
            buttonYn: 'N',
            isButtonDisabled: false,

            //  팝업파람
            popupBasParams: {},

            // 첨부파일
            fileAddShow: false,
            fileList: [],

            infoInsShowPopup: false,
            infoInsPopupParams: {},
        }
    },
    watch: {
        'searchKeyData.accYm_'(newVal) {
            var _newVal = newVal
            if (!_.isEmpty(newVal)) {
                _newVal = newVal.replace(/-/g, '')
            }

            this.searchKeyData.accYm = _newVal
            this.popupBasParams.basMth = _newVal
        },
        'searchKeyData.orgCd'(newVal) {
            this.popupBasParams.orgCd = newVal
        },
        'searchKeyData.orgNm'(newVal) {
            this.popupBasParams.orgNm = newVal
        },
    },
    mounted() {
        //  그리드 초기화
        this.gridInit()

        //  버튼권한
        this.getButtonAuthCodeList()

        //  회사구분 조직코드
        this.searchKeyData.searchCoClOrgCd = this.orgInfo.orgCdLvl0

        // 첨부파일명 클릭시 파일 다운로드
        this.gridObj.gridView.onCellItemClicked = (
            grid,
            rowInfo,
            clickData
        ) => {
            if (clickData.type == 'link') {
                var downloadFileParam = {
                    screenId: grid.getValue(rowInfo.dataRow, 'screenId'),
                    docId: grid.getValue(rowInfo.dataRow, 'docId'),
                    filePathNm: grid.getValue(rowInfo.dataRow, 'filePathNm'),
                    fileNm: grid.getValue(rowInfo.dataRow, 'fileNm'),
                    fileType: grid.getValue(rowInfo.dataRow, 'fileType'),
                }
                this.downloadFile(downloadFileParam)
                return false
            }
        }
        this.gridObj.gridView.onItemChecked = (grid, itemIndex) => {
            grid.setCurrent({ itemIndex: itemIndex })
        }
    },
    methods: {
        // 그리드 초기화
        gridInit() {
            this.gridObj = this.$refs.grdList
            this.gridHeaderObj = this.$refs.gridHeader

            this.gridObj.setGridState(false)
            this.gridObj.gridView.setColumnLayout(GRID_HEADER.layout)

            this.gridObj.gridView.setCheckBar({ visible: true })
            this.gridObj.gridView.displayOptions.selectionStyle = 'rows'

            this.gridObj.gridView.onCellClicked = (grid, rowInfo) => {
                if (rowInfo.dataRow === undefined || rowInfo.dataRow < 0) return

                grid.commit()

                const rowIdx = rowInfo.dataRow
                const row = this.gridObj.dataProvider.getJsonRow(rowIdx)

                if (row.accCloseYn == 'Y') {
                    this.isButtonDisabled = true
                } else {
                    this.isButtonDisabled = false
                }
            }
        },

        // 화면초기화
        screenInit() {
            CommonUtil.clearPage(this, 'searchKeyData', this.gridObj)

            //  회사구분 조직코드
            this.searchKeyData.searchCoClOrgCd = this.orgInfo.orgCdLvl0
        },

        //  화면 상단 버튼에 대한 권한 여부
        async getButtonAuthCodeList() {
            var buttonAuthCodeList = []
            buttonAuthCodeList = await commonApi.getCommonCodeListById(
                'ZBAS_C_00250'
            )

            for (var i in buttonAuthCodeList) {
                if (
                    buttonAuthCodeList[i].commCdVal ==
                        this.userInfo.userGrpCd &&
                    buttonAuthCodeList[i].addInfo5 == 'Y'
                ) {
                    this.isButtonDisabled = true
                    break
                }
            }
        },

        searchList() {
            //  정산월 입력 데이터 정합성체크
            if (!this.searchKeyData.accYm) {
                return this.showTcComAlert('정산월을 입력하십시오.')
            }

            //  조회대상 입력 데이터 정합성체크
            if (!this.searchKeyData.orgCd) {
                return this.showTcComAlert('조직을 선택하십시오.')
            }

            // 채권상계기간설정 체크
            if (this.searchKeyData.bondYn != '0') {
                //    채권상계기간설정이 선택이 되었음에도 일자가 없으면 오류
                if (
                    !this.searchKeyData.bondClsDtTo ||
                    !this.searchKeyData.bondClsDtFrom
                ) {
                    this.showTcComAlert('채권상계기간을 입력하십시오.')
                    return
                }
            }

            //  조회API 호출
            intgApi
                .getIntgSaleCmmsList(this.searchKeyData)
                .then((resultData) => {
                    this.list = resultData
                    this.$refs.grdList.setRows(this.list)

                    // 위탁점수
                    this.dealCnt = resultData.length
                    // resultData.resultGridDto.pagingDto.totalDataCnt

                    // 무선평균수수료
                    this.tAvrgCmms = this.setComma(
                        Math.round(
                            this.list.reduce(
                                (acc, arr) => acc + arr.fixCnsgCmms,
                                0
                            ) / this.dealCnt
                        )
                    )

                    // 유선평균수수료
                    this.bAvgrCmms = this.setComma(
                        Math.round(
                            this.list.reduce(
                                (acc, arr) => acc + arr.bfixCnsgCmms,
                                0
                            ) / this.dealCnt
                        )
                    )

                    //  회계마감이 되었으면 상단버튼 선택 불가
                    if (this.list[0].accCloseYn == 'Y') {
                        this.isButtonDisabled = true
                    } else {
                        this.isButtonDisabled = false
                    }
                })
        },

        //  엑셀다운로드
        downloadIntgSaleCmmsList: function () {
            intgApi.downloadIntgSaleCmmsList(this.searchKeyData)
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.searchKeyData.orgCd
            this.searchParam.orgNm = this.searchKeyData.orgNm
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchKeyData.orgCd = _.get(res[0], 'orgCd')
                        this.searchKeyData.orgNm = _.get(res[0], 'orgNm')
                        this.searchKeyData.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },

        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchKeyData.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },

        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchKeyData.orgNm)) {
                this.showTcComAlert('조직명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },

        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchKeyData.orgCd = ''
        },

        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchKeyData.orgCd = _.get(returnData, 'orgCd')
            this.searchKeyData.orgNm = _.get(returnData, 'orgNm')
            this.searchKeyData.orgLvl = _.get(returnData, 'orgLvl')

            this.popupBasParams.orgCd = _.get(returnData, 'orgCd')
            this.popupBasParams.orgNm = _.get(returnData, 'orgNm')
            this.popupBasParams.orgLvl = _.get(returnData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.popupBasParams).then((res) => {
                if (res.length === 1) {
                    // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                    this.searchKeyData.accDealcoCd = _.get(res[0], 'dealcoCd')
                    this.searchKeyData.accDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                    this.resultDealcoRows = res
                    this.basBcoDealcoShow = true
                }
            })
        },
        onDealcoIconClick() {
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 팝업오픈
            this.basBcoDealcoShow = true
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            this.resultDealcoRows = []
            if (_.isEmpty(this.searchKeyData.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            if (_.isEmpty(this.searchKeyData.accDealcoNm)) {
                this.showTcComAlert('정산처를 입력해주세요.')
                return
            }
            this.popupBasParams.orgCd = this.searchKeyData.orgCd
            this.popupBasParams.orgNm = this.searchKeyData.orgNm
            this.popupBasParams.orgLvl = this.searchKeyData.orgLvl
            this.popupBasParams.dealcoCd = this.searchKeyData.accDealcoCd
            this.popupBasParams.dealcoNm = this.searchKeyData.accDealcoNm

            // 내부거래처조회
            this.getDealcosList()
        },

        onDealcoInput() {
            console.log('input 왔어?')
            // 입력되는 값이 있으면 코드 초기화
            this.searchKeyData.accDealcoCd = ''
        },

        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            console.log('returnData: ', returnData)

            this.searchKeyData.accDealcoCd = _.get(returnData, 'dealcoCd')
            this.searchKeyData.accDealcoNm = _.get(returnData, 'dealcoNm')
        },

        changeAccYm(date) {
            this.searchKeyData.accYm = date.replace(/-/g, '')

            // 정산월 변경 시 조직팝업 파람변경
            this.popupBasParams.basMth = date.replace(/-/g, '')

            // 정산월 변경 시 정산처 파람변경
            this.popupBasParams.basDay = moment(this.searchKeyData.accYm)
                .endOf('month')
                .format('YYYYMMDD')
        },

        changeBond(date) {
            this.searchKeyData.bondClsDtTo = date[0].replace(/-/g, '')
            this.searchKeyData.bondClsDtFrom = date[1].replace(/-/g, '')
        },

        // 종이세금계산서수취
        clickGiftTaxInvoice() {
            const currentItem = this.gridObj.gridView.getCurrent()
            let row

            if (currentItem.dataRow < 0) {
                return this.showTcComAlert('선택된 데이터가 없습니다')
            } else {
                row = this.gridObj.dataProvider.getJsonRow(currentItem.dataRow)
            }

            //  영업월, 정산월 String변환
            row.accYm = AccUtil.dateToFormat(
                new Date(row.accYm),
                'YYYYMM'
            ).substring(0, 6)

            row.accFixYm = AccUtil.dateToFormat(
                new Date(row.accFixYm),
                'YYYYMM'
            ).substring(0, 6)

            if (row.bizNo.replace(/-/g, '').substring(3, 4) == '8') {
                if (
                    this.userInfo.userGrpCd != 'P12' &&
                    this.userInfo.userGrpCd != 'P13'
                ) {
                    return this.showTcComAlert(
                        '[' +
                            row.accDealcoCd +
                            ', ' +
                            row.accDealcoNm +
                            '] 정산처는 법인사업자로 전자세금계산서 발행 대상입니다.'
                    )
                }
            }
            if (!row.apSeq) {
                return this.showTcComAlert(
                    '매입원장에 해당되는 data가 없습니다'
                )
            }
            if (row.taxBilYn == 'N') {
                return this.showTcComAlert('종이세금계산서를 발행할수 없습니다')
            }

            if (row.taxBilYn == 'P') {
                return this.showTcComAlert(
                    '종이세금계산서가 발행된 상태입니다.'
                )
            }
            if (row.totFixCnsgCmms == 0) {
                return this.showTcComAlert(
                    '[' +
                        row.accDealcoNm +
                        '] 정산처의 합계 확정금액이 0원입니다.'
                )
            }

            var dsSeqList = []
            var dsSeq = {}

            this.infoInsPopupParams.callGb = 'P' // 화면구분(R:매출(정발행), P:매입(역발행))
            this.infoInsPopupParams.dealcoCd = row.accDealcoCd
            this.infoInsPopupParams.entryInfo = 'other'
            this.infoInsPopupParams.taxBilClCd = 'P' // 세금계산서발행구분코드

            dsSeq.splyPrc = row.totFixSuprtCnsgCmms
            dsSeq.vatAmt = row.totFixFeeCnsgCmms
            dsSeq.sumAmt =
                parseInt(row.totFixSuprtCnsgCmms, 10) +
                parseInt(row.totFixFeeCnsgCmms, 10)
            dsSeq.wrtDt = row.wrtDt
            dsSeq.dtmGubun = '1'
            dsSeq.accDealcoCd = row.accDealcoCd
            dsSeq.searchDtFrom = row.wrtDt
            dsSeq.searchDtTo = row.wrtDt
            dsSeq.refId = row.refId
            dsSeq.taxPrdCd = 'MTH'

            dsSeqList.push(dsSeq)
            this.infoInsPopupParams.dsSeq = dsSeqList
            console.log('KYJ ==> ', this.infoInsPopupParams)
            this.infoInsShowPopup = true

            // dsSeq.apSeq = row.apSeq
            // dsSeq.taxPrdCd = 'MTH'
            // dsSeq.accDealcoCd = row.accDealcoCd
            // dsSeq.wrtDt = row.wrtDt
            // dsSeq.netAmt = row.totFixSuprtCnsgCmms
            // dsSeq.vatAmt = row.totFixFeeCnsgCmms
            // dsSeq.sumAmt =
            //     parseInt(row.totFixSuprtCnsgCmms, 10) +
            //     parseInt(row.totFixFeeCnsgCmms, 10)
            // dsSeq.refId = row.refId
            // dsSeq.dtmGubun = '1'
            // dsSeq.searchDtmFrom = row.accFixYm + '01'
            // dsSeq.searchDtmTo = moment(row.accFixYm)
            //     .endOf('month')
            //     .format('YYYYMMDD')
            // dsSeq.orgCd = row.orgCd
            // dsSeq.orgLvl = '3'
            // dsSeq.prchsPlc = ''
            // dsSeq.taxCfmId = ''
            // dsSeq.bizNo = row.bizNo.replace(/-/g, '')

            // this.infoInsPopupParams.taxBilId = '' // 세금계산서발행ID
            // this.infoInsPopupParams.callGb = 'P' // 화면구분(R:매출(정발행), P:매입(역발행))
            // this.infoInsPopupParams.taxBilClCd = 'P' // 세금계산서발행구분코드
            // this.infoInsPopupParams.dealcoCd = row.accDealcoCd // 거래처 코드
            // this.infoInsPopupParams.dsSeq = dsSeq
            // this.infoInsPopupParams.entryInfo = 'other'
            // this.infoInsShowPopup = true
        },

        // 종이세금계산서취소
        async clickGiftTaxCancel() {
            const currentItem = this.gridObj.gridView.getCurrent()
            let row

            if (currentItem.dataRow < 0) {
                return this.showTcComAlert('선택된 데이터가 없습니다')
            } else {
                row = this.gridObj.dataProvider.getJsonRow(currentItem.dataRow)
            }

            if (row.taxBilYn != 'P') {
                return this.showTcComAlert('발행된 종이세금계산서가 없습니다.')
            }

            if (!row.taxBilId) {
                row.taxBilId = row.bTaxBilId
                row.taxBilClCd = row.bTaxBilClCd
                row.taxBilStCd = row.tbAxBilStCd
            }

            row.afTaxBilClCd = 'CNCLDZ' /* 종이세금계산서 취소 */

            //  영업월, 정산월 String변환
            row.accYm = AccUtil.dateToFormat(
                new Date(row.accYm),
                'YYYYMM'
            ).substring(0, 6)

            row.accFixYm = AccUtil.dateToFormat(
                new Date(row.accFixYm),
                'YYYYMM'
            ).substring(0, 6)

            if (
                await this.showTcComConfirm(
                    '종이세금계산서 취소를 하시겠습니까?'
                )
            ) {
                return intgApi
                    .savePaperTaxBilCncl({
                        intgSaleCmmsAccMgmtVo: row,
                    })
                    .then((res) => {
                        if (res) {
                            this.showTcComAlert(
                                '종이세금계산서 취소 처리되었습니다.'
                            )
                            this.searchList()
                        }
                    })
            }
        },

        // 정산이월
        async clickSettlementCarryOver() {
            const checkedItemIdx = this.gridObj.gridView.getCheckedRows(true)
            const row = checkedItemIdx.map((arr) =>
                this.gridObj.dataProvider.getJsonRow(arr)
            )

            if (row.length < 1) {
                return this.showTcComAlert('체크박스 선택된 데이터가 없습니다')
            }

            const error = { msg: '', list: [] }

            row.forEach((arr) => {
                if (arr.taxBilYn != 'Y') {
                    error.msg =
                        '[' +
                        arr.accDealcoCd +
                        ', ' +
                        arr.accDealcoNm +
                        '] 처리불가 정산처입니다.'
                    error.list.push(arr)
                }
                //  영업월, 정산월 String변환
                arr.accYm = AccUtil.dateToFormat(
                    new Date(arr.accYm),
                    'YYYYMM'
                ).substring(0, 6)

                arr.accFixYm = AccUtil.dateToFormat(
                    new Date(arr.accFixYm),
                    'YYYYMM'
                ).substring(0, 6)
            })

            if (error.list.length) {
                return this.showTcComAlert(error.msg)
            } else {
                if (
                    await this.showTcComConfirm('정산이월 신청 하시겠습니까?')
                ) {
                    return intgApi
                        .saveIntegSaleCmmsAccCrovr({
                            intgSaleCmmsAccMgmtVoList: row,
                        })
                        .then((res) => {
                            if (res) {
                                this.showTcComAlert('정산이월 처리되었습니다.')
                                this.searchList()
                            }
                        })
                    // .then(this.searchList())
                }
            }
        },

        // 부가세제외 RPAY
        async clickExcludingVAT() {
            const checkedItemIdx = this.gridObj.gridView.getCheckedRows(true)
            const row = checkedItemIdx.map((arr) =>
                this.gridObj.dataProvider.getJsonRow(arr)
            )

            if (row.length < 1) {
                return this.showTcComAlert('체크박스 선택된 데이터가 없습니다')
            }

            const error = { msg: '', list: [] }
            row.forEach((arr) => {
                if (arr.taxBilYn != 'Y') {
                    error.msg =
                        '[' +
                        arr.accDealcoCd +
                        ', ' +
                        arr.accDealcoNm +
                        '] 세금계산서 발행가능상태만 처리할 수 없습니다.'
                    error.list.push(arr)
                }

                if (parseInt(arr.totFixFeeCnsgCmms, 10) == 0) {
                    error.msg =
                        '[' +
                        arr.accDealcoCd +
                        ', ' +
                        arr.accDealcoNm +
                        '] 확정위탁수수료 세액이 0이 아닌 경우만 처리할수 있습니다'
                    error.list.push(arr)
                }
                //  영업월, 정산월 String변환
                arr.accYm = AccUtil.dateToFormat(
                    new Date(arr.accYm),
                    'YYYYMM'
                ).substring(0, 6)

                arr.accFixYm = AccUtil.dateToFormat(
                    new Date(arr.accFixYm),
                    'YYYYMM'
                ).substring(0, 6)
            })

            if (error.list.length) {
                return this.showTcComAlert(error.msg)
            } else {
                if (
                    await this.showTcComConfirm('부가세제외 신청 하시겠습니까?')
                ) {
                    return intgApi
                        .saveIntegSaleCmmsAccRpay({
                            intgSaleCmmsAccMgmtVoList: row,
                        })
                        .then((res) => {
                            if (res) {
                                this.showTcComAlert(
                                    '부가세제외 처리되었습니다.'
                                )
                                this.searchList()
                            }
                        })
                }
            }
        },

        // 부가세제외취소 RPAY_CNCL
        async clickExcludingVATCancel() {
            const checkedItemIdx = this.gridObj.gridView.getCheckedRows(true)
            const row = checkedItemIdx.map((arr) =>
                this.gridObj.dataProvider.getJsonRow(arr)
            )

            if (row.length < 1) {
                return this.showTcComAlert('체크박스 선택된 데이터가 없습니다')
            }

            const error = { msg: '', list: [] }
            row.forEach((arr) => {
                if (arr.taxBilYn != 'Y') {
                    '[' +
                        arr.accDealcoCd +
                        ', ' +
                        arr.accDealcoNm +
                        '] 처리할 수 없습니다.'
                    error.list.push(arr)
                }

                console.log(arr)
                if (arr.rmks != '부가세제외') {
                    error.msg =
                        '[' +
                        arr.accDealcoCd +
                        ', ' +
                        arr.accDealcoNm +
                        '] 부가세제외 상태만 취소 처리할수 있습니다'
                    error.list.push(arr)
                }

                if (parseInt(arr.fixFeeCnsgCmms, 10) != 0) {
                    error.msg =
                        '[' +
                        arr.accDealcoCd +
                        ', ' +
                        arr.accDealcoNm +
                        '] 확정위탁수수료 세액이 0금액만 처리할수 있습니다'
                    error.list.push(arr)
                }
                //  영업월, 정산월 String변환
                arr.accYm = AccUtil.dateToFormat(
                    new Date(arr.accYm),
                    'YYYYMM'
                ).substring(0, 6)

                arr.accFixYm = AccUtil.dateToFormat(
                    new Date(arr.accFixYm),
                    'YYYYMM'
                ).substring(0, 6)
            })

            if (error.list.length) {
                return this.showTcComAlert(error.msg)
            } else {
                row.forEach((arr) => {
                    //    부가세제외 상태만 처리 가능
                    if (parseInt(arr.fixCnsgCmms, 10) != 0) {
                        arr.fixFeeCnsgCmms =
                            parseInt(arr.fixCnsgCmms, 10) -
                            parseInt(arr.fixSuprtCnsgCmms, 10)
                    }

                    if (parseInt(arr.bfixCnsgCmms, 10) != 0) {
                        arr.bfixFeeCnsgCmms =
                            parseInt(arr.bfixCnsgCmms, 10) -
                            parseInt(arr.bfixSuprtCnsgCmms, 10)
                    }
                })

                if (
                    await this.showTcComConfirm(
                        '부가세제외취소 신청 하시겠습니까?'
                    )
                ) {
                    return intgApi
                        .saveIntegSaleCmmsAccRpayCncl({
                            intgSaleCmmsAccMgmtVoList: row,
                        })
                        .then((res) => {
                            if (res) {
                                this.showTcComAlert(
                                    '부가세제외취소 처리되었습니다.'
                                )
                                this.searchList()
                            }
                        })
                }
            }
        },
        //  파일첨부버튼
        fileBtnClick() {
            if (!this.list.length) {
                return this.showTcComAlert('데이터조회후 처리하십시오')
            }
            this.fileAddShow = true
        },

        // File Input 업로드 그리드 샘플 방법
        async onReturnfiles(returnData) {
            const multipartForm = new FormData()
            const addFileLength = returnData.addFile.length
            if (returnData.addFile.length == 0) {
                return
            }

            //  첨부파일명이 조회된 정산처와 동일한지 체크
            //  첨부파일명은 정산처코드로 해야 함.
            var isExist = false
            var nRow = -1
            for (var i = 0; i < returnData.addFile.length; i++) {
                for (var j = 0; j < this.list.length; j++) {
                    if (
                        this.list[j].accDealcoCd ==
                        CommonUtil.getFileName(returnData.addFile[i].file.name)
                    ) {
                        isExist = true
                        nRow = j
                        break
                    }
                }

                if (!isExist) {
                    this.showTcComAlert(
                        '[' +
                            returnData.addFile[i].file.name +
                            '] 파일은 조회된 정산처코드에 없습니다.'
                    )
                    return
                }

                if (
                    this.list[nRow].taxStNm != '(미발행)' &&
                    this.list[nRow].taxStNm != '종이계산서수취(타전산)'
                ) {
                    this.showTcComAlert(
                        '[' +
                            returnData.addFile[i].file.name +
                            '] 파일은 종이세금계산서 등록 가능 상태가 아닙니다.\n세금계산서 컬럼을 확인하십시오.'
                    )
                    return
                }
            }
            _.forEach(returnData.addFile, (item, index) => {
                multipartForm.append('files', item.file)

                multipartForm.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                multipartForm.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                multipartForm.append(
                    `admAppendFileList[${index}].screenId`,
                    'AccSacIntgSaleCmmsAccMgmt'
                )
                multipartForm.append(`admAppendFileList[${index}].docId`, '')
                multipartForm.append(
                    `admAppendFileList[${index}].__rowState`,
                    item.__rowState
                )
            })
            _.forEach(returnData.delFile, (item, index) => {
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].filePathNm`,
                    item.filePathNm
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].fileType`,
                    item.fileType
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].screenId`,
                    item.screenId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].docId`,
                    item.docId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].__rowState`,
                    'deleted'
                )
            })

            if (await this.showTcComConfirm('첨부파일을 저장 하시겠습니까?')) {
                intgApi.saveTaxAttachFile(multipartForm).then((res) => {
                    if (res != null) {
                        console.log('hh')
                        res.forEach(
                            (arr) => (arr.accFixYm = this.searchKeyData.accYm)
                        )
                        return intgApi
                            .saveAttachFile({
                                intgSaleCmmsAccFileDsVo: res,
                            })
                            .then((resultData) => {
                                if (resultData) {
                                    this.showTcComAlert('저장되었습니다.')
                                    this.searchList()
                                }
                            })
                    }
                })
            }
        },

        onReturnTaxPrmDealcoOthItTaxBillIsueInfoIns(retVal) {
            if (retVal) {
                // 화면재조회
                this.searchList()
            }
        },

        setComma(v) {
            return String(v)
                .replace(/,/gi, '')
                .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        },

        //  첨부파일 다운로드
        downloadFile(downloadFileParam) {
            attachedFileApi.downLoadFile(
                '/api/v1/backend/resource/common/file-download',
                downloadFileParam
            )
        },
    },
}
</script>
