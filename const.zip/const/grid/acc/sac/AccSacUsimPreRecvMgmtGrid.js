import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'ssupOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'supOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimPayYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dataSeq',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'ssupOrgNm',
            fieldName: 'ssupOrgNm',
            type: 'data',
            width: '150',
            header: { text: '사업담당' },
            editable: false,
        },
        {
            name: 'supOrgNm',
            fieldName: 'supOrgNm',
            type: 'data',
            width: '150',
            header: { text: '영업팀' },
            editable: false,
            visible: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            width: '150',
            header: { text: '영업PT코드' },
            editable: false,
            visible: false,
        },
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            type: 'data',
            width: '150',
            header: { text: '조직' },
            editable: false,
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    //ret.editable = true

                    //조직코드 입력 유형 변경 행추가 때만 입력가능
                    let agencyCd1 = grid._view.columnByName('orgTree')
                    agencyCd1.editable = false
                    agencyCd1.button = 'action'
                    agencyCd1.buttonVisibility = 'always'
                } else {
                    let agencyCd1 = grid._view.columnByName('orgTree')
                    agencyCd1.editable = false
                    agencyCd1.button = 'none'
                    agencyCd1.buttonVisibility = ''
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'usimPayYn',
            fieldName: 'usimPayYn',
            type: 'data',
            width: '150',
            editable: true,
            header: {
                text: '신품자급usim후불예수금',
            },
            renderer: {
                type: 'check',
                editable: true,
                trueValues: '1',
                falseValues: '0',
            },
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            type: 'data',
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: { text: '적용시작일자' },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyy-MM-dd',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            editable: true,
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            type: 'data',
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: { text: '적용종료일자' },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyy-MM-dd',
                textReadOnly: false,
                textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            editable: true,
        },
        {
            name: 'dataSeq',
            fieldName: 'dataSeq',
            type: 'data',
            width: '150',
            header: { text: 'seq' },
            editable: false,
            visible: false,
        },
    ],
}
