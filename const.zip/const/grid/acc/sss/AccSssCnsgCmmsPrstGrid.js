import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'orgNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoCl1Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ppsCmms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'newMgtCmms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'chgMgtCmms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'opCmms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'wireMgtCmms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'wireCollCmms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'wrwlCombCmms',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        // {
        //     name: 'orgNm1',
        //     fieldName: 'orgNm1',
        //     type: 'data',
        //     header: { text: '사업담당' },
        //     width: '150',
        // },
        // {
        //     name: 'orgNm2',
        //     fieldName: 'orgNm2',
        //     type: 'data',
        //     header: { text: '사업팀' },
        //     width: '150',
        // },
        // {
        //     name: 'orgNm',
        //     fieldName: 'orgNm',
        //     type: 'data',
        //     header: { text: '영업팀PT' },
        //     width: '150',
        // },
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            type: 'data',
            header: { text: '조직' },
            width: '250',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            header: {
                text: '정산처',
            },
            width: '150',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            header: { text: '정산처명' },
            width: '150',
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            header: { text: '매장코드' },
            width: '150',
        },
        {
            name: 'dealCoCl1Nm',
            fieldName: 'dealCoCl1Nm',
            type: 'data',
            header: { text: '거래처구분' },
            width: '150',
        },
        {
            name: 'dealStNm',
            fieldName: 'dealStNm',
            type: 'data',
            header: { text: '거래상태' },
            width: '150',
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            type: 'data',
            header: { text: '거래개시일' },
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            type: 'data',
            header: { text: '거래종료일' },
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            header: { text: 'D코드' },
            width: '150',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            header: { text: 'SUB코드' },
            width: '150',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'ppsCmms',
            fieldName: 'ppsCmms',
            type: 'data',
            header: { text: 'PPS수수료' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'newMgtCmms',
            fieldName: 'newMgtCmms',
            type: 'data',
            header: { text: '신규관리수수료' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'chgMgtCmms',
            fieldName: 'chgMgtCmms',
            type: 'data',
            header: { text: '기변관리수수료' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },

        {
            name: 'opCmms',
            fieldName: 'opCmms',
            type: 'data',
            header: { text: '업무처리수수료' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'wireMgtCmms',
            fieldName: 'wireMgtCmms',
            type: 'data',
            header: { text: '유선관리수수료' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'wireCollCmms',
            fieldName: 'wireCollCmms',
            type: 'data',
            header: { text: '유선모집수수료' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'wrwlCombCmms',
            fieldName: 'wrwlCombCmms',
            type: 'data',
            header: { text: '유무선결합수수료' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
    ],
}
