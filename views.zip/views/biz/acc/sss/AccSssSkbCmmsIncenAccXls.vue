<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1500px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">SKB수수료/인센티브 정산관리 엑셀업로드</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="downloadExcelSample"
                                >엑셀양식 DownLoad</TCComButton
                            >
                        </li>
                        <li class="right">
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onReset"
                                >초기화</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onSave"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onClose"
                                >닫기</TCComButton
                            >
                        </li>
                    </ul>
                    <!-- Search_line 1 -->
                    <div class="searchform">
                        <!-- input -->
                        <div class="formitem div4">
                            <v-file-input
                                id="excelFile"
                                ref="excelFile"
                                label="엑셀업로드"
                                style="display: none"
                                @change="onChangeExcelFile"
                            ></v-file-input>
                        </div>
                        <!-- // input -->
                    </div>
                    <!-- // Search_line 1 -->
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeaderExcelUp"
                                ref="gridHeaderExcelUp"
                                gridTitle="SKB수수료/인센티브 엑셀업로드"
                                :isPageRows="true"
                                :isExceldown="true"
                                :isExcelup="true"
                                @excelUploadBtn="onSelectExcelFile"
                                @excelDownBtn="downloadExcel"
                                :gridObj="gridObj"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="gridExcelUp"
                                ref="gridExcelUp"
                                :editable="false"
                                :fields="view.fields"
                                :columns="view.columns"
                                :styles="gridStyle"
                            />
                        </div>
                        <span
                            class="infoTxt color-black"
                            style="font-weight: bold"
                            >유형 : 01(수수료), 02(인센티브),
                            03(사은품변환금)</span
                        >
                        <span
                            class="infoTxt color-black"
                            style="font-weight: bold"
                            >상품 : A(SKB), B(T-Board)</span
                        >
                        <!-- //gridWrap -->
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeaderExcelUp1"
                                ref="gridHeaderExcelUp1"
                                gridTitle="오류데이터"
                                :isPageRows="true"
                                :isPageCnt="true"
                                :isExceldown="true"
                                @excelDownBtn="downloadExcelerror"
                                :gridObj="gridObj1"
                            >
                                <template #gridElementLeftArea>
                                    <span id="span1" class="stitTxtL">
                                        <span
                                            id="span2"
                                            class="color-red"
                                        ></span
                                    ></span>
                                </template>
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="gridExcelUp1"
                                ref="gridExcelUp1"
                                :editable="false"
                                :fields="view1.fields"
                                :columns="view1.columns"
                                :styles="gridStyle"
                            />
                            <TCRealGridHeader
                                v-show="false"
                                id="gridHeaderExcelUp2"
                                ref="gridHeaderExcelUp2"
                                gridTitle="엑셀업로드 양식다운로드"
                                :gridObj="gridObj2"
                            />
                            <TCRealGrid
                                v-show="false"
                                id="gridExcelUp2"
                                ref="gridExcelUp2"
                                :gridObj="gridObj2"
                                :fields="view2.fields"
                                :columns="view2.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- Close BTN-->
                    <!-- <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    > -->
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
import JSZip from 'jszip'
import moment from 'moment'
import attachApi from '@/api/common/attachedFile'
// import { prototype } from '@/views/prototype/js/prototype'
import { AccExcelUpload } from '@/views/biz/acc'
import { CommonGrid } from '@/utils'
import sktCmmApi from '@/api/biz/acc/sss/AccSssSkbCmmsIncenAccMgmt'
import {
    GRID_HEADER1, //업로드 그리드
    GRID_HEADER2, //오류 그리드
    GRID_HEADER3, //양식 그리드
} from '@/const/grid/acc/sss/AccSssSkbCmmsIncenAccXlsGrid'
import CommonMixin from '@/mixins'

export default {
    name: 'AccSssSkbCmmsIncenAccXls',
    title: 'SKB수수료/인센티브 정산관리 엑셀업로드',
    mixins: [CommonMixin],
    props: {
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER1,
            view1: GRID_HEADER2,
            view2: GRID_HEADER3,
            objAuth: {},
            uploadList: [],
            list2: [],

            gridObj: {},
            gridObj1: {},
            gridObj2: {},
            gridHeaderObj: {},
            gridHeaderObj1: {},
            gridHeaderObj2: {},
            gridStyle: {
                height: '100px', //그리드 높이 조절
            },

            searchForms: {},
            resultData: '',
            res: {},
            rowCnt: 15,

            // checkTypeList: {
            //     date: ['accYm'],
            // },
            requiredGrid: {
                wireAccClCd: '유형항목',
                prodClCd: '상품항목',
                // splyPrc: '공급가',
                agencyCd: '대리점코드',
            },

            accYm_: '',
        }
    },
    computed: {
        // dateFormatted() {
        //     return 'accYm'
        // },
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {},
    created() {
        // this.init()
    },
    mounted() {
        console.log('mounted')

        // grid1 기본
        this.gridObj = this.$refs.gridExcelUp
        this.gridHeaderObj = this.$refs.gridHeaderExcelUp
        this.gridObj.setGridState(false, false, false, true)

        // grid2 오류검사
        this.gridObj1 = this.$refs.gridExcelUp1
        this.gridHeaderObj1 = this.$refs.gridHeaderExcelUp1
        this.gridObj1.setGridState(false, false, false)

        // grid3 양식
        this.gridObj2 = this.$refs.gridExcelUp2
        this.gridHeaderObj2 = this.$refs.gridHeaderExcelUp2
        this.gridObj2.setGridState(false, false, false)
        console.log(this.popupParams.accYm_)
    },
    methods: {
        //GridSet Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        //엑셀 업로드 초기화 버튼 이벤트
        onReset: function () {
            this.uploadList = []
            this.list2 = []
            this.gridObj.setRows(this.uploadList)
            this.gridObj1.setRows(this.list2)
        },

        //저장 ::: addSkbCommsIncenExcelUploadList
        onSave: function () {
            if (this.onSaveVal() == false) {
                return
            }
            this.showTcComConfirm(
                'Excel 자료 ' +
                    this.uploadList.length +
                    '건을 UPLOAD 하시겠습니까?'
            ).then((confirm) => {
                console.log('showTcComConfirm confirm: ', confirm)
                if (confirm) {
                    this.searchForms.uploadList = _.cloneDeep(this.uploadList)
                    this.searchForms.uploadList.map((json) => {
                        json.skbAgencyCd = json.agencyCd
                        // 정산일에서 하이픈(-) 제거
                        if (!_.isEmpty(json.accYm)) {
                            json.accYm = json.accYm.replace(/-/g, '')
                            json.accYm = json.accYm.substring(0, 6)
                        }
                        return json
                    })

                    sktCmmApi
                        .addSkbcmmsIncenExcelUploadList(this.searchForms)
                        .then((resultData) => {
                            if (resultData == undefined) {
                                this.showTcComAlert('저장 실패하였습니다.')
                                return
                            } else
                                this.showTcComAlert(
                                    this.uploadList.length + '건 저장 완료'
                                )
                            this.$emit('confirm', true)
                            this.onClose()
                        })
                        .catch((errList) => {
                            errList.forEach((arr) =>
                                this.showTcComAlert(`${arr.msg}`)
                            )
                        })
                }
            })
        },

        onSaveVal: function () {
            if (_.isEmpty(this.uploadList) || this.uploadList.length == 0) {
                this.showTcComAlert(
                    '수수료 인센티브 정산목록 Upload후 저장하십시오.'
                )
                return false
            }

            return true
        },

        onClose: function () {
            this.activeOpenAgency = false
        },
        onSelectExcelFile: function () {
            document.getElementById('excelFile').click()
        },
        onChangeExcelFile: function (f) {
            var tabNum = 1
            var pageType = 'skb'
            AccExcelUpload.onChange(
                pageType,
                tabNum,
                f,
                this.view.columns,
                // this.checkTypeList,
                this.onReset,
                this.callbackExcelUpload
            )
        },
        callbackExcelUpload: function (uploadList) {
            if (uploadList) {
                for (var i = 0; i < uploadList.length; i++) {
                    // 필수항목 체크
                    var checkRequired = AccExcelUpload.getCheckRequired(
                        uploadList[i],
                        this.requiredGrid
                    )
                    uploadList = _.cloneDeep(uploadList)
                    uploadList.map((json) => {
                        json.skbAgencyCd = json.agencyCd
                        // 정산일에서 하이픈(-) 제거
                        if (!_.isEmpty(json.accYm)) {
                            json.accYm = json.accYm.replace(/-/g, '')
                            json.accYm = json.accYm.substring(0, 6)
                        }
                        // 엑셀 정산일 미입력시 메인 화면의 조회된 정산월 적용 (20221123 P180190 추가)
                        if (_.isEmpty(json.accYm)) {
                            json.accYm = moment(this.popupParams.accYm_).format(
                                'YYYYMM'
                            )
                            console.log(json.accYm)
                        }
                        return json
                    })
                    if (checkRequired.isPass == false) {
                        this.list2.push(
                            AccExcelUpload.getAccPssSkbErrGridJson(
                                uploadList[i],
                                checkRequired.errMsg
                            )
                        )
                        continue
                    }
                    //유형항목 코드 검사
                    if (
                        uploadList[i].wireAccClCd != '01' &&
                        uploadList[i].wireAccClCd != '02' &&
                        uploadList[i].wireAccClCd != '03'
                    ) {
                        this.list2.push(
                            AccExcelUpload.getAccPssSkbErrGridJson(
                                uploadList[i],
                                '유형항목 코드 오류입니다'
                            )
                        )
                        continue
                    }
                    //상품항목 코드 검사
                    if (
                        uploadList[i].prodClCd != 'A' &&
                        uploadList[i].prodClCd != 'B'
                    ) {
                        this.list2.push(
                            AccExcelUpload.getAccPssSkbErrGridJson(
                                uploadList[i],
                                '상품항목 코드 오류입니다'
                            )
                        )
                        continue
                    }
                    // NULL 또는 금액이 숫자인지 체크
                    if (
                        isNaN(uploadList[i].splyPrc) ||
                        Number(uploadList[i].splyPrc) == 0
                    ) {
                        this.list2.push(
                            AccExcelUpload.getAccPssSkbErrGridJson(
                                uploadList[i],
                                '공급가는 0 이아닌 숫자만을 입력하십시오'
                            )
                        )
                        continue
                    }

                    // // 입력값이 정상인 경우는 list에 push한다.
                    this.uploadList.push(uploadList[i])
                }
            }
            this.gridObj.dataProvider.fillJsonData(this.uploadList, {})
            this.gridObj1.dataProvider.fillJsonData(this.list2, {})
            // 오류 총건수 찾기
            document.getElementById('excelFile').value = ''
            if (this.list2.length > 0) {
                var span2 = (document.getElementById('span2').innerHTML =
                    this.list2.length)
                document.getElementById('span1').innerHTML =
                    '(총' + span2 + '건)'
            }
        },

        downloadExcel() {
            window.JSZip = window.JSZip || JSZip

            this.gridObj.gridView.exportGrid({
                type: 'excel',
                target: 'local',
                fileName: 'SKB수수료/인센티브_엑샐업로드_데이터.xlsx',
                applyDynamicStyles: true,
            })
        },
        downloadExcelerror: function () {
            window.JSZip = window.JSZip || JSZip

            this.gridObj1.gridView.exportGrid({
                type: 'excel',
                target: 'local',
                fileName: 'SKB수수료/인센티브엑샐업_오류데이터.xlsx',
                applyDynamicStyles: true,
            })
        },
        // 팝업 닫으면 부모페이지 재조회
        onReAccSssSkbCmmsIncenAccXls(retVal) {
            if (retVal) {
                console.log('retrunData: ', retVal)
                this.onSearch()
            }
        },

        downloadExcelSample() {
            // this.gridHeaderObj2.exportSampleGrid(
            //     'SKB수수료/인센티브엑샐업로드_양식.xlsx'
            // )
            attachApi.downloadSampleFile('403') //  SKB수수료인센티브정산관리
        },
    },
}
</script>
