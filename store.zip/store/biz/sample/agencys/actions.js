import commonApi from '@/api/common/commonCode'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
export default {
    async getCommCodeList_({ commit }, payload) {
        await commonApi.getCommonCodeListById(payload).then((res) => {
            console.log('getCommCodeList_ then : ', res)
            if (payload === 'AGENCY_PTN') {
                commit('SET_AGENCY_PTN_LIST', res)
            } else if (payload === 'AGENCY_TYP') {
                commit('SET_AGENCY_TYP_LIST', res)
            }
        })
    },

    async getAgencyList_({ commit }, payload) {
        await basBcoAgencysApi.getAgencyList(payload).then((res) => {
            console.log('getAgencyList then : ', res)
            commit('SET_AGENCY_LIST', res)
        })
    },

    // setSearchDateModel_({ commit }, payload) {
    //     commit('SET_SEARCH_DATE_MODEL', payload)
    // },
}
