<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">거래처종료확인서 발행요청 등록</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="div_search.orgNm"
                                    :codeVal.sync="div_search.orgCd"
                                    labelName="소속조직"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :eRequired="true"
                                    :disabled="disabledOrgPop"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="div_search"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="div_search.dealcoNm"
                                    :codeVal.sync="div_search.dealcoCd"
                                    labelName="거래처코드"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onDealcoEnterKey"
                                    @appendIconClick="onDealcoIconClick"
                                    @input="onDealcoInput"
                                    :eRequired="true"
                                    :disabled="disabledDealPop"
                                />
                                <BasBcoDealcosPop
                                    v-if="showBasBcoDealcos"
                                    :parentParam="div_search"
                                    :rows="resultDealcoRows"
                                    :dialogShow.sync="showBasBcoDealcos"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComComboBox
                                    labelName="거래종료 주요 사유"
                                    v-model="div_search.cmb_dealEndPriRsn"
                                    :itemList="ds_dealEndPriRsn"
                                    :itemText="'text'"
                                    :itemValue="'value'"
                                    :objAuth="objAuth"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :eRequired="true"
                                    :disabled="disabledDealEndPriRsn"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="div_search.edt_reqTyp"
                                    labelName="유형"
                                    :objAuth="objAuth"
                                    :disabled="disabledReqTyp"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="div_search.edt_dealPeriod"
                                    labelName="거래기간"
                                    :objAuth="objAuth"
                                    :disabled="disabledDealPreriod"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="div_search.edt_avrSales"
                                    labelName="3개월 평균실적(직전 2개월 제외)"
                                    :objAuth="objAuth"
                                    :disabled="disabledAvrSales"
                                >
                                </TCComInput>
                            </div>
                            <div class="textareaLayer_wrap">
                                <TCComTextArea
                                    v-model="div_search.textArea_rmks"
                                    labelName="상세사유"
                                    class="boxtype"
                                    :rows="10"
                                    :eRequired="true"
                                    :disabled="disabledTextArea"
                                >
                                </TCComTextArea>
                            </div>
                        </div>
                    </div>

                    <div class="btn_area_bottom">
                        <TCComButton
                            v-if="parentData.chkNewYn === 'Y'"
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onConfirm"
                            :objAuth="objAuth"
                        >
                            요청
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
        </template>
    </TCComDialog>
</template>

<style></style>

<script>
// import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
import _ from 'lodash'
// import { HEADER } from '@/const/grid/bas/prm/basPrmDealEndNeedReqHeader'
import API from '@/api/biz/bas/prm/basPrmDealEndNeedReq'
//====================내부조직팝업(권한)팝업============================================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================================================================================
//====================내부거래처(권한조직)==============================================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosEndNeedReqPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcosEndNeedReq'
//====================================================================================
import CommonMixin from '@/mixins'
import { msgTxt } from '@/const/msg.Properties'
/**************************************************************************************************************
 * 공통 LIB import 영역
 **************************************************************************************************************/
// import { NewLib } from '@/views/newlib'

export default {
    name: 'BasPrmDealEndNeedReqRgstPopup',
    components: { BasBcoAuthOrgTreesPopup, BasBcoDealcosPop },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    mixins: [CommonMixin],

    data() {
        return {
            // v_btn_del: { visible: false },
            // gridData: this.gridSetData(),
            // gridObj: {},
            // gridHeaderObj: {},
            // view: HEADER,
            // rowCnt: 15,
            // ds_reqTyp: [
            //     { text: '전체', value: '' },
            //     { text: '확인필요(담당임원 결재)', value: '1' },
            //     { text: '일반', value: '2' },
            // ],
            // ds_reqCd: [
            //     { text: '전체', value: '' },
            //     { text: '요청', value: '1' },
            //     { text: '취소', value: '2' },
            //     { text: '승인', value: '3' },
            //     { text: '반려', value: '4' },
            //     { text: '기간만료', value: '5' },
            // ],
            disabledAvrSales: true,
            disabledDealPreriod: true,
            disabledReqTyp: true,
            disabledTextArea: true,
            disabledOrgPop: true,
            disabledDealPop: true,
            disabledDealEndPriRsn: true,
            ds_dealEndPriRsn: [
                { text: '선택', value: '' },
                { text: '실적부진', value: '1' },
                { text: '휴/폐업', value: '2' },
                { text: '업종전환', value: '3' },
                { text: '영업불만(정책 및 단가)', value: '4' },
                { text: '영업불만(정산 및 관리제도)', value: '5' },
                { text: '영업불만(재고)', value: '6' },
                { text: '영업불만(CS전산)', value: '7' },
                { text: '영업불만(마케터)', value: '8' },
                { text: '타 조직 이관', value: '9' },
                { text: '사고 거래처', value: '10' },
                { text: '기타(상세 사유 필수기재)', value: '11' },
            ],
            v_saleDtm: { visible: true, enable: true },
            //각각 엘리먼트 컴포넌트 v-model
            div_search: {
                // saleDtm: [NewLib.cf_today(), NewLib.cf_today()],
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                dealcoCd: '',
                dealcoNm: '',
                edt_reqTyp: '',
                edt_dealPeriod: '', //유형
                edt_avrSales: '', //요청상태
                cmb_dealEndPriRsn: '', //요청자명
                textArea_rmks: '',
                dealStNm: '',
            },
            objAuth: {},
            selectedJsonData: {},
            selectedRow: '',
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchAuthOrgTreeParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                orgLvl: '',
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //================================================================
            //====================내부거래처(권한조직)====================
            showBasBcoDealcos: false,
            searchForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한조직)==================
            colorCdList: [],
            prodMapClCdList: [],
            ds_prodMapList: [], // 조회시 데이터셋
            parentData: [],
        }
    },

    created() {
        this.init()
        console.log('this.$route Detail: ', this.$route)
        // this.searchParam = this.$route.params.search
    },

    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)
        if (this.parentData.chkNewYn == 'N') {
            // this.disabledAvrSales = true
            // let paramObj = {
            //     seq: this.parentData.reqSeq,
            // }

            this.getDealEndConfimPopup()
        } else {
            // this.div_search.orgNm = this.parentData.orgNm
            // this.div_search.orgCd = this.parentData.orgCd
            this.disabledTextArea = false
            this.disabledOrgPop = false
            this.disabledDealPop = false
            this.disabledDealEndPriRsn = false
            this.div_search.orgNm = this.parentData.orgNm
            this.div_search.orgCd = this.parentData.orgCd
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentData', value)
                this.parentData = value

                // this.searchParam.prodCd = value['prodCd']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
        },

        // 거래종료확인서발행요청 목록 조회
        getDealEndConfimPopup() {
            let paramObj = {
                orgCd: this.parentData.orgCd, // 조직코드 'AB1310', //
                orgLvl: this.parentData.orgLvl, // 조직레벨
                seq: this.parentData.reqSeq,
            }

            API.getDealEndConfimPopup(paramObj).then((result) => {
                console.log('result : ', result)
                if (result) {
                    this.div_search = {
                        dealcoCd: result.dealcoCd,
                        dealcoNm: result.dealcoNm,
                        orgCd: result.orgCd,
                        orgNm: result.orgNm,
                        cmb_dealEndPriRsn: result.dealEndPriRsnCd,
                        textArea_rmks: result.dealEndRsn,
                        edt_reqTyp: this.parentParam.reqTypCd,
                        edt_dealPeriod: this.parentParam.dealPeriod,
                        edt_avrSales: this.parentParam.avrSales,
                    }
                    // this.ds_result = result.gridList
                }
            })
        },

        // 거래종료확인서발행요청 팝업 조회
        getDealEndType(dealcoCd) {
            console.log('dealcoCd : ', dealcoCd)
            API.getDealEndType(dealcoCd).then((result) => {
                console.log('result2 : ', result)
                if (result) {
                    console.log('insideResult : ', result)
                    // this.div_search.edt_avrSales = result.avrSales
                    // this.div_search.edt_dealPeriod = result.dealPeriod
                    // this.div_search.edt_reqTyp = result.reqTypCd
                    this.div_search = {
                        ...this.div_search,
                        edt_avrSales: result.avrSales,
                        edt_dealPeriod: result.dealPeriod,
                        edt_reqTyp: result.reqTypCd,
                    }
                }
            })
        },

        // 거래처종료확인서 발행요청 등록
        onConfirm() {
            // if (!uf_chkCustBizNum(div_search.TextArea_rmks)) {
            //     return false
            // }

            if (_.isEmpty(this.div_search.orgNm)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(
                        msgTxt.MSG_01022,
                        '소속조직을 먼저 입력 또는 선택해 주십시오.'
                    )
                )
                return false
            }

            if (_.isEmpty(this.div_search.dealcoNm)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(
                        msgTxt.MSG_00979,
                        '거래처구분은 필수 조건 항목입니다.'
                    )
                )
                return false
            }

            if (_.isEmpty(this.div_search.cmb_dealEndPriRsn)) {
                alert('거래종료 주요사유를 선택하십시오.')
                this.showTcComAlert('거래종료 주요사유를 선택하십시오.')
                return false
            }

            if (_.isEmpty(this.div_search.textArea_rmks)) {
                alert('상세사유를 입력해주십시오.')
                this.showTcComAlert('상세사유를 입력해주십시오.')
                return false
            }
            let dealEndPriRsnNmList = this.ds_dealEndPriRsn.filter(
                (p) => p.value == this.div_search.cmb_dealEndPriRsn
            )

            let saveParam = {
                // seq: '',
                orgCd: this.div_search.orgCd ? this.div_search.orgCd : '',
                orgLvl: this.div_search.orgLvl ? this.div_search.orgLvl : '',
                // dealcoCd: '100000',
                dealcoCd: this.div_search.dealcoCd
                    ? this.div_search.dealcoCd
                    : '',
                reqTypCd: this.div_search.edt_reqTyp
                    ? this.div_search.edt_reqTyp
                    : '',
                dealPeriod: this.div_search.edt_dealPeriod
                    ? this.div_search.edt_dealPeriod
                    : '',
                avrSales: this.div_search.edt_avrSales
                    ? this.div_search.edt_avrSales
                    : '',
                dealEndPriRsnCd: this.div_search.cmb_dealEndPriRsn
                    ? this.div_search.cmb_dealEndPriRsn
                    : '',

                dealEndPriRsnNm: _.get(dealEndPriRsnNmList[0], 'text'),
                dealEndRsn: this.div_search.textArea_rmks
                    ? this.div_search.textArea_rmks
                    : '',
                dealStNm: this.div_search.dealStNm
                    ? this.div_search.dealStNm
                    : '',
                // reqTypCd: '',
                // ssupOrg: '',
                // mstMblPhone: '',
                menuUrl: this.$route.fullPath,
            }
            console.log('saveParam : ', saveParam)
            API.saveDealEndConfimReq(saveParam).then((result) => {
                console.log('result : ', result)
                if (result !== null) {
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    this.onClose()
                } else {
                    this.showTcComAlert(result.message)
                }
            })
        },

        // 초기화
        onResetPage() {
            CommonUtil.clearPage(this.$router)
        },

        onClose() {
            this.activeOpen = false
            this.$parent.onSearch()
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.div_search)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    let cnt = 0

                    res.map((p) => {
                        if (p.orgLvl == '3') {
                            cnt++
                        }
                    })

                    if (cnt === 1) {
                        res.map((p) => {
                            this.div_search.orgCd = _.get(p, 'orgCd')
                            this.div_search.orgNm = _.get(p, 'orgNm')
                            this.div_search.orgLvl = _.get(p, 'orgLvl')
                        })
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            // if (!_.isEmpty(this.searchAuthOrgTreeParam.orgNm)) {
            //     this.getAuthOrgTreeList()
            // } else {
            this.showBcoAuthOrgTrees = true
            // }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.div_search.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.div_search.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.div_search.orgCd = _.get(retrunData, 'orgCd')
            this.div_search.orgNm = _.get(retrunData, 'orgNm')
            this.div_search.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.div_search).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.div_search.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.div_search.dealcoNm = _.get(res[0], 'dealcoNm')
                    this.div_search.dealStNm = _.get(res[0], 'dealStatus')
                    this.getDealEndType(this.div_search.dealcoCd)
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            if (_.isEmpty(this.div_search.orgCd)) {
                this.showTcComAlert('조직을 입력 하여 주시기 바랍니다.')
                return false
            }
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.div_search.dealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.div_search.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-전체조직명 입력해주세요.'
                return
            }
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.div_search.dealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.div_search.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.div_search.dealcoNm = _.get(retrunData, 'dealcoNm')
            this.div_search.dealStNm = _.get(retrunData, 'dealStatus')

            this.getDealEndType(this.div_search.dealcoCd)
        },
        //===================== //내부거래처(권한조직)팝업관련 methods ================================
    },
}
</script>
