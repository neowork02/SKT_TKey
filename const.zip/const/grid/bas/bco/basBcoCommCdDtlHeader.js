/*****************************************
* 업무 그룹명 : 기준정보>공통팝업상세
* 서브 업무명 : 공통팝업상세
* 설 명 : 공통팝업상세검색 Grid 헤더 정보
* 작 성 자 : 이창석
* 작 성 일 : 2022.04.19
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 이창석  / 2022.05.09
* 변경사유/내역 : 
* ---------------------------------------
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const BAS_BCO_COMMCDDTL_HEADER = {
    fields: [
        {
            fieldName: 'commCdVal',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'commCdValNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'commCdVal',
            fieldName: 'commCdVal',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '공통코드',
            },
        },
        {
            name: 'commCdValNm',
            fieldName: 'commCdValNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '공통코드명',
            },
        },
    ],
}
