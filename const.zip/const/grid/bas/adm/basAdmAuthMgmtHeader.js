import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'userGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sortSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'attcClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'attcClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'copy',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'setup',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'searchUser',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: '',
            fieldName: 'attcClCd',
            header: {
                text: '소속유형',
            },
            editable: false,
        },
        {
            name: '',
            fieldName: 'userGrpNm',
            header: {
                text: '권한그룹명',
            },
            editable: false,
        },
        {
            name: '',
            fieldName: 'userGrpCd',
            header: {
                text: '권한그룹코드',
            },
            editable: false,
        },
        {
            name: 'lvOrgCd',
            fieldName: 'lvOrgCd',
            header: {
                text: '',
            },
            visible: false,
        },
        {
            name: 'delYn',
            fieldName: 'delYn',
            header: {
                text: '',
            },
            visible: false,
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },

        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'sortSeq',
            fieldName: 'sortSeq',
            header: {
                text: '정렬순서',
            },
            editable: false,
            visible: true,
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'userGrpCd',
            fieldName: 'userGrpCd',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'serNo',
            fieldName: 'serNo',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'userId',
            fieldName: 'userId',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'userGrpDesc',
            fieldName: 'userGrpDesc',
            header: {
                text: '상세',
            },
            editable: false,
            visible: true,
        },
        {
            name: 'attcClNm',
            fieldName: 'attcClNm',
            header: {
                text: '소속유형',
            },
            editable: false,
            visible: true,
        },
        {
            name: 'copy',
            fieldName: 'copy',
            width: '50',
            header: {
                text: ' ',
            },
            editable: false,
            renderer: {
                type: 'button',
            },
            visible: false,
            buttonVisibility: 'always',
        },
        {
            name: 'setup',
            fieldName: 'setup',
            width: '50',
            header: {
                text: ' ',
            },
            editable: false,
            renderer: {
                type: 'button',
            },
            visible: false,
            buttonVisibility: 'always',
        },
        {
            name: 'searchUser',
            fieldName: 'searchUser',
            width: '50',
            header: {
                text: ' ',
            },
            editable: false,
            renderer: {
                type: 'button',
            },
            visible: false,
            buttonVisibility: 'always',
        },
    ],
}

export const M_HEADER2 = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'origin',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'authTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'portalUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'authGubn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'origin',
            fieldName: 'origin',
            header: {
                text: 'origin',
            },
            visible: false,
        },
        {
            name: 'userGrpCd',
            fieldName: 'userGrpCd',
            header: {
                text: 'userGrpCd',
            },
            visible: false,
        },
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: {
                text: '소속조직',
            },
            editable: false,
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            header: {
                text: '사용자명',
            },
            editable: false,
        },
        {
            name: 'portalUserId',
            fieldName: 'portalUserId',
            header: {
                text: '포탈ID',
            },
            editable: false,
        },
        {
            name: 'userId',
            fieldName: 'userId',
            header: {
                text: '사용아이디',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'authTypCd',
            fieldName: 'authTypCd',
            header: {
                text: 'authTypCd',
            },
            visible: false,
        },
        {
            name: 'orgClCd',
            fieldName: 'orgClCd',
            header: {
                text: 'orgClCd',
            },
            visible: false,
        },
        {
            name: 'serNo',
            fieldName: 'serNo',
            header: {
                text: '',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'authGubn',
            fieldName: 'authGubn',
            header: {
                text: '구분',
            },
            editable: false,
            visible: true,
        },
    ],
}
