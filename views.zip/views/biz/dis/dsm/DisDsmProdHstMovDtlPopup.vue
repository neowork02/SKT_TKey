<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">상세내역</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- gridWrap -->
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="재고이동상세"
                        :gridObj="gridObj"
                        :isPageRows="false"
                        :isExceldown="true"
                        :isNextPage="false"
                        :isPageCnt="true"
                        class="pop"
                        @excelDownBtn="onClickDownload"
                    />
                    <!-- [팝업화면 기준] RealGrid가 화면 최상단에 위치할 경우 TCRealGridHeader에 class="pop" 추가 -->
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :fields="view.fields"
                        :columns="view.columns_move"
                    />
                    <!-- //gridWrap -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonGrid } from '@/utils'

import api from '@/api/biz/dis/dsm/disDsmProdHstBrws'
import attachedFileApi from '@/api/common/attachedFile'

import { OUT_MOVE_HEADER } from '@/const/grid/dis/dsm/disDsmProdHstBrwsDtlHead'

export default {
    name: 'DisDsmProdHstMovDtlPopup',
    mixins: [CommonMixin],
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: this.GridSetData(),

            view: OUT_MOVE_HEADER,
            dsResult: [],

            dsConditionPopup: {},
            objAuth: {},
            //조회 파라미터
            reqParams: {},
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    created() {},
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 조회
        this.fGetSerNumList()
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObj = this.$refs.grid1
            this.gridHeaderObj = this.$refs.gridHeader1
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            this.gridObj.setGridState(true)
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, 1000, '', '')
        },

        fGetSerNumList: function () {
            this.dsConditionPopup = this.popupParams
            //  prodCd // 상품코드
            //  colorCd // 색상코드
            //  serNum // 상품일련번호
            //  inoutMgmtNo // 입출고관리번호
            //  inoutSeq // 입출고순번
            //  prchTypCd // 구매유형코드
            console.log('this.popupParams>>>>>>>>>>>>>>', this.popupParams)

            // this.dsConditionPopup.prodCd = 'A06H'
            // this.dsConditionPopup.colorCd = '10'
            // this.dsConditionPopup.serNum = '0234650'
            // this.dsConditionPopup.inoutMgmtNo = 'MV202112275187138'
            // this.dsConditionPopup.inoutSeq = '172528190'

            this.reqParams = this.dsConditionPopup

            const formData = {
                dsCondition: {
                    prodCd: this.dsConditionPopup.prodCd,
                    colorCd: this.dsConditionPopup.colorCd,
                    serNum: this.dsConditionPopup.serNum,
                    inoutMgmtNo: this.dsConditionPopup.inoutMgmtNo,
                    inoutSeq: this.dsConditionPopup.inoutSeq,
                    //...this.dsConditionPopup,
                },
            }

            // this.popupParams.FV_WORK_CL == 'HST_MOV' || 'HST_MOV_SCHD'
            api.getProdHstMovDtls(formData).then((resultData) => {
                this.dsResult = resultData
                this.gridObj.setRows(this.dsResult)

                //페이지 정보
                let pageInfo = {}
                pageInfo.type = 'noPaging' //페이징이 없는경우
                pageInfo.totalDataCnt = this.gridObj.dataProvider.getRowCount() // 총건수
                this.gridObj.setGridIndicator(pageInfo) //순번 셋팅
            })
        },
        closeBtn: function () {
            this.$emit('confirm', true)
            this.activeOpen = false
        },
        //Grid ExcelDown
        onClickDownload: function () {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/prodHstMovDtlsExcelDown',
                this.reqParams
            )
        },
    },
}
</script>
