import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('sal.sel.saleMgmtStore', Object.keys(state)),
    ...mapGetters('sal.sel.saleMgmtStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('sal.sel.saleMgmtStore', Object.keys(actions)),
    ...mapMutations('sal.sel.saleMgmtStore', Object.keys(mutations)),
}
