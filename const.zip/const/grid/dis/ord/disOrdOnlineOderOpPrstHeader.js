import { ValueType } from 'realgrid'

export const GRID_LAYOUT = [
    'NO',
    'brwsClNm',
    'ordOpTypNm',
    'ordRcvStNm',
    {
        name: '주문처리상태',
        direction: 'horizontal',
        items: ['ordrcvCnt', 'ordfixCnt', 'cncfixCnt', 'iofixCnt', 'opnfixCnt'],
    },
    {
        name: '배송상태',
        direction: 'horizontal',
        items: ['recvCnt', 'redyCnt', 'scn1Cnt', 'scn2Cnt', 'scn3Cnt'],
    },
]

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'brwsClNm',
            dataType: ValueType.TEXT, // 조회구분명
        },
        {
            fieldName: 'ordOpTypNm',
            dataType: ValueType.TEXT, // 주문유형명
        },
        {
            fieldName: 'ordRcvStNm',
            dataType: ValueType.TEXT, // 주문의뢰상태명
        },
        {
            fieldName: 'ordrcvCnt',
            dataType: ValueType.NUMBER, // 주문접수건수
        },
        {
            fieldName: 'ordfixCnt',
            dataType: ValueType.NUMBER, // 주문확정건수
        },
        {
            fieldName: 'cncfixCnt',
            dataType: ValueType.NUMBER, // 취소확정건수
        },
        {
            fieldName: 'iofixCnt',
            dataType: ValueType.NUMBER, // 입출고확정건수
        },
        {
            fieldName: 'opnfixCnt',
            dataType: ValueType.NUMBER, // 개통확정건수
        },
        {
            fieldName: 'recvCnt',
            dataType: ValueType.NUMBER, // 배송의뢰건수
        },
        {
            fieldName: 'redyCnt',
            dataType: ValueType.NUMBER, // 배송대기건수
        },
        {
            fieldName: 'scn1Cnt',
            dataType: ValueType.NUMBER, // 스캔1차건수
        },
        {
            fieldName: 'scn2Cnt',
            dataType: ValueType.NUMBER, // 스캔2차건수
        },
        {
            fieldName: 'scn3Cnt',
            dataType: ValueType.NUMBER, // 스캔3차건수
        },
    ],
    columns: [
        {
            name: 'brwsClNm',
            fieldName: 'brwsClNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '구분',
            },
            footer: {
                text: '합계',
                styleName: 'center-column',
            },
        },
        {
            name: 'ordOpTypNm',
            fieldName: 'ordOpTypNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문유형',
            },
        },
        {
            name: 'ordRcvStNm',
            fieldName: 'ordRcvStNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문의뢰유형',
            },
        },
        {
            name: 'ordrcvCnt',
            fieldName: 'ordrcvCnt',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문접수',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'ordfixCnt',
            fieldName: 'ordfixCnt',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문확정',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cncfixCnt',
            fieldName: 'cncfixCnt',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '취소확정',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'iofixCnt',
            fieldName: 'iofixCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입출고확정',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'opnfixCnt',
            fieldName: 'opnfixCnt',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '개통완료',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'recvCnt',
            fieldName: 'recvCnt',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '배송의뢰',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'redyCnt',
            fieldName: 'redyCnt',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '배송대기',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'scn1Cnt',
            fieldName: 'scn1Cnt',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '스캔1차',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'scn2Cnt',
            fieldName: 'scn2Cnt',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '스캔2차',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'scn3Cnt',
            fieldName: 'scn3Cnt',
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '스캔3차',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],
}
