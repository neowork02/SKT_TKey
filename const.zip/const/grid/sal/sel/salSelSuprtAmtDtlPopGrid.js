import { ValueType } from 'realgrid'

export const GRIDHEADER = {
    fields: [
        {
            fieldName: 'classNm',
            dataType: ValueType.TEXT, // 구분명
        },
        {
            fieldName: 'classAmt',
            dataType: ValueType.NUMBER, // 금액
        },
    ],
    columns: [
        {
            name: 'classNm',
            fieldName: 'classNm',
            type: 'data',
            width: '140',
            styleName: 'left-column',
            header: {
                text: '구분',
                showTooltip: false,
            },
            footer: {
                text: '지원금합계',
            },
        },
        {
            name: 'classAmt',
            fieldName: 'classAmt',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '금액',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
    ],
}
