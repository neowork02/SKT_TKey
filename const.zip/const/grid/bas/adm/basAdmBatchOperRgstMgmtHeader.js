import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'batchProgId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'batNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'midId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'runCycleCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'batRgstDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expStaDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expEndDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expRunDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'batChrgrNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'batchProgId',
            fieldName: 'batchProgId',
            type: 'data',
            header: {
                //text: '*배치프로그램ID',
                template: '<span class="emph_txt">* </span>${headerText}',
                values: { headerText: '배치프로그램ID' },
            },
            editable: false,
            visible: true,
            width: '200',
            //required: true,
            editor: {
                //textCase: 'upper',
                maxLength: 50,
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true
                } else {
                    ret.editable = false
                }
                return ret
            },
        },
        {
            name: 'batNm',
            fieldName: 'batNm',
            type: 'data',
            header: {
                //text: '*배치명',
                template: '<span class="emph_txt">* </span>${headerText}',
                values: { headerText: '배치명' },
            },
            editable: true,
            visible: true,
            width: '200',
            //required: true,
            editor: {
                //textCase: 'upper',
                maxLength: 50,
            },
        },
        {
            name: 'bizId',
            fieldName: 'bizId',
            type: 'data',
            header: {
                //text: '*업무구분',
                template: '<span class="emph_txt">* </span>${headerText}',
                values: { headerText: '업무구분' },
            },
            editable: true,
            visible: true,
            width: '80',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            //required: true,
        },
        {
            name: 'midId',
            fieldName: 'midId',
            type: 'data',
            header: {
                //text: '*업무중분류',
                template: '<span class="emph_txt">* </span>${headerText}',
                values: { headerText: '업무중분류' },
            },
            editable: true,
            visible: true,
            width: '80',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            //required: true,
        },
        {
            name: 'runCycleCd',
            fieldName: 'runCycleCd',
            type: 'data',
            header: {
                text: '수행주기',
            },
            editable: true,
            visible: true,
            width: '80',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'batRgstDt',
            fieldName: 'batRgstDt',
            type: 'data',
            header: {
                text: '등록일자',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'expStaDtm',
            fieldName: 'expStaDtm',
            type: 'data',
            header: {
                text: '예상시작일시',
            },
            editable: true,
            visible: true,
            width: '160',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMddhhmmss',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99 99:99:99',
                },
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'expEndDtm',
            fieldName: 'expEndDtm',
            type: 'data',
            header: {
                text: '예상종료일시',
            },
            editable: true,
            visible: true,
            width: '160',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMddhhmmss',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99 99:99:99',
                },
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'expRunDtm',
            fieldName: 'expRunDtm',
            type: 'data',
            header: {
                text: '예상수행일시',
            },
            editable: true,
            visible: true,
            width: '160',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMddhhmmss',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99 99:99:99',
                },
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'batChrgrNm',
            fieldName: 'batChrgrNm',
            type: 'data',
            header: {
                text: '담당자명',
            },
            editable: true,
            visible: true,
            width: '80',
            editor: {
                //textCase: 'upper',
                maxLength: 50,
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            header: {
                text: '비고',
            },
            editable: true,
            visible: true,
            width: '150',
            editor: {
                //textCase: 'upper',
                maxLength: 250,
            },
            renderer: {
                showTooltip: true,
            },
        },
        {
            name: 'delYn',
            fieldName: 'delYn',
            type: 'data',
            header: {
                text: '삭제여부',
            },
            editable: false,
            visible: true,
            width: '60',
            // lookupDisplay: true,
            // editor: {
            //     type: 'dropdown',
            //     dropDownCount: 2,
            //     domainOnly: true,
            //     textReadOnly: true,
            //     values: [],
            //     labels: [],
            // },
        },
    ],
}
