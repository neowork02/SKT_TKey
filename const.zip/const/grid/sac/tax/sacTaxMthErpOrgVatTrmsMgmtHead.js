import { ValueType } from 'realgrid'

export const ORG_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgLvl', // 조직레벨
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxClNm', // 구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxClCd', // 구분 코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc', // 공급가액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totAmt', // 합계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totalCnt', // 전체건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranTry', // 전송요청건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranCnt', // 전송건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranErr', // 전송오류건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranNot', // 미전송건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNmShot', // 조직명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'taxClNm',
            fieldName: 'taxClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '구분',
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공급가액',
            numberFormat: '#,##0',
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '부가세액',
            numberFormat: '#,##0',
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '합계',
            numberFormat: '#,##0',
        },
        {
            name: 'totalCnt',
            fieldName: 'totalCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전체건수',
        },
        {
            name: 'tranTry',
            fieldName: 'tranTry',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송요청건수',
        },
        {
            name: 'tranCnt',
            fieldName: 'tranCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송건수',
        },
        {
            name: 'tranErr',
            fieldName: 'tranErr',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송오류건수',
        },
        {
            name: 'tranNot',
            fieldName: 'tranNot',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '미전송건수',
        },
        {
            name: 'orgNmShot',
            fieldName: 'orgNmShot',
            type: 'data',
            header: '조직명',
        },
        {
            name: 'orgLvl',
            fieldName: 'orgLvl',
            type: 'data',
            header: '조직레벨',
        },
    ],
    layout: [
        'orgCd',
        'orgNm',
        'taxClNm',
        'splyPrc',
        'vatAmt',
        'totAmt',
        {
            name: '거래처',
            direction: 'horizontal',
            items: ['totalCnt', 'tranTry', 'tranCnt', 'tranErr', 'tranNot'],
        },
    ],
}

export const DEAL_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orglvl', // 조직레벨
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 거래처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 거래처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizNo', // 거래처사업자번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxClNm', // 구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc', // 공급가액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totAmt', // 합계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dealEndYn', // 종료여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqYn', // 요청
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqDtm', // 요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNm', // 요청자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsNm', // 전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsDtm', // 전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'accShopCd',
            fieldName: 'accShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처매장코드',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처코드',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처',
        },
        {
            name: 'bizNo',
            fieldName: 'bizNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처사업자번호',
        },
        {
            name: 'taxClNm',
            fieldName: 'taxClNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '구분',
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공급가액',
            numberFormat: '#,##0',
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '부가세액',
            numberFormat: '#,##0',
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '합계',
            numberFormat: '#,##0',
        },
        {
            name: 'dealEndYn',
            fieldName: 'dealEndYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '종료여부',
        },
        {
            name: 'trmsReqYn',
            fieldName: 'trmsReqYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청',
        },
        {
            name: 'trmsReqDtm',
            fieldName: 'trmsReqDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '요청일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'reqUserNm',
            fieldName: 'reqUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청자',
        },
        {
            name: 'trmsNm',
            fieldName: 'trmsNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송여부',
        },
        {
            name: 'trmsDtm',
            fieldName: 'trmsDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
    ],
}
