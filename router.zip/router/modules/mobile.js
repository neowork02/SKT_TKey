import Vue from 'vue'
import VueRouter from 'vue-router'
import MblLayout from '@/layout/MblLayout'
Vue.use(VueRouter)

const routes = [
    {
        path: '/mobile',
        name: 'mobile',
        component: MblLayout,
        redirect: '/mobile/home/MblMain',
        children: [
            {
                path: '/mobile/home/MblMain',
                name: '/mobile/home/MblMain',
                component: () =>
                    import('@/views/mobile/home/MblMain') /* 모바일-메인 */,
                meta: {
                    menuNm: 'T.key-taka',
                    menuNo: '0001',
                    screenId: 'SC0001',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/home/MblMenu',
                name: '/mobile/home/MblMenu',
                component: () =>
                    import('@/views/mobile/home/MblMenu') /* 모바일-메뉴 */,
                meta: {
                    menuNm: '메뉴',
                    menuNo: '0002',
                    screenId: 'SC0002',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/home/MblMyMenu',
                name: '/mobile/home/MblMyMenu',
                component: () =>
                    import('@/views/mobile/home/MblMyMenu') /* 나의메뉴설정 */,
                meta: {
                    menuNm: '나의 메뉴 설정',
                    menuNo: '0003',
                    screenId: 'SC0003',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/common/MblErrorPage',
                name: '/mobile/common/MblErrorPage',
                component: () =>
                    import(
                        '@/views/mobile/common/MblErrorPage'
                    ) /* 에러페이지 */,
                meta: {
                    menuNm: '에러페이지',
                    menuNo: '0004',
                    screenId: 'SC0004',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/dis/MblDis01',
                name: '/mobile/dis/MblDis01',
                component: () =>
                    import(
                        '@/views/mobile/dis/MblDis01'
                    ) /* 서브-SK네트웍스 입고 */,
                meta: {
                    menuNm: 'SK네트웍스 입고',
                    menuNo: '0005',
                    screenId: 'SC0005',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/dis/MblDis02',
                name: '/mobile/dis/MblDis02',
                component: () =>
                    import(
                        '@/views/mobile/dis/MblDis02'
                    ) /* 서브-SK네트웍스 입고검색 */,
                meta: {
                    menuNm: '입고 검색',
                    menuNo: '0006',
                    screenId: 'SC0006',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/bas/bbs/MblBasBbs01',
                name: '/mobile/bas/bbs/MblBasBbs01',
                component: () =>
                    import(
                        '@/views/mobile/bas/bbs/MblBasBbs01'
                    ) /* 서브-공지사항(View) */,
                meta: {
                    menuNm: '대리점 공지사항',
                    menuNo: '0007',
                    screenId: 'SC0007',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/bas/bbs/MblBasBbs02',
                name: '/mobile/bas/bbs/MblBasBbs02',
                component: () =>
                    import(
                        '@/views/mobile/bas/bbs/MblBasBbs02'
                    ) /* 서브-공지사항 리스트1 */,
                meta: {
                    menuNm: '공지사항',
                    menuNo: '0008',
                    screenId: 'SC0008',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/bas/bbs/MblBasBbs03',
                name: '/mobile/bas/bbs/MblBasBbs03',
                component: () =>
                    import(
                        '@/views/mobile/bas/bbs/MblBasBbs03'
                    ) /* 서브-공지사항 리스트2 */,
                meta: {
                    menuNm: '공지사항',
                    menuNo: '0009',
                    screenId: 'SC0009',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/bas/bbs/MblBasBbs04',
                name: '/mobile/bas/bbs/MblBasBbs04',
                component: () =>
                    import(
                        '@/views/mobile/bas/bbs/MblBasBbs04'
                    ) /* 서브-글쓰기 */,
                meta: {
                    menuNm: '글올리기',
                    menuNo: '0010',
                    screenId: 'SC0010',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/bas/bbs/MblBasBbs05',
                name: '/mobile/bas/bbs/MblBasBbs05',
                component: () =>
                    import(
                        '@/views/mobile/bas/bbs/MblBasBbs05'
                    ) /* 서브-글수정 */,
                meta: {
                    menuNm: '글수정',
                    menuNo: '0011',
                    screenId: 'SC0011',
                    mblGubun: 'Y',
                },
            },
            {
                path: '/mobile/sal/smg/MblSalSmgTsaleDtlSearch',
                name: '/mobile/sal/smg/MblSalSmgTsaleDtlSearch',
                component: () =>
                    import(
                        '@/views/mobile/sal/smg/MblSalSmgTsaleDtlSearch'
                    ) /* 서브- 판매 > T판매세부내역 */,
                meta: {
                    menuNm: 'T판매세부내역 검색',
                    menuNo: '0012',
                    screenId: 'SC0012',
                },
            },
            {
                path: '/mobile/sal/smg/MblSalSmgTsaleDtl',
                name: '/mobile/sal/smg/MblSalSmgTsaleDtl',
                component: () =>
                    import(
                        '@/views/mobile/sal/smg/MblSalSmgTsaleDtl'
                    ) /* 서브- 판매 > T판매세부내역_그리드 */,
                meta: {
                    menuNm: 'T판매세부내역',
                    menuNo: '0013',
                    screenId: 'SC0013',
                },
            },
        ],
    },
]

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch((err) => {
        if (err.name !== 'NavigationDuplicated') throw err
    })
}

export default routes
