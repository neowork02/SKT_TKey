import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'eqpClNm',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repProdCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repProdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticCd3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticCd4',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'prodChrticNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticNm2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticNm3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticNm4',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'comMthdCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'comMthdNm',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'sktOperYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxTypCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'taxTypNm',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'endYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'endDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lifeBarCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sisYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstClCd',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분코드',
                showTooltip: true,
                tooltip: '<span style="color: red;">이름</span>',
            },
            renderer: {
                type: 'text',
                showTooltip: true,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: true,
                tooltip: '<span style="color: red;">이름</span>',
            },
            renderer: {
                type: 'text',
                showTooltip: true,
            },
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분코드',
                showTooltip: false,
            },
        },
        {
            name: 'eqpClNm',
            fieldName: 'eqpClNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사명',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },

            styleName: 'left-column',
            width: 300,
            header: {
                text: '모델명/상품명',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드/바코드정보',
                showTooltip: false,
            },
        },
        {
            name: 'repProdCd',
            fieldName: 'repProdCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표모델코드',
                showTooltip: false,
            },
            numberFormat: '0',
        },
        {
            name: 'repProdNm',
            fieldName: 'repProdNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표모델명',
                showTooltip: false,
            },
            numberFormat: '0',
        },
        {
            name: 'prodChrticCd1',
            fieldName: 'prodChrticCd1',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품특성코드1',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'prodChrticCd2',
            fieldName: 'prodChrticCd2',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품특성코드2',
                showTooltip: false,
            },
            numberFormat: '0',
        },
        {
            name: 'prodChrticCd3',
            fieldName: 'prodChrticCd3',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품특성코드3',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'prodChrticCd4',
            fieldName: 'prodChrticCd4',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품특성코드4',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'prodChrticNm1',
            fieldName: 'prodChrticNm1',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품특성1',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'prodChrticNm2',
            fieldName: 'prodChrticNm2',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품특성2',
                showTooltip: false,
            },
            numberFormat: '0',
        },
        {
            name: 'prodChrticNm3',
            fieldName: 'prodChrticNm3',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품특성3',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'prodChrticNm4',
            fieldName: 'prodChrticNm4',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품특성4',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'comMthdCd',
            fieldName: 'comMthdCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '통신방식코드',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'comMthdNm',
            fieldName: 'comMthdNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '통신방식',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'sktOperYn',
            fieldName: 'sktOperYn',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT운영여부',
                showTooltip: false,
            },
            numberFormat: '0',
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            numberFormat: '0',
        },
        {
            name: 'taxTypCd',
            fieldName: 'taxTypCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '과세구분코드',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'taxTypNm',
            fieldName: 'taxTypNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '과세구분',
                showTooltip: false,
            },
            numberFormat: '0',
        },

        {
            name: 'endYn',
            fieldName: 'endYn',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단종여부',
                showTooltip: false,
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출시일',
                showTooltip: false,
            },
        },
        {
            name: 'endDt',
            fieldName: 'endDt',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단종일',
                showTooltip: false,
            },
        },
        {
            name: 'lifeBarCd',
            fieldName: 'lifeBarCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '바코드정보',
                showTooltip: false,
            },
        },
        {
            name: 'sisYn',
            fieldName: 'sisYn',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SIS상품여부',
                showTooltip: false,
            },
        },
        {
            name: 'rgstClCd',
            fieldName: 'rgstClCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록구분',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_D_HEADER = {
    fields: [
        {
            fieldName: 'PROD_NM',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hide',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'CH_CNT',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'num',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'Bool1',
            dataType: ValueType.BOOLEAN,
        },
        {
            fieldName: 'selectbox',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dateTime',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dateTime2',
            dataType: ValueType.DATETIME,
        },
        {
            fieldName: 'iconBtn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'PROD_NM',
            fieldName: 'PROD_NM',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            styleName: 'multi-line-css',
            header: {
                text: '모델명/상품명',
                showTooltip: false,
            },
            footer: {
                text: '합계',
            },
        },
        {
            name: 'hide',
            fieldName: 'hide',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'hide',
                showTooltip: false,
            },
        },
        {
            name: 'num',
            fieldName: 'num',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '금액',
                showTooltip: false,
            },
            groupFooter: {
                expression: 'sum',
                numberFormat: '#,##0.0',
                styleName: 'right-column',
            },

            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'CH_CNT',
            fieldName: 'CH_CNT',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '숫자',
                showTooltip: false,
            },
            footer: {
                numberFormat: '#,##0',
                styleName: 'orange-column',
                expression: 'sum',
            },
            editor: {
                type: 'number', //숫자 편집기 설정
                showStepButton: true, //숫자 편집 버튼 표시 여부
                direction: 'horizontal', //버튼 표시 방향 설정, "vertical" 설정 시 세로방향
                step: 100, // 버튼 클릭 시 값 단위
                min: 20, //최소값
                max: 999, //최대값
                delay: 100, //버튼을 누르고 있을 때 값 적용 간격
            },
        },
        {
            name: 'Bool1',
            fieldName: 'Bool1',
            type: 'data',
            editable: false,
            renderer: {
                type: 'check',
            },
            header: {
                text: '체크',
            },
        },
        {
            name: 'selectbox',
            fieldName: 'selectbox',
            sortable: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: ['삼성', 'LG', '애플', '샤오미', '팬택', '구글'],
                labels: [
                    '<삼성>',
                    '<LG>',
                    '<애플>',
                    '<샤오미>',
                    '<팬택>',
                    '<구글>',
                ],
            },
            header: {
                text: 'SELECTBOX',
            },
            lookupDisplay: true,
            values: ['삼성', 'LG', '애플', '샤오미', '팬택', '구글'],
            labels: [
                '<삼성>',
                '<LG>',
                '<애플>',
                '<샤오미>',
                '<팬택>',
                '<구글>',
            ],
        },
        {
            name: 'dateTime',
            fieldName: 'dateTime',
            header: {
                text: '입고\n일자',
                styleName: 'multi-line-css',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'dateTime2',
            fieldName: 'dateTime2',
            header: {
                text: '출고일자',
            },
            datetimeFormat: 'yyyyMMdd',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999/99/99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'iconBtn',
            fieldName: 'iconBtn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            button: 'action',
            buttonVisibility: 'always',

            header: {
                text: '아이콘',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_COLOR_HEADER = {
    fields: [
        {
            fieldName: 'colorCode',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'colorCode',
            fieldName: 'colorCode',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
    ],
}
