/*****************************************
 * 업무 그룹명 : 판매관리
 * 서브 업무명 : 일정산-도매일정산
 * 설 명 : 채권거래내역 Grid 헤더
 * 작 성 자 : 양현모
 * 작 성 일 : 2022.07.13
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const WSALE_DEAL_DTL_HEADER = {
    fields: [
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, // 조직트리
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT, // 거래처구분
        },
        {
            fieldName: 'saleDealcoCd',
            dataType: ValueType.TEXT, // 거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, // 거래처
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, // 서비스관리번호
        },
        // {
        //     fieldName: 'clsDt',
        //     dataType: ValueType.TEXT, // 매출일자
        // },
        // {
        //     fieldName: 'saleDtm',
        //     dataType: ValueType.TEXT, // 개통일자
        // },
        // {
        //     fieldName: 'bondItmDtl',
        //     dataType: ValueType.TEXT, // 채권구분
        // },
        // {
        //     fieldName: 'arCl',
        //     dataType: ValueType.TEXT, // 항목
        // },
        // {
        //     fieldName: 'trCl',
        //     dataType: ValueType.TEXT, // 발생구분
        // },
        // {
        //     fieldName: 'saleAmt',
        //     dataType: ValueType.NUMBER, // 금액
        // },
        // {
        //     fieldName: 'refId',
        //     dataType: ValueType.TEXT, // 비고
        // },
        {
            fieldName: 'baseDt',
            dataType: ValueType.TEXT, // 매출일자
        },
        {
            fieldName: 'saleDt',
            dataType: ValueType.TEXT, // 개통일자
        },
        {
            fieldName: 'bondItmNm',
            dataType: ValueType.TEXT, // 채권구분
        },
        {
            fieldName: 'arClNm',
            dataType: ValueType.TEXT, // 항목
        },
        {
            fieldName: 'ocurClNm',
            dataType: ValueType.TEXT, // 발생구분
        },
        {
            fieldName: 'bondItmAmt',
            dataType: ValueType.NUMBER, // 금액
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, // 비고
        },
    ],
    columns: [
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '300',
            styleName: 'left-column',
            header: {
                text: '조직',
            },
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            type: 'data',
            width: '100',
            header: {
                text: '거래처구분',
            },
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            header: {
                text: '거래처',
            },
            footer: {
                text: '합계',
            },
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            width: '100',
            header: {
                text: '서비스관리번호',
            },
        },
        // {
        //     name: 'clsDt',
        //     fieldName: 'clsDt',
        //     type: 'data',
        //     width: '100',
        //     header: {
        //         text: '매출일자',
        //     },
        // },
        // {
        //     name: 'saleDtm',
        //     fieldName: 'saleDtm',
        //     type: 'data',
        //     width: '100',
        //     header: {
        //         text: '개통일자',
        //     },
        // },
        // {
        //     name: 'bondItmDtl',
        //     fieldName: 'bondItmDtl',
        //     type: 'data',
        //     width: '100',
        //     header: {
        //         text: '채권구분',
        //     },
        // },
        // {
        //     name: 'arCl',
        //     fieldName: 'arCl',
        //     type: 'data',
        //     width: '100',
        //     header: {
        //         text: '항목',
        //     },
        // },
        // {
        //     name: 'trCl',
        //     fieldName: 'trCl',
        //     type: 'data',
        //     width: '100',
        //     header: {
        //         text: '발생구분',
        //     },
        // },
        // {
        //     name: 'saleAmt',
        //     fieldName: 'saleAmt',
        //     type: 'data',
        //     width: '100',
        //     styleName: 'right-column',
        //     numberFormat: '#,##0',
        //     header: {
        //         text: '금액',
        //     },
        //     footer: {
        //         expression: 'sum',
        //         numberFormat: '#,##0',
        //     },
        // },
        // {
        //     name: 'refId',
        //     fieldName: 'refId',
        //     type: 'data',
        //     width: '200',
        //     styleName: 'left-column',
        //     header: {
        //         text: '비고',
        //     },
        // },
        {
            name: 'baseDt',
            fieldName: 'baseDt',
            type: 'data',
            width: '100',
            header: {
                text: '매출일자',
            },
        },
        {
            name: 'saleDt',
            fieldName: 'saleDt',
            type: 'data',
            width: '100',
            header: {
                text: '개통일자',
            },
        },
        {
            name: 'bondItmNm',
            fieldName: 'bondItmNm',
            type: 'data',
            width: '100',
            header: {
                text: '채권구분',
            },
        },
        {
            name: 'arClNm',
            fieldName: 'arClNm',
            type: 'data',
            width: '100',
            header: {
                text: '항목',
            },
        },
        {
            name: 'ocurClNm',
            fieldName: 'ocurClNm',
            type: 'data',
            width: '100',
            header: {
                text: '발생구분',
            },
        },
        {
            name: 'bondItmAmt',
            fieldName: 'bondItmAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '금액',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '비고',
            },
        },
    ],
}
