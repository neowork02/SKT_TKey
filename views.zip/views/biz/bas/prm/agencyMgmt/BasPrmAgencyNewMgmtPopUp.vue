<!-----------------------------------------------
 * 업무그룹명: 기준정보>영업기준정보관리
 * 서브업무명: 대리점관리
 * 설명: 대리점관리 조회/입력/수정/삭제 한다.
 * 작성자: P143001
 * 작성일: 2022.11.28
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="600px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">대리점관리 상세</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.agencyCd"
                                    labelName="대리점코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.agencySubCd"
                                    labelName="서브코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.agencyNm"
                                    labelName="대리점명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.bizNo"
                                    labelName="사업자번호"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <!-- <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="parentParam1.aprvTypNm"
                                    labelName="대표자"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div> -->
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.zipCd"
                                    labelName="우편번호"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.addr"
                                    labelName="주소"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.chrgUserNm"
                                    labelName="담당자"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.chrgUserEmail"
                                    labelName="이메일"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.chrgUserTelNo"
                                    labelName="전화번호"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.chrgUserMblTelNo"
                                    labelName="핸드폰"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.faxNo"
                                    labelName="팩스번호"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.bizConNm"
                                    labelName="업태"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="propsParam.bizTypNm"
                                    labelName="종목"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="200"
                                    :eRequired="false"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComComboBox
                                    :itemList="ds_user"
                                    labelName="대표자"
                                    v-model="propsParam.repUserId"
                                    :objAuth="objAuth"
                                    :disabled="repUserDisable"
                                ></TCComComboBox>
                            </div>
                        </div>
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            v-if="propsParam.aplyYn === 'N'"
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="btnAgencySave"
                        >
                            대리점등록
                        </TCComButton>
                        <TCComButton
                            v-if="propsParam.aplyYn === 'Y'"
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="btnAgencyRepSave"
                        >
                            대표자수정
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<script>
import CommonMixin from '@/mixins'
import API from '@/api/biz/bas/prm/basPrmAgencyNewMgmt'
import _ from 'lodash'
export default {
    name: 'BasPrmAgencyNewMgmt',
    mixins: [CommonMixin],

    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },

    data() {
        return {
            objAuth: {},
            repUserDisable: true,
            propsParam: {
                addr: '',
                agencyCd: '',
                agencySubCd: '',
                agencyNm: '',
                aplyYn: '',
                aplyYnNm: '',
                bizConNm: '',
                bizNo: '',
                bizTypNm: '',
                chrgUserEmail: '',
                chrgUserMblTelNo: '',
                chrgUserNm: '',
                chrgUserTelNo: '',
                cntrOrgCd: '',
                cntrOrgNm: '',
                cntrSubCd: '',
                endDt: '',
                faxNo: '',
                orgCd: '',
                orgNm: '',
                mktOrgCd: '',
                mktOrgNm: '',
                mktSubCd: '',
                pagingSeq: '',
                repUserId: '',
                repUserNm: '',
                untClNm: '',
            },

            ds_user: [],
        }
    },
    mounted() {
        console.log(
            '🚀 ~ file: BasPrmAgencyNewMgmtPopUp.vue propsParam ',
            this.propsParam
        )
        if (this.propsParam.aplyYn === 'Y') {
            this.repUserDisable = false
        }
        this.dropDownSetting()
    },
    methods: {
        onEnterKey() {},
        async btnAgencySave() {
            console.log('btnAgencySave============================')
            console.log('btnAgencySave propsParam', this.propsParam)
            API.saveAgencyNewMgmt_(this.propsParam).then((result) => {
                console.log('저장result', result)
                if (result) {
                    // 추가정보 등록/수정
                    // this.saveAddInfo()
                    this.showTcComAlert('정상적으로 처리되었습니다.')

                    this.$parent.onSearch()
                    this.onClose()
                }
                // else {
                //     this.showTcComAlert(result.message)
                // }
            })
        },
        async btnAgencyRepSave() {
            console.log('btnAgencyRepSave============================')
            console.log('btnAgencyRepSave propsParam', this.propsParam)
            API.saveRepAgencyNewMgmt_(this.propsParam).then((result) => {
                console.log('저장result', result)
                if (result) {
                    // 추가정보 등록/수정
                    // this.saveAddInfo()
                    this.showTcComAlert('정상적으로 처리되었습니다.')

                    this.$parent.onSearch()
                    this.onClose()
                }
                // else {
                //     this.showTcComAlert(result.message)
                // }
            })
        },
        onClose() {
            this.activeOpen = false
        },
        async dropDownSetting() {
            console.log('dropDownSetting')

            console.log('key columnName option', this.propsParam)
            let result = await API.getBasPrmAgencyMgmtUserList_(this.propsParam)
            console.log('result', result)
            this.ds_user = result
            // if (this.propsParam.aplyYn === 'N') {
            //     this.propsParam.repUserId = this.propsParam.agencyCd + '00001'
            // }
        },
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentParam', value)
                let val1 = _.clone(value)
                console.log('receive popup param', val1)
                this.propsParam = val1
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>
