<template>
    <div class="content">
        <!-- Tit -->
        <h1>기준정보 Swing I/F관리</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="resetBtn"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>

                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5_1">
                    <TCComDatePicker
                        calType="DP"
                        v-model="arrDate"
                        labelName="처리일자"
                        :eRequired="true"
                        :objAuth="this.objAuth"
                    ></TCComDatePicker>
                </div>
                <div class="formitem div5_1">
                    <!--
                    <v-radio-group
                        row
                        v-model="ds_condition.aplyYn"
                        @change="btnChange"
                    >
                        <v-radio
                            :label="item.commCdValNm"
                            :value="item.commCdVal"
                            v-for="item in ds_apply"
                            v-bind:key="item.commCdVal"
                        ></v-radio>
                    </v-radio-group>
                    -->
                    <TCComRadioBox
                        v-model="ds_condition.aplyYn"
                        :itemList="ds_apply"
                        labelClass="line2"
                        :objAuth="objAuth"
                        @change="btnChange"
                    />
                </div>

                <div v-if="showProd" class="formitem div5_1">
                    <TCComComboBox
                        :itemList="this.ds_wireCl"
                        labelName="유무선구분"
                        v-model="ds_condition.wrcellClCd"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>

                <div v-if="showModel" class="formitem div5_1">
                    <TCComComboBox
                        :itemList="this.ds_mdlCl"
                        labelName="유통여부"
                        v-model="ds_condition.dstrbEqpYn"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>

                <div class="formitem div5_1">
                    <TCComInput
                        v-model="ds_condition.idNm"
                        labelName="코드/명"
                        :objAuth="objAuth"
                        @enterKey="searchBtn"
                    >
                    </TCComInput>
                </div>
            </div>
        </div>
        <TCComTab
            :tab.sync="tabIndex"
            :items="items"
            :itemName="itemName"
            :tabColor="tabColor"
            :textColor="textColor"
            :centered="centered"
            :grow="grow"
            :height="height"
            :hideSlider="hideSlider"
            :sliderColor="sliderColor"
            :vertical="vertical"
            :objAuth="objAuth"
            sliderSize="8"
            @click="tabGridOnChange"
            :cKey="0"
        >
            <template #Template1>
                <TCRealGridHeader
                    id="gridHeader1"
                    ref="gridHeader1"
                    gridTitle="부가상품I/F 목록"
                    :gridObj="gridObj1"
                />
                <TCRealGrid
                    id="grid1"
                    ref="grid1"
                    :fields="view1.fields"
                    :columns="view1.columns"
                    :styles="gridStyle"
                />
                <TCComPaging
                    :totalPage="gridData1.totalPage"
                    :rowCnt="rowCnt"
                    :apiFunc="getSwingIFList"
                    :gridObj="gridObj1"
                    @input="chgRowCnt"
                />
            </template>
            <template #Template2>
                <TCRealGridHeader
                    id="gridHeader2"
                    ref="gridHeader2"
                    gridTitle="상품I/F 목록"
                    :gridObj="gridObj2"
                />
                <TCRealGrid
                    id="grid2"
                    ref="grid2"
                    :fields="view2.fields"
                    :columns="view2.columns"
                    :styles="gridStyle"
                    @hook:mounted="tabGridMounted2"
                />
                <TCComPaging
                    :totalPage="gridData2.totalPage"
                    :rowCnt="rowCnt"
                    :apiFunc="getSwingIFList"
                    :gridObj="gridObj2"
                    @input="chgRowCnt"
                />
            </template>
            <template #Template3>
                <TCRealGridHeader
                    id="gridHeader3"
                    ref="gridHeader3"
                    gridTitle="SKT 코드 I/F 목록"
                    :gridObj="gridObj3"
                />
                <TCRealGrid
                    id="grid3"
                    ref="grid3"
                    :fields="view3.fields"
                    :columns="view3.columns"
                    :styles="gridStyle"
                    @hook:mounted="tabGridMounted3"
                />
                <TCComPaging
                    :totalPage="gridData3.totalPage"
                    :rowCnt="rowCnt"
                    :apiFunc="getSwingIFList"
                    :gridObj="gridObj3"
                    @input="chgRowCnt"
                />
            </template>
        </TCComTab>
        <!-- 상품 팝업 -->
        <BasBcoProdsPopup
            v-if="basBcoProdsShow"
            :parentParam="searchProd_condition"
            :rows="resultProdsRows"
            :dialogShow.sync="basBcoProdsShow"
            @confirm="onProdsReturnData"
        />
        <BasBcoOutDealsPopup
            v-if="showBcoOutDeals"
            :parentParam="searchOutDealParam"
            :rows="resultOutDealRows"
            :dialogShow.sync="showBcoOutDeals"
            @confirm="onOutDealReturnData"
        />
        <BasPdmProdBrwsMgmtPopup
            v-if="localDialogShow === true"
            ref="popup"
            :dialogShow.sync="localDialogShow"
            :parentParam="searchPopParam"
            @confirm="onbasPdmProdBrwsMgmtPopupReturnData"
        />
    </div>
</template>

<style>
/* @import '@/node_modules/realgrid/dist/realgrid-style.css'; */
</style>

<script>
import { CommonGrid } from '@/utils'
import CommonMsg from '@/utils/CommonMsg'
import CommonMixin from '@/mixins'
import moment from 'moment'
// import { M_DATA } from '@/views/biz/bas/pdm/gridData'
import {
    PROD_CODE_GRID_HEADER,
    MDL_DMG_GRID_HEADER,
    SKT_ID_GRID_HEADER,
} from '@/const/grid/bas/cdm/basCdmStrdIfMgmtHeader'
import basCdmAPI from '@/api/biz/bas/cdm/basCdmStrdIfMgmt'
//====================상품팝업====================

import BasPdmProdBrwsMgmtPopup from '@/views/biz/bas/pdm/BasPdmProdBrwsMgmtPopup'

import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'

import {
    BasPdmProdBrwsMgmtParam,
    BasProdMgmtDis,
} from '@/api/biz/bas/pdm/basPdmProdBrwsMgmtParam'

//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'

//====================//상품팝업==================
import _ from 'lodash'

export default {
    name: 'BasCdmStrdIfMgmt',
    mixins: [CommonMixin],
    components: {
        BasPdmProdBrwsMgmtPopup,
        BasBcoProdsPopup,
        BasBcoOutDealsPopup,
    },
    data() {
        return {
            gridStyle: {
                height: '400px',
            },
            // TAB - 공통
            tabIndex: 0,
            //items: ['Template1', 'Template2', 'Template3'],
            //itemName: ['상품코드', '모델단말기', 'SKT ID'],
            items: ['Template1', 'Template2'],
            itemName: ['부가상품I/F', '상품I/F'],
            tabColor: '',
            textColor: '',
            centered: false,
            grow: false,
            height: '',
            sliderColor: '',
            hideSlider: false,
            vertical: false,
            activePage: 1, // 현재 페이지
            toggleActive: false,
            objAuth: {},

            // tab별 조회 조건 show
            showProd: false,
            showModel: false,

            // grid tab1 - 상품코드

            view1: PROD_CODE_GRID_HEADER,
            list1: [],

            gridData1: {},
            gridObj1: {},
            gridHeaderObj1: {},

            // grid tab2 - 모델단말기

            view2: MDL_DMG_GRID_HEADER,
            list2: [],

            gridData2: {},
            gridObj2: {},
            gridHeaderObj2: {},

            // grid tab3 - SKT ID

            view3: SKT_ID_GRID_HEADER,
            list3: [],

            gridData3: {},
            gridObj3: {},
            gridHeaderObj3: {},

            // paging
            rowCnt: 15,

            // 반영여부
            ds_apply: [
                {
                    commCdVal: 'N',
                    commCdValNm: '미반영',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: '반영',
                },
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
            ],
            // 유무선구분
            ds_wireCl: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '무선',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '유선',
                },
            ],
            // 유통구분
            ds_mdlCl: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: '유통',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'OEM',
                },
                {
                    commCdVal: 'O',
                    commCdValNm: 'OMD',
                },
            ],

            arrDate: [
                moment(new Date()).format('YYYY-MM-01'),
                moment(new Date()).format('YYYY-MM-DD'),
            ],

            // 조회조건
            ds_condition: {
                svcClCd: '1', // 상품구분코드
                staDt: '', // 조회기간(시작)
                endDt: '', // 조회기간(끝)
                dstrbEqpYn: '', // 유통단말기여부
                aplyYn: 'N', // 반영여부
                wrcellClCd: '', // 유무선구분
                idNm: '', // 상품코드/명
                // editIdNm: '',
            },

            // 저장조건
            saveParams: {},
            ds_list: [],

            // ===== 상품 팝업 관련 =====
            localDialogShow: false,

            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '2X', // 거래처그룹
                dealcoClCd1: '20', // 거래처구분
            },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            searchProdForm: {
                prodClCd: '1', //상품구분
                sktOperYn: 'Y', //skt운영여부
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
            },
            resultProdsRows: [],
            //====================//상품팝업관련==================
            searchPopParam: {
                prod_cd: '',
                cudFlag: '',
                rgst_cl: '',
                omd_cl: '',
                omd_rgst_cl: '',
            },
            forms: new BasPdmProdBrwsMgmtParam(),
            basProdMgmtDis: new BasProdMgmtDis(),
        }
    },

    mounted() {
        //체크바
        // this.$refs.grid1.gridView.setCheckBar({
        //     visible: true,
        // })
        //console.log('mounted.....')
        this.gridObj1 = this.$refs.grid1
        this.gridHeaderObj1 = this.$refs.gridHeader1
        this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj1.setGridState(true, false, false, false)
        this.gridObj1.gridView.columnByName('seq').visible = false // 번호

        this.gridObj1.gridView.columnByName('svcProdCd').visible = false //상품상세구분코드
        this.gridObj1.gridView.columnByName('exist').visible = false //신규수정코드
        this.gridObj1.gridView.columnByName('wrcellClCd').visible = false //유무선여부
        //console.log('mounted completed...!')
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData1 = this.gridSetData()
            this.gridObj1.setGridState()
            //this.gridObj1.gridView.setRowIndicator({ visible: true })

            this.gridData2 = this.gridSetData()
            this.gridObj2.setGridState()
            this.gridObj2.gridView.setRowIndicator({ visible: true })

            this.gridData3 = this.gridSetData()
            this.gridObj3.setGridState()
            this.gridObj3.gridView.setRowIndicator({ visible: true })
        },

        // 두 번째 탭 클릭 시
        tabGridMounted2() {
            this.gridObj2 = this.$refs.grid2
            this.gridHeaderObj2 = this.$refs.gridHeader2
            this.gridObj2.setGridState(true, false, false, false)

            // Hide some grid
            this.gridObj2.gridView.columnByName('seq').visible = false // 번호
            this.gridObj2.gridView.columnByName('rgstClCd').visible = false // 등록구분코드
            this.gridObj2.gridView.columnByName('eqpClCd').visible = false // 단말기구분코드
            this.gridObj2.gridView.columnByName('prodCl').visible = false //상품상세구분코드
            this.gridObj2.gridView.columnByName('exist').visible = false //신규수정코드
            this.gridObj2.gridView.columnByName('linkColorCd').visible = false //연결색상코드
            //this.gridObj2.gridView.columnByName('wrcellclNm').visible = false //유무선여부

            this.gridObj2.gridView.onCellDblClicked = (grid, clickData) => {
                if (undefined == clickData.dataRow) {
                    return
                }
                console.log('this grid => ', grid)
                console.log('dblClick => ', clickData)

                let prodCd = grid.getValue(clickData.dataRow, 'prodCd')
                // let rgstClCd = grid.getValue(clickData.dataRow, 'rgstClCd')
                // let eqpClCd = grid.getValue(clickData.dataRow, 'eqpClCd')

                // console.log(
                //     `? (1, 2, 3) : ( ${prodCd}, ${rgstClCd}, ${eqpClCd} )`
                // )

                this.searchPopParam.prod_cd = prodCd
                /*
                this.searchPopParam.cudFlag = 'U'
                this.searchPopParam.rgst_cl = rgstClCd

                if ('03' == eqpClCd || '04' == eqpClCd) {
                    this.searchPopParam.omd_cl = 'Y'
                    this.searchPopParam.omd_rgst_cl = 'N'
                } else {
                    this.searchPopParam.omd_cl = ''
                    this.searchPopParam.omd_rgst_cl = ''
                }
*/
                this.localDialogShow = true
            }
        },
        // 세 번째 탭 클릭 시
        tabGridMounted3() {
            this.gridObj3 = this.$refs.grid3
            this.gridHeaderObj3 = this.$refs.gridHeader3
            this.gridObj3.setGridState(true, false, false, false)
        },

        // Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },

        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
            this.searchBtn()
        },

        //조회 버튼 이벤트
        searchBtn() {
            console.log('searchBtn clicked...')
            this.getSwingIFList(1)
        },

        // API 호출
        getSwingIFList: function (pageNum) {
            console.log('chk - arrDate : ', this.arrDate)
            this.ds_condition.staDt = this.removeHyphen(this.arrDate[0])
            this.ds_condition.endDt = this.removeHyphen(this.arrDate[1])

            //alert(this.ds_condition.svcClCd)

            let reqParam = this.ds_condition
            reqParam.pageNum = pageNum
            reqParam.pageSize = this.rowCnt
            console.log('reqParam : ', reqParam)

            basCdmAPI.getSwingIFList(reqParam).then((result) => {
                if (_.isEmpty(result.gridList)) {
                    this.showTcComAlert('조회된 데이터가 없습니다')
                    //return
                }
                // console.log(`Length : ${result.gridList.length}`)
                // // INDEX 셋팅
                // if (result.length > 0) {
                //     for (
                //         let index = 0;
                //         index < result.gridList.length;
                //         index++
                //     ) {
                //         result[index].SEQ = index + 1
                //     }
                // } else if (
                //     result.gridList.length === 0 ||
                //     result.gridList.length === undefined
                // ) {
                //     alert(
                //         '조회된 데이터가 없습니다!!\n(이전 데이터 그리드 그대로입니다)'
                //     )
                //     return
                // }
                console.log('After index setting => result : ', result)

                this.ds_list = result.gridList
                console.log('ds_list => ', this.ds_list)
                let opt = {}
                opt.sort = 'ASC'
                if (this.tabIndex === 0) {
                    console.log('grid1')
                    this.gridObj1.setRows(result.gridList)
                    this.gridObj1.setGridIndicator(result.pagingDto, opt)
                    //this.gridObj1.setGridIndicator(result.pagingDto)
                    this.gridData1 = this.gridSetData()
                    this.gridData1.totalPage = result.pagingDto.totalPageCnt
                    // Grid Row 가져올 때 총 건 수 setting
                    this.gridHeaderObj1.setPageCount(result.paigingDto)
                } else if (this.tabIndex === 1) {
                    console.log('grid2')
                    this.gridObj2.setRows(result.gridList)
                    this.gridObj2.setGridIndicator(result.pagingDto, opt)
                    this.gridData2 = this.gridSetData()
                    this.gridData2.totalPage = result.pagingDto.totalPageCnt
                    // Grid Row 가져올 때 총 건 수 setting
                    this.gridHeaderObj2.setPageCount(result.paigingDto)
                } else if (this.tabIndex === 2) {
                    console.log('grid3')
                    this.gridObj3.setRows(result.gridList)
                    this.gridObj3.setGridIndicator(result.pagingDto)
                    this.gridData3 = this.gridSetData()
                    this.gridData3.totalPage = result.pagingDto.totalPageCnt
                    // Grid Row 가져올 때 총 건 수 setting
                    this.gridHeaderObj3.setPageCount(result.paigingDto)
                }

                /****************** Paging **********************/
                // //Paging관련 조회시 생성
                // //setGirdPaging(Grid Class)
                // this.gridData = this.GridSetData() //초기화
                // this.gridData = this.gridObj.setGirdPaging(this.gridData)
                // //Grid Row 가져올때 페이지정보 Setting
                // this.gridHeaderObj.setPageCount(this.gridData)
                console.log('조회완료')
            })
        },

        //저장 버튼 이벤트
        saveBtn: function () {
            console.log('saveBtn clicked...')
            this.f_save()
        },

        f_save: function () {
            let svcClCd = this.tabIndex === 0 ? 1 : ''

            console.log('svcClCd : ', svcClCd)

            if (svcClCd === 1) {
                // if (!confirm('부가 상품 인터페이스 정보를 일괄 반영합니다.')) {
                //     return

                let saveList = this.ds_list
                console.log('saveList ==> ', saveList)

                if (saveList.length === 0 || saveList === undefined) {
                    this.showTcComAlert(
                        '저장할 데이터가 없습니다!! <br>조회 후 저장버튼 클릭하세요'
                    )
                } else {
                    basCdmAPI.saveIfTable(saveList).then(() => {
                        console.log('saveIfTable start...')
                    })
                }
            } else {
                console.log('svcClCd ==> ', this.tabIndex + 1)
                this.ds_list = []
                console.log('ds_list 초기화... ', this.ds_list)
                this.showTcComAlert('부가상품I/F 탭에서만 저장가능합니다.')
            }
        },

        //초기화 버튼 이벤트
        resetBtn: function () {
            console.log('resetBtn clicked!')
            let gridObj
            if (this.tabIndex === 0) gridObj = this.gridObj1
            else if (this.tabIndex === 1) gridObj = this.gridObj2
            else gridObj = this.gridObj3

            gridObj.gridInit()
            this.ds_condition.aplyYn = 'N'
            this.ds_condition.dstrbEqpYn = ''
            this.ds_condition.wrcellClCd = ''
            this.ds_condition.idNm = ''
            this.arrDate = [
                moment(new Date()).format('YYYY-MM-01'),
                moment(new Date()).format('YYYY-MM-DD'),
            ]
        },

        btnChange: function () {
            console.log('aplyYn : ', this.ds_condition.aplyYn)
        },

        // TAB - 변경한 탭 인덱스에 맞는 그리드 show
        tabGridOnChange(index) {
            //alert('=============>' + index)
            if (index === 0) {
                this.tabIndex = 0
                this.gridObj1 = this.$refs.grid1
                this.gridHeaderObj1 = this.$refs.gridHeader1
                this.gridObj1.setGridState(true, false, false, false)
                this.ds_condition.svcClCd = '1'
                this.showProd = true
                this.showModel = false
            } else if (index === 1) {
                //alert('this.ds_condition.svcClCd' + this.ds_condition.svcClCd)
                this.tabIndex = 1
                /*
                //
                this.gridObj2 = this.$refs.grid2
                this.gridHeaderObj2 = this.$refs.gridHeader2
                this.gridObj2.setGridState(true, false, false, false)
                */
                this.ds_condition.svcClCd = '2'

                this.showModel = true
                this.showProd = false
            } else if (index === 2) {
                this.tabIndex = 2
                this.gridObj3 = this.$refs.grid3
                this.gridHeaderObj3 = this.$refs.gridHeader3
                this.gridObj3.setGridState(true, false, false, false)
                this.ds_condition.svcClCd = '3'
                this.showModel = false
                this.showProd = false
            }
            console.log('tab index : ', this.tabIndex)
            console.log('svcClCd : ', this.ds_condition.svcClCd)
        },

        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            var date = new Date()
            var year = date.getFullYear()
            var month = ('0' + (1 + date.getMonth())).slice(-2)
            var day = ('0' + date.getDate()).slice(-2)

            return year + '-' + month + '-' + day
        },

        // 문자열 하이픈 제거
        removeHyphen: function (val) {
            const regExp = /[^0-9]/g
            const retVal = val.replace(regExp, '')
            return retVal
        },

        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                console.log('getProdsList : ', res)
                if (res === undefined) return
                if (res.length === 1) {
                    this.forms.repProdCd = _.get(res[0], 'prodCd')
                    this.forms.repProdNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.forms.repProdCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.forms.repProdCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.forms.prodNm = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.forms.repProdCd = _.get(retrunData, 'prodCd')
            this.forms.repProdNm = _.get(retrunData, 'prodNm')
        },
        //상품등록 수정 후 다시조회.
        onbasPdmProdBrwsMgmtPopupReturnData(retrunData) {
            console.log(retrunData)
            this.searchBtn()
        },
        //===================== //상품팝업관련 methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    console.log('getOutDealList then : ', res)
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.forms.mfactCd = _.get(res[0], 'dealcoCd')
                        this.forms.mfactNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            if (!_.isEmpty(this.forms.mfactCd)) {
                this.getOutDealList()
            } else {
                this.showBcoOutDeals = true
            }
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.forms.mfactCd)) {
                this.showTcComAlert('외부거래처명을 입력해주세요.')
                return
            }
            // 외부거래처 정보 조회
            this.getOutDealList()
        },
        // 외부거래처 TextField Input 이벤트 처리
        onOutDealInput() {
            // 입력되는 값이 있으면 외부거래처 코드 초기화
            this.forms.mfactNm = ''
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.forms.mfactCd = _.get(retrunData, 'dealcoCd')
            this.forms.mfactNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
    },
}
</script>
