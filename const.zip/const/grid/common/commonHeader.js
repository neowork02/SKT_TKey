import { ValueType } from 'realgrid'

export const fileAddHeader = {
    fields: [
        {
            fieldName: 'name',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'size',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'screenId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'docId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'filePathNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fileType',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'name',
            fieldName: 'name',
            type: 'data',
            width: 200,
            header: {
                text: '파일명',
            },
            renderer: {
                type: 'link',
                // urlCallback(grid, cell) {
                //     console.log('cell: ', cell)
                //     return false
                // },
            },
            styleName: 'left-column',
        },
        {
            name: 'size',
            fieldName: 'size',
            type: 'data',
            width: 110,
            header: {
                text: '크기',
            },
        },
    ],
}
