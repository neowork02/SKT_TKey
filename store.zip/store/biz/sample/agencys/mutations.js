export default {
    SET_AGENCY_TYP_LIST(state, payload) {
        state._agencyTypList = payload
    },
    SET_AGENCY_PTN_LIST(state, payload) {
        state._agencyPtnList = payload
    },
    SET_AGENCY_LIST(state, payload) {
        state._agencyList = payload
    },
    SET_SEARCH_PARAM(state, payload) {
        state._searchParam = payload
    },
    SET_SEARCH_DATE_MODEL(state, payload) {
        state._searchDateModel = payload
    },
}
