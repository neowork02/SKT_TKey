<!-----------------------------------------------
 * 업무그룹명: 타사SMS전송 동의서
 * 서브업무명: 타사SMS전송 동의서
 * 설명: 유통대리점 타사SMS 사용 관리
 * 작성자: P140530
 * 작성일: 2022.11.25
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="700px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">타사 SMS전송 동의서 등록/수정</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInputSearchText
                                    v-model="reqParam.agencyNm"
                                    :codeVal.sync="reqParam.agencyCd"
                                    labelName="대리점"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    :disabled="dataInfoDisabled01"
                                    @enterKey="onAgencyEnterKey"
                                    @appendIconClick="onAgencyIconClick"
                                    @input="onAgencyInput"
                                />
                                <BasBcoAgencysPopup
                                    v-if="showBcoAgencys"
                                    :parentParam="searchParam"
                                    :rows="resultAgencyRows"
                                    :dialogShow.sync="showBcoAgencys"
                                    @confirm="onAgencyReturnData"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    labelName="동의여부"
                                    :eRequired="true"
                                    v-model="reqParam.agreeYn"
                                    :itemList="agreeYnCl"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComCheckBox
                                    labelName="사업자등록증 수령여부"
                                    v-model="reqParam.chkBizLicence"
                                    itemText="text"
                                    itemValue="value"
                                    :objAuth="objAuth"
                                    :itemList="chkBizLicenceYnCl"
                                ></TCComCheckBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="분리과금번호"
                                    :objAuth="objAuth"
                                    v-model="reqParam.spbillNum"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    labelName="비고"
                                    :rows="5"
                                    v-model="reqParam.rmks"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="save"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import BasCmuOthrCoSmsTrmsAcDocApi from '@/api/biz/bas/cmu/basCmuOthrCoSmsTrmsAcDoc'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'
import { CommonMsg } from '@/utils'

//====================대리점팝업====================
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
//====================//대리점팝업====================

export default {
    name: 'Home',
    mixins: [CommonMixin],
    components: { BasBcoAgencysPopup },
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        agencyInfo: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    computed: {
        setDate: {
            get() {
                return this.reqParam.opDt
            },
            set(val) {
                this.reqParam.opDt = val
                return val
            },
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    data() {
        return {
            objAuth: {},
            rowCnt: 15,
            searchForms: {},
            reqParam: {
                agencyNm: '', // 대리점명
                agencyCd: '', // 대리점코드
                seq: '', // seq
                agreeYn: '', // 동의여부
                chkBizLicence: [], // 사업자등록증수령여부
                spbillNum: '', // 분리과금번호
                rmks: '', // 비고
            },

            // 동의여부
            agreeYnCl: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '동의',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '동의안함',
                },
            ],

            // 사업자등록증 수령여부
            chkBizLicenceYnCl: [
                {
                    value: 'Y',
                    text: '',
                },
            ],

            // 기존데이터
            chkUpdateYn: '',
            dataInfoDisabled01: false, // 활성화여부

            // 대리점등록시중복체크
            chkAgency: {},

            //====================//내부조직팝업(권한)팝업관련==================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            searchParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
                searchDate: '', // 조회기준일
            },
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
        }
    },
    mounted() {
        this.initParam()
        this.setInfoData()
    },
    methods: {
        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                agencyNm: '', // 대리점명
                agencyCd: '', // 대리점코드
                seq: '', // seq
                agreeYn: '', // 동의여부
                chkBizLicence: [], // 사업자등록증수령여부
                spbillNum: '', // 분리과금번호
                rmks: '', // 비고
            }
        },
        // 조회시 데이터 set
        setInfoData() {
            if (!_.isEmpty(this.agencyInfo)) {
                this.chkUpdateYn = this.agencyInfo.chkUpdateYn
                // 기존데이터
                if ('Y' == this.chkUpdateYn) {
                    this.dataInfoDisabled01 = true // 대리점비활성화

                    this.reqParam.agencyNm = this.agencyInfo.agencyNm
                    this.reqParam.agencyCd = this.agencyInfo.agencyCd
                    this.reqParam.seq = this.agencyInfo.seq
                    this.reqParam.agreeYn = this.agencyInfo.agreeYn
                    this.reqParam.spbillNum = this.agencyInfo.spbillNum
                    this.reqParam.rmks = this.agencyInfo.rmks
                    this.reqParam.chkBizLicence.push(
                        this.agencyInfo.chkBizLicence
                    )
                }
            }
        },
        /* 타사 SMS전송 동의서 저장 */
        async save() {
            // 파라미터 세팅
            this.setParam()
            if (!(await this.fCheckCondition())) return

            await BasCmuOthrCoSmsTrmsAcDocApi.saveBasCmuOthrCoSmsTrmsAcDoc(
                this.searchForms
            ).then(() => {
                this.$emit('confirm', true)
                this.activeOpen = false
            })
        },
        async fCheckCondition() {
            if (_.isEmpty(this.reqParam.agencyCd)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '대리점코드')
                )
                return false
            }
            if (_.isEmpty(this.reqParam.agreeYn)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '동의여부')
                )
                return false
            }

            if ('Y' != this.chkUpdateYn) {
                await this.fchkAgency()
                if (this.chkAgency > 0) {
                    // 대리점등록시중복체크
                    this.showTcComAlert(
                        CommonMsg.getMessage('MSG_00057', '해당 대리점이')
                    )
                    return false
                }
            }
            return true
        },
        // 대리점등록시중복체크
        async fchkAgency() {
            await BasCmuOthrCoSmsTrmsAcDocApi.getChkAgencyBasCmuOthrCoSmsTrmsAcDoc(
                this.searchForms
            ).then((res) => {
                this.chkAgency = res
            })
        },
        // 파라미터 세팅
        setParam() {
            this.searchForms.chkUpdateYn = this.chkUpdateYn
            this.searchForms.agencyCd = this.reqParam.agencyCd
            this.searchForms.seq = this.reqParam.seq
            this.searchForms.agreeYn = this.reqParam.agreeYn
            this.searchForms.spbillNum = this.reqParam.spbillNum
            this.searchForms.rmks = this.reqParam.rmks
            this.searchForms.chkBizLicence =
                this.reqParam.chkBizLicence[
                    this.reqParam.chkBizLicence.length - 1
                ]
        },
        onReturnReSearch(retVal) {
            if (retVal) {
                this.$emit('confirm', true)
                this.activeOpen = false
            }
        },
        closeBtn() {
            this.activeOpen = false
        },
        //===================== 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getAgencyList() {
            this.searchParam.agencyCd = this.reqParam.agencyCd
            this.searchParam.agencyNm = this.reqParam.agencyNm
            this.searchParam.searchDate = moment(new Date()).format(
                'YYYY-MM-DD'
            )
            basBcoAgencysApi.getAgencyList(this.searchParam).then((res) => {
                // console.log('getAgencyList then : ', res)
                // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.agencyCd = _.get(res[0], 'agencyCd')
                    this.reqParam.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultAgencyRows = res
                    this.showBcoAgencys = true
                }
            })
        },

        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAgencyList()
            } else {
                this.showBcoAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onAgencyEnterKey() {
            this.resultAgencyRows = []
            this.getAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.reqParam.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(retrunData) {
            this.reqParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.reqParam.agencyNm = _.get(retrunData, 'agencyNm')
        },
        //===================== //대리점팝업관련 methods ================================
    },
}
</script>
