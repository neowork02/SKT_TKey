<template>
    <div class="content">
        <h1>월마감</h1>
        <ul class="btn_area top">
            <li class="left">
                <div class="multiForm">
                    <TCComComboBox
                        labelName="마감구분"
                        :objAuth="this.objAuth"
                        :itemList="itemListClCd"
                        :addBlankItem="true"
                        blankItemText=""
                        blankItemValue=""
                        v-model="searchFormData.searchCloseBisMthClCd"
                    ></TCComComboBox>
                </div>
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="closeAccMcl('close')"
                    >마감</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="closeAccMcl('cancel')"
                    >마감취소</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="screenInit"
                    :objAuth="objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="loadData"
                    :objAuth="objAuth"
                    >조회</TCComButton
                >
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="M"
                        v-model="searchFormData.searchClsYm_"
                        labelName="마감월"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4"></div>
                <div class="formitem div4"></div>
                <div class="formitem div4"></div>
            </div>
        </div>
        <!-- //Search_div -->

        <!-- SubTit -->
        <!-- <div class="stitHead">
            <h4 class="subTit">
                월마감 리스트
                <span class="stitTxtL"
                    >(총 <span class="color-red">{{ list.length }}</span
                    >건)</span
                >
            </h4>
            <span class="stitBtnRef">
                <button type="button" class="btn_noline btn_ty04">
                    <span class="ico_exeldown" @click="excelDown()"
                        >엑셀다운로드</span
                    >
                </button>
            </span>
        </div> -->
        <!-- // SubTit -->

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="월마감 리스트"
                :gridObj="this.gridObj"
                :isExceldown="true"
                @excelDownBtn="downloadMclsList"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :styles="gridStyle"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div>

        <!-- gridWrap -->
        <!-- <div class="gridWrap">
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div> -->
        <!-- //gridWrap -->
    </div>
</template>

<script>
import mclApi from '@/api/biz/acc/mcl'
import moment from 'moment'
import _ from 'lodash'
import { GRID_HEADER } from '@/const/grid/acc/mcl/accMclMclsMgmtGrid'
import { CommonUtil } from '@/utils'
import CommonMixin from '@/mixins'

export default {
    name: 'Home',

    mixins: [CommonMixin],

    data() {
        return {
            gridObj: {},
            gridHeaderObj: {},

            view: GRID_HEADER,
            objAuth: {},
            list: [],
            listCount: 0,
            paramJson: {},
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            searchFormData: {
                searchClsYm_: moment(new Date()).format('YYYY-MM'),
                searchClsYm: moment(new Date()).format('YYYYMM'),
                searchCloseBisMthClCd: '',
                searchErpFixYn: '',
                closeType: '',
                searchCoClOrgCd: '',
                searchOrgCd: '',
                checkedRows: [],
            },
            itemListClCd: [
                {
                    commCdVal: '01',
                    commCdValNm: '월마감',
                },
                {
                    commCdVal: '03',
                    commCdValNm: '회계마감',
                },
            ],
        }
    },
    mounted() {
        this.gridInit()
        //체크바
        this.$refs.grid1.gridView.setCheckBar({
            visible: true,
        })

        //편집가능
        this.$refs.grid1.gridView.setEditOptions({
            editable: true,
            updatable: true,
        })

        //목록출력하기
        this.$refs.grid1.setRows(this.list)
        this.$refs.grid1.setGridState(false, true, true, false)

        //  회사구분조직코드, 소속조직코드
        this.searchFormData.searchCoClOrgCd = this.orgInfo.orgCdLvl0
        this.searchFormData.searchOrgCd = this.orgInfo.orgCd
    },
    watch: {
        'searchFormData.searchClsYm_'(newVal) {
            this.searchFormData.searchClsYm = newVal
            if (!_.isEmpty(newVal)) {
                this.searchFormData.searchClsYm = newVal.replace(/-/g, '')
            }
        },
    },
    methods: {
        // 그리드 초기화
        gridInit: function () {
            this.gridObj = this.$refs.grid1
            this.gridHeaderObj = this.$refs.gridHeader1
        },
        // 화면초기화
        screenInit: function () {
            CommonUtil.clearPage(this, 'searchFormData', this.gridObj)

            // 회사구분조직코드, 소속조직코드
            this.searchFormData.searchCoClOrgCd = this.orgInfo.orgCdLvl0
            this.searchFormData.searchOrgCd = this.orgInfo.orgCd
        },
        //  엑셀다운로드
        downloadMclsList: function () {
            mclApi.downloadMclsList(this.searchFormData)
        },
        setGetParamJson: function () {
            this.paramJson = _.cloneDeep(this.searchFormData)

            // get방식으로 파라미터 넘길 때 오류로 인해 아래 제거함
            delete this.paramJson['searchClsYm_']
            delete this.paramJson['checkedRows']

            return this.paramJson
        },
        loadData: function () {
            if (_.isEmpty(this.searchFormData.searchClsYm)) {
                this.showTcComAlert('마감월을 선택해 주세요.')
                return
            }

            // 조회시 마감구분 Clear
            this.searchFormData.searchCloseBisMthClCd = ''

            mclApi
                .getAccMclMclsMgmtList(this.setGetParamJson())
                .then((resultData) => {
                    this.list = resultData
                    this.$refs.grid1.setRows(this.list)
                })
        },
        closeAccMcl: function (closeType) {
            var checkedRows = this.$refs.grid1.gridView.getCheckedRows(false)
            if (checkedRows == null || checkedRows.length == 0) {
                this.showTcComAlert('먼저 목록을 선택해 주세요.')
                return
            }

            // 마감일 경우 validate 체크
            if (closeType == 'close') {
                if (!this.validateCheckClose(checkedRows)) {
                    return
                }
            }
            // 마감취소일 경우 validate 체크
            else if (closeType == 'cancel') {
                if (!this.validateCheckCancel(checkedRows)) {
                    return
                }
            }

            this.searchFormData.closeType = closeType
            this.searchFormData.checkedRows = []
            var rowData = {}
            for (var i = 0; i < checkedRows.length; i++) {
                rowData = this.$refs.grid1.gridView.getValues(checkedRows[i])
                this.searchFormData.checkedRows.push({
                    clsYm: this.searchFormData.searchClsYm,
                    bizChrgOrgCd: rowData.bizChrgOrgCd,
                    closeBisMthClCd: rowData.closeBisMthClCd,
                    closeStCd: rowData.closeStCd,
                    closeYnCd: rowData.closeYnCd,
                    rmks: rowData.rmks,
                    lvOrgCd: this.searchFormData.searchCoClOrgCd,
                })
            }

            // 마감/마감취소 처리로직 실행하기
            mclApi.closeAccMclMclsMgmt(this.searchFormData).then((res) => {
                if (res) {
                    if (closeType == 'close') {
                        this.showTcComAlert('마감이 완료되었습니다.')
                    } else if (closeType == 'cancel') {
                        this.showTcComAlert('마감취소 완료되었습니다.')
                    }

                    // 목록 재조회
                    this.loadData()
                }
            })
        },
        validateCheckClose: function (checkedRows) {
            if (this.searchFormData.searchCloseBisMthClCd == '') {
                this.showTcComAlert('마감구분을 선택하십시오.')
                return false
            }

            if (this.searchFormData.searchClsYm == '') {
                this.showTcComAlert('마감월을 선택하십시오.')
                return false
            }

            var isResult = true
            for (var i = 0; i < checkedRows.length; i++) {
                var row = this.$refs.grid1.gridView.getValues(checkedRows[i])
                // var checkCloseBisMthClcd =
                //     Number(this.searchFormData.searchCloseBisMthClCd) - 2

                // 마감상태인지 체크
                if (
                    row['closeBisMthClCd'] >=
                    this.searchFormData.searchCloseBisMthClCd
                ) {
                    this.showTcComAlert(
                        row['bizChrgOrgNm'] + '는 마감상태입니다.'
                    )
                    isResult = false
                    break
                }

                // 선택한 마감월과 최종마감월이 다른지 체크
                if (
                    row['lastClsYm'] == this.searchFormData.searchClsYm &&
                    row['closeBisMthClCd'] >=
                        this.searchFormData.searchCloseBisMthClCd
                ) {
                    this.showTcComAlert(
                        row['bizChrgOrgNm'] +
                            '의 최종마감월이 마감월과 동일합니다.'
                    )
                    isResult = false
                    break
                }

                // 선택한 마감월보다 최종마감월이 큰지 체크
                if (this.orgInfo.orgCdLvl0 == 'O00000') {
                    if (row['lastClsYm'] > this.searchFormData.searchClsYm) {
                        this.showTcComAlert(
                            row['bizChrgOrgNm'] +
                                '의 최종마감월이 마감월보다 큽니다.'
                        )
                        isResult = false
                        break
                    }
                }
            }

            return isResult
        },
        validateCheckCancel: function (checkedRows) {
            var isResult = true

            for (var i = 0; i < checkedRows.length; i++) {
                var row = this.$refs.grid1.gridView.getValues(checkedRows[i])
                console.log('row: ' + row)

                // 선택한 마감월과 최종마감월이 다른지 체크
                //  PS&M
                // 마감상태 여부 체크
                if (row['closeYnCd'] != '02') {
                    this.showTcComAlert(
                        row['bizChrgOrgNm'] + '이 마감상태가 아닙니다.'
                    )
                    isResult = false
                    break
                }

                if (this.orgInfo.orgCdLvl0 == 'O00000') {
                    if (row['lastClsYm'] != this.searchFormData.searchClsYm) {
                        this.showTcComAlert(
                            row['bizChrgOrgNm'] +
                                '의 최종마감월이 마감월과 동일하지 않습니다.'
                        )
                        isResult = false
                        break
                    }
                } else {
                    //  유통망대리점. -3개월까지 마감취소 가능
                    var sClsYm = this.searchFormData.searchClsYm.replace(
                        /-/g,
                        ''
                    )
                    if (row['lastClsYmBf3'] > sClsYm) {
                        this.showTcComAlert(
                            '3개월 이전 마감데이터는 취소할 수 없습니다.'
                        )
                        isResult = false
                        break
                    }
                }
            }

            return isResult
        },
    },
}
</script>

<style scoped>
.grid {
    height: 550px;
}
</style>
