import { ValueType } from 'realgrid'

export const GRID_CRDT_HEAD = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'crdtOverYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'exCrdtOverYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chrgrUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealStatus',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expirDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'strdCrdtAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'eachCrdtAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'lastAccAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totCrdtAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'notChagAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toPpayAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'disAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'crdAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'balAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'crdtCfmDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyPrd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'crdtUse',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '60',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '순번',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'crdtOverYn',
            fieldName: 'crdtOverYn',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신초과',
                styleName: 'multi-line-css',
            },
            width: '70',
        },
        {
            name: 'exCrdtOverYn',
            fieldName: 'exCrdtOverYn',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신초과추정',
                showTooltip: false,
            },
            width: '90',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직명',
                showTooltip: false,
            },
            width: '310',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직코드',
                showTooltip: false,
            },
            width: '70',
            visible: false,
        },
        {
            name: 'chrgrUserNm',
            fieldName: 'chrgrUserNm',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업사원',
                showTooltip: false,
            },
            width: '80',
        },
        {
            name: 'dealCoClNm',
            fieldName: 'dealCoClNm',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            width: '80',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            width: '80',
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            editable: false,
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            width: '120',
        },

        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래상태',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'expirDt',
            fieldName: 'expirDt',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '담보만료예정일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            width: '100',
        },
        {
            name: 'strdCrdtAmt',
            fieldName: 'strdCrdtAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '기본여신금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'eachCrdtAmt',
            fieldName: 'eachCrdtAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '특별신용여신금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'lastAccAmt',
            fieldName: 'lastAccAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '판매수수료',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'totCrdtAmt',
            fieldName: 'totCrdtAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '여신금액합계',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'notChagAmt',
            fieldName: 'notChagAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '미수채권금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'toPpayAmt',
            fieldName: 'toPpayAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '선급금',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            width: '120',
        },

        {
            name: 'disAmt',
            fieldName: 'disAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '재고금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'crdAmt',
            fieldName: 'crdAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '여신사용금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'balAmt',
            fieldName: 'balAmt',
            type: 'data',
            styleName: 'right-column',
            editable: false,
            header: {
                text: '여신잔액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'crdtCfmDt',
            fieldName: 'crdtCfmDt',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '특별여신적용일자',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            width: '120',
        },
        {
            name: 'aplyStaDtm',
            fieldName: 'aplyStaDtm',
            visible: false,
            type: 'data',
        },
        {
            name: 'aplyEndDtm',
            fieldName: 'aplyEndDtm',
            visible: false,
            type: 'data',
        },
        {
            name: 'aplyPrd',
            fieldName: 'aplyPrd',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '특별여신적용기간',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'crdtUse',
            fieldName: 'crdtUse',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '특별여신사용비율',
                showTooltip: false,
            },
            width: '120',
        },
    ],
    layout: [
        'rowNum',
        'crdtOverYn',
        'exCrdtOverYn',
        'orgNm',
        //'orgCd',
        'dealSktCd',
        'dealcoCd',
        'dealcoNm',
        'dealCoClNm',
        'chrgrUserNm',
        'dealStatus',
        'expirDt',
        'strdCrdtAmt',
        'eachCrdtAmt',
        'lastAccAmt',
        'totCrdtAmt',
        'notChagAmt',
        'toPpayAmt',
        'disAmt',
        'crdAmt',
        'balAmt',
        'crdtCfmDt',
        'aplyPrd',
        'crdtUse',
    ],
}
