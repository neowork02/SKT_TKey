<template>
    <div>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="del"
                    >삭제</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="copy"
                >
                    복사
                </TCComButton>
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="setup"
                >
                    권한설정
                </TCComButton>
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="searchDtl"
                >
                    수정
                </TCComButton>
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveAdmAuthBtn"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    @click="saveBtn2"
                    >저장</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="소속유형"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        codeId="ZBAS_C_00380"
                        v-model="formSearchParams.attcClCd"
                        :objAuth="objAuth"
                        @change="getUserGrpNm"
                        :filterFunc="filters"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComCheckBox
                        labelName="삭제포함"
                        v-model="delYn"
                        :itemList="[{ commCdVal: 'Y', commCdValNm: '' }]"
                    />
                </div>
                <div class="formitem div4">
                    <!--
                    <TCComComboBox
                        v-model="formSearchParams.userGrpNm"
                        labelName="권한명"
                        :size="150"
                        :maxlength="10"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :eRequired="true"
                        :itemList="this.userGrpNmList1"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                    -->
                    <TCComInput
                        v-model="formSearchParams.userGrpNm"
                        labelName="권한그룹명"
                        :eRequired="true"
                        :size="150"
                        :maxlength="10"
                        :objAuth="this.objAuth"
                        @input="setData"
                        @enterKey="searchBtn"
                    ></TCComInput>
                </div>
                <!--
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.userNm"
                        labelName="사용자명"
                        :size="150"
                        :maxlength="10"
                        :objAuth="this.objAuth"
                        @input="setData"
                    ></TCComInput>
                </div>
                -->
            </div>
            <!--         
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="formSearchParams.orgNm"
                                    labelName="조직명"
                                    :size="150"
                                    :maxlength="10"
                                    :objAuth="this.objAuth"
                                    @input="setData"
                                ></TCComInput>
                            </div>
                        </div>
                 -->
        </div>

        <RgstPopup
            v-if="localDialogShow"
            ref="popup"
            :dialogShow.sync="localDialogShow"
            :dtlData.sync="dtlParam"
        />
        <CopyPopup
            v-if="copyDialogShow"
            ref="popup"
            :dialogShow.sync="copyDialogShow"
            :dtlData.sync="dtlParam"
        />
        <SetupPopup
            v-if="setupDialogShow"
            ref="popup"
            :dialogShow.sync="setupDialogShow"
            :dtlData.sync="dtlParam"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/authMgmt/helpers'
import { msgTxt } from '@/const/msg.Properties.js'
import CommonMixin from '@/mixins'

import RgstPopup from './PopupContainer.vue'
import CopyPopup from './PopupContainer.vue'
import SetupPopup from './PopupContainer1.vue'

import _ from 'lodash'

export default {
    mixins: [CommonMixin],
    components: {
        RgstPopup,
        CopyPopup,
        SetupPopup,
    },
    async created() {
        await this.initControls()
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            delYn: [],
            formSearchParams: {
                userGrpNm: '', // 권한그룹명
                delYn: '', //삭제여부
                userNm: '', //유저명
                orgNm: '', //조직명
            },
            localDialogShow: false,
            copyDialogShow: false,
            setupDialogShow: false,
            dtlParam: {
                delYn: '',
                insDtm: '',
                insUserId: '',
                insUserNm: '',
                userGrpNm: '',
                modDtm: '',
                modUserId: '',
                modUserNm: '',
                updCnt: '',
                useYn: '',
                userGrpCd: '',
                userGrpDesc: '',
                lvOrgCd: '',
                authTypCd: '',
            },
        }
    },
    async mounted() {
        await this.initData()
        //화면초기 로딩시 바로 검색
        await this.searchBtn()
    },
    computed: {
        ...serviceComputed,

        saveDone1: {
            get() {
                return this.saveDoneA && this.saveDoneB
            },
        },
        saveAdmAuthDone1: {
            get() {
                return this.saveAdmAuthDone
            },
        },
        userGrpNmList1: {
            get() {
                return this.userGrpNmList
            },
        },
    },
    methods: {
        ...serviceMethods,
        async initControls() {},
        async initData() {
            this.formSearchParams.attcClCd = '' //소속구분
            this.formSearchParams.userGrpNm = '' //권한명
            this.formSearchParams.userNm = '' //
            this.formSearchParams.orgNm = '' //
            this.delYn = [] //삭제여부

            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.initAuthMgmt()
            await this.getUserGrpNmList()
        },
        async getUserGrpNmList() {
            await this.getUserGrpNmList_({ attcClCd: 'ALL' })
        },
        getUserGrpNm(attcClCd) {
            if (!_.isEmpty(attcClCd)) {
                this.getUserGrpNmList_({ attcClCd: attcClCd })
            }
        },
        filters(items) {
            if (_.isEqual(this.orgInfo.orgCdLvl0, 'O00000')) {
                return items.filter(
                    (items) =>
                        !_.isEqual(items['commCdVal'], 'D') &&
                        !_.isEqual(items['commCdVal'], 'P')
                )
            }
        },
        async setData() {
            let params = {}
            if (!_.isEmpty(this.formSearchParams.userNm)) {
                params['userNm'] = this.formSearchParams.userNm
            }
            if (!_.isEmpty(this.formSearchParams.orgNm)) {
                params['orgNm'] = this.formSearchParams.orgNm
            }
            await this.defaultAssign_({
                key: 'searchParams',
                value: params,
            })
        },
        async initAuthMgmt() {
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
            await this.defaultAssign_({
                key: 'resultListAll',
                value: [],
            })
            await this.defaultAssign_({
                key: 'resultListAdm',
                value: [],
            })
            await this.defaultAssign_({
                key: 'saveDataAdd',
                value: [],
            })
            await this.defaultAssign_({
                key: 'saveDataDel',
                value: [],
            })
            await this.defaultAssign_({
                key: 'currentAuth',
                value: '',
            })
            await this.defaultAssign_({
                key: 'newDtlParam',
                value: '',
            })
            await this.defaultAssign_({
                key: 'userGrpNmList',
                value: '',
            })
        },

        async initBtn() {
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 122 ~ data ',
                this.$data
            )
            await this.initData()
        },
        async del() {
            if (_.isEmpty(this.newDtlParam.userGrpCd)) {
                this.showTcComAlert('권한을 선택하세요.')
            } else {
                let params = { ...this.newDtlParam }
                this.defaultAssign_({
                    key: 'params',
                    value: params,
                })
                await this.delBasAdmAuthMgmt_()
                    .then((data) => {
                        if (data !== 1) {
                            this.showTcComAlert('삭제실패')
                        } else {
                            this.showTcComAlert('삭제완료')
                            this.searchData()
                        }
                    })
                    .catch((error) => {
                        Promise.reject(error)
                    })
                    .finally(() => {
                        console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                    })
            }
        },

        copy() {
            if (_.isEmpty(this.newDtlParam.userGrpCd)) {
                this.showTcComAlert('권한을 선택하세요.')
            } else {
                this.dtlParam = { ...this.newDtlParam }
                this.dtlParam.type = 'copy'
                this.copyDialogShow = true
                this.isBtn = true
                this.isCurrentAuth = false
            }
        },
        setup() {
            if (_.isEmpty(this.newDtlParam.userGrpCd)) {
                this.showTcComAlert('권한을 선택하세요.')
            } else {
                this.dtlParam = { ...this.newDtlParam }
                this.dtlParam.type = 'setup'
                this.isBtn = true
                this.setupDialogShow = true
                this.isCurrentAuth = false
            }
        },
        searchDtl() {
            if (_.isEmpty(this.newDtlParam.userGrpCd)) {
                this.showTcComAlert('권한을 선택하세요.')
            } else {
                this.dtlParam = { ...this.newDtlParam }
                this.dtlParam.type = 'update'
                this.copyDialogShow = true
            }
        },
        async searchBtn() {
            //await this.initAuthMgmt()
            await this.defaultAssign_({ key: 'paging', value: this.initPaging })
            await this.getUserGrpNmList()
            let paramObj = { ...this.formSearchParams }

            if (!_.isEmpty(this.delYn)) {
                paramObj.delYn = 'Y'
            } else {
                paramObj.delYn = 'N'
            }

            await this.defaultAssign_({
                key: 'searchParams',
                value: paramObj,
            })
            await this.searchData()
        },
        async searchData() {
            await this.loading(true)
            let data1
            await this.getBasAdmAuthMgmtList_()
                .then((data) => {
                    console.log(
                        '🚀 ~ file: SearchContent.vue ~ line 272 ~ searchData ~ data',
                        data
                    )
                    data1 = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: SearchContent.vue ~ finally')
                    this.loading(false)
                    if (_.isEmpty(data1)) {
                        this.showTcComAlert(msgTxt.MSG_00039.replace(/%s/g, ''))
                    }
                })
        },
        async saveBtn() {
            this.formSearchParams.aplyStaDt =
                this.aplyStaDt.replace(/-/g, '') + '01'
            console.log('🚀 ~ file: saveBtn~ line 122 ~ data ', this.$data)
            await this.defaultAssign_({
                key: 'searchParams',
                value: this.formSearchParams,
            })

            await this.defaultAssign_({
                key: 'saveAction',
                value: true,
            })
        },
        async saveAdmAuthBtn() {
            console.log(
                '🚀 ~ file: saveAdmAuthBtn~ line 122 ~ data ',
                this.$data
            )
            this.dtlParam.type = 'create'
            this.dtlParam.attcClCd = this.formSearchParams.attcClCd
            this.localDialogShow = true
            await this.defaultAssign_({
                key: 'searchParams',
                value: this.formSearchParams,
            })

            await this.defaultAssign_({
                key: 'saveAdmAuthAction',
                value: true,
            })
        },

        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        async inputEvent() {},

        async saveData() {
            await this.loading(true)
            let saveRows = []

            for (let i = 0; i < this.saveDataAdd.length; i++) {
                let e = this.saveDataAdd[i]
                saveRows.push({
                    ...e,
                    rowState: e.__rowState,
                })
            }
            for (let i = 0; i < this.saveDataDel.length; i++) {
                let e = this.saveDataDel[i]
                saveRows.push({
                    ...e,
                    rowState: 'deleted',
                })
            }
            if (!saveRows.length) {
                this.showTcComAlert(msgTxt.MSG_01002)
                return false
            }
            console.log('saveDealCoMgmt crud api call', saveRows)
            this.showTcComAlert('정상처리 되었습니다.')

            await this.defaultAssign_({
                key: 'saveDataAdd',
                value: [],
            })
            await this.defaultAssign_({
                key: 'saveDataDel',
                value: [],
            })
        },

        async saveBtn2() {
            await this.saveData2()
        },

        async saveData2() {
            await this.loading(true)
            let saveRows = []

            _.forEach(this.resultList, (add) => {
                if (_.isEqual(add.origin, 'ex')) {
                    // 매핑안된 사용자가 추가된 경우
                    let serNo = _.isEmpty(add.serNo) ? 1 : Number(add.serNo)
                    add.__rowState = 'created'
                    add.delYn = 'N'
                    add.authTypCd = '1'
                    add.userGrpCd = this.newDtlParam.userGrpCd
                    add.serNo = serNo
                    console.log('add ->', add)
                    saveRows.push(add)
                }
            })
            _.forEach(this.resultListAll, (del) => {
                if (_.isEqual(del.origin, 'in')) {
                    // 매핑된 사용자중 추가된 경우
                    let serNo = Number(del.serNo)
                    del.delYn = 'Y'
                    del.authTypCd = '1'
                    del.userGrpCd = this.newDtlParam.userGrpCd
                    del.serNo = serNo - 1
                    console.log('del -> ', del)
                    console.log('del ->', del)
                    saveRows.push(del)
                }
            })

            if (!saveRows.length) {
                this.showTcComAlert(msgTxt.MSG_01002)
                return false
            }

            let params = {}
            params['tbasAddUserAuthInfoVoList'] = saveRows
            this.defaultAssign_({
                key: 'saveParams',
                value: params,
            })
            await this.rgstBasAdmAuthMgmtUser_()
                .then((data) => {
                    if (data === 0) {
                        //this.showTcComAlert('등록실패')
                    } else {
                        this.activeOpen = false
                        let param1 = {
                            userGrpCd: this.newDtlParam.userGrpCd,
                            attcClCd: this.newDtlParam.attcClCd,
                        }
                        this.getAuthMgmtUserList_({
                            param: param1,
                        })
                        this.showTcComAlert('등록되었습니다.')
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    this.loading(false)

                    this.defaultAssign_({
                        key: 'saveParams',
                        value: [],
                    })
                })
        },
    },
    watch: {
        async saveDone1(val, oldVal) {
            if (val == true) {
                console.log('saveDone1: ', val, oldVal)
                console.log('saveDone1 add: ', this.saveDataAdd)
                console.log('saveDone1 del: ', this.saveDataDel)
                //saveAction 작업들이 모두 완료 되면 default 상태로 변환
                await this.saveData()

                await this.defaultAssign_({
                    key: 'saveAction',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: false,
                })
            }
        },
        async saveAdmAuthDone1(val, oldVal) {
            if (val == true) {
                console.log('saveAdmAuthDone1: ', val, oldVal)

                await this.defaultAssign_({
                    key: 'saveAdmAuthAction',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveAdmAuthDone',
                    value: false,
                })
            }
        },
    },
}
</script>
