<!-----------------------------------------------
 * 업무그룹명: 바로도착Master관리>권역별 재고현황
 * 서브업무명: 권역별 재고현황
 * 설명: 권역별 재고현황
 * 작성자: P179237
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>권역별 재고현황</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="cfSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <div class="formitem div4">
                    <span class="iteminput">
                        <!-- :disabled="true" 임시주석임 다시 적용해야함 -->
                        <TCComDatePicker
                            labelName="기준일자"
                            :eRequired="true"
                            calType="D"
                            v-model="setDate"
                            :disabled="true"
                        >
                        </TCComDatePicker>
                    </span>
                </div>
                <div class="formitem div4">
                    <TCComMultiComboBox
                        codeId="ZBAS_C_00820"
                        labelName="권역"
                        v-model="dsCondition.rgnCdList"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        :autocomplete="true"
                        blankItemValue=""
                    ></TCComMultiComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="dsCondition.hldDealcoNm"
                        :codeVal.sync="dsCondition.hldDealcoCd"
                        labelName="매장"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="dsCondition.prodNm"
                        :codeVal.sync="dsCondition.prodCd"
                        labelName="모델"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onProdsEnterKey"
                        @appendIconClick="onProdsIconClick"
                        @input="onProdsInput"
                    />
                    <BasBcoProdsPopup
                        v-if="basBcoProdsShow"
                        :parentParam="dsCondition"
                        :rows="resultProdsRows"
                        :dialogShow.sync="basBcoProdsShow"
                        @confirm="onProdsReturnData"
                    />
                </div>
            </div>
        </div>
        <!-- //Search_div -->

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="권역 별 재고현황"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getPagingData"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil, CommonGrid } from '@/utils'
import _ from 'lodash'
import { SacCommon } from '@/views/biz/sac/js'

import { G_HEADER } from '@/const/grid/dis/dsm/disDsmDarrvlRgnDisPrstHead'

import api from '@/api/biz/dis/dsm/disDsmDarrvlRgnDisPrst'

import attachedFileApi from '@/api/common/attachedFile'

//====================내부거래처-권한조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================

export default {
    name: 'DisDsmDarrvlRgnDisPrst',
    mixins: [CommonMixin],
    components: {
        BasBcoDealcosPop,
        BasBcoProdsPopup,
    },
    data() {
        return {
            indicatorOpt: { sort: 'ASC' },
            dsCondition: {
                strdDt: '',
                hldDealcoCd: '',
                hldDealcoNm: '',
                prodCd: '',
                prodNm: '',
            },

            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},
            view: G_HEADER,
            dsResult: [],

            objAuth: {}, // ?????
            //====================내부거래처-권한조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            //====================//상품팝업관련==================
            // paging
            rowCnt: 15, // 표시할 행의 갯수
            //조회 파라미터
            reqParams: {},
        }
    },
    created() {
        this.gridData = this.GridSetData()
    },
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 초기값 세팅
        this.fInit()

        this.setLayout()
    },
    computed: {
        setDate: {
            get() {
                return this.dsCondition.strdDt
            },
            set(val) {
                this.dsCondition.strdDt = val
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val).substr(0, 6)
                return val
            },
        },
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            this.gridObj.setGridState(true)
            this.gridData = this.GridSetData()
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // grid header merge
        setLayout: function () {
            this.gridObj.gridView.setColumnLayout(this.view.layout)
        },
        // 폼 초기화
        fInit: function () {
            this.dsCondition.strdDt = SacCommon.getToday()
            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.dsCondition['hldDealcoCd'] = this.userInfo['dealcoCd']
                this.dsCondition['hldDealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
            }
        },
        cfSearch: function () {
            this.dsResult = []
            this.gridObj.setRows([])

            this.dsCondition.pageSize = this.rowCnt
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getPagingData(1)
        },

        getPagingData: function (pageNum) {
            this.dsCondition.pageNum = pageNum
            const formData = this.getDsCondition()

            // 페이징 조회
            api.getRgnDisPrsts(formData).then((resultData) => {
                if (resultData) {
                    this.dsResult = resultData.gridList
                    this.gridObj.setRows(this.dsResult)
                    // 페이징 관련
                    this.gridObj.setGridIndicator(
                        resultData.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.GridSetData() //초기화
                    this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
            })
        },
        // 조회조건 가져오기
        getDsCondition: function () {
            this.dsCondition.rgnCd = _.toString(this.dsCondition.rgnCdList)
            this.dsCondition.strdDt = SacCommon.removeHyphen(
                this.dsCondition.strdDt
            )

            const reqData = SacCommon.objectRemovedArray(this.dsCondition)

            // testdata
            // this.dsCondition.rgnCd = '1036,1037,1038'
            // this.dsCondition.strdDt = '20220713'
            //testdata

            // 엑셀다운로드
            this.reqParams = reqData
            // 상세조회 팝업 데이터
            this.popupParams = { ...reqData }

            const formData = {
                dsCondition: {
                    ...reqData,
                },
            }

            return formData
        },

        onChangeRgnCd: function () {
            // 멀티콤보
        },
        // 초기화
        clearPage() {
            // CommonUtil.clearPage(this.$router)
            CommonUtil.clearPage(this, 'dsCondition')
            this.fInit()
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //Grid ExcelDown
        onClickDownload: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/rgnDisPrstsExcelDown',
                this.reqParams
            )
        },

        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            this.searchForm.dealcoCd = this.dsCondition.hldDealcoCd
            this.searchForm.dealcoNm = this.dsCondition.hldDealcoNm
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.dsCondition.hldDealcoCd = _.get(res[0], 'dealcoCd')
                    this.dsCondition.hldDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.dsCondition.hldDealcoNm)) {
                // this.getDealcosList()
                this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsCondition.hldDealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-권한조직명 입력해주세요.'
                return
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.dsCondition.hldDealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.hldDealcoCd = _.get(retrunData, 'dealcoCd')
            this.dsCondition.hldDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.dsCondition).then((res) => {
                console.log('getProdsList : ', res)
                if (res === undefined) return
                if (res.length === 1) {
                    this.dsCondition.prodCd = _.get(res[0], 'prodCd')
                    this.dsCondition.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.dsCondition.prodCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsCondition.prodCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.dsCondition.prodCd = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.prodCd = _.get(retrunData, 'prodCd')
            this.dsCondition.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
