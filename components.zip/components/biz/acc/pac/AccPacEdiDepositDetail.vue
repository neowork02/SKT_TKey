<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccPacEdiAccMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div>
        <div class="searchLayer_wrap type04 mt20">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        v-model="dtlInfo.patmentDt"
                        labelName="승인일자"
                        :disabled="true"
                    />
                </div>

                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        v-model="dtlInfo.payDt"
                        labelName="입금일자"
                        :disabled="true"
                    />
                </div>

                <div class="formitem div4">
                    <TCComInput
                        labelName="정산처"
                        v-model="dtlInfo.salePlcNm"
                        :disabled="true"
                    />
                </div>

                <div class="formitem div4">
                    <TCComInput
                        labelName="카드사"
                        v-model="dtlInfo.cardCoNm"
                        :disabled="true"
                    />
                </div>
            </div>
        </div>

        <AccGridTable
            ref="accGridTable"
            isEditable
            isColumnNo
            :offset="['btn-excelDownload']"
            :gridMeta="GRID_HEADER"
            :data="data"
            :pagingInfo="pagingInfo"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/pac/card-dpsts-dtl-excel-download`,
                query: query,
            }"
            @movePage="movePage"
            @changePageSize="changePageSize"
        />
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import { GRID_HEADER } from '@/const/grid/acc/pac/accPacEdiDepositDetailGrid'

export default {
    name: 'AccPacEdiDepositDetail',
    mixins: [CommonMixin, accMixin],
    components: {
        AccGridTable,
    },
    props: {
        data: {
            default: () => [],
        },

        dtlInfo: {
            default: () => ({}),
        },

        pagingInfo: {
            default: () => ({
                totalPageCnt: 0,
            }),
        },

        query: {
            default: () => ({}),
        },
    },
    data() {
        return {
            GRID_HEADER,
        }
    },
    mounted() {
        this.$nextTick(() => {
            this.$forceUpdate()
        })
    },
    methods: {
        movePage(query) {
            this.$emit('movePage', query)
        },
        changePageSize(query) {
            this.$emit('changePageSize', query)
        },
    },
}
</script>
