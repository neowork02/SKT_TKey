<!-----------------------------------------------
 * 업무그룹명: 사고기기관리>사고단말기 회수 관리
 * 서브업무명: 사고단말기 회수 관리
 * 설명: 사고단말기 회수 관리
 * 작성자: P179237
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>사고단말기 회수 관리</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="cfSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="cfNew"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <!--text field + search btn -->
                    <TCComDatePicker
                        labelName="조회기간"
                        :eRequired="true"
                        calType="DP"
                        v-model="setDate"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="dsCondition.orgNm"
                        :codeVal.sync="dsCondition.orgCd"
                        labelName="조직"
                        :eRequired="true"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00240"
                        labelName="거래처구분"
                        v-model="dsCondition.dealcoClCd1"
                        :filterFunc="dealcoClCd1Filter"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00171"
                        labelName="Risk 중분류"
                        v-model="dsCondition.riskMclCd"
                        :filterFunc="riskMclCdFilter"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="dsCondition.dealcoNm"
                        :codeVal.sync="dsCondition.dealcoCd"
                        labelName="거래처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoInrDealcosPopup
                        v-if="showBasBcoInrDealcos"
                        :parentParam="searchForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoInrDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 2-1 -->
                <div class="formitem div4_6"></div>
            </div>
            <!-- //Search_line 2 -->
        </div>
        <!-- //Search_div -->

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="사고단말기 회수 관리"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.onClickDownload"
            />
            <TCRealGrid
                id="grid3"
                ref="grid3"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getPagingData"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>

        <DisBeqTrblProdClctMgmtRgst
            v-if="showPopup === true"
            ref="popup"
            :dialogShow.sync="showPopup"
            :popupParams.sync="popupParams"
            @confirm="onReturnDisBeqTrblProdClctMgmtRgst"
        />
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil, CommonGrid } from '@/utils'
import _ from 'lodash'
import { SacCommon } from '@/views/biz/sac/js'

import { G_HEADER } from '@/const/grid/dis/beq/disBeqTrblProdClctMgmtHead'

import api from '@/api/biz/dis/beq/disBeqTrblProdClctMgmt'
import DisBeqTrblProdClctMgmtRgst from '@/views/biz/dis/beq/DisBeqTrblProdClctMgmtRgst.vue'

import attachedFileApi from '@/api/common/attachedFile'

//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-전체조직====================
import BasBcoInrDealcos from '@/api/biz/bas/bco/BasBcoInrDealcos'
import BasBcoInrDealcosPopup from '@/components/common/BasBcoInrDealcosPopup'
//====================//내부거래처-전체조직==================

export default {
    name: 'DisBeqTrblProdClctMgmt',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoInrDealcosPopup,
        DisBeqTrblProdClctMgmtRgst,
    },
    data() {
        return {
            indicatorOpt: { sort: 'ASC' },
            dsCondition: {
                // calOrdDtm: [SacCommon.getFirstday(), SacCommon.getToday()], // 등록일자
                searchDtFrom: '',
                searchDtTo: '',
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLvl: '', // 조직레벨
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명

                dealcoClCd1: '', // 거래처구분
                riskMclCd: '', // Risk 중분류
            },
            gridStyle: {
                height: '400px',
            },

            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},

            view: G_HEADER,
            dsResult: [],

            objAuth: {}, // ?????

            // popup
            popupParams: {},
            showPopup: false,
            //====================내부조직팝업(권한)팝업관련====================
            orgDisabled: false,
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처-전체====================
            showBasBcoInrDealcos: false,
            dealcoDisabled: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: '', // 거래처그룹
                dealcoClCd1: '', // 거래처구분
                //dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                //dealcoClCd1: 'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-전체==================
            // paging
            rowCnt: 15, // 표시할 행의 갯수
            //조회 파라미터
            reqParams: {},
        }
    },
    created() {
        this.gridData = this.GridSetData()
    },
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 초기값 세팅
        this.fInit()
    },
    computed: {
        setDate: {
            get() {
                return [
                    this.dsCondition.searchDtFrom,
                    this.dsCondition.searchDtTo,
                ]
            },
            set(val) {
                this.dsCondition.searchDtFrom = val[0]
                this.dsCondition.searchDtTo = val[1]
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val[1])
                return val
            },
        },
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObj = this.$refs.grid3
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            this.gridObj.setGridState(true)
            this.gridData = this.GridSetData()

            // 그리드 셀 클릭
            this.gridObj.gridView.onCellClicked = (grid, clickData) => {
                if ('data' === clickData.cellType) {
                    this.grdListOnCellDblClick(clickData.dataRow)
                }
            }
        },

        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },

        // 폼 초기화
        fInit: function () {
            this.dsCondition = {
                searchDtFrom: '',
                searchDtTo: '',
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLvl: '', // 조직레벨
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명

                dealcoClCd1: '', // 거래처구분
                riskMclCd: '', // Risk 중분류
            }

            this.dsCondition.searchDtFrom = SacCommon.getFirstday()
            this.dsCondition.searchDtTo = SacCommon.getToday()

            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.dsCondition['orgCd'] = this.orgInfo['orgCd']
                this.dsCondition['orgNm'] = this.orgInfo['orgNm']
                this.dsCondition['orgLvl'] = this.orgInfo['orgLvl']
                // this.dsCondition['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.dsCondition['dealcoCd'] = this.userInfo['dealcoCd']
                this.dsCondition['dealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true
            }

            // this.dsCondition.calOrdDtm = [
            //     SacCommon.getFirstday(),
            //     SacCommon.getToday(),
            // ]
        },

        // 초기화 버튼
        clearPage() {
            this.fInit()
            // CommonUtil.clearPage(this, 'dsCondition', this.gridObj)
        },

        grdListOnCellDblClick: function (index) {
            const jsonRow = this.gridObj.dataProvider.getJsonRow(index)

            jsonRow.orgNm = jsonRow.orgNmShort

            this.popupParams = {
                ...this.popupParams,
                ...jsonRow,
                vNew: 'N',
            }
            this.showPopup = true
        },
        cfSearch: function () {
            if (this.fCheckCondition()) {
                this.dsResult = []
                this.gridObj.setRows([])

                this.dsCondition.pageSize = this.rowCnt
                this.gridData.totalPage = 0 // 이전페이지정보 초기화
                this.getPagingData(1)
            }
        },
        getPagingData: function (pageNum) {
            this.dsCondition.pageNum = pageNum
            const formData = this.getDsCondition()

            // 페이징 조회
            api.getTrblProdclcts(formData).then((resultData) => {
                // console.log(resultData)

                this.dsResult = resultData.gridList
                this.gridObj.setRows(this.dsResult)
                // 페이징 관련
                this.gridObj.setGridIndicator(
                    resultData.pagingDto,
                    this.indicatorOpt
                ) //순번이 필요한경우 계산하는 함수
                this.gridData = this.GridSetData() //초기화
                this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },
        // 조회조건 가져오기
        getDsCondition: function () {
            // testdata
            // this.dsCondition.searchDtFrom = '20220201'
            // this.dsCondition.searchDtTo = '20220227'
            // this.dsCondition.orgLvl = '3'
            // this.dsCondition.orgCd = 'AC1314'
            //testdata

            // const dsCondDatas = _.omit(this.dsCondition, ['calOrdDtm']) // 배열제거
            // 엑셀다운로드
            this.reqParams = this.dsCondition
            // 상세조회 팝업 데이터
            this.popupParams = { ...this.dsCondition }

            const formData = {
                dsCondition: {
                    ...this.dsCondition,
                },
            }

            return formData
        },
        fCheckCondition: function () {
            if (_.isEmpty(this.dsCondition.orgCd)) {
                this.showTcComAlert('조직을 검색하신 후 조회 하시기 바랍니다.')
                return false
            }

            // this.dsCondition.searchDtFrom = this.dsCondition.calOrdDtm[0]
            // this.dsCondition.searchDtTo = this.dsCondition.calOrdDtm[1]

            if (_.isEmpty(this.dsCondition.searchDtFrom)) {
                this.showTcComAlert('시작 등록일자를 입력하여 주시기 바랍니다.')
                return false
            }

            if (_.isEmpty(this.dsCondition.searchDtTo)) {
                this.showTcComAlert('종료 등록일자를 입력하여 주시기 바랍니다.')
                return false
            }

            const fromDtNumber = SacCommon.removeHyphen(
                this.dsCondition.searchDtFrom
            )
            const toDtNumber = SacCommon.removeHyphen(
                this.dsCondition.searchDtTo
            )

            if (fromDtNumber > toDtNumber) {
                this.showTcComAlert(
                    '시작 등록일자는 종료 등록일자보다 클수 없습니다.'
                )
                return false
            }

            const fromYear = _.toNumber(fromDtNumber.substring(0, 4))
            const fromMonth = _.toNumber(fromDtNumber.substring(4, 6))
            const toYear = _.toNumber(toDtNumber.substring(0, 4))
            const toMonth = _.toNumber(toDtNumber.substring(4, 6))
            console.log(fromYear, ' ', fromMonth, ' ', toYear, ' ', toMonth)

            if ((toYear - fromYear) * 12 + (toMonth - fromMonth + 1) > 12) {
                this.showTcComAlert('최대 1년까지만 조회 가능합니다.')
                return false
            }
            return true
        },
        // 신규버튼
        cfNew: function () {
            this.popupParams = { ...this.dsCondition, vNew: 'Y' }
            this.showPopup = true
        },
        dealcoClCd1Filter(item) {
            return item.filter(
                (item) =>
                    item['commCdVal'] === 'A2' ||
                    item['commCdVal'] === 'A3' ||
                    item['commCdVal'] === 'A6' ||
                    item['commCdVal'] === 'B1' ||
                    item['commCdVal'] === 'B2' ||
                    item['commCdVal'] === 'Z1'
            )
        },
        // 팝업종료
        onReturnDisBeqTrblProdClctMgmtRgst: function (retVal) {
            if (retVal) {
                // 화면재조회
                this.cfSearch()
            }
        },
        riskMclCdFilter(item) {
            return item.filter((item) => item['commCdVal'] === '03')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //Grid ExcelDown
        onClickDownload: function () {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/beq/trblProdclctsExcelDown',
                this.reqParams
            )
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.dsCondition.orgCd
            this.searchParam.orgNm = this.dsCondition.orgNm
            this.searchParam.orgLvl = this.dsCondition.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(
                    SacCommon.objectRemovedArray(this.searchParam)
                )
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.dsCondition.orgCd = _.get(res[0], 'orgCd')
                        this.dsCondition.orgNm = _.get(res[0], 'orgNm')
                        this.dsCondition.orgLvl = _.get(res[0], 'orgLvl')
                        this.searchForm.orgCd = this.dsCondition.orgCd
                        this.searchForm.orgNm = this.dsCondition.orgNm
                        this.searchForm.orgLvl = this.dsCondition.orgLvl
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            console.log(this.dsCondition)
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.dsCondition.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            // if (_.isEmpty(this.dsCondition.orgNm)) {
            //     // this.headerText = '검색조건 필수'
            //     this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
            //     return
            // }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.dsCondition.orgCd = ''
            this.dsCondition.orgLvl = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.orgCd = _.get(retrunData, 'orgCd')
            this.dsCondition.orgNm = _.get(retrunData, 'orgNm')
            this.dsCondition.orgLvl = _.get(retrunData, 'orgLvl')
            this.searchForm.orgCd = this.dsCondition.orgCd
            this.searchForm.orgNm = this.dsCondition.orgNm
            this.searchForm.orgLvl = this.dsCondition.orgLvl
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-영업담당자팝업관련 methods ================================
        // 내부거래처-영업담당자 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-영업담당자 팝업 오픈
        getList() {
            this.searchForm.orgCd = this.dsCondition.orgCd
            this.searchForm.orgNm = this.dsCondition.orgNm
            this.searchForm.orgLvl = this.dsCondition.orgLvl
            this.searchForm.dealcoCd = this.dsCondition.dealcoCd
            this.searchForm.dealcoNm = this.dsCondition.dealcoNm
            console.log('this.searchForm>>>>>>>>>>>>> ', this.searchForm)
            BasBcoInrDealcos.getList(this.searchForm).then((res) => {
                console.log('getList then : ', res)
                // 검색된 내부거래처-전체 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-영업담당자 팝업 오픈
                if (res && res.length === 1) {
                    this.dsCondition.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.dsCondition.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoInrDealcos = true
                }
            })
        },
        // 내부거래처-전체 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            if (_.isEmpty(this.dsCondition.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            // 내부거래처-전체 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 내부거래처-전체 정보 조회
            this.getList()
        },
        // 내부거래처-전체 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 검색조건 내부거래처-전체명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsCondition.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            // 내부거래처-전체 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 내부거래처-전체 정보 조회
            this.getList()
        },
        // 내부거래처-전체 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체 코드 초기화
            this.dsCondition.dealcoCd = ''
        },
        // 내부거래처-전체 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.dsCondition.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-전체팝업관련 methods ================================
    },
}
</script>
