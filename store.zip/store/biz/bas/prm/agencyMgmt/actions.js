import api from '@/api/biz/bas/prm/basPrmAgencyMgmt'
import types from './mutation-types'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    showAlert_({ commit }, { title, message }) {
        commit(types.DEFAULT_ASSIGN, {
            key: 'alertHeaderText',
            value: title,
        })
        commit(types.DEFAULT_ASSIGN, {
            key: 'alertBodyText',
            value: message,
        })
        commit(types.DEFAULT_ASSIGN, {
            key: 'alertShow',
            value: true,
        })
    },
    toasting_({ commit }, { message }) {
        commit(types.DEFAULT_ASSIGN, {
            key: 'snackbar',
            value: true,
        })
        commit(types.DEFAULT_ASSIGN, {
            key: 'snackbarText',
            value: message,
        })
    },
    async commonCodes_({ commit }, { option }) {
        let result = await api.commonCodes_({})
        let body = result
            //.filter((item) => item.type == 'I')
            .map((object, index) => ({
                ...object,
                idx: index,
                codeValue: object.commCdId.toString(),
                codeName: object.commCdNm.toString(),
            }))
        body.unshift({ codeValue: '', codeName: option })
        commit(types.DEFAULT_ASSIGN, {
            key: 'commCdIds',
            value: body,
        })
    },
    async dropDownCmmonCodes_({ state, commit }, { key, columnName, option }) {
        let result = await api.dropDownCmmonCodes_(key)
        let values = []
        let labels = []
        values = result.map((a) => a.commCdVal)
        labels = result.map((a) => a.commCdValNm)
        if (option != undefined) {
            values.unshift('')
            labels.unshift(option)
        }

        let obj1 = {}
        obj1[columnName] = {
            values: values,
            labels: labels,
        }
        commit(types.DEFAULT_ASSIGN, {
            key: 'commDropDown',
            value: { ...state.commDropDown, ...obj1 },
        })
    },
    // eslint-disable-next-line no-unused-vars
    async getBasPrmAgencyMgmtAgencys_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ file: actions.js user ~ searchParams', searchParams)
        await api.getBasPrmAgencyMgmtAgencys_({ searchParams }).then((data) => {
            //console.log('🚀 ~ file: actions.js user ~ .then ~ data', data)
            resultData = data
        })
        return resultData
    },
    async getBasPrmAgencyMgmtList_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum
        console.log(
            '🚀 ~ file: actions.js ~ line 87 ~ searchParams',
            searchParams
        )
        await api
            .getBasPrmAgencyMgmtList_({ searchParams })
            .then((data) => {
                // console.log(
                //     '🚀 ~ file: actions.js ~ line 97 ~ .then ~ data',
                //     data
                // )
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: data.pagingDto,
                    })
                    let body = data.gridList
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: body,
                    })
                } else {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: state.initPaging,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: [],
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })
        // const _sleep = (delay) =>
        //     new Promise((resolve) => setTimeout(resolve, delay))
        // const timer = async () => {
        //     await _sleep(1000)
        //     console.log('First')
        //     await _sleep(1000)
        //     console.log('Second')
        // }
        // await timer()

        return resultData
    },
    // eslint-disable-next-line no-unused-vars
    async saveAgencyMgmt_({ state, commit }, { saveRows }) {
        console.log('🚀 ~ file: actions.js ~ line 128 ~ saveRows', saveRows)
        let result = 0
        await api
            .saveAgencyMgmt_(saveRows)
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ saveAgencyMgmt_~ .then ~ data',
                    data
                )
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
}
