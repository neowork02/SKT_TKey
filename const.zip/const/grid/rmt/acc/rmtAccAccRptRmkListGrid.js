'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: '__rowState',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'accMth',
        editable: false,
        header: { text: '정산월' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'orgId',
        editable: false,
        header: { text: '조직' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'orgNm',
        editable: false,
        header: { text: '조직명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    // headgroup 무선상세
    {
        fieldName: 'r1',
        editable: false,
        header: { text: '판매인센티브' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'r2',
        editable: false,
        header: { text: '중고/PPS수수료' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'hhmmss',
        columnDatetimeFormat: 'hh:mm:ss',
    },
    {
        fieldName: 'r3',
        editable: false,
        header: { text: '전환정책' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r4',
        editable: false,
        header: { text: '무선추가1' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r5',
        editable: false,
        header: { text: '무선추가2' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r6',
        editable: false,
        header: { text: '기간INFRA1' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r7',
        editable: false,
        header: { text: '기간INFRA2' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r8',
        editable: false,
        header: { text: 'PT INFRA1' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r9',
        editable: false,
        header: { text: 'PT INFRA2' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r10',
        editable: false,
        header: { text: '2G 전환USIM지원' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r11',
        editable: false,
        header: { text: 'USIM후불수수료' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    // headgroup

    // headgroup 유선상세
    {
        fieldName: 'r12',
        editable: false,
        header: { text: '유선인센티브' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r13',
        editable: false,
        header: { text: '유선추가1' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r14',
        editable: false,
        header: { text: '유선추가2' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r15',
        editable: false,
        header: { text: '유선추가3' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'r16',
        editable: false,
        header: { text: '유선추가4' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r17',
        editable: false,
        header: { text: '재정산' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r18',
        editable: false,
        header: { text: '환수' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    // headgroup

    // headgroup Infra 정책 상세
    {
        fieldName: 'r19',
        editable: false,
        header: { text: 'INFRA1' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r20',
        editable: false,
        header: { text: 'INFRA2' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r21',
        editable: false,
        header: { text: 'INFRA3' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r22',
        editable: false,
        header: { text: 'INFRA4' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r23',
        editable: false,
        header: { text: 'INFRA5' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r24',
        editable: false,
        header: { text: 'INFRA6' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r41',
        editable: false,
        header: { text: 'INFRA7' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r25',
        editable: false,
        header: { text: '보증보험' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    // headgroup

    // headgroup 재정산 상세
    {
        fieldName: 'r27',
        editable: false,
        header: { text: '중고/PPS미유지' },
        type: 'data',
        dataType: ValueType.TEXT,
        footer: {
            text: '합계',
        },
    },
    {
        fieldName: 'r28',
        editable: false,
        header: { text: '회선관리정책' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r29',
        editable: false,
        header: { text: '비정상해지' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r30',
        editable: false,
        header: { text: '파파라치(VAT포함)' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r31',
        editable: false,
        header: { text: 'CIA' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r32',
        editable: false,
        header: { text: 'SKN 물류비' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r33',
        editable: false,
        header: { text: '고정비' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r34',
        editable: false,
        header: { text: '기타 재정산' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r35',
        editable: false,
        header: { text: '요금제재정산' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'r36',
        editable: false,
        header: { text: '전월 재정산' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'r37',
        editable: false,
        header: { text: '파파라치' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'r38',
        editable: false,
        header: { text: 'VOC/명의도용' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'r39',
        editable: false,
        header: { text: '기타1(VAT제외)' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'r40',
        editable: false,
        header: { text: '기타2(VAT제외)' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    // headgroup

    // headgroup 공기기/USIM 판매
    {
        fieldName: 'r26',
        editable: false,
        header: { text: '공기기판매' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = [
    'accMth',
    'orgId',
    'orgNm',
    {
        name: 'wirelessInfo',
        header: { text: '무선상세' },
        direction: 'horizontal',
        items: [
            'r1',
            'r2',
            'r3',
            'r4',
            'r5',
            'r6',
            'r7',
            'r8',
            'r9',
            'r10',
            'r11',
        ],
    },
    {
        name: 'cableInfo',
        header: { text: '유선상세' },
        direction: 'horizontal',
        items: ['r12', 'r13', 'r14', 'r15', 'r16', 'r17', 'r18'],
    },
    {
        name: 'infraInfo',
        header: { text: 'Infra 정책 상세' },
        direction: 'horizontal',
        items: ['r19', 'r20', 'r21', 'r22', 'r23', 'r24', 'r41', 'r25'],
    },
    {
        name: 'resettlementInfo',
        header: { text: '재정산 상세' },
        direction: 'horizontal',
        items: [
            'r27',
            'r28',
            'r29',
            'r30',
            'r31',
            'r32',
            'r33',
            'r34',
            'r35',
            'r36',
            'r37',
            'r38',
            'r39',
            'r40',
        ],
    },
    {
        name: 'saleUnlockInfo',
        header: { text: '공기기/USIM 판매' },
        direction: 'horizontal',
        items: ['r26'],
    },
]
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {}

export { GRID_HEADER, MOCK_DATA }
