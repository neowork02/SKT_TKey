import { ValueType } from 'realgrid'

export const SALACO01400GRIDHEADER = {
    fields: [
        {
            fieldName: 'clsDt',
            //dataType: ValueType.TEXT, // 마감일자
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT, // 사업담당코드
        },
        {
            fieldName: 'bizChrgOrgNm',
            dataType: ValueType.TEXT, // 사업담당명
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT, // 영업팀코드
        },
        {
            fieldName: 'teamOrgNm',
            dataType: ValueType.TEXT, // 영업팀명
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 영업파트코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 영업파트명
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, // 정산처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, // 거래처명
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT, // 거래처구분코드
        },
        {
            fieldName: 'dealcoClNm1',
            dataType: ValueType.TEXT, // 거래처구분명
        },
        {
            fieldName: 'dealEndDt',
            //dataType: ValueType.TEXT, // 거래종료일
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'bfBondAmt',
            dataType: ValueType.NUMBER, // 전일현금잔액
        },
        {
            fieldName: 'toFeesAmt',
            dataType: ValueType.NUMBER, // 당일현금증가_SKT수납
        },
        {
            fieldName: 'toCashAmt',
            dataType: ValueType.NUMBER, // 당일현금증가_현금매출
        },
        {
            fieldName: 'toEtcmAmt',
            dataType: ValueType.NUMBER, // 당일현금증가_기타수납
        },
        {
            fieldName: 'toDpstAmt',
            dataType: ValueType.NUMBER, // 본사송금
        },
        {
            fieldName: 'toRfndAmt',
            dataType: ValueType.NUMBER, // 오입금환불
        },
        {
            fieldName: 'toRcvbAmt',
            dataType: ValueType.NUMBER, // 기타미수금
        },
        {
            fieldName: 'toBondAmt',
            dataType: ValueType.NUMBER, // 당일현금잔액
        },
        {
            fieldName: 'orgNmTree',
            dataType: ValueType.TEXT, // 조직트리
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
    ],
    columns: [
        {
            name: 'clsDt',
            fieldName: 'clsDt',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            header: {
                text: '마감일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
        },
        // {
        //     name: 'bizChrgOrgNm',
        //     fieldName: 'bizChrgOrgNm',
        //     type: 'data',
        //     width: '100',
        //     styleName: 'left-column',
        //     header: {
        //         text: '사업담당',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: 'teamOrgNm',
        //     fieldName: 'teamOrgNm',
        //     type: 'data',
        //     width: '100',
        //     styleName: 'left-column',
        //     header: {
        //         text: '영업팀',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: 'orgNm',
        //     fieldName: 'orgNm',
        //     type: 'data',
        //     width: '100',
        //     styleName: 'left-column',
        //     header: {
        //         text: '영업파트',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'orgNmTree',
            fieldName: 'orgNmTree',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: {
                text: '조직',
                showTooltip: true,
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            width: '100',
            //           styleName: 'left-column',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            width: '80',
            //            styleName: 'left-column',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            footer: {
                text: '계',
            },
        },
        {
            name: 'dealcoClNm1',
            fieldName: 'dealcoClNm1',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            header: {
                text: '거래처유형',
                showTooltip: false,
            },
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            header: {
                text: '거래종료일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'bfBondAmt',
            fieldName: 'bfBondAmt',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            header: {
                text: '전일현금잔액',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toFeesAmt',
            fieldName: 'toFeesAmt',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: 'SKT수납',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toCashAmt',
            fieldName: 'toCashAmt',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '현금매출',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toEtcmAmt',
            fieldName: 'toEtcmAmt',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '기타수납',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toDpstAmt',
            fieldName: 'toDpstAmt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            header: {
                text: '본사송금',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toRfndAmt',
            fieldName: 'toRfndAmt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            header: {
                text: '오입금환불',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toRcvbAmt',
            fieldName: 'toRcvbAmt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            header: {
                text: '기타미수금',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toBondAmt',
            fieldName: 'toBondAmt',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            header: {
                text: '당일현금잔액',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
    ],
}
