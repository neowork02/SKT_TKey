import { ValueType } from 'realgrid'

export const GRID_CASH_TAB = {
    fields: [
        {
            fieldName: 'procDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoCl1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'balAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'deviceQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'usimQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'smtDeviceQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'giftAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'empNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'procDt',
            fieldName: 'procDt',
            type: 'data',
            width: '60',
            header: {
                text: '거래상태',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '60',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealCoCl1',
            fieldName: 'dealCoCl1',
            type: 'data',
            width: '60',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'balAmt',
            fieldName: 'balAmt',
            type: 'data',
            width: '60',
            header: {
                text: '* 현금잔액',
                showTooltip: false,
            },
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            editable: false,
            button: 'action',
            buttonVisibility: 'always',
        },
        {
            name: 'deviceQty',
            fieldName: 'deviceQty',
            type: 'data',
            width: '60',
            header: {
                text: '단말기보유수량(2nd Device)',
                showTooltip: false,
            },
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
        },
        {
            name: 'usimQty',
            fieldName: 'usimQty',
            type: 'data',
            width: '60',
            header: {
                text: 'USIM보유수량',
                showTooltip: false,
            },
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
        },
        {
            name: 'smtDeviceQty',
            fieldName: 'smtDeviceQty',
            type: 'data',
            width: '60',
            header: {
                text: '스마트디바이스',
                showTooltip: false,
            },
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
        },
        {
            name: 'giftAmt',
            fieldName: 'giftAmt',
            type: 'data',
            width: '60',
            header: {
                text: '상품권 보유액',
                showTooltip: false,
            },
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
        },
        {
            name: 'empNo',
            fieldName: 'empNo',
            type: 'data',
            width: '60',
            header: {
                text: '사번',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'userId',
            fieldName: 'userId',
            type: 'data',
            width: '60',
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            width: '60',
            header: {
                text: '처리자명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '60',
            header: {
                text: '수정일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
    layout: ['balAmt', 'deviceQty', 'usimQty', 'smtDeviceQty', 'giftAmt'],
}

export const POPUP_HEADER = {
    fields: [
        {
            fieldName: 'unit',
            dataType: ValueType.TEXT, // 단위
        },
        {
            fieldName: 'unitNm',
            dataType: ValueType.TEXT, // 단위명
        },
        {
            fieldName: 'count', // 갯수
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'amount', // 금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'editYn', // 수정여부
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'unit',
            fieldName: 'unit',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '단위',
            },
            visible: false,
        },
        {
            name: 'unitNm',
            fieldName: 'unitNm',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            renderer: {
                showTooltip: false,
            },
            editable: false,
            header: {
                text: '단위',
            },
        },
        {
            name: 'count',
            fieldName: 'count',
            type: 'data',
            width: '60',
            header: {
                text: '갯수',
                showTooltip: false,
            },
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
        },
        {
            name: 'amount',
            fieldName: 'amount',
            type: 'data',
            width: '60',
            header: {
                text: '금액',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'editYn',
            fieldName: 'editYn',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '수정여부',
            },
            visible: false,
        },
    ],
}

const CASH_DTL_DATAS = {
    cashDtlList: [
        {
            amount: null,
            count: 0,
            editYn: 'N',
            unit: 100000,
            unitNm: '10만원',
        },
        {
            amount: null,
            count: 0,
            editYn: 'N',
            unit: 50000,
            unitNm: '5만원',
        },
        {
            amount: null,
            count: 0,
            editYn: 'N',
            unit: 10000,
            unitNm: '1만원',
        },
        {
            amount: null,
            count: 0,
            editYn: 'N',
            unit: 5000,
            unitNm: '5천원',
        },
        {
            amount: null,
            count: 0,
            editYn: 'N',
            unit: 1000,
            unitNm: '1천원',
        },
        {
            amount: null,
            count: 0,
            editYn: 'N',
            unit: 500,
            unitNm: '500원',
        },
        {
            amount: null,
            count: 0,
            editYn: 'N',
            unit: 100,
            unitNm: '100원',
        },
        {
            amount: null,
            count: 0,
            editYn: 'N',
            unit: 50,
            unitNm: '50원',
        },
        {
            amount: null,
            count: 0,
            editYn: 'N',
            unit: 10,
            unitNm: '10원',
        },
        {
            unit: 0,
            unitNm: '기타(10만원 외 수표)',
            count: null,
            amount: null,
            editYn: 'Y',
        },
    ],
}

export { CASH_DTL_DATAS }
