<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 통합미수금 관리 수납대상집계
 * 설명: 조회, 저장
 * 작성자: P180190
 * 작성일: 2022.11.17
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="900px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">통합미수금관리-미수금상세</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="거래처"
                                    v-model="popupParams.dealcoCd"
                                    :editable="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="거래처명"
                                    v-model="popupParams.dealcoNm"
                                    :editable="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                        </div>
                    </div>

                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="payTotGridHeader"
                            ref="payTotGridHeader"
                            gridTitle="수납내역"
                            :gridObj="payTotGridObj"
                            :isExceldown="true"
                            @excelDownBtn="downloadPayListExcel"
                        >
                        </TCRealGridHeader>
                        <TCRealGrid
                            id="payTotGrid"
                            ref="payTotGrid"
                            :fields="payTotView.fields"
                            :columns="payTotView.columns"
                            :styles="gridStyle"
                        />
                    </div>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="dpstProcGridHeader"
                            ref="dpstProcGridHeader"
                            gridTitle="입금내역"
                            :gridObj="dpstProcGridObj"
                            :isExceldown="true"
                            @excelDownBtn="downloadDpstProcListExcel"
                        >
                        </TCRealGridHeader>
                        <TCRealGrid
                            id="dpstProcGrid"
                            ref="dpstProcGrid"
                            :fields="dpstProcView.fields"
                            :columns="dpstProcView.columns"
                            :styles="gridStyle"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                </div>
                <!-- // Bottom BTN Group -->
                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose"
                    >닫기</a
                >
                <!--//Close BTN-->
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    PAY_GRID_HEADER,
    DPST_GRID_HEADER,
} from '@/const/grid/acc/sac/AccSacIntgUnpdMgmtDtlGrid'
import intgUnpdMgmtApi from '@/api/biz/acc/sac/AccSacIntgUnpdMgmt'
import CommonMixin from '@/mixins'
import moment from 'moment'

export default {
    name: 'AccSacIntgUnpdMgmtDtl',
    title: '통합미수금관리-미수금상세',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            gridData: {},
            payTotGridObj: {},
            dpstProcGridObj: {},

            objAuth: {},
            payTotView: PAY_GRID_HEADER,
            dpstProcView: DPST_GRID_HEADER,

            /*그리드 스타일*/
            gridStyle: {
                height: '100px', //그리드 높이 조절
            },

            popupParams: {
                dpstDt: '',
                dealcoCd: '',
                dealcoNm: '',
                matchKey: '',
            },

            param: {
                saleMgmtNo: [],
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {},
    mounted() {
        this.payGridObj = this.$refs.payTotGrid
        this.dpstGridObj = this.$refs.dpstProcGrid

        this.payTotGridObj = this.$refs.payTotGridHeader
        this.dpstProcGridObj = this.$refs.dpstProcGridHeader

        this.payGridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.payGridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

        this.dpstGridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.dpstGridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

        this.payGridObj.setGridState(false, false, false, true)
        this.dpstGridObj.setGridState(false, false, false, true)

        this.payGridObj.gridView.setRowIndicator({
            zeroBase: false,
            visible: true,
            displayValue: 'index',
        })
        this.dpstGridObj.gridView.setRowIndicator({
            zeroBase: false,
            visible: true,
            displayValue: 'index',
        })
        console.log('this.parentParam::::::::', this.parentParam)

        this.popupParams = this.parentParam
        this.paySearch()
        this.dpstSearch()
    },
    methods: {
        paySearch() {
            this.popupParams.baseDt = moment(this.popupParams.baseDt).format(
                'YYYYMMDD'
            )
            console.log('this.popupParams', this.popupParams)
            intgUnpdMgmtApi.getPay(this.popupParams).then((res) => {
                if (res) {
                    this.payGridObj.setRows(res.gridList)
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },

        downloadPayListExcel() {
            intgUnpdMgmtApi.downloadDpstProcListExcel(this.popupParams)
        },

        dpstSearch() {
            this.popupParams.dpstDt = moment(this.popupParams.baseDt).format(
                'YYYYMMDD'
            )
            console.log('this.popupParams', this.popupParams)
            intgUnpdMgmtApi.getDpstProc(this.popupParams).then((res) => {
                if (res) {
                    this.dpstGridObj.setRows(res.gridList)
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },

        downloadDpstProcListExcel() {
            intgUnpdMgmtApi.downloadDpstProcListExcel(this.popupParams)
        },

        onClose() {
            this.activeOpen = false
        },
    },
}
</script>
