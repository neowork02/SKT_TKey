import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'no',
            dataType: ValueType.TEXT, //번호
        },
        {
            fieldName: 'fidcYn',
            dataType: ValueType.TEXT, //수탁재고여부
        },
        {
            fieldName: 'dlvYnD2',
            dataType: ValueType.TEXT, //D+2 배송여부
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직명
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, //레벨0조직
        },
        {
            fieldName: 'lvOrgNm',
            dataType: ValueType.TEXT, //레벨0조직명
        },
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT, //레벨1조직
        },
        {
            fieldName: 'lvOrgNm1',
            dataType: ValueType.TEXT, //레벨1조직명
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, //레벨2조직
        },
        {
            fieldName: 'lvOrgNm2',
            dataType: ValueType.TEXT, //레벨2조직명
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT, //레벨3조직
        },
        {
            fieldName: 'lvOrgNm3',
            dataType: ValueType.TEXT, //레벨3조직명
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'dealcoShopCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'sknDelvDealcoCd',
            dataType: ValueType.TEXT, //배송지코드
        },
        {
            fieldName: 'rcvSknDelvPlcCd',
            dataType: ValueType.TEXT, //SKN배송지코드
        },
        {
            fieldName: 'sknDelvDealcoNm',
            dataType: ValueType.TEXT, //배송지명
        },
        {
            fieldName: 'crdtBalAmt',
            dataType: ValueType.TEXT, //여신잔액
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'currHldQty',
            dataType: ValueType.TEXT, //현재고
        },
        {
            fieldName: 'salePlcProdQty',
            dataType: ValueType.TEXT, //30일실적
        },
        {
            fieldName: 'asgnQty',
            dataType: ValueType.TEXT, //배정수량
        },
        {
            fieldName: 'rlAsgnQty',
            dataType: ValueType.TEXT, //배정수량
        },
        {
            fieldName: 'addAsgnQty',
            dataType: ValueType.TEXT, //추가배정수량
        },
        {
            fieldName: 'sumQty',
            dataType: ValueType.TEXT, //배정수량합계
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.TEXT, //단가
        },
        {
            fieldName: 'ordAmt',
            dataType: ValueType.TEXT, //주문금액
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //오류사항
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT, //처리자ID
        },
        {
            fieldName: 'asgnClCd',
            dataType: ValueType.TEXT, //배정구분코드
        },
        {
            fieldName: 'strdDt',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'fidcYn',
            fieldName: 'fidcYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수탁재고',
                showTooltip: false,
            },
        },
        {
            name: 'dlvYnD2',
            fieldName: 'dlvYnD2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'D+2',
                showTooltip: false,
            },
        },
        {
            name: 'lvOrgNm',
            fieldName: 'lvOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '회사명',
                showTooltip: false,
            },
        },
        {
            name: 'lvOrgNm1',
            fieldName: 'lvOrgNm1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '담당명',
                showTooltip: false,
            },
        },
        {
            name: 'lvOrgNm2',
            fieldName: 'lvOrgNm2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '팀명',
                showTooltip: false,
            },
        },
        {
            name: 'lvOrgNm3',
            fieldName: 'lvOrgNm3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '파트명',
                showTooltip: false,
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoShopCd',
            fieldName: 'dealcoShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
        },
        {
            name: 'sknDelvDealcoCd',
            fieldName: 'sknDelvDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN배송지코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'currHldQty',
            fieldName: 'currHldQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현보유수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'salePlcProdQty',
            fieldName: 'salePlcProdQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '30일실적',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'rlAsgnQty',
            fieldName: 'rlAsgnQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정수량',
                showTooltip: false,
            },
        },
        {
            name: 'addAsgnQty',
            fieldName: 'addAsgnQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가배정수량',
                showTooltip: false,
            },
        },
        {
            name: 'sumQty',
            fieldName: 'sumQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정수량합계',
                showTooltip: false,
            },
        },
        {
            name: 'crdtBalAmt',
            fieldName: 'crdtBalAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신잔액',
                showTooltip: false,
            },
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
        },
        {
            name: 'ordAmt',
            fieldName: 'ordAmt',
            type: 'number',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문금액',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류사항',
                showTooltip: false,
            },
        },
        {
            name: 'asgnClCd',
            fieldName: 'asgnClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'strdDt',
            fieldName: 'strdDt',
            visible: false,
            type: 'data',
        },
    ],
}
