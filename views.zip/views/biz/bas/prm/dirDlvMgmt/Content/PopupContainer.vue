<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">
                    {{ title }}
                </p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Top BTN -->
                    <!--
                    <ul class="btn_area top pop">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :disabled="true"
                                >거래상태변경</TCComButton
                            >
                        </li>
                    </ul>
                    -->
                    <!-- // Top BTN -->
                    <!-- 신규정보 -->
                    <!--                    <NewInfoContainer />-->

                    <!-- 기준정보 -->
                    <StrdInfoContainer />

                    <!-- 물류창고/직영점/하부망 추가정보 -->
                    <EtcAddInfoContainer />

                    <!-- 사업자등록정보 -->
                    <BizRgstInfoContainer />

                    <!-- 계좌정보 -->
                    <AcntInfoContainer />

                    <!-- 담보 -->
                    <CltInfoContainer />

                    <!-- 배송지 -->
                    <DlvDealcoInfoContainer />

                    <!-- Bottom BTN Group -->
                    <!-- Bottom -->
                    <!--                    <BottomContainer />-->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dirDlvMgmt/helpers'
import CommonMixin from '@/mixins'
import _ from 'lodash'

//==================== 상세정보 ====================
//import NewInfoContainer from './Detail/NewInfoContainer.vue' // 기본정보
import StrdInfoContainer from './Detail/StrdInfoContainer.vue' // 기준정보
import EtcAddInfoContainer from './Detail/EtcAddInfoContainer.vue' // 물류창고/직영점/하부망 추가정보
import BizRgstInfoContainer from './Detail/BizRgstInfoContainer.vue' // 사업자등록정보
import AcntInfoContainer from './Detail/AcntInfoContainer.vue' // 계좌정보
import CltInfoContainer from './Detail/CltInfoContainer.vue' // 담보
import DlvDealcoInfoContainer from './Detail/DlvDealcoInfoContainer.vue'

import { msgTxt } from '@/const/msg.Properties'

//==================== //상세정보 ====================

export default {
    name: 'PopupContainer',
    components: {
        // NewInfoContainer, // 기본정보
        StrdInfoContainer, // 기준정보
        EtcAddInfoContainer, // 물류창고/직영점/하부망 추가정보
        BizRgstInfoContainer, // 사업자등록정보
        AcntInfoContainer, // 계좌정보
        CltInfoContainer, // 담보
        DlvDealcoInfoContainer, // 배송지
    },
    mixins: [CommonMixin],
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            showAddressRgst: false,

            //====================거래상태변경====================
            showDealStatusPopup: false,
            searchParam: {
                dealcoCd: '', // 거래처코드
                normalYn: '', // 거래정상
                payStopYn: '', // 수납정지
                outStopYn: '', // 출고정지
                saleStopYn: '', // 판매정지
                sttlEndYn: '', // 정산정지
                drwStopYn: '', // 출금정지
                ifYn: '',
                sktAgencyCd: '',
                sktSubCd: '',
                sktChnlCd: '',
                hstSeq: '',
            },
            resultDealStatusRows: [],
            //====================//거래상태변경==================
            isDealStatus1: true,
            title: '',
            gridStyle: {
                height: '170px', //그리드 높이 조절
            },
            dealcoClList: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처구분
        }
    },
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },

        initParam: {
            get() {
                return this.initParams
            },
        },
        reqParam: {
            get() {
                return this.reqParams
            },
        },
        dealcoClList1: {
            get() {
                return this.dealcoClList
            },
        },
        initList1: {
            get() {
                return this.initList
            },
        },
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
        ////////////////// 공통코드 조회
        dealCoGrp: {
            get() {
                return this.DEAL_CO_GRP // 거래처그룹
            },
        },
        zbasC00240: {
            get() {
                return this.ZBAS_C_00240 // 거래처구분
            },
        },
        zbasC00510: {
            get() {
                return this.ZBAS_C_00510 // 거래처유형 (판매점구분)
            },
        },
        zbasC00570: {
            get() {
                return this.ZBAS_C_00570 // 거래처유형 (직영점구분)
            },
        },
        zbasC00530: {
            get() {
                return this.ZBAS_C_00530 // 거래처분류
            },
        },
        zbasC00590: {
            get() {
                return this.ZBAS_C_00590 // 거래처분류 (직영점2차점 거래처분류)
            },
        },
        zbasC00110: {
            get() {
                return this.ZBAS_C_00110 // 전자결재 진행여부
            },
        },
        zbasC00130: {
            get() {
                return this.ZBAS_C_00130 // 전자결재 진행여부
            },
        },
        zbasC00120: {
            get() {
                return this.ZBAS_C_00120 // 전자결재 진행여부
            },
        },
        zbasC00400: {
            get() {
                return this.ZBAS_C_00400 //
            },
        },
        zbasC00710: {
            get() {
                return this.ZBAS_C_00710 //
            },
        },
        zbasC00230: {
            get() {
                return this.ZBAS_C_00230 //
            },
        },
        spClsBizClCd: {
            get() {
                return this.SP_CLS_BIZ_CL_CD // 전자결재 진행여부
            },
        },
        comYn: {
            get() {
                return this.COM_YN // 전자결재 진행여부
            },
        },
        emailAcc: {
            get() {
                return this.EMAIL_ACC // 이메일
            },
        },
        taxPrdCd: {
            get() {
                return this.TAX_PRD_CD
            },
        },
        ////////////////// 공통코드 조회

        newInfoData1: {
            get() {
                return this.newInfoData
            },
        }, // 신규정보

        strdInfoData1: {
            get() {
                return this.strdInfoData
            },
        }, // 기준정보

        bizRgstInfoData1: {
            get() {
                return this.bizRgstInfoData
            },
        }, // 사업자등록정보

        dlvDealcoInfoData1: {
            get() {
                return this.dlvDealcoInfoData
            },
        }, // 배송지

        etcAddInfoData1: {
            get() {
                return this.etcAddInfoData
            },
        }, // 물류창고/직영점/하부망 추가정보

        acntInfoData1: {
            get() {
                return this.acntInfoData
            },
        }, // 계좌정보

        cltInfoData1: {
            get() {
                return this.cltInfoData
            },
        }, // 담보정보

        agencyAddInfoData1: {
            get() {
                return this.agencyAddInfoData
            },
        }, // 대리점 추가정보
    },
    async mounted() {
        await this.init() // 초기화
        this.gridSetting()
    },
    methods: {
        ...serviceMethods,

        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        async isDisabled(key, isDisabled) {
            await this.defaultAssign_({
                key: key,
                value: isDisabled,
            })
        },
        gridSetting() {
            let isGridStrdInfo = false // 기준정보
            let isGridEtcAddInfo = false // 추가정보
            let isGridBizRgstInfo = false // 사업자등록정보
            let isGridAcntInfo = false // 계좌정보
            let isGridCltInfo = false // 담보
            let isGridDlvDealcoInfo = false // 배송지

            this.storeSet('isGridStrdInfo', isGridStrdInfo)
            this.storeSet('isGridEtcAddInfo', isGridEtcAddInfo)
            this.storeSet('isGridBizRgstInfo', isGridBizRgstInfo)
            this.storeSet('isGridAcntInfo', isGridAcntInfo)
            this.storeSet('isGridCltInfo', isGridCltInfo)
            this.storeSet('isGridDlvDealcoInfo', isGridDlvDealcoInfo)
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },

        async init() {
            await this.loading(true)
            let isNew = true
            if (!_.isEmpty(this.parentParam)) {
                this.title = '거래처상세'
                let param = { ...this.parentParam }
                if (_.isEqual(param.ifYn, 'Y')) {
                    this.title = '거래처등록'
                }
                await this.defaultAssign_({
                    key: 'reqParams',
                    value: param,
                })

                await this.getBasPrmDealcoDtlNewList()
            } else {
                isNew = false
                this.title = '거래처등록'
            }

            let initPIsNew = {}
            initPIsNew.pIsNew = isNew
            await this.defaultAssign_({
                key: 'initParams',
                value: initPIsNew,
            })

            this.initData()
        },

        async getBasPrmDealcoDtlNewList() {
            //await this.loading(true)
            this.getBasPrmDealcoDtlNewList_()
                .then((data) => {
                    if (_.isEmpty(data)) {
                        this.toasting_({
                            message: msgTxt.MSG_00039.replace(/%s/g, ''),
                        })
                    }
                    // this.initIsDisabled(false)

                    this.getDealcoClList() // 거래처 유형 조회
                    this.changeDealcoCl2(this.etcAddInfoData1.dealcoClCd2)
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                    //this.loading(false)
                })
        },

        disableDataList(isValue) {
            const isDisableDataList = [
                'isDisabledDataUKey',
                'isDisabledDataStlPlc',
                'isDisabledDataDisHldPlc',
                'isDisabledDataStlPlcChk',
                'isDisabledDataDisHldPlcChk',
                'isDisabledDataSknDelvYn',
                'isDisabledDataExcYn',
                'isDisabledDataBankCdYn',
                'isDisabledDataBtnCrdDeal',
            ]

            _.forEach(isDisableDataList, (data) => {
                this.isDisabled(data, !isValue)
            })
        },

        disableDataBankList(isValue) {
            const isDisableDataBankList = [
                'isDisabledDataBankCd1',
                'isDisabledDataBankCd2',
                'isDisabledDataBankCd3',
                'isDisabledDataBankCd4',
                'isDisabledDataBankCd5',
                'isDisabledDataBankCd6',
            ]

            _.forEach(isDisableDataBankList, (data) => {
                this.isDisabled(data, !isValue)
            })
        },

        disableDataDealcoClList(isValue) {
            const isDisableDataDealcoClList = [
                'isDisabledDataDealcoCl1_1',
                'isDisabledDataDealcoCl2_1',
                'isDisabledDataDealcoCl3_1',
                'isDisabledDataMaDirectYn_1',
                'isDisabledDataSisYn_1',
            ]

            _.forEach(isDisableDataDealcoClList, (data) => {
                this.isDisabled(data, !isValue)
            })
        },

        initIsDisabled(isValue) {
            this.disableDataList(isValue)
            this.disableDataBankList(isValue)
            this.disableDataDealcoClList(isValue)
        },

        initData() {
            let basPrmDealco = [
                'dealcoCl2List_1', //
                'dealcoCl3List_1', //
                'basPrmDealcoDtlCardList', // 카드단말기
                'basPrmDealcoDtlCrdList', // 담보
                'basPrmDealcoDtlDlvList', // 배송지
                'basPrmDealcoImagAccList', // 계좌정보
                'basPrmDealcoDtlListVo', // 거래처상세
                'basPrmDealcoDtlCmListVo', // 사업자등록정보
                'basPrmDealcoDtlCardListVo', // 카드단말기
                'basPrmDealcoDtlCrdListVo', // 담보
                'basPrmDealcoDtlDlvListVo', // 배송지
                'basPrmDealcoDtlChrgrListVo', // 영업담당자
                'basPrmDealcoDtlEarvCntListVo', // 전자결재 진행여부
                'basPrmDealcoImagAccListVo', // 전자결재 진행여부
            ] // 상세db정보
            _.forEach(basPrmDealco, (item) => {
                this.defaultAssign_({
                    key: item,
                    value: [],
                })
            })

            this.defaultAssign_({
                key: 'reqParams',
                value: this.initParam.pIsNew ? this.parentParam : [],
            })

            let infoData = [
                'dlvDealcoInfoData', // 배송지정보
                'newInfoData', // 신규정보
                'strdInfoData', // 기준정보
                'etcAddInfoData', // 물류창고/직영점/하부망 추가정보
                'acntInfoData', // 계좌정보
                'cltInfoData', // 담보정보
                'agencyAddInfoData', // 대리점 추가정보
            ] // 상세정보 param

            _.forEach(infoData, (item) => {
                this.defaultAssign_({
                    key: item,
                    value: {},
                })
            })

            this.storeSet('isGridStrdInfo', true)
            this.storeSet('isGridEtcAddInfo', true)
            this.storeSet('isGridBizRgstInfo', true)
            this.storeSet('isGridAcntInfo', true)
            this.storeSet('isGridCltInfo', true)
            this.storeSet('isGridDlvDealcoInfo', true)
            // this.initIsDisabled(true)
            this.loading(false)
        },

        clear() {},
        //팝업닫기
        closeBtn: function () {
            this.initData()
            this.activeOpen = false
        },

        // 거래처구분 조회
        getDealcoClList() {
            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]

            /**
             * addInfo1
             * 3X : 매입처
             * 2X : 제조사
             */
            _.forEach(this.zbasC00240, (data) => {
                if (
                    _.isEqual(data.addInfo1, this.etcAddInfoData1.dealcoGrpCd)
                ) {
                    let isDataUkey
                    if (
                        _.isEqual(data.addInfo1, '3X') ||
                        _.isEqual(data.addInfo1, '2X')
                    ) {
                        isDataUkey = false
                    } else {
                        let strdInfoParams = {}
                        strdInfoParams.mfactDealcoCd = '' // U.Key제조사 코드
                        strdInfoParams.sortSeq = '' // 제조사 정렬순서
                        this.storeSet('strdInfo', strdInfoParams)
                        isDataUkey = true
                    }

                    this.isDisabled('isDisabledDataUKey', isDataUkey) // ukey 제조사코드
                    defaultData.push(data)
                }
            })

            this.dealcoClList = defaultData
            this.storeSet('dealcoClList_1', defaultData)
            this.isDisabled('isDisabledDataDealcoCl2_1', true)
            this.isDisabled('isDisabledDataDealcoCl3_1', true)
            this.storeSet('dealcoCl2List_1', this.initList1) // 초기화
        },
        // 거래처구분 Change 이벤트
        changeDealcoCl2(code) {
            // 거래처유형 코드 구하기
            this.getDealcoCl2Data(code)
            this.getDealcoCl2DataList() // 거래처 유형 조회

            // 거래처분류 조회
            this.getDealcoCl3DataList() // 거래처 분류 조회
        },

        // 거래처 유형 코드조회
        getDealcoCl2Data(code) {
            let dealcoGrpCd = ''
            let addInfoYn = ''

            _.forEach(this.dealcoClList, (data) => {
                if (_.isEqual(code, data.commCdVal)) {
                    dealcoGrpCd = data.addInfo1
                    addInfoYn = data.addInfo4
                }
            })

            if (_.isEmpty(dealcoGrpCd)) {
                dealcoGrpCd = this.etcAddInfoData1.dealcoGrpCd
            }

            /**
             * dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */
            let etcAddInfoParams = {}
            let dealcoClCd2Code = ''
            let isDataDealcoClCd2 = false
            let isDataSisYn = false
            let isDataMaDirectYn = false

            if (_.isEqual(dealcoGrpCd, 'AY')) {
                if (_.isEqual(addInfoYn, 'Y')) {
                    dealcoClCd2Code = this.zbasC00110
                } else if (_.isEqual(addInfoYn, 'N')) {
                    dealcoClCd2Code = this.zbasC00570
                }
                if (
                    _.isEqual(code, 'A2') ||
                    _.isEqual(code, 'B1') ||
                    _.isEqual(code, 'AD') ||
                    _.isEqual(code, 'AE')
                ) {
                    isDataSisYn = true
                } else {
                    isDataSisYn = false
                }
            } else if (_.isEqual(dealcoGrpCd, 'YY')) {
                dealcoClCd2Code = this.zbasC00110
                if (_.isEqual(code, 'M1') || _.isEqual(code, 'M2')) {
                    // MA || B&C MA
                    isDataMaDirectYn = false
                } else {
                    isDataMaDirectYn = true
                    etcAddInfoParams.maDirectYn = '' // 직접운영 여부 초기화
                }
            } else if (_.isEqual(dealcoGrpCd, 'ZZ')) {
                dealcoClCd2Code = this.zbasC00110
            } else {
                isDataDealcoClCd2 = true
                isDataSisYn = false
            }
            this.isDisabled('isDisabledDataMaDirectYn_1', isDataMaDirectYn)
            this.isDisabled('isDisabledDataSisYn_1', isDataSisYn)
            this.isDisabled('isDisabledDataDealcoCl2_1', isDataDealcoClCd2)

            this.storeSet('dealcoCl2CodeData', dealcoClCd2Code)

            etcAddInfoParams.dealcoClCd2 = '' // 거래처유형 초기화
            this.storeSet('etcAddInfo', etcAddInfoParams)
        },
        // 거래처유형 조회
        getDealcoCl2DataList() {
            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]
            if (_.isEmpty(this.dealcoCl2CodeData)) {
                this.storeSet('dealcoCl2List_1', defaultData)
                this.isDisabled('isDisabledDataBankCdYn', true) // 출금계좌 off
            }

            /**
             * basPrmDealcoDtlVo.dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */
            _.forEach(this.dealcoCl2CodeData, (data) => {
                if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'AY')) {
                    if (
                        _.isEqual(
                            data.addInfo1,
                            'Y' || _.isEmpty(data.addInfo1)
                        ) &&
                        _.isEqual(data.commCdId, 'ZBAS_C_00110')
                    ) {
                        defaultData.push(data)
                    } else if (_.isEqual(data.commCdId, 'ZBAS_C_00570')) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'YY')) {
                    if (
                        _.isEqual(
                            data.addInfo2,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'ZZ')) {
                    if (
                        _.isEqual(
                            data.addInfo3,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                }
            })

            this.storeSet('dealcoCl2List_1', defaultData)
            this.isDisabled('isDisabledDataBankCdYn', true) // 출금계좌 off
        },

        // 거래처분류 조회
        getDealcoCl3DataList() {
            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]

            /**
             * basPrmDealcoDtlVo.dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */

            _.forEach(this.zbasC00530, (data) => {
                if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'AY')) {
                    if (
                        _.isEqual(
                            data.addInfo1,
                            'Y' || _.isEmpty(data.addInfo1)
                        ) &&
                        _.isEqual(data.commCdId, 'ZBAS_C_00110')
                    ) {
                        defaultData.push(data)
                    } else if (_.isEqual(data.commCdId, 'ZBAS_C_00570')) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'YY')) {
                    if (
                        _.isEqual(
                            data.addInfo2,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfoData1.dealcoGrpCd, 'ZZ')) {
                    if (
                        _.isEqual(
                            data.addInfo3,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                }
            })

            if (defaultData.length > 1 && _.isEmpty(defaultData[1].commCdVal)) {
                this.isDisabled('isDisabledDataDealcoCl3_1', true) // 거래처구분 off
                this.isDisabled('isDisabledDataBankCdYn', true) // 출금계좌 off
            }
            this.storeSet('dealcoCl3List_1', defaultData)
        },
        typeOfString(value) {
            if (typeof value === 'object') {
                if (_.isEmpty(value)) {
                    value = ''
                }
            }
            return value
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                if (!_.isEmpty(value)) {
                    this.searchParam.dealcoCd =
                        value['dealcoCd'] === undefined ? '' : value['dealcoCd']
                    this.searchParam.hstSeq =
                        value['hstSeq'] === undefined ? '' : value['hstSeq']
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        strdInfoData1: {
            handler: function (value) {
                let isGridStrdInfo = false // 기본정보
                let isGridEtcAddInfo = false // 추가정보
                let isGridBizRgstInfo = false // 사용자등록정보
                let isGridAcntInfo = false // 계좌정보
                let isGridCltInfo = false // 담보
                let isGridDlvDealcoInfo = false // 배송지
                if (!_.isEmpty(value)) {
                    // dealcoRgstClCd 거래처등록구분
                    // dealcoGrpCd 거래처그룹
                    // dealcoClCd1 거래처구분

                    if (
                        _.isEqual(value.dealcoRgstClCd, 'DC') && // 매장공통
                        _.isEqual(value.dealcoGrpCd, 'AY') && // 직영매장
                        (_.isEqual(value.dealcoClCd1, 'A2') || // 직영점
                            _.isEqual(value.dealcoClCd1, 'A6') || // 직영위탁
                            _.isEqual(value.dealcoClCd1, 'A7') || // 자영위탁직영
                            _.isEqual(value.dealcoClCd1, 'B1')) // 온라인직영
                    ) {
                        isGridStrdInfo = true // 기본정보
                        isGridEtcAddInfo = true // 추가정보
                        isGridBizRgstInfo = true // 사용자등록정보
                        isGridAcntInfo = true // 계좌정보
                        isGridCltInfo = true // 담보
                        isGridDlvDealcoInfo = true // 배송지
                        if (
                            _.isEqual(value.dealcoClCd1, 'A2') || // 직영점
                            _.isEqual(value.dealcoClCd1, 'B1') // 온라인직영
                        ) {
                            isGridCltInfo = false // 담보
                        }

                        if (_.isEqual(value.dealcoClCd1, 'B1')) {
                            // 온라인직영
                            isGridDlvDealcoInfo = false // 배송지
                        }
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'DC') && // 매장공통
                        _.isEqual(value.dealcoGrpCd, 'YY') // 하부망
                    ) {
                        isGridStrdInfo = true // 기본정보
                        isGridEtcAddInfo = true // 추가정보
                        isGridBizRgstInfo = true // 사용자등록정보
                        isGridAcntInfo = true // 계좌정보
                        isGridCltInfo = true // 담보
                        isGridDlvDealcoInfo = true // 배송지
                        if (_.isEqual(value.dealcoClCd1, 'B2')) {
                            // 온라인판매점
                            isGridDlvDealcoInfo = false // 배송지
                        }
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'DC') && // 매장공통
                        _.isEqual(value.dealcoGrpCd, '8X') && // 대형유통
                        (_.isEqual(value.dealcoClCd1, 'AE') || // 대형유통망직영
                            _.isEqual(value.dealcoClCd1, 'AF')) // 대영유통망위탁
                    ) {
                        isGridStrdInfo = true // 기본정보
                        isGridEtcAddInfo = true // 추가정보
                        isGridBizRgstInfo = true // 사용자등록정보
                        isGridAcntInfo = true // 계좌정보
                        isGridCltInfo = true // 담보
                        isGridDlvDealcoInfo = true // 배송지
                        if (_.isEqual(value.dealcoClCd1, 'AE')) {
                            // 대형유통망직영
                            isGridCltInfo = false // 담보
                        }
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'DS') && // 매장개별
                        _.isEqual(value.dealcoGrpCd, 'XX') && // 기타
                        (_.isEqual(value.dealcoClCd1, '81') || // 특판처
                            _.isEqual(value.dealcoClCd1, 'A9') || // 오입금환불
                            _.isEqual(value.dealcoClCd1, 'XZ')) // 기타거래처(1)
                    ) {
                        isGridStrdInfo = true // 기본정보
                        isGridEtcAddInfo = true // 추가정보
                        isGridBizRgstInfo = true // 사용자등록정보
                        isGridAcntInfo = true // 계좌정보
                        isGridCltInfo = true // 담보
                        isGridDlvDealcoInfo = true // 배송지
                        if (
                            _.isEqual(value.dealcoClCd1, '81') || // 특판처
                            _.isEqual(value.dealcoClCd1, 'A9') // 오입금환불
                        ) {
                            isGridBizRgstInfo = false // 사용자등록정보
                            isGridAcntInfo = false // 계좌정보
                            isGridCltInfo = false // 담보
                            isGridDlvDealcoInfo = false // 배송지
                        }
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'DS') && // 매장개별
                        _.isEqual(value.dealcoGrpCd, 'ZZ') && // 물류창고
                        (_.isEqual(value.dealcoClCd1, 'Z1') || // 물류창고
                            _.isEqual(value.dealcoClCd1, 'Z2')) // 위탁물류창고
                    ) {
                        isGridStrdInfo = true // 기본정보
                        isGridEtcAddInfo = true // 추가정보
                        isGridBizRgstInfo = false // 사용자등록정보
                        isGridAcntInfo = false // 계좌정보
                        isGridCltInfo = false // 담보
                        isGridDlvDealcoInfo = true // 배송지
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'EC') && // 기타공용
                        _.isEqual(value.dealcoGrpCd, '2X') && // 제조사
                        _.isEqual(value.dealcoClCd1, '20') // 제조사
                    ) {
                        isGridStrdInfo = true // 기본정보
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'EC') && // 기타공용
                        _.isEqual(value.dealcoGrpCd, '7X') && // 금융사
                        (_.isEqual(value.dealcoClCd1, '70') || // 카드사
                            _.isEqual(value.dealcoClCd1, '83') || // VAN사
                            _.isEqual(value.dealcoClCd1, '71')) // 은행
                    ) {
                        isGridStrdInfo = true // 기본정보
                    } else if (
                        _.isEqual(value.dealcoRgstClCd, 'ES') && // 기타개별
                        _.isEqual(value.dealcoGrpCd, 'XX') && // 기타
                        (_.isEqual(value.dealcoClCd1, '30') || // 매입처
                            _.isEqual(value.dealcoClCd1, 'XX')) // 기타거래터(2)
                    ) {
                        isGridStrdInfo = true // 기본정보
                    }
                }

                if (_.isEqual(this.orgInfo.orgCdLvl0, 'O00000')) {
                    // PS&M인 경우 담보노출
                    isGridCltInfo = true // 담보
                }

                this.storeSet('isGridStrdInfo', isGridStrdInfo) // 기본정보
                this.storeSet('isGridEtcAddInfo', isGridEtcAddInfo) // 추가정보
                this.storeSet('isGridBizRgstInfo', isGridBizRgstInfo) // 사용자등록정보
                this.storeSet('isGridAcntInfo', isGridAcntInfo) // 계좌정보
                this.storeSet('isGridCltInfo', isGridCltInfo) // 담보
                this.storeSet('isGridDlvDealcoInfo', isGridDlvDealcoInfo) // 배송지

                this.dealcoClCd1 = value.dealcoGrpCd
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>
