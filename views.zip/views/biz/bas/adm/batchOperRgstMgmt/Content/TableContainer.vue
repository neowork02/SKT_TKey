<template lang="">
    <div class="gridWrap">
        <TCRealGridHeader
            id="batchOperRgstMgmtGridHeader2"
            ref="batchOperRgstMgmtGridHeader2"
            gridTitle="목록"
            :gridObj="gridObj"
            :isPageRows="true"
            :isExceldown="true"
            :isNextPage="false"
            :isPageCnt="false"
            :editable="true"
            :isAddRow="true"
            :isDelRow="true"
            :addData="this.addData"
            @excelDownBtn="excelDownBtn"
            @addRowBtn="this.gridAddRowBtn"
            @chkDelRowBtn="this.gridchkDelRowBtn"
        >
        </TCRealGridHeader>
        <TCRealGrid
            id="batchOperRgstMgmtGrid2"
            ref="batchOperRgstMgmtGrid2"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
        <!-- <TCComPaging
            :totalPage="paging1.totalPageCnt"
            :apiFunc="pageMove"
            :rowCnt="paging1.pageSize"
            @input="pageSizeChange"
        /> -->
        <!-- <Detail1Popup
            v-if="showPopup1"
            :parentParam="searchPopup1"
            :rows="resultPopup1Rows"
            :dialogShow.sync="showPopup1"
            @confirm="onPopup1ReturnData"
        /> -->
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/batchOperRgstMgmt/helpers'
import { GRID_HEADER } from '@/const/grid/bas/adm/basAdmBatchOperRgstMgmtHeader'
import { CommonGrid } from '@/utils'
import CommonMsg from '@/utils/CommonMsg'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
// eslint-disable-next-line no-unused-vars
import attachedFileApi from '@/api/common/attachedFile'
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
//====================팝업1 팝업====================
//import Detail1Popup from './Detail1Popup'
//====================//팝업1 팝업====================
import CommonMixin from '@/mixins'
import JSZip from 'jszip'
export default {
    mixins: [CommonMixin],
    components: {
        //Detail1Popup,
    },
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '460px', //그리드 높이 조절
            },
            view: GRID_HEADER,
            layout: [
                'NO', //순번을 위한 가상컬럼
            ],
            /** 2. Grid 표현 영역 */
            gridDetailLayout: [
                //'chk',
                'NO', //순번을 위한 가상컬럼
                'bizId', //대분류업무구분ID
                'midId', //중분류업무구분ID
                'batchProgId', //배치프로그램ID
                'batNm', //배치명
                'runCycleCd', //수행주기코드
                'expStaDtm', //예상시작일시
                'expEndDtm', //예상종료일시
                'expRunDtm', //예상수행일시
                'batChrgrNm', //담당자명
                'rmks', //비고
                'delYn', //삭제여부
            ],
            addData: [
                '', //NO
                '', //bizId 대분류업무구분ID
                '', //midId 중분류업무구분ID
                '', //batchProgId 배치프로그램ID
                '', //batNm 배치명
                '', //runCycleCd 수행주기코드
                '', //expStaDtm 예상시작일시
                '', //expEndDtm 예상종료일시
                '', //expRunDtm 예상수행일시
                '', //batChrgrNm 담당자명
                '', //rmks 비고
                'N', //삭제여부
            ],
            //행추가,수정시 필수 입력 컬럼
            requiredCols: [
                'batchProgId', //배치프로그램ID
                'batNm', //배치명
                'bizId', //대분류업무구분ID
                'midId', //중분류업무구분ID
            ],
            popupRowIndex: '',
            // //====================팝업1 팝업관련====================
            // showPopup1: false, // 팝업1 팝업 오픈 여부
            // searchPopup1: {},
            // resultPopup1Rows: [], // 팝업1 팝업 오픈 여부
            // //====================//팝업1 팝업관련==================
        }
    },
    async mounted() {
        this.gridObj = this.$refs.batchOperRgstMgmtGrid2
        this.gridHeaderObj = this.$refs.batchOperRgstMgmtGridHeader2
        this.gridObj.gridView.setColumnLayout(this.gridDetailLayout)
        this.gridObj.gridView.setCopyOptions({
            singleMode: true,
            includeHeaderText: false,
        })

        /*
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         */
        //this.$refs.batchOperRgstMgmtGrid2.setGridState(true, true, true, false)
        //    this.gridObj.setGridState()
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(true, false, false, false)

        //체크바
        this.$refs.batchOperRgstMgmtGrid2.gridView.setCheckBar({
            visible: true,
        })
        //this.$refs.batchOperRgstMgmtGrid2.gridView.checkBar.fieldName = 'chk'

        //편집가능
        this.$refs.batchOperRgstMgmtGrid2.gridView.setEditOptions({
            editable: true,
            updatable: true,
            editWhenFocused: true,
            enterToTab: true,
        })
        //컬럼 고정
        // this.gridObj.gridView.setFixedOptions({
        //     colCount: 7,
        // })

        //특정컬럼 속성변경
        //this.gridObj.gridView.columnByName('NO').visible = false
        this.gridObj.gridView.columnByName('NO').editable = false

        //dropdown combo
        await this.dropDownSetting()

        //특정컬럼 속성변경
        //this.gridObj.gridView.columnByName('NO').visible = false
        this.gridObj.gridView.columnByName('NO').editable = false

        //컬럼 크기 자동
        this.$refs.batchOperRgstMgmtGrid2.gridView.displayOptions.fitStyle =
            'even' //'none' //

        //this.gridObj.gridView.summaryMode = 'aggregate' //footer 합계 표시

        // this.$refs.batchOperRgstMgmtGrid2.gridView.onCellDblClicked = (
        //     grid,
        //     clickData
        // ) => {
        //     console.log('onCellDblClicked', clickData.dataRow)
        //     this.gridPopup(clickData.dataRow, clickData.column)
        // }
        // this.$refs.batchOperRgstMgmtGrid2.gridView.onCellClicked = (grid, clickData) => {
        //     console.log('onCellClicked: ' + JSON.stringify(clickData))
        //     const col = clickData.column
        //     if (
        //         col == 'reqUserNm' ||
        //         col == 'reqUserId' ||
        //         col == 'reqUserNmMsk'
        //     ) {
        //         this.gridPopup(clickData.dataRow, clickData.column)
        //     }
        // }
    },
    computed: {
        ...serviceComputed,
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        saveAction1: {
            get() {
                return this.saveAction
            },
        },
    },
    methods: {
        ...serviceMethods,
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 9999, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
            this.gridObj.gridView.clearCurrent() //선택해제
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging',
                value: { ...this.paging, pageSize: pageSize },
            })
            if (this.paging1.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        excelDownBtn: function () {
            // let par1 = {
            //     ..._.clone(this.searchParams),
            //     exDownloadName: `BATCH작업등록관리_${moment(new Date()).format(
            //         'YYYYMMDDHHmmss'
            //     )}`,
            // }
            // attachedFileApi.downLoadFile(
            //     '/api/v1/backend-long/resource/bas/adm/tpay-result-list-excel',
            //     par1
            // )
            window.JSZip = window.JSZip || JSZip
            this.gridObj.gridView.exportGrid({
                type: 'excel',
                target: 'local',
                fileName: `BATCH작업등록관리_${moment(new Date()).format(
                    'YYYYMMDDHHmmss'
                )}.xlsx`,
                compatibility: 'MS Excel', //MS Excel 2007
                applyDynamicStyles: true,
                lookupDisplay: true,
                // done: function () {
                //     //내보내기 완료 후 실행되는 함수
                //     alert('done excel export')
                // },
            })
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            this.gridHeaderObj.setPageCount(this.paging)
        },
        gridAddRowBtn: function () {
            this.gridObj.gridView.commit()
            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            let focuscell = this.gridObj.gridView.getCurrent()
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
        },
        gridDelRowBtn: function () {
            // not used
            console.log('del current row')
            this.gridData.gridRows = this.gridHeaderObj.selDelRow()
        },
        gridchkDelRowBtn: function () {
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        async dropDownSetting() {
            //업무구분
            await this.dropDownCmmonCodes_({
                key: 'TKEY_BIS_ID',
                columnName: 'bizId',
                option: '선택',
            })
            await this.changeDropDown('bizId')
            //업무중분류
            await this.dropDownCmmonCodes_({
                key: 'TKEY_MID_ID',
                columnName: 'midId',
                option: '선택',
            })
            await this.changeDropDown('midId')

            //수동 콤보기입
            let obj1 = {}
            obj1['runCycleCd'] = {
                values: ['', 'HOUR', 'DAY', 'WEEK', 'MON'],
                labels: ['선택', 'Hourly', 'Daily', 'Weekly', 'Monthly'],
            }
            await this.defaultAssign_({
                key: 'commDropDown',
                value: { ...this.commDropDown, ...obj1 },
            })
            await this.changeDropDown('runCycleCd')
        },
        async changeDropDown(key) {
            let col1 = this.gridObj.gridView.columnByName(key)
            col1.values = this.commDropDown[key].values
            col1.labels = this.commDropDown[key].labels
            this.gridObj.gridView.setColumn(col1)
        },
        // eslint-disable-next-line no-unused-vars
        async gridPopup(row, col, val) {
            // const rowData1 = this.gridObj.dataProvider.getJsonRow(row)
            // if (
            //     col == 'reqUserNm' ||
            //     col == 'reqUserId' ||
            //     col == 'reqUserNmMsk'
            // ) {
            //     //사용자정보 팝업
            //     this.resultPopup4Rows = []
            //     this.popupRowIndex = row
            //     let popPar1 = {
            //         ...rowData1,
            //     }
            //     this.searchPopup4 = popPar1
            //     this.showPopup4 = true
            //     console.log('gridPopup 4 ', popPar1)
            // }
        },
        // 팝업1 팝업 리턴 이벤트 처리
        // async onPopup1ReturnData(retrunData) {
        //     console.log('retrunData: ', retrunData)
        //     // this.gridObj.gridView.commit()
        //     // this.gridObj.dataProvider.setValue(
        //     //     this.popupRowIndex,
        //     //     'agencyCd',
        //     //     retrunData.orgCd
        //     // )
        //     this.$emit('Refresh', '') //next paging api call
        // },
        errorCellFocus(chkCell, message) {
            this.showTcComSnackbar(message)
            //cell focus : { index: -1, fieldName: '' }
            this.gridObj.validationChkGrid(chkCell)
        },
        validationCheck() {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            var chk = { index: -1, fieldName: '' }
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.gridObj.dataProvider.getJsonRow(
                        index[i],
                        true
                    )

                    if (
                        row.__rowState == 'created' ||
                        row.__rowState == 'updated'
                    ) {
                        //필수 입력 체크
                        if (this.requiredCols.length) {
                            // created(추가) / updated(수정) 인경우 필수입력항목 체크
                            for (var j = 0; j < this.requiredCols.length; j++) {
                                //필수입력항목이 누락된경우
                                if (
                                    !row[this.requiredCols[j]] ||
                                    _.isEmpty(row[this.requiredCols[j]])
                                ) {
                                    chk.index = index[i]
                                    chk.fieldName = this.requiredCols[j]

                                    this.errorCellFocus(
                                        chk,
                                        this.gridObj.gridView.columnByField(
                                            chk.fieldName
                                        ).header.text + ' 필수 입력 입니다.'
                                    )
                                    return false
                                }
                            }
                        }

                        //적용일자 체크
                        // let fromDt = moment(row.aplyStaDt, 'YYYYMMDD').toDate()
                        // let toDt = moment(row.aplyEndDt, 'YYYYMMDD').toDate()
                        // if (fromDt > toDt) {
                        //     chk.index = index[i]
                        //     chk.fieldName = 'aplyStaDt'

                        //     this.errorCellFocus(
                        //         chk,
                        //         '적용시작일자가 적용마지막일자 보다 큽니다.'
                        //     )
                        //     return false
                        // }
                    }

                    //batchProgId 배치프로그램ID 중복 체크
                    if (row.__rowState == 'created') {
                        let all1 = this.gridObj.dataProvider.getJsonRows(0, -1)
                        let dup1 = all1.filter(
                            (e) => e.batchProgId === row.batchProgId
                        )
                        if (dup1.length > 1) {
                            chk.index = index[i]
                            chk.fieldName = 'batchProgId'

                            this.errorCellFocus(
                                chk,
                                '배치프로그램ID 중복 입니다.'
                            )
                            return false
                        }
                    }

                    //대리점 코드, 위탁창코 중복 체크
                    // if (row.__rowState == 'created') {
                    //     let all1 = this.gridObj.dataProvider.getJsonRows(0, -1)
                    //     let dup1 = all1.filter(
                    //         (e) => e.agencyCd === row.agencyCd
                    //     )
                    //     //대리점 체크
                    //     if (dup1.length > 1) {
                    //         chk.index = index[i]
                    //         chk.fieldName = 'agencyCd'

                    //         this.errorCellFocus(chk, '중복코드 입니다.')
                    //         return false
                    //     }
                    //     //위탁창고 체크
                    //     let dup2 = all1.filter(
                    //         (e) => e.cnsgHldPlcCd === row.cnsgHldPlcCd
                    //     )
                    //     if (dup2.length > 1 && row.cnsgHldPlcCd != '') {
                    //         chk.index = index[i]
                    //         chk.fieldName = 'cnsgHldPlcCd'

                    //         this.errorCellFocus(chk, '중복코드 입니다.')
                    //         return false
                    //     }
                    // }
                }
            } else {
                if (!this.gridData.delRows.length) {
                    this.showTcComSnackbar('저장할 자료가 없습니다.')
                    return false
                }
            }

            return true
        },
        async saveData() {
            let saveRows = []

            for (let i = 0; i < this.gridData.delRows.length; i++) {
                let e = this.gridData.delRows[i]
                saveRows.push({
                    ...e,
                    rowState: e.__rowState,
                })
            }

            var arr = []
            var cIndex = this.gridObj.dataProvider.getStateRows('created')
            var uIndex = this.gridObj.dataProvider.getStateRows('updated')
            arr.push(...cIndex)
            arr.push(...uIndex)
            for (var i = 0; i < arr.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(arr[i], true)
                saveRows.push({
                    ...row,
                    rowState: row.__rowState,
                })
            }

            //checkBar 를 사용할 경우 체크된 건만 저장처리
            // if (this.gridObj.gridView.checkBar.fieldName == 'chk') {
            //     saveRows = saveRows.filter((x) => {
            //         return (
            //             x['chk'] != null &&
            //             x['chk'] == 'true' &&
            //             x['origin'] != 'in'
            //         )
            //     })
            // }

            console.log('crud api call', saveRows)

            // 단독 저장일 경우 아래 코드 처리
            let res1 = await this.saveBatchOperRgstMgmt_({ saveRows })
            console.log('saveBatchOperRgstMgmt_', saveRows, res1)
            if (res1 == 1) {
                //저장후 다시 조회 하는 경우
                this.$emit('Refresh', '')
            }
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        resultList1(val, oldVal) {
            //console.log('resultList1 watched: ', val, oldVal, this.pageSize)
            this.gridObj.gridView.commit()
            this.gridObj.setRows(this.resultList1)

            //순번처리
            //let pageInfo = { ...this.paging1, type: 'paging' } //페이징의 경우
            let pageInfo = {} //페이징이 없는경우
            pageInfo.type = 'noPaging' //페이징이 없는경우
            pageInfo.totalDataCnt = this.resultList1.length //페이징이 없는경우

            this.gridObj.setGridIndicator(pageInfo, { sort: 'ASC' }) //역순으로 번호가 보임 DESC
            this.gridObj.gridView.clearCurrent() //선택해제
        },
        // eslint-disable-next-line no-unused-vars
        paging1(val, oldVal) {
            //console.log('paging1 watched: ', val)
            this.SetPaging()
        },
        async saveAction1(val, oldVal) {
            if (val == true) {
                console.log('saveAction1: ', val, oldVal)
                this.gridObj.gridView.commit()

                console.log('저장 호출 이벤트')

                if (this.validationCheck()) {
                    await this.saveData()
                } else {
                    console.log('validation false')
                }

                //에러든 정상종료든 완료되면 flag처리
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: true,
                })
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: true,
                })
            }
        },
    },
}
</script>
