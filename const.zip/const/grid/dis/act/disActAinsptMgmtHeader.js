import { ValueType } from 'realgrid'

// New T.key+ 보유 그리드
export const DisActAinsptMgmt_GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'hldPlcId',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, // 보유처
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'disTerm',
            dataType: ValueType.TEXT, // 재고기간
        },
        {
            fieldName: 'disHldDay',
            dataType: ValueType.TEXT, // 보유기간
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, // 상품구분코드
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
    ],
    columns: [
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcId',
            fieldName: 'hldPlcId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '보유처',
                showTooltip: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '140',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'disTerm',
            fieldName: 'disTerm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고기간',
                showTooltip: false,
            },
        },
        {
            name: 'disHldDay',
            fieldName: 'disHldDay',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유기간',
                showTooltip: false,
            },
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            visible: false,
        },
    ],
}

// 재고실사 그리드
export const DisActAinsptMgmt_GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT, // 재고상태
        },
        {
            fieldName: 'barYn',
            dataType: ValueType.TEXT, // 스캔여부
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직
        },
        {
            fieldName: 'hldPlcId',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, // 보유처
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
    ],
    columns: [
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '140',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고상태',
                showTooltip: false,
            },
        },
        {
            name: 'barYn',
            fieldName: 'barYn',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '스캔여부',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'hldPlcId',
            fieldName: 'hldPlcId',
            type: 'data',
            visible: false,
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            visible: false,
        },
    ],
}

// New T.key+에만 보유하고 있는 재고 그리드
export const DisActAinsptMgmt_GRID_HEADER3 = {
    fields: [
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직
        },
        {
            fieldName: 'hldPlcId',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, // 보유처
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, // 상품구분코드
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcId',
            fieldName: 'hldPlcId',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '보유처',
                showTooltip: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '140',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
        },
    ],
}

// 보유처에만 보유하고 있는 재고 그리드
export const DisActAinsptMgmt_GRID_HEADER4 = {
    fields: [
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직
        },
        {
            fieldName: 'hldPlcId',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, // 보유처
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, // 상품구분코드
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcId',
            fieldName: 'hldPlcId',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '보유처',
                showTooltip: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '140',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
        },
    ],
}
