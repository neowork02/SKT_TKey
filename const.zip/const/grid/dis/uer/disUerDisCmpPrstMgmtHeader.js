import { ValueType } from 'realgrid'

export const DisUerDisCmpPrstMgmt_GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'shopCd',
            dataType: ValueType.TEXT, //구분코드
        },
        {
            fieldName: 'shopNm',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'disCount',
            dataType: ValueType.NUMBER, //수량
        },
        {
            fieldName: 'inveCmpAmt',
            dataType: ValueType.NUMBER, //단가
        },
        {
            fieldName: 'inveCmpAmtSum',
            dataType: ValueType.NUMBER, //합계
        },
        {
            fieldName: 'etc',
            dataType: ValueType.TEXT, //비고
        },
    ],
    columns: [
        {
            name: 'shopCd',
            fieldName: 'shopCd',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구분',
                showTooltip: false,
            },
        },
        {
            name: 'shopNm',
            fieldName: 'shopNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '구분',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 200,
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 250,
            header: {
                text: '상품명',
                showTooltip: false,
            },
        },
        {
            name: 'disCount',
            fieldName: 'disCount',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'inveCmpAmt',
            fieldName: 'inveCmpAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            styleName: 'right-column',
            width: 150,
            header: {
                text: '단가',
                showTooltip: false,
            },
            footer: {
                text: 'Gap',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'inveCmpAmtSum',
            fieldName: 'inveCmpAmtSum',
            type: 'data',
            styleName: 'right-column',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            numberFormat: '#,##0',
            header: {
                text: '합계',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'etc',
            fieldName: 'etc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 300,
            header: {
                text: '비고',
                showTooltip: false,
            },
        },
    ],
}

export const DisUerDisCmpPrstMgmt_GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'polYm',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMM', //정책년월
        },
        {
            fieldName: 'polTs',
            dataType: ValueType.TEXT, //정책차수
        },
        {
            fieldName: 'aplyDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //보상일자
        },
        {
            fieldName: 'fixCrdtPrchsPrc',
            dataType: ValueType.NUMBER, //확정여신가
        },
        {
            fieldName: 'inveCmpAmt',
            dataType: ValueType.NUMBER, //재고보상금액
        },
        {
            fieldName: 'sknIfYn',
            dataType: ValueType.TEXT, //SKN I/F여부
        },
        {
            fieldName: 'sknIfNo',
            dataType: ValueType.TEXT, //SKN I/F일련번호
        },
        {
            fieldName: 'fstInFixDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //최초입고확정일자
        },
        {
            fieldName: 'fstPrchsPlcNm',
            dataType: ValueType.TEXT, //매입처
        },
        {
            fieldName: 'prchsSktCd',
            dataType: ValueType.TEXT, //매입처매장코드
        },
        {
            fieldName: 'newOrgNm',
            dataType: ValueType.TEXT, //최초입고조직
        },
        {
            fieldName: 'orgIdNm3',
            dataType: ValueType.TEXT, //최초입고팀
        },
        {
            fieldName: 'fstInPlcNm',
            dataType: ValueType.TEXT, //최초입고처
        },
        {
            fieldName: 'fstInSktCd',
            dataType: ValueType.TEXT, //최초입고처매장코드
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '상품명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'polYm',
            fieldName: 'polYm',
            header: {
                text: '정책년월',
            },
            datetimeFormat: 'yyyy-MM',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'polTs',
            fieldName: 'polTs',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정책차수',
                showTooltip: false,
            },
        },
        {
            name: 'aplyDt',
            fieldName: 'aplyDt',
            header: {
                text: '보상일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'fixCrdtPrchsPrc',
            fieldName: 'fixCrdtPrchsPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '확정여신가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'inveCmpAmt',
            fieldName: 'inveCmpAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '재고보상금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'sknIfYn',
            fieldName: 'sknIfYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: 'SKN I/F여부',
                showTooltip: false,
            },
        },
        {
            name: 'sknIfNo',
            fieldName: 'sknIfNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: 'SKN I/F일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'fstInFixDt',
            fieldName: 'fstInFixDt',
            header: {
                text: '최초입고확정일자',
            },
            width: 150,
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'fstPrchsPlcNm',
            fieldName: 'fstPrchsPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '매입처',
                showTooltip: false,
            },
        },
        {
            name: 'prchsSktCd',
            fieldName: 'prchsSktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 100,
            header: {
                text: '매입처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'newOrgNm',
            fieldName: 'newOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 300,
            header: {
                text: '최초입고조직',
                showTooltip: false,
            },
        },
        {
            name: 'orgIdNm3',
            fieldName: 'orgIdNm3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '최초입고팀',
                showTooltip: false,
            },
        },
        {
            name: 'fstInPlcNm',
            fieldName: 'fstInPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '최초입고처',
                showTooltip: false,
            },
        },
        {
            name: 'fstInSktCd',
            fieldName: 'fstInSktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 130,
            header: {
                text: '최초입고처매장코드',
                showTooltip: false,
            },
        },
    ],
}
