<template>
    <div class="content">
        <h1>Swing코드정보수신현황</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5_1">
                    <TCComComboBox
                        labelName="반영여부"
                        v-model="div_search.aplyYn"
                        :itemList="ds_apply"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="Swing코드 목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="flase"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getUKeyCodeList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
            <BasCdmCommCdRgst
                v-if="showBasCdmCommCdRgst"
                :parentParam="parentParam"
                :rows="resultCdmCommCdRgstRows"
                :dialogShow.sync="showBasCdmCommCdRgst"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
// import _ from 'lodash'
import { HEADER } from '@/const/grid/bas/adm/basAdmSwingCdInfoRcvPrstHeader'
import API from '@/api/biz/bas/adm/basAdmSwingCdInfoRcvPrstApi'
import CommonMixin from '@/mixins'
//====================공통코드관리==========================================
import BasCdmCommCdRgst from '@/views/biz/bas/cdm/BasCdmCommCdRgst'
// import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//=========================================================================

export default {
    name: 'BasAdmSwingCdInfoRcvPrst',
    components: { BasCdmCommCdRgst },
    mixins: [CommonMixin],

    data() {
        return {
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            rowCnt: 15,
            ds_apply: [
                { commCdVal: 'N', commCdValNm: '미반영' },
                { commCdVal: 'Y', commCdValNm: '반영' },
            ],
            //각각 엘리먼트 컴포넌트 v-model
            div_search: {
                aplyYn: '',
                idNm: '',
            },
            objAuth: {},
            selectedJsonData: {},
            selectedRow: '',
            ds_getUKeyCodeList: [],

            //====================공통코드관리=================================
            showBasCdmCommCdRgst: false,
            parentParam: {},
            resultCdmCommCdRgstRows: [],
            //================================================================
        }
    },

    created() {
        this.init()
        console.log('this.$route Detail: ', this.$route)
        // this.searchParam = this.$route.params.search
    },

    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState(true)

        // 더블클릭 시 등록팝업오픈
        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            console.log('등록팝업오픈', clickData)
            clearTimeout(this.clickState)
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                clickData.dataRow
            )
            this.grd_list_OnCellDblClick(jsonData)
        }

        // 싱글클릭 시 저장데이터 SET
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            this.selectedJsonData = this.gridObj.dataProvider.getJsonRow(
                clickData.dataRow
            )
            this.selectedRow = clickData.dataRow
            console.log('saveparam set', this.selectedJsonData)
            console.log('clickData.dataRow', clickData.dataRow)
        }
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.gridSetData()
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        //조회 버튼 이벤트
        onSearch: function () {
            this.gridData.totalPage = 0
            this.getUKeyCodeList(1)
        },

        getUKeyCodeList(pageNum) {
            let paramObj = {
                aplyYn: this.div_search.aplyYn,
                idNm: this.div_search.idNm,
            }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt

            // 페이징 조회
            API.getUKeyCodeList(paramObj).then((result) => {
                this.ds_getUKeyCodeList = result.gridList
                this.gridObj.setRows(result.gridList)
                // 페이징 관련
                this.gridObj.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData() //초기화
                this.gridData.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },

        // 초기화
        onResetPage() {
            CommonUtil.clearPage(this.$router)
        },

        // 더블클릭시 공통코드관리 팝업 호출
        grd_list_OnCellDblClick(jsonData) {
            console.log('jsonData' + jsonData)

            this.$router.push({
                name: '/bas/cdm/BasCdmCommCdRgst',
                params: { search: jsonData },
            })
        },
    },
}
</script>
