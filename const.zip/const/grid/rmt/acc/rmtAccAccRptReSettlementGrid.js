'use strict'

import { ValueType } from 'realgrid'
import { filter, gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: '__rowState',
        dataType: ValueType.TEXT,
        visible: false,
    },
    // {
    //     fieldName: 'orgNm3',
    //     editable: false,
    //     header: { text: '팀' },
    //     type: 'data',
    //     dataType: ValueType.TEXT,
    // },
    // {
    //     fieldName: 'orgNm4',
    //     editable: false,
    //     header: { text: 'PT' },
    //     type: 'data',
    //     dataType: ValueType.TEXT,
    // },
    {
        fieldName: 'orgTree',
        editable: false,
        header: { text: '조직' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'svcDt',
        editable: false,
        header: { text: '개통월(일)' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'summary',
        editable: false,
        header: { text: '요약' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'clNm',
        editable: false,
        header: { text: '구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accPlc',
        editable: false,
        header: { text: '정산처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accPlcNm',
        editable: false,
        header: { text: '정산처명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'salePlc',
        editable: false,
        header: { text: '판매처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'salePlcNm',
        editable: false,
        header: { text: '판매처명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeyChannelCd',
        editable: false,
        header: { text: '판매채널' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'saleTypNm',
        editable: false,
        header: { text: '판매유형' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'svcMgmtNum',
        editable: false,
        header: { text: '서비스관리번호' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'saleChrgrNm',
        editable: false,
        header: { text: '영업담당자' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'custNm',
        editable: false,
        header: { text: '고객명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'svcNum',
        editable: false,
        header: { text: '개통번호' },
        type: 'data',
        dataType: ValueType.TEXT,
        displayCallback: filter.grid.phoneNoSection,
    },
    {
        fieldName: 'eqpMdlNm',
        editable: false,
        header: { text: '모델' },
        type: 'data',
        styleName: 'left-column',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'eqpSerNum',
        editable: false,
        header: { text: '일련번호' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'prcplnNm',
        editable: false,
        header: { text: '요금제' },
        type: 'data',
        styleName: 'left-column',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'prcplnSect',
        editable: false,
        header: { text: '구간' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'chgPrcplnNm',
        editable: false,
        header: { text: '변경요금제' },
        type: 'data',
        styleName: 'left-column',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'chgPrcplnSect',
        editable: false,
        header: { text: '변경요금제구간' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'chgDt',
        editable: false,
        header: { text: '변경/해지일자' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'prodNm',
        editable: false,
        header: { text: '상품명' },
        type: 'data',
        styleName: 'left-column',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'reSvcNum',
        editable: false,
        header: { text: '서비스번호' },
        type: 'data',
        dataType: ValueType.TEXT,
        footer: {
            text: '합계',
        },
    },
    {
        fieldName: 'accAmt',
        editable: false,
        header: { text: '금액' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'rmks',
        editable: false,
        header: { text: '비고' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = [
    // 'orgNm3',
    // 'orgNm4',
    'orgTree',
    'svcDt',
    'summary',
    'clNm',
    {
        name: 'sellerInfo',
        header: { text: '판매정보' },
        direction: 'horizontal',
        items: [
            'accPlc',
            'accPlcNm',
            'salePlc',
            'salePlcNm',
            'ukeyChannelCd',
            'saleTypNm',
            'svcMgmtNum',
        ],
    },
    'saleChrgrNm',
    {
        name: 'customerInfo',
        header: { text: '고객정보' },
        direction: 'horizontal',
        items: ['custNm', 'svcNum'],
    },
    {
        name: 'deviceInfo',
        header: { text: '단말기정보' },
        direction: 'horizontal',
        items: ['eqpMdlNm', 'eqpSerNum'],
    },
    {
        name: 'customerInfo',
        header: { text: '요금제정보' },
        direction: 'horizontal',
        items: ['prcplnNm', 'prcplnSect'],
    },
    'chgPrcplnNm',
    'chgPrcplnSect',
    'chgDt',
    'prodNm',
    'reSvcNum',
    'accAmt',
    'rmks',
]
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {
    adpayMgmtVoList: [],
}

export { GRID_HEADER, MOCK_DATA }
