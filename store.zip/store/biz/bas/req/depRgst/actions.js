import api from '@/api/biz/bas/req/basReqDepRgst'
import types from './mutation-types'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    async dropDownCmmonCodes_({ state, commit }, { key, columnName, option }) {
        let result = await api.dropDownCmmonCodes_(key)
        let values = []
        let labels = []
        values = result.map((a) => a.commCdVal)
        labels = result.map((a) => a.commCdValNm)
        if (option != undefined) {
            values.unshift('')
            labels.unshift(option)
        }

        let obj1 = {}
        obj1[columnName] = {
            values: values,
            labels: labels,
        }
        commit(types.DEFAULT_ASSIGN, {
            key: 'commDropDown',
            value: { ...state.commDropDown, ...obj1 },
        })
    },
    // eslint-disable-next-line no-unused-vars
    async getBasReqDepMgmtDetails_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getBasReqDepMgmtDetails_', searchParams)
        await api.getBasReqDepMgmtDetails_({ searchParams }).then((data) => {
            console.log('🚀 ~ getBasReqDepMgmtDetails_ ~ .then ~ data', data)
            resultData = data
        })
        return resultData
    },
    // eslint-disable-next-line no-unused-vars
    async getBasReqDepTestDetails_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getBasReqDepTestDetails_', searchParams)
        await api.getBasReqDepTestDetails_({ searchParams }).then((data) => {
            console.log('🚀 ~ getBasReqDepTestDetails_ ~ .then ~ data', data)
            resultData = data
        })
        return resultData
    },
    // eslint-disable-next-line no-unused-vars
    async getBasReqDocMgmtList_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getBasReqDocMgmtList_', searchParams)
        await api.getBasReqDocMgmtList_({ searchParams }).then((data) => {
            console.log('🚀 ~ getBasReqDocMgmtList_ ~ .then ~ data', data)
            resultData = data
        })
        return resultData
    },
    // // eslint-disable-next-line no-unused-vars
    // async saveDocMgmt_({ state, commit }, formData) {
    //     console.log('🚀 ~ saveDocMgmt_ ~ formData', formData)
    //     let result = await api.saveDocMgmt_(formData)
    //     return result
    // },
    // eslint-disable-next-line no-unused-vars
    async saveDocMgmt_({ state, commit }, { saveRows }) {
        console.log('🚀 ~ file: actions.js ~ saveDocMgmt_ ~ saveRows', saveRows)
        let result = 0
        await api
            .saveDocMgmt_(saveRows)
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ saveDocMgmt_~ .then ~ data',
                    data
                )
                result = data
            })
            .catch((error) => {
                throw error
            })
        // const _sleep = (delay) =>
        //     new Promise((resolve) => setTimeout(resolve, delay))
        // const timer = async () => {
        //     await _sleep(1000)
        // }
        // await timer()
        return result
    },
}
