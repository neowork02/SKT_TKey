export const Demo = {
    prodCd: '', //상품코드
    prodNm: '' || undefined, //상품명
    colorCd: '', //색상코드
    colorNm: '' || undefined, //색상명
    serNum: '', // 일련번호
    demoRgstSeq: 0, //시연등록순번
    demoMgmtNo: 0, //시연관리번호
    demoYn: '', //시연여부
    tdayDemoYn: '', //변경여부
    demoRgstDt: '', //시연등록일자
    saleAmt: 0, //판매금액
    salePosDt: '', //판매가능일자
    rmks: '', //비고
    dealcoCd: '', //시연재고등록처코드
    hldDealcoCd: '' || undefined, //보유처코드
    hldPlcNm: '' || undefined, //보유처명
    delYn: 'N', //삭제여부
    updCnt: 0, //수정횟수
    insUserId: '', //입력사용자ID
    insDtm: '', //입력일시입력일시
    modUserId: '', //수정사용자ID
    modDtm: '', //수정 일시
}
