<template>
    <div>
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="거래처목록"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="paging1.totalPageCnt"
                :apiFunc="pageMove"
                :rowCnt="paging1.pageSize"
                @input="pageSizeChange"
            />
        </div>

        <DetailPopup
            v-if="localDialogShow"
            ref="popup"
            :dialogShow.sync="localDialogShow"
            :dtlData.sync="dtlParam"
        />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/etcDealcoMgmt/helpers'
import { CommonGrid } from '@/utils'

import { HEADER } from '@/const/grid/bas/adm/basAdmEtcDealcoMgmtHeader'
import DetailPopup from './PopupContainer.vue'
import _ from 'lodash'
import attachedFileApi from '@/api/common/attachedFile'

export default {
    name: 'TableContainer',
    components: { DetailPopup },
    data() {
        return {
            activePage: 1, // 현재페이지
            rowCnt: 30,
            localDialogShow: false,
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            layout: HEADER.layout,
            gridData: this.GridSetData(),
            dtlParam: {
                dealcoRgstClCd: '', // 거래처등록구분
                dealcoGrpNm: '', // 거래처그룹명
                dealcoCl1Nm: '', // 거래처구분코드명
                modUserNm: '', // 처리자
                dealcoCd: '', // 거래처코드
                dealCoNm: '', // 거래처명
                dealcoGrpCd: '', // 거래처그룹코드
                dealcoClCd1: '', // 거래처구분코드
                effStaDtm: '', // 유효시작일시
                effEndDtm: '', // 유효종료일시
                hstSeq: '', // 이력순번
                delYn: '', // 사용여부
            },
        }
    },
    mounted() {
        // grid
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader

        this.gridObj.setGridState(false, false, false)
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: 'No',
        })
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.displayOptions.selectionStyle = 'even'

        this.gridObj.gridView.setColumnLayout(this.layout)

        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            if (typeof clickData.itemIndex !== 'undefined') {
                _.forEach(HEADER.fields, (item) => {
                    const key = item.fieldName
                    this.dtlParam[key] = grid.getValue(clickData.itemIndex, key)
                })
                this.detailPopup()
            }
        }
    },
    computed: {
        ...serviceComputed,
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        searchParam: {
            get() {
                return this.searchParams
            },
        },
    },
    methods: {
        ...serviceMethods,
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging',
                value: { ...this.paging, pageSize: pageSize },
            })
            if (this.paging.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            this.gridHeaderObj.setPageCount(this.paging)
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/adm/etcDealcoMgmtExcelList',
                this.searchParam
            )
        },
        detailPopup() {
            this.localDialogShow = true
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
    },
    watch: {
        resultList1(val, oldVal) {
            console.log('resultList1 watched: ', val, oldVal, this.pageSize)
            this.gridObj.setRows(this.resultList)
        },
        paging1() {
            this.SetPaging()
        },
    },
}
</script>

<style scoped></style>
