<template>
    <div>
        <search-container ref="searchContainer" />
        <table-container @PopupOpen="PopupOpen" @Refresh="Refresh" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/docMgmt/helpers'
import SearchContainer from './SearchContainer.vue'
import TableContainer from './TableContainer.vue'
//import PopupContainer from './Popup/PopupContainer.vue'

export default {
    components: {
        SearchContainer,
        TableContainer,
        //PopupContainer,
    },
    data() {
        return {
            objAuth: {},
        }
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        PopupOpen(param) {
            this.$refs.popupContainer.open(param)
        },
        async Refresh() {
            console.log('emit refresh')
            //this.$refs.searchContainer.searchData() //paging api call
            await this.$refs.searchContainer.searchAllData(this.searchParams) //full search api call
        },
    },
}
</script>

<style></style>
