<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">관계사채권채무현황-상세</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParams.srchAgencyCd"
                                    labelName="D코드"
                                    :objAuth="objAuth"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParams.srchAgencyNm"
                                    labelName="D코드명"
                                    :objAuth="objAuth"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComDatePicker
                                    calType="M"
                                    v-model="searchParams.srchAccYm"
                                    labelName="정산월"
                                    :disabled="true"
                                >
                                </TCComDatePicker>
                            </div>
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="div5_5 cont1 left">
                            <div class="wrapTblDefault">
                                <table
                                    cellpadding="0"
                                    cellspacing="0"
                                    class="thCenter"
                                >
                                    <colgroup>
                                        <col style="width: 50%" />
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th class="ar">
                                                SKT 매출채권 내역
                                            </th>
                                            <th class="ar">금액</th>
                                        </tr>
                                        <tr>
                                            <td>위탁매출채권</td>
                                            <td class="ar">
                                                <span>
                                                    {{
                                                        popupParamsAmtList.saleCmmsAmt
                                                            | comma
                                                    }}
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>위탁조정매출채권</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.saleCmmsAdjAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>인센티브매출채권</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.prMnyAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>보조금매출채권</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.tbasAgrmtAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>할부채권</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.allotAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td
                                                class="ar"
                                                rowspan="2"
                                                id="total"
                                            >
                                                TOTAL
                                            </td>
                                            <td class="ar" id="total">
                                                {{
                                                    popupParamsAmtList.totSaleAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table
                                    cellpadding="0"
                                    cellspacing="0"
                                    class="thCenter"
                                >
                                    <colgroup>
                                        <col style="width: 50%" />
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th class="ar">
                                                SKN 매입채무 내역
                                            </th>
                                            <th class="ar">금액</th>
                                        </tr>
                                        <tr>
                                            <td>여신B</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.sknLoanCrdtAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td
                                                class="ar"
                                                rowspan="2"
                                                id="total"
                                            >
                                                TOTAL
                                            </td>
                                            <td class="ar" id="total">
                                                {{
                                                    popupParamsAmtList.sknLoanCrdtAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table
                                    cellpadding="0"
                                    cellspacing="0"
                                    class="thCenter"
                                >
                                    <colgroup>
                                        <col style="width: 50%" />
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th class="ar">입금구성항목</th>
                                            <th class="ar">금액</th>
                                        </tr>
                                        <tr>
                                            <td>SKT-USIM 매출입금금액</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.sktUsimSaleAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>할부채권(카드) 입금액</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.allotBondCardAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>판매수수료 입금액</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.resaleCmmsAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>SKT선지급입금액</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.sktAdvPayAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>공제후입금액</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.deductAftAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td
                                                class="ar"
                                                rowspan="2"
                                                id="total"
                                            >
                                                TOTAL
                                            </td>
                                            <td class="ar" id="total">
                                                {{
                                                    popupParamsAmtList.totDpstAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="div5_5 cont2 right">
                            <div class="wrapTblDefault">
                                <table
                                    cellpadding="0"
                                    cellspacing="0"
                                    class="thCenter"
                                >
                                    <colgroup>
                                        <col style="width: 50%" />
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th class="ar">
                                                SKT 채권잔액 검증
                                            </th>
                                            <th class="ar">금액</th>
                                            <th class="ar">비고</th>
                                        </tr>
                                        <tr>
                                            <td>총 매출채권</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.totSaleAmt
                                                        | comma
                                                }}
                                            </td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>개통여신1차공제-할부채권</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.sktAllotDeductAmt1
                                                        | comma
                                                }}
                                            </td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>개통여신2차공제-인센/위탁등</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.sktAllotDeductAmt2
                                                        | comma
                                                }}
                                            </td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>SKT입금액</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.totDpstAmt
                                                        | comma
                                                }}
                                            </td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>SKT공제항목</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.sktDeductEtcAmt
                                                        | comma
                                                }}
                                            </td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td
                                                class="ar"
                                                rowspan="2"
                                                id="total"
                                            >
                                                SKT채권잔액
                                            </td>
                                            <td class="ar" id="total">
                                                {{
                                                    popupParamsAmtList.sktLeftAmt
                                                        | comma
                                                }}
                                            </td>
                                            <td id="total"></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table
                                    cellpadding="0"
                                    cellspacing="0"
                                    class="thCenter"
                                >
                                    <colgroup>
                                        <col style="width: 50%" />
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th class="ar">
                                                SKT 채권 환수내역
                                            </th>
                                            <th class="ar">금액</th>
                                        </tr>
                                        <tr>
                                            <td>SKT할부채권공제1</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.sktAllotDeductAmt1
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>SKT할부채권공제2</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.sktAllotDeductAmt2
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>T-SELLER공제액</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.tsellerDeductAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>전대료공제액</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.rentDeductAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>SKT공제-그외</td>
                                            <td class="ar">
                                                {{
                                                    popupParamsAmtList.sktDeductEtcAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td
                                                class="ar"
                                                rowspan="2"
                                                id="total"
                                            >
                                                SKT채권잔액
                                            </td>
                                            <td class="ar" id="total">
                                                {{
                                                    popupParamsAmtList.totDeductAmt
                                                        | comma
                                                }}
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- //gridWrap -->

                        <!-- Bottom BTN Group -->
                        <div class="btn_area_bottom">
                            <TCComButton
                                :eLarge="true"
                                eClass="btn_ty02"
                                @click="onClose"
                            >
                                닫기
                            </TCComButton>
                        </div>
                        <!-- Close BTN-->
                        <a
                            href="#none"
                            class="layerClose b-close"
                            @click="onClose"
                            >닫기</a
                        >
                        <!--//Close BTN-->
                    </div>
                    <!-- //Popup_Cont -->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
export default {
    name: 'AccSssBondDebtPrstGridDtl',
    mixins: [CommonMixin],
    title: 'SKT수수료정산등록',
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            objAuth: {},

            searchParams: {
                agencyCd: '', // D 코드
                agencyNm: '', // D 코드명
                srchAccYm: '', // 정산월
            },

            popupParamsAmtList: {
                sktLeftAmt: '',
            },
        }
    },
    computed: {
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    filters: {
        comma(val) {
            return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        },
    },
    mounted() {
        console.log('popupMounted')
        this.searchParams.srchAccYm = this.popupParams.srchAccYm
        this.searchParams.srchAgencyCd = this.popupParams.agencyCd
        this.searchParams.srchAgencyNm = this.popupParams.agencyNm
        this.popupParamsAmtList = { ...this.popupParams }
        console.log(this.popupParamsAmtList)

        // SKT 채권잔액 검증 - SKT 채권잔액 값 구하기
        this.popupParamsAmtList.sktLeftAmt =
            this.popupParamsAmtList.totSaleAmt -
            this.popupParamsAmtList.sktAllotDeductAmt1 -
            this.popupParamsAmtList.sktAllotDeductAmt2 -
            this.popupParamsAmtList.sktUsimSaleAmt -
            this.popupParamsAmtList.allotBondCardAmt -
            this.popupParamsAmtList.resaleCmmsAmt -
            this.popupParamsAmtList.sktAdvPayAmt -
            this.popupParamsAmtList.deductAftAmt -
            this.popupParamsAmtList.sktDeductEtcAmt
        console.log(this.popupParamsAmtList.sktLeftAmt)
    },
    watch: {},
    methods: {
        onClose: function () {
            this.activeOpenAgency = false
        },
    },
}
</script>
<style>
table {
    margin-top: 20px;
    margin-bottom: 20px;
}
#total {
    background-color: #f6f6f8;
}
</style>
