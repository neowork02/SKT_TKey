<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <div class="btn_area_bottom">
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="closeBtn()"
                        >닫기</a
                    >
                </div>
                <p class="popTitle">전자결재 전송 신규 팝업</p>

                <div class="layerCont">
                    <ul class="btn_area pop">
                        <li class="left">
                            <input type="checkbox" />서류미비 선등록(지급보류 및
                            해제
                        </li>
                        <li class="right">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                @click="btnClick('1')"
                                :objAuth="objAuth"
                            >
                                결재전송
                            </TCComButton>
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                @click="btnClick('2')"
                                :objAuth="objAuth"
                            >
                                기안취소
                            </TCComButton>
                        </li>
                    </ul>
                    <div><h2>작성정보</h2></div>
                    <div>
                        <ul>
                            <li>제목 : 신규거래처 계약품의서_TEST_123</li>
                            <li>문서번호 : 188884478</li>
                        </ul>
                        <ul>
                            <li>작성자명 : 테스트</li>
                            <li>작성자사번 : OPS123345</li>
                        </ul>
                    </div>
                    <div><h2>문서내용</h2></div>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader1"
                            ref="gridHeader1"
                            gridTitle="기본정보"
                            :gridObj="gridObj"
                        />
                        <div>
                            <ul>
                                <li>사업자명(상호) : 테스트업체</li>
                                <li>사업자구분 : 직영점</li>
                                <li>거래처구분 : 1234</li>
                                <li>거래처코드 : 4567</li>
                            </ul>
                        </div>
                    </div>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader1"
                            ref="gridHeader1"
                            gridTitle="거래처 세부정보 입력"
                            :gridObj="gridObj"
                        />
                        <ul>
                            <li>거래처명 : 김거래</li>
                            <li>거래처주소 : 서울시 서초구 서초동 5</li>
                            <li>매장영업형태 : 테스트</li>
                        </ul>
                    </div>

                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader1"
                            ref="gridHeader1"
                            gridTitle="거래처 기타 정보 입력"
                            :gridObj="gridObj"
                        />
                        <ul>
                            <li>신용등급 : 1등급</li>
                            <li>
                                거래불가 등급 거래서 RISK 관리방안 : 신용우수
                            </li>
                            <li>
                                * 신용등급 7,8,9,10 등급 개설결재시 품의작성자
                                위 사유 기재
                            </li>
                        </ul>
                        <ul>
                            <li>매장경력 : 30년</li>
                            <li>주위평판 : 좋음</li>
                            <li>판매현황 : 판매왕</li>
                        </ul>
                    </div>
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { GRID_DTL } from '@/const/grid/bas/prm/basPrmDealcoEarvLnkgGrid'
import API from '@/api/biz/bas/prm/basPrmDealcoEarvLnkgSrch'

export default {
    name: 'DealCoEarvLnkgDtl',
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            //Paging Class init
            // gridData: this.GridSetData(),
            objAuth: {},
            view: GRID_DTL,
            view1: GRID_DTL,
            view2: GRID_DTL,
            view3: GRID_DTL,
            view4: GRID_DTL,
            view5: GRID_DTL,
            gridObj: {},
            gridHeaderObj: {},
            reqParam: this.dtlData,
            rowCnt: 10,
        }
    },
    created() {
        this.searchDtl()
    },
    mounted() {
        /****************** Grid **********************/
        // this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.popupGridHeader
        // this.gridObj.setGridState(true)
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        init: function () {
            // this.gridData = this.GridSetData()
        },
        //초기화 버튼 이벤트
        clearBtn: function () {},
        closeBtn: function () {
            this.activeOpen = false
        },
        //상세 조회
        searchDtl: function () {
            console.log('>>>>>' + JSON.stringify(this.reqParam))
            let paramObj = { ...this.reqParam }
            paramObj.stReqDt = '20220401' // todo 임시
            paramObj.endReqDt = '20220405' // todo 임시
            API.getDealcoEarvLnkgDtl(paramObj).then((res) => {
                //Get Row Data
                console.log('>>>> rtn')
                console.log(res)
                console.log(res.earvTypCd)
                // this.gridObj.setRows(res.gridList)
                // this.gridData = this.GridSetData() //초기화
            })
        },
        //Grid Paging Move(Append)
        gridAddPageBtn() {},
        btnClick(btnType) {
            if (btnType === '1') {
                alert('결재전송')
                return
            } else if (btnType === '2') {
                alert('기안취소')
                return
            }
        },
    },
}
</script>
