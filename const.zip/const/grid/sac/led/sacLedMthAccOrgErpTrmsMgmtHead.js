import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsDt', // 정산월
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgLvl', // 조직레벨
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmNm', // 구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmCd', // 구분 코드(전송항목코드)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsAmt', // 금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totCnt', // 전체건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranTryCnt', // 전송요청건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranCnt', // 전송건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranErrCnt', // 전송오류건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranNvlCnt', // 전송대상미존재
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranNotCnt', // 미전송건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNmShot', // 조직명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'trmsDt',
            fieldName: 'trmsDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산월',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '조직',
        },

        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'trmsItmNm',
            fieldName: 'trmsItmNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '구분',
        },
        {
            name: 'trmsAmt',
            fieldName: 'trmsAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '금액',
            numberFormat: '#,##0',
        },
        {
            name: 'totCnt',
            fieldName: 'totCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전체건수',
        },
        {
            name: 'tranTryCnt',
            fieldName: 'tranTryCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송요청건수',
        },
        {
            name: 'tranCnt',
            fieldName: 'tranCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송건수',
        },
        {
            name: 'tranErrCnt',
            fieldName: 'tranErrCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송오류건수',
        },
        {
            name: 'tranNvlCnt',
            fieldName: 'tranNvlCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송대상미존재',
        },
        {
            name: 'tranNotCnt',
            fieldName: 'tranNotCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '미전송건수',
        },
    ],
}
