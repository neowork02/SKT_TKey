<template>
    <div class="content">
        <h1>정산업로드판매점매핑 상세</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onMoveListClick"
                >
                    목록
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSaveClick"
                >
                    저장
                </TCComButton>
            </li>
        </ul>

        <div class="gridWrap">
            <TCRealGridHeader
                id="updSubMapDtlGridHeader"
                ref="updSubMapDtlGridHeader"
                gridTitle="목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="false"
            />
            <TCRealGrid
                id="updSubMapDtlGrid"
                ref="updSubMapDtlGrid"
                :fields="updSubMapDtlHeader.fields"
                :columns="updSubMapDtlHeader.columns"
                :editable="true"
                :updatable="true"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
// import CommonUtil from '@/utils/CommonUtil.js'
import { UPD_SUB_MAP_DTL_HEADER } from '@/const/grid/bas/adm/basAdmInfsUpdSubMapHeader'
import basAdmInfsUpdSubMapApi from '@/api/biz/bas/adm/basAdmInfsUpdSubMapApi'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'BasAdmInfsUpdSubMapDtlList',
    components: {},
    mixins: [CommonMixin],

    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            updSubMapDtlHeader: UPD_SUB_MAP_DTL_HEADER,
            //각각 엘리먼트 컴포넌트 v-model
            searchParam: {
                templetSeq: null,
                seq: null,
            },
        }
    },

    created() {
        this.init()
    },

    mounted() {
        this.gridObj = this.$refs.updSubMapDtlGrid
        this.gridHeaderObj = this.$refs.updSubMapDtlGridHeader
        this.gridObj.setGridState(false, false, true, false)
        // 번호 설정(리얼 그리드에서 제공해주는 순번)
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: 'No',
        })
        this.setGridEvent()
        this.getUpdSubMapDtlList()
    },

    methods: {
        init() {
            this.gridData = this.gridSetData()

            if (!_.isEmpty(this.$route.params.parentParam)) {
                this.searchParam.seq = this.$route.params.parentParam.seq
                this.searchParam.templetSeq =
                    this.$route.params.parentParam.templetSeq
            }
        },

        gridSetData() {
            return new CommonGrid(0, 15, '', '')
        },

        setGridEvent() {
            // 사용자 입력이 셀에 반영함을 결정하는 콜백
            this.gridObj.gridView.onEditCommit = (grid) => {
                grid.editOptions.commitByCell = true
            }
        },

        getGridEditRows() {
            // 아래 commit을 해야 Row 값을 가져올 수 있음
            this.gridObj.gridView.commit()

            const arr = []
            const uIndex = this.gridObj.dataProvider.getStateRows('updated')
            arr.push(...uIndex)

            let jsonData = []
            arr.forEach((data) => {
                jsonData = [
                    ...jsonData,
                    this.gridObj.dataProvider.getJsonRow(data, true),
                ]
            })
            return jsonData
        },

        // 목록 버튼 이벤트
        onMoveListClick() {
            this.$router.push({
                name: '/bas/adm/BasAdmInfsUpdSubMapList',
                params: {
                    parentSearchParam: this.$route.params.parentSearchParam,
                },
            })
        },

        // 저장
        onSaveClick() {
            this.setUpdSubMap()
        },

        getUpdSubMapDtlList() {
            basAdmInfsUpdSubMapApi
                .getUpdSubMapDtlList(this.searchParam)
                .then((result) => {
                    this.gridObj.dataProvider.setRows(result)
                })
        },

        async setUpdSubMap() {
            // const gridEditRows = this.getGridEditRows()
            // console.log('gridEditRows: ', gridEditRows)

            const selectedRows = []
            const checkedRows = this.gridObj.gridView.getCheckedRows(false)
            if (!checkedRows.length) {
                this.showTcComAlert('맵핑할 목록 정보를 선택해 주세요.')
                return
            }

            checkedRows.forEach((item) => {
                const row = this.gridObj.dataProvider.getJsonRow(item)
                selectedRows.push(row)
            })

            const confirm = await this.showTcComConfirm('저장 하시겠습니까?')

            if (confirm) {
                basAdmInfsUpdSubMapApi.setUpdSubMap(selectedRows).then(() => {
                    this.getUpdSubMapDtlList()
                })
            }
        },
    },
}
</script>
