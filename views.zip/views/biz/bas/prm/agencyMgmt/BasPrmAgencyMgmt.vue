<!-----------------------------------------------
 * 업무그룹명: 기준정보>영업기준정보관리
 * 서브업무명: 대리점관리
 * 설명: 대리점관리 조회/입력/수정/삭제 한다.
 * 작성자: P180392
 * 작성일: 2022.04.27
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content1">
        <div class="content">
            <main-content ref="mainContent" />
        </div>
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/agencyMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/prm/agencyMgmt'

export default {
    name: 'BasPrmAgencyMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (this.$store.hasModule('bas.prm.agencyMgmtStore') != true) {
            this.$store.registerModule('bas.prm.agencyMgmtStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.prm.agencyMgmtStore') == true) {
            this.$store.unregisterModule('bas.prm.agencyMgmtStore')
        }
    },

    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>

<style>
.content1 {
    display: flex;
    height: 800px;
    gap: 1em;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
}
</style>
