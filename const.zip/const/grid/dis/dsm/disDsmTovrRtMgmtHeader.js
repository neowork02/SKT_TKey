import { ValueType } from 'realgrid'

export const DisDsmTovrRtMgmtGRID_LAYOUT = [
    'NO',
    'orgNm',
    'dealSktCd',
    'dealcoCd',
    'dealcoNm',
    'prodNm',
    {
        name: '현재고',
        direction: 'horizontal',
        items: [
            'dd30',
            'du30d60',
            'du60d90',
            'du90d150',
            'du150d240',
            'du240',
            'dtotal',
            'ddisHldDayAvg',
        ],
        header: {
            text: '현재고',
        },
    },
    {
        name: '판매재고',
        direction: 'horizontal',
        items: [
            'sd30',
            'su30d60',
            'su60d90',
            'su90d150',
            'su150d240',
            'su240',
            'stotal',
            'sdisHldDayAvg',
        ],
        header: {
            text: '판매재고',
        },
    },
]

export const DisDsmTovrRtMgmtGRID_HEADER = {
    fields: [
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dd30',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'du30d60',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'du60d90',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'du90d150',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'du150d240',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'du240',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dtotal',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ddisHldDayAvg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sd30',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'su30d60',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'su60d90',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'su90d150',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'su150d240',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'su240',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'stotal',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sdisHldDayAvg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '140',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'dd30',
            fieldName: 'dd30',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '30일이전',
                showTooltip: false,
            },
        },
        {
            name: 'du30d60',
            fieldName: 'du30d60',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '30일초과',
                showTooltip: false,
            },
        },
        {
            name: 'du60d90',
            fieldName: 'du60d90',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '60일초과',
                showTooltip: false,
            },
        },
        {
            name: 'du90d150',
            fieldName: 'du90d150',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '90일초과',
                showTooltip: false,
            },
        },
        {
            name: 'du150d240',
            fieldName: 'du150d240',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '150일초과',
                showTooltip: false,
            },
        },
        {
            name: 'du240',
            fieldName: 'du240',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '240일초과',
                showTooltip: false,
            },
        },
        {
            name: 'dtotal',
            fieldName: 'dtotal',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '합계',
                showTooltip: false,
            },
        },
        {
            name: 'ddisHldDayAvg',
            fieldName: 'ddisHldDayAvg',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '평균보유일',
                showTooltip: false,
            },
        },
        {
            name: 'sd30',
            fieldName: 'sd30',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '30일이전',
                showTooltip: false,
            },
        },
        {
            name: 'su30d60',
            fieldName: 'su30d60',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '30일초과',
                showTooltip: false,
            },
        },
        {
            name: 'su60d90',
            fieldName: 'su60d90',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '60일초과',
                showTooltip: false,
            },
        },
        {
            name: 'su90d150',
            fieldName: 'su90d150',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '90일초과',
                showTooltip: false,
            },
        },
        {
            name: 'su150d240',
            fieldName: 'su150d240',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '150일초과',
                showTooltip: false,
            },
        },
        {
            name: 'su240',
            fieldName: 'su240',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '240일초과',
                showTooltip: false,
            },
        },
        {
            name: 'stotal',
            fieldName: 'stotal',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '합계',
                showTooltip: false,
            },
        },
        {
            name: 'sdisHldDayAvg',
            fieldName: 'sdisHldDayAvg',
            type: 'data',
            numberFormat: '#,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '평균보유일',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            visible: false,
            type: 'data',
        },
    ],
}
