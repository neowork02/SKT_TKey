<template>
    <div>
        <ul class="btn_area top">
            <!-- <li class="left">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="regBtn"
                    :objAuth="this.objAuth"
                >
                    요건서 등록
                </TCComButton>
            </li> -->
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComDatePicker
                        v-model="schdDt"
                        :calType="calType5"
                        labelName="요청일자"
                    />
                </div>
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="요청구분"
                        v-model="formSearchParams.reqClCd"
                        :itemList="searchCode[0]"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    />
                </div>
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="진행상태"
                        v-model="formSearchParams.reqStNm"
                        :itemList="searchCode[1]"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div3">
                    <TCComInputSearchText
                        labelName="요청대리점"
                        v-model="searchAuthOrgParam.orgNm"
                        :codeVal.sync="searchAuthOrgParam.orgCd"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                </div>
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="개발담당자"
                        v-model="formSearchParams.devClCd"
                        :itemList="searchCode[2]"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    />
                </div>
                <div class="formitem div3">
                    <TCComInput
                        v-model="formSearchParams.reqTitle"
                        labelName="요건명"
                        :size="150"
                        :maxlength="100"
                        :objAuth="objAuth"
                        @input="inputEvent()"
                        @enterKey="searchBtn"
                    />
                </div>
            </div>
        </div>
        <BasBcoAuthOrgTreesPopup
            v-if="showBcoAuthOrgTrees"
            :parentParam="searchAuthOrgParam"
            :rows="resultAuthOrgTreeRows"
            :dialogShow.sync="showBcoAuthOrgTrees"
            @confirm="onAuthOrgTreeReturnData"
        />
        <!-- <Detail1Popup
            v-if="showPopup1"
            :parentParam="searchPopup1"
            :rows="resultPopup1Rows"
            :dialogShow.sync="showPopup1"
            @confirm="onPopup1ReturnData"
        /> -->
    </div>
</template>
<script>
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/depMgmt/helpers'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
// eslint-disable-next-line no-unused-vars
import commonApi from '@/api/common/commonCode'
//import CommonUtil from '@/utils/CommonUtil.js'
// eslint-disable-next-line no-unused-vars
import { msgTxt } from '@/const/msg.Properties.js'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees' //--BasReqDaySalePrst.vue code 사용참조
//====================//내부조직팝업(권한)팝업====================
//====================팝업1 팝업====================
//import Detail1Popup from './Detail1Popup'
//import Detail1Popup from '@/views/biz/bas/req/docRgst/BasReqDocRgst.vue'
//====================//팝업1 팝업====================
import CommonMixin from '@/mixins'
export default {
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        //Detail1Popup,
    },
    async created() {},
    data() {
        return {
            objAuth: {},
            calType5: 'DP', //'M' //'DP' //'D'
            schdDt: [],
            searchCode: [
                [
                    {
                        commCdVal: '신규요건',
                        commCdValNm: '신규요건',
                    },
                    {
                        commCdVal: '변경요건',
                        commCdValNm: '변경요건',
                    },
                    {
                        commCdVal: '오류수정',
                        commCdValNm: '오류수정',
                    },
                    {
                        commCdVal: '데이타보정',
                        commCdValNm: '데이타보정',
                    },
                    {
                        commCdVal: '데이타추출',
                        commCdValNm: '데이타추출',
                    },
                    {
                        commCdVal: '운영업무',
                        commCdValNm: '운영업무',
                    },
                ],
                [
                    // {
                    //     commCdVal: '요청',
                    //     commCdValNm: '요청',
                    // },
                    // {
                    //     commCdVal: '승인',
                    //     commCdValNm: '승인',
                    // },
                    // {
                    //     commCdVal: '반려',
                    //     commCdValNm: '반려',
                    // },
                    // {
                    //     commCdVal: '취소',
                    //     commCdValNm: '취소',
                    // },
                    {
                        commCdVal: '진행',
                        commCdValNm: '진행',
                    },
                    // {
                    //     commCdVal: '1차테스트',
                    //     commCdValNm: '1차테스트',
                    // },
                    // {
                    //     commCdVal: '2차테스트',
                    //     commCdValNm: '2차테스트',
                    // },
                    {
                        commCdVal: '배포',
                        commCdValNm: '배포',
                    },
                    {
                        commCdVal: '취소',
                        commCdValNm: '취소',
                    },
                    // {
                    //     commCdVal: '완료',
                    //     commCdValNm: '완료',
                    // },
                ],
                [], //개발담당자 api 호출용
            ],
            //clsDt: '',
            payDtFrom: '',
            payDtTo: '',
            orgCd: '' /*조직코드*/,

            formSearchParams: {
                reqDt: '',
                reqDtFrom: '',
                reqDtTo: '',
                uuid: '',
                reqClCd: '',
                reqOrgCd: '',
                reqUserNm: '',
                reqStNm: '',
                reqTitle: '',
                devClCd: '',
                reqStNmCl: '',
            },
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchAuthOrgParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                orgLvl: '',
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            // //====================팝업1 팝업관련====================
            // showPopup1: false, // 팝업1 팝업 오픈 여부
            // searchPopup1: {},
            // resultPopup1Rows: [], // 팝업1 팝업 오픈 여부
            // //====================//팝업1 팝업관련==================
        }
    },
    async mounted() {
        console.log('depMgmt SearchContainer')
        commonApi.getCommonCodeListById('ZADM_C_00010').then((commData) => {
            const devComm = commData.map((a) => {
                return {
                    commCdVal: a.commCdValNm + '담당',
                    commCdValNm: a.commCdValNm + '담당',
                }
            })
            this.searchCode[2] = devComm
            console.log('ZADM_C_00010', commData)
        })

        await this.initData()

        //화면초기 로딩시 바로 검색
        await this.searchBtn()
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        copyObjExist(obj1, obj2) {
            Object.keys(obj2).forEach(function (key) {
                if (key in obj1) {
                    obj1[key] = _.isEmpty(obj2[key]) ? '' : obj2[key]
                }
            })
        },
        initObj(obj1) {
            for (let prop in obj1) {
                if (Object.prototype.hasOwnProperty.call(obj1, prop)) {
                    obj1[prop] = ''
                }
            }
        },
        async initData() {
            let today = moment(new Date()).add(-7, 'd').format('YYYY-MM-DD')
            let today1 = moment(new Date()).format('YYYY-MM-DD')
            this.schdDt = [today, today1]

            this.searchAuthOrgParam.orgNm = '' /*조직코드*/
            this.searchAuthOrgParam.orgLvl = '' /*조직코드*/
            this.searchAuthOrgParam.orgCd = '' /*조직코드*/

            this.initObj(this.formSearchParams)

            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
        },
        async initBtn() {
            await this.initData()
            //this.searchBtn() //이화면은 초기화가 다시 조회처리

            //CommonUtil.clearPage(this.$router)
        },
        async regBtn() {
            //this.searchPopup1 = {} //추가
            //this.showPopup1 = true
            console.log('요건서등록 flag on')
            await this.defaultAssign_({
                key: 'popupOpenNew',
                value: true,
            })
            this.$nextTick(() => {
                this.defaultAssign_({
                    key: 'popupOpenNew',
                    value: false,
                })
            })
        },
        async searchBtn() {
            let payDtFrom = new Date(this.schdDt[0])
            let payDtTo = new Date(this.schdDt[1])
            if (payDtFrom > payDtTo) {
                this.showTcComAlert('시작일자가 마지막일자 보다 큽니다.')
                return
            }
            // if (
            //     moment(payDtFrom).format('YYYY-MM') !=
            //         moment(payDtTo).format('YYYY-MM') &&
            //     _.isEmpty(this.formSearchParams.svcMgmtNum)
            // ) {
            //     this.showTcComAlert('같은 월 검색만 됩니다.')
            //     return
            // }
            // if (_.isEmpty(this.searchAuthOrgParam.orgCd)) {
            //     this.showTcComAlert('조직은 필수 입니다.')
            //     return //test 시 조건 해제
            // }

            // //this.formSearchParams.clsDt = this.clsDt.replace(/-/g, '')
            // this.formSearchParams.payDtFrom = this.schdDt[0].replace(/-/g, '')
            // this.formSearchParams.payDtTo = this.schdDt[1].replace(/-/g, '')

            this.formSearchParams.reqStNmCl = 'dev'
            this.formSearchParams.reqDtFrom = this.schdDt[0].replace(/-/g, '')
            this.formSearchParams.reqDtTo = this.schdDt[1].replace(/-/g, '')
            this.formSearchParams.reqOrgCd = this.searchAuthOrgParam.orgCd
            // this.formSearchParams.orgLvl = this.searchAuthOrgParam.orgLvl
            // this.formSearchParams.agencyCd = this.searchParamAgency.agencyCd //대리점
            // this.formSearchParams.sktSubCd = this.searchSwingDealIfForm.sktSubCd //수납처

            await this.defaultAssign_({ key: 'paging', value: this.initPaging })

            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 197 ~ searchBtn ~ this.formSearchParams',
                this.formSearchParams
            )
            let par1 = _.clone(this.formSearchParams)

            // Test data
            // let par1 = {
            //     reqDt: '',
            //     reqDtFrom: '',
            //     reqDtTo: '',
            //     uuid: '',
            //     reqClCd: '',
            //     reqOrgCd: '',
            //     reqUserNm: '',
            //     reqStNm: '',
            //     reqTitle: '',
            //     devClCd: '',
            // }

            await this.defaultAssign_({
                key: 'searchParams',
                value: par1,
            })
            //페이징 조회 ------------------------------
            //await this.searchData()

            //전체조회 --------------------------------
            await this.searchAllData(par1)
        },
        // async searchData() {
        //     //페이징 조회 ------------------------------
        //     await this.getBasReqDocMgmtList_()
        // },
        async searchAllData(param1) {
            //전체조회 --------------------------------
            let data = await this.getBasReqDocMgmtDetails_({
                param: param1,
            })
            if (data.length > 0) {
                await this.defaultAssign_({
                    key: 'resultList',
                    value: data,
                })
            } else {
                await this.defaultAssign_({
                    key: 'resultList',
                    value: [],
                })
            }
        },
        async inputEvent() {},
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchAuthOrgParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchAuthOrgParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchAuthOrgParam.orgNm = _.get(res[0], 'orgNm')
                        this.searchAuthOrgParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchAuthOrgParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            this.onAuthOrgTreeIconClick()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchAuthOrgParam.orgCd = ''
            this.searchAuthOrgParam.orgLvl = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchAuthOrgParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchAuthOrgParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchAuthOrgParam.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //====================내부거래처 팝업====================
        // 팝업1 팝업 리턴 이벤트 처리
        async onPopup1ReturnData(returnData) {
            console.log('Popup1 returnData new: ', returnData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     returnData.orgCd
            // )
            //저장후 다시 조회 하는 경우
            //this.$emit('Refresh')
            //this.searchBtn()
            await this.searchAllData(this.searchParams)
        },
    },
}
</script>
