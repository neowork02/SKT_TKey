import { ValueType } from 'realgrid'

export const DisDtrDisMovInDtlGRID_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixYnOrg',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outFixDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'barCdType',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'movSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disBadYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disDisStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disLastInoutClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disLastInoutDtlClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mthCloseMovInYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mthCloseMovInDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lastInoutDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'barCdTypCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            header: {
                text: '상품구분',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            header: {
                text: '제조사',
                showTooltip: false,
            },
            width: '210',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            header: {
                text: '모델',
                showTooltip: false,
            },
            width: '370',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            header: {
                text: '색상',
                showTooltip: false,
            },
            width: '170',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            header: {
                text: '일련번호',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'inFixYn',
            fieldName: 'inFixYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고확정',
                checkLocation: 'right',
            },
            renderer: {
                type: 'check',
                editable: true,
                trueValues: 'Y',
                falseValues: 'N',
                startEditOnClick: true,
            },
        },
        {
            name: 'inFixYnOrg',
            fieldName: 'inFixYnOrg',
            type: 'data',
            visible: false,
        },
        {
            name: 'outFixDt',
            fieldName: 'outFixDt',
            type: 'data',
            visible: false,
        },
        {
            name: 'outMgmtNo',
            fieldName: 'outMgmtNo',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'mfactCd',
            fieldName: 'mfactCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'disStCd',
            fieldName: 'disStCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'barCdType',
            fieldName: 'barCdType',
            visible: false,
            type: 'data',
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'movSeq',
            fieldName: 'movSeq',
            visible: false,
            type: 'data',
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            visible: false,
            type: 'data',
        },
        {
            name: 'inFixQty',
            fieldName: 'inFixQty',
            visible: false,
            type: 'data',
        },
        {
            name: 'inFixDt',
            fieldName: 'inFixDt',
            visible: false,
            type: 'data',
        },
        {
            name: 'disBadYn',
            fieldName: 'disBadYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'disDisStCd',
            fieldName: 'disDisStCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'disDealcoCd',
            fieldName: 'disDealcoCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'disLastInoutClCd',
            fieldName: 'disLastInoutClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'disLastInoutDtlClCd',
            fieldName: 'disLastInoutDtlClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'mthCloseMovInYn',
            fieldName: 'mthCloseMovInYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'mthCloseMovInDt',
            fieldName: 'mthCloseMovInDt',
            visible: false,
            type: 'data',
        },
        {
            name: 'lastInoutDt',
            fieldName: 'lastInoutDt',
            visible: false,
            type: 'data',
        },
    ],
}
