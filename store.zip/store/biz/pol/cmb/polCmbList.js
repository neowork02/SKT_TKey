/*****************************************
* 업무 그룹명 : B대리점정책관리
* 서브 업무명 : B대리점정책관리
* 설 명 : B대리점정책관리 Store
* 작 성 자 : 정일수
* 작 성 일 : 2022.11.28
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 
* 변경사유/내역 : 
======================================
*****************************************/
// import send from '@/api/axios-tdcs'
// import _ from 'lodash'
import moment from 'moment'

export default {
    namespaced: true,
    state: {
        storeParam: {
            searchDt: moment().format('YYYY-MM'),
            orgNm: '',
            orgCd: '',
            orgLvl: '',
            writer: '',
            operNm: '',
            operCd: '',
            subjCd: '',
            grpCd: '',
            kndCd: '',
            statusCd: '',
            vatCd: '',
            hisYn: '',
            polNm: '',
            vLevel: '2',
            all: 'Y',
            lvOrgCd: '',
        },
    },
    mutations: {
        setStoreParam(state, data) {
            state.storeParam = data
        },
    },
    actions: {},
    getters: {},
}
