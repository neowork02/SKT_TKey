import { ValueType } from 'realgrid'

export const GRID_INFO = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'simulOpDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procDtFr',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procDtTo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'simulReqUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'simulReqUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'execStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'execStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gubun',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'simulOpDt',
            fieldName: 'simulOpDt',
            type: 'data',
            width: '100',
            header: {
                text: '신청일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'procDtFr',
            fieldName: 'procDtFr',
            type: 'data',
            width: '100',
            header: {
                text: '시작대상일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'procDtTo',
            fieldName: 'procDtTo',
            type: 'data',
            width: '100',
            header: {
                text: '종료대상일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'simulReqUserNm',
            fieldName: 'simulReqUserNm',
            type: 'data',
            width: '100',
            header: {
                text: '신청자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'execStNm',
            fieldName: 'execStNm',
            type: 'data',
            width: '150',
            header: {
                text: '진행상태',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}
