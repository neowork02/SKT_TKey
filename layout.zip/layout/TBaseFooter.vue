<script>
export default {
    name: 'layout-footer',

    methods: {},
}
</script>
<template>
    <div class="footer">
        <!-- Footer -->
        <div class="footerWrap">
            <!--span class="logo_foot"></span-->
            <p class="address">
                대표 : 유영상 <span class="bar">|</span> 주소 서울특별시 중구
                을지로 2가11
                <!-- <span class="cs">콜센터 : 02-6496-8988 </span> -->
            </p>
            <p class="copyright">
                COPYRIGHT 2023 BY SK TELECOM ALL RIGHTS RESERVED
            </p>
        </div>
    </div>
    <!-- Footer // -->
</template>
