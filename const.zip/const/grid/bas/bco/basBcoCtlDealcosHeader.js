import { ValueType } from 'realgrid'

export const BAS_BCO_CTL_DEALCOS_HEADER = {
    fields: [
        {
            fieldName: 'orgNmTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'crdtTypCdCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'crdtTypCdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'grtInstCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'grtInstCdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'setBasisDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'setDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expirDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mrtgAmt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mrtgSetAmt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mrtgSetAmtSum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dtlCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'setAmt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgNmTree',
            fieldName: 'orgNmTree',
            type: 'data',
            width: 350,
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '조직',
            },
        },
        {
            name: 'dealEndYn',
            fieldName: 'dealEndYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래상태',
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '거래처명',
            },
        },
        {
            name: 'bizNo',
            fieldName: 'bizNo',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업자번호',
            },
        },
        {
            name: 'crdtTypCdNm',
            fieldName: 'crdtTypCdNm',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신유형',
            },
        },
        {
            name: 'grtInstCdNm',
            fieldName: 'grtInstCdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보증기관',
            },
        },
        {
            name: 'setBasisDesc',
            fieldName: 'setBasisDesc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '설정근거',
            },
        },
        {
            name: 'setDt',
            fieldName: 'setDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '설정일',
            },
        },
        {
            name: 'expirDt',
            fieldName: 'expirDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '만료일',
            },
        },
        {
            name: 'mrtgAmt',
            fieldName: 'mrtgAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '담보금액',
            },
        },
        {
            name: 'mrtgSetAmt',
            fieldName: 'mrtgSetAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '설정금액',
            },
        },
        {
            name: 'mrtgSetAmtSum',
            fieldName: 'mrtgSetAmtSum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '담보잔액',
            },
        },
        {
            name: 'dtlCnt',
            fieldName: 'dtlCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '공유담보거래처수',
            },
        },
    ],
}
