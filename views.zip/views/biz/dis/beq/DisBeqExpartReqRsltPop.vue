<!-----------------------------------------------
 * 업무그룹명: 불량기기관리현황
 * 서브업무명: Swing 교품신청결과 상세
 * 설명: Swing 교품신청결과 상세 조회한다.
 * 작성자: P179234
 * 작성일: 2022.06.7
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>

<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">Swing 교품신청결과 상세</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="모델"
                                    :disabled="true"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.prodNm"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="일련번호"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.serNum"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="색상"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="badProd.colorNm"
                                >
                                </TCComInput>
                            </div>
                        </div>
                    </div>

                    <div class="contBoth">
                        <div class="div5_5 cont1 left">
                            <div class="stitHead pop">
                                <h4 class="subTit">교품신청정보</h4>
                            </div>
                            <div class="searchLayer_wrap">
                                <div class="searchform">
                                    <div class="formitem div1">
                                        <TCComInput
                                            labelName="교품신청점"
                                            :disabled="true"
                                            :eRequired="false"
                                            :objAuth="objAuth"
                                            v-model="badProd.expartReqPlcNm"
                                        >
                                        </TCComInput>
                                    </div>
                                </div>
                                <div class="searchform">
                                    <div class="formitem div1">
                                        <TCComDatePicker
                                            labelName="교품신청일"
                                            :disabled="true"
                                            calType="D"
                                            :eRequired="false"
                                            :objAuth="objAuth"
                                            v-model="badProd.expartReqDt"
                                        />
                                    </div>
                                </div>
                                <div class="searchform">
                                    <div class="formitem div1">
                                        <TCComInput
                                            labelName="교품신청자"
                                            :disabled="true"
                                            :eRequired="false"
                                            :objAuth="objAuth"
                                            v-model="badProd.expartRgstNm"
                                        >
                                        </TCComInput>
                                    </div>
                                </div>
                                <!-- <div class="searchform">
                                    <div class="formitem div1">
                                        <TCComInput
                                            labelName="영업담당"
                                            :disabled="true"
                                            :eRequired="false"
                                            :objAuth="objAuth"
                                            v-model="badProd.chrgrUserNm"
                                        >
                                        </TCComInput>
                                    </div>
                                </div>
                                <div class="searchform">
                                    <div class="formitem div1">
                                        <TCComInput
                                            labelName="판매점"
                                            :disabled="true"
                                            :eRequired="false"
                                            :objAuth="objAuth"
                                            v-model="badProd.saleDealcdNm"
                                        >
                                        </TCComInput>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                        <div class="div5_5 cont2 right">
                            <div class="stitHead pop">
                                <h4 class="subTit">교품결과정보</h4>
                            </div>
                            <div class="searchLayer_wrap">
                                <div class="searchform">
                                    <div class="formitem div1">
                                        <TCComInput
                                            labelName="교품신청 처리결과"
                                            :disabled="true"
                                            labelClass="line2"
                                            :eRequired="false"
                                            :objAuth="objAuth"
                                            v-model="badProd.expartOpStNm"
                                        >
                                        </TCComInput>
                                    </div>
                                </div>
                                <div class="searchform">
                                    <div class="formitem div1">
                                        <TCComInput
                                            labelName="교품신청사유"
                                            :disabled="true"
                                            :eRequired="false"
                                            :objAuth="objAuth"
                                            v-model="badProd.expartOpCttNm"
                                        >
                                        </TCComInput>
                                    </div>
                                </div>
                                <div class="searchform">
                                    <div class="formitem div1">
                                        <TCComInput
                                            labelName="교품불가사유"
                                            :disabled="true"
                                            :eRequired="false"
                                            :objAuth="objAuth"
                                            v-model="badProd.expartNoRsnNm"
                                        >
                                        </TCComInput>
                                    </div>
                                </div>
                                <div class="searchform">
                                    <div class="formitem div1">
                                        <TCComDatePicker
                                            labelName="배송예정일"
                                            :disabled="true"
                                            calType="D"
                                            :eRequired="false"
                                            :objAuth="objAuth"
                                            v-model="badProd.expartDlvSchdDt"
                                        >
                                        </TCComDatePicker>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="closeBtn"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- //Bottom BTN Group -->
                </div>
                <a href="#none" class="layerClose b-close" @click="closeBtn"
                    >닫기</a
                >
            </div>
        </template>
    </TCComDialog>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 콜백 서비스 아이디
------------------------------------------------>
<script>
import disBeqBadProdApi from '@/api/biz/dis/beq/disBeqBadProdMgmt.js'
import CommonMixin from '@/mixins'
export default {
    name: 'ExpartReqRsltPop',
    mixins: [CommonMixin],
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        expartReqRslt: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            objAuth: {},
            badProd: this.expartReqRslt,
            searchForms: {},
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        console.log(this.badProd)
        this.search()
    },
    methods: {
        async search() {
            this.searchForms = { ...this.badProd }
            // testdata
            // this.searchForms = {
            //     prodCd: '09033',
            //     prodNm: '',
            //     colorCd: '99',
            //     serNum: '02085563',
            //     rgstSeq: '1',
            // }
            // testdata
            await disBeqBadProdApi
                .getBadProdChgRslt(this.searchForms)
                .then((res) => {
                    if (res) {
                        this.badProd = Object.assign(this.badProd, res)
                    } else {
                        this.showTcComAlert(
                            '교품신청 정보가 존재하지않는 상품입니다.'
                        )
                        setTimeout(() => {
                            this.closeBtn()
                        }, 1500)
                    }
                })
        },
        closeBtn() {
            this.activeOpen = false
        },
    },
}
</script>
