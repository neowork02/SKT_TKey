import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'dataClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'tranTm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'hhmmss',
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'connIp',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'screenId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'screenNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'actionClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custInfo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'queryClNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'dataClNm',
            fieldName: 'dataClNm',
            header: {
                text: '데이터구분',
            },
        },
        {
            name: 'tranDt',
            fieldName: 'tranDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조회일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'tranTm',
            fieldName: 'tranTm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조회시간',
            },
            datetimeFormat: 'hh:mm:ss',
        },
        {
            name: 'userId',
            fieldName: 'userId',
            header: {
                text: '사용자ID',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            header: {
                text: '사용자명',
            },
        },
        {
            name: 'connIp',
            fieldName: 'connIp',
            header: {
                text: '조회IP',
            },
        },
        {
            name: 'screenId',
            fieldName: 'screenId',
            header: {
                text: '화면URL',
            },
            width: '200',
        },
        {
            name: 'screenNm',
            fieldName: 'screenNm',
            header: {
                text: '화면명',
            },
        },
        {
            name: 'actionClNm',
            fieldName: 'actionClNm',
            header: {
                text: '수행업무',
            },
        },
        {
            name: 'custInfo',
            fieldName: 'custInfo',
            header: {
                text: '고객정보',
            },
        },
        {
            name: 'queryClNm',
            fieldName: 'queryClNm',
            header: {
                text: '조회구분',
            },
        },
    ],
}
