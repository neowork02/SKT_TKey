import { ValueType } from 'realgrid'
// import { DisOpnOpenStMgmtRgst_GRID_HEADER } from '../../dis/opn/disOpnOpenStMgmtRgstHeader'

export let GRID_PROPERTYINFO_APLY = {
    fields: [
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
            booleanFormat: 'N:Y',
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'sktChnlCd', // 채널코드
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'lvOrgNm', // 조직레벨0
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1', // 조직레벨1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2', // 조직레벨2
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpCd', // 거래처그룹코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1', // 거래처구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd2', // 거래처유형코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoCd', // 재고보유처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn', // 거래상태
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        // {
        //     name: 'orgTree',
        //     fieldName: 'orgTree',
        //     type: 'data',
        //     width: '120',
        //     header: {
        //         text: '조직',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },

        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '120',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },

        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '80',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '120',
            header: {
                text: '거래처',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        // {
        //     name: 'sktChnlCd',
        //     fieldName: 'sktChnlCd',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '채널코드',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm',
        //     fieldName: 'lvOrgNm',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨0',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm1',
        //     fieldName: 'lvOrgNm1',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨1',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm2',
        //     fieldName: 'lvOrgNm2',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨2',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        {
            name: 'dealcoGrpCd',
            fieldName: 'dealcoGrpCd',
            type: 'data',
            width: '80',
            header: {
                text: '거래처그룹',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            type: 'data',
            width: '80',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'dealcoClCd2',
            fieldName: 'dealcoClCd2',
            type: 'data',
            width: '80',
            header: {
                text: '거래처유형',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '재고보유처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        {
            name: 'dealEndYn',
            fieldName: 'dealEndYn',
            type: 'data',
            width: '80',
            header: {
                text: '거래상태',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
    ],

    layout: [
        // 'orgTree', //조직
        'dealSktCd', //매장코드
        'dealcoCd', // 거래처코드
        'dealcoNm', // 거래처명
        // 'sktChnlCd', // 채널코드
        // 'lvOrgNm', // 조직레벨0
        // 'lvOrgNm1', // 조직레벨1
        // 'lvOrgNm2', // 조직레벨2
        'dealcoGrpCd', // 거래처그룹코드
        'dealcoClCd1', // 거래처구분코드
        'dealcoClCd2', // 거래처유형코드
        'accDealcoCd', // 정산처코드
        'hldDealcoCd', // 재고보유처코드
        'dealEndYn', // 거래상태
    ],
}

export let GRID_PROPERTYINFO_RGST = {
    fields: [
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
            booleanFormat: 'N:Y',
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'sktChnlCd', // 채널코드
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'lvOrgNm', // 조직레벨0
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1', // 조직레벨1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2', // 조직레벨2
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpCd', // 거래처그룹코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1', // 거래처구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd2', // 거래처유형코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoCd', // 재고보유처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn', // 거래상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            type: 'data',
            width: '120',
            header: {
                text: '조직',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },

        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '120',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '80',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '120',
            header: {
                text: '거래처',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        // {
        //     name: 'sktChnlCd',
        //     fieldName: 'sktChnlCd',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '채널코드',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm',
        //     fieldName: 'lvOrgNm',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨0',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm1',
        //     fieldName: 'lvOrgNm1',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨1',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm2',
        //     fieldName: 'lvOrgNm2',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨2',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        {
            name: 'dealcoGrpCd',
            fieldName: 'dealcoGrpCd',
            type: 'data',
            width: '80',
            header: {
                text: '거래처그룹',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            type: 'data',
            width: '80',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'dealcoClCd2',
            fieldName: 'dealcoClCd2',
            type: 'data',
            width: '80',
            header: {
                text: '거래처유형',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '재고보유처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        {
            name: 'dealEndYn',
            fieldName: 'dealEndYn',
            type: 'data',
            width: '80',
            header: {
                text: '거래상태',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
    ],

    layout: [
        'dealcoCd', // 거래처코드
        'dealcoNm', // 거래처명
        // 'sktChnlCd', // 채널코드
        // 'lvOrgNm', // 조직레벨0
        // 'lvOrgNm1', // 조직레벨1
        // 'lvOrgNm2', // 조직레벨2
        'dealcoGrpCd', // 거래처그룹코드
        'dealcoClCd1', // 거래처구분코드
        'dealcoClCd2', // 거래처유형코드
        'accDealcoCd', // 정산처코드
        'hldDealcoCd', // 재고보유처코드
        'dealEndYn', // 거래상태
    ],
}
