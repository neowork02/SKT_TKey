import { ValueType } from 'realgrid'

export const DisInnInMgmtDtlGRID_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'barCdType',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
            width: '220',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
            width: '430',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
            width: '190',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
            width: '180',
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'mfactCd',
            fieldName: 'mfactCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'disStCd',
            fieldName: 'disStCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            visible: false,
            type: 'data',
        },
        {
            name: 'barCdType',
            fieldName: 'barCdType',
            visible: false,
            type: 'data',
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'inSeq',
            fieldName: 'inSeq',
            visible: false,
            type: 'data',
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            visible: false,
            type: 'data',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            visible: false,
            type: 'data',
        },
    ],
}
