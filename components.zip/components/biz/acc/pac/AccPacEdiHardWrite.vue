<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccPacEdiAccMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div>
        <AccGridTable
            ref="accGridTable"
            isEditable
            isColumnNo
            isCheckbox
            :isExcelupParse="true"
            :offset="['btn-addRow', 'btn-deleteRow', 'btn-excelDownload']"
            :preventEvent="[
                'clickDeleteRow',
                'clickAddRow',
                'clickExcelDownload',
            ]"
            :gridMeta="GRID_HEADER"
            :data="data"
            :pagingInfo="pagingInfo"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/pac/card-hnds-excel-download`,
                query: query,
            }"
            :popupParamCardCoCd="popupParamSearchCardCoCd"
            @clickCell="clickCellButton"
            @rowUpdated="rowUpdated"
            @movePage="movePage"
            @changePageSize="changePageSize"
            @excelDownload="excelDownload"
            @deleteRow="deleteRow"
            @addRow="addRow"
            @excelUpParseloadBtn="excelUpParseloadBtn"
        />

        <v-file-input
            id="excelUpload"
            ref="excelUpload"
            label="엑셀업로드 파일선택(숨김)"
            style="display: none"
            @change="onChangeExcelFile"
        ></v-file-input>

        <!-- 거래처팝업 -->
        <PopupDealcoClCd1
            v-if="popupDealcoClCd1.status.show"
            :parentParam="popupParamDealCoCd"
            :dialogShow.sync="popupDealcoClCd1.status.show"
            @confirm="changeDealcoClCd1"
        />

        <!-- 매입사팝업 -->
        <PopupCardCoCd
            v-if="popupCardCoCd.status.show"
            :parentParam="popupParamCardCoCd"
            :rows="popupCardCoCd.query"
            :dialogShow.sync="popupCardCoCd.status.show"
            @confirm="changeCardCoCd"
        />
    </div>
</template>

<script>
import _ from 'lodash'

import pacApi from '@/api/biz/acc/pac'

// import { gridMetaUtil } from '@/utils/accUtil'

import attachApi from '@/api/common/attachedFile'

import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import { GRID_HEADER } from '@/const/grid/acc/pac/accPacEdiHardWriteGrid'

import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup' // 내부거래처(권한조직) 팝업
import BasBcoCommCdDtlPopup from '@/components/common/BasBcoCommCdDtlPopup' // 공통팝업

import attachedFileApi from '@/api/common/attachedFile'

export default {
    name: 'AccPacEdiHardWrite',
    mixins: [CommonMixin, accMixin],
    components: {
        AccGridTable,
        PopupDealcoClCd1: BasBcoDealcosPopup,
        PopupCardCoCd: BasBcoCommCdDtlPopup,
    },
    props: {
        data: {
            default: () => [],
        },

        pagingInfo: {
            default: () => ({
                totalPageCnt: 0,
            }),
        },

        query: {
            default: () => ({}),
        },
    },
    data() {
        return {
            GRID_HEADER,
            popupDealcoClCd1: {
                query: {},
                status: {
                    show: false,
                },
            },

            popupCardCoCd: {
                query: [],
                status: {
                    show: false,
                },
            },

            // 검색영역 매입사 팝업전달
            popupParamSearchCardCoCd: {
                commCdId: 'ZBAS_C_00050',
            },

            // 그리드영역 매입사 팝업전달
            popupParamCardCoCd: {
                commCdId: 'ZBAS_C_00050',
            },

            popupParamDealCoCd: {},
        }
    },
    created() {},
    methods: {
        clickCellButton(row, rowIdx, rowInfo) {
            switch (rowInfo.fieldName) {
                case 'salePlc':
                    this.popupParamDealCoCd.basDay = row.aprvDt // 승인일자
                    this.popupParamDealCoCd.orgCd =
                        row.orgCd || this.query.orgCd || '' // 조직코드
                    this.popupParamDealCoCd.orgNm =
                        row.orgNm || this.query.orgNm || '' // 조직명

                    this.popupDealcoClCd1.query.rowIdx = rowIdx
                    this.popupDealcoClCd1.status.show = true
                    break

                case 'prchCoCd':
                    this.popupCardCoCd.query.rowIdx = rowIdx
                    this.popupCardCoCd.status.show = true
                    break
            }
        },
        excelUpParseloadBtn() {
            document.getElementById('excelUpload').click()
        },

        onChangeExcelFile: function (xlsData) {
            if (!_.isUndefined(xlsData) && !_.isNull(xlsData)) {
                const formData = new FormData()
                formData.append('files', xlsData)
                pacApi.getParseExcelEdiTcip(formData).then((res) => {
                    console.log('res', res)
                    const rows = res
                    console.log('rows', rows)
                    rows.forEach((row) => {
                        row.rowStatus = '신규'
                        row.__rowState = 'created'
                    })
                    this.$emit('excelUpParseloadBtn', rows)
                    this.$nextTick(() => {
                        rows.map((arr, idx) => {
                            this.accGridTable.setRowStateInIdx(idx, 'created')
                        })
                    })
                    throw new Error('err')
                })
                // 파일선택 inputbox의 값 제거
                document.getElementById('excelUpload').value = ''
            }
        },

        rowUpdated(row, rowIdx) {
            const rowData = Object.assign({}, row)
            rowData.cmmsAmt = rowData.aprvAmt - rowData.payAmt

            if (rowData.__rowState != 'created') {
                rowData.rowStatus = '수정'
                rowData.__rowState = 'updated'
            }

            this.accGridTable.modifyRowData(rowIdx, rowData)

            this.$emit('rowUpdated', rowData)
        },

        deleteRow(rows, rowIdx) {
            const removeRows = []
            rows.forEach((arr, idx) => {
                if (arr.__rowState == 'deleted') {
                    this.accGridTable.modifyRowData(rowIdx[idx], {
                        rowStatus: '',
                        __rowState: '',
                    })
                } else if (arr.__rowState == 'created') {
                    removeRows.push(rowIdx[idx])
                } else {
                    this.accGridTable.modifyRowData(rowIdx[idx], {
                        rowStatus: '삭제',
                        __rowState: 'deleted',
                    })
                }
            })

            if (removeRows.length) {
                this.accGridTable.removeRowData(removeRows)
            }
        },

        addRow() {
            // 그리드 행 추가
            this.accGridTable.dataProvider.insertRow(0, [])

            // 그리드 데이터 수정
            this.accGridTable.modifyRowData(0, {
                rowStatus: '신규',
                __rowState: 'created',
            })

            // 그리드 수정으로 인한 상태값 변경을 추가로 복원
            this.accGridTable.setRowStateInIdx(0, 'created')
        },

        changeDealcoClCd1(model) {
            const row = {
                salePlc: model.dealcoCd,
                salePlcNm: model.dealcoNm,
            }

            this.$refs.accGridTable.modifyRowData(
                this.popupDealcoClCd1.query.rowIdx,
                row
            )

            this.$emit('changeDealcoClCd1', model)
        },

        changeCardCoCd(model) {
            const row = {
                prchCoCd: model.commCdVal,
                prchCoNm: model.commCdValNm,
            }

            this.$refs.accGridTable.modifyRowData(
                this.popupCardCoCd.query.rowIdx,
                row
            )

            this.$emit('changeCardCoCd', model)
        },

        movePage(query) {
            this.$emit('movePage', query)
        },

        changePageSize(query) {
            this.$emit('changePageSize', query)
        },
        excelDownload() {
            if (this.data.length == 0) {
                attachApi.downloadSampleFile('420')
            } else {
                attachedFileApi.downLoadFile(
                    `/api/v1/backend-max/resource/acc/pac/card-hnds-excel-download`,
                    this.query
                )
            }
        },
    },
}
</script>
