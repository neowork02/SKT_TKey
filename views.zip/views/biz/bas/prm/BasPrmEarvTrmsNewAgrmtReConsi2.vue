<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">전자결재 전송 신규계약재품의</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Top BTN + form -->
                    <ul class="btn_area top pop">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="btn_earvSnd_OnClick"
                                >결재전송</TCComButton
                            >
                            <TCComButton :eOutlined="true" eClass="btn_ty"
                                >기안취소</TCComButton
                            >
                        </li>
                        <li class="right">
                            <div class="multiForm">
                                <TCComCheckBox
                                    labelName=""
                                    v-model="ds_detail.BASIC_0"
                                    :itemList="Checkbox4"
                                    cols="12"
                                />
                            </div>
                            <div class="multiForm ml10">
                                <TCComInput labelName="서류전송이력" />
                            </div>
                        </li>
                    </ul>
                    <!-- // Top BTN + form -->

                    <!-- SubTit -->
                    <div class="stitHead line mgt">
                        <h4 class="subTitLine">작성정보</h4>
                    </div>
                    <!-- // SubTit -->
                    <!-- TableWrap -->
                    <div class="wrapTblDefault">
                        <table cellpadding="0" cellspacing="0" class="thCenter">
                            <colgroup>
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: auto" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row" class="sub">제목</th>
                                    <td colspan="3">
                                        {{ ds_detail.earvTitl }}
                                    </td>
                                    <th scope="row" class="sub">문서번호</th>
                                    <td>문서번호</td>
                                    <th scope="row" class="sub">작성일</th>
                                    <td>{{ ds_detail.makeDt }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">작업자명</th>
                                    <td colspan="3">{{ userInfo.userNm }}</td>
                                    <th scope="row" class="sub">작업자사번</th>
                                    <td colspan="3">{{ userInfo.userCd }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">변경내용</th>
                                    <td colspan="7">
                                        {{ parentData.tradeName }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- //TableWrap -->

                    <!-- SubTit -->
                    <div class="stitHead line">
                        <h4 class="subTitLine">문서내용</h4>
                    </div>
                    <!-- // SubTit -->
                    <!-- defSubTit  -->
                    <div class="defSubTitWrap mgt">
                        <h4 class="defSubTit">1. 기본정보</h4>
                    </div>
                    <!-- //defSubTit -->
                    <!-- TableWrap -->
                    <div class="wrapTblDefault">
                        <table cellpadding="0" cellspacing="0" class="thCenter">
                            <colgroup>
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: auto" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row" class="sub">
                                        사업자명(상호)
                                    </th>
                                    <td colspan="3">
                                        {{ parentData.tradeName }}
                                    </td>
                                    <th scope="row" class="sub">거래처구분</th>
                                    <td>{{ parentData.dealCoCl1 }}</td>
                                    <th scope="row" class="sub">거래처코드</th>
                                    <td>{{ parentData.dealCoCd }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">사업자구분</th>
                                    <td colspan="3">
                                        {{ parentData.dealCoCd }}
                                    </td>
                                    <th scope="row" class="sub">사업자번호</th>
                                    <td>{{ parentData.bizNum }}</td>
                                    <th scope="row" class="sub">주민번호</th>
                                    <td>{{ parentData.regNum }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">업태</th>
                                    <td colspan="3">{{ parentData.bizCon }}</td>
                                    <th scope="row" class="sub">종목</th>
                                    <td>{{ parentData.typOfBiz }}</td>
                                    <th scope="row" class="sub">과세구분</th>
                                    <td>과세구분</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">사업장주소</th>
                                    <td colspan="7">{{ parentData.regNum }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">인감주소</th>
                                    <td colspan="7">{{ parentData.regNum }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">대표자명</th>
                                    <td colspan="3">
                                        {{ parentData.repUserNm }}
                                    </td>
                                    <th scope="row" class="sub">
                                        대표자생년월일
                                    </th>
                                    <td colspan="3" class="detail">
                                        {{ parentData.basic3 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">
                                        대표자이동전화
                                    </th>
                                    <td colspan="3">
                                        {{ parentData.repMblPhon }}
                                    </td>
                                    <th scope="row" class="sub">
                                        사업장연락처
                                    </th>
                                    <td>{{ parentData.telNo }}</td>
                                    <th scope="row" class="sub">
                                        예금주명(일치확인)
                                    </th>
                                    <td>{{ parentData.slcmDfryDepo }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">은행</th>
                                    <td>{{ parentData.slcmDfryBankCd }}</td>
                                    <th scope="row" class="sub">출금계좌</th>
                                    <td>{{ parentData.slcmDfryAccNo }}</td>
                                    <th scope="row" class="sub">예금주</th>
                                    <td>{{ parentData.slcmDfryDepo }}</td>
                                    <th scope="row" class="sub">일치여부</th>
                                    <td>{{ parentData.slcmChk }}</td>
                                </tr>
                                <tr>
                                    <td colspan="8">
                                        <span class="color-red ml10">
                                            * 아래 실경영자가 대표자와 동일한
                                            경우라도 기재할것.</span
                                        >
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">
                                        실경영자명 (실제매장운영자)
                                    </th>
                                    <td colspan="3" class="detail">
                                        {{ parentData.basic2 }}
                                    </td>
                                    <th scope="row" class="sub">
                                        대표자생년월일
                                    </th>
                                    <td colspan="3" class="detail">
                                        {{ parentData.basic3 }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- //TableWrap -->

                    <!-- defSubTit  -->
                    <div class="defSubTitWrap">
                        <h4 class="defSubTit">2. 거래처 세부정보 입력</h4>
                    </div>
                    <!-- //defSubTit -->
                    <!-- TableWrap -->
                    <div class="wrapTblDefault">
                        <table cellpadding="0" cellspacing="0" class="thCenter">
                            <colgroup>
                                <col style="width: 7.5%" />
                                <col style="width: 5%" />
                                <col style="width: 37.5%" />
                                <col style="width: 7.5%" />
                                <col style="width: 5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 8.5%" />
                                <col style="width: 16.5%" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row" class="sub" colspan="2">
                                        거래처명
                                    </th>
                                    <td>{{ parentData.dealCoNm }}</td>
                                    <th scope="row" class="sub" colspan="2">
                                        거래처코드(P,R)
                                    </th>
                                    <td colspan="3">
                                        {{ parentData.sktChannelCd }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" colspan="2">
                                        사업자구분
                                    </th>
                                    <td colspan="6">
                                        {{ parentData.perBizCl }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" colspan="2">
                                        매장영업형태
                                    </th>
                                    <td colspan="6"></td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" colspan="2">
                                        딜러여부
                                    </th>
                                    <td class="detail">
                                        {{ parentData.dtl1 }}
                                    </td>
                                    <th scope="row" class="sub" colspan="2">
                                        본점명
                                    </th>
                                    <td colspan="3" class="detail">
                                        {{ parentData.dtl3 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" colspan="2">
                                        본직영점구분
                                    </th>
                                    <td class="detail">
                                        {{ parentData.dtl2 }}
                                    </td>
                                    <th scope="row" class="sub" rowspan="2">
                                        U.FAX
                                    </th>
                                    <th scope="row" class="sub">번호1</th>
                                    <td colspan="3" class="detail">
                                        {{ parentData.dtl5 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" colspan="2">
                                        SKT 관할 마케팅팀
                                    </th>
                                    <td class="detail">
                                        {{ parentData.dtl4 }}
                                    </td>
                                    <th scope="row" class="sub">번호2</th>
                                    <td colspan="3" class="detail">
                                        {{ parentData.dtl6 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" colspan="2">
                                        센터담당매니저
                                    </th>
                                    <td class="detail">
                                        {{ parentData.dtl7 }}
                                    </td>
                                    <th scope="row" class="sub" colspan="2">
                                        휴대폰
                                    </th>
                                    <td class="detail">
                                        {{ parentData.dtl8 }}
                                    </td>
                                    <th scope="row" class="sub">소속</th>
                                    <td class="detail">
                                        {{ parentData.dtl9 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" rowspan="3">
                                        판매점실무자(실경영자와 구분됨)
                                    </th>
                                    <th scope="row" class="sub">성명</th>
                                    <td class="detail">
                                        {{ parentData.dtl10 }}
                                    </td>
                                    <th scope="row" class="sub" colspan="2">
                                        휴대폰
                                    </th>
                                    <td class="detail">
                                        {{ parentData.dtl11 }}
                                    </td>
                                    <th scope="row" class="sub">e-mail</th>
                                    <td class="detail">
                                        {{ parentData.dtl12 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">성명</th>
                                    <td class="detail">
                                        {{ parentData.dtl13 }}
                                    </td>
                                    <th scope="row" class="sub" colspan="2">
                                        휴대폰
                                    </th>
                                    <td class="detail">
                                        {{ parentData.dtl14 }}
                                    </td>
                                    <th scope="row" class="sub">e-mail</th>
                                    <td class="detail">
                                        {{ parentData.dtl15 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">성명</th>
                                    <td class="detail">
                                        {{ parentData.dtl16 }}
                                    </td>
                                    <th scope="row" class="sub" colspan="2">
                                        휴대폰
                                    </th>
                                    <td class="detail">
                                        {{ parentData.dtl17 }}
                                    </td>
                                    <th scope="row" class="sub">e-mail</th>
                                    <td class="detail">
                                        {{ parentData.dtl18 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" colspan="2">
                                        구슬약도
                                    </th>
                                    <td colspan="6" class="detail">
                                        {{ parentData.dtl19 }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- //TableWrap -->

                    <!-- defSubTit  -->
                    <div class="defSubTitWrap">
                        <h4 class="defSubTit">3. 거래처 기타정보 입력</h4>
                    </div>
                    <!-- //defSubTit -->
                    <!-- TableWrap -->
                    <div class="wrapTblDefault">
                        <table cellpadding="0" cellspacing="0" class="thCenter">
                            <colgroup>
                                <col style="width: 7.5%" />
                                <col style="width: 9.5%" />
                                <col style="width: 14.5%" />
                                <col style="width: 14.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: 14.5%" />
                                <col style="width: 12.5%" />
                                <col style="width: auto" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row" class="sub" rowspan="2">
                                        신용등급
                                    </th>
                                    <th scope="row" class="sub">개인사업자</th>
                                    <td colspan="6" class="detail">
                                        {{ parentData.etc1 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">법인사업자</th>
                                    <td colspan="6" class="detail">
                                        {{ parentData.etc2 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" colspan="2">
                                        거래불가 등급 거래시 RISK 관리방안
                                    </th>
                                    <td colspan="6" class="detail">
                                        {{ parentData.etc3 }}
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="8">
                                        <span class="color-red ml10">
                                            * 신용등급 7,8,9,10 등급 개설결재시
                                            품의 작성자 위 사유 기재</span
                                        >
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" rowspan="2">
                                        매장경력
                                    </th>
                                    <th scope="row" class="sub">총경력</th>
                                    <td colspan="6" class="detail">
                                        {{ parentData.etc4 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">법인사업자</th>
                                    <td colspan="6" class="detail">
                                        {{ parentData.etc5 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" colspan="2">
                                        주위평판
                                    </th>
                                    <td colspan="6" class="detail">
                                        {{ parentData.etc6 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" rowspan="3">
                                        판매현황 (신규+기변)
                                    </th>
                                    <th scope="row" class="sub">SKT</th>
                                    <td class="detail ar">
                                        {{ parentData.etc7
                                        }}<span class="unit">건</span>
                                    </td>
                                    <td class="detail ar">
                                        {{ parentData.etc8
                                        }}<span class="unit">%</span>
                                    </td>
                                    <th scope="row" class="sub" rowspan="3">
                                        SKT 주요거래점
                                    </th>
                                    <td class="detail ar" colspan="2">
                                        {{ parentData.etc13
                                        }}<span class="unit">건</span>
                                    </td>
                                    <td class="detail ar">
                                        {{ parentData.etc14
                                        }}<span class="unit">%</span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">KT</th>
                                    <td class="detail ar">
                                        {{ parentData.etc9
                                        }}<span class="unit">건</span>
                                    </td>
                                    <td class="detail ar">
                                        {{ parentData.etc10
                                        }}<span class="unit">%</span>
                                    </td>
                                    <td class="detail ar" colspan="2">
                                        {{ parentData.etc15
                                        }}<span class="unit">건</span>
                                    </td>
                                    <td class="detail ar">
                                        {{ parentData.etc16
                                        }}<span class="unit">%</span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">LG</th>
                                    <td class="detail ar">
                                        {{ parentData.etc11
                                        }}<span class="unit">건</span>
                                    </td>
                                    <td class="detail ar">
                                        {{ parentData.etc12
                                        }}<span class="unit">%</span>
                                    </td>
                                    <td class="detail ar" colspan="2">
                                        {{ parentData.etc17
                                        }}<span class="unit">건</span>
                                    </td>
                                    <td class="detail ar">
                                        {{ parentData.etc18
                                        }}<span class="unit">%</span>
                                    </td>
                                </tr>
                                <tr>
                                    <th
                                        scope="row"
                                        class="sub"
                                        colspan="2"
                                        rowspan="2"
                                    >
                                        판매목표(월)
                                    </th>
                                    <td colspan="2" class="detail">
                                        {{ parentData.etc19 }}
                                    </td>
                                    <th scope="row" class="sub">상권</th>
                                    <td colspan="3" class="detail">???</td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="detail">
                                        {{ parentData.etc20 }}
                                    </td>
                                    <th scope="row" class="sub">
                                        동일지역내판매점 월평균판매건
                                    </th>
                                    <td colspan="3" class="detail">
                                        {{ parentData.etc21 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" rowspan="4">
                                        담보1
                                    </th>
                                    <th scope="row" class="sub">여신유형</th>
                                    <td colspan="2">
                                        {{ parentData.crdTypNm1 }}
                                    </td>
                                    <th scope="row" class="sub">
                                        보증(금융)기관
                                    </th>
                                    <td colspan="3">
                                        {{ parentData.grtInstNm1 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">설정근거</th>
                                    <td colspan="2">
                                        {{ parentData.setBasis1 }}
                                    </td>
                                    <th scope="row" class="sub">설정일</th>
                                    <td>{{ parentData.setDt1 }}</td>
                                    <th scope="row" class="sub">만료일</th>
                                    <td>{{ parentData.expirDt1 }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">담보금액</th>
                                    <td colspan="2">
                                        {{ parentData.mrtgAmt1 }}
                                    </td>
                                    <th scope="row" class="sub">
                                        담보(설정)금액
                                    </th>
                                    <td>{{ parentData.mrtgSetAmt1 }}</td>
                                    <th scope="row" class="sub">수수료</th>
                                    <td>{{ parentData.cmms1 }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">비고</th>
                                    <td class="detail" colspan="6">
                                        {{ parentData.etc22 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" rowspan="4">
                                        담보2
                                    </th>
                                    <th scope="row" class="sub">여신유형</th>
                                    <td colspan="2">
                                        {{ parentData.crdTypNm2 }}
                                    </td>
                                    <th scope="row" class="sub">
                                        보증(금융)기관
                                    </th>
                                    <td colspan="3">
                                        {{ parentData.grtInstNm2 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">설정근거</th>
                                    <td colspan="2">
                                        {{ parentData.setBasis2 }}
                                    </td>
                                    <th scope="row" class="sub">설정일</th>
                                    <td>{{ parentData.setDt2 }}</td>
                                    <th scope="row" class="sub">만료일</th>
                                    <td>{{ parentData.expirDt2 }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">담보금액</th>
                                    <td colspan="2">
                                        {{ parentData.mrtgAmt2 }}
                                    </td>
                                    <th scope="row" class="sub">
                                        담보(설정)금액
                                    </th>
                                    <td>{{ parentData.mrtgSetAmt2 }}</td>
                                    <th scope="row" class="sub">수수료</th>
                                    <td>{{ parentData.cmms2 }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">비고</th>
                                    <td class="detail" colspan="6">
                                        {{ parentData.etc23 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub" rowspan="4">
                                        담보3
                                    </th>
                                    <th scope="row" class="sub">여신유형</th>
                                    <td colspan="2">
                                        {{ parentData.crdTypNm3 }}
                                    </td>
                                    <th scope="row" class="sub">
                                        보증(금융)기관
                                    </th>
                                    <td colspan="3">
                                        {{ parentData.grtInstNm3 }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">설정근거</th>
                                    <td colspan="2">
                                        {{ parentData.setBasis3 }}
                                    </td>
                                    <th scope="row" class="sub">설정일</th>
                                    <td>{{ parentData.setDt3 }}</td>
                                    <th scope="row" class="sub">만료일</th>
                                    <td>{{ parentData.expirDt3 }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">담보금액</th>
                                    <td colspan="2">
                                        {{ parentData.mrtgAmt3 }}
                                    </td>
                                    <th scope="row" class="sub">
                                        담보(설정)금액
                                    </th>
                                    <td>{{ parentData.mrtgSetAmt3 }}</td>
                                    <th scope="row" class="sub">수수료</th>
                                    <td>{{ parentData.cmms3 }}</td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">비고</th>
                                    <td class="detail" colspan="6">
                                        {{ parentData.etc24 }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- //TableWrap -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton eClass="btn_ty02_point" :eLarge="true"
                            >확인</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="onClose"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { GRID_D_HEADER } from '@/const/grid/sample/sampleGrid'
// import { SAMPLE_D_DATA, SAMPLE_DATA } from '@/const/grid/sample/sampleGridData'
import api from '@/api/biz/bas/prm/basPrmDealcoMgmt'
import _ from 'lodash'
// import moment from 'moment'
import CommonMixin from '@/mixins'
// import CommonUtil from '@/utils/CommonUtil.js'
import { SacCommon } from '@/views/biz/sac/js'
import {
    serviceComputed,
    // serviceMethods,
} from '@/store/biz/bas/prm/dealcoMgmt/helpers'

export default {
    name: 'BasPrmEarvTrmsNewAgrmtReConsi',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            calType7: 'DHMP',
            inputValue: '2021-01-01',
            inputValue7: ['2022-03-20', '2022-03-25'],
            sHourVal7: '11',
            eHourVal7: '23',
            sMinuVal7: '50',
            eMinuVal7: '59',
            inputValue2: '2021-02',
            inputValue5: '2022-03-15',
            calType5: 'M',
            endDateVal5: '2022-03-16',
            calType4: 'DHM',
            inputValue4: [true],
            inputValue41: '01',
            inputValue42: '59',
            //Paging Class init
            guideTab: 0,
            guideTab2: 0,
            tabItems: ['가상배정', '위탁배정'],
            gridData: this.gridSetData(),
            objAuth: {},
            gridObj: {},
            gridHeaderObj: {},
            gridObj2: {},
            gridHeaderObj2: {},
            codeIDView: true,
            codeIDViewVal: '',
            value1: '',
            value2: '',
            list01: [],
            list02: [],
            view: GRID_D_HEADER,
            radio1: '1',
            radio2: '2',
            checked1: true,
            checked2: false,
            input: '',
            input11: '',
            input12: '',
            input13: '',
            input14: '',
            input15: '',
            input21: '',
            input22: '',
            input23: '',
            input24: '',
            input25: '',
            input26: '',
            input27: '',
            checkbox: true,
            radios: null,
            tab: null,
            itemName: ['판매상세', '수납', '비고'],
            MdlClData: [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'Option 1',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Option 2',
                },
            ],
            MdlClData2: [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'Option 1',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Option 2',
                },
            ],
            items: [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'Option 1',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Option 2',
                },
            ],
            itemList1: [
                {
                    commCdVal: '10',
                    commCdValNm: 'T/B연계판매',
                },
            ],
            Checkbox4: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '서류미비 선등록(지급보류 및 해제)',
                },
            ],
            itemList3: [
                {
                    commCdVal: '10',
                    commCdValNm: '정상',
                },
                {
                    commCdVal: '20',
                    commCdValNm: '수납정지',
                },
                {
                    commCdVal: '30',
                    commCdValNm: '출고정지',
                },
                {
                    commCdVal: '40',
                    commCdValNm: '판매정지',
                },
                {
                    commCdVal: '50',
                    commCdValNm: '출금정지',
                },
                {
                    commCdVal: '60',
                    commCdValNm: '거래종료',
                },
            ],
            itemList4: [
                {
                    commCdVal: '10',
                    commCdValNm: '월별발행',
                },
                {
                    commCdVal: '20',
                    commCdValNm: '건별발행',
                },
            ],
            itemList5: [
                {
                    commCdVal: '10',
                    commCdValNm: '사업자주소와동일',
                },
            ],
            itemList6: [
                {
                    commCdVal: '10',
                    commCdValNm: 'SKIN직배송여부',
                },
                {
                    commCdVal: '20',
                    commCdValNm: '전속점여부',
                },
            ],
            itemList7: [
                {
                    commCdVal: '10',
                    commCdValNm: '',
                },
            ],
            gridStyle: {
                height: '170px', //그리드 높이 조절
            },
            parentData: {},
            ds_detail: {
                earvTitl: '거래처 변경&담보갱신품의서_',
                BASIC_0: [],
                makeDt: SacCommon.getToday(),
            },
            ds_mibiYn: {},
        }
    },
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
    },
    mounted() {
        // this.gridObj = this.$refs.grid1
        // this.gridHeaderObj = this.$refs.gridHeader1
        // this.gridObj.setRows(SAMPLE_D_DATA)
        // this.gridObj.gridView.onCellClicked = (grid, clickData) => {
        //     alert(clickData.fieldName)
        // }
        // this.gridObj3 = this.$refs.grid3
        // this.gridHeaderObj3 = this.$refs.gridHeader3
        // this.gridObj3.setRows(SAMPLE_DATA)
        // this.gridObj3.gridView.onCellClicked = (grid, clickData) => {
        //     alert(clickData.fieldName)
        // }
        this.init()
        // this.getMibiYn()
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentData', value)
                this.parentData = value
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        // ...serviceMethods,
        setData() {
            let params = { ...this.newInfo }
            this.storeSet(this.storeKey, params)
        },

        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        init() {
            console.log('init')
            this.getMibiYn()
            // if (this.ds_mibiYn.GetColumn(0, 'MIBI_YN') == '지급보류등록') {
            //     this.Checkbox4.commCdVal = 'Y'
            // }
        },
        gridSetData: function () {
            return new CommonGrid(0, 10, '', '')
        },
        //팝업닫기
        // closeBtn: function () {
        //     this.activeOpen = false
        // },
        // onActiveTabChange(tabIdx) {
        //     console.log('onActiveTabChange: ', tabIdx)
        // },
        // onActiveTabClick() {},

        //2번째 탭 클릭시 그리드 Mounted 후 실행
        //@hook:mounted
        // tabGridMounted() {
        //     console.log('tabGridMounted mounted')
        //     this.gridObj4 = this.$refs.grid4
        //     this.gridHeaderObj4 = this.$refs.gridHeader4
        //     this.gridObj4.setRows(SAMPLE_DATA)
        //     this.gridObj4.gridView.onCellClicked = (grid, clickData) => {
        //         alert(clickData.fieldName)
        //     }
        // },

        // 서류미비여부
        getMibiYn() {
            console.log('dealCoCd : ', this.parentData.dealCoCd)
            let param = {
                dealCoCd: this.parentData.dealCoCd,
            }
            api.getMibiYn_(param).then((result) => {
                // this.gridData = this.gridSetData() //초기화
                console.log('this.ds_mibiYn', result)
                if (result) {
                    this.ds_mibiYn = result
                }
            })
        },

        // 결재전송
        async btn_earvSnd_OnClick() {
            console.log(
                'this.basPrmDealcoDtlEarvCntVo',
                this.basPrmDealcoDtlEarvCntVo
            )
            // 전자결재 중복 체크

            if (!_.isEmpty(this.basPrmDealcoDtlEarvCntVo)) {
                if (
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.deal, '0') ||
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.dlv, '0') ||
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.crd, '0') ||
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.cust, '0')
                ) {
                    this.showTcComAlert('전자결재 승인 대기중입니다.')
                    return false
                }
            }

            console.log('this.ds_mibiYn', this.ds_mibiYn)
            if (
                //this.Checkbox4[0].commCdVal == 'Y' &&
                _.isEqual(this.ds_detail.BASIC_0[0], 'Y') &&
                this.ds_mibiYn == '지급보류등록'
            ) {
                let confirm = await this.showTcComConfirm(
                    '해당 거래처에 지급보류(W)가 유지됩니다.'
                )

                if (!confirm) {
                    return false
                }
            }

            if (
                _.isEqual(this.ds_detail.BASIC_0[0], 'Y') &&
                this.ds_mibiYn == '정상등록'
            ) {
                let confirm = await this.showTcComConfirm(
                    '해당 거래처에 지급보류(W)가 설정됩니다.'
                )

                if (!confirm) {
                    return false
                }
            }

            if (
                _.isEqual(this.ds_detail.BASIC_0[0], 'N') &&
                this.ds_mibiYn == '지급보류등록'
            ) {
                let confirm = await this.showTcComConfirm(
                    '해당 거래처에 지급보류(W)가 해제됩니다.'
                )

                if (!confirm) {
                    return false
                }
            }

            console.log('dealCoCd : ', this.parentData.dealCoCd)
            let params = {
                basPrmDealcoElecAprvLnkgDetailDto: [
                    {
                        earvTitl: this.ds_detail.earvTitl,
                        dealCoCd: this.parentData.dealCoCd
                            ? this.parentData.dealCoCd
                            : '',
                        userCd: this.userInfo.userCd
                            ? this.parentData.userCd
                            : '',
                        rmks: '임시 고객정보', // 고객정보의 비고
                        newOrgCd: this.parentData.newOrgCd
                            ? this.parentData.newOrgCd
                            : '',
                        orgCd3: this.parentData.orgCd3
                            ? this.parentData.orgCd3
                            : '',
                        orgCd2: this.parentData.orgCd2
                            ? this.parentData.orgCd2
                            : '',
                        bizNum: this.parentData.bizNum
                            ? this.parentData.bizNum
                            : '',
                        slcmDfryDepo: this.parentData.slcmDfryDepo
                            ? this.parentData.slcmDfryDepo
                            : '',
                        slcmChk: this.parentData.slcmChk
                            ? this.parentData.slcmChk
                            : '',
                        slcmDfryDepoCheck: this.params.vrfDpstrNm
                            ? this.params.vrfDpstrNm
                            : '',
                    },
                ],
            }
            api.requestCrdAdd5_(params).then(() => {
                this.gridData = this.gridSetData() //초기화
                // this.$parent.imsiSave3()
                // console.log('this.$parent', this.$parent)
                this.onClose()
            })
        },

        onClose() {
            console.log('this.$parent', this.$parent)
            // this.$parent.onSearch()
            // this.$parent.onSearch()
            this.activeOpen = false
            // this.$parent.onSearch()
            // this.$refs.$parent.imsiSave3()
        },
    },
}
</script>
