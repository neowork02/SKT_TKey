import { ValueType } from 'realgrid'

export const GRID_GROUP_HEADER = {
    group: {
        org: {
            name: '조직',
            fields: [
                {
                    fieldName: 'orgLvl',
                    description: '조직레벨',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'orgCd',
                    description: '조직(영업파트)코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'orgNm',
                    description: '조직(영업파트)명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'teamOrgCd',
                    description: '영업팀코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'teamOrgNm',
                    description: '영업팀명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'bizChrgOrgCd',
                    description: '사업팀코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'bizChrgOrgNm',
                    description: '사업팀명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'lvOrgCd',
                    description: '레벨0조직코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'orgTree',
                    description: '조직Display',
                    dataType: ValueType.TEXT,
                },
            ],
        },
        orgExtends: {
            name: '조직(확장형)',
            descriptoin: '조직 & 정산처/판매처/거래처',
            fields: [
                {
                    fieldName: 'orgLvl',
                    description: '조직레벨',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'orgCd',
                    description: '조직(영업파트)코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'orgNm',
                    description: '조직(영업파트)명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'teamOrgCd',
                    description: '영업팀코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'teamOrgNm',
                    description: '영업팀명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'bizChrgOrgCd',
                    description: '사업팀코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'bizChrgOrgNm',
                    description: '사업팀명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'lvOrgCd',
                    description: '레벨0조직코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'orgTree',
                    description: '조직Display',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'accDealcoCd',
                    description: '정산처코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'accDealcoNm',
                    description: '정산처명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'accStNm',
                    description: '정산상태',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'saleDealcoCd',
                    description: '판매처코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'saleDealcoNm',
                    description: '판매처명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'saleStNm',
                    description: '판매상태',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'saleChgDtm',
                    description: '매출일',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'dealcoCd',
                    description: '거래처코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'dealcoNm',
                    description: '거래처명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'dealcoClCd1',
                    description: '거래처구분코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'dealcoClNm1',
                    description: '거래처구분명',
                    dataType: ValueType.TEXT,
                },
            ],
        },
        chnl: {
            name: '채널',
            fields: [
                {
                    fieldName: 'sktChnlCd',
                    description: '판매채널코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'polChnlCd',
                    description: '정책채널코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'saleChnlCd',
                    description: '영업채널코드',
                    dataType: ValueType.TEXT,
                },
            ],
        },
        cust: {
            name: '고객정보',
            fields: [
                {
                    fieldName: 'custNm',
                    discription: '고객명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'svcNum',
                    discription: '개통번호',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'custClNm',
                    discription: '고객구분',
                    dataType: ValueType.TEXT,
                },
            ],
        },
        agrmt: {
            name: '개통정보',
            fields: [
                {
                    fieldName: 'agrmtClCd',
                    discription: '유통망코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'agrmtClNm',
                    discription: '유통망',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'agrmtPrdCd',
                    discription: '약정기간코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'agrmtPrdNm',
                    discription: '약정기간명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'saleDtlTypCd',
                    discription: '판매유형코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'saleDtlTypNm',
                    discription: '판매유형명',
                    dataType: ValueType.TEXT,
                },
            ],
        },
        eqp: {
            name: '단말기정보',
            fields: [
                {
                    fieldName: 'prodCd',
                    discription: '모델코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'prodNm',
                    discription: '모델명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'eqpColorCl',
                    discription: '색상코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'eqpColorNm',
                    discription: '색상명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'serNum',
                    discription: '일련번호',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'eqpSettlCondCl',
                    discription: '결제조건코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'eqpSettlCondNm',
                    discription: '결제조건명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'eqpDisClCd',
                    discription: '재고구분코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'eqpDisClNm',
                    discription: '재고구분명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'allotPrdCd',
                    discription: '할부개월코드',
                    dataType: ValueType.TEXT,
                },
            ],
        },
        usim: {
            name: 'USIM정보',
            fields: [
                {
                    fieldName: 'usimProdCd',
                    discription: '모델코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'usimProdNm',
                    discription: '모델명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'usimSerNo',
                    discription: '일련번호',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'usimSettlCondCd',
                    discription: '결제조건코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'usimSettlCondNm',
                    discription: '결제조건명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'usimDisClCd',
                    discription: '재고구분코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'usimDisClCdNm',
                    discription: '재고구분명',
                    dataType: ValueType.TEXT,
                },
            ],
        },
        smrt: {
            name: '스마트디바이스',
            fields: [
                {
                    fieldName: 'smrtProdCd',
                    discription: '모델코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'smrtProdNm',
                    discription: '모델명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'smrtColorCd',
                    discription: '색상코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'smrtColorNm',
                    discription: '색상명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'smrtSerNo',
                    discription: '일련번호',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'smrtSettlCondCd',
                    discription: '결제조건코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'smrtSettlCondNm',
                    discription: '결제조건명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'smrtDisClCd',
                    discription: '재고구분코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'smrtDisClNm',
                    discription: '재고구분명',
                    dataType: ValueType.TEXT,
                },
            ],
        },
        gnrl: {
            name: '일반상품',
            fields: [
                {
                    fieldName: 'gnrlProdCd',
                    discription: '모델코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'gnrlProdNm',
                    discription: '모델명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'gnrlColorCd',
                    discription: '색상코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'gnrlColorNm',
                    discription: '색상명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'gnrlSerNo',
                    discription: '일련번호',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'gnrlSettlCondCd',
                    discription: '결제조건코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'gnrlSettlCondNm',
                    discription: '결제조건명',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'gnrlDisClCd',
                    discription: '재고구분코드',
                    dataType: ValueType.TEXT,
                },
                {
                    fieldName: 'gnrlDisClNm',
                    discription: '재고구분명',
                    dataType: ValueType.TEXT,
                },
            ],
        },
        allotAmt: {
            name: '할부금액',
            fields: [
                {
                    fieldName: 'crdtSaleCostPrc',
                    discription: '할부원금',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'allotSaleAmt',
                    discription: '단말기',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'usimAllotSaleAmt',
                    discription: 'USIM',
                    dataType: ValueType.NUMBER,
                },
            ],
        },
        cashAmt: {
            name: '현금금액',
            fields: [
                {
                    fieldName: 'cashSaleAmt',
                    discription: '현금매출',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'adjtCashSaleAmt',
                    discription: '현금매출조정',
                    dataType: ValueType.NUMBER,
                },
            ],
        },
        dcAmt: {
            name: '추가(선)할인',
            list: [
                {
                    fieldName: 'agrmtAstAmt',
                    discription: '고객지원금',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'retentionAgrmtSuprtAmt',
                    discription: '유통망지원금',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'agreeAmt',
                    discription: '약정지원금',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'tecoDcAmt',
                    discription: 'T-ECO',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'cardDcAmt',
                    discription: '제휴카드',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'phoneSafeAmt',
                    discription: '폰세이프',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'freeclubDcAmt',
                    discription: '프리클럽',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'tgiftDcAmt',
                    discription: 'T사은권',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'tgiftMbrDcAmt',
                    discription: '멤버쉽',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'addDcAmt',
                    discription: '추가할인',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'tfPt',
                    discription: 'T패밀리포인트',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'rbPt',
                    discription: '레인보우포인트',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'kindPhoneDcAmt',
                    discription: '착한폰기변',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'kindPhoneDcLightAmt',
                    discription: '착한폰기변라이트',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'tmoaCopnDcAmt',
                    discription: 'T모아쿠폰',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'twdOcbDcAmt',
                    discription: 'TWD OCB',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'tarmyPt',
                    discription: 'T군사용포인트',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'elevenPointDcAmt',
                    discription: '11번가포인트',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'galaxyClubAmt',
                    discription: '갤럭시클럽',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'nagrmtPt',
                    discription: '무약정포인트',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'totPreDcAmt',
                    discription: '소계',
                    dataType: ValueType.NUMBER,
                },
            ],
        },
        sktAmt: {
            name: 'T판매가격표',
            list: [
                {
                    fieldName: 'skt01PrMnyAmt',
                    discription: 'SKT본사',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'skt02PrMnyAmt',
                    discription: 'SKT본부',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'skt03PrMnyAmt',
                    discription: 'SKT팀',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'sktPrMnyAmt',
                    discription: 'SKT소계',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'sknPrMnyAmt',
                    discription: 'SKN',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'mfactPrMnyAmt',
                    discription: '제조사',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'prMnySumAmt',
                    discription: '합계',
                    dataType: ValueType.NUMBER,
                },
            ],
        },
        psnmAmt: {
            name: 'PSNM판매가격표',
            list: [
                {
                    fieldName: 'psnm01PrMnyAmt',
                    discription: '본사',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'psnm02PrMnyAmt',
                    discription: '사업담당',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'psnm03PrMnyAmt',
                    discription: '영업팀',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'infraPrMny',
                    discription: '인프라재원',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'psnmPrMny',
                    discription: '소계',
                    dataType: ValueType.NUMBER,
                },
            ],
        },
        cmmsAmt: {
            name: '판매수수료',
            list: [
                {
                    fieldName: 'basCmmsAmt',
                    discription: '기본단가정책',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'svcCmmsAmt',
                    discription: '서비스정책',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'vasCmmsAmt',
                    discription: 'VAS정책',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'prcplnCmmsAmt',
                    discription: '요금제정책',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'upldCmmsAmt',
                    discription: '파일업로드정책',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'untCmmsAmt',
                    discription: '연합/특판',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'payDiffAmt',
                    discription: '수납차액',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'adjtCmmsAmt',
                    discription: '수수료조정',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'totCmms',
                    discription: '소계',
                    dataType: ValueType.NUMBER,
                },
            ],
        },
        fixAmt: {
            name: '확정금액',
            list: [
                {
                    fieldName: 'fixCashSaleAmt',
                    discription: '현금매출',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'fixCnsgCmmsAmt',
                    discription: '위탁수수료',
                    dataType: ValueType.NUMBER,
                },
            ],
        },
        etcAmt: {
            name: '기타금액',
            list: [
                {
                    fieldName: 'flxDcAmt',
                    discription: '프리할부선납',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'outCashSaleAmt',
                    discription: '매출출고현금매출',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'usimCmmsAmt',
                    discription: 'USIM후불예수금(할부수수료)',
                    dataType: ValueType.NUMBER,
                },
                {
                    fieldName: 'accAmt',
                    discription: '최종정산금',
                    dataType: ValueType.NUMBER,
                },
            ],
        },
    },
}
