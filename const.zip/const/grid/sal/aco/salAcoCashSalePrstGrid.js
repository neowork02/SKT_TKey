/*****************************************
 * 업무그룹명: 판매
 * 서브업무명: 일정산
 * 설명: 판매-일정산-현금영수증 수기관리(SALACO02400) 그리드 헤더
 * 작성자: P179234
 * 작성일: 2022.08.26
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'salGubn', // 판매구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'issueSignTypCd',
            dataType: ValueType.TEXT, //발행구분코드
        },
        {
            fieldName: 'issueInfoCd',
            dataType: ValueType.TEXT, //발행정보
        },
        {
            fieldName: 'totAmt',
            dataType: ValueType.NUMBER, //발행금액
        },
        {
            fieldName: 'aprvNo', // 승인번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'issueProcStCd', // 발행상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'issueProcStNm', // 발행상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleNo', // 판매관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq', // 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleChgSeq', // 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'allotSale', // 할부원금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'advanceDc', // 선할인금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'swingCashAmt', // SKT현금매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'orgNmTree',
            dataType: ValueType.TEXT, //조직트리
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'sktAgencyCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyNm', // 대리점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubNm', // 개통처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', // 개통처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoNm', // 판매처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd', // 판매처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtm', // SKT처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payDtm', // 수납처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', // 서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlCondCd', // 단말기결제조건코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlCondNm', // 단말기결제조건
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 단말기모델코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 단말기모델명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum', // 단말기일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // 수정횟수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 수정자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm', // 수정자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 수정일자
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'issueSignTypCd',
            fieldName: 'issueSignTypCd',
            type: 'data',
            width: '150',
            header: {
                text: '발행구분',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'issueInfoCd',
            fieldName: 'issueInfoCd',
            type: 'data',
            width: '150',
            header: '발행정보',
            //textFormat: '([0-9]{3})([0-9]{3})([0-9]{4})$;$1-$2-$3',
            editor: {
                // type: 'line',
                // inputCharacters: '0-9',
                type: 'text',
                maxLength: 20,
            },
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            styleName: 'right-column',
            header: '발행금액',
            numberFormat: '#,##0',
        },
        {
            name: 'aprvNo',
            fieldName: 'aprvNo',
            type: 'data',
            header: '승인번호',
            editable: false,
        },
        // {
        //     name: 'issueProcStCd',
        //     fieldName: 'issueProcStCd',
        //     type: 'data',
        //     width: '150',
        //     header: {
        //         text: '발행상태',
        //         showTooltip: false,
        //     },
        //     editable: true,
        //     lookupDisplay: true,
        //     values: [],
        //     labels: [],
        //     editor: {
        //         type: 'dropdown',
        //     },
        // },
        {
            name: 'issueProcStNm',
            fieldName: 'issueProcStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발행상태',
            editable: false,
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            header: '판매관리번호',
            editable: false,
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            header: '순번',
            editable: false,
        },
        {
            name: 'allotSale',
            fieldName: 'allotSale',
            type: 'data',
            styleName: 'right-column',
            header: '할부원금',
            numberFormat: '#,##0',
            editable: false,
        },
        {
            name: 'advanceDc',
            fieldName: 'advanceDc',
            type: 'data',
            styleName: 'right-column',
            header: '선할인금액',
            numberFormat: '#,##0',
            editable: false,
        },
        {
            name: 'swingCashAmt',
            fieldName: 'swingCashAmt',
            type: 'data',
            styleName: 'right-column',
            header: 'SKT현금매출',
            numberFormat: '#,##0',
            editable: false,
        },
        {
            name: 'orgNmTree',
            fieldName: 'orgNmTree',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
            editable: false,
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            header: '매장코드',
            editable: false,
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            styleName: 'left-column',
            header: '대리점',
            editable: false,
        },
        {
            name: 'sktSubNm',
            fieldName: 'sktSubNm',
            type: 'data',
            styleName: 'left-column',
            header: '개통처',
            editable: false,
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            header: '거래처코드',
            editable: false,
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            styleName: 'left-column',
            header: '판매처',
            editable: false,
        },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            header: 'SKT처리일시',
            width: '150',
            editable: false,
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            header: '수납처리일시',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            header: '서비스관리번호',
            editable: false,
        },
        {
            name: 'settlCondNm',
            fieldName: 'settlCondNm',
            type: 'data',
            header: '단말기결제조건',
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            header: '단말기모델명',
            editable: false,
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styleName: 'left-column',
            header: '단말기일련번호',
            editable: false,
        },
    ],
}
