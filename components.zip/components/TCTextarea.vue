<template>
    <textarea
        :class="cls"
        :style="tStyle"
        :readonly="readonly"
        :disabled="disabled"
        v-model="getTextareaValue"
        @change="bindChange($event.target.value)"
        @keyup="bindKeyup($event.key)"
    ></textarea>
</template>

<style type="text/css">
textarea {
    background-color: #313338;
    opacity: 1;
    border: 1px solid #606a7a;
    resize: none;
}
textarea:read-only {
    color: #ccc;
}
</style>

<script>
export default {
    name: 'IssTextarea',

    props: {
        cls: {
            type: String,
            default: '',
        },
        tStyle: {
            type: String,
            default: '',
        },
        val: {
            type: String,
            default: '',
        },
        readonly: {
            type: Boolean,
            default: false,
        },
        disabled: {
            type: Boolean,
            default: false,
        },
    },

    methods: {
        bindChange: function (value) {
            this.$emit('change', value)
        },
        bindKeyup: function (value) {
            this.$emit('keyup', value)
        },
    },

    computed: {
        getTextareaValue: {
            get() {
                return this.val
            },
            set(newVal) {
                this.$emit('changeval', newVal)
            },
        },
    },
}
</script>
