import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'aplyYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cdVal',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cdValNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cdId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'aplyYn',
            fieldName: 'aplyYn',
            header: {
                text: '처리상태',
            },
            editable: false,
        },
        {
            name: 'cdVal',
            fieldName: 'cdVal',
            header: {
                text: '코드ID',
            },
            editable: false,
        },
        {
            name: 'cdValNm',
            fieldName: 'cdValNm',
            header: {
                text: '코드명',
            },
            editable: false,
        },
        {
            name: 'cdId',
            fieldName: 'cdId',
            header: {
                text: '구분코드ID',
            },
            editable: false,
        },
        {
            name: 'opDtm',
            fieldName: 'opDtm',
            header: {
                text: '수신일시',
            },
            editable: false,
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            header: {
                text: '처리자ID',
            },
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            header: {
                text: '처리자',
            },
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '처리일시',
            },
            editable: false,
        },
    ],
}
