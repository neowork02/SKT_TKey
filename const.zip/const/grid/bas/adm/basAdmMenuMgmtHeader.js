/*****************************************
* 업무 그룹명 : ADMIN메뉴관리
* 서브 업무명 : ADMIN메뉴관리
* 설 명 : ADMIN메뉴관리 Grid 헤더 정보
* 작 성 자 : 배수현
* 작 성 일 : 2022.00.00
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 배수현  / 2022.00.00
* 변경사유/내역 : 
* ---------------------------------------
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const BAS_MENU_HEADER = {
    fields: [
        {
            fieldName: 'menuNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuNo1',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'menuNm2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuNo2',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'menuNm3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuNo3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuNm4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuNo4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sortSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuUrl4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'psYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'menuNm1',
            fieldName: 'menuNm1',
            type: 'data',
            width: 70,

            header: {
                text: '기준메뉴',
            },
        },
        {
            name: 'menuNo1',
            fieldName: 'menuNo1',
            type: 'data',
            width: 60,
            header: {
                text: '기준메뉴NO',
            },
        },
        {
            name: 'menuNm2',
            fieldName: 'menuNm2',
            type: 'data',
            width: 80,
            header: {
                text: '대메뉴',
            },
        },
        {
            name: 'menuNo2',
            fieldName: 'menuNo2',
            type: 'data',
            width: 60,
            header: {
                text: '대메뉴NO',
            },
        },
        {
            name: 'menuNm3',
            fieldName: 'menuNm3',
            type: 'data',
            width: 75,
            header: {
                text: '중메뉴',
            },
        },
        {
            name: 'menuNo3',
            fieldName: 'menuNo3',
            type: 'data',
            width: 60,
            header: {
                text: '중메뉴NO',
            },
        },

        {
            name: 'menuNm4',
            fieldName: 'menuNm4',
            type: 'data',
            width: 130,
            styles: {
                textAlignment: 'left',
            },
            styleName: 'left-column',
            header: {
                text: '소메뉴',
            },
        },
        {
            name: 'menuNo4',
            fieldName: 'menuNo4',
            type: 'data',
            width: 60,
            header: {
                text: '소메뉴NO',
            },
        },
        {
            name: 'sortSeq',
            fieldName: 'sortSeq',
            type: 'data',
            width: 47,
            header: {
                text: 'SORT SEQ',
            },
        },
        {
            name: 'menuUrl4',
            fieldName: 'menuUrl4',
            type: 'data',
            width: 200,
            styles: {
                textAlignment: 'left',
            },
            styleName: 'left-column',
            header: {
                text: 'URL',
            },
        },
        {
            name: 'mblYn',
            fieldName: 'mblYn',
            type: 'data',
            width: 55,
            header: {
                text: '모바일여부',
            },
        },
        {
            name: 'psYn',
            fieldName: 'psYn',
            type: 'data',
            width: 70,
            header: {
                text: 'PS&M전용여부',
            },
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            width: 45,
            header: {
                text: '사용여부',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: 70,
            header: {
                text: '처리일',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            width: 70,
            header: {
                text: '처리자',
            },
        },
    ],
}
