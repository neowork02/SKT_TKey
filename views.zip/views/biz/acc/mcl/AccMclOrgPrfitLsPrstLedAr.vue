<!-----------------------------------------------
 * 업무그룹명: 판매회계>매출/매출원장관리
 * 서브업무명: 매출원장
 * 설명: 매출원장 조회
 * 작성자: P179237
 * 작성일: 2022.05.24
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1600px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">매출원장상세</p>
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="clearPage"
                                :objAuth="objAuth"
                                >초기화</TCComButton
                            >
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="cfSearch"
                                :objAuth="objAuth"
                            >
                                조회
                            </TCComButton>
                        </li>
                    </ul>
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    :eRequired="true"
                                    v-model="dsCondition.searchGubun"
                                    labelName="조회구분"
                                    :itemList="searchGubunList"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div4">
                                <TCComDatePicker
                                    labelName="조회기간"
                                    :eRequired="true"
                                    calType="DP"
                                    v-model="setDate"
                                >
                                </TCComDatePicker>
                                <!-- </div> -->
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="dsCondition.refId"
                                    labelName="참고ID"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div4">
                                <!-- codeId="USE_YN" :itemList="getDelYnOptions" -->
                                <TCComComboBox
                                    codeId="TR_CL_CD"
                                    labelName="거래구분"
                                    v-model="dsCondition.trClCd"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                ></TCComComboBox>
                            </div>
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    :eRequired="true"
                                    v-model="dsCondition.orgNm"
                                    :codeVal.sync="dsCondition.orgCd"
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                />
                            </div>
                            <div class="formitem div4">
                                <!-- codeId="USE_YN" :itemList="getDelYnOptions" -->
                                <TCComComboBox
                                    codeId="AR_CL_CD"
                                    labelName="매출구분"
                                    v-model="dsCondition.arClCd"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :autocomplete="true"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="dsCondition.orgRefId"
                                    labelName="원참고ID"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div4">
                                <!-- codeId="USE_YN" :itemList="getDelYnOptions" -->
                                <TCComComboBox
                                    codeId="SALE_CHNL"
                                    labelName="영업채널"
                                    v-model="dsCondition.saleChnlCd"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                ></TCComComboBox>
                            </div>
                        </div>
                        <!-- //Search_line 2 -->

                        <template>
                            <div class="btn_def">
                                <v-btn
                                    plain
                                    class="btn_ty_exp"
                                    v-bind:class="{
                                        ' btn_ty_exp_active ': active,
                                    }"
                                    @click="active = !active"
                                >
                                </v-btn>
                            </div>
                        </template>

                        <v-expand-transition>
                            <div class="toggleWrap" v-show="active">
                                <!-- Search_line 3-->
                                <div class="searchform">
                                    <div class="formitem div4">
                                        <TCComInput
                                            v-model="dsCondition.accDealcoCd"
                                            labelName="정산처"
                                        >
                                        </TCComInput>
                                    </div>
                                    <div class="formitem div4">
                                        <!-- codeId="USE_YN" :itemList="getDelYnOptions" -->
                                        <TCComComboBox
                                            codeId="SALE_CL_CD"
                                            labelName="판매구분"
                                            :filterFunc="filterFunc"
                                            v-model="dsCondition.saleClCd"
                                            :addBlankItem="true"
                                            blankItemText="전체"
                                            blankItemValue=""
                                        ></TCComComboBox>
                                    </div>
                                    <div class="formitem div4">
                                        <TCComInput
                                            v-model="dsCondition.svcMgmtNum"
                                            labelName="서비스관리번호"
                                        >
                                        </TCComInput>
                                    </div>
                                    <div class="formitem div4">
                                        <TCComInputSearchText
                                            v-model="dsCondition.sktAgencyNm"
                                            :codeVal.sync="
                                                dsCondition.sktAgencyCd
                                            "
                                            labelName="대리점"
                                            placeholder="입력해주세요"
                                            :disabledAfter="true"
                                            :objAuth="objAuth"
                                            @enterKey="onAgencyEnterKey"
                                            @appendIconClick="onAgencyIconClick"
                                            @input="onAgencyInput"
                                        />
                                        <BasBcoAgencysPopup
                                            v-if="showBcoAgencys"
                                            :parentParam="searchParams"
                                            :rows="resultAgencyRows"
                                            :dialogShow.sync="showBcoAgencys"
                                            @confirm="onAgencyReturnData"
                                        />
                                    </div>
                                </div>
                                <!-- //Search_line 3-->
                                <!-- Search_line 4-->
                                <div class="searchform">
                                    <div class="formitem div4">
                                        <!--saleChnlCd 판매채널 -->
                                        <TCComInput
                                            v-model="dsCondition.saleDealcoCd"
                                            labelName="판매처"
                                        >
                                        </TCComInput>
                                        <BasBcoAuthOrgTreesPopup
                                            v-if="showBcoAuthOrgTrees"
                                            :parentParam="dsCondition"
                                            :rows="resultAuthOrgTreeRows"
                                            :dialogShow.sync="
                                                showBcoAuthOrgTrees
                                            "
                                            @confirm="onAuthOrgTreeReturnData"
                                        />
                                    </div>
                                    <div class="formitem div4">
                                        <TCComInput
                                            v-model="dsCondition.taxCfmId"
                                            labelName="TAX승인번호"
                                        >
                                        </TCComInput>
                                    </div>
                                    <div class="formitem div4">
                                        <TCComInputSearchText
                                            v-model="dsCondition.sktSubNm"
                                            :codeVal.sync="dsCondition.sktSubCd"
                                            labelName="서브점"
                                            :disabledAfter="true"
                                            :objAuth="objAuth"
                                            @enterKey="onSwingDealIfEnterKey"
                                            @appendIconClick="
                                                onSwingDealIfIconClick
                                            "
                                            @input="onSwingDealIfInput"
                                        />
                                        <BasBcoTbasDealIfPopup
                                            v-if="basBcoSwingDealIfShow"
                                            :parentParam="searchParams"
                                            :rows="resultSwingDealIfRows"
                                            :dialogShow.sync="
                                                basBcoSwingDealIfShow
                                            "
                                            @confirm="onSwingDealIfReturnData"
                                        />
                                    </div>
                                    <div class="formitem div4"></div>
                                </div>
                                <!-- //Search_line 4-->
                            </div>
                        </v-expand-transition>
                        <!-- //Search_line 1 -->
                    </div>
                    <!-- //Search_div -->

                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeaderAr"
                            ref="gridHeaderAr"
                            gridTitle="매출원장 목록"
                            :gridObj="gridObjAr"
                            :addData="addData"
                            :isPageRows="true"
                            :isExceldown="true"
                            @excelDownBtn="onClickDownload"
                        />
                        <TCRealGrid
                            id="gridAr"
                            ref="gridAr"
                            :editable="false"
                            :movable="false"
                            :columnMovable="false"
                            :fields="view.fields"
                            :columns="view.columns"
                            :styles="gridStyle"
                        />
                        <TCComPaging
                            :totalPage="gridData.totalPage"
                            :apiFunc="getSaleLedsPagingData"
                            :rowCnt="rowCnt"
                            @input="chgRowCnt"
                        />
                    </div>
                    <SacSapSaleLedDtl
                        v-if="showPopup === true"
                        ref="popup"
                        :dialogShow.sync="showPopup"
                        :popupParams.sync="popupParams"
                    />
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<script>
import CommonMixin from '@/mixins'
import { CommonGrid, CommonUtil } from '@/utils'
import _ from 'lodash'
import { SacCommon } from '@/views/biz/sac/js'

import { G_HEADER } from '@/const/grid/sac/sap/sacSapSaleLedHead'
// import { TEST_DATA_SACSAP01030 } from '@/const/grid/sac/testData'
import api from '@/api/biz/sac/sap/sacSapSaleLed'

import SacSapSaleLedDtl from '@/views/biz/sac/sap/SacSapSaleLedDtl.vue'
import attachedFileApi from '@/api/common/attachedFile'

//====================대리점팝업====================
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
//====================//대리점팝업====================
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================SWING대리점/서브점/판매점팝업====================
import BasBcoTbasDealIfPopup from '@/components/common/BasBcoTbasDealIfPopup'
import basBcoTbasDealIfPopApi from '@/api/biz/bas/bco/basBcoTbasDealIfPop'
//====================//SWING대리점/서브점/판매점팝업==================

export default {
    name: 'SacSapSaleLed',
    mixins: [CommonMixin],
    components: {
        SacSapSaleLedDtl,
        BasBcoAgencysPopup,
        BasBcoAuthOrgTreesPopup,
        BasBcoTbasDealIfPopup,
    },
    props: {
        //params
        parentParam: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            active: false,
            // main grid 영역
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
            gridObjAr: {},
            gridHeaderObj: {},
            gridData: this.GridSetData(),
            addData: ['', '', '', '', '', '', ''],

            view: G_HEADER,
            dsResult: [],

            searchParams: { sktOrgClCd: '06', searchDate: '' }, // 조직구분},

            dsCondition: {
                searchGubun: '', // 조회구분
                searchDtFrom: '',
                searchDtTo: '',
                refId: '', // 참고ID
                trClCd: '', // 거래구분
                saleDealcoCd: '', // 판매처
                arClCd: '', // 매출구분
                orgRefId: '', // 원참고ID
                saleChnlCd: '', // 영업채널
                accDealcoCd: '', // 정산처
                saleClCd: '', // 판매구분
                svcMgmtNum: '', // 서비스관리번호
                sktAgencyCd: '', //대리점코드
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLvl: '', // 조직레벨
                taxCfmId: '', // TAX승인번호(세금계산서승인ID)
                sktSubCd: '', // 서브점코드
            },

            // 고객정보
            dsCustInfo: [],

            objAuth: {},
            searchGubunList: [
                { commCdVal: '1', commCdValNm: '판매일' },
                { commCdVal: '2', commCdValNm: '전기일' },
                { commCdVal: '3', commCdValNm: '증빙일' },
            ],

            // popup
            popupParams: {},
            showPopup: false,
            //====================//내부조직팝업(권한)팝업관련==================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================SWING대리점/서브점/판매점팝업관련====================
            basBcoSwingDealIfShow: false,
            resultSwingDealIfRows: [],
            //====================//SWING대리점/서브점/판매점팝업관련==================

            // paging
            rowCnt: 15, // 표시할 행의 갯수
            //조회 파라미터
            reqParams: {},
        }
    },
    created() {},
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 초기값 세팅
        this.fInit()

        this.setLayout()
        this.dsCondition = this.parentParam
        console.log('dsCondition::::', this.dsCondition)

        // this.cfSearch()
    },
    computed: {
        setDate: {
            get() {
                return [
                    this.dsCondition.searchDtFrom,
                    this.dsCondition.searchDtTo,
                ]
            },
            set(val) {
                this.dsCondition.searchDtFrom = val[0]
                this.dsCondition.searchDtTo = val[1]
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.dsCondition.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                this.searchParams.searchDate = CommonUtil.onlyNumber(val[1])
                return val
            },
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObjAr = this.$refs.gridAr
            this.gridHeaderAr = this.$refs.gridHeaderAr
            this.gridObjAr.gridView.displayOptions.fitStyle = 'even'
            this.gridObjAr.setGridState(true)

            // 그리드 셀 클릭 이벤트
            this.gridObjAr.gridView.onCellDblClicked = (grid, clickData) => {
                if ('data' === clickData.cellType) {
                    const rowData = this.dsResult[clickData.dataRow]
                    this.cfCallPopup(rowData)
                }
            }
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        // grid header merge
        setLayout: function () {
            this.gridObjAr.gridView.setColumnLayout(this.view.layout)
        },
        // 폼 초기화
        fInit: function () {
            this.dsCondition.searchGubun = '1' // 조회구분

            this.dsCondition.searchDtFrom = SacCommon.getFirstday()
            this.dsCondition.searchDtTo = SacCommon.getToday()

            this.dsCondition.refId = ''
            this.dsCondition.trClCd = ''
            this.dsCondition.saleDealcoCd = '' // 세션값
            this.dsCondition.saleDealcoNm = ''

            this.dsCondition.arClCd = ''
            this.dsCondition.orgRefId = ''
            this.dsCondition.saleChnlCd = ''
            this.dsCondition.accDealcoCd = ''
            this.dsCondition.saleClCd = ''
            this.dsCondition.svcMgmtNum = ''

            this.dsCondition.sktAgencyNm = '' // 대리점
            this.dsCondition.sktAgencyCd = ''

            this.dsCondition.taxCfmId = ''

            this.dsCondition.sktSubNm = '' // 서브점
            this.dsCondition.sktSubCd = ''

            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.dsCondition['orgCd'] = this.orgInfo['orgCd']
                this.dsCondition['orgNm'] = this.orgInfo['orgNm']
                this.dsCondition['orgLvl'] = this.orgInfo['orgLvl']
            }
        },
        clearPage() {
            this.fInit()
        },

        // 판매구분 combobox filter
        filterFunc(items) {
            return items.filter((item) => item['addInfo2'] == 'Y')
        },
        //=========================================================
        // 이벤트영역
        //=========================================================
        cfSearch: function () {
            if (_.isEmpty(this.dsCondition.searchDtFrom)) {
                this.showTcComAlert('조회기간을 입력해주십시요.')
                return
            }

            if (_.isEmpty(this.dsCondition.searchDtTo)) {
                this.showTcComAlert('조회기간을 입력해주십시요.')
                return
            }

            if (_.isEmpty(this.dsCondition.orgCd)) {
                this.showTcComAlert('조직을 선택해 주십시요.')
                return
            } else if (this.dsCondition.orgLvl < 2) {
                this.showTcComAlert('팀단위 조직까지 조회가 가능합니다.')
                return
            }

            const fromDtNumber = SacCommon.removeHyphen(
                this.dsCondition.searchDtFrom
            )
            const toDtNumber = SacCommon.removeHyphen(
                this.dsCondition.searchDtTo
            )

            if (fromDtNumber > toDtNumber) {
                this.showTcComAlert('조회기간 입력이 잘못되었습니다.')
                return
            }

            const startMonth = this.dsCondition.searchDtFrom
                .replace(/-/g, '')
                .substring(0, 6)
            const endMonth = this.dsCondition.searchDtTo
                .replace(/-/g, '')
                .substring(0, 6)

            if (startMonth !== endMonth) {
                this.showTcComAlert(
                    '조회일자의 시작일과 종료일을 동일한 월로 지정해 주세요.'
                )
                return
            }

            this.dsCondition.pageSize = this.rowCnt
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getSaleLedsPagingData(1)
        },
        // 조회조건 가져오기
        getDsCondition: function () {
            // const dsCondDatas = _.omit(this.dsCondition, ['calOrdDtm']) // 배열제거
            this.reqParams = this.dsCondition

            const formData = {
                dsCondition: {
                    ...this.dsCondition,
                },
            }

            return formData
        },

        // 페이징 api호출
        getSaleLedsPagingData: function (pageNum) {
            this.dsCondition.pageNum = pageNum
            const formData = this.getDsCondition()
            // 페이징 조회
            api.getSaleLeds(formData).then((resultData) => {
                console.log(resultData)
                console.log('resultData.pagingDto======', resultData.pagingDto)

                this.dsResult = resultData.gridList // 임시주석
                this.gridObjAr.setRows(this.dsResult) // 임시주석
                // 페이징 관련
                this.gridObjAr.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData = this.GridSetData() //초기화
                this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                // this.gridHeaderObj.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },
        //Grid ExcelDown
        onClickDownload: function () {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/sac/sap/saleLedsExcelDown',
                this.reqParams
            )
        },

        closeBtn() {
            this.activeOpen = false
        },
        //========================================================
        // popup
        //========================================================
        cfCallPopup: function (pParams) {
            this.popupParams = { ...pParams }
            this.showPopup = true
        },
        //===================== 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getAgencyList() {
            this.searchParams.agencyCd = this.dsCondition.sktAgencyCd
            this.searchParams.agencyNm = this.dsCondition.sktAgencyNm
            basBcoAgencysApi.getAgencyList(this.searchParams).then((res) => {
                console.log('getAgencyList then : ', res)
                // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (res.length === 1) {
                    this.dsCondition.sktAgencyCd = _.get(res[0], 'agencyCd')
                    this.dsCondition.sktAgencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultAgencyRows = res
                    this.showBcoAgencys = true
                }
            })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.dsCondition.sktAgencyNm)) {
                this.getAgencyList()
            } else {
                this.showBcoAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 대리점 정보 조회
            this.getAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.dsCondition.sktAgencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.sktAgencyCd = _.get(retrunData, 'agencyCd')
            this.dsCondition.sktAgencyNm = _.get(retrunData, 'agencyNm')
        },
        //===================== //대리점팝업관련 methods ================================

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(
                    SacCommon.objectRemovedArray(this.dsCondition)
                )
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.dsCondition.orgCd = _.get(res[0], 'orgCd')
                        this.dsCondition.orgNm = _.get(res[0], 'orgNm')
                        this.dsCondition.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.dsCondition.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.dsCondition.orgCd = ''
            this.dsCondition.orgLvl = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.orgCd = _.get(retrunData, 'orgCd')
            this.dsCondition.orgNm = _.get(retrunData, 'orgNm')
            this.dsCondition.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================

        //===================== SWING대리점/서브점/판매점팝업 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getSwingDealIfPop() {
            console.log('searchParams<<<<<<<-----------', this.searchParams)
            basBcoTbasDealIfPopApi
                .getTbasDealIfPop(this.searchParams)
                .then((res) => {
                    console.log('getSwingDealIfPopdsList : ', res)

                    if (res && res.length === 1) {
                        this.dsCondition.sktSubCd = _.get(res[0], 'sktOrgCd')
                        this.dsCondition.sktSubNm = _.get(res[0], 'orgNm')
                    } else {
                        this.resultSwingDealIfRows = res
                        this.basBcoSwingDealIfShow = true
                    }
                })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onSwingDealIfIconClick() {
            if (_.isEmpty(this.dsCondition.sktAgencyCd)) {
                this.showTcComAlert(
                    '서브점 조회시 대리점 코드은(는) 필수 조건 항목입니다.'
                )
                return false
            }
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultSwingDealIfRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈

            this.searchParams.sktOrgClCd = '06' // 조직구분
            this.searchParams.sktOrgCd = this.dsCondition.sktAgencyCd //'D01046',<<테스트데이터 // 대리점코드
            this.searchParams.orgNm = this.dsCondition.sktSubNm // 서브점 조직명
            this.searchParams.sktSubCdNm = '' // 서브점코드

            if (!_.isEmpty(this.dsCondition.sktSubCd)) {
                this.getSwingDealIfPop()
                this.basBcoSwingDealIfShow = true
            } else {
                this.basBcoSwingDealIfShow = true
            }
        },
        // TextField 엔터키 이벤트 처리
        onSwingDealIfEnterKey() {
            if (_.isEmpty(this.dsCondition.sktAgencyCd)) {
                this.showTcComAlert(
                    '서브점 조회시 대리점 코드은(는) 필수 조건 항목입니다.'
                )
                return false
            }
            // 팝업 Row 설정 Prop 변수 초기화
            this.resultSwingDealIfRows = []

            this.searchParams.sktOrgClCd = '06' // 조직구분
            this.searchParams.sktOrgCd = this.dsCondition.sktAgencyCd //'D01046',<<테스트데이터 // 대리점코드
            this.searchParams.orgNm = this.dsCondition.sktSubNm // 서브점 조직명
            this.searchParams.sktSubCdNm = '' // 서브점코드

            // 팝업 정보 조회
            this.getSwingDealIfPop()
        },
        // 팝업 TextField Input 이벤트 처리
        onSwingDealIfInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.dsCondition.sktSubCd = ''
        },
        // 팝업 리턴 이벤트 처리
        onSwingDealIfReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.sktSubNm = _.get(retrunData, 'orgNm')
            this.dsCondition.sktSubCd = _.get(retrunData, 'sktSubCd')
        },
        //===================== //SWING대리점/서브점/판매점팝업 methods ================================
    },
}
</script>
