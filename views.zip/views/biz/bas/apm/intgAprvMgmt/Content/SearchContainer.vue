<template>
    <div>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="init"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    @click="aprv"
                    >승인
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    @click="rjct"
                >
                    반려
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="search"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <!-- 소속조직 -->
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="searchParam.orgNm"
                        :codeVal.sync="searchParam.orgCd"
                        labelName="소속조직"
                        placeholder="선택해주세요"
                        :eRequired="true"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //소속조직 -->
                <div class="formitem div3">
                    <TCComDatePicker
                        :eRequired="true"
                        v-model="searchParam.aprvDtm"
                        :calType="'DP'"
                        labelName="요청일자"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div3">
                    <TCComComboBox
                        v-model="searchParam.aprvStCd"
                        labelName="요청상태"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :itemList="this.aprvStCds"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div3">
                    <TCComComboBox
                        v-model="searchParam.menuGrpCd"
                        labelName="업무구분"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        codeId="ZADM_C_00010"
                        :objAuth="this.objAuth"
                        @change="getAprvTypNm"
                    ></TCComComboBox>
                </div>
                <div class="formitem div3">
                    <TCComComboBox
                        v-model="searchParam.aprvTypCd"
                        labelName="승인유형"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :itemList="this.aprvTypNmList1"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/apm/intgAprvMgmt/helpers'
import { msgTxt } from '@/const/msg.Properties'
import { CommonGrid } from '@/utils'

import moment from 'moment'
import _ from 'lodash'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================

export default {
    name: 'SearchContainer',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
    },
    data() {
        return {
            objAuth: {},

            gridData: this.gridSetData(),
            searchParam: {
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                serachGubnCd: '',
                aprvDtm: ['', ''], // 요청일자
                aprvStCd: '', // 요청상태
                menuGrpCd: '', // 업무구분
                aprvTypCd: '', // 승인유형
            },
            aprvStCds: [
                { commCdVal: '', commCdValNm: '전체' },
                { commCdVal: '1', commCdValNm: '요청' },
                { commCdVal: '2', commCdValNm: '취소' },
                { commCdVal: '3', commCdValNm: '승인' },
                { commCdVal: '4', commCdValNm: '반려' },
                { commCdVal: '5', commCdValNm: '기간만료' },
            ],
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            headerText: '',
            //====================//내부조직팝업(권한)팝업관련==================
        }
    },
    computed: {
        ...serviceComputed,
        paging1: {
            get() {
                return this.paging
            },
        },
        initPaging1: {
            get() {
                return this.initPaging
            },
        },
        aprvTypNmList1: {
            get() {
                return this.aprvTypNmList
            },
        },
        requestParam1: {
            get() {
                return this.requestParams
            },
        },
        aprvUrlList1: {
            get() {
                return this.aprvUrlList
            },
        },
    },
    mounted() {
        this.initParam()
        //this.search()
    },
    methods: {
        ...serviceMethods,
        gridSetData() {
            return new CommonGrid(0, 100, '', '')
        },
        init() {
            this.initPagingAssign_()
            this.initParam()
            //this.search()
        },
        async initParam() {
            const format = 'YYYY-MM-DD'
            let today = moment().format(format)
            let firstDay = moment(today).startOf('month').format(format)

            this.searchParam = {
                orgCd: this.orgInfo.orgCd,
                orgLvl: this.orgInfo.orgLvl,
                orgNm: this.orgInfo.orgNm,
                serachGubnCd: '1',
                aprvDtm: [firstDay, today], // 요청일자
                aprvStCd: '', // 요청상태
                menuGrpCd: '', // 업무구분
                aprvTypCd: '', // 승인유형
            }

            await this.initGetAprvTypNm()
            await this.getAprvTypNmList()

            this.defaultAssign_({
                key: 'requestParams',
                value: {},
            })

            this.defaultAssign_({
                key: 'aprvUrlList',
                value: {},
            })

            this.defaultAssign_({
                key: 'searchParams',
                value: {},
            })

            this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
        },
        initPagingAssign_() {
            this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        async initGetAprvTypNm() {
            this.searchParam.aprvTypCd = ''
            await this.defaultAssign_({
                key: 'aprvTypNmList',
                value: [],
            })
        },
        async getAprvTypNmList() {
            await this.initGetAprvTypNm()
            await this.getAprvTypNmList_({ menuGrpCd: 'ALL' })
        },
        getAprvTypNm(menuGrpCd) {
            if (!_.isEmpty(menuGrpCd)) {
                this.initGetAprvTypNm()
                this.getAprvTypNmList_({ menuGrpCd: menuGrpCd })
            }
        },
        validationCheck(title) {
            console.log('this.requestParam1', this.requestParam1)
            if (_.isEmpty(this.requestParam1.aprvSeqs)) {
                this.showTcComAlert('체크된 ' + title + '데이터가 없습니다')
                return false
            } else {
                return true
            }
        },
        async aprv() {
            let title = '승인'
            if (!this.validationCheck(title)) {
                return false
            } else if (await this.showTcComConfirm(title + ' 하시겠습니까?')) {
                await this.intgAprvApi('3')
            }
        },
        async rjct() {
            let title = '반려'
            if (!this.validationCheck(title)) {
                return false
            } else if (await this.showTcComConfirm(title + ' 하시겠습니까?')) {
                await this.intgAprvApi('4')
            }
        },

        async intgAprvApi(aprvStCd) {
            await _.forEach(this.requestParam1.aprvSeqs, (aprvSeq) => {
                let params = {}
                params.aprvSeq = aprvSeq
                params.aprvStCd = aprvStCd
                params.path = this.$route.fullPath

                console.log('params -> ', params)
                this.defaultAssign_({
                    key: 'params',
                    value: params,
                })

                this.postBasAprmIntgAprvMgmt_({
                    url: this.aprvUrlList1[aprvSeq],
                })
                    .then(() => {})
                    .catch((error) => {
                        Promise.reject(error)
                    })
                    .finally(() => {
                        this.search()
                    })
            })
        },

        search() {
            //this.initPagingAssign_()
            let paramObj = {}
            if (this.searchValidation()) {
                return
            }
            paramObj.fromDt = this.searchParam.aprvDtm[0].replaceAll('-', '')
            paramObj.toDt = this.searchParam.aprvDtm[1].replaceAll('-', '')

            paramObj.orgCd = this.searchParam.orgCd
            paramObj.serachGubnCd = this.searchParam.serachGubnCd
            paramObj.orgLvlCd = this.searchParam.orgLvl
            paramObj.aprvStCd = this.searchParam.aprvStCd
            paramObj.menuGrpCd = this.searchParam.menuGrpCd
            paramObj.aprvTypNm = this.searchParam.aprvTypCd
            paramObj.pageNum = this.paging1.pageNum
            paramObj.pageSize = this.initPaging1.pageSize

            console.log('paramObj ->', paramObj)
            this.defaultAssign_({
                key: 'searchParams',
                value: paramObj,
            })
            this.searchData()
        },

        async searchData() {
            let data1
            await this.loading(true)
            await this.getBasAprmIntgAprvMgmt_()
                .then((data) => {
                    data1 = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    this.loading(false)
                    if (_.isEmpty(data1)) {
                        this.showTcComAlert(msgTxt.MSG_00039.replace(/%s/g, ''))
                    }
                })
        },

        searchValidation() {
            if (_.isEmpty(this.searchParam.orgCd)) {
                this.showTcComAlert('조직을 선택하여 주세요.')
                return true
            }
            if (
                _.isEmpty(this.searchParam.aprvDtm[0]) ||
                _.isEmpty(this.searchParam.aprvDtm[1])
            ) {
                this.showTcComAlert('요청일자를 입력하여 주세요.')
                return true
            }
            return false
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    let cnt = 0

                    res.map((p) => {
                        if (p.orgLvl == '3') {
                            cnt++
                        }
                    })

                    if (cnt === 1) {
                        res.map((p) => {
                            this.searchParam.orgCd = _.get(p, 'orgCd')
                            this.searchParam.orgNm = _.get(p, 'orgNm')
                            this.searchParam.orgLvl = _.get(p, 'orgLvl')
                        })
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            //if (!_.isEmpty(this.searchParam.orgNm)) {
            //                this.getAuthOrgTreeList()
            //            } else {

            this.showBcoAuthOrgTrees = true
            //            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return false
            }

            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchParam.orgCd = _.get(returnData, 'orgCd')
            this.searchParam.orgNm = _.get(returnData, 'orgNm')
            this.searchParam.orgLvl = _.get(returnData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
    },
}
</script>

<style scoped></style>
