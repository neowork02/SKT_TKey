import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('bas.apm.aprvTypMgmtStore', Object.keys(state)),
    ...mapGetters('bas.apm.aprvTypMgmtStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('bas.apm.aprvTypMgmtStore', Object.keys(actions)),
    ...mapMutations('bas.apm.aprvTypMgmtStore', Object.keys(mutations)),
}
