import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('sal.sco.wlessSaleHstStore', Object.keys(state)),
    ...mapGetters('sal.sco.wlessSaleHstStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('sal.sco.wlessSaleHstStore', Object.keys(actions)),
    ...mapMutations('sal.sco.wlessSaleHstStore', Object.keys(mutations)),
}
