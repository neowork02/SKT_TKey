<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">재고상품리스트</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="gridWrap">
                        <!-- SubTit -->
                        <TCRealGridHeader
                            id="disProdListPopGridHeader"
                            ref="disProdListPopGridHeader"
                            gridTitle="상품내역"
                            :gridObj="gridObj"
                        />
                        <!-- // SubTit -->
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="disProdListPopGrid"
                                ref="disProdListPopGrid"
                                :fields="view.fields"
                                :columns="view.columns"
                                :styles="gridStyle"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { DisDcoDisProdListGRID_HEADER } from '@/const/grid/dis/dco/disDcoDisProdListHeader'
// import _ from 'lodash'

export default {
    name: 'DisDcoDisProdList',
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        disProdList: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        },
    },
    data() {
        return {
            gridObj: {},
            gridHeaderObj: {},
            view: DisDcoDisProdListGRID_HEADER,
            gridStyle: {
                height: '200px', //그리드 높이 조절
            },
        }
    },
    created() {
        this.init()
    },
    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.disProdListPopGrid
        this.gridHeaderObj = this.$refs.disProdListPopGridHeader
        this.gridObj.setGridState(false, false, false, false)
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        console.log(this.disProdList)
        this.gridObj.setRows(this.disProdList)
        this.setGridNo()
    },
    watch: {},
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        init() {},
        // 그리드 더블클릭 이벤트
        onCellDblClicked(grid, clickData) {
            if (clickData?.dataRow >= 0) {
                const rowData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                // 그리드의 클릭데이터와 prop데이터 일치데이터 추출
                for (var i = 0; i < this.disProdList.length; i++) {
                    if (
                        this.disProdList[i].serNum == rowData.serNum &&
                        this.disProdList[i].prodCd == rowData.prodCd &&
                        this.disProdList[i].colorCd == rowData.colorCd
                    ) {
                        // 클릭데이터 부모창 전송
                        this.$emit('returnVal', this.disProdList[i])
                        this.activeOpen = false
                        return
                    }
                }
            }
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        // 그리드 번호 채번
        setGridNo() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            for (var i = 0; i < rowCount; i++) {
                this.gridObj.gridView.setValue(i, 'no', i + 1)
            }
        },
    },
}
</script>
