<!-----------------------------------------------
 * 업무그룹명: Snackbar 컴포넌트
 * 서브업무명: Snackbar 공통함수
 * 설명: Snackbar 컴포넌트및 공통함수 
 * 작성자: 최고운
 * 작성일: 2022.07.21
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <!-- [2022-07-22] Snackbar 컴포넌트 수정_퍼블리싱 -->
    <div class="text-center infoMsg">
        <v-snackbar
            v-model="snackbarShow"
            :timeout="timeout"
            @input="emitInput"
            rounded="pill"
        >
            {{ message }}
            <template>
                <a href="#none" class="snackbarClose" @click="onClose">닫기</a>
            </template>
        </v-snackbar>
    </div>
    <!-- //[2022-07-22] Snackbar 컴포넌트 수정_퍼블리싱 -->
    <!-- <div class="text-center">
        <v-snackbar
            v-model="snackbarShow"
            :timeout="timeout"
            @input="emitInput"
        >
            {{ message }}
            <template>
                <v-btn color="blue" text @click="onClose"> Close </v-btn>
            </template>
        </v-snackbar>
    </div> -->
</template>

<script>
import _ from 'lodash'
export default {
    inheritAttrs: false,
    name: 'TCComSnackbar',
    components: {},
    props: {},
    data() {
        return {}
    },
    computed: {
        message() {
            return this.$store.getters['tcComSnackbarMessage']
        },
        getSnackbarOptions() {
            return this.$store.getters['tcComSnackbarOptions']
        },
        snackbarShow: {
            get() {
                return this.$store.getters['tcComSnackbarShow']
            },
            set() {},
        },
        timeout() {
            let timeout = _.get(this.getSnackbarOptions, 'timeout')
            if (_.isEmpty(timeout)) {
                timeout = 2000
            }
            return timeout
        },
    },
    // props 동적제어
    watch: {},
    created() {},
    mounted() {},
    methods: {
        emitInput() {
            this.$store.dispatch('closeTcComSnackbar')
        },
        onClose() {
            this.$store.dispatch('closeTcComSnackbar')
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
.snackbarClose {
    position: absolute;
    top: 21px;
    right: 22px;
    width: 17px;
    height: 17px;
    background: url('~@/assets/images/common/btn_close_snackbar.png') no-repeat
        left top;
    font-size: 0px;
    text-indent: -9999px;
}
</style>
