import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('sal.smg.daySalePrst2Store', Object.keys(state)),
    ...mapGetters('sal.smg.daySalePrst2Store', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('sal.smg.daySalePrst2Store', Object.keys(actions)),
    ...mapMutations('sal.smg.daySalePrst2Store', Object.keys(mutations)),
}
