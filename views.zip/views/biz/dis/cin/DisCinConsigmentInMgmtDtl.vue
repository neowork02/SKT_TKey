<!-----------------------------------------------
 * 업무그룹명: 재고관리>수탁입고
 * 서브업무명: 수탁입고상세(등록)[DISINN00400]
 * 설명: 수탁입고관리 상세를 조회, 등록한다.
 * 작성자: P179229
 * 작성일: 2022.05.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>수탁입고등록</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="addProdPop"
                    v-show="addProd"
                    >상품입력</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    v-show="addProd"
                    @click="addSwingProdPop"
                    >Swing상품입력</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    v-show="addProd"
                    @click="saveBtn"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="listBtn"
                    :objAuth="this.objAuth"
                >
                    목록
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5_2">
                    <TCComComboBox
                        codeId="ZDIS_C_00020"
                        labelName="입고구분"
                        :eRequired="true"
                        :objAuth="objAuth"
                        v-model="masterParam.inClCd"
                        :disabled="!addProd"
                        :filterFunc="inClCdFilter"
                    ></TCComComboBox>
                </div>
            </div>
        </div>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="입고일"
                        calType="D"
                        v-model="setDate"
                        :eRequired="true"
                        :disabled="!addProd"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="masterParam.orgNm"
                        :codeVal.sync="masterParam.orgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :eRequired="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchOrgForm"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="masterParam.inDealcoNm"
                        :codeVal.sync="masterParam.inDealcoCd"
                        labelName="입고처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :eRequired="true"
                        :disabled="dealcoDisabled"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchDealcosForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="masterParam.prchsDealcoNm"
                        :codeVal.sync="masterParam.prchsDealcoCd"
                        labelName="매입처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :eRequired="true"
                        :objAuth="objAuth"
                        :disabled="!addProd"
                        @enterKey="onOutDealEnterKey"
                        @appendIconClick="onOutDealIconClick"
                        @input="onOutDealInput"
                    />
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onOutDealReturnData"
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="this.agencyData"
                        labelName="대리점"
                        v-model="masterParam.agencyCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        :eRequired="true"
                        blankItemText="선택하세요"
                        blankItemValue=""
                        :disabled="!addProd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ORD_TYP_CD"
                        labelName="입고형태"
                        :eRequired="true"
                        :objAuth="objAuth"
                        v-model="masterParam.inTypCd"
                        :disabled="!addProd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="PRCH_TYP_CD"
                        labelName="구매유형"
                        :eRequired="true"
                        :objAuth="objAuth"
                        v-model="masterParam.prchTypCd"
                        :disabled="!addProd"
                        :filterFunc="prchTypeCdFilter"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComCheckBox
                        labelName="VAT포함여부"
                        :objAuth="objAuth"
                        :itemList="chkData"
                        v-model="chkValue"
                        @change="onChangeVat"
                        :disabled="!addProd"
                    ></TCComCheckBox>
                </div>
            </div>
        </div>
        <!-- // Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="입고등록 내역"
                :gridObj="this.gridObj"
                :isExcelup="false"
                :isExceldown="!addProd"
                :isDelRow="addProd"
                @chkDelRowBtn="gridchkDelRowBtn"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div>
        <!-- //gridWrap -->
        <!-- Text area -->
        <div class="textareaLayer_wrap">
            <TCComTextArea
                v-model="masterParam.rmks"
                labelName="비고"
                :readonly="!addProd"
                class="boxtype"
            ></TCComTextArea>
        </div>
        <!-- //Text area -->
        <!-- popup -->
        <DisDcoProdInsInPopup
            v-if="showAddProdPop === true"
            ref="popup"
            :dialogShow.sync="showAddProdPop"
            :parentParam.sync="addProdPopParam"
            @addProdList="addProdList"
        />
        <DisDcoSwingInProdInsInPopup
            v-if="showAddSwingProdPop === true"
            ref="popup"
            :dialogShow.sync="showAddSwingProdPop"
            :parentParam="addSwingProdPopParam"
            @confirm="addProdList"
        />
        <!-- // popup -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { DisInnInMgmtDtlGRID_HEADER } from '@/const/grid/dis/inn/disInnInMgmtDtlHeader'
import disInnInMgmtDtlApi from '@/api/biz/dis/inn/disInnInMgmtDtl'
import attachedFileApi from '@/api/common/attachedFile'
import DisDcoProdInsInPopup from '@/views/biz/dis/dco/DisDcoProdInsInPopup'
import DisDcoSwingInProdInsInPopup from '@/views/biz/dis/dco/DisDcoSwingInProdInsPopup'
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-전체조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-전체조직==================
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'DisCinConsigmentInMgmtDtl',
    mixins: [CommonMixin],
    components: {
        DisDcoProdInsInPopup,
        DisDcoSwingInProdInsInPopup,
        BasBcoOutDealsPopup,
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
    },
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: DisInnInMgmtDtlGRID_HEADER,
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '3X', // 거래처그룹
                dealcoClCd1: '30', // 거래처구분
            },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            //====================내부조직팝업(권한)팝업관련====================
            orgDisabled: false,
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchOrgForm: {
                orgCd: '', // 조직id
                orgNm: '', // 조직명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처-전체조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchDealcosForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
            },
            resultDealcoRows: [],
            //====================//내부거래처-전체조직==================
            chkData: [
                {
                    commCdVal: 'Y',
                },
            ],
            agencyData: [],
            chkValue: ['Y'],
            fromDt: '',
            listSearch: {},
            addProd: true,
            dtlData: {},
            searchParam: {},
            masterParam: {
                procFlag: '', //처리구분
                inClCd: '101', //입고구분
                inMgmtNo: '', //입고번호
                inSchdDt: '', //입고일자
                prchsDealcoCd: '', //매입처
                prchsDealcoNm: '', //매입처명
                inDealcoCd: '', // 입고처
                inDealcoNm: '', // 입고처명
                orgCd: '', //조직
                orgNm: '', //조직명
                orgLvl: '', //조직레벨
                agencyCd: '', //대리점
                agencyNm: '', //대리점명
                inTypCd: 'OT02', //입고형태
                prchTypCd: 'PT03', //구매유형
                vatInclYn: 'Y', //VAT포함여부
                rmks: '', //비고
            },
            prodSerNumParam: {},
            showAddProdPop: false,
            addProdPopParam: {},
            showAddSwingProdPop: false,
            addSwingProdPopParam: {},
            deleleGridData: [],
        }
    },
    computed: {
        setDate: {
            get() {
                return this.fromDt
            },
            set(val) {
                this.masterParam.inSchdDt = CommonUtil.replaceDash(val)
                this.searchDealcosForm.basDay = CommonUtil.getDayFormat(
                    val,
                    'YYYYMMDD'
                )
                this.searchOrgForm.basMth = CommonUtil.getDayFormat(
                    val,
                    'YYYYMM'
                )
                return val
            },
        },
    },
    created() {
        // 화면 default설정
        this.defaultSet()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        // 리스트 검색조건
        this.listSearch = this.$route.params.search
        this.dtlData = this.$route.params.datas
        // 상세
        if (!_.isEmpty(this.dtlData)) {
            //입고 마스터/상세조회
            this.searchParam.inMgmtNo = this.dtlData.inMgmtNo
            this.getDisInnSchdDtlLists()
        } else {
            this.masterParam['orgCd'] = this.listSearch['orgCd']
            this.masterParam['orgNm'] = this.listSearch['orgNm']
            this.masterParam['orgLvl'] = this.listSearch['orgLvl']
            this.masterParam['orgCdLvl0'] = this.listSearch['orgCdLvl0']
            this.masterParam['inDealcoCd'] = this.listSearch['inDealcoCd']
            this.masterParam['inDealcoNm'] = this.listSearch['inDealcoNm']
            this.masterParam['prchsDealcoCd'] = this.listSearch['prchsDealcoCd']
            this.masterParam['prchsDealcoNm'] = this.listSearch['prchsDealcoNm']
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
            //대리점 조회
            this.getAgencyList()
        }
    },
    methods: {
        gridSetData: function () {
            // CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(-1, 10, '', '')
        },
        defaultSet() {
            this.gridData = this.gridSetData()
            //검색영역
            this.fromDt = moment(new Date()).format('YYYY-MM-DD') // 입고일
        },
        //입고구분 Filter
        inClCdFilter(items) {
            return items.filter((item) => item['commCdVal'] === '101')
        },
        //구매유형 Filter
        prchTypeCdFilter(items) {
            return items.filter((item) => item['commCdVal'] === 'PT03')
        },
        //VAT포함여부
        onChangeVat(value) {
            this.masterParam.vatInclYn = _.isEmpty(_.get(value, 0))
                ? 'N'
                : _.get(value, 0)
        },
        //대리점 조회
        getAgencyList: function () {
            disInnInMgmtDtlApi.getAgencyList(this.masterParam).then((res) => {
                res.disInnAgencyVo.forEach((data) => {
                    const agencyInfo = {}
                    agencyInfo.commCdVal = _.get(data, 'agencyCd')
                    agencyInfo.commCdValNm = _.get(data, 'agencyNm')
                    this.agencyData.push(agencyInfo)
                })
            })
        },
        //상품입력
        addProdPop: function () {
            // validation
            if (!this.isMasterParamValidChk()) {
                return false
            }
            this.addProdPopParam.prodSerNumList =
                this.gridObj.dataProvider.getJsonRows(0, -1)
            this.addProdPopParam.inClCd = this.masterParam.inClCd
            this.addProdPopParam.inSchdDt = this.masterParam.inSchdDt
            this.addProdPopParam.prchTypCd = this.masterParam.prchTypCd
            this.showAddProdPop = true
        },
        //상품입력 callback
        addProdList(value) {
            var chk = false
            this.gridObj.gridView.commit()
            value.forEach((data) => {
                if (this.chkAddProdList(data)) {
                    if (_.isEmpty(data.badYn)) {
                        data.badYn = '01'
                    }
                    if (_.isEmpty(data.disSt)) {
                        data.disSt = '01'
                    }
                    if (_.isEmpty(data.inQty)) {
                        data.inQty = '1'
                    }
                    if (_.isEmpty(data.updCnt)) {
                        data.updCnt = '1'
                    }
                    if (_.isEmpty(data.unitPrc)) {
                        data.unitPrc = '0'
                    }
                    // 상품정보 append
                    this.gridObj.dataProvider.insertRow(
                        this.gridObj.gridView.getItemCount(),
                        data
                    )
                } else {
                    chk = true
                }
            })
            if (chk) {
                this.showTcComAlert(
                    '중복된 일련번호를 제외하고 추가하였습니다.'
                )
            }
        },
        //SWING상품입력
        addSwingProdPop: function () {
            // validation
            if (this.masterParam.inClCd === '103') {
                this.showTcComAlert(
                    'Swing 상품입력은 입고구분이 구매입고만 가능합니다.'
                )
                return false
            }
            if (!this.isMasterParamValidChk()) {
                return false
            }
            this.addSwingProdPopParam.inClCd = this.masterParam.inClCd
            this.addSwingProdPopParam.inClNm = '구매입고'
            this.addSwingProdPopParam.orgCd = this.masterParam.orgCd
            this.addSwingProdPopParam.orgLvl = this.masterParam.orgLevel
            this.addSwingProdPopParam.orgNm = this.masterParam.orgNm
            this.addSwingProdPopParam.inDealcoCd = this.masterParam.inDealcoCd
            this.addSwingProdPopParam.inDealcoNm = this.masterParam.inDealcoNm
            this.showAddSwingProdPop = true
        },
        //상품입력 일련번호 중복체크
        chkAddProdList(data) {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.gridObj.dataProvider.getJsonRow(i)
                    if (
                        _.get(row, 'prodCd') === data.prodCd &&
                        _.get(row, 'serNum') === data.serNum
                    ) {
                        return false
                    }
                }
            }
            return true
        },
        //저장
        saveBtn: function () {
            // validation
            if (!this.isMasterParamValidChk()) {
                return false
            }
            var addInnData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(addInnData)) {
                this.showTcComAlert('상품은 반드시 한개이상 등록해야 합니다.')
                return
            }
            let saveData = {}
            if (
                moment(new Date()).format('YYYYMMDD') >
                this.masterParam.inSchdDt
            ) {
                this.showTcComAlert(
                    '입고일자가 현재일 이전으로는 불가능합니다.'
                )
                return
            }
            if (
                moment(new Date()).format('YYYYMMDD').substr(0, 6) !==
                this.masterParam.inSchdDt.substr(0, 6)
            ) {
                this.showTcComAlert('입고일자를 오늘과 동일한 월로 지정하세요.')
                return
            }
            this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    //신규등록
                    saveData = { ...this.masterParam }
                    saveData.serNumList = addInnData
                    disInnInMgmtDtlApi
                        .addDisInnInMgmtDtl(saveData)
                        .then((res) => {
                            // 정상등록
                            if (!_.isEmpty(res)) {
                                setTimeout(() => {
                                    this.gridData = this.gridSetData() //초기화
                                    this.searchParam.inMgmtNo = res
                                    this.getDisInnSchdDtlLists()
                                }, 2000)
                            }
                        })
                }
            })
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/inn/disInnInMgmtDtlExcelList',
                this.masterParam
            )
        },
        //목록
        listBtn() {
            this.$router.push({
                name: '/dis/cin/DisCinConsigmentInMgmt',
                params: { search: this.listSearch },
            })
        },
        //입고 마스터/상세 조회
        getDisInnSchdDtlLists: function () {
            disInnInMgmtDtlApi
                .getDisInnSchdDtlLists(this.searchParam)
                .then((res) => {
                    //마스터정보 세팅
                    this.gridObj.setGridState(false, false, false)
                    this.fromDt = moment(res.disInMasterVo.inSchdDt).format(
                        'YYYY-MM-DD'
                    )
                    this.masterParam = res.disInMasterVo
                    this.prodSerNumParam = res.disProdSerNumListVo
                    this.gridObj.setRows(res.disProdSerNumListVo)
                    this.addProd = false
                    this.orgDisabled = true
                    this.dealcoDisabled = true
                    //대리점 조회
                    this.getAgencyList()
                })
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            this.gridObj.gridView.commit()
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
            this.deleleGridData = this.gridData.delRows
        },
        isMasterParamValidChk() {
            if (_.isEmpty(this.masterParam.inClCd)) {
                this.showTcComAlert('입고구분(을)를 선택해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.inSchdDt)) {
                this.showTcComAlert('입고일자를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.orgCd)) {
                this.showTcComAlert('조직(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.inDealcoCd)) {
                this.showTcComAlert('입고처(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.prchsDealcoCd)) {
                this.showTcComAlert('매입처(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.agencyCd)) {
                this.showTcComAlert('대리점(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.inTypCd)) {
                this.showTcComAlert('입고형태(을)를 선택해 주십시오.')
                return false
            }
            if (_.isEmpty(this.masterParam.prchTypCd)) {
                this.showTcComAlert('구매유형(을)를 선택해 주십시오.')
                return false
            }
            return true
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchOrgForm.orgCd = this.masterParam.orgCd
            this.searchOrgForm.orgNm = this.masterParam.orgNm
            this.searchOrgForm.orgLvl = this.masterParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchOrgForm)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.masterParam.orgCd = _.get(res[0], 'orgCd')
                        this.masterParam.orgNm = _.get(res[0], 'orgNm')
                        this.masterParam.orgLvl = _.get(res[0], 'orgLvl')
                        this.masterParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            if (!this.addProd) return
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.masterParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.masterParam.orgCd = ''
            this.masterParam.orgLvl = ''
            this.masterParam.orgCdLvl0 = ''
            this.masterParam.inDealcoCd = ''
            this.masterParam.inDealcoNm = ''
            this.masterParam.agencyCd = ''
            this.agencyData = []
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            this.masterParam.orgCd = _.get(retrunData, 'orgCd')
            this.masterParam.orgNm = _.get(retrunData, 'orgNm')
            this.masterParam.orgLvl = _.get(retrunData, 'orgLvl')
            this.masterParam.orgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
            this.masterParam.inDealcoCd = ''
            this.masterParam.inDealcoNm = ''
            this.masterParam.agencyCd = ''
            this.agencyData = []
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcosForm)
                .then((res) => {
                    // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                    if (res.length === 1) {
                        this.masterParam.inDealcoCd = _.get(res[0], 'dealcoCd')
                        this.masterParam.inDealcoNm = _.get(res[0], 'dealcoNm')
                        //대리점 조회
                        this.getAgencyList()
                    } else {
                        this.resultDealcoRows = res
                        this.showBasBcoDealcos = true
                    }
                })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            if (!this.addProd) return
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (_.isEmpty(this.masterParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }

            this.searchDealcosForm.orgCd = this.masterParam.orgCd
            this.searchDealcosForm.orgNm = this.masterParam.orgNm
            this.searchDealcosForm.orgLvl = this.masterParam.orgLvl
            this.searchDealcosForm.dealcoCd = this.masterParam.inDealcoCd
            this.searchDealcosForm.dealcoNm = this.masterParam.inDealcoNm
            // 팝업오픈
            this.showBasBcoDealcos = true
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.masterParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            this.searchDealcosForm.orgCd = this.masterParam.orgCd
            this.searchDealcosForm.orgNm = this.masterParam.orgNm
            this.searchDealcosForm.orgLvl = this.masterParam.orgLvl
            this.searchDealcosForm.dealcoCd = this.masterParam.inDealcoCd
            this.searchDealcosForm.dealcoNm = this.masterParam.inDealcoNm
            if (_.isEmpty(this.masterParam.inDealcoNm)) {
                // 팝업오픈
                this.showBasBcoDealcos = true
            } else {
                // 내부거래처-전체조직 정보 조회
                this.getDealcosList()
            }
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.masterParam.inDealcoCd = ''
            this.masterParam.agencyCd = ''
            this.agencyData = []
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            this.masterParam.inDealcoCd = _.get(retrunData, 'dealcoCd')
            this.masterParam.inDealcoNm = _.get(retrunData, 'dealcoNm')
            //대리점 조회
            this.getAgencyList()
        },
        //===================== //내부거래처-전체조직팝업관련 methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.masterParam.prchsDealcoCd = _.get(
                            res[0],
                            'dealcoCd'
                        )
                        this.masterParam.prchsDealcoNm = _.get(
                            res[0],
                            'dealcoNm'
                        )
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            if (!this.addProd) return
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            this.searchOutDealParam.dealcoCd = this.masterParam.prchsDealcoCd
            this.searchOutDealParam.dealcoNm = this.masterParam.prchsDealcoNm
            //팝업 오픈
            this.showBcoOutDeals = true
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            this.searchOutDealParam.dealcoCd = this.masterParam.prchsDealcoCd
            this.searchOutDealParam.dealcoNm = this.masterParam.prchsDealcoNm
            if (_.isEmpty(this.masterParam.prchsDealcoNm)) {
                //팝업 오픈
                this.showBcoOutDeals = true
            } else {
                // 외부거래처 정보 조회
                this.getOutDealList()
            }
        },
        // 외부거래처 TextField Input 이벤트 처리
        onOutDealInput() {
            // 입력되는 값이 있으면 외부거래처 코드 초기화
            if (_.isEmpty(this.masterParam.prchsDealcoNm)) {
                this.masterParam.prchsDealcoCd = ''
                this.searchOutDealParam.dealcoCd = ''
                this.searchOutDealParam.dealcoNm = ''
            }
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            this.masterParam.prchsDealcoCd = _.get(retrunData, 'dealcoCd')
            this.masterParam.prchsDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
    },
}
</script>
