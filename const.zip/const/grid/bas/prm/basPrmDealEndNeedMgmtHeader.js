import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.BOOLEAN,
        },
        {
            fieldName: 'reqStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealPeriod',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ptOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chargUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUser',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'printCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndPriRsnCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndRsn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqSeq', // 거래처거래종료순번(asis = seq)")
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            editable: false,
            renderer: {
                type: 'check',
            },
            header: {
                text: '선택',
            },
        },
        {
            name: 'reqStCd',
            fieldName: 'reqStCd',
            header: {
                text: '요청상태',
            },
        },
        {
            name: 'reqTypCd',
            fieldName: 'reqTypCd',
            editable: false,
            header: {
                text: '유형',
            },
        },
        {
            name: 'dealPeriod',
            fieldName: 'dealPeriod',
            editable: false,
            header: {
                text: '거래기간',
            },
        },
        {
            name: 'avrSales',
            fieldName: 'avrSales',
            header: {
                text: '3개월 평균실적(직전 2개월 제외)',
            },
        },
        {
            name: 'bizChrgOrgCd',
            fieldName: 'bizChrgOrgCd',
            header: {
                text: '사업담당',
            },
        },
        {
            name: 'teamOrgCd',
            fieldName: 'teamOrgCd',
            header: {
                text: '영업팀',
            },
        },
        {
            name: 'ptOrgCd',
            fieldName: 'ptOrgCd',
            header: {
                text: '영업파트',
            },
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            header: {
                text: '거래처구분',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: {
                text: '거래처명',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            header: {
                text: '채널코드',
            },
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            header: {
                text: '거래개시일',
            },
        },
        {
            name: 'chargUserId',
            fieldName: 'chargUserId',
            header: {
                text: '영업담당',
            },
        },
        {
            name: 'dealStNm',
            fieldName: 'dealStNm',
            header: {
                text: '거래처상태',
            },
        },
        {
            name: 'reqUser',
            fieldName: 'reqUser',
            header: {
                text: '요청자',
            },
        },
        {
            name: 'reqDtm',
            fieldName: 'reqDtm',
            header: {
                text: '요청일시',
            },
        },
        {
            name: 'aprvUserId',
            fieldName: 'aprvUserId',
            header: {
                text: '승인자',
            },
        },
        {
            name: 'aprvDtm',
            fieldName: 'aprvDtm',
            header: {
                text: '승인일시',
            },
        },
        {
            name: 'printCnt',
            fieldName: 'printCnt',
            header: {
                text: '출력횟수',
            },
        },
        {
            name: 'dealEndPriRsnCd',
            fieldName: 'dealEndPriRsnCd',
            header: {
                text: '거래종료 주요 사유',
            },
        },
        {
            name: 'dealEndRsn',
            fieldName: 'dealEndRsn',
            header: {
                text: '상세사유',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            header: {
                text: '반려사유',
            },
        },
    ],
}
