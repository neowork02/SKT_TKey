<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">재고상품</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- gridWrap -->
                    <TCRealGridHeader
                        id="gridHeaderSerNum"
                        ref="gridHeaderSerNum"
                        gridTitle=""
                        :gridObj="gridObj"
                        class="pop"
                    />
                    <!-- [팝업화면 기준] RealGrid가 화면 최상단에 위치할 경우 TCRealGridHeader에 class="pop" 추가 -->
                    <TCRealGrid
                        id="gridSerNum"
                        ref="gridSerNum"
                        :fields="view.fields"
                        :columns="view.columns"
                    />
                    <!-- //gridWrap -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonGrid } from '@/utils'

import _ from 'lodash'

import api from '@/api/biz/dis/dsm/disDsmProdHstBrws'
import { SERNUM_HEADER } from '@/const/grid/dis/dsm/disDsmProdHstBrwsDtlHead'

import disBeqBadProdApi from '@/api/biz/dis/beq/disBeqBadProdMgmt.js'
import disBeqLossRobberyProdApi from '@/api/biz/dis/beq/disBeqLossRobberyProdMgmt.js'
import demApi from '@/api/biz/dis/dem/disDemDemoDisMgmt.js'

export default {
    name: 'DisDsmProdHstBrwsSerNumPopup',
    mixins: [CommonMixin],
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: this.GridSetData(),

            view: SERNUM_HEADER,
            dsResult: [],

            dsConditionPopup: {},
            objAuth: {},
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    created() {},
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 조회
        this.fGetSerNumList()
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObj = this.$refs.gridSerNum
            this.gridHeaderObj = this.$refs.gridHeaderSerNum
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            this.gridObj.setGridState(true)

            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                if (_.isEqual(clickData.cellType, 'data')) {
                    const obj = {
                        flag: true,
                        data: this.gridObj.dataProvider.getJsonRow([
                            clickData.dataRow,
                        ]),
                    }
                    this.$emit('confirm', obj)
                    this.activeOpen = false
                }
            }
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, 1000, '', '')
        },

        fGetSerNumList: function () {
            this.dsConditionPopup = this.popupParams

            if ('prodHst' == this.dsConditionPopup.api) {
                const formData = {
                    dsCondition: {
                        serNum: this.dsConditionPopup.serNum,
                    },
                }

                api.getProdHstDisList(formData).then((resultData) => {
                    this.dsResult = resultData
                    this.gridObj.setRows(this.dsResult)

                    //페이지 정보
                    let pageInfo = {}
                    pageInfo.type = 'noPaging' //페이징이 없는경우
                    pageInfo.totalDataCnt =
                        this.gridObj.dataProvider.getRowCount() // 총건수
                    this.gridObj.setGridIndicator(pageInfo) //순번 셋팅
                })
            } else {
                const formData = {
                    ...this.dsConditionPopup.params,
                }
                if ('badProd' == this.dsConditionPopup.api) {
                    disBeqBadProdApi
                        .getBadProdDisInfo(formData)
                        .then((resultData) => {
                            this.dsResult = resultData
                            this.gridObj.setRows(this.dsResult)

                            //페이지 정보
                            let pageInfo = {}
                            pageInfo.type = 'noPaging' //페이징이 없는경우
                            pageInfo.totalDataCnt =
                                this.gridObj.dataProvider.getRowCount() // 총건수
                            this.gridObj.setGridIndicator(pageInfo) //순번 셋팅
                        })
                } else if ('lossRobberyProd' == this.dsConditionPopup.api) {
                    disBeqLossRobberyProdApi
                        .getDisProdInfo(formData)
                        .then((resultData) => {
                            this.dsResult = resultData
                            this.gridObj.setRows(this.dsResult)

                            //페이지 정보
                            let pageInfo = {}
                            pageInfo.type = 'noPaging' //페이징이 없는경우
                            pageInfo.totalDataCnt =
                                this.gridObj.dataProvider.getRowCount() // 총건수
                            this.gridObj.setGridIndicator(pageInfo) //순번 셋팅
                        })
                } else if ('demoCre' == this.dsConditionPopup.api) {
                    demApi.getDemoDisMgmt(formData).then((resultData) => {
                        this.dsResult = resultData
                        this.gridObj.setRows(this.dsResult)

                        //페이지 정보
                        let pageInfo = {}
                        pageInfo.type = 'noPaging' //페이징이 없는경우
                        pageInfo.totalDataCnt =
                            this.gridObj.dataProvider.getRowCount() // 총건수
                        this.gridObj.setGridIndicator(pageInfo) //순번 셋팅
                    })
                }
            }
        },
        closeBtn: function () {
            this.$emit('confirm', { flag: false })
            this.activeOpen = false
        },
    },
}
</script>
