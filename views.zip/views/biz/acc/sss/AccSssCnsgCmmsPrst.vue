<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 위탁매장위탁수수료현황
 * 소스 ID : AccSssCnsgCmmsPrst
 * 설명: 
 * 작성자: 김성엽
 * 작성일: 2022.07.25
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>위탁매장위탁수수료현황</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton eClass="btn_ty01" :objAuth="objAuth" @click="init"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        @change="changeAccYm"
                        v-model="reqParam.accYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabled="false"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :eRequired="true"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :codeVal.sync="reqParam.orgCd"
                        v-model="reqParam.orgNm"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="popupBasParams"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="D코드"
                        :objAuth="objAuth"
                        v-model="reqParam.sktAgencyCd"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="SUB코드"
                        :objAuth="objAuth"
                        v-model="reqParam.sktSubCd"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="정산처"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @input="onDealcoInput"
                        @appendIconClick="onDealcoIconClick"
                        :codeVal.sync="reqParam.accDealcoCd"
                        v-model="reqParam.accDealcoNm"
                        :disabled="isAccDealcoCd"
                    />
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="popupBasParams"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="거래상태"
                        codeId="ZBAS_C_00120"
                        :eRequired="true"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="this.objAuth"
                        v-model="reqParam.dealStat"
                    ></TCComComboBox>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="위탁매장위탁수수료현황"
                :isExceldown="true"
                :isPageRows="true"
                :isNextPage="false"
                :isPageCnt="true"
                :gridObj="gridObj"
                @excelDownBtn="downloadExcelAll()"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getTrustCmmsList"
                :gridObj="gridObj"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
// import commonApi from '@/api/common/prototype'
import { CommonGrid, CommonUtil } from '@/utils'
import moment from 'moment'
//  내부조직팝업(권한)
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//  내부거래처(권한조직)
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//  내부거래처(권한조직)
import trustCmmsApi from '@/api/biz/acc/sss/AccSssCnsgCmmsPrst'
import { GRID_HEADER } from '@/const/grid/acc/sss/AccSssCnsgCmmsPrstGrid'
import CommonMixin from '@/mixins'
export default {
    name: 'AccSssSkbCmmsIncenAccMgmt',
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,

            //Grid
            objAuth: {},
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},

            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            reqParam: {
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLevel: '', // 조직레벨
                orgLvl: '', //조직level
                searchCoClOrgCd: '',
                accYm: moment(new Date()).format('YYYY-MM'),
                accYm_: moment(new Date()).format('YYYY-MM'),
                sktAgencyCd: '',
                sktSubCd: '',
                accDealcoCd: '',
                accDealcoNm: '',
                dealStat: '',
            },
            rowCnt: 15,

            isAccDealcoCd: false,

            //  내부조직팝업(권한)
            showBcoAuthOrgTrees: false,
            resultAuthOrgTreeRows: [],
            //  내부조직팝업(권한)

            //  내부거래처(권한조직)
            basBcoDealcoShow: false,
            resultDealcoRows: [],
            //  내부거래처(권한조직)

            //  팝업Parameter
            popupBasParams: {},
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, false, false)
        this.gridObj.gridView.setColumnLayout(this.view.layout)
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'

        this.init()
    },
    created() {
        this.gridData = this.gridSetData(this.rowCnt)
    },
    methods: {
        // 초기화
        init: function () {
            this.$refs.grid.setRows([])

            // 정산월 초기화
            this.reqParam.accMth_ = moment(new Date()).format('YYYY-MM')
            this.reqParam.accMth = CommonUtil.onlyNumber(this.reqParam.accMth_)

            // D코드 / SUB코드 초기화
            this.reqParam.sktAgencyCd = ''
            this.reqParam.sktSubCd = ''

            // 조직 초기화
            if (!_.isEmpty(this.orgInfo['orgCd'])) {
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLvl'] = this.orgInfo['orgLvl']
                this.reqParam['searchCoClOrgCd'] = this.orgInfo['orgCdLvl0']
                console.log(this.orgInfo)
            }
            // 정산처 초기화
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['accDealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['accDealcoNm'] = this.userInfo['dealcoNm']
                this.reqParam['modUserId'] = this.userInfo['userId']
                this.reqParam['insUserId'] = this.userInfo['userId']
            }

            //거래상태 초기화
            this.reqParam.dealStat = ''

            //  Admin그룹 정산처 변경가능
            // if (
            //     this.userInfo.userGrpCd == 'P12' ||
            //     this.userInfo.userGrpCd == 'P13'
            // ) {
            //     this.isAccDealcoCd = false
            // } else {
            //     this.isAccDealcoCd = true
            // }
        },

        gridSetData: function (rowCnt) {
            return new CommonGrid(0, rowCnt, '', '')
        },

        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        changeAccYm() {
            this.reqParam.accYm = CommonUtil.onlyNumber(this.reqParam.accYm_)
            this.popupBasParams.basMth = this.reqParam.accYm
            this.popupBasParams.basDay = moment(this.reqParam.accYm)
                .endOf('month')
                .format('YYYYMMDD')
        },

        //================================================
        // 전체 조회 :::: getSwingSaleReport
        //================================================
        onSearch: function () {
            const srchaccMth = this.reqParam.accMth_
            if (_.isEmpty(srchaccMth)) {
                this.showTcComAlert('정산월을 확인하세요.')
                return
            }
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.reqParam.orgLvl = ''
            }

            this.reqParam.accMth = CommonUtil.onlyNumber(this.reqParam.accMth_)
            this.gridData.totalPage = 0
            this.searchForms = { ...this.reqParam }
            this.searchForms.pageSize = this.rowCnt
            this.searchForms.pageNum = 1
            this.getTrustCmmsList(this.searchForms.pageNum)
            console.log('전체리스트조회 ::::::: 시작')
        },
        async getTrustCmmsList(page) {
            this.searchForms.pageNum = page
            await trustCmmsApi
                .getTrustCmmsList(this.searchForms)
                .then((res) => {
                    if (res) {
                        console.log(
                            '전체리스트조회 ::::::: ',
                            res.resultGridDto
                        )
                        this.gridObj.setRows(res.resultGridDto.gridList)
                        this.gridObj.setGridIndicator(
                            res.resultGridDto.pagingDto
                        )
                        this.gridData = this.gridSetData()
                        this.gridData.totalPage =
                            res.resultGridDto.pagingDto.totalPageCnt
                        this.gridHeaderObj.setPageCount(
                            res.resultGridDto.pagingDto
                        )
                        console.log('전체리스트조회 ::::::: 끝')
                        console.log(res.resultGridDto.gridList.length)
                    }
                    // if (res.resultGridDto.gridList.length === 0) {
                    //     this.showTcComAlert('조회된 데이터가 없습니다.')
                    // }
                })
        },
        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcelAll: function () {
            // this.searchFormData.searchaccMth = CommonUtil.onlyNumber(
            //     this.searchFormData.accMth_
            // )
            // this.searchFormData.orgCd = this.reqParam.orgCd
            trustCmmsApi.getTrustCmmsExcelList(this.searchForms)
        },

        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.popupBasParams.orgCd = this.reqParam.orgCd
            this.popupBasParams.orgNm = this.reqParam.orgNm
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.popupBasParams)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'vLevel')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgNm)) {
                this.showTcComAlert('조직명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.orgLvl = _.get(returnData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.popupBasParams).then((res) => {
                if (res.length === 1) {
                    // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                    this.reqParam.accDealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.accDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                    this.resultDealcoRows = res
                    this.basBcoDealcoShow = true
                }
            })
        },
        onDealcoIconClick() {
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            if (this.userInfo.userGrpCd == 'P12') {
                this.resultDealcoRows = []
                this.basBcoDealcoShow = true
            } else {
                this.basBcoDealcoShow = false
            }

            // 팝업오픈
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            this.resultDealcoRows = []
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            if (_.isEmpty(this.reqParam.accDealcoNm)) {
                this.showTcComAlert('정산처를 입력해주세요.')
                return
            }
            this.popupBasParams.orgCd = this.reqParam.orgCd
            this.popupBasParams.orgNm = this.reqParam.orgNm
            this.popupBasParams.orgLvl = this.reqParam.orgLvl
            this.popupBasParams.dealcoCd = this.reqParam.accDealcoCd
            this.popupBasParams.dealcoNm = this.reqParam.accDealcoNm

            // 내부거래처조회
            this.getDealcosList()
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.reqParam.accDealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.reqParam.accDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.accDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================
    },
}
</script>
