<!-----------------------------------------------
 * 업무그룹명: 재고 dashBoard
 * 서브업무명: 재고 dashBoard
 * 설명: 재고 dashBoard
 * 작성자: P179237
 * 작성일: 2022.09.30
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="dashBoard">
        <!-- dashbord_임시이미지 -->
        <!-- <p class="temp_dashDis">임시이미지</p> -->
        <!-- SubTit -->
        <div class="stitHead">
            <h3 class="subTit">{{ titleNm }}</h3>
            <span class="stitBtnRef">
                <p>데이터 기준일 : {{ refDate }}(전일)</p>
                <!-- <p>판매실적 / 무선실적 / <strong>무선실적 현황</strong></p> -->
            </span>
        </div>
        <!-- //SubTit -->
        <!-- dashLayer_wrap -->
        <div class="dashLayer_wrap">
            <!-- dashForm_line 1 -->
            <div class="dashForm">
                <div class="type div3">
                    <div class="boxArea dis">
                        <p class="tit">재고 현황</p>
                        <div
                            :class="[
                                'grid2b-list',
                                { 'bg-dec': getPosBColor(prstPer) },
                                { 'bg-inc': getNegBColor(prstPer) },
                            ]"
                        >
                            <ul>
                                <li>
                                    <p
                                        :class="[
                                            'costSmall',
                                            {
                                                pointColor3:
                                                    getNegTColor(prstPer),
                                            },
                                        ]"
                                    >
                                        {{ prstProdCnt
                                        }}<em class="per"
                                            >({{ prstProdTdCnt }})건</em
                                        >
                                    </p>
                                    <p class="txt">단말</p>
                                </li>
                                <li>
                                    <p
                                        :class="[
                                            'costSmall',
                                            {
                                                pointColor3:
                                                    getNegTColor(prstPer),
                                            },
                                        ]"
                                    >
                                        {{ prstUsimCnt
                                        }}<em class="per"
                                            >({{ prstUsimTdCnt }})건</em
                                        >
                                    </p>
                                    <p class="txt">USIM</p>
                                </li>
                            </ul>
                            <span class="perUnit"
                                ><em :class="setPercentClass(prstPer)"
                                    ><span class="blind">증가</span></em
                                >{{ prstPer }}%</span
                            >
                        </div>
                    </div>
                </div>
                <div class="type div3">
                    <div class="boxArea dis">
                        <p class="tit">입고 현황</p>
                        <div
                            :class="[
                                'grid2b-list',
                                { 'bg-dec': getPosBColor(innPrstPer) },
                                { 'bg-inc': getNegBColor(innPrstPer) },
                            ]"
                        >
                            <ul>
                                <li>
                                    <p
                                        :class="[
                                            'costSmall',
                                            {
                                                pointColor3:
                                                    getNegTColor(innPrstPer),
                                            },
                                        ]"
                                    >
                                        {{ innPrstProdCnt
                                        }}<em class="per"
                                            >({{ innPrstProdTdCnt }})건</em
                                        >
                                    </p>
                                    <p class="txt">단말</p>
                                </li>
                                <li>
                                    <p
                                        :class="[
                                            'costSmall',
                                            {
                                                pointColor3:
                                                    getNegTColor(innPrstPer),
                                            },
                                        ]"
                                    >
                                        {{ innPrstUsimCnt
                                        }}<em class="per"
                                            >({{ innPrstUsimTdCnt }})건</em
                                        >
                                    </p>
                                    <p class="txt">USIM</p>
                                </li>
                            </ul>
                            <span class="perUnit"
                                ><em :class="setPercentClass(innPrstPer)"
                                    ><span class="blind">증가</span></em
                                >{{ innPrstPer }}%</span
                            >
                        </div>
                    </div>
                </div>
                <div class="type div3">
                    <div class="boxArea dis">
                        <p class="tit">출고 현황</p>
                        <div
                            :class="[
                                'grid2b-list',
                                { 'bg-dec': getPosBColor(outPrstPer) },
                                { 'bg-inc': getNegBColor(outPrstPer) },
                            ]"
                        >
                            <ul>
                                <li>
                                    <p
                                        :class="[
                                            'costSmall',
                                            {
                                                pointColor3:
                                                    getNegTColor(outPrstPer),
                                            },
                                        ]"
                                    >
                                        {{ outPrstProdCnt
                                        }}<em class="per"
                                            >({{ outPrstProdTdCnt }})건</em
                                        >
                                    </p>
                                    <p class="txt">단말</p>
                                </li>
                                <li>
                                    <p
                                        :class="[
                                            'costSmall',
                                            {
                                                pointColor3:
                                                    getNegTColor(outPrstPer),
                                            },
                                        ]"
                                    >
                                        {{ outPrstUsimCnt
                                        }}<em class="per"
                                            >({{ outPrstUsimTdCnt }})건</em
                                        >
                                    </p>
                                    <p class="txt">USIM</p>
                                </li>
                            </ul>
                            <span class="perUnit"
                                ><em :class="setPercentClass(outPrstPer)"
                                    ><span class="blind">감소</span></em
                                >{{ outPrstPer }}%</span
                            >
                        </div>
                    </div>
                </div>
                <!-- <div class="type div4">
                    <div class="boxArea dis">
                        <p class="tit">회전일 평균</p>
                        <div class="grid2a-list bg-dec2">
                            <ul class="single">
                                <li>
                                    <p class="count">
                                        90<em class="per">건</em>
                                    </p>
                                </li>
                            </ul>
                            <span class="perUnit"
                                ><em class="bulUpper"
                                    ><span class="blind">증가</span></em
                                >15.7%</span
                            >
                        </div>
                    </div>
                </div> -->
            </div>
            <!-- //dashForm_line 1 -->
        </div>
        <!-- //dashLayer_wrap -->

        <!-- dashLayer_wrap -->
        <div class="dashLayer_wrap">
            <!-- dashForm_line 1 -->
            <div class="dashForm">
                <div class="type div4">
                    <div class="listArea dis">
                        <ul>
                            <li class="backHeader">
                                <span class="tit">단말재고 TOP5</span>
                                <span class="date">재고수량</span>
                            </li>
                            <li
                                v-for="data in dis5TopList"
                                :key="data.listNm"
                                :class="data.class"
                            >
                                <span class="tit">{{ data.listNm }}</span>
                                <span class="date"> {{ data.listCnt }}</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="type div4">
                    <div class="listArea dis">
                        <ul>
                            <li class="backHeader">
                                <span class="tit">입고구분</span>
                                <span class="date">수량</span>
                            </li>
                            <li
                                v-for="data in innDtlList"
                                :key="data.listNm"
                                :class="data.class"
                            >
                                <span class="tit">{{ data.listNm }}</span>
                                <span class="date"> {{ data.listCnt }}</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="type div4">
                    <div class="listArea dis">
                        <ul>
                            <li class="backHeader">
                                <span class="tit">출고구분</span>
                                <span class="date">수량</span>
                            </li>
                            <li
                                v-for="data in outDtlList"
                                :key="data.listNm"
                                :class="data.class"
                            >
                                <span class="tit">{{ data.listNm }}</span>
                                <span class="date"> {{ data.listCnt }}</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="type div4">
                    <div class="listArea dis">
                        <ul>
                            <li class="backHeader">
                                <span class="tit">회전일</span>
                                <span class="date">수량</span>
                            </li>
                            <li
                                v-for="data in tovrDayList"
                                :key="data.listNm"
                                :class="data.class"
                            >
                                <span class="tit">{{ data.listNm }}</span>
                                <span class="date"> {{ data.listCnt }}</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- //dashForm_line 1 -->
            <!-- dashForm_line 2 -->
            <div class="dashForm">
                <div class="type div2">
                    <div class="boxArea dis2">
                        <p class="tit">미처리 / 미확정 알림</p>
                        <p class="infoIcon alram">
                            {{ movNtrtCnt }}<span>건</span>
                        </p>
                    </div>
                    <div class="boxArea dis2 mt20">
                        <p class="tit">당일 사고 / 불량 기기 현황</p>
                        <div class="grid3a-list mlr-15">
                            <ul>
                                <li>
                                    <p class="cost">
                                        {{ dayBadProdCnt
                                        }}<em class="per">건</em>
                                    </p>
                                    <p class="txt">단말</p>
                                </li>
                                <li>
                                    <p class="cost">
                                        {{ dayBadUsimCnt
                                        }}<em class="per">건</em>
                                    </p>
                                    <p class="txt">USIM</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="type div2">
                    <!--  Divide Type : 1x2 -->
                    <div class="approval-box">
                        <div class="approval-box_item">
                            <div class="boxArea dis2">
                                <p class="tit ac">재고요청 건수</p>
                                <p class="cost pointColor3">
                                    {{ movReqCnt }}<em class="per">건</em>
                                </p>
                            </div>
                        </div>
                        <div class="approval-box_item">
                            <div class="boxArea dis2">
                                <p class="tit ac">요청승인 건수</p>
                                <p class="cost pointColor3">
                                    {{ movAsgnCnt }}<em class="per">건</em>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- //Divide Type : 1x2 -->
                    <div class="boxArea dis2 mt20">
                        <p class="tit">전체 사고 / 불량 기기 현황</p>
                        <div class="grid3a-list mlr-15">
                            <ul>
                                <li>
                                    <p class="cost">
                                        {{ mthBadProdCnt
                                        }}<em class="per">건</em>
                                    </p>
                                    <p class="txt">단말</p>
                                </li>
                                <li>
                                    <p class="cost">
                                        {{ mthBadUsimCnt
                                        }}<em class="per">건</em>
                                    </p>
                                    <p class="txt">USIM</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- <div class="type div4">
                    <div class="listArea dis">
                        <ul>
                            <li class="backHeader">
                                <span>회전일 상위 TOP5 단말</span>
                            </li>
                            <li>
                                <span class="tit">회전일 상위 TOP5 매장</span>
                                <span class="date">100</span>
                            </li>
                            <li class="backGray">
                                <span class="tit">아이폰 13_PRO</span>
                                <span class="date">30</span>
                            </li>
                            <li>
                                <span class="tit">갤럭시 S22</span>
                                <span class="date">1,000</span>
                            </li>
                            <li class="backGray">
                                <span class="tit">갤럭시 S22+</span>
                                <span class="date">120</span>
                            </li>
                            <li>
                                <span class="tit">아이폰 13_PRO_MAX</span>
                                <span class="date">250</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="type div4">
                    <div class="listArea dis">
                        <ul>
                            <li class="backHeader">
                                <span>회전일 상위 TOP5 매장</span>
                            </li>
                            <li>
                                <span class="tit">회전일 상위 TOP5 매장</span>
                                <span class="date">100</span>
                            </li>
                            <li class="backGray">
                                <span class="tit">아이폰 13_PRO</span>
                                <span class="date">30</span>
                            </li>
                            <li>
                                <span class="tit">갤럭시 S22</span>
                                <span class="date">1,000</span>
                            </li>
                            <li class="backGray">
                                <span class="tit">갤럭시 S22+</span>
                                <span class="date">120</span>
                            </li>
                            <li>
                                <span class="tit">아이폰 13_PRO_MAX</span>
                                <span class="date">250</span>
                            </li>
                        </ul>
                    </div>
                </div> -->
            </div>
            <!-- //dashForm_line 2 -->
        </div>
        <!-- //dashLayer_wrap -->
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import _ from 'lodash'
import moment from 'moment'
import api from '@/api/biz/dis/dsm/disDsmDashBoard'

export default {
    name: 'DisDsmDashBoard',
    mixins: [CommonMixin],
    components: {},
    data() {
        return {
            titleNm: '',
            // 기준일
            refDate: '',
            // 재고 현황
            prstProdCnt: '0',
            prstProdTdCnt: '0',
            prstUsimCnt: '0',
            prstUsimTdCnt: '0',
            prstPer: '0',
            // 당일 입고 현황
            innPrstProdCnt: '0',
            innPrstProdTdCnt: '0',
            innPrstUsimCnt: '0',
            innPrstUsimTdCnt: '0',
            innPrstPer: '0',
            // 당일 출고 현황
            outPrstProdCnt: '0',
            outPrstProdTdCnt: '0',
            outPrstUsimCnt: '0',
            outPrstUsimTdCnt: '0',
            outPrstPer: '0',

            // 단말재고 TOP5
            dis5TopList: [],
            // 입고구분
            innDtlList: [],
            // 출고구분
            outDtlList: [],
            // 회전일
            tovrDayList: [],

            // 미처리 / 미확정 알림
            movNtrtCnt: '0',
            // 재고요청 건수
            movReqCnt: '0',
            // 요청승인 건수
            movAsgnCnt: '0',

            // 당일사고/불량기기현황
            dayBadProdCnt: '0',
            dayBadUsimCnt: '0',
            // 전체사고/불량기기현황
            mthBadProdCnt: '0',
            mthBadUsimCnt: '0',
        }
    },
    mounted() {
        this.fInit()
    },

    methods: {
        async fInit() {
            if (!_.isEmpty(this.userInfo['dealcoNm'])) {
                this.titleNm = this.userInfo.dealcoNm
            }
            this.refDate = moment().add(-1, 'days').format('YYYY년 MM월 DD일')

            // const formData = {
            //     orgCdLvl0: 'O00000',
            //     orgCd: '',
            //     orgLvl: '',
            //     dealcoCd: '57553',
            // }
            const formData = {
                orgCdLvl0: this.orgInfo.orgCdLvl0,
                orgCd: this.orgInfo.orgCd,
                orgLvl: this.orgInfo.orgLvl,
                dealcoCd: this.userInfo.dealcoCd,
            }

            api.getDisDashBoard(formData).then((res) => {
                //
                console.log(res.result)

                // 재고 현황
                this.prstProdCnt = CommonUtil.commaString(
                    res.result.disPrstVo.prodCnt
                )
                this.prstProdTdCnt = CommonUtil.commaString(
                    res.result.disPrstVo.prodTdCnt
                )
                this.prstUsimCnt = CommonUtil.commaString(
                    res.result.disPrstVo.usimCnt
                )
                this.prstUsimTdCnt = CommonUtil.commaString(
                    res.result.disPrstVo.usimTdCnt
                )

                this.prstPer = this.calcPercent(
                    res.result.disPrstVo.prodCnt,
                    res.result.disPrstVo.bfProdCnt
                )

                // 당일 입고 현황
                this.innPrstProdCnt = CommonUtil.commaString(
                    res.result.dayInnPrstVo.prodCnt
                )
                this.innPrstProdTdCnt = CommonUtil.commaString(
                    res.result.dayInnPrstVo.prodTdCnt
                )
                this.innPrstUsimCnt = CommonUtil.commaString(
                    res.result.dayInnPrstVo.usimCnt
                )
                this.innPrstUsimTdCnt = CommonUtil.commaString(
                    res.result.dayInnPrstVo.usimTdCnt
                )

                this.innPrstPer = this.calcPercent(
                    res.result.dayInnPrstVo.prodCnt,
                    res.result.dayInnPrstVo.bfProdCnt
                )

                // 당일 출고 현황
                this.outPrstProdCnt = CommonUtil.commaString(
                    res.result.dayOutPrstVo.prodCnt
                )
                this.outPrstProdTdCnt = CommonUtil.commaString(
                    res.result.dayOutPrstVo.prodTdCnt
                )
                this.outPrstUsimCnt = CommonUtil.commaString(
                    res.result.dayOutPrstVo.usimCnt
                )
                this.outPrstUsimTdCnt = CommonUtil.commaString(
                    res.result.dayOutPrstVo.usimTdCnt
                )

                this.outPrstPer = this.calcPercent(
                    res.result.dayOutPrstVo.prodCnt,
                    res.result.dayOutPrstVo.bfProdCnt
                )

                // 단말재고 TOP5
                this.dis5TopList = this.setListData(
                    res.result.dis5TopList,
                    'listCnt'
                )

                // 입고구분
                this.innDtlList = this.setListData(
                    res.result.innDtlList,
                    'listOrder'
                )

                // 출고구분
                this.outDtlList = this.setListData(
                    res.result.outDtlList,
                    'listOrder'
                )

                // 회전일
                this.tovrDayList = this.setListData(
                    res.result.tovrDayList,
                    'listOrder'
                )

                //
                this.movNtrtCnt = res.result.movNtrtCnt.cnt
                this.movReqCnt = res.result.movReqCnt.cnt
                this.movAsgnCnt = res.result.movAsgnCnt.cnt

                // 당일사고/불량기기현황
                this.dayBadProdCnt = res.result.dayBadProdVo.prodCnt
                this.dayBadUsimCnt = res.result.dayBadProdVo.usimCnt
                // 전체사고/불량기기현황
                this.mthBadProdCnt = res.result.mthBadProdVo.prodCnt
                this.mthBadUsimCnt = res.result.mthBadProdVo.usimCnt
            })
        },

        // 리스트 데이터 정렬, 배경색 class
        setListData(pList, orderKey, isReverse) {
            let res = []
            if (isReverse) {
                res = _.sortBy(pList, Number(orderKey)).reverse()
            } else {
                res = _.sortBy(pList, Number(orderKey))
            }
            _.map(res, (val, idx) =>
                idx % 2 == 1 ? _.assign(val, { class: 'backGray' }) : ''
            )
            return res
        },

        // 비율계산
        calcPercent(pProdCnt, pBfProdCnt) {
            let prodCnt = Number(pProdCnt)
            let bfProdCnt = Number(pBfProdCnt)
            const res =
                bfProdCnt != 0
                    ? Math.floor(((prodCnt - bfProdCnt) / bfProdCnt) * 100)
                    : 0
            return res
        },

        // class 적용 ==============================================
        // 상승하락 기호
        setPercentClass(pPercent) {
            return Number(pPercent) >= 0 ? 'bulUpper' : 'bulLower'
        },
        // 상승 배경색
        getPosBColor(value) {
            return value >= 0 ? true : false
        },
        // 하락 배경색
        getNegBColor(value) {
            return value < 0 ? true : false
        },
        // 하락 글자색
        getNegTColor(value) {
            return value < 0 ? true : false
        },
    },
}
</script>
