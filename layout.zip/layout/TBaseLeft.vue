<template>
    <!-- LefeMenu -->
    <div class="leftWrap">
        <div class="member">
            <p class="memberName">{{ userNm }}</p>
            <p class="memberInfo">{{ orgNmLvl0 }}</p>
        </div>

        <ul class="myInfo">
            <li>
                <a @click="onfavoriteAddClick">
                    <span class="favorite"></span>
                    <p class="btn_left">Favorite</p>
                </a>
            </li>
            <li>
                <a @click="onSmsSendClick">
                    <span class="sms"> </span>
                    <p class="btn_left">SMS</p>
                </a>
            </li>
            <MainSmsSendPopup
                v-if="showMainSmsSend"
                :parentParam="searchSmsParam"
                :dialogShow.sync="showMainSmsSend"
                @confirm="onSmsSendReturnData"
            />
            <li>
                <a @click="logout">
                    <span class="logout"> </span>
                    <p class="btn_left">Logout</p>
                </a>
            </li>
        </ul>
        <!-- LefeTab -->
        <div class="ltabWrap">
            <v-tabs class="leftTab" v-model="active_tab">
                <v-tab> 업무메뉴 </v-tab>
                <v-tab @click="onfavoriteTabClick"> 즐겨찾기 </v-tab>
                <v-tab-item>
                    <template>
                        <div style="color: black" class="tabCont">
                            <!-- LefeMenu Navi -->
                            <nav class="nav">
                                <ul
                                    v-for="(itemLv2, indexLv2) in leftMenus"
                                    v-bind:key="itemLv2.menuNo"
                                >
                                    <!-- 2depth -->
                                    <li
                                        :class="`menuLv2List ${
                                            indexLv2 === 0 ? 'active' : ''
                                        }`"
                                        @click="onToggleLv2"
                                    >
                                        <strong role="button">{{
                                            itemLv2.menuNm
                                        }}</strong>

                                        <ul
                                            v-for="(
                                                subItem, subIndex
                                            ) in itemLv2['subMenus']"
                                            v-bind:key="subItem.menuNo"
                                            :class="
                                                subItem.menuLvlCd === '3' ||
                                                subItem.menuLvlCd === '4'
                                                    ? 'lastDepth'
                                                    : ''
                                            "
                                            :style="
                                                indexLv2 === 0
                                                    ? ''
                                                    : 'display:none'
                                            "
                                        >
                                            <!-- 3depth. 선택되었을 경우 : class="active" -->
                                            <li
                                                v-if="subItem.menuLvlCd === '3'"
                                                :class="`menuLv3List ${
                                                    subIndex === 0
                                                        ? 'active'
                                                        : ''
                                                }`"
                                                @click="onToggleLv3"
                                            >
                                                <strong role="button">{{
                                                    subItem.menuNm
                                                }}</strong>
                                                <!-- 4depth -->
                                                <ul
                                                    v-for="itemLv4 in subItem[
                                                        'subMenus'
                                                    ]"
                                                    v-bind:key="itemLv4.menuNo"
                                                    :style="
                                                        subIndex === 0
                                                            ? ''
                                                            : 'display:none'
                                                    "
                                                >
                                                    <li>
                                                        <a
                                                            href=""
                                                            @click.prevent="
                                                                onPageClick(
                                                                    itemLv4.menuUrl,
                                                                    $event
                                                                )
                                                            "
                                                            :class="
                                                                currentClass(
                                                                    itemLv4.menuNo
                                                                )
                                                            "
                                                            >{{
                                                                itemLv4.menuNm
                                                            }}</a
                                                        >
                                                    </li>
                                                </ul>
                                                <!-- //4depth -->
                                            </li>
                                            <!-- //3depth -->
                                            <!-- 4depth -->
                                            <li
                                                v-else-if="
                                                    subItem.menuLvlCd === '4'
                                                "
                                            >
                                                <a
                                                    href=""
                                                    @click.prevent="
                                                        onPageClick(
                                                            subItem.menuUrl,
                                                            $event
                                                        )
                                                    "
                                                    :class="
                                                        currentClass(
                                                            subItem.menuNo
                                                        )
                                                    "
                                                    >{{ subItem.menuNm }}</a
                                                >
                                            </li>
                                            <!-- //4depth -->
                                        </ul>
                                    </li>
                                </ul>
                                <!-- //2depth -->
                            </nav>
                            <!-- //LefeMenu Navi -->
                        </div>
                    </template>
                </v-tab-item>
                <v-tab-item>
                    <template>
                        <div class="tabCont bookmark">
                            <!-- 즐겨찾기 -->
                            <div class="btnWrap">
                                <!-- 편집 버튼 -->
                                <TCComButton
                                    :Vuetify="false"
                                    @click="onEditingFavorite()"
                                    eClass="btn_ty06"
                                    labelName="편집"
                                />
                                <!-- disabled -->
                                <!-- <TCComButton
                                    :Vuetify="false"
                                    eClass="btn_ty06"
                                    labelName="편집"
                                    disabled
                                /> -->
                                <!-- //편집 버튼 -->
                            </div>
                            <div class="editWrap">
                                <!-- case 1: 편집 -->
                                <div class="edidList">
                                    <draggable v-model="favoriteArray">
                                        <div
                                            class="editComp"
                                            v-for="(
                                                todoItem, index
                                            ) in favoriteArray"
                                            :key="index"
                                            :onAdd="dragMove(index)"
                                            :change="false"
                                        >
                                            <span class="chk">
                                                <input
                                                    v-if="favoriteEditingShow"
                                                    type="checkbox"
                                                    v-model="favoriteCheckArray"
                                                    :value="`${todoItem.menuNo}`"
                                                />
                                                <label
                                                    style="cursor: pointer"
                                                    @click="
                                                        onClickFavoriteUrl(
                                                            todoItem.menuUrl
                                                        )
                                                    "
                                                    >{{
                                                        todoItem.menuNm
                                                    }}</label
                                                >
                                            </span>
                                            <span class="ico">
                                                <button
                                                    v-if="favoriteEditingShow"
                                                    @click="
                                                        onDelFavorite(
                                                            todoItem.menuNo
                                                        )
                                                    "
                                                    type="button"
                                                    class="delIcon"
                                                ></button>
                                            </span>
                                        </div>
                                    </draggable>
                                </div>
                                <!-- //case 1: 편집 -->

                                <!-- 버튼 영역 -->
                                <div
                                    class="bottomWrap"
                                    v-if="favoriteEditingShow"
                                >
                                    <!-- 선택삭제 버튼 -->
                                    <TCComButton
                                        :Vuetify="false"
                                        eClass="btn_selectDel"
                                        labelName="선택삭제"
                                        @click="onDelFavoriteAll()"
                                    >
                                    </TCComButton>
                                    <!-- //선택삭제 버튼 -->
                                    <!-- disabled -->
                                    <!-- <TCComButton
                                    :Vuetify="false"
                                    eClass="btn_selectDel"
                                    labelName="선택삭제"
                                    disabled
                                >
                                </TCComButton> -->
                                </div>
                                <!-- //버튼 영역 -->
                            </div>

                            <!-- 하단 버튼 영역 -->
                            <!-- <div class="footerBtnWrap">
                                <TCComButton
                                    :Vuetify="false"
                                    eClass="btn_selectDel"
                                    labelName="선택삭제"
                                >
                                </TCComButton>
                            </div> -->
                            <!-- //하단 버튼 영역 -->
                            <!-- //즐겨찾기 -->
                        </div>
                    </template>
                </v-tab-item>
            </v-tabs>
        </div>
        <!-- //LefeTab -->
        <!-- <img
            src="@/assets/images/temp/leftmenu3.png"
            height="510px"
            width="auto"
        /> -->
        <!-- LefeMenu 임시 이미지 -->
    </div>
    <!--  LefeMenu // -->
</template>

<style></style>
<script>
import CommonMixin from '@/mixins'
import _ from 'lodash'
import tBaseBookmarkApi from '@/api/common/tBaseBookmarkApi'
//====================//SMS전송팝업====================
import MainSmsSendPopup from '@/components/common/MainSmsSendPopup'
//====================//SMS전송팝업==================
import draggable from 'vuedraggable'
export default {
    name: 'layout-left',
    mixins: [CommonMixin],
    components: { MainSmsSendPopup, draggable },
    data() {
        return {
            active_tab: 0,
            show: false,
            expand: false,
            active: false,
            value: '',
            tab: null,
            tabs: null,
            tabitems: [
                { tab: '업무메뉴', content: '업무메뉴 영역' },
                { tab: '즐겨찾기', content: '즐겨찾기 영역' },
            ],
            items: [
                { tab: '업무메뉴', content: 'Tab 1 Content' },
                { tab: '즐겨찾기', content: 'Tab 2 Content' },
            ],
            leftMenus: [],
            activeLv2: '',
            activeLv3: '',
            favoriteParam: {
                menuNo: '',
                saveYn: '',
            },
            favoriteArray: [],
            favoriteArrayCnt: 0,
            favoriteCheckArray: [],
            favoriteCnt: 0,

            favoriteEditingShow: false,
            //favoriteClick: true,
            enabled: true,
            //SMS SEND
            showMainSmsSend: false,
            searchSmsParam: {
                type: Object,
                default: () => {},
                required: false,
            },
            userNm: '',
            orgNmLvl0: '',
        }
    },
    computed: {
        getMenuGrpCd() {
            return this.currentMenuInfo.menuGrpCd
        },
    },
    watch: {
        getMenuGrpCd: {
            handler: function (value) {
                if (this.menuInfo != undefined) {
                    const menus = this.menuInfo.filter(
                        (item) =>
                            item.menuGrpCd === value &&
                            item.topMenuYn === 'N' &&
                            item.useYn === 'Y'
                    )

                    if (menus.length) {
                        const menuTree = this.getMenuTree(menus)
                        this.leftMenus = _.get(menuTree[0], 'subMenus')
                    }
                }
            },
            deep: true,
            immediate: true,
        },
    },
    created() {},
    mounted() {
        //Store에 있는 정보 담기
        this.userNm = !_.isEmpty(this.userInfo) ? this.userInfo.userNm : ''
        this.orgNmLvl0 = !_.isEmpty(this.orgInfo) ? this.orgInfo.orgNmLvl0 : ''

        let active_tab = this.$route.params.active_tab
        if (1 != active_tab) {
            this.active_tab = 0
        } else {
            this.active_tab = active_tab
        }

        this.getFavoriteApi()
        this.init()
    },
    methods: {
        init() {},
        onfavoriteTabClick() {
            //this.getFavoriteApi()
            //this.favoriteParam.saveYn = 'Y'
            this.favoriteEditingShow = false
        },
        getMenuTree(menus) {
            const parentProp = 'supMenuNo' // 부모가 되는 속성 정의
            const keyProp = 'menuNo' // 키가 되는 속성 정의
            let map = {}
            for (let i = 0; i < menus.length; i++) {
                let obj = menus[i]
                obj = { ...obj, subMenus: [] }

                // 메뉴 정보를 map 오브젝트 속성(메뉴번호)에 설정
                map[obj[keyProp]] = obj
                // 값이 존재하지 않으면 문자열 root으로 처리
                const parent = obj[parentProp] ?? 'root'

                // 값이 존재하지 않으면 subMenus 속성 초기화
                if (!map[parent]) {
                    map[parent] = {
                        subMenus: [],
                    }
                }
                map[parent].subMenus.push(obj)
            }

            // subMenus 속성 length가 0이면 속성 제거
            // for (let prop in map) {
            //     if (map[prop].subMenus.length === 0) {
            //         delete map[prop].subMenus
            //     }
            // }
            return map['root'].subMenus
        },

        //왼쪽메뉴 화면(Lv4) 클릭이벤트
        onPageClick(url, ev) {
            this.$router
                .push({
                    name: url,
                })
                .catch(() => {})

            ev.stopPropagation()
            // @click.prevent 사용시 중복 된 기능이라 주석처리
            // ev.preventDefault()
        },

        // LogOut
        logout: function () {
            //let opt = { header: 'LOGOUT' }
            //this.showTcComConfirm('로그아웃 진행 하시겠습니까?', opt).then(
            this.showTcComConfirm('로그아웃 진행 하시겠습니까?').then(
                (confirm) => {
                    if (confirm) {
                        this.$router.push({
                            name: '/smlogoff',
                        })
                    }
                }
            )
        },

        onToggleLv2(ev) {
            const menuListObjs = document.querySelectorAll('.menuLv2List')
            const curChildNodes = ev.currentTarget.childNodes
            if (ev.currentTarget.className === 'menuLv2List active') {
                curChildNodes.forEach((el) => {
                    if (el.nodeName === 'UL') {
                        el.style.display = 'none'
                    }
                })
                ev.currentTarget.classList.remove('active')
            } else {
                ev.currentTarget.classList.add('active')
            }
            menuListObjs.forEach((el) => {
                if (el.className === 'menuLv2List active') {
                    el.childNodes.forEach((child) => {
                        if (child.nodeName === 'UL') {
                            child.style.display = ''
                        }
                    })
                }
            })
            ev.stopPropagation() // 부모 태그로의 이벤트 전파를 중지
            ev.preventDefault() // 클릭 이벤트 외에 별도의 브라우저 행동을 막기 위한 메서드
        },

        onToggleLv3(ev) {
            const menuListObjs = document.querySelectorAll('.menuLv3List')
            const curChildNodes = ev.currentTarget.childNodes
            if (ev.currentTarget.className === 'menuLv3List active') {
                curChildNodes.forEach((el) => {
                    if (el.nodeName === 'UL') {
                        el.style.display = 'none'
                    }
                })
                ev.currentTarget.classList.remove('active')
            } else {
                ev.currentTarget.classList.add('active')
            }
            menuListObjs.forEach((el) => {
                if (el.className === 'menuLv3List active') {
                    el.childNodes.forEach((child) => {
                        if (child.nodeName === 'UL') {
                            child.style.display = ''
                        }
                    })
                }
            })
            ev.stopPropagation() // 부모 태그로의 이벤트 전파를 중지
            ev.preventDefault() // 클릭 이벤트 외에 별도의 브라우저 행동을 막기 위한 메서드
        },

        //현재메뉴 class적용
        currentClass(menuNo) {
            return [this.$route.meta.menuNo == menuNo ? 'active' : '']
        },
        //즐겨찾기조회
        async getFavoriteApi() {
            // 체크내역 초기화.
            this.favoriteCheckArray = []

            await tBaseBookmarkApi
                .getFavoriteApi(this.favoriteParam)
                .then((res) => {
                    console.log('getFavoriteApi then : ', res)

                    this.favoriteArray = res
                    this.favoriteArrayCnt = res.length
                })
        },
        //즐겨찾기전체저장
        postFavoriteAllApi() {
            tBaseBookmarkApi
                .postFavoriteAllApi(this.favoriteArray)
                .then((res) => {
                    console.log('postFavoriteAllApi then : ', res)

                    //this.favoriteArray = res
                })
        },
        //즐겨찾기추가
        postFavoriteApi() {
            this.active_tab = 1
            this.favoriteEditingShow = false
            tBaseBookmarkApi.postFavoriteApi(this.favoriteParam).then((res) => {
                console.log('postFavoriteApi then : ', res)
                //추가후 리스트
                this.getFavoriteApi()
                //this.favoriteArray = res
                this.showTcComAlert('즐겨찾기에 추가 되었습니다.', {
                    header: '저장',
                    size: '500',
                    confirmLabel: 'OK',
                })
            })
        },

        //즐겨찾기정렬수정
        putFavoriteSortApi() {
            //console.log('putFavoriteSortApi===>', this.favoriteArray)
            let arrayLength = this.favoriteArray.length
            for (let i = 0; i < arrayLength; i++) {
                //console.log(i, this.favoriteArray[i].sortSeq, arrayLength)
                //배열순서대로 재정렬
                this.favoriteArray[i].sortSeq = i
            }

            //console.log('putFavoriteSortApi===>', this.favoriteArray)
            tBaseBookmarkApi
                .putFavoriteSortApi(this.favoriteArray)
                .then((res) => {
                    console.log('putFavoriteSortApi then : ', res)
                    this.getFavoriteApi()
                })
        },
        //즐겨찾기체크삭제
        deleteFavoriteAllApi(fParamArray) {
            //console.log('putFavoriteSortApi222===>', this.favoriteArray)
            tBaseBookmarkApi.deleteFavoriteAllApi(fParamArray).then((res) => {
                console.log('postFavoriteApi then : ', res)
                //재조회
                this.getFavoriteApi()
                //편집모드->정상모드로
                this.favoriteEditingShow = false
            })
        },
        //즐겨찾기단건삭제
        deleteFavoriteApi() {
            this.showTcComConfirm('즐겨찾기 내역을 삭제 하시겠습니까?').then(
                (confirm) => {
                    if (confirm) {
                        tBaseBookmarkApi
                            .deleteFavoriteApi(this.favoriteParam)
                            .then((res) => {
                                console.log('deleteFavoriteApi then : ', res)

                                this.getFavoriteApi()
                            })
                    }
                }
            )
        },
        onSmsSendClick() {
            if (this.userInfo.attcClCd == 1) {
                this.showMainSmsSend = true
            } else {
                this.showTcComAlert('권한이 없습니다.')
                return
            }
        },
        //SMS리턴
        onSmsSendReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.showTcComAlert('발송 완료 되었습니다.', {
                header: '성공',
                size: '500',
                confirmLabel: 'OK',
            })
            //this.searchSmsParam.cd = _.get(retrunData, 'cd')
            this.showMainSmsSend = false
        },
        onfavoriteAddClick() {
            if (undefined == this.$route.meta.menuNo) {
                this.showTcComAlert(
                    '실패하였습니다. 정상적인 메뉴가 아닙니다. ',
                    {
                        header: '추가실패',
                        size: '500',
                        confirmLabel: 'OK',
                    }
                )
                return
            } else if (0 == this.$route.meta.menuNo) {
                this.showTcComAlert(
                    '대시보드는 즐겨찾기등록이 되지 않습니다.',
                    {
                        header: '추가실패',
                        size: '500',
                        confirmLabel: 'OK',
                    }
                )
                return
            }

            if (this.favoriteValidation('add')) return
            this.favoriteParam.menuNo = this.$route.meta.menuNo
            this.postFavoriteApi()
        },
        dragMove(index) {
            //console.log(event.type)
            if (undefined != event) {
                if ('drop' == event.type) {
                    //드래그시 모든 즐겨찾기 건이 모두 sort되므로 마지막건 이동시 저장실행.
                    if (1 + index == this.favoriteArray.length) {
                        console.log('#### DRAG_저장실행 ####')
                        this.putFavoriteSortApi()
                    }
                }
            }
        },

        onDelFavorite(menuNo) {
            this.favoriteParam.menuNo = menuNo
            this.deleteFavoriteApi()
        },
        //즐겨찾기 체크된것 삭제
        onDelFavoriteAll() {
            if (this.favoriteValidation('check')) return
            console.log(this.favoriteCheckArray)

            this.showTcComConfirm('즐겨찾기 내역을 삭제 하시겠습니까?').then(
                (confirm) => {
                    if (confirm) {
                        let fParamArray = []
                        this.favoriteCheckArray.forEach((data) => {
                            //console.log(data)
                            let fParam = {}
                            fParam.menuNo = data
                            fParamArray.push(fParam)
                        })

                        this.deleteFavoriteAllApi(fParamArray)
                    }
                }
            )
        },
        //즐겨찾기 편집모드
        onEditingFavorite() {
            if (this.favoriteEditingShow) {
                this.favoriteEditingShow = false
            } else {
                this.favoriteEditingShow = true
            }
        },
        //즐겨찾기페이지이동
        onClickFavoriteUrl(menuUrl) {
            if (!this.favoriteEditingShow) {
                this.$router.push({
                    name: menuUrl,
                    params: '',
                })
            }
        },
        //진행불가시 true
        favoriteValidation(key) {
            //추가
            if ('add' == key) {
                let arrayLength = this.favoriteArray.length
                for (let i = 0; i < arrayLength; i++) {
                    if (
                        this.favoriteArray[i].menuNo == this.$route.meta.menuNo
                    ) {
                        this.showTcComAlert(
                            '즐겨찾기에 이미 등록 되어있습니다.',
                            {
                                header: '등록내역확인',
                                size: '500',
                                confirmLabel: 'OK',
                            }
                        )
                        return true
                    }
                }
            }

            //체크박스 선택시 후 삭제시
            if ('check' == key) {
                if (0 == this.favoriteCheckArray.length) {
                    this.showTcComAlert('선택된 체크내역이 없습니다.', {
                        header: '체크내역확인',
                        size: '500',
                        confirmLabel: 'OK',
                    })
                    return true
                }
            }

            return false
        },
    },
}
</script>
