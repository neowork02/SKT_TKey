<template>
    <div class="div5_5 cont3">
        <ul class="btnOrder">
            <li>
                <TCComButton
                    :Vuetify="false"
                    color=""
                    eClass="btnOrderleft"
                    @click="addBtn"
                    :objAuth="this.objAuth"
                >
                </TCComButton>
            </li>
            <li>
                <TCComButton
                    :Vuetify="false"
                    color=""
                    eClass="btnOrderright"
                    @click="delBtn"
                    :objAuth="this.objAuth"
                >
                </TCComButton>
            </li>
        </ul>
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/authMgmt/helpers'
export default {
    name: 'ButtonContainer',
    components: {},
    data() {
        return {
            objAuth: {},
            showFlag: false,
            title: 'BasAdmAuthMgmtButtonCont',
            status: 1,
            isReadOnly: false,
            form: {},
        }
    },
    created() {},
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        async addBtn() {
            await this.defaultAssign_({
                key: 'moveStore',
                value: 'add',
            })
        },
        async delBtn() {
            await this.defaultAssign_({
                key: 'moveStore',
                value: 'del',
            })
        },
    },
}
</script>
