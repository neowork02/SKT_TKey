<template>
    <div class="content">
        <!-- Tit -->
        <h1>정보사용자이력조회</h1>
        <!-- // Tit -->
        <!-- //================================버튼========================== -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="resetBtn"
                    :objAuth="this.objAuth"
                    >초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                    >조회
                </TCComButton>
            </li>
        </ul>
        <!-- //================================//버튼========================== -->
        <!-- //================================searchLayer_wrap========================== -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="DP"
                        v-model="arrDate"
                        labelName="조회일자"
                        :objAuth="this.objAuth"
                    ></TCComDatePicker>
                </div>
                <!--
                <div class="formitem div5_1">
                    <TCComComboBox
                        codeId="ZBAS_C_00380"
                        v-model="reqParam.attcClCd"
                        labelName="소속유형"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        @change="cmb_attcCat_OnChanged"
                        :eRequired="true"
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>

                <div class="formitem div5_1">
                    <TCComComboBox
                        :itemList="commUserGrpList"
                        v-model="reqParam.userGrp"
                        labelName="권한그룹"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :eRequired="true"
                        :objAuth="objAuth"
                        :disabled="disabledUserGrp"
                    ></TCComComboBox>
                </div>
                
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="reqParam.userNm"
                        :codeVal.sync="reqParam.userId"
                        labelName="사용자ID"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onUserEnterKey"
                        @appendIconClick="onUserIconClick"
                        @input="onUserInput"
                    />
                    <BasBcoUserPopup
                        v-if="showBcoUser"
                        :parentParam="reqParam"
                        :rows="resultUserRows"
                        :dialogShow.sync="showBcoUser"
                        @confirm="onUserReturnData"
                    />
                </div>
                -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="reqParam.screenNm"
                        labelName="화면명"
                        :objAuth="objAuth"
                        @enterKey="searchBtn"
                    >
                    </TCComInput>
                </div>
                <!-- <div class="formitem div4">
                    <TCComComboBox
                        labelName="수행업무_old"
                        v-model="reqParam.actionClCd"
                        :objAuth="objAuth"
                        codeId="ACTION_CL"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div> -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="수행업무"
                        v-model="reqParam.actClCd"
                        :itemList="ds_actionCl"
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="데이터구분"
                        v-model="reqParam.dataClCd"
                        :objAuth="objAuth"
                        codeId="DATA_CL"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
        </div>
        <!-- //================================//searchLayer_wrap========================== -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="화면목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getCustLogList_"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <!-- gridWrap -->
    </div>
</template>

<script>
import { CommonGrid } from '@/utils'
import attachedFileApi from '@/api/common/attachedFile'
import { HEADER } from '@/const/grid/bas/usm/basUsmNtcCinfLogHeader'
import API from '@/api/biz/bas/usm/basUsmNtcCinfLog'
import commonApi from '@/api/common/commonCode'
//====================사용자팝업====================
// import BasBcoUserPopup from '@/components/common/BasBcoUserPopup'
// import basBcoUserApi from '@/api/biz/bas/bco/basBcoUserPop'
//====================//사용자팝업====================
// import _ from 'lodash'

import moment from 'moment'
import CommonMixin from '@/mixins'
export default {
    name: 'BasUsmNtcCinfLog',
    mixins: [CommonMixin],
    components: {
        // BasBcoUserPopup,
    },

    data() {
        return {
            objAuth: {},
            // gridStyle: {
            //     height: '500px', //그리드 높이 조절
            // },
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            arrDate: [],
            resultList: [],
            reqParam: {
                attcClCd: '', // 소속유형
                userGrp: '', //권한그룹
                userId: '',
                userNm: '',
                screenNm: '',
                actClCd: '',
                dataClCd: '',
            },
            commUserGrpOriginList: [],
            commUserGrpList: [],
            rowCnt: 15,
            activePage: 1, // 현재페이지
            paging: {
                pageNum: 1,
                pageSize: 15,
                totalPageCnt: 0,
                totalDataCnt: 0,
            },
            resultUserRows: [],
            disabledUserGrp: true,
            //====================사용자팝업관련====================
            showBcoUser: false, // 서비스상품 팝업 오픈 여부
            searchUserParam: {},
            resultUserProdRows: [], // 서비스상품 팝업 오픈 여부
            //====================//사용자팝업관련==================
            ds_actionCl: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '조회',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '저장',
                },
                {
                    commCdVal: '3',
                    commCdValNm: '삭제',
                },
                {
                    commCdVal: '4',
                    commCdValNm: '엑셀다운로드',
                },
            ],
            excelParam: {},
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState(true)
        this.initParam()
        // 공통코드 API
        this.getCommCodeList('ZBAS_C_00250')
    },

    methods: {
        initParam() {
            this.resultList = []
            this.arrDate = [
                moment(new Date()).format('YYYY-MM-DD'),
                moment(new Date()).format('YYYY-MM-DD'),
            ]
            this.reqParam = {
                attcClCd: '', // 소속유형
                actClCd: '',
                userGrp: '', //권한그룹
                userId: '',
                userNm: '',
                screenNm: '',
                dataClCd: '',
            }
            this.paging = {
                pageNum: 1,
                pageSize: 10,
                totalPageCnt: 0,
                totalDataCnt: 0,
            }
        },
        init() {
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수),
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        // pageMove(page) {
        //     console.log('pageMove', page)
        //     //Page Move
        //     this.paging.pageNum = page
        //     let paramObj = { ...this.reqParam }
        //     paramObj.fromDt = this.removeHyphen(this.arrDate[0])
        //     paramObj.toDt = this.removeHyphen(this.arrDate[1])

        //     paramObj.pageNum = this.paging.pageNum
        //     paramObj.pageSize = this.paging.pageSize

        //     this.getCustLogList_(paramObj)
        // },
        chgRowCnt(pageSize) {
            this.rowCnt = pageSize
        },
        // 공통코드 API
        getCommCodeList(codeId) {
            commonApi.getCommonCodeListById(codeId).then((res) => {
                if (res !== undefined) {
                    this.commUserGrpOriginList = res
                    // this.dCommItemList = res
                }
            })
        },
        /*
        //===================== 사용자팝업관련 methods ================================
        // 사용자 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 사용자 팝업 오픈
        getUserPopList() {
            basBcoUserApi.getUserPopList(this.searchUserParam).then((res) => {
                console.log('getUserPopList then : ', res)
                // 검색된 사용자 정보가 1건이면 TextField에 바로 설정
                // 검색된 사용자 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (!_.isEmpty(res)) {
                    this.reqParam.userId = _.get(res[0], 'userId')
                    this.reqParam.userNm = _.get(res[0], 'userNm')
                } else {
                    this.resultUserRows = res
                    this.showBcoUser = true
                }
            })
        },
        // 사용자 TextField 돋보기 Icon 이벤트 처리
        onUserIconClick() {
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultUserRows = []
            // 검색조건 사용자명이 빈값이 아니면 사용자 정보 조회
            // 그 이외는 사용자 팝업 오픈
            if (!_.isEmpty(this.searchUserParam.suplSvcNm)) {
                this.getUserPopList()
            } else {
                this.showBcoUser = true
            }
        },
        // 사용자 TextField 엔터키 이벤트 처리
        onUserEnterKey() {
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultUserRows = []
            // 검색조건 사용자명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchUserParam.userNm)) {
                this.showTcComAlert('사용자명을 입력해주세요.')
                return false
            }
            // 사용자 정보 조회
            this.getUserPopList()
        },
        // 사용자 TextField Input 이벤트 처리
        onUserInput() {
            // 입력되는 값이 있으면 사용자 코드 초기화
            this.reqParam.userCd = ''
        },
        // 사용자 팝업 리턴 이벤트 처리
        onUserReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.reqParam.userId = _.get(retrunData, 'userId')
            this.reqParam.userNm = _.get(retrunData, 'userNm')
        },
        //===================== //사용자팝업관련 methods ================================
*/
        executePayment(map, type) {
            return map[type]
        },
        //조회 버튼 이벤트
        searchBtn: function () {
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getCustLogList_(1)
        },

        getCustLogList_(pageNum) {
            this.reqParam.fromDt = this.removeHyphen(this.arrDate[0])
            this.reqParam.toDt = this.removeHyphen(this.arrDate[1])
            let paramObj = { ...this.reqParam }

            paramObj.pageSize = this.rowCnt
            paramObj.pageNum = pageNum

            if (paramObj.dataClCd == '01') {
                paramObj.custClCd = 'S'
            } else if (paramObj.dataClCd == '02') {
                paramObj.custClCd = 'N'
            }

            console.log('paramObj : ', paramObj)
            this.excelParam = paramObj

            let data

            API.getCustLogList(paramObj)
                .then((result) => {
                    console.log('result -> ', result)
                    data = result
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    if (data.gridList.length > 0) {
                        this.resultList = data.gridList
                        this.paging = data.pagingDto
                    } else {
                        this.showTcComAlert('데이터가 없습니다.')
                        this.resultList = []
                        this.paging = {
                            pageNum: 1,
                            pageSize: 15,
                            totalPageCnt: 0,
                            totalDataCnt: 0,
                        }
                    }
                    this.gridSet()
                })
        },
        gridSet() {
            // dataSet
            this.gridObj.setRows(this.resultList)
            this.gridObj.setGridIndicator(this.paging) //순번이 필요한경우 계산하는 함수

            // paging
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
        },

        // 소속유형 이벤트
        cmb_attcCat_OnChanged(e) {
            // console.log(e)
            if (e == '1') {
                this.disabledUserGrp = true
            } else {
                this.disabledUserGrp = false
            }

            this.commUserGrpList = []

            if (e == '') {
                this.reqParam.userGrp = ''
                this.commUserGrpList = this.commUserGrpOriginList
                this.disabledUserGrp = true
            } else {
                // 소속유형에 따른 권한그룹 combobox filter
                this.commUserGrpList = this.commUserGrpOriginList.filter(
                    (item) => item['addInfo1'] == e
                )
                this.reqParam.userGrp = ''
            }
        },

        //초기화 버튼 이벤트
        resetBtn: function () {
            this.initParam()
            this.gridSet()
        },

        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            var date = new Date()
            var year = date.getFullYear()
            var month = ('0' + (1 + date.getMonth())).slice(-2)
            var day = ('0' + date.getDate()).slice(-2)

            return year + '-' + month + '-' + day
        },

        // 문자열 하이픈 제거
        removeHyphen: function (val) {
            try {
                return val.replace(/[^0-9]/g, '')
            } catch (e) {
                return val
            }
        },

        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/usm/usmCustLogExcelList',
                this.excelParam
            )
        },
    },
}
</script>
