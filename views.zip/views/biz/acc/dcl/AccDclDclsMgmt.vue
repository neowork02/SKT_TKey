<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccSacWireEtcUpld.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <AccHeadline title="일마감관리" />

        <AccSearchField
            ref="accSearchField"
            :offset="[
                'btn-left-closed',
                'btn-left-closedCancel',
                { slotButtonLeft: 'workClCd' },
                'btn-right-reset',
                'btn-right-view',
                'search-clsDt',
                '!search-accumuCl',
                '!search-lastDayCls',
            ]"
            :initValue="initValue"
            :statusHiddenBtn="statusHiddenBtn"
            :statusDisableSearch="{
                lastDayCls: true,
            }"
            @reset="resetForm"
            @view="viewForm"
            @closed="closedForm"
            @closedCancel="closedCancelForm"
        >
            <template slot="workClCd">
                <div class="multiForm">
                    <div class="col1">
                        <TCComComboBox
                            v-model="formGetDayClsInfo.query.workClCd"
                            codeId="WORK_CL_CD"
                            blankItemText="전체"
                            blankItemValue=""
                            labelName=""
                            :addBlankItem="true"
                            :filterFunc="filterFunc"
                        ></TCComComboBox>
                    </div>
                </div>
            </template>
        </AccSearchField>

        <AccGridTable
            ref="accGridTablePart"
            title="파트별현황"
            class="accGridTable"
            noPaging
            :offset="['btn-excelDownload']"
            :gridMeta="GRID_HEADER_PART"
            :data="formGetDayClsInfo.data.partList"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/dcl/day-cls-info-parts-excel-download`,
                query: formGetDayClsInfo.query,
            }"
        />

        <AccGridTable
            ref="accGridTableSwing"
            title="Swing실적현황"
            class="accGridTable"
            noPaging
            :offset="['btn-excelDownload']"
            :gridMeta="GRID_HEADER_SWING"
            :data="formGetDayClsInfo.data.ukeyList"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/dcl/day-cls-info-ukies-excel-download`,
                query: formGetDayClsInfo.query,
            }"
        />
    </div>
</template>
<style scoped>
.accGridTable :deep(.rg-header) .rg-table tr td.emphasis .rg-header-renderer {
    /* color: #0388fc; */
    color: #92d6ff;
}
</style>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'
import moment from 'moment'

import {
    getTodayDate,
    convertDate,
    distanceDate,
    getCalcDays,
    isSameDate,
    errorHandle,
} from '@/utils/accUtil'

import AccHeadline from '@/components/biz/common/acc/AccHeadline'
import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import dclApi from '@/api/biz/acc/dcl'

import {
    GRID_HEADER as GRID_HEADER_PART,
    // MOCK_DATA,
} from '@/const/grid/acc/dcl/AccDclDclsMgmtPartGrid'
import { GRID_HEADER as GRID_HEADER_SWING } from '@/const/grid/acc/dcl/AccDclDclsMgmtSwingGrid'

export default {
    name: 'AccSacWireEtcUpld',
    mixins: [CommonMixin, accMixin],
    components: {
        AccHeadline,
        AccSearchField,
        AccGridTable,
    },
    data() {
        return {
            GRID_HEADER_PART,
            GRID_HEADER_SWING,

            initValue: {
                clsDt: getTodayDate('YYYY-MM-DD'),
                accumuCl: '0',
                pageSize: 15,
                pageNum: 1,
            },

            statusHiddenBtn: {
                closed: false,
                closedCancel: true,
            },

            formGetDayClsInfo: {
                query: {
                    workClCd: '',
                },
                data: {
                    partList: [],
                    ukeyList: [],
                },
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formGetLastDayCls: {
                query: {},
                data: {},
            },

            formPostSaveDayCls: {
                query: {},
                data: {},
            },
        }
    },

    computed: {},

    created() {
        this.initPage()
    },

    mounted() {},

    methods: {
        initPage() {
            this.formGetLastDayCls.query.searchCoClOrgCd =
                this.orgInfo.orgCdLvl0
            this.getLastDayCls()
                .then((res) => {
                    const lastDate = res.mthCls.lastDayCls

                    if (lastDate == null) {
                        this.initValue.clsDt = moment(new Date()).format(
                            'YYYY-MM-DD'
                        )
                        this.initValue.lastDayCls = ''
                    } else {
                        this.initValue.clsDt = getCalcDays(
                            { date: lastDate, dataFormat: 'YYYYMMDD' },
                            { count: 1, per: 'days' },
                            'YYYY-MM-DD'
                        )
                        this.initValue.lastDayCls = convertDate(
                            lastDate,
                            'YYYY-MM-DD'
                        )
                    }

                    this.accSearchField.refreshSearchQuery()

                    Object.assign(
                        this.formGetDayClsInfo.query,
                        this.accSearchField.getQuery()
                    )
                })
                .then(this.getDayClsInfo)
        },

        resetForm(query) {
            Object.assign(this.formGetDayClsInfo.query, query)
            this.formGetDayClsInfo.query.workClCd = ''
            this.formGetDayClsInfo.data = {
                partList: [],
                ukeyList: [],
            }
        },

        viewForm(query) {
            Object.assign(this.formGetDayClsInfo.query, query)
            return this.getDayClsInfo()
        },

        async closedCancelForm() {
            this.formPostSaveDayCls.query = { ...this.formGetDayClsInfo.query }

            if (!this.formGetDayClsInfo.data.partList.length) {
                return this.showTcComAlert(
                    `데이터를 조회 하신 후 요청하시기 바랍니다`
                )
            }

            //  PS&M대리점 최종 마감에 대해서만 취소가능
            //  일반대리점 M-3개월까지 취소가능.
            if (this.orgInfo.orgCdLvl0 == 'O00000') {
                if (
                    this.formPostSaveDayCls.query.lastDayCls &&
                    !isSameDate(
                        this.formPostSaveDayCls.query.lastDayCls,
                        this.formPostSaveDayCls.query.clsDt
                    )
                ) {
                    // query.lastDayCls + 1 != query.clsDt
                    return this.showTcComAlert(
                        `최종 마감에 대해서만 취소 가능 합니다.`
                    )
                }
            } else {
                //  3개월 이전인지 체크. 일반대리점만 가능
                if (
                    this.formPostSaveDayCls.query.clsDt.substr(0, 6) <
                    this.formGetDayClsInfo.data.mthCls.lastClsYmBf3
                ) {
                    return this.showTcComAlert(
                        '마감취소는 현재월 -3개월 까지만 가능합니다.'
                    )
                }
            }

            const confirm = await this.showTcComConfirm(
                '업무일마감을 취소 하시겠습니까?'
            )

            if (!confirm) {
                return this.showTcComAlert(`업무일마감이 취소되었습니다`)
            }

            this.formPostSaveDayCls.query.clsYn = 'N'

            this.postSaveDayCls()
                .then(this.getLastDayCls)
                .then((res) => {
                    this.accSearchField.setQuery({
                        lastDayCls: convertDate(
                            res.mthCls.lastDayCls,
                            'YYYY-MM-DD'
                        ),
                    })

                    Object.assign(
                        this.formGetDayClsInfo.query,
                        this.accSearchField.getQuery()
                    )
                })
                .then(this.getDayClsInfo)
        },

        async closedForm() {
            this.formPostSaveDayCls.query = { ...this.formGetDayClsInfo.query }

            if (!this.formGetDayClsInfo.data.partList.length) {
                return this.showTcComAlert(
                    `데이터를 조회 하신 후 요청하시기 바랍니다`
                )
            }

            if (this.orgInfo.orgCdLvl0 == 'O00000') {
                if (
                    distanceDate(
                        this.formPostSaveDayCls.query.clsDt,
                        this.formPostSaveDayCls.query.lastDayCls
                    ) < 1
                ) {
                    // query.clsDt <= query.lastDayCls
                    return this.showTcComAlert(
                        `입력하신 마감일은 이미 마감되었습니다.\n마감일은 최종마감일 이후여야 합니다`
                    )
                }

                //  최종마감일 + 1
                const lastNextDay = getCalcDays(
                    {
                        date: this.formPostSaveDayCls.query.lastDayCls,
                        format: 'YYYYMMDD',
                    },
                    {
                        count: 1,
                        per: 'days',
                    },
                    'YYYY-MM-DD'
                )

                if (
                    this.formPostSaveDayCls.query.lastDayCls &&
                    !isSameDate(
                        lastNextDay,
                        this.formPostSaveDayCls.query.clsDt
                    )
                ) {
                    // query.lastDayCls + 1 != query.clsDt
                    return this.showTcComAlert(
                        `처리 가능한 마감일은 최종마감일의 익일인 [${lastNextDay}]입니다`
                    )
                }
            }

            if (!(await this.showTcComConfirm('마감 하시겠습니까?'))) {
                return this.showTcComAlert(`마감이 취소되었습니다`)
            }

            this.formPostSaveDayCls.query.clsYn = 'Y'

            this.postSaveDayCls()
                .then(this.getLastDayCls)
                .then((res) => {
                    this.accSearchField.setQuery({
                        lastDayCls: convertDate(
                            res.mthCls.lastDayCls,
                            'YYYY-MM-DD'
                        ),
                    })

                    Object.assign(
                        this.formGetDayClsInfo.query,
                        this.accSearchField.getQuery()
                    )

                    //  일반대리점일 경우 메시지
                    if (res && this.orgInfo.orgCdLvl0 != 'O00000') {
                        this.showTcComAlert(
                            '월마감이 취소되었을 경우 월마감처리 반드시 해야 합니다.'
                        )
                    }
                })
                .then(this.getDayClsInfo)
        },

        getDayClsInfo() {
            return dclApi
                .getDayClsInfo(this.formGetDayClsInfo.query)
                .then((res) => {
                    this.formGetDayClsInfo.data = res
                    Object.assign(this.formGetDayClsInfo.query, res.dayCls)

                    if (res.dayCls && res.dayCls.clsYn == 'Y') {
                        this.statusHiddenBtn.closed = true
                        this.statusHiddenBtn.closedCancel = false
                    } else {
                        this.statusHiddenBtn.closed = false
                        this.statusHiddenBtn.closedCancel = true
                    }
                })
                .catch(errorHandle)
        },

        getLastDayCls() {
            return dclApi
                .getLastDayCls(this.formGetLastDayCls.query)
                .then((res) => {
                    this.formGetLastDayCls.data = res
                    return res
                })
                .catch(errorHandle)
        },

        postSaveDayCls() {
            return dclApi
                .postSaveDayCls(this.formPostSaveDayCls.query)
                .then((res) => {
                    this.formPostSaveDayCls.data = res
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                    return res
                })
            // .catch(errorHandle)
        },
        // 마감구분comboBox filter. 판매마감/재고마감
        filterFunc(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] === 'SLS' || item['commCdVal'] === 'STK'
            )
        },
    },
}
</script>
