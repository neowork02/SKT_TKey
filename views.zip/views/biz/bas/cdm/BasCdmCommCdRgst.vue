<template>
    <div class="content">
        <!-- Tit -->
        <h1>공통코드관리<!--{{ this.gridSelect }}--></h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                    >조회
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div3">
                    <TCComInputSearch
                        labelName="코드구분ID"
                        @appendIconClick="onCommCdSrchIconClick"
                        :objAuth="objAuth"
                        v-model="forms.commCdId"
                    >
                    </TCComInputSearch>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div3">
                    <TCComInput
                        labelName="코드구분명"
                        :objAuth="objAuth"
                        v-model="forms.commCdNm"
                    >
                    </TCComInput>
                </div>
                <!-- //item 1-2 -->
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- //Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="구분코드 목록"
                :gridObj="gridObj"
                :addData="this.addData"
                :isAddRow="true"
                @addRowBtn="this.gridAddRowBtn"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :editable="true"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div>
        <!-- //gridWrap -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader2"
                ref="gridHeader2"
                gridTitle="코드 목록"
                :gridObj="gridObj2"
                :addData="this.addData2"
                :isAddRow="true"
                :isExcelup="true"
                :isExceldown="true"
                @addRowBtn="this.gridAddRowBtn2"
                @excelDownBtn="this.exportGridBtn"
            />
            <TCRealGrid
                id="grid2"
                ref="grid2"
                :editable="true"
                :fields="subView.fields"
                :columns="subView.columns"
            />
            <BasCdmCommCdSrchPopup
                v-if="showCdmCommCdSrch"
                :parentParam="searchCommCdSrchParam"
                :dialogShow.sync="showCdmCommCdSrch"
                @confirm="onCommCdSrchReturnData"
            />
        </div>
        <!-- //gridWrap -->
        <!-- Bottom BTN Group -->
        <div class="btn_area_bottom">
            <TCComButton
                :eLarge="true"
                eClass="btn_ty02_point"
                :objAuth="objAuth"
                @click="commSave"
            >
                저장
            </TCComButton>
        </div>
        <!-- // Bottom BTN Group -->
    </div>
</template>
<style></style>
<script>
//====================공통코드검색====================
import BasCdmCommCdSrchPopup from '@/components/common/BasCdmCommCdSrchPopup'
//====================//공통코드검색====================
import { NewLib } from '@/views/newlib'
import { CommonGrid } from '@/utils'
import {
    commCodeLstHeader,
    commCodeDtlHeader,
} from '@/const/grid/bas/cdm/basCdmCommCdRgstHeader'

//import { prototype2 } from '@/views/prototype/js/prototype'
import cdmApi from '@/api/biz/bas/cdm/basCdmCommCdRgst'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'Home',
    mixins: [CommonMixin],
    components: {
        BasCdmCommCdSrchPopup,
    },

    data() {
        return {
            gridSelect: '',
            gridData: this.GridSetData(),
            gridData2: this.GridSetData(),
            addData: ['', '', '', '', '3', 'New사용자등록', 'N', ''],
            addData2: [
                '',
                '',
                '',
                '',
                '',
                NewLib.cf_today(),
                '99991231',
                '',
                '3',
                'New사용자등록',
                'N',
                '',
            ],
            gridObj: {},
            gridHeaderObj: {},
            gridObj2: {},
            gridHeaderObj2: {},
            objAuth: {},
            view: commCodeLstHeader,
            subView: commCodeDtlHeader,
            forms: {
                commCdId: '',
                commCdNm: '',
            },
            //showAlert: false,
            //alertBodyText: '',
            //alertHeaderText: '',

            //====================공통검색팝업관련====================
            showCdmCommCdSrch: false, // 공통검색팝업 팝업 오픈 여부
            searchCommCdSrchParam: {
                value: '', // 공통검색팝업코드
            },
            selectGridTypeText: '', //선택한그리드
            selectDataRow: '', //선택한공통코드검색ROW
            selectFieldIndex: '', //선택한index
            selectFieldName: '', //선택한컬럼이름
            selectBdataRow: '', //과거클릭한그리드
            //====================//대리점팝업관련==================
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, true, true, false)

        this.gridObj2 = this.$refs.grid2
        this.gridHeaderObj2 = this.$refs.gridHeader2
        this.gridObj2.setGridState(false, true, true, false)

        this.gridObj2.gridView.columnByName('commCdId').visible = false
        this.gridObj.gridView.columnByName('rgstClCd').visible = false
        this.gridObj2.gridView.columnByName('rgstClCd').visible = false

        //상위공통코드 그리드 클릭이벤트
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            //선택한그리드
            this.selectDataRow = clickData.dataRow
            //빈곳클릭시작업없음
            if (undefined == this.selectDataRow) {
                return
            }
            this.selectGridTypeText = 'U'

            this.selectFieldIndex = clickData.fieldIndex
            this.selectFieldName = clickData.fieldName
            if ('supCommCdId' == clickData.fieldName) {
                this.showCdmCommCdSrch = true
            }

            let sdRow = this.selectDataRow
            let sbdRow = this.selectBdataRow
            if (undefined != sdRow) {
                sdRow = sdRow.toString()
            }
            if (undefined != sbdRow) {
                sbdRow = sbdRow.toString()
            }

            let commCdId = grid.getValue(clickData.itemIndex, 'commCdId')
            this.gridSelect = commCdId

            //첫번째클릭할때만 두번째 그리드를 가져오기위해
            if (sdRow != sbdRow) {
                //두번째그리드초기화
                this.gridData2 = this.GridSetData()
                this.gridObj2.dataProvider.clearRows()

                //첫번째 컬럼(구분코드ID)값으로 하위공통코드 가져오기

                if (commCdId) {
                    this.getCommCodeDtl(commCdId)
                }
            }

            this.selectBdataRow = clickData.dataRow

            //this.onCommCdSrchIconClick()
        }
        //상위공통코드 그리드 클릭이벤트
        this.gridObj2.gridView.onCellClicked = (grid, clickData) => {
            if ('subCommCdId' == clickData.fieldName) {
                this.selectDataRow = clickData.dataRow
                //빈곳클릭시작업없음
                if (undefined == this.selectDataRow) {
                    return
                }
                this.showCdmCommCdSrch = true
                //선택한그리드
                this.selectGridTypeText = 'D'

                this.selectFieldIndex = clickData.fieldIndex
                this.selectFieldName = clickData.fieldName
            }

            console.log(clickData)
            console.log(clickData.fieldName)
            console.log(clickData.dataRow)
            console.log(clickData.fieldIndex)
        }
        //구분코드ID변경시 두번째그리드 초기화
        //this.gridObj.gridView.onKeyDown = (grid, e) => {
        this.gridObj.gridView.onCellEdited = (
            grid,
            itemIndex,
            dataRow,
            field
        ) => {
            console.log(dataRow)
            console.log(field)
            //두번째그리드초기화
            this.gridData2 = this.GridSetData()
            this.gridObj2.dataProvider.clearRows()
            this.gridSelect = ''

            let commCdId = grid.getValue(itemIndex, 'commCdId')
            this.gridSelect = commCdId

            //첫번째 컬럼(구분코드ID)값으로 하위공통코드 가져오기

            if (commCdId) {
                this.getCommCodeDtl(commCdId)
            }
        }

        //let test = { a: '1' }
        //this.saveSearchWhere({ searchWhere: test })
        //this.$store.dispatch('searchWhere/saveSearchWhere', test)
    },
    computed: {
        test() {
            return this.$store.getters.searchWhere
        },
    },
    methods: {
        init: function () {},
        clearBtn() {
            this.forms.commCdId = ''
            this.forms.commCdNm = ''
            this.gridData = this.GridSetData()
            this.gridData2 = this.GridSetData()
            this.gridSelect = ''
            this.gridObj.dataProvider.clearRows()
            this.gridObj2.dataProvider.clearRows()
            this.selectBdataRow = ''
            this.selectGridTypeText = ''
        },
        clearGrid() {
            //그리드만 초기화
            this.gridData = this.GridSetData()
            this.gridData2 = this.GridSetData()
            this.gridSelect = ''
            this.gridObj.dataProvider.clearRows()
            this.gridObj2.dataProvider.clearRows()
            this.selectBdataRow = ''
            this.selectGridTypeText = ''
        },
        //Grid Init
        GridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(-1, 1000, '', '')
        },

        //Add Row Event
        gridAddRowBtn: function () {
            //두번째그리드 구분코드id초기화
            this.addData2[0] = ''
            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            // readOnly 컬럼 행추가시 입력가능하도록 변경처리
            let commCdId = this.gridObj.gridView.columnByName('commCdId')
            const f = function () {
                return { editable: true }
            }
            commCdId.styleCallback = f
        },
        //Add Row Event
        gridAddRowBtn2: function () {
            if ('' == this.gridSelect) {
                this.showTcComAlert('구분코드목록의 구분코드ID 선택해주세요.', {
                    header: '구분코드 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            //구분코드id생성
            this.addData2[0] = this.gridSelect
            this.gridData2.gridRows = this.gridHeaderObj2.addRow(
                this.gridData2.gridRows
            )
            // readOnly 컬럼 행추가시 입력가능하도록 변경처리
            let commCdVal = this.gridObj2.gridView.columnByName('commCdVal')
            const f = function () {
                return { editable: true }
            }
            commCdVal.styleCallback = f
            //구분코드id 생성후 초기화
            this.addData2[0] = ''
            //setValue(row, field, value)
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            this.gridHeaderObj2.exportGrid('commCode.xls')
        },

        //조회 버튼 이벤트
        searchBtn: function () {
            if (
                _.isEmpty(this.forms.commCdId) ||
                _.isEmpty(this.forms.commCdNm)
            ) {
                this.showTcComAlert('조회조건을 입력해주세요.', {
                    header: '검색필수 조건',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            this.clearGrid()
            this.getCommCodeLst()
        },

        //상위공통코드 조회완료
        getCommCodeLst() {
            cdmApi.getCommonCode(this.forms).then((resultData) => {
                //Get Row Data
                this.gridObj.setRows(resultData)
                // this.gridData = this.GridSetData() //초기화
                console.log('상위공통코드 조회완료')
            })
        },
        //하위공통코드 조회완료
        getCommCodeDtl(codeId) {
            var params = {
                commCdId: codeId,
            }
            cdmApi.getCommonCodeDetail(params).then((resultData) => {
                //Get Row Data
                this.gridObj2.setRows(resultData)
                // this.gridData = this.GridSetData() //초기화

                console.log('하위공통코드 조회완료')
            })
        },

        //공통코드 API등록
        saveCommonCodeList(formData) {
            console.log('saveCommonCodeList')
            //그리드 validation
            cdmApi.saveCommonCodeList(formData).then((res) => {
                if (res) {
                    this.showTcComAlert('저장 완료하였습니다.', {
                        header: 'Grid Data 저장',
                        size: '500',
                        confirmLabel: 'OK',
                    })

                    console.log('저장완료')

                    //초기화
                    this.gridData = this.GridSetData()
                    this.gridData2 = this.GridSetData()
                    formData.basCommCdLst = ''
                    formData.basCommCdDtl = ''
                    this.gridSelect = ''
                }
            })
        },

        //하위공통코드 API등록
        saveCommonCodeList2(formData) {
            console.log('saveCommonCodeList2', this.gridSelect)
            //그리드 validation
            cdmApi.saveCommonCodeList(formData).then((res) => {
                if (res) {
                    this.showTcComAlert('코드저장 완료하였습니다.', {
                        header: 'Grid Data 저장',
                        size: '500',
                        confirmLabel: 'OK',
                    })

                    console.log('코드저장완료')

                    //초기화
                    this.gridData2 = this.GridSetData()
                    formData.basCommCdDtl = ''
                    this.gridSelect = ''
                }
            })
        },

        //저장버튼 클릭시 이벤트
        commSave() {
            //첫번째 그리드 필수입력항목
            let requiredCol = ['commCdId', 'commCdNm', 'rgstClCd']
            //두번째 그리드 필수입력항목
            let requiredCol2 = [
                'commCdVal',
                'commCdValNm',
                'prtSeq',
                'effStaDt',
                'effEndDt',
                'rgstClCd',
            ]

            //그리드 Commit
            this.gridObj.gridView.commit()
            this.gridObj2.gridView.commit()

            // Grid Validation 체크
            // valiGrid.error 값이 없으면 정상
            // valiGrid.error 값이 있으면 에러
            // valiGrid.error = 'index' - 변경된 행이 없는경우
            // valiGrid.error = 'require' - 필수입력항목 입력누락
            let valiGrid = this.gridObj.validationGrid(
                this.gridData,
                requiredCol
            )
            let valiGrid2 = this.gridObj2.validationGrid(
                this.gridData2,
                requiredCol2
            )

            if (valiGrid.error == 'index' && valiGrid2.error == 'index') {
                this.showTcComAlert('대상이 존재하지 않습니다.', {
                    header: 'Grid Data 저장',
                    size: '500',
                    confirmLabel: 'OK',
                })
            } else {
                let formData = {}

                //상위 하위 공통코드 모두 변경사항 있는경우
                if (_.isEmpty(valiGrid.error) && _.isEmpty(valiGrid2.error)) {
                    formData.basCommCdLst = this.gridData.saveRows
                    if (this.gridSelect) {
                        formData.basCommCdDtl = this.gridData2.saveRows
                        formData.basCommCdDtl.commCdId = this.gridSelect
                    }
                    console.log('formData', formData)
                    this.saveCommonCodeList(formData)

                    // 필수입력항목 입력누락인 경우
                } else if (
                    valiGrid.error == 'require' ||
                    valiGrid2.error == 'require'
                ) {
                    this.showTcComAlert('필수입력항목을 입력해주세요.', {
                        header: '필수입력항목',
                        size: '500',
                        confirmLabel: 'OK',
                    })

                    // 상위공통코드만 변경사항 있는경우
                } else if (_.isEmpty(valiGrid.error)) {
                    formData.basCommCdLst = this.gridData.saveRows
                    this.saveCommonCodeList(formData)

                    // 하위공통코드만 변경사항 있는경우
                } else if (_.isEmpty(valiGrid2.error)) {
                    //상위공통코드가 선택된경우만 하위공통코드 입력가능
                    if (this.gridSelect) {
                        console.log('this.gridObj sec', this.gridObj)
                        formData.basCommCdDtl = this.gridData2.saveRows
                        formData.basCommCdDtl.commCdId = this.gridSelect

                        this.saveCommonCodeList2(formData)
                    } else {
                        this.showTcComAlert('대상이 존재하지 않습니다.', {
                            header: 'Grid Data 저장',
                            size: '500',
                            confirmLabel: 'OK',
                        })
                    }
                }
            }
        },

        onCommCdSrchIconClick() {
            this.selectGridTypeText = ''
            this.showCdmCommCdSrch = true
        },
        // 공통팝업검색 팝업 리턴 이벤트 처리
        onCommCdSrchReturnData(retrunData) {
            console.log('retrunData: ', retrunData)

            let commCdId = _.get(retrunData, 'commCdId')
            let commCdNm = _.get(retrunData, 'commCdNm')

            console.log(this.selectGridTypeText)
            console.log(this.selectDataRow)
            console.log(this.selectfieldIndex)

            let gridType = this.selectGridTypeText

            //검색부분팝업
            if ('' == gridType) {
                this.clearBtn()
                this.forms.commCdId = commCdId
                this.forms.commCdNm = commCdNm
            }

            //첫번째그리드팝업
            if ('U' == gridType) {
                this.gridObj.gridView.setValue(
                    this.selectDataRow,
                    this.selectFieldName,
                    commCdId
                )
            }

            //두번째그리드팝업
            if ('D' == gridType) {
                this.gridObj2.gridView.setValue(
                    this.selectDataRow,
                    this.selectFieldName,
                    commCdId
                )
            }

            this.selectGridTypeText = ''
        },
    },
}
</script>
