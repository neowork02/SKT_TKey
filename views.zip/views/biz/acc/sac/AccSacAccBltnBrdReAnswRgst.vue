<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="700px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle"></p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="inputData.inqTitle"
                                    labelName="제목"
                                    :eRequired="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="inputData.inqCtt"
                                    labelName="내용"
                                    class="boxtype"
                                    :eRequired="true"
                                    :rows="8"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComComboBox
                                    codeId="ZACC_C_00200"
                                    labelName="처리상태"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    v-model="inputData.accProcStCd"
                                ></TCComComboBox>
                            </div>
                        </div>
                    </div>

                    <!-- 파일첨부 그리드 -->
                    <AttachedFileAdd
                        ref="attachedFileAdd"
                        :fileList="fileSearchList"
                        @file-change="onFileAddChange"
                        gridHeight="80px"
                        gridHeaderId="gridHearderReAnsw"
                        gridId="gridReAnsw"
                    ></AttachedFileAdd>

                    <!-- Bottom BTN Group -->
                    <!-- <div class="btn_area_bottom">
                        <div class="right">
                            <TCComButton
                                eClass="btn_ty01"
                                @click="saveReAnswRgst"
                                >저장</TCComButton
                            >
                            <TCComButton eClass="btn_ty01" @click="closeBtn"
                                >닫기</TCComButton
                            >
                        </div>
                    </div> -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom type2">
                        <div class="right">
                            <TCComButton
                                eClass="btn_ty02"
                                :eLarge="true"
                                @click="saveReAnswRgst"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :eLarge="true"
                                @click="closeBtn"
                                >닫기</TCComButton
                            >
                        </div>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<style lang="scss" scoped></style>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import _ from 'lodash'
import AttachedFileAdd from '@/components/common/AttachedFileAdd'
import boardApi from '@/api/biz/acc/sac/AccSacAccBltnBrdApi'

export default {
    name: 'AccSacAccBltnBrdReAnswRgst',
    mixins: [CommonMixin],
    components: {
        AttachedFileAdd, //  파일첨부
    },
    props: {
        //parmas
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            //  파일첨부
            admAppendFileList: [],
            formData: new FormData(),
            fileSearchList: [],

            inputData: {
                accDealcoCd: '',
                accDealcoNm: '',
                accProcStCd: '',
                accQueDtlCd: '',
                accQueTypCd: '',
                accYm: '',
                boardLvl: '',
                boardNo: '',
                docId: '',
                inqCtt: '',
                inqTitle: '',
                makeDtm: '',
                maxBoardLvl: '',
                maxBoardNo: '',
                modUserId: '',
                orgCd: '',
                orgBoardNo: '',
                supBoardNo: '',
                screenId: 'AccSacAccBltnBrd',
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        //  화면 초기 셋팅
        this.getBase()
    },
    methods: {
        //팝업닫기
        closeBtn: function () {
            this.activeOpen = false
            this.$emit('close')
        },
        //  초기값 셋팅
        getBase: function () {
            delete this.popupParams.inqTitle
            delete this.popupParams.inqCtt

            this.inputData = this.popupParams
        },

        //  저장
        saveReAnswRgst: function () {
            if (_.isEmpty(this.inputData.inqTitle)) {
                this.showTcComAlert('제목을 입력하십시오.')
                return
            } else if (!CommonUtil.chkRmks(this.inputData.inqTitle)) {
                this.showTcComAlert('제목을 확인하십시오.')
                return
            }
            if (_.isEmpty(this.inputData.inqCtt)) {
                this.showTcComAlert('내용을 입력하십시오.')
                return
            } else if (!CommonUtil.chkRmks(this.inputData.inqCtt)) {
                this.showTcComAlert('내용을 확인하십시오.')
                return
            }
            if (_.isEmpty(this.inputData.accProcStCd)) {
                this.showTcComAlert('처리상태를 입력하십시오.')
                return
            }

            this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    //  첨부파일 저장
                    boardApi
                        .saveAnswAttachFile(this.formData)
                        .then((resultData) => {
                            if (resultData != null) {
                                this.inputData.docId = resultData[0].docId
                            }

                            //  문의상세내용 저장
                            return boardApi.saveBoardAnswRgst(this.inputData)
                        })
                        .then((resultData) => {
                            if (resultData) {
                                this.showTcComAlert('저장되었습니다.')
                                this.closeBtn()
                            }
                        })
                }
            })
        },
        //  파일첨부(Add,Delete)
        onFileAddChange(files) {
            console.log('files: ', files)
            this.formData = new FormData()
            const addFileLength = files.addFile.length

            _.forEach(files.addFile, (item, index) => {
                this.formData.append('files', item.file)
                this.formData.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].screenId`,
                    'AccSacAccBltnBrd'
                )
                this.formData.append(`admAppendFileList[${index}].docId`, '')
                this.formData.append(
                    `admAppendFileList[${index}].__rowState`,
                    'created'
                )
            })
            _.forEach(files.delFile, (item, index) => {
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].filePathNm`,
                    item.filePathNm
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].fileType`,
                    item.fileType
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].screenId`,
                    item.screenId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].docId`,
                    item.docId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].__rowState`,
                    'deleted'
                )
            })
        },
        reAnswRgstPopup: function () {},
    },
}
</script>
