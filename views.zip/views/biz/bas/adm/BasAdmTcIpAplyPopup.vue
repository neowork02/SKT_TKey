<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">항목설정PopUp</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParam.sktId"
                                    labelName="Swing ID"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParam.sktIdNm"
                                    labelName="Swing 사용자명"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 :오른쪽 정렬 버튼 영역 -->
                            <div class="formitem div3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_search"
                                            labelName="조회"
                                            @click="onSearch"
                                            :objAuth="objAuth"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 1-3 :오른쪽 정렬 버튼 영역 -->
                        </div>
                        <!-- //Search_line 1 -->
                    </div>
                    <!-- //Search_div -->

                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader"
                            ref="gridHeader"
                            :gridObj="gridObj"
                            :isAddRow="true"
                            :isDelRow="true"
                            :isPageCnt="true"
                            @addRowBtn="btnAddTcIpAply"
                            @chkDelRowBtn="btnDelTcIpAply"
                        />
                        <TCRealGrid
                            id="grid"
                            ref="grid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onSave"
                            :objAuth="objAuth"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
        </template>
    </TCComDialog>
</template>

<script>
import { HEADER } from '@/const/grid/bas/adm/basAdmTcIpAplyMenuMgmtHeader'
import api from '@/api/biz/bas/adm/basAdmTcIpAplyMenuMgmt'
import CommonMixin from '@/mixins'
import _ from 'lodash'
export default {
    name: 'BasAdmTcIpAplyPopup',
    components: {},
    mixins: [CommonMixin],
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            showAlertBool: false,
            headerText: '',
            alertBodyText: '',
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: HEADER,
            // ds_user_auth 사용자 권한정보 받아오면됨 아직back-end 미완
            parentData: [],
            searchParam: { sktId: '', sktIdNm: '' },
        }
    },

    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.initGrid()
        console.log('this.parentData', this.parentData)
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.parentData = value
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            console.log('this.parentData', this.parentData)
            this.gridObj.setGridState()
            // if (!_.isEmpty(this.parentData.userNm)) {
            this.searchParam.sktIdNm = this.parentData.sktIdNm
            // }
            this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj.setRows(this.parentData)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                this.selectDataRow = clickData.dataRow
                //빈곳클릭시작업없음
                if (undefined == this.selectDataRow) {
                    return
                }

                /*
                let jsonData = []
                jsonData.push(
                    this.gridObj.dataProvider.getJsonRow(clickData.dataRow)
                )
                */

                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )

                this.$emit('confirm', jsonData)
                // this.onClose()
            }
        },

        //조회 버튼
        onSearch() {
            if (
                _.isEmpty(this.searchParam.sktId) &&
                _.isEmpty(this.searchParam.sktIdNm)
            ) {
                this.showTcComAlert('Swing Id 또는 Swing 사용자명을 입력하세요')
                return
            }

            api.getSktCodeList(this.searchParam).then((result) => {
                // let list = result.gridList

                this.gridObj.setRows(result)
                // this.gridData = this.gridSetData() //초기화
            })
        },

        // 항목 설정 저장
        onSave() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('저장할 항목을 추가해주세요.', {
                    header: '데이터',
                    size: '500',
                    confirmLabel: 'OK',
                })

                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        btnAddTcIpAply() {
            this.gridObj.gridView.commit()
            let rowData = {
                // addUserGrpCd: '',
                // staDt: this.getToday().replaceAll('-', '/'),
                // expirDt: this.lastDay,
            }
            let rowCount = this.gridObj.dataProvider.getRowCount()
            this.gridObj.dataProvider.insertRow(rowCount, rowData)
        },
        btnDelTcIpAply() {
            this.gridData = this.gridHeaderObj.focusDelRow(this.gridData)
        },
    },
}
</script>
