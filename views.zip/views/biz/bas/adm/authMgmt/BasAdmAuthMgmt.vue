<!-----------------------------------------------
 * 업무그룹명: 기준정보 > 권한관리
 * 서브업무명: 권한관리
 * 설명: 권한관리 CRUD
 * 작성자: P180291
 * 작성일: 2022.06.24
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>권한관리</h1>
        <!-- // Tit -->
        <main-content ref="mainContent" />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/authMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/adm/authMgmt'

export default {
    name: 'BasAdmAuthMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (!this.$store.hasModule('bas.adm.authMgmtStore')) {
            this.$store.registerModule('bas.adm.authMgmtStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.adm.authMgmtStore')) {
            this.$store.unregisterModule('bas.adm.authMgmtStore')
        }
    },
    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>
