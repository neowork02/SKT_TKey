<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 통합미수금 관리 수납대상집계
 * 설명: 조회, 저장
 * 작성자: P180190
 * 작성일: 2022.11.17
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">통합미수금관리-미수금상세</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="입금일자"
                                    calType="DP"
                                    :eRequired="true"
                                    v-model="popupParams.baseDt"
                                >
                                </TCComDatePicker>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="조직명"
                                    v-model="popupParams.orgNm"
                                    :editable="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="거래처명"
                                    v-model="popupParams.dealcoNm"
                                    :editable="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                        </div>
                    </div>

                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader"
                            ref="gridHeader"
                            gridTitle="수납내역"
                            :gridObj="gridObj"
                        >
                        </TCRealGridHeader>
                        <TCRealGrid
                            id="popupGrid"
                            ref="popupGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                </div>
                <!-- // Bottom BTN Group -->
                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose"
                    >닫기</a
                >
                <!--//Close BTN-->
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { GRID_HEADER } from '@/const/grid/acc/sac/AccSacIntgUnpdMgmtPayTotGrid'
import intgRcvbApi from '@/api/biz/acc/sac/AccSacIntgUnpdMgmt'
import CommonMixin from '@/mixins'
// import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'AccSacIntgUnpdMgmtPayTot',
    title: '통합미수금관리 수납내역 팝업',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            gridData: {},
            gridObj: {},
            objAuth: {},
            view: GRID_HEADER,

            popupParams: {
                dealcoCd: '',
                dealcoNm: '',
                baseDt: [],
            },

            params: {
                dealcoCd: '',
                dealcoNm: '',
                baseDt: [],
                srchStartDpstDt: '',
                srchEndDpstDt: '',
            },

            param: {
                payTotList: [],
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        'parentParam.baseDt': {
            handler: function (newArr) {
                if (!_.isEmpty(newArr[0])) {
                    this.params.srchStartDpstDt = newArr[0].replace(/-/g, '')
                }
                if (!_.isEmpty(newArr[1])) {
                    this.params.srchEndDpstDt = newArr[1].replace(/-/g, '')
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    mounted() {
        this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState(false, true, true, true)
        this.popupParams = this.parentParam
        this.onSearch()
    },
    methods: {
        onSearch() {
            // this.params.baseDt = moment(this.parentParam.baseDt).format(
            //     'YYYYMMDD'
            // )
            this.params.dealcoCd = this.popupParams.dealcoCd
            intgRcvbApi.getPayTot(this.params).then((res) => {
                if (res) {
                    this.gridObj.setRows(res.gridList)
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },

        onConfirm() {
            var rowData = {}
            this.param.payTotList = []
            var checkedRows = this.gridObj.gridView.getCheckedItems(true)
            if (checkedRows.length > 0) {
                for (var i = 0; i < checkedRows.length; i++) {
                    rowData = this.gridObj.dataProvider.getJsonRow(
                        checkedRows[i]
                    )
                    this.param.payTotList.push(rowData)
                    console.log('this.param', this.param)
                }
                intgRcvbApi.savePayTot(this.param).then((res) => {
                    if (res) {
                        this.showTcComAlert('정상적으로 저장 되었습니다.')
                    } else {
                        this.showTcComAlert('저장에 실패하였습니다.')
                    }
                })
                this.$emit('confirm', this.param)
                this.onClose()
            } else {
                this.showTcComAlert('선택한 데이터가 없습니다.')
            }
        },

        onClose() {
            this.activeOpen = false
        },
    },
}
</script>
