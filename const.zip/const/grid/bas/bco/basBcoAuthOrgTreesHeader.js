// eslint-disable-next-line no-unused-vars
import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [],
    columns: [],
}
