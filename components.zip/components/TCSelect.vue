<script>
export default {
    name: 'Select',

    props: {
        value: { type: String, default: '', required: false },
        readonly: { type: Boolean, default: false, required: false },
        size: { type: Number, default: 30, required: false },
        placeholder: { type: String, default: '선택해주세요', required: false },
        index: { type: Number, default: 0, required: false },
        option: {
            type: Array,
            required: true,
        },
    },

    data() {
        return {
            dpMountYn: 'N',
            unformattedDate: this.value,
            select1: this.value,
        }
    },
    watch: {
        readonly() {
            if (!this.readonly) {
                this.test()
            } else {
                //
            }
        },
    },
    mounted() {
        // console.log(this.option)
        if (!this.readonly) {
            this.test()
        } else {
            //
        }
    },
    methods: {
        test() {
            if (this.dpMountYn === 'Y') {
                return
            }
            this.dpMountYn = 'Y'
        },
        //SELECT Change Event
        updateValue: function (value) {
            value
        },
        //SELECT Change Event
        changeValue: function () {
            this.$emit('input', this.select1)
        },
    },
}
</script>

<template>
    <div class="">
        <select
            v-model="select1"
            @change="changeValue"
            :index="index"
            v-on:input="updateValue($event.target.value)"
        >
            <option value="">---- {{ this.placeholder }} ----</option>
            <option
                v-for="item in option"
                :value="item.value"
                v-bind:key="item.id"
            >
                {{ item.name }}
            </option>
        </select>
    </div>
</template>

<style>
.ui-Inputs .ui-state-default {
    border: 1px solid #ffffff !important;
    background: #ffffff !important;
    font-weight: normal;
    color: #454545;
    text-align: center !important;
}
</style>
