<template>
    <div v-if="this.isGridEtcAddInfo1">
        <!--    <div>-->
        <!-- SubTit  -->
        <div class="stitHead">
            <h4 class="subTit">추가정보</h4>
        </div>
        <!-- //SubTit -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 3 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="etcAddInfo.orgNm"
                        :codeVal.sync="etcAddInfo.orgCd"
                        labelName="소속조직"
                        :eRequired="true"
                        placeholder="선택해주세요"
                        :disabledAfter="true"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :disabled="initParams.pIsNew"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="popupParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- item 2-4 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="etcAddInfo.sktAgencyNm"
                        :codeVal.sync="etcAddInfo.sktAgencyCd"
                        labelName="Swing대리점"
                        :eRequired="true"
                        :disabledAfter="true"
                        @enterKey="onAgencyEnterKey"
                        @appendIconClick="onAgencyIconClick"
                        @input="onAgencyInput"
                        :disabled="reqParam.ifYn === 'Y' ? true : false"
                    />
                    <BasBcoOrgAgencysPopup
                        v-if="showBcoOrgAgencys"
                        :parentParam="searchOrgAgencyParam"
                        :rows="resultOrgAgencyRows"
                        :dialogShow.sync="showBcoOrgAgencys"
                        @confirm="onOrgAgencyReturnData"
                    />
                </div>
                <!-- //item 2-4 -->
                <!-- item 3-1 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="etcAddInfo.sktChnlCd"
                        labelName="SwingP코드"
                        :eRequired="isRequiredSktChnlCd"
                        :disabled="reqParam.ifYn === 'Y' ? true : false"
                    />
                </div>
                <!-- //item 3-1 -->
                <!-- item 3-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="etcAddInfo.sktSubNm"
                        :codeVal.sync="etcAddInfo.sktSubCd"
                        labelName="Swing서브점"
                        :eRequired="isRequiredSktSubCd"
                        :disabledAfter="true"
                        @appendIconClick="onSwingDealIfIconClick"
                        @input="onSwingDealIfInput"
                        :disabled="reqParam.ifYn === 'Y' ? true : false"
                    />
                    <BasBcoTbasDealIfPopup
                        v-if="basBcoSwingDealIfShow"
                        :parentParam="popupParam4"
                        :rows="resultSwingDealIfRows"
                        :dialogShow.sync="basBcoSwingDealIfShow"
                        @confirm="onSwingDealIfReturnData"
                    />
                </div>
                <!-- //item 3-3 -->
            </div>
            <!-- //Search_line 3 -->
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="etcAddInfo.dealcoClCd2"
                        labelName="거래처유형"
                        :eRequired="!isDisabledDataDealcoCl2_1_1"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :itemList="dealcoCl2List"
                        :disabled="isDisabledDataDealcoCl2_1_1"
                        @change="changeDealcoCl2"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="etcAddInfo.dealcoClCd3"
                        labelName="거래처분류"
                        :eRequired="!isDataDealcoCl3"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :itemList="dealcoCl3List"
                        :disabled="isDataDealcoCl3"
                        @input="setData"
                    ></TCComComboBox>
                    <!--                  @change="changeDealcoCl3"-->
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <!--
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="etcAddInfo.saleGrpClCd"
                        labelName="영업그룹"
                        :itemList="zbasC00130"
                        blankItemValue=""
                        :addBlankItem="true"
                        blankItemText="선택"
                        @input="setData"
                    ></TCComComboBox>
                </div>
                -->
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div4">
                    <div class="arrayType btnType">
                        <div class="colinput">
                            <TCComInput
                                v-model="etcAddInfo.saleChrgr"
                                labelName="영업담당자"
                                :disabled="initParams.pIsNew ? true : false"
                            />
                        </div>
                        <div class="colbtn">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="저장"
                                @click="saveSaleChrgr"
                            />
                        </div>
                    </div>
                </div>
                <!-- //item 1-4 -->
                <div class="formitem div4"></div>
            </div>
            <!-- //Search_line 1 -->

            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <!-- arrayType_chkboxType -->
                    <div class="arrayType chkboxType">
                        <div class="colinput">
                            <TCComInputSearchText
                                v-model="etcAddInfo.accDealcoCdNm"
                                :codeVal.sync="etcAddInfo.accDealcoCd"
                                labelName="정산처"
                                :disabledAfter="true"
                                :disabled="isDisabledDataStlPlc1"
                                @enterKey="onAccDealcoEnterKey"
                                @appendIconClick="onAccDealcoIconClick"
                                @input="onAccDealcoInput"
                            />
                            <BasBcoDealcosPop
                                v-if="showBasBcoAccDealcos"
                                :parentParam="accSearchForm"
                                :rows="resultDealcoRows"
                                :dialogShow.sync="showBasBcoAccDealcos"
                                @confirm="onAccDealcoReturnData"
                            />
                        </div>
                        <div class="colchk">
                            <TCComCheckBox
                                labelName=""
                                v-model="etcAddInfo.accDealcoChk"
                                :disabled="isDisabledDataStlPlcChk1"
                                :itemList="stlPlcItem"
                                @change="stlPlcCheck"
                                @input="setData"
                            />
                        </div>
                    </div>
                    <!-- //arrayType_chkboxType -->
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div4">
                    <!-- arrayType_chkboxType -->
                    <div class="arrayType chkboxType">
                        <div class="colinput">
                            <TCComInputSearchText
                                v-model="etcAddInfo.hldDealcoCdNm"
                                :codeVal.sync="etcAddInfo.hldDealcoCd"
                                labelName="재고보유처"
                                :disabledAfter="true"
                                :disabled="isDisabledDataDisHldPlc1"
                                @enterKey="onHldDealcoEnterKey"
                                @appendIconClick="onHldDealcoIconClick"
                                @input="onHldDealcoInput"
                            />
                            <BasBcoDealcosPop
                                v-if="showBasBcoHldDealcos"
                                :parentParam="hldSearchForm"
                                :rows="hldDealcoResultDealcoRows"
                                :dialogShow.sync="showBasBcoHldDealcos"
                                @confirm="onHldDealcoReturnData"
                            />
                        </div>

                        <div class="colchk">
                            <TCComCheckBox
                                labelName=""
                                v-model="etcAddInfo.hldDealcoChk"
                                :disabled="isDisabledDataDisHldPlcChk1"
                                :itemList="disHldPlcItem"
                                @change="hldPlcCheck"
                                @input="setData"
                            />
                        </div>
                    </div>
                    <!-- //arrayType_chkboxType -->
                </div>
                <!-- //item 2-3 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="etcAddInfo.qckSvcCoNm"
                        labelName="퀵서비스명"
                        @input="setData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="etcAddInfo.qckSvcTelNo"
                        labelName="퀵서비스번호"
                        @input="setData"
                    />
                </div>
            </div>
            <!-- //Search_line 2 -->
        </div>
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/tDealcoMgmt/helpers'
import _ from 'lodash'
import moment from 'moment'

//====================내부거래처-전체조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-전체조직==================
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================조직별대리점팝업====================
import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
//====================//조직별대리점팝업====================
//====================서브점팝업====================
import BasBcoTbasDealIfPopup from '@/components/common/BasBcoTbasDealIfPopup'
import basBcoTbasDealIfPopApi from '@/api/biz/bas/bco/basBcoTbasDealIfPop'

import { GRID_ETC_ADD_INFO_DEALCO_DTL_CARD } from '@/const/grid/bas/prm/basPrmtDealcoMgmtHeader'
//====================//서브점팝업==================
import CommonMixin from '@/mixins'
import { CommonGrid, CommonUtil } from '@/utils'
import API from '@/api/biz/bas/prm/basPrmSaleChrgrMgmt'

export default {
    name: 'EtcAddInfoContainer',
    components: {
        BasBcoDealcosPop,
        BasBcoAuthOrgTreesPopup,
        BasBcoOrgAgencysPopup,
        BasBcoTbasDealIfPopup,
    },
    mixins: [CommonMixin],
    props: {},

    mounted() {
        this.init()
        this.initData()
    },

    data() {
        return {
            view: GRID_ETC_ADD_INFO_DEALCO_DTL_CARD,
            gridStyle: {
                height: '130px', //그리드 높이 조절
            },
            isRequiredSktChnlCd: false, // SwingP코드
            isRequiredSktSubCd: false, // Swing서브코드

            gridObj: {},
            objCnt: 0,
            gridData: this.GridSetData(),
            isDtlAdd: false,
            objAuth: {},
            cardInfo: {
                dealcoCd: '',
                cardEqpSerNo: '',
                effStaDt: '',
                effEndDt: '',
                useYn: '',
                gubun: '',
            },
            cardList: [],
            cardParam: {},
            cardLayout: [
                'cardEqpSerNo',
                'useYn',
                'effStaDt',
                'effEndDt',
                'modDtm',
                'modUserNm',
            ],
            etcAddInfo: {
                orgNm: '',
                orgCd: '', // newOrgCd
                bizChrgOrgCd: '', // orgCd2
                teamOrgCd: '', // orgCd3
                sktAgencyNm: '',
                sktAgencyCd: '',
                sktChnlCd: '',
                sktSubNm: '',
                sktSubCd: '',
                dealcoClCd2: '',
                dealcoClCd3: '',
                saleGrpClCd: '',
                saleChrgr: '',
                accDealcoCdNm: '',
                accDealcoCd: '',
                accDealcoChk: [],
                hldDealcoCdNm: '',
                hldDealcoCd: '',
                hldDealcoChk: [],
                qckSvcCoNm: '',
                qckSvcTelNo: '',
                sknDelvYn: [],
            },
            storeKey: 'etcAddInfoData',
            stlPlcItem: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '',
                },
            ],
            disHldPlcItem: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '',
                },
            ],
            isDataDealcoCl2: true,
            isDataDealcoCl3: true,
            dealcoCl2CodeId: '',
            dealcoCl2List: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처유형
            dealcoCl3List: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처분류

            //====================내부거래처-전체조직====================
            showBasBcoAccDealcos: false,
            accSearchForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
            },
            resultDealcoRows: [],
            //====================//내부거래처-전체조직==================
            //====================내부거래처-전체조직====================
            showBasBcoHldDealcos: false,
            hldSearchForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
            },
            hldDealcoResultDealcoRows: [],
            //====================//내부거래처-전체조직==================
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            popupParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================조직별대리점팝업관련====================
            showBcoOrgAgencys: false, // 조직별대리점 팝업 오픈 여부
            searchOrgAgencyParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultOrgAgencyRows: [], // 조직별대리점 팝업 오픈 여부
            //====================//조직별대리점팝업관련==================
            //====================SWING대리점/서브점/판매점팝업관련====================
            basBcoSwingDealIfShow: false,
            popupParam4: {
                sktOrgClCd: '', // 조직구분
                orgNm: '', // 조직명
                sktOrgCd: '', //대리점코드
                sktSubCd: '', // 서브점코드
            },
            resultSwingDealIfRows: [],
            //====================//SWING대리점/서브점/판매점팝업관련==================
            clickStatus: null,
        }
    },
    computed: {
        ...serviceComputed,
        reqParam: {
            get() {
                return this.reqParams
            },
        },
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
        isDisabledDataStlPlc1: {
            get() {
                return this.isDisabledDataStlPlc
            },
        },
        isDisabledDataDisHldPlc1: {
            get() {
                return this.isDisabledDataDisHldPlc
            },
        },
        isDisabledDataStlPlcChk1: {
            get() {
                return this.isDisabledDataStlPlcChk
            },
        },
        isDisabledDataDisHldPlcChk1: {
            get() {
                return this.isDisabledDataDisHldPlcChk
            },
        },
        isDisabledDataDealcoCl2_1_1: {
            get() {
                return this.isDisabledDataDealcoCl2_1
            },
        },
        isDisabledDataDealcoCl3_1_1: {
            get() {
                return this.isDisabledDataDealcoCl3_1
            },
        },
        dealcoCl2List1: {
            get() {
                return this.dealcoCl2List_1
            },
        },
        dealcoCl3List1: {
            get() {
                return this.dealcoCl3List_1
            },
        },
        ////////////////// 공통코드 조회
        dealcoGrpCdList1: {
            get() {
                return this.DEAL_CO_GRP // 거래처그룹
            },
        },
        zbasC00240: {
            get() {
                return this.ZBAS_C_00240 // 거래처구분
            },
        },
        zbasC00510: {
            get() {
                return this.ZBAS_C_00510 // 거래처유형 (판매점구분)
            },
        },
        zbasC00570: {
            get() {
                return this.ZBAS_C_00570 // 거래처유형 (직영점구분)
            },
        },
        zbasC00530: {
            get() {
                return this.ZBAS_C_00530 // 거래처분류
            },
        },
        zbasC00590: {
            get() {
                return this.ZBAS_C_00590 // 거래처분류 (직영점2차점 거래처분류)
            },
        },
        zbasC00110: {
            get() {
                return this.ZBAS_C_00110 // 전자결재 진행여부
            },
        },
        zbasC00130: {
            get() {
                return this.ZBAS_C_00130 // 전자결재 진행여부
            },
        },
        zbasC00120: {
            get() {
                return this.ZBAS_C_00120 // 전자결재 진행여부
            },
        },
        zbasC00400: {
            get() {
                return this.ZBAS_C_00400 //
            },
        },
        zbasC00710: {
            get() {
                return this.ZBAS_C_00710 //
            },
        },
        zbasC00230: {
            get() {
                return this.ZBAS_C_00230 //
            },
        },
        spClsBizClCd: {
            get() {
                return this.SP_CLS_BIZ_CL_CD // 전자결재 진행여부
            },
        },
        ////////////////// 공통코드 조회
        basPrmDealcoDtlCardList1: {
            get() {
                return this.basPrmDealcoDtlCardList
            },
        },
        isGridEtcAddInfo1: {
            get() {
                return this.isGridEtcAddInfo
            },
        },
    },
    methods: {
        ...serviceMethods,
        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        async initData() {
            this.etcAddInfo = {
                orgNm: '',
                orgCd: '', // newOrgCd
                bizChrgOrgCd: '', // orgCd2
                teamOrgCd: '', // orgCd3
                sktAgencyNm: '',
                sktAgencyCd: '',
                sktChnlCd: '',
                sktSubNm: '',
                sktSubCd: '',
                dealcoClCd2: '',
                dealcoClCd3: '',
                saleGrpClCd: '',
                saleChrgr: '',
                accDealcoCdNm: '',
                accDealcoCd: '',
                accDealcoChk: [],
                hldDealcoCdNm: '',
                hldDealcoCd: '',
                hldDealcoChk: [],
                qckSvcCoNm: '',
                qckSvcTelNo: '',
                sknDelvYn: [],
            }
            this.isDataDealcoCl2 = true
            this.isDataDealcoCl3 = true
            if (this.initParams.pIsNew) {
                this.dealcoCl2List = this.dealcoCl2List1
                this.dealcoCl3List = this.dealcoCl3List1
            }
        },
        GridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        stlPlcCheck() {
            // 체크시 등록중인 거래처코드 저장
            console.log(
                'this.etcAddInfo.accDealcoChk ->',
                this.etcAddInfo.accDealcoChk
            )
            if (this.etcAddInfo.accDealcoChk.length > 0) {
                this.etcAddInfo.accDealcoCdNm = this.basPrmDealcoDtlVo.dealcoNm
                this.etcAddInfo.accDealcoCd = this.basPrmDealcoDtlVo.dealcoCd
            } else {
                this.etcAddInfo.accDealcoCdNm = ''
                this.etcAddInfo.accDealcoCd = ''
            }
            this.setData()
        },
        hldPlcCheck() {
            // 체크시 등록중인 거래처코드 저장
            console.log(
                'this.etcAddInfo.hldDealcoChk ->',
                this.etcAddInfo.hldDealcoChk
            )
            if (this.etcAddInfo.hldDealcoChk.length > 0) {
                this.etcAddInfo.hldDealcoCdNm = this.basPrmDealcoDtlVo.dealcoNm
                this.etcAddInfo.hldDealcoCd = this.basPrmDealcoDtlVo.dealcoCd
            } else {
                this.etcAddInfo.hldDealcoCdNm = ''
                this.etcAddInfo.hldDealcoCd = ''
            }
            this.setData()
        },
        errorCellFocus(chkCell, message) {
            this.showTcComAlert(message)
            this.gridObj.validationChkGrid(chkCell)
        },
        validationCheck() {
            let index = this.$refs.gridCardInfo.modifyGrid() //변경한 행 index 가져오기
            this.$refs.gridCardInfo.gridView.commit()
            const chk = { index: -1, fieldName: '' }

            for (let i = 0; i < index.length; i++) {
                let row = this.$refs.gridCardInfo.dataProvider.getJsonRow(
                    index[i],
                    true
                )

                // 유효성체크
                if (_.isEmpty(row.cardEqpSerNo)) {
                    chk.index = index[i]
                    chk.fieldName = 'cardEqpSerNo'

                    this.errorCellFocus(chk, '카드번호를 입력하세요.')
                    return false
                }

                //코드 중복 체크
                if (row.__rowState == 'created') {
                    let all1 = this.$refs.gridCardInfo.dataProvider.getJsonRows(
                        0,
                        -1
                    )
                    let dup1 = all1.filter(
                        (e) => e.cardEqpSerNo === row.cardEqpSerNo //'카드번호', //은행코드
                    )
                    if (_.isEmpty(row.cardEqpSerNo)) return true
                    //은행코드 체크
                    if (dup1.length > 1) {
                        chk.index = index[i]
                        chk.fieldName = 'cardEqpSerNo'

                        this.errorCellFocus(chk, '중복된 카드번호 입니다')
                        return false
                    }
                }
            }

            return true
        },
        gubunSetting() {
            /**
             *
             * UC : 단말기 번호 수정
             * UD : 미사용건 사용으로 수정
             * D  : 사용건 미사용으로 수정
             * N  : 신규 추가
             * M  : 유효일시변경시 유효일시만 수정
             * @description    : 데이터 변경에 따른 구분값 변경
             */
            if (
                !_.isEmpty(this.cardInfo.effStaDt) ||
                !_.isEmpty(this.cardInfo.effEndDt)
            ) {
                if (!_.isEmpty(this.cardInfo.modDtm)) {
                    if (
                        !_.isEqual(this.cardInfo.gubun, 'N') &&
                        !_.isEqual(this.cardInfo.gubun, 'UC') &&
                        !_.isEqual(this.cardInfo.gubun, 'D')
                    ) {
                        this.cardInfo.gubun = 'M'
                    }
                }
            }

            if (!_.isEmpty(this.cardInfo.useYn)) {
                if (_.isEqual(this.cardInfo.useYn, 'Y')) {
                    this.cardInfo.effStaDt = String(CommonUtil.getToday())
                    this.cardInfo.effEndDt = '99991231'

                    if (
                        !_.isEqual(this.cardInfo.gubun, 'N') &&
                        !_.isEqual(this.cardInfo.gubun, 'UC')
                    ) {
                        this.cardInfo.gubun = 'UD'
                    }
                } else {
                    this.cardInfo.effStaDt = String(CommonUtil.getToday())
                    this.cardInfo.effEndDt = String(CommonUtil.getToday() - 1)
                    if (
                        !_.isEqual(this.cardInfo.gubun, 'N') &&
                        !_.isEqual(this.cardInfo.gubun, 'UC')
                    ) {
                        this.cardInfo.gubun = 'D'
                    }
                }
            }
            /*
      if (!_.isEmpty(this.cardInfo.cardEqpNo)) {
          let newGubun
          if (!_.isEqual(this.cardInfo.gubun, newGubun)) {
              if (!_.isEqual(this.cardInfo.gubun, 'N')) {
                  this.cardInfo.gubun = 'UC'
              }
          }
      }

       */
        },
        async saveSaleChrgr() {
            if (_.isEmpty(this.basPrmDealcoDtlChrgrVo.userId)) {
                this.showTcComAlert('변경된 영업담당자가 없습니다.')
                return false
            }
            let saveParam = []
            let obj = {}
            obj.userId = this.basPrmDealcoDtlChrgrVo.userId
            obj.aplyStaDt = moment(new Date()).format('YYYYMMDD') //조회년월
            obj.aplyEndDt = '99991231'
            obj.dealcoCd = this.basPrmDealcoDtlChrgrVo.dealcoCd
            obj.__rowState = this.basPrmDealcoDtlChrgrVo.__rowState
            saveParam.push(obj)
            await API.saveSaleChrgr(saveParam).then((result) => {
                console.log('result : ', result)
                if (result != null) {
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                }
                // else {
                //     this.showTcComAlert('다시 시도하여 주십시오')
                // }
            })
        },
        async gridSaveBtn() {
            this.isAcntNo = true
            if (_.isEmpty(this.basPrmDealcoDtlVo.dealcoCd)) {
                this.showTcComAlert('상세에서만 가능합니다.')
                return false
            }
            if (!this.validationCheck()) {
                return false
            }
            let index = this.$refs.gridCardInfo.modifyGrid() //변경한 행 index 가져오기
            if (index.length === 0) {
                this.showTcComAlert('변경된 데이터가 없습니다')
                return false
            }
            await this.showTcComConfirm('입력저장 하시겠습니까?').then(
                (confirm) => {
                    if (!confirm) return false
                    this.gridData = this.$refs.gridCardInfo.setModifyData(
                        this.gridData
                    )

                    this.cardInfoList = []
                    _.forEach(this.gridData.saveRows, (item) => {
                        if (_.isEmpty(item)) {
                            return true
                        }
                        this.cardInfo = {}
                        this.cardInfo.dealcoCd = this.basPrmDealcoDtlVo.dealcoCd // 거래처코드
                        this.cardInfo.cardEqpSerNo = item.cardEqpSerNo // 계좌구분

                        let effStaDt = _.isEmpty(item.effStaDt)
                            ? String(CommonUtil.getToday())
                            : item.effStaDt
                        let effEndDt = _.isEmpty(item.effEndDt)
                            ? '99991231'
                            : item.effEndDt

                        this.cardInfo.effStaDt = effStaDt // 유효시작일
                        this.cardInfo.effEndDt = effEndDt // 유효종료일
                        this.cardInfo.useYn = item.useYn // 사용여부
                        this.cardInfo.gubun = item.gubun // 구분
                        // 구분셋팅
                        this.gubunSetting()
                        this.cardInfo.__rowState = item.__rowState
                        this.cardInfoList.push(this.cardInfo)
                    })
                    this.gridData.saveRows = []

                    this.etcAddInfo['basPrmDealcoDtlNewCardDto'] =
                        this.cardInfoList
                    this.setData()

                    /*
                                      this.defaultAssign_({
                                          key: 'cardParams',
                                          value: this.cardParam,
                                      })
                                      let data1
                                      this.cardInfoInsert_()
                                          .then((data) => {
                                              data1 = data
                                          })
                                          .catch((error) => {
                                              Promise.reject(error)
                                          })
                                          .finally(() => {
                                              if (data1 === 1) {
                                                  this.showTcComAlert('등록성공')
                                                  this.cardParam = {}
                                                  this.cardInfoList = []
                                                  this.defaultAssign_({
                                                      key: 'cardParams',
                                                      value: [],
                                                  })
                                              } else if (data1 === 2) {
                                                  this.showTcComAlert('카드번호가 중복 됩니다.')
                                              } else {
                                                  this.showTcComAlert('등록실패')
                                              }
                                          })

                                     */
                }
            )
        },
        gridAddRowBtn: function () {
            if (_.isEmpty(this.basPrmDealcoDtlVo.dealcoCd)) {
                this.showTcComAlert('상세에서만 가능합니다.')
                return false
            }

            let rowCnt = this.$refs.gridCardInfo.dataProvider.getRowCount()
            if (rowCnt > 1) {
                this.showTcComAlert('최대 2개까지만 등록 가능합니다.')
                return
            } else {
                if (!this.validationCheck()) {
                    return false
                }
                this.$refs.gridCardInfo.dataProvider.addRow([])
                this.$refs.gridCardInfo.gridView.setValue(
                    rowCnt,
                    'effStaDt',
                    moment(new Date()).format('YYYY-MM-DD')
                )
                this.$refs.gridCardInfo.gridView.setValue(
                    rowCnt,
                    'effEndDt',
                    moment('99991231').format('YYYY-MM-DD')
                )
                this.$refs.gridCardInfo.gridView.setValue(rowCnt, 'useYn', 'Y')
                this.$refs.gridCardInfo.gridView.setValue(rowCnt, 'gubun', 'N')

                this.$refs.gridCardInfo.gridView.onEditCommit = (grid) => {
                    grid.editOptions.commitByCell = true
                }
                /*
                let focusCell = this.$refs.gridCardInfo.gridView.getCurrent()

                this.gridData.gridRows =
                    this.$refs.gridCardInfo.dataProvider.addRow(
                        this.gridData.gridRows
                    )

                let gridIndex = focusCell.dataRow + 1
                // 기본값 세팅하기
                this.$refs.gridCardInfo.gridView.setValue(
                    gridIndex,
                    'effStaDt',
                    moment(new Date()).format('YYYY-MM-DD')
                )
                this.$refs.gridCardInfo.gridView.setValue(
                    gridIndex,
                    'effEndDt',
                    moment('99991231').format('YYYY-MM-DD')
                )
                this.$refs.gridCardInfo.gridView.setValue(
                    gridIndex,
                    'useYn',
                    'Y'
                )
                this.$refs.gridCardInfo.gridView.setValue(
                    gridIndex,
                    'gubun',
                    'N'
                )
                this.$refs.gridCardInfo.gridView.setValue(
                    gridIndex,
                    '__rowState',
                    'created'
                )

                console.log('focusCell.dataRow -> ', gridIndex)

                focusCell.dataRow =
                    this.$refs.gridCardInfo.dataProvider.getRows(0, -1).length -
                    1
                this.$refs.gridCardInfo.gridView.setCurrent(focusCell)
                this.$refs.gridCardInfo.gridView.commit()

                 */
            }
        },

        gridChkDelRowBtn: function () {
            if (_.isEmpty(this.basPrmDealcoDtlVo.dealcoCd)) {
                this.showTcComAlert('상세에서만 가능합니다.')
                return false
            }
            this.$refs.gridCardInfo.gridView.commit()

            let newRows = []
            let checkRows =
                this.$refs.gridCardInfo.gridView.getCheckedRows(true)
            let rows = this.$refs.gridCardInfo.dataProvider.getJsonRows()

            if (checkRows.length === 0) {
                this.showTcComAlert('삭제할 대상을 선택해 주세요.')
                return false
            }
            this.showTcComConfirm('삭제 하시겠습니까?').then((confirm) => {
                if (!confirm) return false

                checkRows.forEach((n) => {
                    rows.forEach((v, i) => {
                        if (n === i) {
                            v.__rowState = 'deleted'
                            if (!_.isEmpty(v.cardEqpSerNo)) {
                                newRows.push(v)
                            }
                        }
                    })
                })

                this.storeSet('basPrmDealcoDtlCardListDel', newRows) // 삭제된 항목
                this.$refs.gridCardInfo.dataProvider.beginUpdate()
                this.$refs.gridCardInfo.dataProvider.removeRows(checkRows)
                this.$refs.gridCardInfo.dataProvider.endUpdate()
                this.objCnt -= checkRows.length
            })

            if (this.objCnt < 0) {
                this.initData()
            }
        },
        setData() {
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },
        init() {
            this.gridObj = this.$refs.gridCardInfo
            if (this.gridObj !== undefined) {
                this.gridObj.gridView.setColumnLayout(this.cardLayout)

                this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
                //this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
                this.gridObj.setGridState(true, true, true, false)

                this.gridObj.gridView.columnByName('useYn').values =
                    CommonUtil.convListToGridLovValues(
                        this.COM_YN,
                        'commCdVal',
                        'SELECT'
                    )
                this.gridObj.gridView.columnByName('useYn').labels =
                    CommonUtil.convListToGridLovLabels(
                        this.COM_YN,
                        'commCdValNm',
                        'SELECT'
                    )

                if (!_.isEmpty(this.basPrmDealcoDtlCardList1)) {
                    if (!this.isDtlAdd) {
                        if (!_.isEmpty(this.basPrmDealcoDtlCardList1)) {
                            this.gridObj.setRows(this.basPrmDealcoDtlCardList1)
                        }
                        this.isDtlAdd = true
                    }
                }
            }
        },

        async isDisabled(key, isDisabled) {
            await this.defaultAssign_({
                key: key,
                value: isDisabled,
            })
        },
        setDealcoCl2(dealcoCl) {
            // 거래처유형 코드 구하기
            this.getDealcoCl2CodeId(dealcoCl)
            this.getDealcoCl2List() // 거래처 유형 조회

            // 거래처분류 조회
            this.getDealcoCl3List() // 거래처 분류 조회
        },
        // 거래처 유형 코드조회
        getDealcoCl2CodeId(dealcoCl) {
            let dealcoGrpCd = ''
            let addInfoYn = ''
            _.forEach(this.dealcoClList_1, (data) => {
                if (_.isEqual(dealcoCl, data.commCdVal)) {
                    dealcoGrpCd = data.addInfo1
                    addInfoYn = data.addInfo4
                }
            })
            /**
             * dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */
            if (_.isEqual(dealcoGrpCd, 'AY')) {
                if (_.isEqual(addInfoYn, 'Y')) {
                    this.dealcoCl2CodeId = this.zbasC00110
                } else if (_.isEqual(addInfoYn, 'N')) {
                    this.dealcoCl2CodeId = this.zbasC00570
                }

                this.isDataDealcoCl2 = false
                this.isDataDealcoCl3 = false
                this.etcAddInfo.dealcoCl2 = ''
            } else if (_.isEqual(dealcoGrpCd, 'YY')) {
                this.dealcoCl2CodeId = this.zbasC00110

                this.isDataDealcoCl2 = false
                this.isDataDealcoCl3 = false
                this.etcAddInfo.dealcoCl2 = ''
            } else if (_.isEqual(dealcoGrpCd, 'ZZ')) {
                this.dealcoCl2CodeId = this.zbasC00110

                this.isDataDealcoCl2 = false
                this.isDataDealcoCl3 = false
                this.etcAddInfo.dealcoCl2 = ''
            }

            this.isDisabled('isDisabledDataDealcoCl2_1', this.isDataDealcoCl2)
            this.isDisabled('isDisabledDataDealcoCl3_1', this.isDataDealcoCl3)
            this.etcAddInfo.dealcoGrpCd = dealcoGrpCd
            this.etcAddInfo.addInfoYn = addInfoYn
        },
        // 거래처유형 조회
        getDealcoCl2List() {
            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]

            _.forEach(this.dealcoCl2CodeId, (data) => {
                if (_.isEqual(this.etcAddInfo.dealcoGrpCd, 'AY')) {
                    if (
                        _.isEqual(
                            data.addInfo1,
                            'Y' || _.isEmpty(data.addInfo1)
                        ) &&
                        _.isEqual(data.commCdId, 'ZBAS_C_00110')
                    ) {
                        defaultData.push(data)
                    } else if (_.isEqual(data.commCdId, 'ZBAS_C_00570')) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfo.dealcoGrpCd, 'YY')) {
                    if (
                        _.isEqual(
                            data.addInfo2,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfo.dealcoGrpCd, 'ZZ')) {
                    if (
                        _.isEqual(
                            data.addInfo3,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                }
            })
            this.dealcoCl2List = defaultData
        },
        // 거래처분류 조회
        getDealcoCl3List() {
            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]
            /**
             * strdInfo.dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */
            _.forEach(this.zbasC00530, (data) => {
                if (_.isEqual(this.etcAddInfo.dealcoGrpCd, 'AY')) {
                    if (
                        _.isEqual(
                            data.addInfo1,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfo.dealcoGrpCd, 'YY')) {
                    if (
                        _.isEqual(
                            data.addInfo2,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.etcAddInfo.dealcoGrpCd, 'ZZ')) {
                    if (
                        _.isEqual(
                            data.addInfo3,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                }
            })

            if (defaultData.length > 1 && _.isEmpty(defaultData[1].commCdVal)) {
                this.isDataDealcoCl3 = true
                this.isDisabled('isDisabledDataBankCdYn', true) // 출금계좌 off
            }
            this.dealcoCl3List = defaultData
        },

        changeDealcoCl2(code) {
            this.init()
            this.isDisabledData(code)
        },
        isDisabledData(code) {
            const dealCoGrp = this.strdInfoData.dealcoGrpCd
            const dealCoCl1 = this.strdInfoData.dealcoClCd1
            let isDataEarvYn = true // 전자결재전송
            let isDataDealcoCl3_1 = true // 거래처 분류 해제
            let isDataBankCdYn = true // 출금계좌
            let isDataStlPlc = true // 정산처
            let isDataDisHldPlc = true // 재고보유처
            let isDataStlPlcChk = true // 정산처 chk
            let isDataDisHldPlcChk = true // 재고보유처 chk
            if (
                this.dealcoCl3List1.length > 1 &&
                !_.isEmpty(this.dealcoCl3List1[1].commCdVal)
            ) {
                // 거래처유형이 클릭시 거래처 분류 해제
                isDataDealcoCl3_1 = false
            }

            if (
                _.isEqual(dealCoGrp, 'AY') &&
                (_.isEqual(dealCoCl1, 'A6') ||
                    _.isEqual(dealCoCl1, 'A7') ||
                    _.isEqual(dealCoCl1, 'AF')) &&
                _.isEqual(code, '1')
            ) {
                isDataBankCdYn = false // 출금계좌 on
            } else if (
                _.isEqual(dealCoGrp, 'YY') &&
                (_.isEqual(dealCoCl1, 'C1') ||
                    _.isEqual(dealCoCl1, 'A3') ||
                    _.isEqual(dealCoCl1, 'B2') ||
                    _.isEqual(dealCoCl1, 'M1') ||
                    _.isEqual(dealCoCl1, 'E1') ||
                    _.isEqual(dealCoCl1, 'M2') ||
                    _.isEqual(dealCoCl1, 'AC')) &&
                _.isEqual(code, '2')
            ) {
                isDataBankCdYn = false // 출금계좌 on
            } else {
                isDataBankCdYn = true // 출금계좌 off
            }

            if (_.isEqual(dealCoGrp, 'YY')) {
                // TODO 체크해제 확인
                if (_.isEqual(code, '3')) {
                    isDataStlPlc = false // 정산처 on
                    isDataDisHldPlc = false // 재고보유처 on
                    isDataStlPlcChk = true // 정산처 chk off
                    isDataDisHldPlcChk = true // 재고보유처 chk off
                } else if (_.isEqual(code, '2')) {
                    isDataStlPlc = true // 정산처 off
                    isDataDisHldPlc = true // 재고보유처 off
                    isDataStlPlcChk = false // 정산처 chk on
                    isDataDisHldPlcChk = false // 재고보유처 chk on
                } else {
                    isDataStlPlc = true // 정산처 off
                    isDataDisHldPlc = true // 재고보유처 off
                    isDataStlPlcChk = true // 정산처 chk off
                    isDataDisHldPlcChk = true // 재고보유처 chk off
                }
            } else {
                isDataStlPlc = true // 정산처 off
                isDataDisHldPlc = true // 재고보유처 off
                isDataStlPlcChk = true // 정산처 chk off
                isDataDisHldPlcChk = true // 재고보유처 chk off
            }
            if (_.isEqual(dealCoGrp, 'AY') && _.isEqual(dealCoCl1, 'A2')) {
                isDataDealcoCl3_1 = false
            }
            this.isDisabled('isDisabledDataEarvYn', isDataEarvYn) // 전자결재전송
            this.isDisabled('isDisabledDataDealcoCl3_1', isDataDealcoCl3_1) // 거래처 분류 해제
            this.isDisabled('isDisabledDataBankCdYn', isDataBankCdYn) // 출금계좌
            this.isDisabled('isDisabledDataStlPlc', isDataStlPlc) // 정산처
            this.isDisabled('isDisabledDataDisHldPlc', isDataDisHldPlc) // 재고보유처
            this.isDisabled('isDisabledDataStlPlcChk', isDataStlPlcChk) // 정산처 chk
            this.isDisabled('isDisabledDataDisHldPlcChk', isDataDisHldPlcChk) // 재고보유처 chk
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },

        changeDealcoCl3() {
            const dealCoCl1 = this.strdInfoData.dealcoClCd1
            const dealCoCl2 = this.etcAddInfoData.dealcoClCd2
            const dealCoCl3 = this.etcAddInfoData.dealcoClCd3

            let isDataEarvYn = true // 전자결재전송대상
            if (
                (_.isEqual(dealCoCl1, 'A2') ||
                    _.isEqual(dealCoCl1, 'A3') ||
                    _.isEqual(dealCoCl1, 'AC') ||
                    _.isEqual(dealCoCl1, 'AD') ||
                    _.isEqual(dealCoCl1, 'AE') ||
                    _.isEqual(dealCoCl1, 'B1') ||
                    _.isEqual(dealCoCl1, 'B2') ||
                    _.isEqual(dealCoCl1, 'E1') ||
                    _.isEqual(dealCoCl1, 'M1') ||
                    _.isEqual(dealCoCl1, 'M2') ||
                    _.isEqual(dealCoCl1, 'D1')) &&
                _.isEqual(dealCoCl2, '2')
            ) {
                isDataEarvYn = false
            } else if (
                (_.isEqual(dealCoCl1, 'A6') || _.isEqual(dealCoCl1, 'A7')) &&
                (_.isEqual(dealCoCl2, '1') || _.isEqual(dealCoCl2, '2')) &&
                (_.isEqual(dealCoCl3, '1') || _.isEqual(dealCoCl3, '2'))
            ) {
                isDataEarvYn = false
            } else if (
                _.isEqual(dealCoCl1, 'AF') &&
                _.isEqual(dealCoCl2, '1') &&
                _.isEqual(dealCoCl3, '1' || _.isEqual(dealCoCl3, '2'))
            ) {
                isDataEarvYn = false
            } else {
                isDataEarvYn = true
            }

            this.isDisabled('isDisabledDataEarvYn', isDataEarvYn) // 전자결재전송대상
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },
        getSknDlvSkyAgencyCd(sktAgencyCd) {
            console.log('sktAgencyCd -> ', sktAgencyCd)
            let dealcoRgstClCd = this.strdInfoData.dealcoRgstClCd // 매장개별 DS
            let dealcoGrpCd = this.strdInfoData.dealcoGrpCd // 물류창고, 기타 ZZ, XZ

            if (
                _.isEqual(dealcoRgstClCd, 'DS') && // 매장개별(DS)
                (_.isEqual(dealcoGrpCd, 'ZZ') || _.isEqual(dealcoGrpCd, 'XZ')) // 물류창고(ZZ), 기타(XZ)
            ) {
                let param = {}
                param['sknDlvSktAgencyCd'] = sktAgencyCd
                let list = [param]
                let params = {}
                params['basPrmDealcoDtlNewDlvDealcoCdDto'] = list
                this.storeSet('paramAgencyCd', params)

                this.getSknDlvDealcoCd_()
                    .then((data) => {
                        this.storeSet(
                            'getSknDlvDealcoCd',
                            data[0].sknDlvDealcoCd
                        )
                    })
                    .catch((error) => {
                        Promise.reject(error)
                    })
                    .finally(() => {
                        console.log('배송지코드발급종료')
                    })
            }
        },
        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getAccDealcosList() {
            let searchParam = {}
            let orgCd = this.basPrmDealcoDtlVo.orgCd
            let orgNm = this.basPrmDealcoDtlVo.orgNm

            searchParam['dealcoCd'] = this.etcAddInfo.accDealcoCd
            searchParam['dealcoNm'] = this.etcAddInfo.accDealcoCdNm

            searchParam['orgCd'] = _.isEmpty(orgCd) ? this.orgInfo.orgCd : orgCd
            searchParam['orgNm'] = _.isEmpty(orgNm) ? this.orgInfo.orgNm : orgNm

            searchParam['dealcoRgstClCd'] = this.strdInfoData.dealcoRgstClCd
            searchParam['dealcoGrpCd'] = this.strdInfoData.dealcoGrpCd
            searchParam['dealcoClCd1'] = this.strdInfoData.dealcoClCd1

            basBcoDealcosApi.getDealcosList(searchParam).then((res) => {
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (!_.isEmpty(res)) {
                    this.etcAddInfo.accDealcoCd = _.get(res[0], 'dealcoCd')
                    this.etcAddInfo.accDealcoCdNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.accSearchForm.dealcoCd = this.etcAddInfo.accDealcoCd
                    this.accSearchForm.dealcoNm = this.etcAddInfo.accDealcoCdNm
                    this.accSearchForm.orgCd = _.isEmpty(orgCd)
                        ? this.orgInfo.orgCd
                        : orgCd
                    this.accSearchForm.orgNm = _.isEmpty(orgNm)
                        ? this.orgInfo.orgNm
                        : orgNm
                    this.accSearchForm.dealcoRgstClCd =
                        this.strdInfoData.dealcoRgstClCd
                    this.accSearchForm.dealcoGrpCd =
                        this.strdInfoData.dealcoGrpCd
                    this.accSearchForm.dealcoClCd1 =
                        this.strdInfoData.dealcoClCd1
                    this.showBasBcoAccDealcos = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onAccDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈

            if (!_.isEmpty(this.etcAddInfo.accDealcoCdNm)) {
                this.getAccDealcosList()
            } else {
                let orgCd = this.basPrmDealcoDtlVo.orgCd
                let orgNm = this.basPrmDealcoDtlVo.orgNm
                this.accSearchForm.dealcoCd = this.etcAddInfo.accDealcoCd
                this.accSearchForm.dealcoNm = this.etcAddInfo.accDealcoCdNm
                this.accSearchForm.orgCd = _.isEmpty(orgCd)
                    ? this.orgInfo.orgCd
                    : orgCd
                this.accSearchForm.orgNm = _.isEmpty(orgNm)
                    ? this.orgInfo.orgNm
                    : orgNm
                this.accSearchForm.dealcoRgstClCd =
                    this.strdInfoData.dealcoRgstClCd
                this.accSearchForm.dealcoGrpCd = this.strdInfoData.dealcoGrpCd
                this.accSearchForm.dealcoClCd1 = this.strdInfoData.dealcoClCd1
                this.showBasBcoAccDealcos = true
            }
        },
        onAccDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.etcAddInfo.accDealcoCdNm)) {
                this.showTcComAlert('정산처명을 입력해주세요.')
                return false
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAccDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onAccDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.etcAddInfo.accDealcoCd = ''
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onAccDealcoReturnData(returnData) {
            this.etcAddInfo.accDealcoCd = _.get(returnData, 'dealcoCd')
            this.etcAddInfo.accDealcoCdNm = _.get(returnData, 'dealcoNm')
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },
        //===================== //내부거래처-전체조직팝업관련 methods ================================
        // ===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getHldDealcosList() {
            let searchParam = {}
            let orgCd = this.basPrmDealcoDtlVo.orgCd
            let orgNm = this.basPrmDealcoDtlVo.orgNm
            searchParam['dealcoCd'] = this.etcAddInfo.hldDealcoCd
            searchParam['dealcoNm'] = this.etcAddInfo.hldDealcoCdNm

            searchParam['orgCd'] = _.isEmpty(orgCd) ? this.orgInfo.orgCd : orgCd
            searchParam['orgNm'] = _.isEmpty(orgNm) ? this.orgInfo.orgNm : orgNm

            searchParam['dealcoRgstClCd'] = this.strdInfoData.dealcoRgstClCd
            searchParam['dealcoGrpCd'] = this.strdInfoData.dealcoGrpCd
            searchParam['dealcoClCd1'] = this.strdInfoData.dealcoClCd1

            basBcoDealcosApi.getDealcosList(searchParam).then((res) => {
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (!_.isEmpty(res)) {
                    this.etcAddInfo.hldDealcoCd = _.get(res[0], 'dealcoCd')
                    this.etcAddInfo.hldDealcoCdNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.hldDealcoResultDealcoRows = res
                    this.hldSearchForm.dealcoCd = this.etcAddInfo.hldDealcoCd
                    this.hldSearchForm.dealcoNm = this.etcAddInfo.hldDealcoCdNm
                    this.hldSearchForm.orgCd = _.isEmpty(orgCd)
                        ? this.orgInfo.orgCd
                        : orgCd
                    this.hldSearchForm.orgNm = _.isEmpty(orgNm)
                        ? this.orgInfo.orgNm
                        : orgNm
                    this.hldSearchForm.dealcoRgstClCd =
                        this.strdInfoData.dealcoRgstClCd
                    this.hldSearchForm.dealcoGrpCd =
                        this.strdInfoData.dealcoGrpCd
                    this.hldSearchForm.dealcoClCd1 =
                        this.strdInfoData.dealcoClCd1
                    this.showBasBcoHldDealcos = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onHldDealcoIconClick() {
            let orgCd = this.basPrmDealcoDtlVo.orgCd
            let orgNm = this.basPrmDealcoDtlVo.orgNm
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.hldDealcoResultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.etcAddInfo.hldDealcoCdNm)) {
                this.getHldDealcosList()
            } else {
                this.hldSearchForm.dealcoCd = this.etcAddInfo.hldDealcoCd
                this.hldSearchForm.dealcoNm = this.etcAddInfo.hldDealcoCdNm
                this.hldSearchForm.orgCd = _.isEmpty(orgCd)
                    ? this.orgInfo.orgCd
                    : orgCd
                this.hldSearchForm.orgNm = _.isEmpty(orgNm)
                    ? this.orgInfo.orgNm
                    : orgNm
                this.hldSearchForm.dealcoRgstClCd =
                    this.strdInfoData.dealcoRgstClCd
                this.hldSearchForm.dealcoGrpCd = this.strdInfoData.dealcoGrpCd
                this.hldSearchForm.dealcoClCd1 = this.strdInfoData.dealcoClCd1
                this.showBasBcoHldDealcos = true
            }
        },
        onHldDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.hldDealcoResultDealcoRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.etcAddInfo.hldDealcoCdNm)) {
                this.showTcComAlert('재고보유처명을 입력해주세요.')
                return false
            }
            // 내부조직팝업(권한) 정보 조회
            this.getHldDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onHldDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.etcAddInfo.hldDealcoCd = ''
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onHldDealcoReturnData(returnData) {
            this.etcAddInfo.hldDealcoCd = _.get(returnData, 'dealcoCd')
            this.etcAddInfo.hldDealcoCdNm = _.get(returnData, 'dealcoNm')
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },
        //===================== //내부거래처-전체조직팝업관련 methods ================================
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            let searchParam = {}
            searchParam['orgCd'] = this.etcAddInfo.orgCd
            searchParam['orgNm'] = this.etcAddInfo.orgNm
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(searchParam)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (!_.isEmpty(res)) {
                        this.etcAddInfo.orgCd = _.get(res[0], 'orgCd')
                        this.etcAddInfo.orgNm = _.get(res[0], 'orgNm')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.popupParam.orgCd = this.etcAddInfo.orgCd
                        this.popupParam.orgNm = this.etcAddInfo.orgNm
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.etcAddInfo.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.popupParam.orgCd = this.etcAddInfo.orgCd
                this.popupParam.orgNm = this.etcAddInfo.orgNm
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.etcAddInfo.orgNm)) {
                this.showTcComAlert('소속조직명을 입력해주세요.')
                return false
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.etcAddInfo.orgCd = ''
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            let orgCd = _.get(returnData, 'orgCd')
            let orgNm = _.get(returnData, 'orgNm')
            let bizChrgOrgCd = _.get(returnData, 'teamOrgCd')
            let teamOrgCd = _.get(returnData, 'teamOrgCd')

            this.etcAddInfo.orgCd = _.isEmpty(orgCd) ? '' : orgCd
            this.etcAddInfo.bizChrgOrgCd = _.isEmpty(bizChrgOrgCd)
                ? ''
                : bizChrgOrgCd
            this.etcAddInfo.teamOrgCd = _.isEmpty(teamOrgCd) ? '' : teamOrgCd
            this.etcAddInfo.orgNm = _.isEmpty(orgNm) ? '' : orgNm
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 조직별 대리점팝업관련 methods ================================
        getOrgAgencyList() {
            let searchParam = {}
            searchParam['agencyCd'] = this.etcAddInfo.sktAgencyCd
            searchParam['agencyNm'] = this.etcAddInfo.sktAgencyNm
            basBcoOrgAgencysApi.getOrgAgencyList(searchParam).then((res) => {
                // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (!_.isEmpty(res)) {
                    this.etcAddInfo.agencyCd = _.get(res[0], 'agencyCd')
                    this.etcAddInfo.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultOrgAgencyRows = res
                    this.searchOrgAgencyParam.agencyCd =
                        this.etcAddInfo.sktAgencyCd
                    this.searchOrgAgencyParam.agencyNm =
                        this.etcAddInfo.sktAgencyNm
                    this.showBcoOrgAgencys = true
                }
            })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            if (_.isEqual(this.reqParam.ifYn, 'Y')) {
                return false
            }
            if (_.isEmpty(this.etcAddInfo.orgNm)) {
                this.showTcComAlert('소속조직을 먼저 선택해주세요.')
                return false
            }
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.etcAddInfo.sktAgencyNm)) {
                this.getOrgAgencyList()
            } else {
                this.searchOrgAgencyParam.agencyCd = this.etcAddInfo.sktAgencyCd
                this.searchOrgAgencyParam.agencyNm = this.etcAddInfo.sktAgencyNm
                this.showBcoOrgAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onAgencyEnterKey() {
            if (_.isEqual(this.reqParam.ifYn, 'Y')) {
                return false
            }
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.etcAddInfo.orgNm)) {
                this.showTcComAlert('소속조직을 먼저 선택해주세요.')
                return false
            }
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.etcAddInfo.sktAgencyNm)) {
                this.showTcComAlert('대리점명을 입력해주세요.')
                return false
            }
            // 내부조직팝업(권한) 정보 조회
            this.getOrgAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.etcAddInfo.agencyCd = ''
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },
        // 대리점 팝업 리턴 이벤트 처리
        onOrgAgencyReturnData(returnData) {
            this.etcAddInfo.sktAgencyCd = _.get(returnData, 'agencyCd')
            this.etcAddInfo.sktAgencyNm = _.get(returnData, 'agencyNm')
            // this.getSknDlvSkyAgencyCd(this.etcAddInfo.sktAgencyCd) 221206 배송지정보에서 코드발급 받는걸로 로직변경
            let params = { ...this.etcAddInfo }
            this.storeSet(this.storeKey, params)
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== //대리점팝업관련 methods ================================
        //===================== 서브점팝업 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getSwingDealIfPop() {
            let searchParam = {}
            searchParam['sktSubCdNm'] = this.etcAddInfo.sktSubCd
            searchParam['sktOrgClCd'] = '06'
            basBcoTbasDealIfPopApi.getTbasDealIfPop(searchParam).then((res) => {
                this.resultSwingDealIfRows = res
                this.basBcoSwingDealIfShow = true

                if (!_.isEmpty(res)) {
                    this.etcAddInfo.sktSubCd = _.get(res[0], 'sktSubCd')
                    this.etcAddInfo.sktSubNm = _.get(res[0], 'orgNm')
                } else {
                    this.resultOrgAgencyRows = res
                    this.popupParam4.sktOrgClCd = '06'
                    this.popupParam4.sktOrgCd = this.etcAddInfo.sktAgencyCd
                    this.popupParam4.sktSubCd = this.etcAddInfo.sktSubCd
                    this.popupParam4.orgNm = this.etcAddInfo.sktSubNm
                    this.basBcoSwingDealIfShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onSwingDealIfIconClick() {
            if (_.isEqual(this.reqParam.ifYn, 'Y')) {
                return false
            }
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.etcAddInfo.sktSubCd)) {
                this.getSwingDealIfPop()
            } else {
                this.popupParam4.sktOrgClCd = '06'
                this.popupParam4.sktSubCd = this.etcAddInfo.sktSubCd
                this.popupParam4.sktOrgCd = this.etcAddInfo.sktAgencyCd
                this.popupParam4.orgNm = this.etcAddInfo.sktSubNm
                this.basBcoSwingDealIfShow = true
            }
        },
        // 팝업 TextField Input 이벤트 처리
        onSwingDealIfInput() {
            if (_.isEqual(this.reqParam.ifYn, 'Y')) {
                return false
            }
            // 입력되는 값이 있으면 코드 초기화
            this.popupParam4.sktSubCd = ''
            let param = { ...this.etcAddInfo }
            this.storeSet('etcAddInfoData', param)
        },
        // 팝업 리턴 이벤트 처리
        onSwingDealIfReturnData(returnData) {
            this.etcAddInfo.sktSubCd = _.get(returnData, 'sktSubCd')
            this.etcAddInfo.sktSubNm = _.get(returnData, 'orgNm')
            let param = { ...this.etcAddInfo }
            this.storeSet('etcAddInfoData', param)
        },
        //===================== //서브점팝업 methods ================================
    },
    watch: {
        basPrmDealcoDtlChrgrVo: {
            handler: function (values) {
                this.etcAddInfo.saleChrgr = values['saleChrgr']

                let param = { ...this.etcAddInfo }
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        basPrmDealcoDtlVo: {
            handler: function (values) {
                let detailData = this.etcAddInfo // 데이터 Set
                let dealcoGrpCd = this.strdInfoData.dealcoGrpCd
                let dealcoClCd1 = this.strdInfoData.dealcoClCd1
                let dealcoClCd2 = this.etcAddInfo.dealcoClCd2
                if (!_.isEmpty(dealcoGrpCd)) {
                    if (_.isEqual(dealcoGrpCd, 'YY')) {
                        // 하부망
                        this.isRequiredSktChnlCd = true
                        this.isRequiredSktSubCd = false
                    } else if (_.isEqual(dealcoGrpCd, 'AY')) {
                        // 직영매장
                        this.isRequiredSktChnlCd = false
                        this.isRequiredSktSubCd = true

                        if (
                            _.isEqual(dealcoClCd1, 'A2') && // 직영점
                            _.isEqual(dealcoClCd2, '2') // 2차점
                        ) {
                            this.isDataDealcoCl3 = true
                        }
                    }
                }

                _.forEach(Object.keys(detailData), (key) => {
                    if (!_.isEmpty(key)) {
                        // 기본정보셋팅
                        let value = values[key]
                        let isValue = false
                        //let currentDate = moment(new Date()).format('YYYY-MM-DD')
                        if (
                            _.isEqual(value, undefined) ||
                            _.isEqual(value, null) ||
                            _.isEqual(value, '')
                        ) {
                            if (typeof detailData[key] === 'object') {
                                value = []
                            } else {
                                value = ''
                            }
                        } else if (_.isEqual(value, 'N')) {
                            if (
                                typeof detailData[key] === 'object' &&
                                (_.isEqual(key, 'accDealcoChk') ||
                                    _.isEqual(key, 'hldDealcoChk'))
                            ) {
                                value = []
                            } else {
                                value = ''
                            }
                        } else {
                            isValue = true
                        }

                        // 필터정보셋팅
                        if (!_.isEqual(key, 'saleChrgr')) {
                            detailData[key] = value
                        }

                        const orgInfoKey = ['orgCd', 'orgNm', 'orgLvl']
                        _.forEach(orgInfoKey, (orgKey) => {
                            if (_.isEqual(key, orgKey)) {
                                detailData[key] = isValue
                                    ? value
                                    : this.orgInfo[key]
                            }
                        })

                        if (!_.isEmpty(values['dealcoClCd1'])) {
                            this.setDealcoCl2(values['dealcoClCd1'])
                        }
                    }
                })

                if (!_.isEmpty(this.etcAddInfo.accDealcoCd)) {
                    this.etcAddInfo.accDealcoChk[0] = 'Y'
                }
                if (!_.isEmpty(this.etcAddInfo.hldDealcoCd)) {
                    this.etcAddInfo.hldDealcoChk[0] = 'Y'
                }

                console.log(
                    'this.etcAddInfo.sktAgencyCd',
                    this.etcAddInfo.sktAgencyCd
                )
                /* 221206 배송지정보에서 코드발급 받는걸로 로직변경
                if (!_.isEmpty(this.etcAddInfo.sktAgencyCd)) {
                    this.getSknDlvSkyAgencyCd(this.etcAddInfo.sktAgencyCd)
                }
                */
                let param = { ...detailData }
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        isDisabledDataDealcoCl2_1_1: {
            handler: function (values) {
                this.isDataDealcoCl2 = values
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },

        isDisabledDataDealcoCl3_1_1: {
            handler: function (values) {
                this.isDataDealcoCl3 = values
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },

        dealcoCl2List1: {
            handler: function (values) {
                if (!this.initParams.pIsNew) {
                    this.dealcoCl2List = values
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        dealcoCl3List1: {
            handler: function (values) {
                if (!this.initParams.pIsNew) {
                    this.dealcoCl3List = values
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        basPrmDealcoDtlCardList1: {
            handler: function (values) {
                if (!_.isEmpty(values) && this.isGridEtcAddInfo1) {
                    clearTimeout(this.clickStatus)
                    this.clickStatus = setTimeout(() => {
                        this.init()
                    }, 200)
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
