import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'pagingSeq',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'rgnCd',
        //     dataType: ValueType.TEXT, //권역코드
        // },
        {
            fieldName: 'rgnNm',
            dataType: ValueType.TEXT, //권역
        },
        // {
        //     fieldName: 'lvOrgCd1',
        //     dataType: ValueType.TEXT, //조직1코드
        // },
        // {
        //     fieldName: 'lvOrgNm1',
        //     dataType: ValueType.TEXT, //조직1명
        // },
        // {
        //     fieldName: 'lvOrgCd2',
        //     dataType: ValueType.TEXT, //조직2코드
        // },
        // {
        //     fieldName: 'lvOrgNm2',
        //     dataType: ValueType.TEXT, //조직2명
        // },
        // {
        //     fieldName: 'orgCd',
        //     dataType: ValueType.TEXT, //조직코드
        // },
        // {
        //     fieldName: 'orgNm',
        //     dataType: ValueType.TEXT, // 조직명
        // },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, //조직트리명
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처처명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //상품색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //상품색상명
        },
        {
            fieldName: 'totDisQty',
            dataType: ValueType.NUMBER, //보유수량합계
        },
        {
            fieldName: 'tdDisQty',
            dataType: ValueType.NUMBER, //보유수량TD
        },
        {
            fieldName: 'shopDisQty',
            dataType: ValueType.NUMBER, //보유수량매장재고
        },
        {
            fieldName: 'movIngTdQty',
            dataType: ValueType.NUMBER, //이동예정이동중
        },
        {
            fieldName: 'movInTdQty',
            dataType: ValueType.NUMBER, //이동예정입고
        },
        {
            fieldName: 'saleTdDisQty',
            dataType: ValueType.NUMBER, //판매출고확정TD
        },
        {
            fieldName: 'saleShopDisQty',
            dataType: ValueType.NUMBER, //판매출고확정매장재고
        },
        {
            fieldName: 'saleSumQty',
            dataType: ValueType.NUMBER, //판매출고확정합계
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'pagingSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'NO',
                showTooltip: false,
            },
        },
        // {
        //     name: '권역코드',
        //     fieldName: 'rgnCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '권역코드',
        //         showTooltip: false,
        //     },
        // },
        {
            name: '권역',
            fieldName: 'rgnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '권역',
                showTooltip: false,
            },
        },
        // {
        //     name: '조직1코드',
        //     fieldName: 'lvOrgCd1',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '조직1코드',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: '조직1명',
        //     fieldName: 'lvOrgNm1',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '조직1명',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: '조직2코드',
        //     fieldName: 'lvOrgCd2',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '조직2코드',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: '조직2명',
        //     fieldName: 'lvOrgNm2',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '조직2명',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: '조직코드',
        //     fieldName: 'orgCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '조직코드',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: '조직명',
        //     fieldName: 'orgNm',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '조직명',
        //         showTooltip: false,
        //     },
        // },
        {
            name: '조직트리명',
            fieldName: 'treeOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직트리명',
                showTooltip: false,
            },
        },
        {
            name: '거래처코드',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: '거래처명',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
        },
        {
            name: '모델코드',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: '모델명',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: '색상코드',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: '색상명',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: '합계',
            fieldName: 'totDisQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,###',
            header: {
                text: '합계',
                showTooltip: false,
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'TD',
            fieldName: 'tdDisQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,###',
            header: {
                text: 'TD',
                showTooltip: false,
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: '매장',
            fieldName: 'shopDisQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,###',
            header: {
                text: '매장',
                showTooltip: false,
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: '이동중',
            fieldName: 'movIngTdQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,###',
            header: {
                text: '이동중',
                showTooltip: false,
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: '입고',
            fieldName: 'movInTdQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,###',
            header: {
                text: '입고',
                showTooltip: false,
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: '출고_TD',
            fieldName: 'saleTdDisQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,###',
            header: {
                text: '출고_TD',
                showTooltip: false,
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: '출고_매장',
            fieldName: 'saleShopDisQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,###',
            header: {
                text: '출고_매장',
                showTooltip: false,
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: '출고_합계',
            fieldName: 'saleSumQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,###',
            header: {
                text: '출고_합계',
                showTooltip: false,
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
    ],
    layout: [
        'NO',
        // '권역코드',
        '권역',
        // '조직1코드',
        // '조직1명',
        // '조직2코드',
        // '조직2명',
        // '조직코드',
        // '조직명',
        '조직트리명',
        '거래처코드',
        '거래처명',
        '모델코드',
        '모델명',
        '색상코드',
        '색상명',
        {
            name: '보유수량',
            direction: 'horizontal',
            items: ['합계', 'TD', '매장'],
        },
        {
            name: '이동예정',
            direction: 'horizontal',
            items: ['이동중', '입고'],
        },
        {
            name: '판매출고',
            direction: 'horizontal',
            items: ['출고_TD', '출고_매장', '출고_합계'],
        },
    ],
}
