<!-----------------------------------------------
 * 업무그룹명: 재고이동>재고조정이동현황 → 재고조정현황(명칭변경)
 * 서브업무명: 재고조정현황
 * 설명: 재고조정현황
 * 작성자: P179237
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>재고조정현황</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="cfSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="개통일자"
                        :eRequired="true"
                        calType="DP"
                        v-model="setDate"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="dsCondition.orgNm"
                        :codeVal.sync="dsCondition.orgCd"
                        labelName="조직"
                        :eRequired="true"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00500"
                        labelName="단말기구분"
                        v-model="dsCondition.eqpClCd"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        v-model="dsCondition.prodClCd"
                        :filterFunc="filterFunc"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00240"
                        labelName="거래처구분"
                        v-model="dsCondition.dealcoClCd1"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="dsCondition.saleDealcoNm"
                        :codeVal.sync="dsCondition.saleDealcoCd"
                        labelName="판매처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div2"></div>
            </div>
            <!-- //Search_line 2 -->
        </div>
        <!-- //Search_div -->

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="재고조정현황"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getPagingData"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil, CommonMsg, CommonGrid } from '@/utils'
import _ from 'lodash'
import { SacCommon } from '@/views/biz/sac/js'

import { G_HEADER } from '@/const/grid/dis/dtr/disDtrDisAdjHead'

import api from '@/api/biz/dis/dtr/disDtrDisAdj'
import attachedFileApi from '@/api/common/attachedFile'

//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-권한조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================

export default {
    name: 'DisDtrDisAdj',
    mixins: [CommonMixin],
    components: { BasBcoAuthOrgTreesPopup, BasBcoDealcosPop },
    data() {
        return {
            indicatorOpt: { sort: 'ASC' },
            dsCondition: {
                saleDealcoCd: '',
                saleDealcoNm: '',
                onlyAccDeaCoCd: 'Y', //정산처리여부
                basDay: '', //기준년월
                eqpClCd: '',
                prodClCd: '',
                dealcoClCd1: '',
                fromSvcDt: '',
                toSvcDt: '',
            },
            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},
            view: G_HEADER,
            dsResult: [],

            objAuth: {}, // ?????
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처-권한조직====================
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: '', //거래처그룹코드
                dealcoClCd1: '', //거래처구분코드
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================
            // paging
            rowCnt: 15, // 표시할 행의 갯수
            //조회 파라미터
            reqParams: {},
        }
    },
    created() {
        this.gridData = this.GridSetData()
    },
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 초기값 세팅
        this.fInit()
    },
    computed: {
        setDate: {
            get() {
                return [this.dsCondition.fromSvcDt, this.dsCondition.toSvcDt]
            },
            set(val) {
                this.dsCondition.fromSvcDt = val[0]
                this.dsCondition.toSvcDt = val[1]
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                return val
            },
        },
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            this.gridObj.setGridState(true)
            this.gridData = this.GridSetData()
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 폼 초기화
        fInit: function () {
            this.dsCondition.fromSvcDt = SacCommon.getFirstday()
            this.dsCondition.toSvcDt = SacCommon.getToday()
            this.dsCondition.basDay = SacCommon.getTodayMonth()
        },
        cfSearch: function () {
            if (this.fCheckDefault()) {
                this.dsResult = []
                this.gridObj.setRows([])

                this.dsCondition.pageSize = this.rowCnt
                this.gridData.totalPage = 0 // 이전페이지정보 초기화
                this.getPagingData(1)
            }
        },
        getPagingData: function (pageNum) {
            this.dsCondition.pageNum = pageNum
            const formData = this.getDsCondition()

            // 페이징 조회
            api.getDisAdjMovePrsts(formData).then((resultData) => {
                if (resultData) {
                    this.dsResult = resultData.gridList
                    this.gridObj.setRows(this.dsResult)
                    // 페이징 관련
                    this.gridObj.setGridIndicator(
                        resultData.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.GridSetData() //초기화
                    this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
            })
        },
        fCheckDefault: function () {
            // this.dsCondition.fromSvcDt = this.dsCondition.calOrdDtm[0]
            // this.dsCondition.toSvcDt = this.dsCondition.calOrdDtm[1]

            if (_.isEmpty(this.dsCondition.fromSvcDt)) {
                this.showTcComAlert('개통일(시작일)을 입력해주십시요.')
                return false
            }
            if (_.isEmpty(this.dsCondition.toSvcDt)) {
                this.showTcComAlert('개통일(종료일)을 입력해주십시요.')
                return false
            }

            const fromDtNumber = SacCommon.removeHyphen(
                this.dsCondition.searchDtFrom
            )
            const toDtNumber = SacCommon.removeHyphen(
                this.dsCondition.searchDtTo
            )

            if (fromDtNumber > toDtNumber) {
                this.showTcComAlert(
                    '개통일(종료일)은 개통일(시작일)보다 커야합니다.'
                )
                return false
            }

            if (fromDtNumber.substr(0, 6) != toDtNumber.substr(0, 6)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_01001'))
                return false
            }

            if (_.isEmpty(this.dsCondition.orgCd)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return false
            }
            return true
        },

        // 조회조건 가져오기
        getDsCondition: function () {
            // testdata
            // this.dsCondition.orgLvl = '3'
            // this.dsCondition.orgCd = 'AC1314'
            // this.dsCondition.fromSvcDt = '20220101'
            // this.dsCondition.toSvcDt = '20220103'
            // this.dsCondition.saleDealcoCd = '96674'
            //testdata

            const reqData = SacCommon.objectRemovedArray(this.dsCondition)

            // 엑셀다운로드
            this.reqParams = reqData

            const formData = {
                dsCondition: {
                    ...reqData,
                },
            }
            return formData
        },

        // 초기화
        clearPage() {
            CommonUtil.clearPage(this, 'dsCondition', this.gridObj)
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //Grid ExcelDown
        onClickDownload: function () {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dtr/disAdjMovePrstsExcelDown',
                this.reqParams
            )
        },
        // 상품구분 combobox filter
        filterFunc(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] === '' ||
                    item['commCdVal'] === '1' ||
                    item['commCdVal'] === '2'
            )
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.dsCondition.orgCd
            this.searchParam.orgNm = this.dsCondition.orgNm
            this.searchParam.orgLvl = this.dsCondition.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(
                    SacCommon.objectRemovedArray(this.searchParam)
                )
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.dsCondition.orgCd = _.get(res[0], 'orgCd')
                        this.dsCondition.orgNm = _.get(res[0], 'orgNm')
                        this.dsCondition.orgLvl = _.get(res[0], 'orgLvl')
                        this.searchForm.orgCd = this.dsCondition.orgCd
                        this.searchForm.orgNm = this.dsCondition.orgNm
                        this.searchForm.orgLvl = this.dsCondition.orgLvl
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.dsCondition.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsCondition.orgNm)) {
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                // this.headerText = '검색조건 필수'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.dsCondition.orgCd = ''
            this.dsCondition.orgLvl = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.orgCd = _.get(retrunData, 'orgCd')
            this.dsCondition.orgNm = _.get(retrunData, 'orgNm')
            this.dsCondition.orgLvl = _.get(retrunData, 'orgLvl')
            this.searchForm.orgCd = this.dsCondition.orgCd
            this.searchForm.orgNm = this.dsCondition.orgNm
            this.searchForm.orgLvl = this.dsCondition.orgLvl
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            this.searchForm.dealcoCd = this.dsCondition.saleDealcoCd
            this.searchForm.dealcoNm = this.dsCondition.saleDealcoNm
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.dsCondition.saleDealcoCd = _.get(res[0], 'dealcoCd')
                    this.dsCondition.saleDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.dsCondition.saleDealcoNm)) {
                // this.getDealcosList()
                this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsCondition.saleDealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-권한조직명 입력해주세요.'
                return
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.dsCondition.saleDealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.saleDealcoCd = _.get(retrunData, 'dealcoCd')
            this.dsCondition.saleDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================
    },
}
</script>
