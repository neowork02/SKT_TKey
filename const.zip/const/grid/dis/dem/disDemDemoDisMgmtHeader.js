import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'demoRgstSeq',
            dataType: ValueType.TEXT, //시연등록순번
        },
        {
            fieldName: 'demoMgmtNo',
            dataType: ValueType.TEXT, //시연관리번호
        },
        {
            fieldName: 'demoYn',
            dataType: ValueType.TEXT, //시연재고여부
        },
        {
            fieldName: 'demoYnNm',
            dataType: ValueType.TEXT, //시연재고여부명
        },
        {
            fieldName: 'tdayDemoYn',
            dataType: ValueType.TEXT, //당일시연변경여부
        },
        {
            fieldName: 'demoRgstDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', //시연등록일자
        },
        {
            fieldName: 'saleAmt',
            dataType: ValueType.NUMBER, //판매금액
        },
        {
            fieldName: 'salePosDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', //판매가능일자
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, //시연재고등록처코드 보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, // 보유처명
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT, //삭제여부
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, //수정횟수
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT, //입력사용자ID
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT, //입력일시입력일시
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, //수정사용자ID
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT, //등록자명
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, //수정일시
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, //레벨0조직코드
        },
        {
            fieldName: 'lvOrgNm',
            dataType: ValueType.TEXT, //레벨0조직명
        },
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT, //레벨1조직코드
        },
        {
            fieldName: 'lvOrgNm1',
            dataType: ValueType.TEXT, //레벨1조직명
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, //레벨2조직코드
        },
        {
            fieldName: 'lvOrgNm2',
            dataType: ValueType.TEXT, //레벨2조직명
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT, //레벨3조직코드
        },
        {
            fieldName: 'lvOrgNm3',
            dataType: ValueType.TEXT, //레벨3조직명
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직명
        },
        {
            fieldName: 'hldShopCd',
            dataType: ValueType.TEXT, //보유처매장코드
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT, //재고상태코드
        },
        {
            fieldName: 'disStNm',
            dataType: ValueType.TEXT, //재고상태명
        },
        {
            fieldName: 'lastInoutDtlClCd',
            dataType: ValueType.TEXT, //최종이력코드
        },
        {
            fieldName: 'lastInoutDtlClNm',
            dataType: ValueType.TEXT, //최종이력명
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분명
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT, //제조사코드
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사명
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처매장코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'dealcoShopCd',
            dataType: ValueType.TEXT, //거래처매장코드
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT, //요청사용자ID
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'badYnNm',
            dataType: ValueType.TEXT, //불량여부명
        },
        {
            fieldName: 'lastInoutDt',
            dataType: ValueType.TEXT, //최종입출고일자
        },
        {
            fieldName: 'posDealcoCd',
            dataType: ValueType.TEXT, //소속거래처코드
        },
        {
            fieldName: 'posDealcoNm',
            dataType: ValueType.TEXT, //소속거래처명
        },
        {
            fieldName: 'posShopCd',
            dataType: ValueType.TEXT, //소속거래처매장코드
        },
        {
            fieldName: 'fixCrdtAmt',
            dataType: ValueType.TEXT, //확정여신가
        },
        {
            fieldName: 'realAmt',
            dataType: ValueType.TEXT, //실매입가
        },
        {
            fieldName: 'oprNm',
            dataType: ValueType.TEXT, //등록자명
        },
    ],
    columns: [
        {
            name: 'demoRgstDt',
            fieldName: 'demoRgstDt',
            type: 'data',
            header: {
                text: '등록일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            header: {
                text: '등록자',
                showTooltip: false,
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'hldShopCd',
            fieldName: 'hldShopCd',
            type: 'data',
            header: {
                text: '보유처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            type: 'data',
            header: {
                text: '보유처',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            header: {
                text: '모델코드',
            },
            editor: {
                type: 'date',
                textReadOnly: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            header: {
                text: '모델',
            },
            editor: {
                type: 'date',
                textReadOnly: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'demoYnNm',
            fieldName: 'demoYnNm',
            type: 'data',
            header: {
                text: '시연재고여부',
                showTooltip: false,
            },
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            type: 'data',
            header: {
                text: '판매금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'salePosDt',
            fieldName: 'salePosDt',
            type: 'data',
            header: {
                text: '판매가능일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'disStNm',
            fieldName: 'disStNm',
            type: 'data',
            header: {
                text: '재고상태',
                showTooltip: false,
            },
        },
        {
            name: 'lastInoutDtlClNm',
            fieldName: 'lastInoutDtlClNm',
            type: 'data',
            header: {
                text: '최종이력',
                showTooltip: false,
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '300',
            header: {
                text: '비고',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_HEADER_REGISTER = {
    fields: [
        {
            fieldName: 'no',
            dataType: ValueType.TEXT, //번호
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //모델코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'saleAmt',
            dataType: ValueType.TEXT, //판매금액
        },
        {
            fieldName: 'salePosDt',
            dataType: ValueType.TEXT, //판매가능일
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //오류사항
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT, //처리자ID
        },
        {
            fieldName: 'demoOrdDt',
            dataType: ValueType.TEXT, //등록일자
        },
    ],
    columns: [
        // {
        //     name: 'no',
        //     fieldName: 'no',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '번호',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매금액',
                showTooltip: false,
            },
        },
        {
            name: 'salePosDt',
            fieldName: 'salePosDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매가능일',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류검증',
                showTooltip: false,
            },
        },
        {
            name: 'demoOrdDt',
            fieldName: 'demoOrdDt',
            visible: false,
            type: 'data',
        },
    ],
}
