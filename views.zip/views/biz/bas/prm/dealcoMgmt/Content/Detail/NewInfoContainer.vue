<template>
    <div>
        <!-- 신규정보 -->
        <!-- Search_div_Type4 -->
        <div class="searchLayer_wrap type04 mt20">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div3">
                    <TCComCheckBox
                        labelName=""
                        v-model="newInfo.earvType"
                        :itemList="docList"
                        cols="6"
                        @change="changeDoc"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div3">
                    <!-- arrayType_notit -->
                    <div class="arrayType notit">
                        <div class="colbtn">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="품의기안"
                                @click="earvSnd"
                                :disabled="this.isDisabledDataEarvYn1"
                            />

                            <!-- :disabled="true"-->
                        </div>
                        <div class="colinput">
                            <TCComComboBox
                                v-model="newInfo.eravStCd"
                                :addBlankItem="true"
                                blankItemText="전송유형 선택"
                                blankItemValue=""
                                :itemList="eravStcdList"
                                @change="changeEravStCd"
                                :disabled="this.isDisabledDataEarvYn1"
                            />
                        </div>
                        <BasPrmEarvTrmsNewAgrmtPopup
                            v-if="showBasPrmEarvNewAgrmt"
                            :rows="resultBasPrmEarv"
                            :dialogShow.sync="showBasPrmEarvNewAgrmt"
                            :parentParam="searchEarv"
                            :objAuth="objAuth"
                        />
                        <BasPrmEarvTrmsCltRenewalPopup
                            v-if="showBasPrmEarvCltRenewal"
                            :rows="resultBasPrmEarv"
                            :dialogShow.sync="showBasPrmEarvCltRenewal"
                            :parentParam="searchEarv"
                            :objAuth="objAuth"
                        />
                        <BasPrmEarvTrmsAgrmtTermPopup
                            v-if="showBasPrmEarvAgrmtTerm"
                            :rows="resultBasPrmEarv"
                            :dialogShow.sync="showBasPrmEarvAgrmtTerm"
                            :parentParam="searchEarv"
                            :objAuth="objAuth"
                        />
                        <BasPrmEarvTrmsChgPopup
                            v-if="showBasPrmEarvChg"
                            :rows="resultBasPrmEarv"
                            :dialogShow.sync="showBasPrmEarvChg"
                            :parentParam="searchEarv"
                            :objAuth="objAuth"
                        />
                        <BasPrmEarvTrmsChgCltRenewalPopup
                            v-if="showBasPrmEarv"
                            :rows="resultBasPrmEarv"
                            :dialogShow.sync="showBasPrmEarv"
                            :parentParam="searchEarv"
                            :objAuth="objAuth"
                        />
                        <BasPrmEarvTrmsNewAgrmtReConsi
                            v-if="showBasPrmEarvReConsi"
                            :rows="resultBasPrmEarv"
                            :dialogShow.sync="showBasPrmEarvReConsi"
                            :parentParam="searchEarv"
                            :objAuth="objAuth"
                        />
                    </div>
                    <!-- //arrayType_notit -->
                </div>
                <!-- //item 1-2 -->
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- //Search_div_Type4 -->
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dealcoMgmt/helpers'

import BasPrmEarvTrmsNewAgrmtPopup from '../../../BasPrmEarvTrmsNewAgrmtPopup'
import BasPrmEarvTrmsCltRenewalPopup from '../../../BasPrmEarvTrmsCltRenewalPopup'
import BasPrmEarvTrmsAgrmtTermPopup from '../../../BasPrmEarvTrmsAgrmtTermPopup'
import BasPrmEarvTrmsChgPopup from '../../../BasPrmEarvTrmsChgPopup'
import BasPrmEarvTrmsChgCltRenewalPopup from '../../../BasPrmEarvTrmsChgCltRenewalPopup'
import BasPrmEarvTrmsNewAgrmtReConsi from '../../../BasPrmEarvTrmsNewAgrmtReConsi'

import _ from 'lodash'
import CommonMixin from '@/mixins'
export default {
    name: 'NewInfoContainer',
    components: {
        BasPrmEarvTrmsNewAgrmtPopup,
        BasPrmEarvTrmsCltRenewalPopup,
        BasPrmEarvTrmsAgrmtTermPopup,
        BasPrmEarvTrmsChgPopup,
        BasPrmEarvTrmsChgCltRenewalPopup,
        BasPrmEarvTrmsNewAgrmtReConsi,
    },
    mixins: [CommonMixin],
    props: {},
    data() {
        return {
            objAuth: {},
            newInfo: {
                earvType: [],
                eravStCd: '',
            },
            storeKey: 'newInfoData',
            docList: [
                {
                    commCdVal: '10',
                    commCdValNm: '신규 서류첨부',
                },
                {
                    commCdVal: '20',
                    commCdValNm: '변경 서류첨부',
                },
            ],
            eravStcdList: [
                {
                    commCdVal: '',
                    commCdValNm: '전송유형 선택',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '신규계약',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '담보갱신',
                },
                {
                    commCdVal: '3',
                    commCdValNm: '계약해지',
                },
                {
                    commCdVal: '4',
                    commCdValNm: '변경',
                },
                {
                    commCdVal: '5',
                    commCdValNm: '변경&담보갱신',
                },
                {
                    commCdVal: '6',
                    commCdValNm: '신규계약_재품의',
                },
            ],
            //====================신규계약====================
            showBasPrmEarvNewAgrmt: false, // 팝업 오픈 여부
            searchEarv: {},
            resultBasPrmEarv: [], // 팝업 리턴 값
            //===============================================
            //====================담보갱신====================
            showBasPrmEarvCltRenewal: false, // 팝업 오픈 여부
            // searchEarv: {},
            // resultBasPrmEarv: [], // 팝업 리턴 값
            //===============================================
            //====================계약해지====================
            showBasPrmEarvAgrmtTerm: false, // 팝업 오픈 여부
            // searchEarv: {},
            // resultBasPrmEarv: [], // 팝업 리턴 값
            //===============================================
            //====================변경=======================
            showBasPrmEarvChg: false, // 팝업 오픈 여부
            // searchEarv: {},
            // resultBasPrmEarv: [], // 팝업 리턴 값
            //===============================================
            //====================변경&담보갱신===============
            showBasPrmEarv: false, // 팝업 오픈 여부
            // searchEarv: {},
            // resultBasPrmEarv: [], // 팝업 리턴 값
            //===============================================
            //====================신규계약재품의==============
            showBasPrmEarvReConsi: false, // 팝업 오픈 여부
            // searchEarv: {},
            // resultBasPrmEarv: [], // 팝업 리턴 값
            //===============================================
        }
    },
    computed: {
        ...serviceComputed,
        isDealStatusYn: {
            get() {
                return this.isDealStatus
            },
        },
        isDisabledDataEarvYn1: {
            get() {
                return this.isDisabledDataEarvYn
            },
        },
        earvSt: {
            get() {
                return this.earvStType
            },
        },
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },

        dealcoCl2List1: {
            get() {
                return this.dealcoCl2ListEarv
            },
        },
        dealcoCl3List1: {
            get() {
                return this.dealcoCl3ListEarv
            },
        },
    },
    created() {},
    mounted() {
        this.initData()
    },
    methods: {
        ...serviceMethods,
        initData() {
            this.newInfo = {
                earvType: [],
                eravStCd: '',
            }
        },
        setData() {
            let params = { ...this.newInfo }
            this.storeSet(this.storeKey, params)
        },

        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        test() {
            //  TODO TEST
            console.log('earvSnd 전자결재 테스트 로직!!!')
            if (_.isEqual(this.newInfo.eravStCd, '1')) {
                // 신규계약
                this.cltEarvTrms()
            } else if (_.isEqual(this.newInfo.eravStCd, '2')) {
                // 담보갱신
                this.chgNew() // BASPRM02643.xml
            } else if (_.isEqual(this.newInfo.eravStCd, '3')) {
                // 계약해지
                this.dealEndChg() // BASPRM02644.xml
            } else if (_.isEqual(this.newInfo.eravStCd, '4')) {
                // 변경
                this.chg() // BASPRM02641.xml
            } else if (_.isEqual(this.newInfo.eravStCd, '5')) {
                // 변경&담보갱신
                this.chgClt() // BASPRM02642.xml
            } else if (_.isEqual(this.newInfo.eravStCd, '6')) {
                // 신규계약_재품의
                this.newReEarv() // BASPRM02646.xml
            } else {
                this.showTcComAlert('전자결재 전송 대상이 아닙니다.')
            }
        },
        real() {
            if (
                _.isEmpty(this.newInfo.eravStCd) // 전송유형
            ) {
                this.showTcComAlert('전송유형을 선택하세요')
            } else {
                if (
                    _.isEmpty(this.params.dealcoCd) && // 거래처코드
                    !_.isEqual(this.newInfo.eravStCd, '1') // 전송유형 1 : 신규계약
                ) {
                    this.showTcComAlert('품의기안(신규계약) 대상입니다.')
                } else if (
                    _.isEmpty(this.params.dealcoCd) && // 거래처코드
                    _.isEqual(this.newInfo.eravStCd, '1') && // 전송유형 1 : 신규계약
                    _.isEqual(this.earvSt, '2') // 사업자정보 2: 신규
                ) {
                    // 신규계약_전자결재_전송
                    this.cltEarvTrms() // BASPRM02640.xml
                } else if (
                    _.isEqual(this.earvSt, '3') && // 사업자정보 3 : 변경
                    !_.isEqual(this.newInfo.eravStCd, '4') // 전송유형 4 : 변경이 아닐 경우
                ) {
                    //변경 3
                    // 변경_제외
                    this.showTcComAlert('품의기안(변경) 대상입니다.')
                } else if (
                    _.isEqual(this.earvSt, '3') && // 사업자정보 3 : 변경
                    _.isEqual(this.newInfo.eravStCd, '4') // 전송유형 4 : 변경
                ) {
                    // TODO 내용수정
                    // 변경
                    this.chg() // BASPRM02641.xml
                } else if (
                    _.isEqual(this.earvSt, '4') && // 사업자정보 4 : 담보갱신
                    !_.isEqual(this.newInfo.eravStCd, '2') // 전송유형 2 : 담보갱신이 아닐 경우
                ) {
                    //담보갱신:2
                    // 변경_신규_제외
                    this.showTcComAlert('품의기안(담보갱신) 대상입니다.')
                } else if (
                    _.isEqual(this.earvSt, '4') && // 사업자정보 4 : 담보갱신
                    _.isEqual(this.newInfo.eravStCd, '2') // 전송유형 2 : 담보갱신
                ) {
                    // TODO 내용수정
                    // 변경_신규
                    this.chgNew() // BASPRM02643.xml
                } else if (
                    this.isDealStatusYn && // 거래종료
                    !_.isEqual(this.newInfo.eravStCd, '3') // 전송유형 3 : 계약해지이 아닌 경우
                ) {
                    //계약해지:3
                    // 거래_종료_변경_제외
                    this.showTcComAlert('품의기안(계약해지) 대상입니다.')
                } else if (
                    this.isDealStatusYn && // 거래종료
                    _.isEqual(this.newInfo.eravStCd, '3') && // 전송유형 3 : 계약해지
                    _.isEqual(this.earvSt, '6') // 사업자정보 6 : 해지
                ) {
                    // TODO 내용수정
                    // 거래_종료_변경
                    this.dealEndChg() // BASPRM02644.xml
                } else if (
                    _.isEqual(this.earvSt, '5') && // 사업자정보 5 : 변경&담보갱신
                    !_.isEqual(this.newInfo.eravStCd, '5') // 전송유형 5 : 변경&담보갱신이 아닌 경우
                ) {
                    // 변경_담보_제외
                    this.showTcComAlert('품의기안(변경&담보갱신) 대상입니다.')
                } else if (
                    _.isEqual(this.earvSt, '5') && // 사업자정보 5 : 변경&담보갱신
                    _.isEqual(this.newInfo.eravStCd, '5') // 전송유형 5 : 변경&담보갱신
                ) {
                    // TODO 내용수정
                    // 변경_담보
                    this.chgClt() // BASPRM02642.xml
                } else if (
                    _.isEqual(this.earvSt, '7') && // 사업자정보 7 : 품의기안(신규_재품의)
                    !_.isEqual(this.newInfo.eravStCd, '6') // 전송유형 6 :신규계약_재품의이 아닌 경우
                ) {
                    //재품의
                    // 신규_재품의_제외
                    this.showTcComAlert('품의기안(신규계약_재품의) 대상입니다.')
                } else if (
                    _.isEqual(this.earvSt, '7') && // 사업자정보 7 : 품의기안(신규_재품의)
                    _.isEqual(this.newInfo.eravStCd, '6') // 전송유형 6 :신규계약_재품의
                ) {
                    // TODO 내용수정
                    // 신규_재품의
                    this.newReEarv() // BASPRM02646.xml
                } else {
                    this.showTcComAlert('전자결재 전송 대상이 아닙니다.')
                }
            }
        },
        earvSnd() {
            console.log('this.earvSt ->', this.earvSt)
            console.log('this.newInfo.eravStCd ->', this.newInfo.eravStCd)
            //this.test()
            this.real()
        },
        changeDoc(docType) {
            if (docType.length > 1) {
                this.showTcComAlert('동시 체크를 할 수 없습니다.')
                this.newInfo.earvType = []
            } else {
                _.forEach(docType, (data) => {
                    if (_.isEqual(data, '20')) {
                        if (
                            this.isStrdInfo &&
                            this.isBizRgst &&
                            this.isCltInfo
                        ) {
                            this.newInfo.earvType = []
                            this.showTcComAlert(
                                '변경 데이터가 있을때 사용 할 수 없습니다.'
                            )
                        }
                    }
                })
            }
            let param = { ...this.newInfo }
            this.storeSet(this.storeKey, param)
        },
        changeEravStCd(code) {
            this.newInfo.eravStCd = code
            let param = { ...this.newInfo }
            this.storeSet(this.storeKey, param)
        },
        isEmptyDefault(value) {
            let val = this.params[value]
            if (_.isEmpty(val) || val === 'undefined') {
                val = ''
            }
            return val
        },
        getCrdInfo() {
            let data = this.isEmptyDefault('basPrmDealcoCrdDto')
            if (!_.isEmpty(data)) {
                let cnt = 1
                _.forEach(data, (item) => {
                    if (_.isEqual(item.earv, 'Y')) {
                        ;(this.searchEarv['crdTypNm' + cnt] = item.crdtTypCd), // 여신유형
                            (this.searchEarv['crdTypNmNm' + cnt] = this.getName(
                                'crdTypNm',
                                item.crdtTypCd
                            )), // 여신유형
                            (this.searchEarv['grtInstNm' + cnt] =
                                item.grtInstCd), // 보증기관
                            (this.searchEarv['grtInstNmNm' + cnt] =
                                this.getName('grtInstNm', item.grtInstCd)), // 보증기관
                            (this.searchEarv['setDt' + cnt] = item.setDt), // 설정일
                            (this.searchEarv['mrtgAmt' + cnt] = item.mrtgAmt), // 담보금액
                            (this.searchEarv['cmms' + cnt] = item.cmmsAmt), // 수수료
                            (this.searchEarv['mrtgSetAmt' + cnt] =
                                item.mrtgSetAmt), // 담보설정금액
                            (this.searchEarv['setBasis' + cnt] =
                                item.setBasisDesc), // 설정근거
                            (this.searchEarv['expirDt' + cnt] = item.expirDt), // 만료일
                            (this.searchEarv['etc2' + (cnt + 1)] = item.crdRmks) // 비고
                        cnt++
                    }
                })
            }
        },
        getJson(val, json) {
            for (let i = 0; i < json.length; i++) {
                let jsonVal = json[i].commCdVal
                let valueNm = json[i].commCdValNm

                if (_.isEqual(val, jsonVal)) {
                    return valueNm
                }
            }
        },
        getName(key, value) {
            // 거래처구분
            if (_.isEqual('dealCoCl1', key)) {
                return this.getJson(value, this.ZBAS_C_00240)
                // 사업자구분
            } else if (_.isEqual('dealCoCl2', key)) {
                return this.getJson(value, this.dealcoCl2List1)
                // 과세구분
            } else if (_.isEqual('dealCoCl3', key)) {
                return this.getJson(value, this.dealcoCl3List1)
                // 과세구분
            } else if (_.isEqual('perBizCl', key)) {
                return this.getJson(value, this.ZBAS_C_00400)
                // 과세구분
            } else if (_.isEqual('taxStrd', key)) {
                return this.getJson(value, this.ZBAS_C_00230)
                // 출금은행
            } else if (_.isEqual('slcmDfryBankCd', key)) {
                return this.getJson(value, this.ZBAS_C_00420)
                // 여신유형
            } else if (_.isEqual('crdTypNm', key)) {
                return this.getJson(value, this.CRD_TYP)
                // 보증(금융)기관
            } else if (_.isEqual('grtInstNm', key)) {
                return this.getJson(value, this.ZBAS_C_00200)
            }
        },
        getAddr() {
            return (
                this.isEmptyDefault('signZipCd') +
                ' ' +
                this.isEmptyDefault('signAddr') +
                ' ' +
                this.isEmptyDefault('signDtlAddr')
            )
        },
        paramSet() {
            this.searchEarv.earvTypCd = this.isEmptyDefault(this.earvSt) // 전자결재유형코드
            this.searchEarv.eravStCd = this.newInfo.eravStCd
            this.searchEarv.newOrgCd = this.isEmptyDefault('newOrgCd')
            this.searchEarv.orgCd3 = this.isEmptyDefault('orgCd3')
            this.searchEarv.orgCd2 = this.isEmptyDefault('orgCd2')
            // 전자결재상태코드

            this.searchEarv.tradeName = this.isEmptyDefault('tradeNm')
            this.searchEarv.dealCoCl1 = this.isEmptyDefault('dealcoClCd1')
            this.searchEarv.dealCoClNm1 = this.getName(
                'dealCoCl1',
                this.searchEarv.dealCoCl1
            )
            this.searchEarv.dealCoCd = this.isEmptyDefault('dealcoCd')
            this.searchEarv.perBizCl = this.isEmptyDefault('perBizClCd')
            this.searchEarv.perBizClNm = this.getName(
                'perBizCl',
                this.searchEarv.perBizCl
            )
            this.searchEarv.bizNum = this.isEmptyDefault('bizNo')
            this.searchEarv.regNum = this.isEmptyDefault('bizNo')
            this.searchEarv.bizCon = this.isEmptyDefault('bizConNm')
            this.searchEarv.typOfBiz = this.isEmptyDefault('typOfBizNm')
            this.searchEarv.taxStrd = this.isEmptyDefault('taxTypCd')
            this.searchEarv.taxStrdNm = this.getName(
                'taxStrd',
                this.searchEarv.taxStrd
            )
            this.searchEarv.infoAdd = _.trim(this.getAddr())

            this.searchEarv.repUserNm = this.isEmptyDefault('repUserNm')
            this.searchEarv.repMblPhon = this.isEmptyDefault('repMblPhonNo')
            this.searchEarv.telNo = this.isEmptyDefault('telNo')
            this.searchEarv.slcmDfryBankCd =
                this.isEmptyDefault('slcmDfryBankCd')
            this.searchEarv.slcmDfryBankCdNm = this.getName(
                'slcmDfryBankCd',
                this.searchEarv.slcmDfryBankCd
            )
            this.searchEarv.slcmDfryCmsCd = this.isEmptyDefault('slcmDfryCmsCd')
            this.searchEarv.slcmDfryAccNo = this.isEmptyDefault('slcmDfryAccNo')
            this.searchEarv.slcmDfryDepo = this.isEmptyDefault('slcmDfryDepo')

            this.searchEarv.dealCoNm = this.isEmptyDefault('dealcoNm')
            this.searchEarv.sktAgencyCd = this.isEmptyDefault('sktAgencyCd')
            this.searchEarv.dealAdd = _.trim(this.getAddr())

            this.searchEarv.dealCoCl2 = this.isEmptyDefault('dealcoClCd2')
            this.searchEarv.dealCoClNm2 = this.getName(
                'dealCoCl2',
                this.searchEarv.dealCoCl2
            )
            this.searchEarv.dealCoCl3 = this.isEmptyDefault('dealcoClCd3')
            this.searchEarv.dealCoClNm3 = this.getName(
                'dealCoCl3',
                this.searchEarv.dealCoCl3
            )
            this.searchEarv.slcmChk = _.isEqual(
                this.isEmptyDefault('slcmChk'),
                'N'
            )
                ? '불일치'
                : '일치'
            this.searchEarv.slcmDfryDepoCheck = this.params.vrfDpstrNm
            this.searchEarv.signDealAdd = _.trim(this.getAddr())
            this.getCrdInfo()
            console.log('this.searchEarv ->', this.searchEarv)
        },
        /**
         * 신규계약
         * _.isEmpty(this.searchParam.dealcoCd) &&
         * !_.isEqual(this.searchParam.eravStCd, '1')
         */
        newAgrmt() {},
        /**
         * 담보갱신_전자결재_전송
         * _.isEmpty(this.searchParam.dealcoCd) &&
         * _.isEqual(this.earvSt, '2') &&
         * _.isEqual(this.searchParam.eravStCd, '1')
         * BASPRM02640.xml
         */
        cltEarvTrms() {
            this.defaultAssign_({
                key: 'initParams.pIsNew',
                value: false,
            })
            this.searchEarv.pIsNew = '1'
            this.paramSet()
            console.log(
                'cltEarvTrms newReEarv this.searchEarv->',
                this.searchEarv
            )
            this.showBasPrmEarvNewAgrmt = true
        },
        /**
         * 변경_제외
         * _.isEqual(this.earvSt, '3') &&
         * !_.isEqual(this.searchParam.eravStCd, '4')
         */
        chgExl() {},
        /**
         * 변경
         * _.isEqual(this.earvSt, '3') &&
         * _.isEqual(this.searchParam.eravStCd, '4')
         *  BASPRM02641.xml
         */
        chg() {
            this.searchEarv.pIsNew = ''
            this.paramSet()
            console.log('chg newReEarv this.searchEarv->', this.searchEarv)
            this.showBasPrmEarvChg = true
        },
        /**
         * 변경_신규_제외
         * _.isEqual(this.earvSt, '4') &&
         * !_.isEqual(this.searchParam.eravStCd, '2')
         */
        chgNewExl() {},
        /**
         * 변경_신규
         * _.isEqual(this.earvSt, '4') &&
         * !_.isEqual(this.searchParam.eravStCd, '2')
         * BASPRM02643.xml
         */
        chgNew() {
            this.searchEarv.pIsNew = ''
            this.paramSet()
            console.log('chgNew newReEarv this.searchEarv->', this.searchEarv)
            this.showBasPrmEarvCltRenewal = true
        },
        /**
         * 거래_종료_변경_제외
         * this.isDealStatusYn &&
         * !_.isEqual(this.searchParam.eravStCd, '3')
         */
        dealEndChgExl() {},
        /**
         * 거래_종료_변경
         * _.isEqual(this.earvSt, '4') &&
         * !_.isEqual(this.searchParam.eravStCd, '2')
         * BASPRM02644.xml
         */
        dealEndChg() {
            this.searchEarv.pIsNew = ''
            this.paramSet()
            console.log(
                'dealEndChg newReEarv this.searchEarv->',
                this.searchEarv
            )
            this.showBasPrmEarvAgrmtTerm = true
        },
        /**
         * 변경_담보갱신_제외
         * _.isEqual(this.earvSt, '5') &&
         * !_.isEqual(this.searchParam.eravStCd, '5')
         */
        chgCltExl() {},
        /**
         * 변경_담보갱신
         * _.isEqual(this.earvSt, '5') &&
         * _.isEqual(this.searchParam.eravStCd, '5')
         * BASPRM02642.xml
         */
        chgClt() {
            this.searchEarv.pIsNew = ''
            this.paramSet()
            console.log('chgClt newReEarv this.searchEarv->', this.searchEarv)
            this.showBasPrmEarv = true
        },
        /**
         * 신규_재품의_제외
         * _.isEqual(this.earvSt, '7') &&
         * !_.isEqual(this.searchParam.eravStCd, '6')
         */
        newReEarvExt() {},
        /**
         * 신규_재품의
         * _.isEqual(this.earvSt, '7') &&
         * _.isEqual(this.searchParam.eravStCd, '6')
         * BASPRM02646.xml
         */
        newReEarv() {
            this.searchEarv.pIsNew = ''
            this.paramSet()
            console.log('newReEarv this.searchEarv->', this.searchEarv)
            this.showBasPrmEarvReConsi = true
        },
    },
    watch: {
        basPrmDealcoDtlVo: {
            handler: function (values) {
                let detailData = this.newInfo // 데이터 Set

                _.forEach(Object.keys(detailData), (key) => {
                    if (!_.isEmpty(key)) {
                        // 기본정보셋팅
                        let value = values[key]
                        //let isValue = false
                        //let currentDate = moment(new Date()).format('YYYY-MM-DD')
                        if (
                            _.isEqual(value, undefined) ||
                            _.isEqual(value, null) ||
                            _.isEqual(value, '')
                        ) {
                            if (typeof detailData[key] === 'object') {
                                value = []
                            } else {
                                value = ''
                            }
                        } else {
                            //isValue = true
                        }

                        // 필터정보셋팅
                        detailData[key] = value
                    }
                })

                let param = { ...detailData }
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
