/*****************************************
* 업무 그룹명 : 기준정보>통합 SSO ID
* 서브 업무명 : 통합 SSO ID
* 설 명 : 통합 SSO ID Grid 헤더 정보
* 작 성 자 : 양현모
* 작 성 일 : 2022.05.02
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 양현모  / 2022.05.02
* 변경사유/내역 : 
* ---------------------------------------
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const BAS_BCO_SSO_IDS_HEADER = {
    fields: [
        {
            fieldName: 'loginUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'loginUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pwdNo',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'loginUserId',
            fieldName: 'loginUserId',
            styleName: 'left-column',
            header: {
                text: '통합 LOGIN ID',
            },
        },
        {
            name: 'loginUserNm',
            fieldName: 'loginUserNm',
            styleName: 'left-column',
            header: {
                text: '통합 LOGIN 명',
            },
        },
        {
            name: 'userId',
            fieldName: 'userId',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '사용자 ID',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '사용자명',
            },
        },
        {
            name: 'pwdNo',
            fieldName: 'pwdNo',
            type: 'data',
            visible: false,
            header: {
                text: 'PWD NO',
            },
        },
    ],
}
