import { ValueType } from 'realgrid'

export const GRIDHEADER = {
    fields: [
        {
            fieldName: 'opStCd',
            dataType: ValueType.TEXT, // 처리상태코드
        },
        {
            fieldName: 'iniFreeProdeSaleNo',
            dataType: ValueType.TEXT, // 원일반상품판매번호
        },
        {
            fieldName: 'pkgProdSaleNo',
            dataType: ValueType.TEXT, // 패키지상품판매번호
        },
        {
            fieldName: 'pkgProdSaleChgSeq',
            dataType: ValueType.TEXT, // 패키지상품판매변경순번
        },
        {
            fieldName: 'saleChgDtm',
            //dataType: ValueType.TEXT, // 판매변경일시
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'saleDtm',
            //dataType: ValueType.TEXT, // 판매일시
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'saleDealcoCd',
            dataType: ValueType.TEXT, // 판매처코드
        },
        {
            fieldName: 'saleDealcoNm',
            dataType: ValueType.TEXT, // 판매처명
        },
        {
            fieldName: 'prodQty',
            dataType: ValueType.NUMBER, // 수량
        },
        {
            fieldName: 'saleUprc',
            dataType: ValueType.NUMBER, // 판매단가
        },
        {
            fieldName: 'fixStrdSalePrc',
            dataType: ValueType.NUMBER, // 확정기준판매가격
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 처리자ID
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT, // 처리자명
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, //처리일시
        },
        // {
        //     fieldName: 'modDtm',
        //     //dataType: ValueType.TEXT, //처리일시
        //     dataType: 'datetime',
        //     datetimeFormat: 'yyyyMMddhhmmss',
        // },
        {
            fieldName: 'saleStCd',
            dataType: ValueType.TEXT, // 판매상태코드
        },
        {
            fieldName: 'saleStNm',
            dataType: ValueType.TEXT, // 판매상태명
        },
        {
            fieldName: 'orgNmTree',
            dataType: ValueType.TEXT, // 조직트리
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
    ],
    columns: [
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            width: '100',
            header: {
                text: '매출일',
                showTooltip: false,
            },
            editable: false,
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            width: '100',
            header: {
                text: '최초판매일',
                showTooltip: false,
            },
            editable: false,
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'orgNmTree',
            fieldName: 'orgNmTree',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: {
                text: '조직',
                showTooltip: true,
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            width: '100',
            //           styleName: 'left-column',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            width: '100',
            //           styleName: 'left-column',
            header: {
                text: '판매처코드',
                showTooltip: false,
            },
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            header: {
                text: '판매처',
                showTooltip: true,
            },
        },
        {
            name: 'prodQty',
            fieldName: 'prodQty',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '매출수량',
                showTooltip: true,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'saleStNm',
            fieldName: 'saleStNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            header: {
                text: '판매상태',
                showTooltip: true,
            },
        },
        {
            name: 'fixStrdSalePrc',
            fieldName: 'fixStrdSalePrc',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '매출금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'pkgProdSaleNo',
            fieldName: 'pkgProdSaleNo',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            header: {
                text: '판매관리번호',
                showTooltip: true,
            },
        },
        {
            name: 'pkgProdSaleChgSeq',
            fieldName: 'pkgProdSaleChgSeq',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            header: {
                text: '판매변경순번',
                showTooltip: true,
            },
            visible: false,
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            header: {
                text: '처리자',
                showTooltip: true,
            },
        },
        // {
        //     name: 'modDtm',
        //     fieldName: 'modDtm',
        //     type: 'data',
        //     width: '130',
        //     header: {
        //         text: '처리일시',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
        //     editable: false,
        // },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '130',
            styleName: 'left-column',
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMddhhmmss',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99 99:99:99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}
