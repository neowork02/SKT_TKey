import { ValueType } from 'realgrid'

export const GRIDHEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT, // 선택
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, // 불량여부
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT, // 재고상태코드
        },
        {
            fieldName: 'disAmt',
            dataType: ValueType.NUMBER, // 재고금액
        },
        {
            fieldName: 'fDisAmt',
            dataType: ValueType.NUMBER, // 개별원가
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT, // 제조사코드
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, // 제조사명
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, // 상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
        {
            fieldName: 'salePrc',
            dataType: ValueType.NUMBER, // 판매단가
        },
        {
            fieldName: 'fixUnitSalePrc',
            dataType: ValueType.NUMBER, // 확정판매단가
        },
        {
            fieldName: 'realPrchsPrc',
            dataType: ValueType.NUMBER, // 실제매입가격
        },
        {
            fieldName: 'fixCrdtPrchsPrc',
            dataType: ValueType.NUMBER, // 확정여신매입가격
        },
        {
            fieldName: 'barCd',
            dataType: ValueType.TEXT, // 바코드
        },
        {
            fieldName: 'fixYn',
            dataType: ValueType.TEXT, // 확정여부
        },
        {
            fieldName: 'editFlag',
            dataType: ValueType.TEXT, // 편집상태
        },
        {
            fieldName: 'prodCdSerNum',
            dataType: ValueType.TEXT, // 상품코드+일련번호
        },
        {
            fieldName: 'saleTypCd',
            dataType: ValueType.TEXT, // 판매유형코드
        },
        {
            fieldName: 'giveMthdCd',
            dataType: ValueType.TEXT, // 인도방식코드
        },
        {
            fieldName: 'saleUprc',
            dataType: ValueType.NUMBER, // 판매단가
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '120',
            header: {
                text: '상품구분',
                showTooltip: true,
            },
            editable: false,
        },
        {
            name: 'mfactCd',
            fieldName: 'mfactCd',
            type: 'data',
            width: '100',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                let prodClCd = grid.getValue(
                    dataCell.index.itemIndex,
                    'prodClCd'
                )
                let editFlag = grid.getValue(
                    dataCell.index.itemIndex,
                    'editFlag'
                )

                if (prodClCd !== '9' || editFlag === '2') {
                    ret.editor = {
                        type: 'text',
                    }
                    ret.editable = false
                } else {
                    ret.editor = {
                        type: 'dropdown',
                    }
                    ret.editable = true
                }
                return ret
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            header: {
                text: '모델',
                showTooltip: true,
            },
            editable: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            header: {
                text: '색상',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                let prodClCd = grid.getValue(
                    dataCell.index.itemIndex,
                    'prodClCd'
                )
                let editFlag = grid.getValue(
                    dataCell.index.itemIndex,
                    'editFlag'
                )
                if (prodClCd !== '9' || editFlag === '2') {
                    ret.editor = {
                        type: 'text',
                    }
                    ret.editable = false
                } else {
                    ret.editor = {
                        type: 'dropdown',
                    }
                    ret.editable = true
                }
                return ret
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '120',
            header: {
                text: '일련번호',
                showTooltip: true,
            },
            editable: false,
        },
        {
            name: 'barCd',
            fieldName: 'barCd',
            type: 'data',
            width: '120',
            header: {
                text: '바코드',
            },
            renderer: {
                showTooltip: true,
            },
            editable: true,
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            type: 'data',
            width: '100',
            header: {
                text: '불량여부',
                showTooltip: false,
            },
            editable: false,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'disStCd',
            fieldName: 'disStCd',
            type: 'data',
            width: '100',
            header: {
                text: '재고상태',
                showTooltip: false,
            },
            editable: false,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'salePrc',
            fieldName: 'salePrc',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '판매단가',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
            },
            numberFormat: '#,##0',
            editable: false,
        },
    ],
}
