import { ValueType } from 'realgrid'

export const ODER_INFO_GRID_HEADER = {
    fields: [
        {
            fieldName: 'brwsClNm',
            dataType: ValueType.TEXT, // 조회구분명
        },
        {
            fieldName: 'ordOpStNm',
            dataType: ValueType.TEXT, // 주문처리상태명
        },
        {
            fieldName: 'shipStNm',
            dataType: ValueType.TEXT, // 배송상태명
        },
        {
            fieldName: 'ordProdStNm',
            dataType: ValueType.TEXT, // 주문진행상태명
        },
        {
            fieldName: 'eqpExpartTypNm',
            dataType: ValueType.TEXT, // 단말기교품유형명
        },
        {
            fieldName: 'ordMgmtNo',
            dataType: ValueType.TEXT, // 주문관리번호
        },
        {
            fieldName: 'ordRcvDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 주문접수일시
        },
        {
            fieldName: 'ordId',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'svcClCd',
            dataType: ValueType.TEXT, // 개통구분코드
        },
        {
            fieldName: 'svcClNm',
            dataType: ValueType.TEXT, // 개통구분명
        },
        {
            fieldName: 'saleClNm',
            dataType: ValueType.TEXT, // 판매구분명
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'salePlcCd',
            dataType: ValueType.TEXT, // 판매처코드
        },
        {
            fieldName: 'salePlcNm',
            dataType: ValueType.TEXT, // 판매처명
        },
        {
            fieldName: 'sktAgnCd',
            dataType: ValueType.TEXT, // SKT대리점코드
        },
        {
            fieldName: 'sktAgnNm',
            dataType: ValueType.TEXT, // SKT대리점명
        },
        {
            fieldName: 'saleChnlNm',
            dataType: ValueType.TEXT, // 영업채널명
        },
        {
            fieldName: 'saleAprvNo',
            dataType: ValueType.TEXT, // 영업승인번호
        },
        {
            fieldName: 'pkgNo',
            dataType: ValueType.TEXT, // 패키지번호
        },
        {
            fieldName: 'dlvClNm',
            dataType: ValueType.TEXT, // 배송구분명
        },
        {
            fieldName: 'dlvCoNm',
            dataType: ValueType.TEXT, // 배송사명
        },
        {
            fieldName: 'waybillNo',
            dataType: ValueType.TEXT, // 송장번호
        },
        {
            fieldName: 'ordMthdNm',
            dataType: ValueType.TEXT, // 주문방식명
        },
        {
            fieldName: 'ordSpmallNm',
            dataType: ValueType.TEXT, // 주문쇼핑몰명
        },
        {
            fieldName: 'oprUserId',
            dataType: ValueType.TEXT, // 처리사용자ID
        },
        {
            fieldName: 'oprUserNm',
            dataType: ValueType.TEXT, // 처리사용자명
        },
        {
            fieldName: 'opDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMddhhmmss', // 처리일시
        },
    ],
    columns: [
        {
            name: 'brwsClNm',
            fieldName: 'brwsClNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '구분',
            },
        },
        {
            name: 'ordOpStNm',
            fieldName: 'ordOpStNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문처리상태',
            },
        },
        {
            name: 'shipStNm',
            fieldName: 'shipStNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '배송상태',
            },
        },
        {
            name: 'ordProdStNm',
            fieldName: 'ordProdStNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문진행상태',
            },
        },
        {
            name: 'eqpExpartTypNm',
            fieldName: 'eqpExpartTypNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '단말기교품유형',
            },
        },
        {
            name: 'ordMgmtNo',
            fieldName: 'ordMgmtNo',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문관리번호',
            },
        },
        {
            name: 'ordRcvDtm',
            fieldName: 'ordRcvDtm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문일자',
            },
        },
        {
            name: 'ordId',
            fieldName: 'ordId',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문번호',
            },
        },
        {
            name: 'svcClNm',
            fieldName: 'svcClNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '개통구분',
            },
        },
        {
            name: 'saleClNm',
            fieldName: 'saleClNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매구분',
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '조직',
            },
        },
        {
            name: 'salePlcCd',
            fieldName: 'salePlcCd',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매처코드',
            },
        },
        {
            name: 'salePlcNm',
            fieldName: 'salePlcNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '판매처',
            },
        },
        {
            name: 'sktAgnCd',
            fieldName: 'sktAgnCd',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '대리점코드',
            },
        },
        {
            name: 'sktAgnNm',
            fieldName: 'sktAgnNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '대리점',
            },
        },
        {
            name: 'saleChnlNm',
            fieldName: 'saleChnlNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '영업채널',
            },
        },
        {
            name: 'saleAprvNo',
            fieldName: 'saleAprvNo',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '영업승인번호',
            },
        },
        {
            name: 'pkgNo',
            fieldName: 'pkgNo',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '패키지번호',
            },
        },
        {
            name: 'dlvClNm',
            fieldName: 'dlvClNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '배송구분',
            },
        },
        {
            name: 'dlvCoNm',
            fieldName: 'dlvCoNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '배송사',
            },
        },
        {
            name: 'waybillNo',
            fieldName: 'waybillNo',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '송장번호',
            },
        },
        {
            name: 'ordMthdNm',
            fieldName: 'ordMthdNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문방식',
            },
        },
        {
            name: 'ordSpmallNm',
            fieldName: 'ordSpmallNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문쇼핑몰',
            },
        },
        {
            name: 'oprUserId',
            fieldName: 'oprUserId',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'oprUserNm',
            fieldName: 'oprUserNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '처리자',
            },
        },
        {
            name: 'opDtm',
            fieldName: 'opDtm',
            type: 'data',
            width: '120',
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '처리일시',
            },
        },
    ],
}

export const PROD_INFO_GRID_HEADER = {
    fields: [
        {
            fieldName: 'NO',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'ordMgmtNo',
            dataType: ValueType.TEXT, // 주문관리번호
        },
        {
            fieldName: 'ordStSeq',
            dataType: ValueType.TEXT, // 주문상태순번
        },
        {
            fieldName: 'ordProdTypCd',
            dataType: ValueType.TEXT, // 주문상품유형코드
        },
        {
            fieldName: 'ordProdSeq',
            dataType: ValueType.TEXT, // 주문상품순번
        },
        {
            fieldName: 'scanStNm',
            dataType: ValueType.TEXT, // 스캔상태명
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'boxNum1',
            dataType: ValueType.TEXT, // 박스번호1
        },
        {
            fieldName: 'boxNum2',
            dataType: ValueType.TEXT, // 박스번호2
        },
        {
            fieldName: 'serNumMatchDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 일련번호매칭일자
        },
        {
            fieldName: 'outPlcCd',
            dataType: ValueType.TEXT, // 출고처코드
        },
        {
            fieldName: 'outPlcNm',
            dataType: ValueType.TEXT, // 출고처명
        },
        {
            fieldName: 'openYn',
            dataType: ValueType.TEXT, // 개봉여부
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, // 일반판매번호
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.NUMBER, // 일반판매변경순번
        },
        {
            fieldName: 'ordOpStCd',
            dataType: ValueType.TEXT, // 주문처리상태코드
        },
        {
            fieldName: 'ordOpStNm',
            dataType: ValueType.TEXT, // 주문처리상태명
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'NO',
            type: 'data',
            width: '40',
            styleName: 'center-column',
            numberFormat: '##0',
            header: {
                text: 'No',
            },
            editor: {
                textReadOnly: false,
            },
        },
        {
            name: 'scanStNm',
            fieldName: 'scanStNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '스캔상태',
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '상품모델',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'boxNum1',
            fieldName: 'boxNum1',
            type: 'data',
            width: '40',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX1',
            },
        },
        {
            name: 'boxNum2',
            fieldName: 'boxNum2',
            type: 'data',
            width: '40',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX2',
            },
        },
        {
            name: 'serNumMatchDt',
            fieldName: 'serNumMatchDt',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '일련번호매칭일',
            },
        },
        {
            name: 'outPlcCd',
            fieldName: 'outPlcCd',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '출고처코드',
            },
        },
        {
            name: 'outPlcNm',
            fieldName: 'outPlcNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '출고처',
            },
        },
        {
            name: 'openYn',
            fieldName: 'openYn',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '개통여부',
            },
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매번호',
            },
        },
        {
            name: 'gnrlSaleChgSeq',
            fieldName: 'gnrlSaleChgSeq',
            type: 'data',
            width: '120',
            styleName: 'center-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매변경순번',
            },
        },
    ],
}
