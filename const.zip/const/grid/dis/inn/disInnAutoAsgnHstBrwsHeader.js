import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'asgnClCd',
            dataType: ValueType.TEXT, //배정구분코드
        },
        {
            fieldName: 'asgnClNm',
            dataType: ValueType.TEXT, //배정구분명
        },
        {
            fieldName: 'reqStCd',
            dataType: ValueType.TEXT, //요청상태코드
        },
        {
            fieldName: 'reqStNm',
            dataType: ValueType.TEXT, //요청상태명
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT, //요청자명
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT, //요청일시
        },
        {
            fieldName: 'chkable',
            dataType: ValueType.TEXT, //
        },
    ],
    columns: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점',
                showTooltip: false,
            },
        },
        {
            name: 'asgnClCd',
            fieldName: 'asgnClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정구분코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'asgnClNm',
            fieldName: 'asgnClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정구분',
                showTooltip: false,
            },
        },
        {
            name: 'reqStCd',
            fieldName: 'reqStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청상태코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'reqStNm',
            fieldName: 'reqStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청상태',
                showTooltip: false,
            },
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청자명',
                showTooltip: false,
            },
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청일시',
                showTooltip: false,
            },
        },
    ],
}
