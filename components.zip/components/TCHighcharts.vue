<!-----------------------------------------------
 * 업무그룹명: highchart 컴포넌트
 * 서브업무명: highchart 공통함수
 * 설명: highchart 컴포넌트및 공통함수 
 * 작성자: 이창석
 * 작성일: 2022.05.26
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <highcharts ref="highcharts" :options="chartOptions" />
</template>

<script>
import Vue from 'vue'
import { Chart } from 'highcharts-vue'
Vue.use(Chart)

export default {
    name: 'TCHighcharts',
    props: {
        chartKey: {
            type: Array,
            default: () => [],
        },
        chartText: {
            type: String,
            default: '',
        },
        chartShowInLegend: { type: Boolean, default: false, required: false },
        chartData: {
            type: Array,
            default: () => [],
        },
        chartColors: {
            type: Array,
            default: () => [],
        },
    },
    components: {
        highcharts: Chart,
    },
    data() {
        return {
            chartOptions: {},
        }
    },
    created() {},
    mounted() {
        this.chartOptions = {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: 0,
                plotShadow: false,
                type: 'pie',
                height: 100 + '%',
            },
            colors: this.fnChartColors,
            title: {
                text: this.chartText,
                align: 'center',
                verticalAlign: 'middle',
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
            },
            accessibility: {
                point: {
                    valueSuffix: '%',
                },
            },
            plotOptions: {
                pie: {
                    innerSize: '50%',
                    allowPointSelect: true /*하단 표시옵션*/,
                    cursor: 'pointer',
                    dataLabels: {
                        format: '<b>{point.name}</b><br>{point.percentage:.1f} %',
                        distance: -30,
                        filter: {
                            property: 'percentage',
                            operator: '>',
                            value: 1,
                        },
                        style: {
                            fontWeight: 'bold',
                            color: 'white',
                        },
                    },

                    showInLegend: this.chartShowInLegend,
                },
            },
            series: [
                {
                    type: 'pie',
                    innerSize: '50%',
                    name: '%',
                    colorByPoint: true,
                    data: this.fnCodeChange,
                },
            ],
        }
    },
    methods: {
        fnNewChartColors: function (chartData) {
            let resultArray = []
            //기본제공컬러 5개이상은 고정컬러로 노출
            let basicColor = [
                '#675CF9',
                '#FF5B6A',
                '#FFDF6D',
                '#6EBBFF',
                '#FF3739',
            ]

            for (let i = 0; i < chartData.length; i++) {
                //지정컬러보다 아이템이 많을경우 고정컬러로 변경 5개이상 대비
                if (basicColor[i] == undefined) {
                    resultArray[i] = '#4572A7'
                } else {
                    resultArray[i] = basicColor[i]
                }
            }
            //사용자 차트컬러 입력시 해당 차트컬러사용 없을경우 지정공식차트컬러사용
            if (this.chartColors.length > 0) {
                return this.chartColors
            } else {
                return resultArray
            }
        },
        fnCodeNmChange: function (chartData) {
            if (this.chartKey.length != 2) {
                alert(
                    '개발자메세지 : chartKey를 name, percent 순으로 입력하세요. '
                )
                return
            }

            let resultArray = []
            for (let i = 0; i < chartData.length; i++) {
                let keyName = eval('this.chartData[i].' + this.chartKey[0])
                let keyPercent = eval('this.chartData[i].' + this.chartKey[1])

                //console.log(keyName)
                //console.log(keyPercent)
                resultArray[i] = {
                    name: keyName,
                    y: keyPercent,
                }
            }
            return resultArray
        },
    },
    computed: {
        //컬러가 없을경우 기본컬러값으로 변경한다.
        fnChartColors: function () {
            if (this.chartData == undefined) {
                return
            }
            return this.fnNewChartColors(this.chartData)
        },
        //키값변경 -> 하이차트키값(name,y)으로 변경한다.(itemName -> name, itemPercent-> y)
        fnCodeChange: function () {
            if (this.chartData == undefined) {
                return
            }
            return this.fnCodeNmChange(this.chartData)
        },
    },
}
</script>
