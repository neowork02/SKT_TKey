import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('bas.odm.ondemandOperBrwsStore', Object.keys(state)),
    ...mapGetters('bas.odm.ondemandOperBrwsStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('bas.odm.ondemandOperBrwsStore', Object.keys(actions)),
    ...mapMutations('bas.odm.ondemandOperBrwsStore', Object.keys(mutations)),
}
