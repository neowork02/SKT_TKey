<template lang="">
    <div class="gridWrap">
        <TCRealGridHeader
            id="docMgmtGridHeader2"
            ref="docMgmtGridHeader2"
            gridTitle="목록"
            :gridObj="gridObj"
            :isPageRows="true"
            :isExceldown="false"
            :isNextPage="false"
            :isPageCnt="false"
            :editable="true"
            :isAddRow="false"
            :isDelRow="false"
            :addData="this.addData"
            @excelDownBtn="excelDownBtn"
            @addRowBtn="this.gridAddRowBtn"
            @chkDelRowBtn="this.gridchkDelRowBtn"
        >
            <template #gridBtnArea>
                <!--유통DT팀 또는 MNO IT개발팀 만 사용 -->
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_approval"
                    labelName="승  인"
                    @click="approvePopup"
                />
                <!--유통DT팀 또는 MNO IT개발팀 또는 TDCS운영팀 만 사용 -->
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_basic"
                    labelName="반  려"
                    @click="rejectPopup"
                />
                <!--TDCS운영팀 만 사용 -->
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_basic"
                    labelName="개발진행"
                    @click="devProgressPopup"
                />
                <!-- <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_exeldown"
                    labelName="다운로드"
                    @click="excelDetailDownBtn"
                /> -->
            </template>
        </TCRealGridHeader>
        <TCRealGrid
            id="docMgmtGrid2"
            ref="docMgmtGrid2"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
        <!-- <TCComPaging
            :totalPage="paging1.totalPageCnt"
            :apiFunc="pageMove"
            :rowCnt="paging1.pageSize"
            @input="pageSizeChange"
        /> -->
        <Detail1Popup
            v-if="showPopup1"
            :parentParam="searchPopup1"
            :rows="resultPopup1Rows"
            :dialogShow.sync="showPopup1"
            @confirm="onPopup1ReturnData"
        />
        <Detail2Popup
            v-if="showPopup2"
            :parentParam="searchPopup2"
            :rows="resultPopup2Rows"
            :dialogShow.sync="showPopup2"
            @confirm="onPopup2ReturnData"
        />
        <Detail3Popup
            v-if="showPopup3"
            :parentParam="searchPopup3"
            :rows="resultPopup3Rows"
            :dialogShow.sync="showPopup3"
            @confirm="onPopup3ReturnData"
        />
        <Detail4Popup
            v-if="showPopup4"
            :parentParam="searchPopup4"
            :rows="resultPopup4Rows"
            :dialogShow.sync="showPopup4"
            @confirm="onPopup4ReturnData"
        />
        <Detail0Popup
            v-if="showPopup0"
            :parentParam="searchPopup0"
            :rows="resultPopup0Rows"
            :dialogShow.sync="showPopup0"
            @confirm="onPopup0ReturnData"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/docMgmt/helpers'
import { GRID_HEADER } from '@/const/grid/bas/req/basReqDocMgmtHeader'
import { CommonGrid } from '@/utils'
import CommonMsg from '@/utils/CommonMsg'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
// eslint-disable-next-line no-unused-vars
import attachedFileApi from '@/api/common/attachedFile'
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
//====================팝업1 팝업====================
import Detail1Popup from './Detail1Popup'
import Detail2Popup from './Detail2Popup'
import Detail3Popup from './Detail3Popup'
import Detail4Popup from './Detail4Popup'
//====================//팝업1 팝업====================
//====================//팝업0 팝업====================
import Detail0Popup from '@/views/biz/bas/req/docRgst/BasReqDocRgst.vue'
//====================//팝업0 팝업====================
import CommonMixin from '@/mixins'
export default {
    mixins: [CommonMixin],
    components: {
        Detail1Popup,
        Detail2Popup,
        Detail3Popup,
        Detail4Popup,
        Detail0Popup,
    },
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '380px', //그리드 높이 조절
            },
            view: GRID_HEADER,
            layout: [
                'NO', //순번을 위한 가상컬럼
            ],
            /** 2. Grid 표현 영역 */
            gridDetailLayout: [
                //'chk',
                'NO', //순번을 위한 가상컬럼
                'reqDt', //요청일자
                //'uuid', //uuid
                'reqClCd', //요청구분
                //'itDocNo', //IT지원요청서
                'reqStNm', //진행상태
                'reqTitle', //요건명
                //'reqDtl', //요건상세
                //'reqUserNm', //요청자명
                'reqUserNmMsk',
                'reqUserId', //요청자
                //'reqOrgCd', //요청자조직
                //'reqUserEmail', //요청자메일
                //'devClCd', //개발담당자
                //'expEndDt', //완료예상일자
                //'reqDocId', //요구사항첨부문서Id
                //'aprvOrgCd', //승인조직
                //'aprvDtl', //고려사항/제한조건
                //'aprvUserId', //승인자
                //'rejOrgCd', //반려조직
                //'rejDtl', //반려사유
                //'rejUserId', //반려자
                //'vrfSnro', //검증시나리오
                //'devTestYn', //1차테스트여부
                //'piTestYn', //2차테스트여부
                //'depSchdDt', //배포예정일자
                //'depDt', //배포완료일자

                //'reqOrgNm', //요청자조직명
                //'reqMblPhonNo', //요청자핸드폰번호
                //'aprvUserNm', //승인자명
                //'aprvOrgNm', //승인조직명
                //'rejUserNm', //반려자명
                //'rejOrgNm', //반려조직명
            ],
            addData: [],
            //행추가,수정시 필수 입력 컬럼
            requiredCols: [],
            popupRowIndex: '',
            //====================팝업1 팝업관련====================
            showPopup1: false, // 팝업1 팝업 오픈 여부
            searchPopup1: {},
            resultPopup1Rows: [], // 팝업1 팝업 오픈 여부
            //====================//팝업1 팝업관련==================
            //====================팝업2 팝업관련====================
            showPopup2: false, // 팝업2 팝업 오픈 여부
            searchPopup2: {},
            resultPopup2Rows: [], // 팝업2 팝업 오픈 여부
            //====================//팝업2 팝업관련==================
            //====================팝업3 팝업관련====================
            showPopup3: false, // 팝업3 팝업 오픈 여부
            searchPopup3: {},
            resultPopup3Rows: [], // 팝업3 팝업 오픈 여부
            //====================//팝업3 팝업관련==================
            //====================팝업4 팝업관련====================
            showPopup4: false, // 팝업4 팝업 오픈 여부
            searchPopup4: {},
            resultPopup4Rows: [], // 팝업4 팝업 오픈 여부
            //====================//팝업4 팝업관련==================
            //====================팝업0 팝업관련====================
            showPopup0: false, // 팝업0 팝업 오픈 여부
            searchPopup0: {},
            resultPopup0Rows: [], // 팝업0 팝업 오픈 여부
            //====================//팝업0 팝업관련==================
        }
    },
    async mounted() {
        //체크바
        // this.$refs.docMgmtGrid2.gridView.setCheckBar({
        //     visible: true,
        // })
        this.gridObj = this.$refs.docMgmtGrid2
        this.gridHeaderObj = this.$refs.docMgmtGridHeader2
        this.gridObj.gridView.setColumnLayout(this.gridDetailLayout)
        this.gridObj.gridView.setCopyOptions({
            singleMode: true,
            includeHeaderText: false,
        })

        /*
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         */
        //this.$refs.docMgmtGrid2.setGridState(true, true, true, false)
        //    this.gridObj.setGridState()
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(true, false, false, false)

        //체크바
        this.$refs.docMgmtGrid2.gridView.setCheckBar({
            visible: true,
        })
        this.$refs.docMgmtGrid2.gridView.checkBar.fieldName = 'chk'

        //편집가능
        this.$refs.docMgmtGrid2.gridView.setEditOptions({
            editable: true,
            updatable: true,
        })
        //컬럼 고정
        // this.gridObj.gridView.setFixedOptions({
        //     colCount: 7,
        // })

        //특정컬럼 속성변경
        //this.gridObj.gridView.columnByName('NO').visible = false
        this.gridObj.gridView.columnByName('NO').editable = false

        //컬럼 크기 자동
        this.$refs.docMgmtGrid2.gridView.displayOptions.fitStyle = 'even' //'none' //

        //this.gridObj.gridView.summaryMode = 'aggregate' //footer 합계 표시

        this.$refs.docMgmtGrid2.gridView.onCellDblClicked = (
            grid,
            clickData
        ) => {
            console.log('onCellDblClicked', clickData.dataRow)
            this.gridPopup(clickData.dataRow, clickData.column)
        }
        // this.$refs.docMgmtGrid2.gridView.onCellClicked = (grid, clickData) => {
        //     console.log('onCellClicked: ' + JSON.stringify(clickData))
        //     const col = clickData.column
        //     if (
        //         col == 'reqUserNm' ||
        //         col == 'reqUserId' ||
        //         col == 'reqUserNmMsk'
        //     ) {
        //         this.gridPopup(clickData.dataRow, clickData.column)
        //     }
        // }
    },
    computed: {
        ...serviceComputed,
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        popupOpenNew1: {
            get() {
                return this.popupOpenNew
            },
        },
    },
    methods: {
        ...serviceMethods,
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 9999, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
            this.gridObj.gridView.clearCurrent() //선택해제
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging',
                value: { ...this.paging, pageSize: pageSize },
            })
            if (this.paging1.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        excelDownBtn: function () {
            let par1 = {
                ..._.clone(this.searchParams),
                exDownloadName: `요건서관리_${moment(new Date()).format(
                    'YYYYMMDDHHmmss'
                )}`,
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/req/tpay-result-list-excel',
                par1
            )
        },
        excelDetailDownBtn: function () {
            let par1 = {
                ..._.clone(this.searchParams),
                exDownloadName: `요건서관리_상세_${moment(new Date()).format(
                    'YYYYMMDDHHmmss'
                )}`,
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/req/tpay-result-paging-list-excel',
                par1
            )
        },
        approvePopup() {
            //<!--유통DT팀 또는 MNO IT개발팀 만 사용 -->
            const chk1 = this.gridObj.dataProvider.getJsonRows().filter((x) => {
                return x['chk'] == 'true' && x['reqStNm'] == '요청'
            })
            console.log(
                'approve data',
                this.gridObj.dataProvider.getJsonRows(),
                chk1
            )
            if (chk1.length == 0) {
                this.showTcComAlert(
                    '승인 처리할 건을 선택하세요.<br/>([진행상태: 요청] 건 만 가능)'
                )
                return
            }

            let popPar1 = {
                chkList: chk1,
            }
            this.resultPopup1Rows = []
            this.showPopup1 = true
            this.searchPopup1 = popPar1 //TODO
            console.log('Popup2 param', this.searchPopup1)
        },
        rejectPopup() {
            //<!--유통DT팀 또는 MNO IT개발팀 또는 TDCS운영팀 만 사용 -->
            const chk1 = this.gridObj.dataProvider.getJsonRows().filter((x) => {
                return x['chk'] == 'true' && x['reqStNm'] == '요청'
            })
            console.log(
                'approve data',
                this.gridObj.dataProvider.getJsonRows(),
                chk1
            )
            if (chk1.length == 0) {
                this.showTcComAlert(
                    '반려 처리할 건을 선택하세요.<br/>([진행상태: 요청] 건 만 가능)'
                )
                return
            }

            let popPar1 = {
                chkList: chk1,
            }
            this.resultPopup2Rows = []
            this.showPopup2 = true
            this.searchPopup2 = popPar1 //TODO
            console.log('Popup2 param', this.searchPopup2)
        },
        devProgressPopup() {
            //<!--TDCS운영팀 만 사용 -->
            const chk1 = this.gridObj.dataProvider.getJsonRows().filter((x) => {
                return (
                    x['chk'] == 'true' &&
                    (x['reqStNm'] == '승인' || x['reqStNm'] == '반려')
                )
            })
            console.log(
                'devProgress data',
                this.gridObj.dataProvider.getJsonRows(),
                chk1
            )
            if (chk1.length == 0) {
                this.showTcComAlert(
                    '개발진행 처리할 건을 선택하세요.<br/>([진행상태: 승인/반려] 건 만 가능)'
                )
                return
            }

            let popPar1 = {
                readOnly: false, //readOnly1  //요건서 조회 true // 요건서 수정 false
                mode: 'dev', //'req', //요건서 수정 //dev : 요건서 수정(개발팀)
                reqDt: chk1[0].reqDt,
                uuid: chk1[0].uuid,
            }
            this.resultPopup0Rows = []
            this.searchPopup0 = popPar1
            this.showPopup0 = true
            console.log('Popup0 param', this.searchPopup0)
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            this.gridHeaderObj.setPageCount(this.paging)
        },
        gridAddRowBtn: function () {
            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            let focuscell = this.gridObj.gridView.getCurrent()
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
        },
        gridDelRowBtn: function () {
            // not used
            console.log('del current row')
            this.gridData.gridRows = this.gridHeaderObj.selDelRow()
        },
        gridchkDelRowBtn: function () {
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        // eslint-disable-next-line no-unused-vars
        async gridPopup(row, col, val) {
            const rowData1 = this.gridObj.dataProvider.getJsonRow(row)

            if (
                col == 'reqUserNm' ||
                col == 'reqUserId' ||
                col == 'reqUserNmMsk'
            ) {
                //사용자정보 팝업
                this.resultPopup4Rows = []
                this.popupRowIndex = row
                let popPar1 = {
                    ...rowData1,
                }
                this.searchPopup4 = popPar1
                this.showPopup4 = true
                console.log('gridPopup 4 ', popPar1)
            } else if (col == 'reqStNm') {
                if (rowData1['reqStNm'] == '요청') {
                    this.showTcComAlert(
                        '[진행상태: 요청] 건 은 조회할 승인/반려가 없습니다.'
                    )
                    return
                }
                //승인/반려 정보 팝업
                this.resultPopup1Rows = []
                this.popupRowIndex = row
                let popPar1 = {
                    ...rowData1,
                }
                this.searchPopup3 = popPar1
                this.showPopup3 = true
                console.log('gridPopup', popPar1)
            } else if (
                col == 'NO' ||
                col == 'reqTitle' ||
                col == 'reqClCd' ||
                col == 'reqDt'
            ) {
                //요청서 정보 팝업
                let readOnly1 = true
                let mode1 = 'req'
                if (
                    rowData1['reqStNm'] == '요청' &&
                    rowData1['reqUserId'] == this.userInfo.userId
                ) {
                    readOnly1 = false
                } else if (rowData1['reqStNm'] == '승인') {
                    //readOnly1 = false
                    //mode1 = 'dev'
                    readOnly1 = true
                }
                let popPar1 = {
                    readOnly: readOnly1, //readOnly1  //요건서 조회 true // 요건서 수정 false
                    mode: mode1, //'req', //요건서 수정 //dev : 요건서 수정(개발팀)
                    reqDt: rowData1.reqDt,
                    uuid: rowData1.uuid,
                }
                this.resultPopup0Rows = []
                this.searchPopup0 = popPar1
                this.showPopup0 = true
                console.log('Popup0 param', this.searchPopup0)
            }
        },
        // 팝업1 팝업 리턴 이벤트 처리
        async onPopup1ReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     retrunData.orgCd
            // )
            this.$emit('Refresh', '') //next paging api call
        },
        // 팝업2 팝업 리턴 이벤트 처리
        async onPopup2ReturnData(retrunData) {
            console.log('retrunData2: ', retrunData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     retrunData.orgCd
            // )
            this.$emit('Refresh', '') //next paging api call
        },
        // 팝업3 팝업 리턴 이벤트 처리
        async onPopup3ReturnData(retrunData) {
            console.log('retrunData3: ', retrunData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     retrunData.orgCd
            // )
            this.$emit('Refresh', '') //next paging api call
        },
        // 팝업4 팝업 리턴 이벤트 처리
        async onPopup4ReturnData(retrunData) {
            console.log('retrunData4: ', retrunData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     retrunData.orgCd
            // )
            this.$emit('Refresh', '') //next paging api call
        },
        // 팝업0 팝업 리턴 이벤트 처리
        async onPopup0ReturnData(retrunData) {
            console.log('retrunData0: ', retrunData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     retrunData.orgCd
            // )
            if (retrunData) this.$emit('Refresh', '') //next paging api call
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        resultList1(val, oldVal) {
            //console.log('resultList1 watched: ', val, oldVal, this.pageSize)
            this.gridObj.gridView.commit()
            this.gridObj.setRows(this.resultList1)

            //순번처리
            //let pageInfo = { ...this.paging1, type: 'paging' } //페이징의 경우
            let pageInfo = {} //페이징이 없는경우
            pageInfo.type = 'noPaging' //페이징이 없는경우
            pageInfo.totalDataCnt = this.resultList1.length //페이징이 없는경우

            this.gridObj.setGridIndicator(pageInfo, { sort: 'DESC' }) //역순으로 번호가 보임
            this.gridObj.gridView.clearCurrent() //선택해제
        },
        // eslint-disable-next-line no-unused-vars
        paging1(val, oldVal) {
            //console.log('paging1 watched: ', val)
            this.SetPaging()
        },
        // eslint-disable-next-line no-unused-vars
        popupOpenNew1(val, oldVal) {
            if (val) {
                console.log('popupOpenNew1')
                this.searchPopup0 = {} //추가
                this.showPopup0 = true
            }
        },
    },
}
</script>
