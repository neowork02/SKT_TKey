import { ValueType } from 'realgrid'

export const GRID_INFO_EQP = {
    fields: [
        {
            fieldName: 'eqpFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'eqpCd',
            fieldName: 'eqpCd',
            type: 'data',
            header: {
                text: '유형코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'eqpNm',
            fieldName: 'eqpNm',
            type: 'data',
            header: {
                text: '단말기유형명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_EQP_GEN = {
    fields: [
        {
            fieldName: 'eqpFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'eqpCd',
            fieldName: 'eqpCd',
            type: 'data',
            header: {
                text: '유형코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'eqpNm',
            fieldName: 'eqpNm',
            type: 'data',
            header: {
                text: '단말기유형명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}
