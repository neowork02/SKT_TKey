<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">거래상태변경</p>

                <div class="layerCont">
                    <div class="stitHead">
                        <h4 class="subTit">거래상태변경</h4>
                    </div>
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParam.dealcoCd"
                                    labelName="거래처코드"
                                    :disabled="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComCheckBox
                                    labelName="거래상태"
                                    id="comCheck1"
                                    ref="comCheck1"
                                    v-model="searchParam.dealStatus"
                                    :itemList="zbasC00120"
                                    @change="changeRsnCd"
                                    :filterFunc="filterRsnCd"
                                />
                            </div>
                        </div>
                    </div>

                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            @click="save"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="close"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="close"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/tDealcoMgmt/helpers'
import _ from 'lodash'

import CommonMixin from '@/mixins'

export default {
    name: 'DealStatusPopupContainer',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            objAuth: {},
            searchParam: { dealcoCd: '', hstSeq: '', dealStatus: [] },
            isChk: true,
        }
    },
    mounted() {},
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        initParam: {
            get() {
                return this.initParams
            },
        },
        zbasC00120: {
            get() {
                return this.ZBAS_C_00120 // 전자결재 진행여부
            },
        },
    },
    methods: {
        ...serviceMethods,
        changeRsnCd(items) {
            _.forEach(items, (data) => {
                if (_.isEqual(data, '1')) {
                    this.isChk = true
                    this.searchParam.dealStatus = []
                    this.searchParam.dealStatus[0] = '1'
                } else if (_.isEqual(data, '5')) {
                    this.isDealEndDt = false
                } else if (!_.isEqual(data, '1')) {
                    if (this.isChk) {
                        this.isChk = false
                        this.searchParam.dealStatus = []
                        this.searchParam.dealStatus[0] = data
                    }
                } else {
                    this.isChk = false
                }
            })
        },
        filterRsnCd(items) {
            if (!this.initParam.pIsNew) {
                return items.filter(
                    (item) => !_.isEqual(item['commCdVal'], '5')
                )
            } else if (this.initParam.pIsNew) {
                let data1 = items.filter(
                    (item) => !_.isEqual(item['commCdVal'], '5')
                )

                let data2 = Object.assign(
                    {},
                    items.filter((item) => _.isEqual(item['commCdVal'], '5'))
                )
                data1.push(data2[0])
                console.log('data1 -> ', data1)
                return data1
            } else {
                return items
            }
        },
        save() {
            this.showTcComConfirm('저장 하시겠습니까?').then((confirm) => {
                if (confirm) {
                    let params = {}
                    params['dealcoCd'] = this.searchParam.dealcoCd
                    params['hstSeq'] = this.searchParam.hstSeq

                    this.searchParam.dealStatus.forEach((item) => {
                        if (_.isEqual(item, '1')) {
                            params['normalYn'] = 'Y'
                        } else if (_.isEqual(item, '2')) {
                            params['payStopYn'] = 'Y'
                        } else if (_.isEqual(item, '3')) {
                            params['outStopYn'] = 'Y'
                        } else if (_.isEqual(item, '4')) {
                            params['saleStopYn'] = 'Y'
                        } else if (_.isEqual(item, '5')) {
                            params['dealEndYn'] = 'Y'
                        } else if (_.isEqual(item, '6')) {
                            params['sttlEndYn'] = 'Y'
                        } else if (_.isEqual(item, '7')) {
                            params['drwStopYn'] = 'Y'
                        }
                    })

                    params['normalYn'] = _.isEmpty(params['normalYn'])
                        ? 'N'
                        : params['normalYn']
                    params['payStopYn'] = _.isEmpty(params['payStopYn'])
                        ? 'N'
                        : params['payStopYn']
                    params['outStopYn'] = _.isEmpty(params['outStopYn'])
                        ? 'N'
                        : params['outStopYn']
                    params['saleStopYn'] = _.isEmpty(params['saleStopYn'])
                        ? 'N'
                        : params['saleStopYn']
                    params['dealEndYn'] = _.isEmpty(params['dealEndYn'])
                        ? 'N'
                        : params['dealEndYn']
                    params['sttlEndYn'] = _.isEmpty(params['sttlEndYn'])
                        ? 'N'
                        : params['sttlEndYn']
                    params['drwStopYn'] = _.isEmpty(params['drwStopYn'])
                        ? 'N'
                        : params['drwStopYn']

                    this.defaultAssign_({
                        key: 'dealStatusParam',
                        value: params,
                    })

                    // API 호출
                    this.updateMgmtDealStatus_()
                        .then((data) => {
                            if (data === 1) {
                                this.showTcComAlert('등록성공')

                                let dealcoStatus = {
                                    ...this.basPrmDealcoDtlListVo,
                                }

                                dealcoStatus['normalYn'] = params['normalYn']
                                dealcoStatus['payStopYn'] = params['payStopYn']
                                dealcoStatus['outStopYn'] = params['outStopYn']
                                dealcoStatus['saleStopYn'] =
                                    params['saleStopYn']
                                dealcoStatus['dealEndYn'] = params['dealEndYn']
                                dealcoStatus['sttlEndYn'] = params['sttlEndYn']
                                dealcoStatus['drwStopYn'] = params['drwStopYn']

                                this.defaultAssign_({
                                    key: 'basPrmDealcoDtlListVo',
                                    value: dealcoStatus,
                                })

                                this.close()
                            } else {
                                this.showTcComAlert('등록실패')
                            }
                        })
                        .catch((error) => {
                            Promise.reject(error)
                        })
                        .finally(() => {
                            console.log(
                                '🚀 ~ file: PopupContainer.vue ~ finally'
                            )
                        })
                } else {
                    this.close()
                }
            })
        },
        close() {
            this.activeOpen = false
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchParam.dealcoCd =
                    value['dealcoCd'] === undefined ? '' : value['dealcoCd']
                this.searchParam.normalYn =
                    value['normalYn'] === undefined ? [] : value['normalYn']
                this.searchParam.payStopYn =
                    value['payStopYn'] === undefined ? [] : value['payStopYn']
                this.searchParam.outStopYn =
                    value['outStopYn'] === undefined ? [] : value['outStopYn']
                this.searchParam.saleStopYn =
                    value['saleStopYn'] === undefined ? [] : value['saleStopYn']
                this.searchParam.dealEndYn =
                    value['dealEndYn'] === undefined ? [] : value['dealEndYn']
                this.searchParam.sttlEndYn =
                    value['sttlEndYn'] === undefined ? [] : value['sttlEndYn']
                this.searchParam.drwStopYn =
                    value['drwStopYn'] === undefined ? [] : value['drwStopYn']
                this.searchParam.hstSeq =
                    value['hstSeq'] === undefined ? [] : value['hstSeq']

                let normalYn = _.isEqual(this.searchParam.normalYn, 'Y')
                    ? '1'
                    : ''
                let payStopYn = _.isEqual(this.searchParam.payStopYn, 'Y')
                    ? '2'
                    : ''
                let outStopYn = _.isEqual(this.searchParam.outStopYn, 'Y')
                    ? '3'
                    : ''
                let saleStopYn = _.isEqual(this.searchParam.saleStopYn, 'Y')
                    ? '4'
                    : ''
                let dealEndYn = _.isEqual(this.searchParam.dealEndYn, 'Y')
                    ? '5'
                    : ''
                let sttlEndYn = _.isEqual(this.searchParam.sttlEndYn, 'Y')
                    ? '6'
                    : ''
                let drwStopYn = _.isEqual(this.searchParam.drwStopYn, 'Y')
                    ? '7'
                    : ''

                if (!_.isEmpty(normalYn)) {
                    this.searchParam.dealStatus.push(normalYn)
                }
                if (!_.isEmpty(payStopYn)) {
                    this.searchParam.dealStatus.push(payStopYn)
                }
                if (!_.isEmpty(outStopYn)) {
                    this.searchParam.dealStatus.push(outStopYn)
                }
                if (!_.isEmpty(saleStopYn)) {
                    this.searchParam.dealStatus.push(saleStopYn)
                }
                if (!_.isEmpty(dealEndYn)) {
                    this.searchParam.dealStatus.push(dealEndYn)
                }
                if (!_.isEmpty(sttlEndYn)) {
                    this.searchParam.dealStatus.push(sttlEndYn)
                }
                if (!_.isEmpty(drwStopYn)) {
                    this.searchParam.dealStatus.push(drwStopYn)
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
