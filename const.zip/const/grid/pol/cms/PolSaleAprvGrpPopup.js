import { ValueType } from 'realgrid'

export let GRID_INFO_GRP = {
    fields: [
        {
            fieldName: 'grpMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'grpMgmtNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'grpMgmtNo',
            fieldName: 'grpMgmtNo',
            type: 'data',
            width: '30',
            header: {
                text: '그룹번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'grpMgmtNm',
            fieldName: 'grpMgmtNm',
            type: 'data',
            header: {
                text: '그룹명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export let GRID_INFO_DTL = {
    fields: [
        {
            fieldName: 'saleAprvNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polClNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'saleAprvNo',
            fieldName: 'saleAprvNo',
            type: 'data',
            width: '30',
            header: {
                text: '영업승인번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleAprvNm',
            fieldName: 'saleAprvNm',
            type: 'data',
            header: {
                text: '영업승인명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'polClNm',
            fieldName: 'polClNm',
            type: 'data',
            width: '30',
            header: {
                text: '정책구분명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}
