import api from '@/api/biz/sal/smg/salSmgShSdSalePrst'
import types from './mutation-types'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    // // eslint-disable-next-line no-unused-vars
    // async getSalSmgShSdSalePrstDetails_({ state, commit }, { param }) {
    //     let resultData
    //     let searchParams = param
    //     console.log('🚀 ~ file: actions.js sub ~ auths', searchParams)
    //     await api
    //         .getSalSmgShSdSalePrstDetails_({ searchParams })
    //         .then((data) => {
    //             console.log(
    //                 '🚀 ~ getSalSmgShSdSalePrstDetails_ ~ .then ~ data',
    //                 data
    //             )
    //             resultData = data
    //         })
    //     return resultData
    // },
    async getSalSmgShSdSalePrstList_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum
        console.log(
            '🚀 ~ getSalSmgShSdSalePrstList_ ~ searchParams',
            searchParams
        )
        await api
            .getSalSmgShSdSalePrstList_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ getSalSmgShSdSalePrstList_ ~ .then ~ data',
                    data
                )
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: data.pagingDto,
                    })
                    let body = data.gridList
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: body,
                    })
                } else {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: state.initPaging,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: [],
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })
        const _sleep = (delay) =>
            new Promise((resolve) => setTimeout(resolve, delay))
        const timer = async () => {
            await _sleep(200)
        }
        await timer()

        return resultData
    },
    async getSalSmgShSdSalePrstList2_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum
        console.log(
            '🚀 ~ getSalSmgShSdSalePrstList2_ ~ searchParams',
            searchParams
        )
        await api
            .getSalSmgShSdSalePrstList2_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ getSalSmgShSdSalePrstList2_ ~ .then ~ data',
                    data
                )
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging2',
                        value: data.pagingDto,
                    })
                    let body = data.gridList
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList2',
                        value: body,
                    })
                } else {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging2',
                        value: state.initPaging,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList2',
                        value: [],
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })
        const _sleep = (delay) =>
            new Promise((resolve) => setTimeout(resolve, delay))
        const timer = async () => {
            await _sleep(200)
        }
        await timer()

        return resultData
    },
    async getSalSmgShSdSalePrstList3_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum
        console.log(
            '🚀 ~ getSalSmgShSdSalePrstList3_ searchParams',
            searchParams
        )
        await api
            .getSalSmgShSdSalePrstList3_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ getSalSmgShSdSalePrstList3_ ~ .then ~ data',
                    data
                )
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging3',
                        value: data.pagingDto,
                    })
                    let body = data.gridList
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList3',
                        value: body,
                    })
                } else {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging3',
                        value: state.initPaging,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList3',
                        value: [],
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })
        const _sleep = (delay) =>
            new Promise((resolve) => setTimeout(resolve, delay))
        const timer = async () => {
            await _sleep(200)
        }
        await timer()

        return resultData
    },
    // // eslint-disable-next-line no-unused-vars
    // async saveShSdSalePrst_({ state, commit }, { saveRows }) {
    //     console.log('🚀 ~ file: actions.js ~ line 128 ~ saveRows', saveRows)
    //     let result = 0
    //     await api
    //         .saveShSdSalePrst_(saveRows)
    //         .then((data) => {
    //             console.log(
    //                 '🚀 ~ file: actions.js ~ saveShSdSalePrst_~ .then ~ data',
    //                 data
    //             )
    //             result = data
    //         })
    //         .catch((error) => {
    //             throw error
    //         })
    //     // const _sleep = (delay) =>
    //     //     new Promise((resolve) => setTimeout(resolve, delay))
    //     // const timer = async () => {
    //     //     await _sleep(1000)
    //     // }
    //     // await timer()
    //     return result
    // },
}
