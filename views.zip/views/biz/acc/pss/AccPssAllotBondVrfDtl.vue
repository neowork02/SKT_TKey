<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1264px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">할부채권상세조회 세부내역</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                    <!-- // Top BTN -->
                    <div class="contBoth">
                        <div class="searchLayer_wrap">
                            <div class="searchform">
                                <div class="formitem div4">
                                    <TCComDatePicker
                                        labelName="기준월"
                                        calType="M"
                                        eClass="div2"
                                        v-model="searchFormData.accYm"
                                        :disabled="true"
                                    >
                                    </TCComDatePicker>
                                </div>

                                <div class="formitem div4">
                                    <TCComInput
                                        labelName="서비스관리번호"
                                        :disabled="true"
                                        v-model="searchFormData.svcMgmtNum"
                                        :disabledAfter="true"
                                    >
                                    </TCComInput>
                                </div>
                            </div>
                        </div>
                        <!-- //Search_div -->
                    </div>
                    <div class="gridWrap">
                        <!-- SubTit -->
                        <TCRealGridHeader
                            id="popupGridHeader"
                            ref="popupGridHeader"
                            gridTitle="Swing I/F"
                            :gridHeaderObj="gridHeaderObj"
                        >
                            <template #gridElementArea>
                                <button
                                    type="button"
                                    class="btn_noline btn_ty04"
                                    @click="exportExcelDown"
                                >
                                    <span class="ico_exeldown"
                                        >엑셀다운로드</span
                                    >
                                </button>
                            </template>
                        </TCRealGridHeader>
                        <TCRealGrid
                            id="popupGrid"
                            ref="popupGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                            :gridObj="gridObj"
                            :styles="gridStyle"
                        />
                    </div>
                    <div class="gridWrap">
                        <!-- SubTit -->
                        <TCRealGridHeader
                            id="popupGridHeader1"
                            ref="popupGridHeader1"
                            gridTitle="T.Key take 판매"
                            :gridHeaderObj="gridHeaderObj1"
                        />
                        <TCRealGrid
                            id="popupGrid1"
                            ref="popupGrid1"
                            :fields="view1.fields"
                            :columns="view1.columns"
                            :gridObj="gridObj1"
                            :styles="gridStyle1"
                            @hook:mounted="tabGridMounted"
                        />
                    </div>
                    <!-- //gridWrap -->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    GRID_HEADER_SWING,
    GRID_HEADER_TKEY,
} from '@/const/grid/acc/pss/AccPssAllotBondVrfDtlGrid'
import moment from 'moment'
import allotBondVrfRgstApi from '@/api/biz/acc/pss/accPssAllotBondVrfMgmt'
import _ from 'lodash'
import CommonMixin from '@/mixins'
export default {
    name: 'accPssEtcSaleAccRgst',
    mixins: [CommonMixin],
    props: {
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            //Paging Class init
            gridObj: {},
            gridObj1: {},
            gridHeaderObj: {},
            gridHeaderObj1: {},
            gridStyle: {
                height: '100px',
            },
            gridStyle1: {
                height: '300px',
            },

            objAuth: {},
            swingDtl: [],
            tkeyDtl: [],
            view: GRID_HEADER_SWING,
            view1: GRID_HEADER_TKEY,
            localPersistent: true,
            disabledBtnDel: true,

            searchFormData: {
                accYm: moment(new Date()).format('YYYY-MM'), // 정산월
                agencyCd: '',
                svcMgmtNum: '',
                items: [],
            },
        }
    },
    mounted() {
        this.searchFormData.agencyCd = this.popupParams.agencyCd
        this.searchFormData.accYm = this.popupParams.accMth
        this.searchFormData.svcMgmtNum = this.popupParams.svcMgmtNum

        /****************** Grid **********************/
        this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.popupGridHeader
        this.gridObj.setRows()

        this.gridObj.setGridState(false, false, false)
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: '번호',
        })

        this.fInit()

        /****************** Event **********************/
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        // 닫기
        closeBtn: function () {
            console.log('닫기')
            this.activeOpen = false
        },
        closeTopBtn: function () {
            console.log('닫기')
            this.activeOpen = false
        },
        fInit: function () {
            this.swingDtl = []
            this.swingDtl.push({
                svcMgmtNum: this.popupParams.svcMgmtNum,
                accYm: this.popupParams.accYm,
            })
            this.tkeyDtl = []
            this.tkeyDtl.push({
                svcMgmtNum: this.popupParams.svcMgmtNum,
                accYm: this.popupParams.accYm,
            })
            this.fSearch()
        },
        fSearch: function () {
            if (_.isEmpty(this.popupParams.agencyCd)) {
                return
            }
            this.swingDtl = []

            allotBondVrfRgstApi
                .getSwingDtlList(this.searchFormData)
                .then((resultData) => {
                    this.list = resultData.swingDtl
                    this.list1 = resultData.tkeyDtl
                    this.$refs.popupGrid.setRows(this.list)
                    this.$refs.popupGrid1.setRows(this.list1)
                    console.log('swingDtl::::', this.list)
                    console.log('tkeyDtl::::', this.list1)
                })
        },
        exportExcelDown: function () {
            for (var i = 0; i < 2; i++) {
                if (i == 0) {
                    //  Swing I/F 엑셀다운로드
                    allotBondVrfRgstApi.downAllotBondVrfDtlSwingExcel(
                        this.searchFormData
                    )
                } else {
                    //  Tkey 엑셀다운로드
                    allotBondVrfRgstApi.downAllotBondVrfDtlTkeyExcel(
                        this.searchFormData
                    )
                }
            }
        },
        tabGridMounted() {
            this.gridObj1 = this.$refs.popupGrid1
            this.gridHeaderObj1 = this.$refs.popupGridHeader1

            this.gridObj1.setRows()
            this.gridObj1.setGridState(false, false, false)
            this.gridObj1.gridView.setRowIndicator({
                visible: true,
                headText: '번호',
            })
        },
    },
}
</script>
