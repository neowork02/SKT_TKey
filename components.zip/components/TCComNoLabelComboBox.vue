<!-----------------------------------------------
 * 업무그룹명: ComboBox 컴포넌트 (No Label)
 * 서브업무명: ComboBox 공통함수 (No Label)
 * 설명: ComboBox 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.04.07
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <span :class="spanClass">
        <v-select
            v-if="!autocomplete"
            ref="combobox"
            :value="value"
            :dense="isDense"
            outlined
            color="basiccont"
            append-icon="mdi-chevron-down"
            :item-text="itemText"
            :item-value="itemValue"
            :label="label"
            :style="cStyle"
            :suffix="suffix"
            :items="cItemList"
            :readonly="readonly"
            :disabled="disabled"
            :rules="getRules"
            :return-object="false"
            :menu-props="{
                auto: true,
                bottom: true,
                offsetY: true,
            }"
            @change="emitChange"
            :class="eClass"
        ></v-select>
        <v-autocomplete
            v-else
            ref="combobox"
            :value="value"
            :dense="isDense"
            outlined
            color="basiccont"
            append-icon="mdi-chevron-down"
            :item-text="itemText"
            :item-value="itemValue"
            :label="label"
            :style="cStyle"
            :suffix="suffix"
            :items="cItemList"
            :readonly="readonly"
            :disabled="disabled"
            :rules="getRules"
            :return-object="false"
            @change="emitChange"
            :class="eClass"
        ></v-autocomplete>
    </span>
</template>

<script>
import commonApi from '@/api/common/prototype'
import _ from 'lodash'
export default {
    inheritAttrs: false,
    name: 'TCComNoLabelComboBox',
    components: {},
    props: {
        // 선택값
        value: { type: [String, Number, Object], required: false },
        // 컴포넌트 넓이
        size: { type: Number, default: null, required: false },
        // 타이틀값
        label: { type: String, default: '', required: false },
        //텍스트박스 명
        labelName: { type: String, default: '', required: false },
        // 접미사 텍스트 표시
        suffix: { type: String, required: false },
        // disabled
        disabled: { type: Boolean, default: false, required: false },
        // readonly
        readonly: { type: Boolean, default: false, required: false },
        //필수입력여부
        eRequired: { type: Boolean, default: false, required: false },
        // auth
        objAuth: { type: Object, default: () => {}, required: false },
        // 공통코드 유형 Id
        codeId: { type: String, default: '', required: false },
        // ITEM TEXT
        itemText: { type: String, default: 'commCdValNm', required: false },
        // ITEM VALUE
        itemValue: { type: String, default: 'commCdVal', required: false },
        // 목록 정보(codeId가 없을때만 적용)
        itemList: {
            type: Array,
            default: () => [],
            required: false,
        },
        // Blank Item 추가 여부
        addBlankItem: { type: Boolean, default: false, required: false },
        // Blank Item Text
        blankItemText: { type: String, default: '', required: false },
        // Blank Item Value
        blankItemValue: { type: String, default: '', required: false },
        // Sort By
        sortBy: { type: [String, Array], required: false },
        // Sort Order
        sortOrder: { type: String, default: 'asc', required: false },
        // 함수, 부울 및 문자열의 혼합 배열을 사용할 수 있습니다.
        // 함수는 입력값을 인수로 전달하며 true/false 또는 오류 메시지를 포함하는 문자열을 반환해야 합니다.
        // 함수가 false를 반환하거나(또는 배열의 모든 값에 포함됨) 문자열인 경우 입력 필드가 오류 상태가 됩니다.
        rules: { required: false },
        // autocomplete 여부
        autocomplete: { type: Boolean, default: false, required: false },
        // 사용자 정의 필터 함수 설정
        filterFunc: { type: Function, required: false },
        //CSS ComboBox Class
        eClass: { type: String, default: '', required: false },
        // span class
        spanClass: {
            type: String,
            default: 'iteminput-type2',
            required: false,
        },
        // dense 여부
        isDense: { type: Boolean, default: true, required: false },
    },
    data() {
        return {
            dCommItemList: [],
        }
    },
    computed: {
        cStyle() {
            let res = 'width:auto;'
            if (this.size != null) {
                res = 'width:' + this.size + '%;'
            }
            return res
        },
        cItemList() {
            let items = []
            if (!_.isEmpty(this.codeId)) {
                items = this.dCommItemList.slice()
            } else {
                items = this.itemList.slice()
            }
            if (!_.isEmpty(items)) {
                if (typeof this.filterFunc === 'function') {
                    items = this.filterFunc(items)
                }

                if (this.sortBy) {
                    items = _.sortBy(items, this.sortBy)
                    if (this.sortOrder !== 'asc') {
                        items.reverse()
                    }
                }

                if (this.addBlankItem) {
                    items.unshift({
                        [this.itemValue]: this.blankItemValue,
                        [this.itemText]: this.blankItemText,
                    })
                }
            }
            return items
        },
        getRules() {
            let rules = []
            if (this.rules) {
                rules = this.rules
            }
            return rules
        },
        getValueText() {
            let items = []
            if (!_.isEmpty(this.codeId)) {
                items = this.dCommItemList
            } else {
                items = this.itemList
            }
            return _.find(items, {
                [this.itemValue]: this.value,
            })?.[this.itemText]
        },
    },
    // props 동적 제어
    watch: {
        value: {
            handler: function () {
                this.emitInput(this.value)
            },
            deep: true,
            immediate: true,
        },
        codeId: function () {
            if (!_.isEmpty(this.codeId)) {
                this.getCommCodeList()
            }
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            // 코드 ID 존재시 공통코드 호출
            if (!_.isEmpty(this.codeId)) {
                this.getCommCodeList()
            }
        },
        // 공통코드 API
        getCommCodeList() {
            commonApi.getCommonCodeList(this.codeId).then((res) => {
                this.dCommItemList = res
            })
        },
        emitInput(value) {
            this.$emit('input', value)
        },
        emitChange(value) {
            this.emitInput(value)
            this.$emit('change', value)
        },
        inputFocus() {
            this.$refs.combobox.focus()
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
