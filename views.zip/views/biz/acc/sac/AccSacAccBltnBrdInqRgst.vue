<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="700px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">정산지원 상세보기</p>
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="제목"
                                    :eRequired="true"
                                    v-model="inputData.inqTitle"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="작성일시"
                                    :eRequired="true"
                                    :disabled="true"
                                    v-model="inputData.makeDtm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComComboBox
                                    codeId="ZACC_C_00210"
                                    labelName="문의유형"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :disabled="isAccQueTypCd"
                                    v-model="inputData.accQueTypCd"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div2">
                                <TCComComboBox
                                    codeId="ZACC_C_00220"
                                    labelName="문의세부"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :disabled="isAccQueDtlCd"
                                    v-model="inputData.accQueDtlCd"
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInputSearchText
                                    v-model="inputData.accDealcoNm"
                                    :codeVal.sync="inputData.accDealcoCd"
                                    labelName="정산처"
                                    :objAuth="objAuth"
                                    :disabled="isAccDealcoCd"
                                    :searchIconDisabled="searchIconDisabled"
                                    :disabledAfter="true"
                                    @appendIconClick="onDealcoIconClick"
                                    @enterKey="onDealcoEnterKey"
                                    @input="onDealcoInput"
                                />
                                <BasBcoDealcosPopup
                                    v-if="basBcoDealcoShow"
                                    :parentParam="searchAccDealcoParams"
                                    :dialogShow.sync="basBcoDealcoShow"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div1">
                                <div class="arrayType">
                                    <div class="col0">
                                        <TCComRadioBox
                                            v-model="inputData.inqPwdNoYn"
                                            :itemList="itemList2"
                                            labelName="비밀번호설정"
                                            @change="inqPwdNoYnChange"
                                        />
                                    </div>
                                    <div class="col0">
                                        <TCComNoLabelInput
                                            style="w100"
                                            v-model="inputData.inqPwdNum"
                                            :type="inqPwdNoInputType"
                                            :disabled="isInqPwdNo"
                                            :inputRuleType="
                                                CONSTANTS.INPUTRULE_NUM
                                            "
                                            :maxlength="4"
                                        />
                                    </div>
                                    <div class="col0">
                                        <TCComCheckBox
                                            v-model="inputData.inqPwdNoDisplay"
                                            :itemList="[
                                                {
                                                    commCdVal: 'Y',
                                                    commCdValNm: '비밀번호표시',
                                                },
                                            ]"
                                            @change="inqPwdNoDisplay"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div1">
                                <div class="arrayType">
                                    <div class="col0">
                                        <div class="col0">
                                            <TCComRadioBox
                                                v-model="inputData.noticYn"
                                                :itemList="itemList2"
                                                labelName="공지사항여부"
                                                :eRequired="false"
                                                :disabled="isNotic"
                                                @change="noticYnChange"
                                            />
                                        </div>
                                    </div>
                                    <div class="col0">
                                        <TCComDatePicker
                                            calType="DP"
                                            v-model="searchYmd"
                                            labelName=""
                                            :disabled="isNotic"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="inputData.inqCtt"
                                    labelName="내용"
                                    class="boxtype"
                                    :eRequired="true"
                                    :rows="8"
                                />
                            </div>
                        </div>
                    </div>

                    <!-- 파일첨부 그리드 -->
                    <AttachedFileAdd
                        ref="attachedFileAdd"
                        :fileList="fileSearchList"
                        @file-change="onFileAddChange"
                        gridHeight="100px"
                    ></AttachedFileAdd>

                    <!-- <div class="btn_area_bottom">
                        <div class="left">
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                :disabled="isAnswRgstBtn"
                                @click="answRgstPopOpen"
                                >답변등록</TCComButton
                            >
                        </div>

                        <div class="right">
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                :disabled="isRgstBtn"
                                @click="saveInqRgst"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onClose"
                                >목록</TCComButton
                            >
                        </div>
                    </div> -->
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom type2">
                        <div class="left">
                            <TCComButton
                                eClass="btn_ty02"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="answRgstPopOpen"
                                :disabled="isAnswRgstBtn"
                                >답변등록</TCComButton
                            >
                        </div>
                        <div class="right">
                            <TCComButton
                                eClass="btn_ty02"
                                :eLarge="true"
                                :objAuth="objAuth"
                                :disabled="isRgstBtn"
                                @click="saveInqRgst"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :eLarge="true"
                                :objAuth="objAuth"
                                @click="onClose"
                                >목록</TCComButton
                            >
                        </div>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>

            <!-- 답변등록 팝업 -->
            <answRgstPopup
                v-if="answShowPopupOrg === true"
                ref="answPopup"
                :dialogShow.sync="answShowPopupOrg"
                :popupParams="popupAnswParams"
                @close="onClose"
            />
        </template>
    </TCComDialog>
</template>

<style lang="scss" scoped></style>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import _ from 'lodash'
import moment from 'moment'
import AttachedFileAdd from '@/components/common/AttachedFileAdd'
import boardApi from '@/api/biz/acc/sac/AccSacAccBltnBrdApi'
import answRgstPopup from '@/views/biz/acc/sac/AccSacAccBltnBrdAnswRgst'

//  내부거래처(권한조직)
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//  내부거래처(권한조직)

export default {
    name: 'AccSacAccBltnBrdInqRgst',
    mixins: [CommonMixin],
    components: {
        AttachedFileAdd, //  파일첨부
        BasBcoDealcosPopup, //  내부거래처(권한조직)
        answRgstPopup,
    },
    props: {
        //parmas
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            objAuth: {},

            searchYmd: [],
            dateType: 'DP',
            itemList2: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],

            //  파일첨부
            admAppendFileList: [],
            formData: new FormData(),
            fileSearchList: [],

            //  Disable여부
            isInqPwdNo: false, //  비밀번호
            isNotic: false, //  공지사항
            isAnswRgstBtn: false, //  답변등록버튼
            isRgstBtn: false, //  저장버튼
            isAccDealcoCd: false, //  정산처
            searchIconDisabled: false, // 정산처 돋보기버튼
            isAccQueTypCd: false, //  문의유형
            isAccQueDtlCd: false, //  문의세부

            inqPwdNoInputType: 'password',

            //  내부거래처(권한조직)
            basBcoDealcoShow: false,
            resultDealcoRows: [],
            searchAccDealcoParams: {
                basDay: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                dealcoCd: '',
                dealcoNm: '',
            },
            //  내부거래처(권한조직)

            //  답변등록팝업
            answShowPopupOrg: false,
            popupAnswParams: {},

            inputData: {
                accDealcoCd: '',
                accDealcoNm: '',
                accProcStCd: '',
                accQueDtlCd: '',
                accQueTypCd: '',
                accYm: moment(new Date()).format('YYYYMM'),
                boardLvl: '',
                boardNo: '',
                docId: '',
                inqCtt: '',
                inqPwdNum: '',
                inqPwdNoYn: 'N',
                inqTitle: '',
                makeDtm: '',
                maxBoardLvl: '',
                maxBoardNo: '',
                modUserId: '',
                noticEndDt: '',
                noticFromDt: '',
                noticYn: 'N',
                orgCd: '',
                screenId: 'AccSacAccBltnBrd',
            },
            attachFileData: {
                boardNo: '',
                docId: '',
            },
            backupData: {
                accQueTypCd: '',
                accQueDtlCd: '',
                accDealcoCd: '',
                accDealcoNm: '',
            },
        }
    },
    mounted() {
        //  화면 초기 셋팅
        this.getBase()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        //  초기값 셋팅
        getBase: function () {
            //  저장권한이 있을 경우 공지사항 및 저장버튼 활성화
            // let saveAuthYn = CommonUtil.getObjAuth(this.$route.path, '저장')
            // if (saveAuthYn == 'Y') {
            //     this.isRgstBtn = false
            //     this.isNotic = false
            // }
            if (this.popupParams.newOpenYn == 'Y') {
                //  신규(메인화면에서 신규버튼으로 오픈)

                //  작성일시, 답변등록버튼 Disable
                this.inputData.makeDtm = moment(new Date()).format(
                    'YYYY-MM-DD HH:mm:ss'
                )

                this.isAnswRgstBtn = true
            } else {
                //  기존(메인화면에서 Row더블클릭으로 오픈)
                this.isAnswRgstBtn = false

                // 조회
                this.loadData()
            }

            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.inputData.accDealcoCd = this.userInfo.dealcoCd
                this.inputData.accDealcoNm = this.userInfo.dealcoNm

                this.isNotic = true //  공지사항
                this.isAccDealcoCd = true //  정산처
                this.searchIconDisabled = false
            } else {
                this.isNotic = false //  공지사항
                this.isAccDealcoCd = false //  정산처
            }
        },
        loadData() {
            //  조회API 호출
            boardApi
                .getBoardInqRgstList(this.popupParams)
                .then((resultData) => {
                    this.inputData = resultData

                    if (
                        !_.isEmpty(this.inputData.noticFromDt) &&
                        this.inputData.noticFromDt.length > 0
                    ) {
                        this.searchYmd.push(
                            moment(this.inputData.noticFromDt).format(
                                'YYYY-MM-DD'
                            ),
                            moment(this.inputData.noticEndDt).format(
                                'YYYY-MM-DD'
                            )
                        )
                    }

                    //  비밀번호여부
                    this.inqPwdNoYnChange()

                    //  공지사항여부
                    this.noticYnChange()

                    //  첨부파일 조회
                    this.attachFileData = {}
                    this.attachFileData.docId = this.inputData.docId
                    this.attachFileData.boardNo = this.inputData.boardNo

                    boardApi.getAttachFile(this.attachFileData).then((res) => {
                        this.fileSearchList = []
                        res.forEach((item) => {
                            this.fileSearchList.push({
                                screenId: item.screenId,
                                docId: item.docId,
                                name: item.fileNm,
                                size: item.fileSize,
                                filePathNm: item.filePathNm,
                                fileType: item.fileType,
                            })
                        })
                        this.$refs.attachedFileAdd.init()
                    })
                })
        },
        //  비밀번호설정여부 변경. 비밀번호입력가능여부설정
        inqPwdNoYnChange: function () {
            this.isInqPwdNo = true
            if (this.inputData.inqPwdNoYn == 'Y') {
                this.isInqPwdNo = false
            } else {
                this.inputData.inqPwdNum = ''
            }
        },
        //  비밀번호표시여부 설정
        inqPwdNoDisplay: function () {
            if (this.inputData.inqPwdNoDisplay == 'Y') {
                this.inqPwdNoInputType = 'text'
            } else {
                this.inqPwdNoInputType = 'password'
            }
        },
        //  공지사항여부 변경. 공지사항일자입력가능여부 설정
        noticYnChange: function () {
            // this.isNotic = true
            if (this.inputData.noticYn == 'Y') {
                this.isNotic = false

                //  공지사항여부를 N으로 했을경우 이전값 복원
                this.backupData.accDealcoCd = this.inputData.accDealcoCd
                this.backupData.accDealcoNm = this.inputData.accDealcoNm
                this.backupData.accQueTypCd = this.inputData.accQueTypCd
                this.backupData.accQueDtlCd = this.inputData.accQueDtlCd

                //  정산처, 문의유형, 문의세부 Clear
                this.inputData.accDealcoCd = ''
                this.inputData.accDealcoNm = ''
                this.inputData.accQueTypCd = ''
                this.inputData.accQueDtlCd = ''

                //  정산처, 문의유형, 문의세부, 답변등록버튼 Disable
                this.isAccDealcoCd = true
                this.searchIconDisabled = true
                this.isAccQueTypCd = true
                this.isAccQueDtlCd = true
                this.isAnswRgstBtn = true
            } else {
                if (!_.isEmpty(this.backupData.accDealcoCd)) {
                    this.inputData.accDealcoCd = this.backupData.accDealcoCd
                    this.inputData.accDealcoNm = this.backupData.accDealcoNm
                    this.inputData.accQueTypCd = this.backupData.accQueTypCd
                    this.inputData.accQueDtlCd = this.backupData.accQueDtlCd
                    this.backupData = {}
                }

                //  정산처, 문의유형, 문의세부, 답변등록버튼 Enable
                this.isAccDealcoCd = false
                this.searchIconDisabled = false
                this.isAccQueTypCd = false
                this.isAccQueDtlCd = false

                if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                    this.isAccDealcoCd = true
                    this.searchIconDisabled = false
                }
                if (this.popupParams.newOpenYn != 'Y') {
                    this.isAnswRgstBtn = false
                }
            }
        },

        //  답변등록 팝업 Open
        answRgstPopOpen: function () {
            if (this.inputData.boardLvl < this.inputData.maxBoardLvl) {
                this.showTcComAlert('답글이 등록되어 있습니다.')
                return
            }
            if (this.userInfo.userId == this.inputData.modUserId) {
                this.showTcComAlert('질문게시자는 답변등록 할 수 없습니다.')
                return
            }

            //  답변등록 팝업 오픈
            this.popupAnswParams.orgBoardNo = this.inputData.boardNo
            this.popupAnswParams.supBoardNo = this.inputData.boardNo
            this.popupAnswParams.accYm = this.inputData.accYm
            this.popupAnswParams.accDealcoCd = this.inputData.accDealcoCd
            this.popupAnswParams.accDealcoNm = this.inputData.accDealcoNm
            this.popupAnswParams.boardLvl = this.inputData.boardLvl
            this.popupAnswParams.modUserId = this.inputData.modUserId
            this.popupAnswParams.accProcStCd = this.inputData.accProcStCd
            this.popupAnswParams.accQueDtlCd = this.inputData.accQueDtlCd
            this.popupAnswParams.accQueTypCd = this.inputData.accQueTypCd
            this.popupAnswParams.makeDtm = this.inputData.makeDtm
            this.popupAnswParams.newOpenYn = 'Y'

            this.answShowPopupOrg = true
        },

        //  저장(질문 등록및변경)
        saveInqRgst: function () {
            if (_.isEmpty(this.inputData.inqTitle)) {
                this.showTcComAlert('제목을 입력하십시오.')
                return
            } else if (!CommonUtil.chkRmks(this.inputData.inqTitle)) {
                this.showTcComAlert('제목을 확인하십시오.')
                return
            }
            if (_.isEmpty(this.inputData.inqCtt)) {
                this.showTcComAlert('내용을 입력하십시오.')
                return
            } else if (!CommonUtil.chkRmks(this.inputData.inqCtt)) {
                this.showTcComAlert('내용을 확인하십시오.')
                return
            }
            if (
                !_.isEmpty(this.inputData.modUserId) &&
                this.inputData.modUserId != this.userInfo.userId
            ) {
                this.showTcComAlert('작성자만 저장 할 수 있습니다.')
                return
            }
            if (this.inputData.boardLvl < this.inputData.maxBoardLvl) {
                this.showTcComAlert('답글이 등록되어 저장 할 수 없습니다.')
                return
            }
            if (
                this.inputData.inqPwdNoYn == 'Y' &&
                _.isEmpty(this.inputData.inqPwdNum)
            ) {
                this.showTcComAlert('비밀번호를 입력해 주십시오.')
                return
            }
            if (
                this.inputData.inqPwdNoYn == 'Y' &&
                this.inputData.inqPwdNum.length != 4
            ) {
                this.showTcComAlert('비밀번호를 4자리로 입력해 주십시오.')
                return
            }
            if (this.inputData.noticYn == 'Y' && _.isEmpty(this.searchYmd)) {
                this.showTcComAlert('공지기간을 입력해 주십시오.')
                return
            }
            if (this.searchYmd[0] > this.searchYmd[1]) {
                this.showTcComAlert(
                    '공지 종료일자는 시작일자 이후 날자만 입력 가능합니다.'
                )
                return
            }
            if (this.inputData.noticYn != 'Y') {
                if (
                    _.isEmpty(this.inputData.accDealcoCd) ||
                    _.isEmpty(this.inputData.accDealcoNm)
                ) {
                    this.showTcComAlert('정산처를 입력하십시오.')
                    return
                }
                if (_.isEmpty(this.inputData.accQueTypCd)) {
                    this.showTcComAlert('문의유형을 입력하십시오.')
                    return
                }
                if (_.isEmpty(this.inputData.accQueDtlCd)) {
                    this.showTcComAlert('문의세부를 입력하십시오.')
                    return
                }
            } else {
                //  공지사항일 경우 로그인 사용자의 조직코드를 Set
                this.inputData.orgCd = this.orgInfo.orgCd

                //  공지기간
                this.inputData.noticFromDt = this.searchYmd[0].replace(/-/g, '')
                this.inputData.noticEndDt = this.searchYmd[1].replace(/-/g, '')
            }

            this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    //  첨부파일 저장
                    boardApi
                        .saveAttachFile(this.formData)
                        .then((resultData) => {
                            if (resultData != null) {
                                this.inputData.docId = resultData[0].docId
                            }

                            //  문의상세내용 저장
                            return boardApi.saveBoardInqRgst(this.inputData)
                        })
                        .then((resultData) => {
                            if (resultData) {
                                this.showTcComAlert('저장되었습니다.')
                                this.onClose()
                            }
                        })
                }
            })
        },

        //팝업닫기
        onClose: function () {
            this.activeOpen = false
            this.$emit('close')
        },
        //  파일첨부(Add,Delete)
        onFileAddChange(files) {
            console.log('files: ', files)
            this.formData = new FormData()
            const addFileLength = files.addFile.length

            _.forEach(files.addFile, (item, index) => {
                this.formData.append('files', item.file)
                this.formData.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].screenId`,
                    'AccSacAccBltnBrd'
                )
                this.formData.append(
                    `admAppendFileList[${index}].docId`,
                    this.inputData.docId === undefined
                        ? ''
                        : this.inputData.docId
                )
                this.formData.append(
                    `admAppendFileList[${index}].__rowState`,
                    'created'
                )
            })
            _.forEach(files.delFile, (item, index) => {
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].filePathNm`,
                    item.filePathNm
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].fileType`,
                    item.fileType
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].screenId`,
                    item.screenId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].docId`,
                    item.docId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].__rowState`,
                    'deleted'
                )
            })
        },

        //===================== 내부거래처(권한조직)) methods ================================
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchAccDealcoParams)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.inputData.accDealcoCd = _.get(res[0], 'dealcoCd')
                        this.inputData.accDealcoNm = _.get(res[0], 'dealcoNm')

                        //  매장등록 사용자일 경우 돋보기 버튼을 클릭하면 팝업오픈(추가근무지조회)
                        if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                            this.basBcoDealcoShow = true
                        }
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        onDealcoIconClick() {
            this.resultDealcoRows = []
            // if (_.isEmpty(this.inputData.accDealcoNm)) {
            //     this.showTcComAlert('정산처를 입력해주세요.')
            //     return
            // }
            this.searchAccDealcoParams.orgCd = this.popupParams.orgCd
            this.searchAccDealcoParams.orgNm = this.popupParams.orgNm
            this.searchAccDealcoParams.orgLvl = this.popupParams.orgLvl
            this.searchAccDealcoParams.dealcoCd = this.inputData.accDealcoCd
            this.searchAccDealcoParams.dealcoNm = this.inputData.accDealcoNm
            this.searchAccDealcoParams.basDay = moment(
                this.inputData.accYm
            ).format('YYYYMMDD')

            // 내부거래처조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            this.resultDealcoRows = []
            if (_.isEmpty(this.inputData.accDealcoNm)) {
                this.showTcComAlert('정산처를 입력해주세요.')
                return
            }
            this.searchAccDealcoParams.orgCd = this.popupParams.orgCd
            this.searchAccDealcoParams.orgNm = this.popupParams.orgNm
            this.searchAccDealcoParams.orgLvl = this.popupParams.orgLvl
            this.searchAccDealcoParams.dealcoCd = this.inputData.accDealcoCd
            this.searchAccDealcoParams.dealcoNm = this.inputData.accDealcoNm
            this.searchAccDealcoParams.basDay = moment(
                this.inputData.accYm
            ).format('YYYYMMDD')

            // 내부거래처조회
            this.getDealcosList()
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.inputData.accDealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.inputData.accDealcoCd = _.get(returnData, 'dealcoCd')
            this.inputData.accDealcoNm = _.get(returnData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================
    },
}
</script>
