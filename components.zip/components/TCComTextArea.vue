<!-----------------------------------------------
 * 업무그룹명: TextArea 컴포넌트
 * 서브업무명: TextArea 공통함수
 * 설명: Tab 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.03.25
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div>
        <span class="itemtit" v-if="labelName" :class="labelClass">{{
            labelName
        }}</span>

        <span class="iteminput">
            <v-textarea
                ref="tcComTextArea"
                v-model="localValue"
                no-resize
                outlined
                :label="label"
                :placeholder="placeholder"
                :hint="hint"
                :persistentHint="true"
                :suffix="suffix"
                :prefix="prefix"
                :readonly="readonly"
                :disabled="disabled"
                :autofocus="autofocus"
                :clearable="clearable"
                :append-icon="appendIcon"
                :prepend-icon="prependIcon"
                :rules="getRules"
                :auto-grow="autoGrow"
                :rows="rows"
                :background-color="backgroundColor"
                :maxLength="maxLength === 0 ? '' : maxLength"
                @input="emitInput"
                @change="emitChange"
                @blur="emitBlur"
                @click="emitClick"
                @focus="emitFocus"
                @click:append="emitAppendClick"
                @click:prepend="emitPrependClick"
                @click:clear="emitClearClick"
                @keydown="emitKeyDown"
                @keydown.enter="emitKeyDownEnter"
                @keyup.enter="emitKeyUpEnter"
                @mousedown="emitMouseDown"
            ></v-textarea>
        </span>
    </div>
</template>

<script>
export default {
    inheritAttrs: false,
    name: 'TCComTextArea',
    components: {},
    props: {
        value: { required: false },
        label: { type: String, default: '', required: false }, // 라벨
        hint: { type: String, default: '', required: false }, // 힌트 테스트
        persistentHint: { type: Boolean, default: true, required: false }, // 힌트를 항상 표시 여부 설정
        dialogSlotted: { type: Boolean, default: false, required: false },
        labelName: { type: String, required: false },
        readonly: { type: Boolean, default: false, required: false }, // 읽기 전용 상태 여부
        disabled: { type: Boolean, default: false, required: false }, // 입력 비활성화 여부
        placeholder: { type: String, default: '', required: false }, // 입력의 자리 표시자 텍스트를 설정 여부
        suffix: { type: String, required: false }, // 접미사 텍스트 표시
        prefix: { type: String, required: false }, // Prefix 텍스트 표시
        // 구성 요소에 아이콘을 추가하고 v-icon과 동일한 구문을 사용합니다.
        appendIcon: { type: String, required: false },
        // 구성 요소에 아이콘을 추가하고 v-icon과 동일한 구문을 사용
        prependIcon: { type: String, required: false },
        // 입력 지우기 기능을 추가. 기본 아이콘은 mdi-clear
        clearable: { type: Boolean, default: false, required: false },
        // 자동 포커스 유효 여부
        autofocus: { type: Boolean, default: false, required: false },
        maxLength: { type: Number, default: 0, required: false }, // 최대 길이
        required: { type: Boolean, default: false, required: false }, // 필수 여부
        // 함수, 부울 및 문자열의 혼합 배열을 사용할 수 있습니다.
        // 함수는 입력값을 인수로 전달하며 true/false 또는 오류 메시지를 포함하는 문자열을 반환해야 합니다.
        // 함수가 false를 반환하거나(또는 배열의 모든 값에 포함됨) 문자열인 경우 입력 필드가 오류 상태가 됩니다.
        rules: { required: false },
        rows: { type: Number, default: 2, required: false }, // Default row count
        // 텍스트 양에 따라 텍스트 영역 자동 증가 여부
        autoGrow: { type: Boolean, default: false, required: false },
        backgroundColor: { type: String, default: '', required: false }, // 입력 배경색을 변경
        objAuth: { type: Object, default: () => {}, required: false }, // auth
        //CSS Label Class
        labelClass: { type: String, default: '', required: false },
    },

    data() {
        return {
            localValue: '',
        }
    },
    computed: {
        getRules() {
            let rules = []
            if (this.rules) {
                rules = this.rules
            }
            return rules
        },
    },
    watch: {
        value: function () {
            this.localValue = this.value
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.localValue = this.value
        },
        textAreaFocus() {
            this.$refs.tcComTextArea.focus()
        },
        emitInput(value) {
            this.$emit('input', value)
        },
        emitChange(value) {
            this.emitInput(value)
            this.$emit('change', value)
        },
        emitBlur(ev) {
            this.$emit('blur', ev)
        },
        emitClick(ev) {
            this.$emit('click', ev)
        },
        emitFocus(ev) {
            this.$emit('focus', ev)
        },
        emitAppendClick(ev) {
            this.$emit('appendClick', ev)
        },
        emitKeyDownEnter(ev) {
            this.$emit('keyDownEnter', ev)
        },
        emitKeyDown(ev) {
            this.$emit('key-down', ev)
        },
        emitKeyUpEnter(ev) {
            this.$emit('keyUpEnter', ev)
        },
        emitMouseDown(ev) {
            this.$emit('mouse-down', ev)
        },
        emitPrependClick(ev) {
            this.$emit('prependClick', ev)
        },
        emitClearClick(ev) {
            this.$emit('clear-click', ev)
        },
        emitPrependImg(ev) {
            this.$emit('clickPrependImg', ev)
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
