import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'aaa',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        /*
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '변경일자',
            },
        },
        */
        {
            name: 'userGrpNm',
            fieldName: 'userGrpNm',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '권한그룹',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '처리일시',
            },
        },
    ],
}
