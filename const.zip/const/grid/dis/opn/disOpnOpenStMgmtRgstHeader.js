import { ValueType } from 'realgrid'

export const DisOpnOpenStMgmtRgst_GRID_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'openYn',
            dataType: ValueType.TEXT, //개봉상태
        },
        {
            fieldName: 'toOpenYn',
            dataType: ValueType.TEXT, //상태변경
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'openInsDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', //처리일자
        },
        {
            fieldName: 'openInsNm',
            dataType: ValueType.TEXT, //처리자
        },
        {
            fieldName: 'openInsId',
            dataType: ValueType.TEXT, //처리자ID
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT, //제조사ID
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'prchTyp',
            dataType: ValueType.TEXT, //구매유형코드
        },
        {
            fieldName: 'opnOrdDt',
            dataType: ValueType.TEXT, //개봉지시일
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'openYn',
            fieldName: 'openYn',
            values: ['Y', 'N'],
            labels: ['개봉', '미개봉'],
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 2,
            },
            header: {
                text: '개봉상태',
            },
        },
        {
            name: 'toOpenYn',
            fieldName: 'toOpenYn',
            values: ['Y', 'N'],
            labels: ['미개봉 -> 개봉', '개봉 -> 미개봉'],
            lookupDisplay: true,
            editor: {
                type: 'dropDown',
                dropDownCount: 2,
            },
            header: {
                text: '상태변경',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'openInsDtm',
            fieldName: 'openInsDtm',
            header: {
                text: '처리일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'openInsNm',
            fieldName: 'openInsNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
        {
            name: 'openInsId',
            fieldName: 'openInsId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분코드',
                showTooltip: false,
            },
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사ID',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'prchTyp',
            fieldName: 'prchTyp',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구매유형코드',
                showTooltip: false,
            },
        },
        {
            name: 'opnOrdDt',
            fieldName: 'opnOrdDt',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개봉지시일',
                showTooltip: false,
            },
        },
    ],
}
