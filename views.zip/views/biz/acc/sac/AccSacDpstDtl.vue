<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 입금 내역서
 * 설명: 입금 내역서 조회
 * 작성자: P180190
 * 작성일: 2022.12.20
------------------------------------------------>
<template>
    <div class="content">
        <h1>입금 내역서</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton eClass="btn_ty01" :objAuth="objAuth" @click="init"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComDatePicker
                        labelName="영업월"
                        calType="M"
                        :eRequired="true"
                        v-model="accYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="searchFormData.searchCoOrgClNm"
                        :codeVal.sync="searchFormData.searchCoOrgClCd"
                        labelName="대리점"
                        :disabledAfter="true"
                        :disabled="true"
                        :objAuth="objAuth"
                    />
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="searchFormData.dealcoNm"
                        :codeVal.sync="searchFormData.dealcoCd"
                        labelName="거래처"
                        :disabledAfter="true"
                        :disabled="true"
                        :objAuth="objAuth"
                    />
                </div>
            </div>
        </div>
        <div class="wrapTblDefault pt10">
            <table cellpadding="0" cellspacing="0" class="thCenter">
                <tbody>
                    <tr>
                        <th>지급 합계</th>
                        <th>공제 합계</th>
                        <th>최종 입금액</th>
                    </tr>
                    <tr>
                        <td class="ar">{{ accAmtSum | comma }}</td>
                        <td class="ar">{{ deductAmtSum | comma }}</td>
                        <td class="ar">
                            {{ (accAmtSum - deductAmtSum) | comma }}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="wrapTblDefault pt20">
            <table cellpadding="0" cellspacing="0" class="thCenter">
                <colgroup>
                    <col style="width: 25%" />
                    <col style="width: 25%" />
                    <col style="width: 25%" />
                    <col style="width: 25%" />
                </colgroup>
                <tbody>
                    <tr>
                        <th>지급 항목</th>
                        <th>지급 금액</th>
                        <th>공제 항목</th>
                        <th>공제 금액</th>
                    </tr>
                    <tr>
                        <td class="detail ac">계산서금액</td>
                        <td class="ar">{{ accAmt.billAmt | comma }}</td>
                        <td class="detail ac">현금개통</td>
                        <td class="ar">
                            {{ deductAmtRows.deductAmt0 | comma }}
                        </td>
                    </tr>
                    <tr>
                        <td class="detail ac">미발행 금액</td>
                        <td class="ar">{{ accAmt.notAplyAmt | comma }}</td>
                        <td class="detail ac">공기기청구(단말기)</td>
                        <td class="ar">
                            {{ deductAmtRows.deductAmt1 | comma }}
                        </td>
                    </tr>
                    <tr
                        v-for="deductAmtList in deductAmtS"
                        :key="deductAmtList.deductItmCd"
                    >
                        <td class="detail ac"></td>
                        <td class="ar"></td>
                        <td class="detail ac">
                            {{ deductAmtList.deductItmNm }}
                        </td>
                        <td class="ar">
                            {{ deductAmtList.deductAmt | comma }}
                        </td>
                    </tr>
                    <tr>
                        <td class="ac">지급 계</td>
                        <td class="ar" id="total">{{ accAmtSum | comma }}</td>
                        <td class="ac">공제 계</td>
                        <td class="ar" id="total">
                            {{ deductAmtSum | comma }}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
import { CommonUtil } from '@/utils'
import moment from 'moment'
import dpstDtlApi from '@/api/biz/acc/sac/AccSacDpstDtl'
import CommonMixin from '@/mixins'
export default {
    name: 'AccSacDpstDtl',
    title: '입금 내역서',
    components: {},
    mixins: [CommonMixin],
    data() {
        return {
            objAuth: {},

            accYm_: moment(new Date()).format('YYYY-MM'),

            //요청 파라미터
            searchFormData: {
                searchAccYm: '',
                dealcoCd: '',
                searchCoOrgClCd: '',
            },

            // 지급항목
            accAmt: [],
            // 공제항목 1~2
            deductAmtRows: [],
            // 공제항목 3~9
            deductAmtS: [],

            // 지급합계
            accAmtSum: 0,
            // 공제합계
            deductAmtSum: 0,
        }
    },
    mounted() {
        // 첫번째 그리드 세팅
        this.grid = this.$refs.grid
        this.gridHeader = this.$refs.gridHeader
        this.searchFormData.searchCoOrgClCd = this.orgInfo.orgCd
        this.searchFormData.searchCoOrgClNm = this.orgInfo.orgNm
        this.searchFormData.dealcoCd = this.userInfo.dealcoCd
        this.searchFormData.dealcoNm = this.userInfo.dealcoNm
        this.onSearch()
    },
    computed: {},
    filters: {
        comma(val) {
            return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        },
    },
    watch: {},
    methods: {
        // 초기화 버튼
        init: function () {
            this.accYm_ = moment(new Date()).format('YYYY-MM')
            this.onSearch()
        },

        //================================================
        // :::: 조회 ::::
        //================================================
        onSearch: function () {
            this.searchFormData.searchAccYm = this.accYm_
            if (_.isEmpty(this.searchFormData.searchAccYm)) {
                this.showTcComAlert('기준년월을 확인하세요.')
            } else {
                this.searchFormData.searchAccYm = CommonUtil.onlyNumber(
                    this.accYm_
                )
                this.getDpstDtlList()
            }
        },
        getDpstDtlList() {
            this.deductAmtSum = 0
            dpstDtlApi.getDpstDtlList(this.searchFormData).then((res) => {
                if (res) {
                    console.log('조회결과 ::::::: ', res)
                    this.accAmt = res.accSacAccAmtVoList
                    if (this.accAmt.length <= 0) {
                        this.accAmtSum = 0
                        this.accAmt.billAmt = 0
                        this.accAmt.notAplyAmt = 0
                    } else {
                        this.accAmtSum =
                            this.accAmt[0].billAmt + this.accAmt[0].notAplyAmt
                        this.accAmt.billAmt = this.accAmt[0].billAmt
                        this.accAmt.notAplyAmt = this.accAmt[0].notAplyAmt
                    }
                    this.deductAmtRows = res.accSacDeductAmtVoList
                    this.deductAmtRows.deductAmt0 =
                        this.deductAmtRows[0].deductAmt
                    this.deductAmtRows.deductAmt1 =
                        this.deductAmtRows[1].deductAmt

                    this.deductAmtS = res.accSacDeductAmtVoList.slice(2, 9)
                    this.deductAmtRows.forEach((item) => {
                        this.deductAmtSum += Number(item.deductAmt)
                    })
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },
    },
}
</script>
