<!-----------------------------------------------
 * 업무그룹명: Treeview 컴포넌트
 * 서브업무명: Treeview 공통함수
 * 설명: Treeview 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.03.24
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <!-- [2022-07-07 수정]-->
    <div class="treeWrap" :class="eClass">
        <v-treeview
            ref="treeview"
            v-model="selection"
            :activatable="activatable"
            :items="items"
            color="treepoint"
            :dense="dense"
            :hoverable="hoverable"
            :selectable="selectable"
            :selected-color="selectedColor"
            :item-disabled="disabled"
            :open-all="openAll"
            :open-on-click="openOnClick"
            :rounded="rounded"
            :shaped="shaped"
            :selection-type="selectionType"
            :return-object="returnObject"
            :search="search"
            :filter="filter"
            :open="openNode"
            @input="emitInput"
            @update:active="emitActive"
            @update:open="emitOpen"
        >
            <template v-slot:label="{ item, open }">
                <v-btn text :ripple="false" class="ma-0 pa-0">
                    <!--button icon-->
                    <v-icon v-if="!item.file" @click="icOpenOn(true)">
                        {{ open ? 'mdi-folder-open' : 'mdi-folder' }}
                    </v-icon>
                    <v-icon v-else @click="icOpenOn(false)">
                        {{ files[item.file] }}
                    </v-icon>
                    <!--button text-->
                    <span @click="icOpenOn(false)" @dblclick="dblclick">{{
                        item.name
                    }}</span>
                </v-btn>
            </template>
        </v-treeview>
    </div>
    <!-- //[2022-07-07 수정] -->
</template>

<script>
export default {
    inheritAttrs: false,
    name: 'TCComTreeview',
    components: {},
    props: {
        activatable: { type: Boolean, default: false, required: false }, // 노드 활성화 설정
        items: {
            type: Array,
            default: () => {
                return [
                    {
                        files: {
                            plus: 'mdi-folder',
                            last: 'mdi-checkbox-blank-circle-outline',
                        },
                    },
                ] //[2022-07-07 추가]
            },
            required: false,
        }, // 노드 정보
        value: {
            type: Array,
            default: () => {},
            required: false,
        }, // 선택한 노드 정보
        color: { type: String, default: '', required: false }, // 노드 색상
        dense: { type: Boolean, default: false, required: false }, // Dense mode 설정(트리 사이 간격을 줄어줌)
        hoverable: { type: Boolean, default: true, required: false }, //  hover effect 설정
        selectable: { type: Boolean, default: false, required: false }, // 노드 체크박스 설정
        selectedColor: { type: String, default: '', required: false }, // 노드 체크박스 색상
        disabled: { type: String, default: '', required: false }, // 노드 Disable 설정(locked)
        openAll: { type: Boolean, default: false, required: false }, // OPEN ALL 여부 설정
        openOnClick: { type: Boolean, default: false, required: false }, // 노드 클릭시 OPEN 여부 설정
        rounded: { type: Boolean, default: false, required: false }, // 노드 rounded 설정
        shaped: { type: Boolean, default: false, required: false }, // 노드 shaped 설정
        // Selection Type 설정(leaf, independent)
        // leaf: 부모노드 클릭시 자식 노드까지 Selection
        // independent: 노드 독릭적인 Selection
        selectionType: { type: String, required: false },
        returnObject: { type: Boolean, default: false, required: false }, // 오브젝트 리턴 설정 여부
        search: { type: String, required: false }, // 필터링 결과를 위한 검색 모델
        filter: { type: Function, required: false }, // 필터 함수 설정
        open: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        }, // Open 노드 제어 속성(Open 할 노드 id 값을 배열로 넘긴다.)
        objAuth: { type: Object, default: () => {}, required: false }, // auth
        icOpenOnClick: { type: Boolean, default: false, required: false }, //  아이콘클릭시에만 OPEN여부 설정
        // Style Class
        eClass: { type: String, default: 'yscroll h400', required: false },
    },
    data() {
        return {
            selection: [],
            openOnYn: false,
            files: {
                plus: 'mdi-folder',
                last: 'mdi-checkbox-blank-circle-outline',
            },
        }
    },
    computed: {
        openNode: {
            get() {
                return this.open
            },
            set(value) {
                this.$emit('update:open', value)
            },
        },
    },
    watch: {
        value: {
            handler: function () {
                this.selection = this.value
            },
            deep: true,
            immediate: false,
        },
        activatable: true,
        search: function (newVal) {
            if (newVal) {
                this.$refs.treeview.updateAll(true)
            } else {
                if (this.openAll) {
                    this.$refs.treeview.updateAll(true)
                } else {
                    this.$refs.treeview.updateAll(false)
                }
            }
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.selection = this.value
        },
        emitInput(node) {
            // console.log('emit node: ', node)
            this.$emit('input', node)
        },
        emitActive(node) {
            // console.log('emit active: ', node)
            this.$emit('active', node)
        },
        emitOpen(node) {
            this.$emit('open', node)
        },
        icOpenOn(bl) {
            if (this.icOpenOnClick) {
                this.$emit('onOpenFolder', bl)
            }
        },
        dblclick(node) {
            this.$emit('dblclick', node)
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
