<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccGridTable.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="gridWrap" :class="{ noTitleArea: !isTitleArea }">
        <TCRealGridHeader
            class="accGridTableHeader"
            ref="accGridTableHeader"
            :id="`accGridTableHeader${_uid}`"
            :gridTitle="title"
            :gridObj="gridObj"
            :isAddRow="isComponentOffset('btn-addRow')"
            :isDelRow="isComponentOffset('btn-deleteRow')"
            :isExcelup="isComponentOffset('btn-excelUpload')"
            :isExceldown="isComponentOffset('btn-excelDownload')"
            :isFileAdd="isComponentOffset('btn-fileAdd')"
            :isPageRows="isComponentOffset('headerTotalPage')"
            :isSetPaging="isComponentOffset('headerSetPage')"
            @excelUploadBtn="clickExcelUpload"
            @excelDownBtn="clickExcelDownload"
            @addRowBtn="clickAddRow"
            @chkDelRowBtn="clickDeleteRow"
        >
            <template v-for="(_, name) in $scopedSlots" :slot="name"
                ><slot :name="name"
            /></template>
            <template #gridElementArea>
                <span v-if="isExcelupParse">
                    <TCComButton
                        :Vuetify="false"
                        :disabled="disExcelupParse"
                        eClass="btn_noline btn_ty04"
                        eAttr="ico_exelup"
                        labelName="업로드"
                        @click="excelUpParseloadBtn"
                    />
                </span>
            </template> </TCRealGridHeader
        ><TCRealGrid
            class="accGridTableBody"
            ref="accGridTableBody"
            :id="`accGridTableBody${_uid}`"
            :editable="isEditable"
            :movable="isMovable"
            :columnMovable="isColumnMovable"
            :fields="gridMeta.fields"
            :columns="gridMeta.columns"
            :style="gridMeta.contextStyle"
            :editWhenFocused="isEditWhenFocused"
        />

        <div class="pagingWrap" v-if="isPaging">
            <ul>
                <li>
                    <button
                        type="button"
                        class="arrow first"
                        @click="clickMovePageFirst"
                    >
                        <span></span>
                    </button>
                </li>
                <li>
                    <button
                        type="button"
                        class="arrow prev"
                        @click="clickMovePagePrev"
                    >
                        <span></span>
                    </button>
                </li>
                <li
                    v-for="(page, idx) in pagingOffset"
                    :key="`${_uid}gridpaging${idx}`"
                >
                    <button
                        type="button"
                        class="text"
                        :class="{ active: page == pagingInfo.pageNum }"
                        @click="clickMovePage(page)"
                    >
                        {{ page }}
                    </button>
                </li>
                <li>
                    <button
                        type="button"
                        class="arrow next"
                        @click="clickMovePageNext"
                    >
                        <span></span>
                    </button>
                </li>
                <li>
                    <button
                        type="button"
                        class="arrow last"
                        @click="clickMovePageLast"
                    >
                        <span></span>
                    </button>
                </li>
            </ul>

            <TCComComboBox
                class="sortSize"
                :itemList="[15, 30, 50, 100, 200]"
                v-model="pagingInfo.pageSize"
                @change="changePageSize"
            />
        </div>

        <AccFileLoader
            ref="accFileLoader"
            labelName="파일선택"
            isHidden
            @load="loadExcel"
        />

        <div ref="trashGrid" class="trashGrid"></div>
    </div>
</template>
<style scoped>
.gridWrap.noTitleArea {
    margin: 20px 0 0;
}
.gridWrap :deep(.accGridTableHeader).stitHead {
    min-height: 44px;
}
.gridWrap :deep(.accGridTableBody) .rg-table .rg-header-cell.editable {
    background: #99ccff !important;
}

.gridWrap :deep(.accGridTableBody) .rg-table .rg-data-cell.align-left {
    text-align: left;
}
.gridWrap :deep(.accGridTableBody) .rg-table .rg-data-cell.align-right {
    text-align: right;
}
.trashGrid {
    position: absolute;
    left: 0;
    top: 0;
    width: 0;
    height: 0;
    opacity: 0;
    overflow: hidden;
    visibility: hidden;
}
.pagingWrap {
    position: relative;
}

.pagingWrap ul > li {
    display: inline-block;
    width: 24px;
    vertical-align: middle;
    line-height: 34px;
}
.pagingWrap .arrow {
    vertical-align: top;
    width: 24px;
    height: 34px;
    background-position: center;
}
.pagingWrap .text {
    display: block;
    margin-top: -2px;
    width: 100%;
    vertical-align: middle;
    color: #777;

    &.active {
    }
}

.pagingWrap .text.active {
    color: #d81d1f;
    font-weight: 700;
}

.pagingWrap .sortSize {
    position: absolute;
    right: 0;
    top: 10px;
    width: 90px;
}
</style>

<script>
import JSZip from 'jszip'
import moment from 'moment'

import CommonMixin from '@/mixins'
import { GridView, LocalDataProvider } from 'realgrid'

import attachedFileApi from '@/api/common/attachedFile'

import AccFileLoader from '@/components/biz/common/acc/AccFileLoader'

export default {
    name: 'AccGridTable',
    mixins: [CommonMixin],
    components: { AccFileLoader },
    props: {
        isExcelupParse: {
            type: Boolean,
            default: false,
        },
        disExcelupParse: {
            type: Boolean,
            default: false,
        },
        /**
         * 컴포넌트 옵션
         * @description 선언되지 않으면 false (this.isColumnMovable ==> false)
         *
         * 선언 안된 경우)
         * <AccGridTable
         *   ref="accGridTablePart"
         * />
         *
         * 선언 된 경우)
         * <AccGridTable
         *   ref="accGridTablePart"
         *   isColumnMovable
         * />
         *
         */
        isColumnMovable: Boolean, // 컬럼 드래그이동 유무
        isEditable: Boolean, // 편집가능 유무
        isMovable: Boolean, // 행이동 여부
        isColumnNo: Boolean, // 컬럼번호 여부
        isCheckbox: Boolean, // 체크박스행 여부
        isRadiobox: Boolean, // 라디오박스행 여부
        isFooter: Boolean, // 하단푸터 여부
        noPaging: Boolean, // 페이징 여부 (true면 페이징 없음)

        // true로 설정하면 그리드를 한번 클릭으로 편집기가 바로 표시
        isEditWhenFocused: {
            default: true,
        },

        /**
         * 그리드 타이틀
         */
        title: {
            default: null,
        },

        /**
         * 화면에 표시할 항목
         * @description
         *      btn-addRow - 행추가
         *      btn-deleteRow - 행삭제
         *      btn-excelUpload - 엑셀업로드
         *      btn-excelDownload - 엑셀다운로드
         *      btn-fileAdd - 파일추가
         *      btn-approvalRequest - 승인요청
         *      headerSetPage - 상단 페이지설정 셀렉트박스
         *      footerSetPage - 하단 페이지설정 셀렉트박스
         *      headerTotalPage - 전체페이지 표시
         */
        offset: {
            default: () => [],
        },

        /**
         * 그리드 동작에 필요한 부가정보(메타)
         */
        gridMeta: {
            default: () => ({
                columns: [],
                fields: [],
                layout: [],
                contextStyle: `height: 500px`,
            }),
        },

        /**
         * 그리드 데이터
         */
        data: {
            type: [Array],
            default: () => [],
        },

        /**
         * 컴포넌트에서 기본으로 실행하는 동작 방어
         */
        preventEvent: {
            default: () => [],
        },

        /**
         * 페이징 정보
         * @description
         *      pageSize - 한페이지 조회 개수
         *      pageNum - 현재 페이지
         *      totalPageCnt - 전체페이지 개수
         *      totalDataCnt - 전체데이터 개수
         */
        pagingInfo: {
            default: () => ({
                totalPageCnt: 0,
                pageSize: 15,
            }),
        },

        /**
         * 그리드 내보내기 정보
         * @description
         *      uri - 다운로드 API 정보,
         *      query - 검색조건,
         */
        exportInfo: {
            default: () => ({}),
        },
    },
    data() {
        return {
            gridObj: {},
            gridHeaderObj: {},
            gridView: {},
            objAuth: {},

            // 한번에 표현할 페이징 개수, 만약 5면, << < 1 2 3 4 5 > >>
            perPageDisplay: 10,
        }
    },
    computed: {
        /**
         * 그리드 타이틀 존재 여부
         */
        isTitleArea() {
            return this.title || this.offset.length
        },

        /**
         * 페이징 존재 여부
         */
        isPaging() {
            // this.pagingInfo.totalPageCnt && this.pagingInfo.totalPageCnt > 0
            return !this.noPaging
        },

        /**
         * 페이징 표현 계산
         */
        pagingOffset() {
            if (!this.isPaging || this.pagingInfo.totalPageCnt == 0) return []

            const offset = []

            let recentPoint = Math.floor(
                (this.pagingInfo.pageNum - 1) / this.perPageDisplay
            )
            let start = recentPoint * this.perPageDisplay + 1
            let end = start + this.perPageDisplay

            if (end > this.pagingInfo.totalPageCnt) {
                end = this.pagingInfo.totalPageCnt + 1
            }

            for (let page = start; page < end; page++) {
                offset.push(page)
            }

            return offset
        },

        accFileLoader() {
            return this.$refs.accFileLoader
        },
    },
    watch: {
        /**
         * 그리드 데이터 변경 시
         */
        data: {
            immediate: false,
            deep: true,
            handler(value) {
                this.gridView.commit()
                this.dataProvider.setRows(value)
            },
        },

        /**
         * 그리드 부가정보(메타) 변경 시
         */
        gridMeta: {
            immediate: false,
            deep: true,
            handler() {
                //@TODO 헤더정보 갱신 시 테스트 필요
                this.gridView.commit()
                this.setGrid(this.data)
            },
        },
    },
    created() {
        if (!Object.prototype.hasOwnProperty.call(window, JSZip)) {
            window.JSZip = JSZip
        }
    },
    mounted() {
        this.gridObj = this.$refs.accGridTableBody
        this.gridHeaderObj = this.$refs.accGridTableHeader
        this.gridView = this.gridObj.gridView
        this.dataProvider = this.gridObj.dataProvider

        this.setGrid(this.data)

        // 셀데이터 추가된 후
        this.dataProvider.onRowInserted = (provider, rowIdx) => {
            this.gridView.commit()

            const fieldName = this.gridView.getCurrent().fieldName
            if (!fieldName) return

            const status = this.getRowStateInIdx(rowIdx)
            const row = this.getRowDataInIdx(rowIdx)
            const rowInfo = this.getColumn(fieldName)
            rowInfo.dataRow = rowIdx
            rowInfo.status = status

            if (status != 'created') {
                if (this.isColumn('__rowState')) {
                    provider.setValue(rowIdx, '__rowState', 'created')
                }
            }

            this.$nextTick(() => this.$emit('rowAdded', row, rowIdx, rowInfo))
        }

        // 셀데이터 수정반영 후
        this.dataProvider.onRowUpdated = (provider, rowIdx) => {
            this.gridView.commit()

            const fieldName = this.gridView.getCurrent().fieldName
            const status = this.getRowStateInIdx(rowIdx)
            const row = this.getRowDataInIdx(rowIdx)
            const rowInfo = this.getColumn(fieldName)
            rowInfo.dataRow = rowIdx
            rowInfo.status = status

            if (status != 'created') {
                if (this.isColumn('__rowState')) {
                    provider.setValue(rowIdx, '__rowState', 'updated')
                }
            }

            this.$nextTick(() => this.$emit('rowUpdated', row, rowIdx, rowInfo))
        }

        // 셀 클릭 한 경우
        this.gridView.onCellClicked = (grid, rowInfo) => {
            if (rowInfo.dataRow === undefined || rowInfo.dataRow < 0) return

            const rowIdx = rowInfo.dataRow
            const cellIdx = rowInfo.fieldIndex
            const row = this.getRowDataInIdx(rowIdx)
            const status = this.getRowStateInIdx(rowIdx)

            Object.assign(rowInfo, this.gridMeta.columns[cellIdx])
            rowInfo.status = status

            this.$nextTick(() => this.$emit('clickCell', row, rowIdx, rowInfo))
        }

        // 셀 더블클릭 한 경우
        this.gridView.onCellDblClicked = (grid, rowInfo) => {
            if (rowInfo.dataRow === undefined || rowInfo.dataRow < 0) return

            const rowIdx = rowInfo.dataRow
            const cellIdx = rowInfo.fieldIndex
            const row = this.getRowDataInIdx(rowIdx)
            const status = this.getRowStateInIdx(rowIdx)

            Object.assign(rowInfo, this.gridMeta.columns[cellIdx])
            rowInfo.status = status

            this.$nextTick(() =>
                this.$emit('dblClickCell', row, rowIdx, rowInfo)
            )
        }

        // 셀 버튼클릭 한 경우
        this.gridView.onCellButtonClicked = (grid, rowInfo, colInfo) => {
            if (rowInfo.dataRow === undefined || rowInfo.dataRow < 0) return

            const rowIdx = rowInfo.dataRow
            const cellIdx = rowInfo.fieldIndex
            const row = this.getRowDataInIdx(rowIdx)
            const status = this.getRowStateInIdx(rowIdx)

            Object.assign(rowInfo, this.gridMeta.columns[cellIdx])
            rowInfo.status = status

            this.$nextTick(() =>
                this.$emit(
                    'editCellButton',
                    row,
                    rowIdx,
                    rowInfo,
                    colInfo,
                    grid
                )
            )
        }

        // 셀 이동 후 선택된 상태
        this.gridView.onCurrentChanging = (grid, oldRowInfo, rowInfo) => {
            if (rowInfo.dataRow === undefined || rowInfo.dataRow < 0) return

            const rowIdx = rowInfo.dataRow
            const cellIdx = rowInfo.fieldIndex
            const row = this.getRowDataInIdx(rowIdx)
            const status = this.getRowStateInIdx(rowIdx)

            Object.assign(rowInfo, this.gridMeta.columns[cellIdx])
            rowInfo.status = status

            this.$nextTick(() =>
                this.$emit('rowSelected', row, rowIdx, rowInfo)
            )
            // return false; 를 하는 경우 위치 변경이 되지 않는다.
        }

        // 셀 편집창이 열린상태
        this.gridView.onShowEditor = (grid, rowInfo) => {
            if (rowInfo.dataRow === undefined || rowInfo.dataRow < 0) return

            const rowIdx = rowInfo.dataRow
            const cellIdx = rowInfo.fieldIndex
            const row = this.getRowDataInIdx(rowIdx)
            const status = this.getRowStateInIdx(rowIdx)

            Object.assign(rowInfo, this.gridMeta.columns[cellIdx])
            rowInfo.status = status

            this.$nextTick(() => this.$emit('rowEditing', row, rowIdx, rowInfo))
        }
    },
    methods: {
        /**
         * 그리드 초기화
         * @param {object} rowsData 그리드 데이터
         */

        excelUpParseloadBtn() {
            this.$emit('excelUpParseloadBtn')
        },

        setGrid(rowsData) {
            this.gridView.setStateBar({ visible: false })
            this.gridView.setCheckBar({
                visible: this.isCheckbox,
            })

            if (this.isRadiobox) {
                this.gridView.setCheckBar({
                    visible: true,
                    exclusive: true,
                })
            }

            this.gridView.setFooters({ visible: this.isFooter })

            this.gridView.setEditOptions({
                commitByCell: true,
            })

            // displayValue - none: 값을 표시 하지 않습니다.
            // displayValue - index: 1부터 시작하여 순서대로 표시합니다. (정렬에 무관하게 1번부터 시작)
            // displayValue - row: Row의 고유번호를 표시합니다. (정렬에 따라서 섞여서 표시)
            this.gridView.setRowIndicator({
                zeroBase: false,
                visible: this.isColumnNo,
                displayValue: 'index',
            })

            this.gridView.setColumns(this.gridMeta.columns)

            if (this.gridMeta.layout && this.gridMeta.layout.length) {
                this.gridView.setColumnLayout(this.gridMeta.layout)
            }

            this.dataProvider.setFields(this.gridMeta.fields)
            this.dataProvider.setRows(rowsData)
        },

        /**
         * 화면에 표현되는 항목 여부
         * @param {string} name 속성 이름
         * @description 표현항목이면 true
         */
        isComponentOffset(name) {
            return this.offset.includes(name)
        },

        /**
         * 추가된 데이터만 있는지 확인
         * @param {number} rowIdx 데이터 인덱스
         */
        isAddRowInIdx(rowIdx) {
            return new Promise((resolve, reject) => {
                const status = this.getRowStateInIdx(rowIdx)
                const invalidList = status.reduce((acc, arr, idx) => {
                    if (arr != 'created') acc.push(rowIdx[idx])
                    return acc
                }, [])

                if (invalidList.length) reject(invalidList)

                resolve(rowIdx)
            })
        },

        /**
         * fieldName 이 존재하는지 확인
         * @param {string} columnName 컬럼이름
         */
        isColumn(columnName) {
            return (
                this.gridMeta.columns.filter(
                    (arr) => arr.fieldName === columnName
                ).length != 0
            )
        },

        /**
         * 행추가 클릭 시
         */
        clickAddRow() {
            this.gridView.commit()

            if (this.preventEvent.includes('clickAddRow')) {
                this.$emit('addRow', null)
            } else {
                if (this.data.length == 0) {
                    return this.showTcComAlert('조회된 데이터가 없습니다')
                }

                this.addRowData({}, 'first')
                this.$emit('addRow', null)
            }
        },

        /**
         * 행삭제 클릭 시
         */
        clickDeleteRow() {
            this.gridView.commit()

            const allRows = this.getAllRow()
            const rows = this.getCheckedRow()
            const rowIdx = this.getCheckedRowIdx()

            if (rows.length == 0) {
                return this.showTcComAlert('선택된 데이터가 없습니다')
            }

            if (this.preventEvent.includes('clickDeleteRow')) {
                this.$emit('deleteRow', rows, rowIdx)
            } else {
                if (allRows.length == 0) {
                    return this.showTcComAlert('조회된 데이터가 없습니다')
                }

                this.isAddRowInIdx(rowIdx)
                    .then(() => {
                        this.dataProvider.removeRows(rowIdx)
                        this.$emit('deleteRow', rows, rowIdx)
                    })
                    .catch((invalidList) => {
                        console.warn(invalidList)
                        return this.showTcComAlert(
                            `신규 추가된 데이터만 삭제가 가능합니다.`
                        )
                    })
            }
        },

        /**
         * 엑셀업로드 클릭 시
         */
        clickExcelUpload() {
            if (this.preventEvent.includes('clickExcelUpload')) {
                this.$emit('excelUpload')
            } else {
                this.openSelector()
            }
        },

        /**
         * 엑셀다운로드 클릭 시
         */
        clickExcelDownload() {
            if (this.preventEvent.includes('clickExcelDownload')) {
                this.$emit('excelDownload')
            } else {
                if (this.data.length == 0) {
                    return this.showTcComAlert('조회된 데이터가 없습니다')
                }

                attachedFileApi
                    .downLoadFile(this.exportInfo.uri, this.exportInfo.query)
                    .finally(() => {
                        this.$emit('excelDownload', this.exportInfo)
                    })
            }
        },

        /**
         * 선택된 row 데이터
         */
        getCheckedRow() {
            const checkedItemIdx = this.gridView.getCheckedRows(true)
            return checkedItemIdx.map((arr) => {
                const row = this.getRowDataInIdx(arr)
                const status = this.getRowStateInIdx(arr)

                row.dataRow = arr
                row.status = status

                return row
            })
        },

        /**
         * 선택된 row 데이터의 index
         */
        getCheckedRowIdx() {
            return this.gridView.getCheckedRows(true)
        },

        /**
         * 모든 row 데이터
         */
        getAllRow() {
            return this.changeDateOnGridformat(
                this.dataProvider.getJsonRows(0, -1)
            )
        },

        /**
         * 현재 선택된 row 데이터
         */
        getCurrentRow() {
            const currentItem = this.gridView.getCurrent()

            if (currentItem.dataRow < 0) {
                this.showTcComAlert('선택된 데이터가 없습니다')
                return false
            }

            return this.getRowDataInIdx(currentItem.dataRow)
        },

        /**
         * 변경된 row 데이터의 index
         */
        getChangedRowIdx() {
            if (this.data.length == 0) {
                this.showTcComAlert('조회된 데이터가 없습니다')
                return []
            }

            return this.gridObj.modifyGrid()
        },

        /**
         * 변경된 row 데이터
         */
        getChangedRow() {
            this.gridView.commit()

            const changedItemIdx = this.gridObj.modifyGrid()
            const rows = this.getAllRow()

            if (changedItemIdx.length == 0) {
                this.showTcComAlert('변경된 데이터가 없습니다')
                return []
            }

            return changedItemIdx.reduce((acc, cur) => {
                const row = { ...rows[cur] }
                const status = this.getRowStateInIdx(cur)

                row.dataRow = cur
                row.status = status

                acc.push(row)
                return acc
            }, [])
        },

        /**
         * index 로 row 데이터 가져오기
         * @param {number} rowIdx 그리드 index
         */
        getRowDataInIdx(rowIdx) {
            let row = []
            if (rowIdx instanceof Array) {
                row = rowIdx.map((arr) => this.dataProvider.getJsonRow(arr))
            } else {
                row = this.dataProvider.getJsonRow(rowIdx)
            }

            return this.changeDateOnGridformat(row)
        },

        /**
         * index 로 데이터컬럼 값 가져오기
         * @param {number} itemIdx 아이템 index
         * @param {string} columnName 컬럼이름
         * @description rowInfo.itemIndex (not dataRow)
         */
        getColumnDataInIdx(itemIdx, columnName) {
            return this.gridView.getValue(itemIdx, columnName)
        },

        /**
         * index 로 데이터 상태값 가져오기
         * @param {number} rowIdx 그리드데이터 index
         * @description none, created, updated, deleted
         */
        getRowStateInIdx(rowIdx) {
            if (rowIdx instanceof Array) {
                return rowIdx.map((arr) => this.dataProvider.getRowState(arr))
            } else {
                return this.dataProvider.getRowState(rowIdx)
            }
        },

        /**
         * 컬럼정보
         * @param {string} fieldName 컬럼이름
         */
        getColumn(fieldName) {
            if (!fieldName) return
            return this.gridView.columnByName(fieldName)
        },

        /**
         * index 로 데이터 상태값 설정하기
         * @param {array|number} rowIdx 그리드데이터 index
         * @param {object} value 상태값
         */
        setRowStateInIdx(rowIdx, value) {
            if (rowIdx instanceof Array) {
                this.dataProvider.setRowStates(rowIdx, value)
            } else {
                this.dataProvider.setRowState(rowIdx, value)
            }
        },

        /**
         * 데이터 수정
         * @param {array|number} rowIdx 그리드데이터 index
         * @param {object} rowsData 컬럼이름
         */
        modifyRowData(rowIdx, rowsData) {
            let rowIdxs = rowIdx
            if (!(rowIdx instanceof Array)) {
                rowIdxs = [rowIdx]
            }

            const status = this.getRowStateInIdx(rowIdxs)

            rowIdxs.forEach((arr, idx) => {
                // 생성데이터가 아니면
                if (status[idx] != 'created') {
                    // __rowState를 가지고 있으면
                    if (this.isColumn('__rowState')) {
                        this.dataProvider.setValue(arr, '__rowState', 'updated')
                    }
                }
            })

            Object.keys(rowsData).forEach((fieldName) => {
                this.dataProvider.setValue(
                    rowIdx,
                    fieldName,
                    rowsData[fieldName]
                )
            })
        },

        /**
         * 데이터 추가
         * @param {array|object} rowsData 추가할 데이터 정보
         * @param {string} locate 추가위치
         * @param {string} [locate=first] 첫줄에 추가
         * @param {string} [locate=last] 마지막줄에 추가
         */
        addRowData(rows, locate = 'last') {
            const idx = locate == 'first' ? 0 : this.gridView.getItemCount()

            if (!(rows instanceof Array)) rows = [rows]

            rows.forEach((row) => {
                // __rowState를 가지고 있으면
                if (this.isColumn('__rowState')) {
                    rows.forEach((row) => (row.__rowState = 'created'))
                }

                this.dataProvider.insertRow(idx, row)
            })
        },

        /**
         * 데이터 삭제
         * @param {array|number} rowIdx 삭제할 그리드 인덱스 번호
         */
        removeRowData(rowIdx) {
            if (!(rowIdx instanceof Array)) rowIdx = [rowIdx]
            this.dataProvider.removeRows(rowIdx)
        },

        /**
         * 엑셀 파일 로드 후 콜백
         * @param {object|string} xlsData 로딩된 데이터
         * @description input[type=file] 에 의한 파일 선택 후 호출되는 콜백으로 사용됨
         */
        loadExcel(xlsData) {
            if (this.preventEvent.includes('clickExcelUpload')) {
                this.$emit('excelLoad', xlsData, this.accFileLoader.getFile())
            } else {
                this.$emit('excelUpload', xlsData, this.accFileLoader.getFile())
            }
        },

        /**
         * 페이징설정, 한 화면에 보여줄 페이징 개수 변경 시
         * @param {number} v 페이지 크기
         */
        changePageSize(v) {
            this.$emit('changePageSize', { pageNum: 1, pageSize: v })
        },

        /**
         * 페이징 번호 클릭 시
         * @param {number} n 페이지번호
         */
        clickMovePage(n) {
            this.$emit('movePage', { pageNum: n })
        },

        /**
         * 페이징 < 클릭 시
         */
        clickMovePagePrev() {
            const prevNo = this.pagingInfo.pageNum - 1
            if (prevNo < 1) {
                return this.showTcComAlert(`현재 첫번째 페이지 입니다.`)
            }

            this.$emit('movePage', { pageNum: prevNo })
        },

        /**
         * 페이징 > 클릭 시
         */
        clickMovePageNext() {
            const nextNo = this.pagingInfo.pageNum + 1
            if (nextNo > this.pagingInfo.totalPageCnt) {
                return this.showTcComAlert(`현재 마지막 페이지 입니다.`)
            }

            this.$emit('movePage', { pageNum: nextNo })
        },

        /**
         * 페이징 << 클릭 시
         */
        clickMovePageFirst() {
            this.$emit('movePage', { pageNum: 1 })
        },

        /**
         * 페이징 >> 클릭 시
         */
        clickMovePageLast() {
            this.$emit('movePage', { pageNum: this.pagingInfo.totalPageCnt })
        },

        /**
         * 그리드 내보내기
         * @param {object} opts 옵션
         * @property {boolean} opts.hideRow true면 데이터 없이 내보내기
         */
        exportGrid(opts = { hideRow: false }) {
            /**
             * options
             * @reference https://docs.realgrid.com/refs/grid-export-options
             */
            let dataProvider = this.dataProvider
            let gridView = this.gridView

            const options = Object.assign(
                {
                    type: 'excel',
                    target: 'local',
                    fileName: 'gridExportSample.xlsx',
                    showProgress: true,
                    progressMessage: '엑셀 내보내기중',
                    indicator: 'hidden',
                    header: 'visible',
                    footer: 'hidden',
                    compatibility: true, // true: MS Excel, false: MS Excel 2007
                    allColumns: false,
                    allItems: false,
                    // hideColumns: [],
                    // exportLayout: [],
                    // onlyCheckedItems: Boolean,
                },
                opts
            )

            if (options.hideRow) {
                dataProvider = new LocalDataProvider(false)
                dataProvider.setFields(this.gridMeta.fields)

                gridView = new GridView(this.$refs.trashGrid)
                gridView.setDataSource(dataProvider)
                gridView.setColumns(this.gridMeta.columns)
            }

            return new Promise((resolve) => {
                gridView.exportGrid(
                    Object.assign(options, {
                        done: () => {
                            if (options.hideRow) {
                                dataProvider.destroy()
                                gridView.destory()
                                this.$refs.trashGrid.innerHTML = ''
                            }

                            resolve(options)
                        },
                    })
                )
            })
        },

        /**
         * 그리드 데이터의 UTC Date 타입을 그리드 지정포맷으로 강제로 조정
         * @param {object|array} row 데이터
         * @description 수행함수
         */
        changeDateOnGridformat(row) {
            let target = row

            if (!(target instanceof Array)) {
                target = [row]
            }

            target.forEach((arr) => {
                Object.keys(arr).forEach((key, idx) => {
                    if (arr[key] instanceof Date) {
                        const dataFormat =
                            this.gridMeta.columns[
                                idx
                            ].fieldDatetimeFormat.toUpperCase()
                        arr[key] = moment(arr[key]).format(dataFormat)
                    }
                })
            })

            return row
        },

        openSelector() {
            this.$refs.accFileLoader.openSelector('excel')
        },
    },
}
</script>
