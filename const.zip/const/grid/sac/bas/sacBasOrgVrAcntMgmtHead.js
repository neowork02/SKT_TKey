import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'orgNm', // 조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgLvl', // 조직레벨
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNmShot', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accClNm', // 계좌구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effStaDt', // 시작일자
            //dataType: ValueType.DATETIME,
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effEndDt', // 종료일자
            //dataType: ValueType.DATETIME,
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bankNm', // 은행
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'acntNo', // 계좌번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgLevel', //
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accSeq', //
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accCl', //
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'acntSeq', //
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn', //
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', //
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            header: '조직명',
        },
        {
            name: 'accClNm',
            fieldName: 'accClNm',
            type: 'data',
            header: '계좌구분',
        },
        {
            name: 'effStaDt',
            fieldName: 'effStaDt',
            type: 'data',
            header: {
                text: '시작일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'effEndDt',
            fieldName: 'effEndDt',
            header: {
                text: '종료일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'bankNm',
            fieldName: 'bankNm',
            type: 'data',
            header: '은행',
        },
        {
            name: 'acntNo',
            fieldName: 'acntNo',
            type: 'data',
            header: '계좌번호',
        },
    ],
}
