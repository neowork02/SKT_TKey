import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'rowNum', //순번
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoCl1Nm', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pcode', // p코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStatus', // 거래상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt', // 거래개시일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndDt', // 거래종료일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgr', // 영업담당
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mrtgSetAmt', // 담보금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'baseDt', // 날짜
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'exptBondAmt', // 상계불가예상채권
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdayFeesAmt', // 당일채권증가_SKT수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdayCashAmt', // 당일채권증가_현금매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdayFreeAmt', // 당일채권증가_공기기매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toTecoAmt', // 당일채권증가_T에코환수
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdayRfndAmt', // 당일채권증가_오입금환불
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdayRcvbAmt', // 당일채권증가_기타미수금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dayTotAmt', // 당일채권계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdayDpstAmt', // 입금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'overBondAmt', // 연체채권(A)
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthToFeesAmt', // 당월채권누적_SKT수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthToCashAmt', // 당월채권누적_현금매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthToFreeAmt', // 당월채권누적_공기기매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthToTecoAmt', // 당월채권누적_T에코환수
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthToRfndAmt', // 당월채권누적_오입금환불
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthToRcvbAmt', // 당월채권누적_기타미수금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthTotAmt', // 당월채권누계(B)
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthToDpstAmt', // 입금누계(C)
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bondBamt', // 채권잔액(A+B+C)
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdayFeesPossRt', // 당월발생채권유형별점유비_SKT수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toCashRt', // 당월발생채권유형별점유비_현금매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdaySalePossRt', // 당월발생채권유형별점유비_공기기매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toTecoRt', // 당월발생채권유형별점유비_T에코환수
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdayRfndRt', // 당월발생채권유형별점유비_오입금환불
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdayUncltPossRt', // 당월발생채권유형별점유비_오입금환불
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bondRtnRt', // 채권회수율
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleLimitYn', // 연체채권판매제한대상점
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleLimitViltYn', // 판매제한위반여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'guideOverBondAmt', // 가이드초과채권( D-5)
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bondHundHoldYn', // 채권100만원이상보유점
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'crdtOverYn', // 여신초과여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'totCrdtAmt', // 총여신금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'balAmt', // 여신잔액
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            editable: false,
            header: '순번',
            type: 'data',
            width: '50',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            header: '조직코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: '조직',
            editable: false,
            type: 'data',
            width: '380',
            styleName: 'left-column',
        },
        {
            name: 'dealCoCl1Nm',
            fieldName: 'dealCoCl1Nm',
            header: '거래처구분',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            header: '거래처코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: '거래처명',
            editable: false,
            type: 'data',
            width: '150',
            styleName: 'left-column',
        },
        {
            name: 'pcode',
            fieldName: 'pcode',
            header: '매장코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            header: '거래상태',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            editable: false,
            header: {
                text: '거래개시일',
                showTooltip: false,
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            editable: false,
            header: {
                text: '거래종료일',
                showTooltip: false,
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'saleChrgr',
            fieldName: 'saleChrgr',
            editable: false,
            header: '영업담당',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'mrtgSetAmt',
            fieldName: 'mrtgSetAmt',
            editable: false,
            header: '담보금액',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },

        {
            name: 'baseDt',
            fieldName: 'baseDt',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '날짜',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'exptBondAmt',
            fieldName: 'exptBondAmt',
            editable: false,
            header: {
                text: '상계불가\n예상채권',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        // {
        //     name: 'bfBondAmt',
        //     fieldName: 'bfBondAmt',
        //     editable: false,
        //     header: '전일채권잔액',
        //     type: 'data',
        //     width: '100',
        //     dataType: ValueType.NUMBER,
        //     numberFormat: '#,###,###,###',
        //     footer: {
        //         text: '0',
        //         expression: 'sum',
        //         numberFormat: '#,###,###,###',
        //     },
        // },
        {
            name: 'tdayFeesAmt',
            fieldName: 'tdayFeesAmt',
            editable: false,
            header: 'SKT수납',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'tdayCashAmt',
            fieldName: 'tdayCashAmt',
            editable: false,
            header: '현금매출',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'tdayFreeAmt',
            fieldName: 'tdayFreeAmt',
            editable: false,
            header: '공기기매출',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toTecoAmt',
            fieldName: 'toTecoAmt',
            editable: false,
            header: 'T에코환수',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'tdayRfndAmt',
            fieldName: 'tdayRfndAmt',
            editable: false,
            header: '오입금환불',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'tdayRcvbAmt',
            fieldName: 'tdayRcvbAmt',
            editable: false,
            header: '기타미수금',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'dayTotAmt',
            fieldName: 'dayTotAmt',
            editable: false,
            header: '당일 채권계',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'tdayDpstAmt',
            fieldName: 'tdayDpstAmt',
            editable: false,
            header: '입금',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'overBondAmt',
            fieldName: 'overBondAmt',
            editable: false,
            header: '연체채권(A)',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthToFeesAmt',
            fieldName: 'mthToFeesAmt',
            editable: false,
            header: 'SKT수납',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthToCashAmt',
            fieldName: 'mthToCashAmt',
            editable: false,
            header: '현금매출',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthToFreeAmt',
            fieldName: 'mthToFreeAmt',
            editable: false,
            header: '공기기매출',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthToTecoAmt',
            fieldName: 'mthToTecoAmt',
            editable: false,
            header: 'T에코환수',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthToRfndAmt',
            fieldName: 'mthToRfndAmt',
            editable: false,
            header: '오입금환불',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthToRcvbAmt',
            fieldName: 'mthToRcvbAmt',
            editable: false,
            header: '기타미수금',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthTotAmt',
            fieldName: 'mthTotAmt',
            editable: false,
            header: {
                text: '당월채권\n누계(B)',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthToDpstAmt',
            fieldName: 'mthToDpstAmt',
            editable: false,
            header: '입금누계(C)',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'bondBamt',
            fieldName: 'bondBamt',
            editable: false,
            header: {
                text: '채권잔액\n(A+B+C)',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'tdayFeesPossRt',
            fieldName: 'tdayFeesPossRt',
            editable: false,
            header: 'SKT수납',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toCashRt',
            fieldName: 'toCashRt',
            editable: false,
            header: '현금매출',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'tdaySalePossRt',
            fieldName: 'tdaySalePossRt',
            editable: false,
            header: '공기기매출',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toTecoRt',
            fieldName: 'toTecoRt',
            editable: false,
            header: 'T에코환수',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'tdayRfndRt',
            fieldName: 'tdayRfndRt',
            editable: false,
            header: '오입금환불',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'tdayUncltPossRt',
            fieldName: 'tdayUncltPossRt',
            editable: false,
            header: '기타미수금',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'bondRtnRt',
            fieldName: 'bondRtnRt',
            editable: false,
            header: {
                text: '채권회수율\n(C/(A+B))',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '100',
            suffix: ' %',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },

        {
            name: 'saleLimitYn',
            fieldName: 'saleLimitYn',
            editable: false,
            header: {
                text: '연체채권판매\n제한대상점',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '100',
            dataType: ValueType.TEXT,
        },
        {
            name: 'saleLimitViltYn',
            fieldName: 'saleLimitViltYn',
            editable: false,
            header: {
                text: '판매제한\n위반여부',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '100',
            dataType: ValueType.TEXT,
        },
        {
            name: 'guideOverBondAmt',
            fieldName: 'guideOverBondAmt',
            editable: false,
            header: {
                text: '가이드초과\n채권(D-5)',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'bondHundHoldYn',
            fieldName: 'bondHundHoldYn',
            editable: false,
            header: {
                text: '채권100만원\n이상보유점',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '100',
            dataType: ValueType.TEXT,
        },
        {
            name: 'crdtOverYn',
            fieldName: 'crdtOverYn',
            editable: false,
            header: {
                text: '여신\n초과여부',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '100',
            dataType: ValueType.TEXT,
        },
        {
            name: 'totCrdtAmt',
            fieldName: 'totCrdtAmt',
            editable: false,
            header: '총여신금액',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'balAmt',
            fieldName: 'balAmt',
            editable: false,
            header: '여신잔액',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
    ],
    layout: [
        'rowNum',
        'orgNm',
        //'orgCd',
        'pcode',
        'dealcoCd',
        'dealcoNm',
        'dealCoCl1Nm',
        'dealStatus',
        'dealStaDt',
        'dealEndDt',
        'saleChrgr',
        'mrtgSetAmt',
        'baseDt',
        'exptBondAmt',
        {
            name: '당일채권증가 ',
            direction: 'horizontal',
            items: [
                'tdayFeesAmt',
                'tdayCashAmt',
                'tdayFreeAmt',
                'toTecoAmt',
                'tdayRfndAmt',
                'tdayRcvbAmt',
            ],
        },
        'dayTotAmt',
        'tdayDpstAmt',
        'overBondAmt',
        {
            name: '당월채권누적 ',
            direction: 'horizontal',
            items: [
                'mthToFeesAmt',
                'mthToCashAmt',
                'mthToFreeAmt',
                'mthToTecoAmt',
                'mthToRfndAmt',
                'mthToRcvbAmt',
            ],
        },
        'mthTotAmt',
        'mthToDpstAmt',
        'bondBamt',
        {
            name: '당월발생채권 유형별 점유비(%)',
            direction: 'horizontal',
            items: [
                'tdayFeesPossRt',
                'toCashRt',
                'tdaySalePossRt',
                'toTecoRt',
                'tdayRfndRt',
                'tdayUncltPossRt',
            ],
        },
        'bondRtnRt',
        'saleLimitYn',
        'saleLimitViltYn',
        'guideOverBondAmt',
        'bondHundHoldYn',
        'crdtOverYn',
        'totCrdtAmt',
        'balAmt',
    ],
}
