<!-----------------------------------------------
 * 업무그룹명: 기준정보 > 기타
 * 서브업무명: 승인통합관리
 * 설명: 승인통합관리 조회/입력/수정/삭제 한다.
 * 작성자: P180291
 * 작성일: 2022.09.06
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>승인통합관리</h1>
        <!-- // Tit -->
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/apm/intgAprvMgmt/helpers'

import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/apm/intgAprvMgmt'

export default {
    name: 'BasApmIntgAprvMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (!this.$store.hasModule('bas.apm.intgAprvMgmtStore')) {
            this.$store.registerModule('bas.apm.intgAprvMgmtStore', store)
        }
    },

    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.apm.intgAprvMgmtStore')) {
            this.$store.unregisterModule('bas.apm.intgAprvMgmtStore')
        }
    },
    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>
