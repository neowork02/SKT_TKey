import { ValueType } from 'realgrid'

export const BAS_BCO_SALE_DEALCO_HEADER = {
    fields: [
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgLvl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd0',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm0',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNmTree',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgNmTree',
            fieldName: 'orgNmTree',
            type: 'data',
            width: 350,
            styleName: 'left-column',
            header: {
                text: '조직',
            },
        },
        /*
        {
            name: 'orgNm0',
            fieldName: 'orgNm0',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업부',
            },
        },
        {
            name: 'orgNm1',
            fieldName: 'orgNm1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당',
            },
        },
        {
            name: 'orgNm2',
            fieldName: 'orgNm2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업팀',
            },
        },
        {
            name: 'orgNm3',
            fieldName: 'orgNm3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업파트',
            },
        },
*/
        {
            name: 'dealCoClCd1',
            fieldName: 'dealCoClCd1',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '매장구분',
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '매장명',
            },
            width: 250,
        },
    ],
}
