import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'pagingSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reservedDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usedCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cmpMsgId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lmsJobClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sendCl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sndOrg4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tranUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rtnTelNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'telNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'context',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sndMsg',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rsltValCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'pagingSeq',
            fieldName: 'pagingSeq',
            header: {
                text: 'No.',
            },
            editable: false,
            width: 40,
        },
        {
            name: 'reservedDtm',
            fieldName: 'reservedDtm',
            header: {
                text: '전송일시',
            },
            editable: false,
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'usedCd',
            fieldName: 'usedCd',
            header: {
                text: '구분',
            },
            editable: false,
            width: 50,
        },
        {
            name: 'trmsSeq',
            fieldName: 'trmsSeq',
            header: {
                text: '전송순번',
            },
            editable: false,
            width: 50,
        },
        {
            name: 'cmpMsgId',
            fieldName: 'cmpMsgId',
            header: {
                text: '전송번호',
            },
            editable: false,
        },
        {
            name: 'lmsJobClCd',
            fieldName: 'lmsJobClCd',
            header: {
                text: '업무구분',
            },
            editable: false,
        },
        {
            name: 'sendCl',
            fieldName: 'sendCl',
            header: {
                text: '전송구분',
            },
            editable: false,
            width: 50,
        },
        {
            name: 'sndOrg4',
            fieldName: 'sndOrg4',
            header: {
                text: '발신소속PT',
            },
            editable: false,
        },
        {
            name: 'tranUserNm',
            fieldName: 'tranUserNm',
            header: {
                text: '발신자명',
            },
            editable: false,
        },
        {
            name: 'tranUserId',
            fieldName: 'tranUserId',
            header: {
                text: '발신자ID',
            },
            editable: false,
        },
        {
            name: 'rtnTelNo',
            fieldName: 'rtnTelNo',
            header: {
                text: '발신번호',
            },
            editable: false,
        },
        {
            name: 'telNo',
            fieldName: 'telNo',
            header: {
                text: '수신번호',
            },
            editable: false,
        },
        {
            name: 'context',
            fieldName: 'context',
            header: {
                text: '전체메시지',
            },
            editable: false,
        },
        {
            name: 'sndMsg',
            fieldName: 'sndMsg',
            header: {
                text: '분할메시지',
            },
            editable: false,
        },
        {
            name: 'rsltValCd',
            fieldName: 'rsltValCd',
            header: {
                text: '전송결과',
            },
            editable: false,
            width: 50,
        },
    ],
}
