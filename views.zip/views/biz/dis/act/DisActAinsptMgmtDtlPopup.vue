<!-----------------------------------------------
 * 업무그룹명: 재고실사관리
 * 서브업무명: 재고실사관리상세팝업
 * 설명: 재고실사상세내역을 조회한다.
 * 작성자: P179890
 * 작성일: 2022.08.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<!-- 
-->
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1500px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">재고실사관리상세</p>
                <div class="layerCont">
                    <!-- <ul class="btn_area top">
                        <li class="left"></li>
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="closeBtn"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton>
                        </li>
                    </ul> -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    labelName="조직"
                                    :objAuth="objAuth"
                                    v-model="searchParam.orgNm"
                                    :codeVal="searchParam.orgCd"
                                    :disabledAfter="true"
                                    :disabled="true"
                                >
                                </TCComInputSearchText>
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    labelName="보유처"
                                    :objAuth="objAuth"
                                    v-model="searchParam.hldPlcNm"
                                    :codeVal="searchParam.hldPlcId"
                                    :disabledAfter="true"
                                    :disabled="true"
                                >
                                </TCComInputSearchText>
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div4">
                                <TCComDatePicker
                                    labelName="기준일자"
                                    :calType="calType"
                                    v-model="searchParam.strdDt"
                                    :disabled="true"
                                >
                                </TCComDatePicker>
                            </div>
                            <!-- //item 1-3 -->
                        </div>
                        <!-- //Search_line 1 -->
                    </div>
                    <!-- //Search_div -->
                    <!-- gridWrap -->
                    <div class="contBoth">
                        <div class="div6_4 cont1 left">
                            <div class="gridWrap">
                                <TCRealGridHeader
                                    id="gridHeader1"
                                    ref="gridHeader1"
                                    gridTitle="TkeyTaka보유"
                                    :gridObj="gridObj1"
                                    :isPageRows="true"
                                    :isExceldown="true"
                                    @excelDownBtn="exportGridBtn('1')"
                                />
                                <!-- // SubTit -->
                                <!-- gridWrap -->
                                <TCRealGrid
                                    id="grid1"
                                    ref="grid1"
                                    :fields="view1.fields"
                                    :columns="view1.columns"
                                    :styles="gridStyle"
                                />
                            </div>
                        </div>
                        <div class="div6_4 cont2 right">
                            <!-- SubTit -->
                            <div class="gridWrap">
                                <TCRealGridHeader
                                    id="gridHeader2"
                                    ref="gridHeader2"
                                    gridTitle="재고실사"
                                    :gridObj="gridObj2"
                                    :isPageRows="true"
                                    :isExceldown="true"
                                    @excelDownBtn="exportGridBtn('2')"
                                >
                                </TCRealGridHeader>
                                <TCRealGrid
                                    id="grid2"
                                    ref="grid2"
                                    :fields="view2.fields"
                                    :columns="view2.columns"
                                    :styles="gridStyle"
                                />
                            </div>
                            <!-- //gridWrap -->
                        </div>
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeader3"
                                ref="gridHeader3"
                                gridTitle="TkeyTaka에만 보유하고 있는 재고"
                                :gridObj="gridObj3"
                                :isPageRows="true"
                                :isExceldown="true"
                                @excelDownBtn="exportGridBtn('3')"
                            />
                            <!-- // SubTit -->
                            <!-- gridWrap -->
                            <TCRealGrid
                                id="grid3"
                                ref="grid3"
                                :fields="view3.fields"
                                :columns="view3.columns"
                                :styles="gridStyle"
                            />
                        </div>
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeader4"
                                ref="gridHeader4"
                                gridTitle="보유처에만 보유하고 있는 재고"
                                :gridObj="gridObj4"
                                :isPageRows="true"
                                :isExceldown="true"
                                @excelDownBtn="exportGridBtn('4')"
                            />
                            <!-- // SubTit -->
                            <!-- gridWrap -->
                            <TCRealGrid
                                id="grid4"
                                ref="grid4"
                                :fields="view4.fields"
                                :columns="view4.columns"
                                :styles="gridStyle"
                            />
                        </div>
                    </div>
                    <div class="textareaLayer_wrap">
                        <TCComTextArea
                            v-model="rmks"
                            labelName="비고"
                            :rows="3"
                            class="boxtype"
                            :maxLength="300"
                            :disabled="true"
                        />
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<!--style scoped>
</style-->
<script>
import {
    DisActAinsptMgmt_GRID_HEADER1,
    DisActAinsptMgmt_GRID_HEADER2,
    DisActAinsptMgmt_GRID_HEADER3,
    DisActAinsptMgmt_GRID_HEADER4,
} from '@/const/grid/dis/act/disActAinsptMgmtHeader.js'
import actApi from '@/api/biz/dis/act/disActAinsptMgmt.js'
import attachedFileApi from '@/api/common/attachedFile'
import commonApi from '@/api/common/prototype'
import { CommonUtil, CommonGrid, CommonMsg } from '@/utils'
// import moment from 'moment'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'DisActAinsptMgmtDtlPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        params: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            alertHeadTxt: '재고실사관리상세',
            alertBodyTxt: '',
            calType: 'D',
            gridData: {},
            gridObj1: {},
            gridHeaderObj1: {},
            gridObj2: {},
            gridHeaderObj2: {},
            gridObj3: {},
            gridHeaderObj3: {},
            gridObj4: {},
            gridHeaderObj4: {},
            view1: DisActAinsptMgmt_GRID_HEADER1,
            view2: DisActAinsptMgmt_GRID_HEADER2,
            view3: DisActAinsptMgmt_GRID_HEADER3,
            view4: DisActAinsptMgmt_GRID_HEADER4,
            objAuth: {},
            rmks: '',
            searchForms: {},
            searchParam: {
                // 요청파라미터
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLevel: '', // 조직레벨
                orgCdLvl0: '', // 레벨0조직코드
                strdDt: '', // 기준일
                hldPlcId: '', // 보유처코드
                hldPlcNm: '', // 보유처명
            },
            gridStyle: {
                height: '100px', //그리드 높이 조절
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        params: {
            handler: function (value) {
                this.searchParam.orgCd = value['orgCd']
                this.searchParam.orgNm = value['orgNm']
                this.searchParam.orgLevel = value['orgLevel']
                this.searchParam.orgCdLvl0 = value['orgCdLvl0']
                this.searchParam.strdDt = CommonUtil.onlyNumber(value['strdDt'])
                this.searchParam.hldPlcId = value['hldPlcId']
                this.searchParam.hldPlcNm = value['hldPlcNm']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.gridData = this.gridSetData()
    },
    async mounted() {
        // New T.key+ 보유
        this.gridObj1 = this.$refs.grid1
        this.gridHeaderObj1 = this.$refs.gridHeader1
        this.gridObj1.setGridState(false)
        this.gridObj1.gridView.setRowIndicator({ visible: true })
        // 재고실사
        this.gridObj2 = this.$refs.grid2
        this.gridHeaderObj2 = this.$refs.gridHeader2
        this.gridObj2.setGridState(false, false, true)
        this.gridObj2.gridView.setRowIndicator({ visible: true })
        // New T.key+에만 보유하고 있는 재고
        this.gridObj3 = this.$refs.grid3
        this.gridHeaderObj3 = this.$refs.gridHeader3
        this.gridObj3.setGridState(false)
        this.gridObj3.gridView.setRowIndicator({ visible: true })
        // 보유처에만 보유하고 있는 재고
        this.gridObj4 = this.$refs.grid4
        this.gridHeaderObj4 = this.$refs.gridHeader4
        this.gridObj4.setGridState(false)
        this.gridObj4.gridView.setRowIndicator({ visible: true })
        const commData = await this.getCommCodeList('ZDIS_C_00100')
        let columnValues = []
        let columnLabels = []
        if (commData.length) {
            commData.forEach((data) => {
                columnValues.push(data.commCdVal)
                columnLabels.push(data.commCdValNm)
            })
        }
        // 그리드 컬럼 콤보박스 데이터 설정
        this.gridObj2.gridView.setColumnProperty(
            'disSt',
            'values',
            columnValues
        )
        this.gridObj2.gridView.setColumnProperty(
            'disSt',
            'labels',
            columnLabels
        )
        this.gridObj2.gridView.setColumnProperty('disSt', 'lookupDisplay', true)

        this.getActualTkeyHoldList()
    },
    methods: {
        init() {},
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 100000, '', '')
        },
        // Grid ExcelDown
        exportGridBtn: function (flag) {
            let rowCount = 0
            let apiUrl = ''
            switch (flag) {
                case '1':
                    // New T.key+ 보유
                    rowCount = this.gridObj1.dataProvider.getRowCount()
                    apiUrl =
                        '/api/v1/backend-long/resource/dis/act/disActOnTkeyExcels'
                    break
                case '2':
                    // 재고실사
                    rowCount = this.gridObj2.dataProvider.getRowCount()
                    apiUrl =
                        '/api/v1/backend-long/resource/dis/act/disActOnActExcels'
                    break
                case '3':
                    // New T.key+에만 보유하고 있는 재고
                    rowCount = this.gridObj3.dataProvider.getRowCount()
                    apiUrl =
                        '/api/v1/backend-long/resource/dis/act/disActOnlyTkeyExcels'
                    break
                case '4':
                    // 보유처에만 보유하고 있는 재고
                    rowCount = this.gridObj4.dataProvider.getRowCount()
                    apiUrl =
                        '/api/v1/backend-long/resource/dis/act/disActOnlyActExcels'
                    break
                default:
                    break
            }
            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }
            attachedFileApi.downLoadFile(apiUrl, this.searchForms)
        },
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        getActualTkeyHoldList() {
            this.searchForms = { ...this.searchParam }
            this.searchForms.strdDt = CommonUtil.onlyNumber(
                this.searchForms.strdDt
            )
            actApi.getActualTkeyHoldList(this.searchForms).then((res) => {
                // New T.key+ 보유
                // LIST일련번호별 정렬
                let sortList = []
                sortList =
                    res.result.onTkeyList.length > 0
                        ? _.sortBy(res.result.onTkeyList, 'serNum')
                        : res.result.onTkeyList
                this.gridObj1.setRows(sortList)
                this.gridHeaderObj1.setPageCount({
                    totalDataCnt: res.result.onTkeyList.length,
                })
                // 재고실사
                this.gridObj2.setRows(res.result.onActList)
                this.gridHeaderObj2.setPageCount({
                    totalDataCnt: res.result.onActList.length,
                })

                // New T.key+에만 보유하고 있는 재고
                // LIST일련번호별 정렬
                sortList =
                    res.result.onlyTkeyList.length > 0
                        ? _.sortBy(res.result.onlyTkeyList, 'serNum')
                        : res.result.onlyTkeyList
                this.gridObj3.setRows(sortList)
                this.gridHeaderObj3.setPageCount({
                    totalDataCnt: res.result.onlyTkeyList.length,
                })

                // 보유처에만 보유하고 있는 재고
                this.gridObj4.setRows(res.result.onlyActList)
                this.gridHeaderObj4.setPageCount({
                    totalDataCnt: res.result.onlyActList.length,
                })

                // 비고
                if (res.result.onTkeyList.length > 0) {
                    this.rmks = res.result.onTkeyList[0].rmks
                }
            })
        },
        closeBtn() {
            this.activeOpen = false
        },
        // 공통코드조회
        async getCommCodeList(codeId) {
            return await commonApi.getCommonCodeList(codeId)
        },
    },
}
</script>
