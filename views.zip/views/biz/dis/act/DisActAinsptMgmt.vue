<!-----------------------------------------------
 * 업무그룹명: 재고실사관리
 * 서브업무명: 재고실사관리
 * 설명: 재고실사내역을 조회/검증한다.
 * 작성자: P179890
 * 작성일: 2022.07.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<!-- 
-->
<template>
    <div class="content">
        <!-- Tit -->
        <h1>재고실사관리</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="dataVrt"
                    >검증</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="getActualTkeyHoldList"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="delBtn"
                    :objAuth="this.objAuth"
                    :disabled="delDisabled"
                >
                    삭제
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        @enterKey="onAuthOrgTreeIconClick"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :objAuth="this.objAuth"
                        v-model="reqParam.orgNm"
                        :codeVal="reqParam.orgCd"
                        :disabledAfter="true"
                        :eRequired="true"
                        :disabled="searchDisable"
                    >
                    </TCComInputSearchText>
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="reqParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="보유처"
                        @enterKey="onDealcoIconClick"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                        :objAuth="this.objAuth"
                        v-model="reqParam.hldPlcNm"
                        :codeVal="reqParam.hldPlcId"
                        :disabledAfter="true"
                        :eRequired="true"
                        :disabled="searchDisable"
                    >
                    </TCComInputSearchText>
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchDealcoParam"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="기준일자"
                        :calType="calType"
                        v-model="setDate"
                        :disabled="true"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 1-3 -->
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- //Search_div -->
        <!-- gridWrap -->
        <div class="contBoth">
            <div class="div6_4 cont1 left">
                <div class="gridWrap">
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="TkeyTaka 보유"
                        :gridObj="gridObj1"
                        :isExceldown="true"
                        :isPageRows="true"
                        @excelDownBtn="exportGridBtn('1')"
                    />
                    <!-- // SubTit -->
                    <!-- gridWrap -->
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :fields="view1.fields"
                        :columns="view1.columns"
                        :styles="gridStyle"
                    />
                </div>
            </div>
            <div class="div6_4 cont2 right">
                <!-- SubTit -->
                <div class="gridWrap">
                    <TCRealGridHeader
                        id="gridHeader2"
                        ref="gridHeader2"
                        gridTitle="재고실사"
                        :gridObj="gridObj2"
                        :isDelRow="true"
                        :isPageRows="true"
                        :isExceldown="isSearch"
                        @excelDownBtn="exportGridBtn('2')"
                        @chkDelRowBtn="gridchkDelRowBtn"
                    >
                        <template #gridBtnArea>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_fileadd"
                                labelName="상품입력"
                                :objAuth="objAuth"
                                @click="addProdPopup"
                            />
                        </template>
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid2"
                        ref="grid2"
                        :fields="view2.fields"
                        :columns="view2.columns"
                        :styles="gridStyle"
                    />
                </div>
                <!-- //gridWrap -->
            </div>
            <div class="gridWrap">
                <TCRealGridHeader
                    id="gridHeader3"
                    ref="gridHeader3"
                    gridTitle="TkeyTaka에만 보유하고 있는 재고"
                    :gridObj="gridObj3"
                    :isExceldown="true"
                    :isPageRows="true"
                    @excelDownBtn="exportGridBtn('3')"
                />
                <!-- // SubTit -->
                <!-- gridWrap -->
                <TCRealGrid
                    id="grid3"
                    ref="grid3"
                    :fields="view3.fields"
                    :columns="view3.columns"
                    :styles="gridStyle"
                />
            </div>
            <div class="gridWrap">
                <TCRealGridHeader
                    id="gridHeader4"
                    ref="gridHeader4"
                    gridTitle="보유처에만 보유하고 있는 재고"
                    :gridObj="gridObj4"
                    :isExceldown="true"
                    :isPageRows="true"
                    @excelDownBtn="exportGridBtn('4')"
                />
                <!-- // SubTit -->
                <!-- gridWrap -->
                <TCRealGrid
                    id="grid4"
                    ref="grid4"
                    :fields="view4.fields"
                    :columns="view4.columns"
                    :styles="gridStyle"
                />
            </div>
        </div>
        <div class="textareaLayer_wrap">
            <TCComTextArea
                v-model="rmks"
                labelName="비고"
                :rows="3"
                class="boxtype"
                :maxLength="300"
            />
        </div>
        <div class="btn_area_bottom">
            <TCComButton eClass="btn_ty02_point" :eLarge="true" @click="saveBtn"
                >저장</TCComButton
            >
        </div>
        <!-- //gridWrap -->
        <!-- 팝업 시작 -->
        <DisActProdInsPopup
            v-if="showAddProdPop === true"
            :dialogShow.sync="showAddProdPop"
            :params.sync="addProdPopParam"
            @returnVal="returnProdList"
        />
    </div>
</template>

<!--style scoped>
</style-->
<script>
import {
    DisActAinsptMgmt_GRID_HEADER1,
    DisActAinsptMgmt_GRID_HEADER2,
    DisActAinsptMgmt_GRID_HEADER3,
    DisActAinsptMgmt_GRID_HEADER4,
} from '@/const/grid/dis/act/disActAinsptMgmtHeader.js'
import actApi from '@/api/biz/dis/act/disActAinsptMgmt.js'
import attachedFileApi from '@/api/common/attachedFile'
import commonApi from '@/api/common/prototype'
import { CommonUtil, CommonGrid, CommonMsg } from '@/utils'
import moment from 'moment'
import CommonMixin from '@/mixins'
import _ from 'lodash'
//====================내부조직팝업(권한)팝업====================
import DisActProdInsPopup from '@/views/biz/dis/act/DisActProdInsPopup'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================내부거래처(권한조직)====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'

export default {
    name: 'DisActAinsptMgmt',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
        DisActProdInsPopup,
    },
    data() {
        return {
            //====================조직 팝업====================
            authOrgParam: {},
            showBcoAuthOrgTrees: false,
            resultAuthOrgTreeRows: [],
            //====================조직 팝업====================
            //====================내부거래처(권한 조직))====================
            basBcoDealcoShow: false,
            searchDealcoParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY',
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC',
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한 조직)==================
            isSearch: false,
            searchDisable: false,
            delDisabled: false,
            alertHeadTxt: '재고실사관리',
            alertBodyTxt: '',
            calType: 'D',
            gridData: {},
            gridObj1: {},
            gridHeaderObj1: {},
            gridObj2: {},
            gridHeaderObj2: {},
            gridObj3: {},
            gridHeaderObj3: {},
            gridObj4: {},
            gridHeaderObj4: {},
            view1: DisActAinsptMgmt_GRID_HEADER1,
            view2: DisActAinsptMgmt_GRID_HEADER2,
            view3: DisActAinsptMgmt_GRID_HEADER3,
            view4: DisActAinsptMgmt_GRID_HEADER4,
            objAuth: {},
            searchForms: {},
            addProdPopParam: {},
            showAddProdPop: false,
            rmks: '',
            listSearch: {},
            reqParam: {
                // 요청파라미터
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLevel: '', // 조직레벨
                orgCdLvl0: '', // 레벨0조직코드
                strdDt: '', // 기준일
                hldPlcId: '', // 보유처코드
                hldPlcNm: '', // 보유처명
            },
            gridStyle: {
                height: '100px', //그리드 높이 조절
            },
        }
    },
    computed: {
        setDate: {
            get() {
                return this.reqParam.strdDt
            },
            set(val) {
                this.reqParam.strdDt = val
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.reqParam.basMth = CommonUtil.onlyNumber(val).substr(0, 6)
                // 내부거래처 기준년월 파라미터 set
                this.searchDealcoParam.basDay = CommonUtil.onlyNumber(
                    val
                ).substr(0, 8)
                return val
            },
        },
    },
    watch: {},
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        // New T.key+ 보유
        this.gridObj1 = this.$refs.grid1
        this.gridHeaderObj1 = this.$refs.gridHeader1
        this.gridObj1.setGridState(false)
        this.gridObj1.gridView.setRowIndicator({ visible: true })
        // 재고실사
        this.gridObj2 = this.$refs.grid2
        this.gridHeaderObj2 = this.$refs.gridHeader2
        this.gridObj2.setGridState(false, false, true)
        this.gridObj2.gridView.setRowIndicator({ visible: true })
        // New T.key+에만 보유하고 있는 재고
        this.gridObj3 = this.$refs.grid3
        this.gridHeaderObj3 = this.$refs.gridHeader3
        this.gridObj3.setGridState(false)
        this.gridObj3.gridView.setRowIndicator({ visible: true })
        // 보유처에만 보유하고 있는 재고
        this.gridObj4 = this.$refs.grid4
        this.gridHeaderObj4 = this.$refs.gridHeader4
        this.gridObj4.setGridState(false)
        this.gridObj4.gridView.setRowIndicator({ visible: true })

        this.getCommCodeList(this.gridObj2, 'ZDIS_C_00100', 'disSt')

        this.init()
    },
    methods: {
        init() {
            this.delDisabled = true
            this.isSearch = false
            //검색영역
            this.reqParam.strdDt = moment(new Date()).format('YYYY-MM-DD') // 기준일자
            // 세션정보 set
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                // 출고처
                this.reqParam['hldPlcId'] = this.userInfo['dealcoCd']
                this.reqParam['hldPlcNm'] = this.userInfo['dealcoNm']
                // 조직
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLevel'] = this.orgInfo['orgLvl']
                this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']

                if (this.userInfo['attcClCd'] == '4') {
                    this.searchDisable = true
                }
            } else {
                this.searchDisable = false
            }
            this.rmks = ''
            this.gridInit()
        },
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 100000, '', '')
        },
        gridchkDelRowBtn: function () {
            this.gridHeaderObj2.chkDelRow(this.gridData)
        },
        // Grid ExcelDown
        exportGridBtn: function (flag) {
            let rowCount = 0
            let apiUrl = ''
            switch (flag) {
                case '1':
                    // New T.key+ 보유
                    rowCount = this.gridObj1.dataProvider.getRowCount()
                    apiUrl =
                        '/api/v1/backend-long/resource/dis/act/disActOnTkeyExcels'
                    break
                case '2':
                    // 재고실사
                    rowCount = this.gridObj2.dataProvider.getRowCount()
                    apiUrl =
                        '/api/v1/backend-long/resource/dis/act/disActOnActExcels'
                    break
                case '3':
                    // New T.key+에만 보유하고 있는 재고
                    rowCount = this.gridObj3.dataProvider.getRowCount()
                    apiUrl =
                        '/api/v1/backend-long/resource/dis/act/disActOnlyTkeyExcels'
                    break
                case '4':
                    // 보유처에만 보유하고 있는 재고
                    rowCount = this.gridObj4.dataProvider.getRowCount()
                    apiUrl =
                        '/api/v1/backend-long/resource/dis/act/disActOnlyActExcels'
                    break
                default:
                    break
            }
            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }
            attachedFileApi.downLoadFile(apiUrl, this.searchForms)
        },
        // 초기화 버튼 이벤트
        clearPage() {
            CommonUtil.clearPage(this, 'reqParam')
            this.init()
        },
        // 삭제버튼 이벤트
        async delBtn() {
            const confirm = await this.showTcComConfirm(
                CommonMsg.getMessage('MSG_00102', '전체')
            )

            if (confirm) {
                // 로직처리
                this.deleteActualTkeyHold()
            }
        },
        deleteActualTkeyHold() {
            const deleteParam = {
                strdDt: CommonUtil.onlyNumber(this.reqParam.strdDt),
                hldPlcId: this.reqParam.hldPlcId,
            }
            actApi.deleteActualTkeyHold(deleteParam).then((res) => {
                // 정상등록
                if (res === 1) {
                    // 조회
                    // MSG_00065
                    this.openAlert(CommonMsg.getMessage('MSG_00065', ''))
                    this.getActualTkeyHoldList()
                }
            })
        },
        // 비고저장버튼 이벤트
        saveBtn() {
            const rowCount = this.gridObj1.dataProvider.getRowCount()
            if (rowCount == 0) {
                this.openAlert(
                    '보유 데이터가 조회되지 않았습니다.\n조회 후 사용하시기 바랍니다.'
                )
                return
            }

            if (_.isEmpty(this.rmks.trim())) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '비고'))
                this.rmks = ''
                return
            }

            const saveParam = {
                strdDt: CommonUtil.onlyNumber(this.reqParam.strdDt),
                hldPlcId: this.reqParam.hldPlcId,
                rmks: this.rmks.trim(),
            }
            actApi.saveActualTkeyRmks(saveParam).then((res) => {
                // 정상등록
                if (res === 1) {
                    // 조회
                    // MSG_00065
                    this.openAlert(CommonMsg.getMessage('MSG_00006', ''))
                }
            })
        },
        isValidChk() {
            if (_.isEmpty(this.reqParam.strdDt)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '기준일자'))
                return false
            }
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.openAlert(CommonMsg.getMessage('MSG_00121', '조직;조회'))
                return false
            }
            if (_.isEmpty(this.reqParam.hldPlcId)) {
                this.openAlert(CommonMsg.getMessage('MSG_00121', '보유처;조회'))
                return false
            }
            return true
        },
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        // 검증버튼 이벤트
        async dataVrt() {
            const rowCount = this.gridObj1.dataProvider.getRowCount()
            if (rowCount == 0) {
                this.openAlert(
                    '보유 데이터가 조회되지 않았습니다.\n조회 후 사용하시기 바랍니다.'
                )
                return
            }
            const confirm = await this.showTcComConfirm(
                CommonMsg.getMessage('MSG_00136', '입력하신 정보를 검증')
            )

            if (confirm) {
                // 로직처리
                this.saveActualTkeyHold()
            }
        },
        saveActualTkeyHold() {
            // 보상 데이터 저장
            // New T.key+ 보유 리스트
            let onTkeyList = this.gridObj1.dataProvider.getJsonRows(0, -1)
            // 재고실사 리스트
            let onActList = this.gridObj2.dataProvider.getJsonRows(0, -1)

            let saveData = {
                strdDt: CommonUtil.onlyNumber(this.reqParam.strdDt),
                hldPlcId: this.reqParam.hldPlcId,
                rmks: this.rmks,
                onTkeyList: this.gridObj1.dataProvider.getJsonRows(0, -1),
                onActList: this.gridObj2.dataProvider.getJsonRows(0, -1),
            }
            onActList.forEach((item1) => {
                onTkeyList.forEach((item2, i) => {
                    if (
                        item1['serNum'] == item2['serNum'] &&
                        item1['colorCd'] == item2['colorCd'] &&
                        item1['prodCd'] == item2['prodCd']
                    ) {
                        onTkeyList.splice(i, 1)
                    }
                })
            })

            // New T.key+에만 보유하고 있는 재고 set
            saveData.onlyTkeyList = onTkeyList
            // this.gridObj3.setRows(onTkeyList)

            onTkeyList = this.gridObj1.dataProvider.getJsonRows(0, -1)
            onActList = this.gridObj2.dataProvider.getJsonRows(0, -1)

            onTkeyList.forEach((item1) => {
                onActList.forEach((item2, i) => {
                    if (
                        item1['serNum'] == item2['serNum'] &&
                        item1['colorCd'] == item2['colorCd'] &&
                        item1['prodCd'] == item2['prodCd']
                    ) {
                        onActList.splice(i, 1)
                    }
                })
            })
            // 보유처에만 보유하고 있는 재고 set
            saveData.onlyActList = onActList
            // this.gridObj4.setRows(onActList)
            actApi.saveActualTkeyHold(saveData).then((res) => {
                // 정상등록
                if (res === 1) {
                    // 조회
                    this.openAlert(CommonMsg.getMessage('MSG_00006', '검증'))
                    this.getActualTkeyHoldList()
                }
            })
        },
        getActualTkeyHoldList() {
            if (!this.isValidChk()) {
                return false
            }
            //그리드 초기화
            this.gridInit()

            this.searchForms = { ...this.reqParam }
            this.searchForms.strdDt = CommonUtil.onlyNumber(
                this.searchForms.strdDt
            )
            actApi.getActualTkeyHoldList(this.searchForms).then((res) => {
                // New T.key+ 보유
                // LIST일련번호별 정렬
                let sortList = []
                sortList =
                    res.result.onTkeyList.length > 0
                        ? _.sortBy(res.result.onTkeyList, 'serNum')
                        : res.result.onTkeyList
                // this.gridObj1.setRows(res.result.onTkeyList)
                this.gridObj1.setRows(sortList)
                this.gridHeaderObj1.setPageCount({
                    totalDataCnt: res.result.onTkeyList.length,
                })
                // 재고실사
                this.gridObj2.setRows(res.result.onActList)
                this.gridHeaderObj2.setPageCount({
                    totalDataCnt: res.result.onActList.length,
                })

                // New T.key+에만 보유하고 있는 재고
                // LIST일련번호별 정렬
                sortList =
                    res.result.onlyTkeyList.length > 0
                        ? _.sortBy(res.result.onlyTkeyList, 'serNum')
                        : res.result.onlyTkeyList
                this.gridObj3.setRows(sortList)
                this.gridHeaderObj3.setPageCount({
                    totalDataCnt: res.result.onlyTkeyList.length,
                })

                // 보유처에만 보유하고 있는 재고
                this.gridObj4.setRows(res.result.onlyActList)
                this.gridHeaderObj4.setPageCount({
                    totalDataCnt: res.result.onlyActList.length,
                })

                // 비고
                if (res.result.onTkeyList.length > 0) {
                    this.rmks = res.result.onTkeyList[0].rmks
                }

                this.isSearch = true
                if (
                    res.result.onActList.length +
                        res.result.onlyTkeyList.length +
                        res.result.onlyActList.length >
                    0
                ) {
                    this.delDisabled = false
                } else {
                    this.delDisabled = true
                }
            })
        },
        // 재고실사 상품입력 팝업버튼 클릭 이벤트
        addProdPopup() {
            // New T.key+ 보유 그리드 데이터 수
            const rowCount = this.gridObj1.dataProvider.getRowCount()
            if (rowCount == 0) {
                this.openAlert(
                    '보유 데이터가 조회되지 않았습니다.\n조회 후 사용하시기 바랍니다.'
                )
                return
            }

            this.gridObj3.gridInit()
            this.gridObj4.gridInit()

            // 상품입력팝업 호출
            // 상품입력팝업 파라미터 set
            this.addProdPopParam = {
                aplyDt: this.reqParam.strdDt,
                hldPlcId: this.reqParam.hldPlcId,
                parentList: this.gridObj2.dataProvider.getJsonRows(0, -1),
            }
            this.showAddProdPop = true
        },
        // 그리드초기화
        gridInit() {
            // 그리드초기화
            this.gridObj1.gridInit()
            this.gridHeaderObj1.setPageCount({ totalDataCnt: 0 })
            this.gridObj2.gridInit()
            this.gridHeaderObj2.setPageCount({ totalDataCnt: 0 })
            this.gridObj3.gridInit()
            this.gridHeaderObj3.setPageCount({ totalDataCnt: 0 })
            this.gridObj4.gridInit()
            this.gridHeaderObj4.setPageCount({ totalDataCnt: 0 })
        },
        returnProdList(returnVal) {
            if (returnVal.length > 0) {
                returnVal.forEach((data) => {
                    // 상품 append
                    this.gridObj2.dataProvider.insertRow(
                        this.gridObj2.gridView.getItemCount(),
                        data
                    )
                })
            }
        },
        // 공통코드조회
        getCommCodeList(gridObj, codeId, columnId) {
            commonApi.getCommonCodeList(codeId).then((res) => {
                let columnValues = []
                let columnLabels = []
                if (res.length) {
                    res.forEach((data) => {
                        columnValues.push(data.commCdVal)
                        columnLabels.push(data.commCdValNm)
                    })
                }
                // 그리드 컬럼 콤보박스 데이터 설정
                gridObj.gridView.setColumnProperty(
                    columnId,
                    'values',
                    columnValues
                )
                gridObj.gridView.setColumnProperty(
                    columnId,
                    'labels',
                    columnLabels
                )
                gridObj.gridView.setColumnProperty(
                    columnId,
                    'lookupDisplay',
                    true
                )
            })
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.authOrgParam)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLevel = _.get(res[0], 'orgLvl')
                        this.reqParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            this.authOrgParam['orgNm'] = this.reqParam['orgNm']
            this.authOrgParam['orgCd'] = this.reqParam['orgCd']
            this.authOrgParam['orgLvl'] = this.reqParam['orgLevel']
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            if (
                !_.isEmpty(this.reqParam.orgCd) &&
                this.reqParam.orgCd != retrunData.orgCd
            ) {
                this.reqParam.hldPlcId = ''
                this.reqParam.hldPlcNm = ''
                this.gridInit()
                this.isSearch = false
                this.delDisabled = true
            }
            this.reqParam.orgCd = _.get(retrunData, 'orgCd')
            this.reqParam.orgNm = _.get(retrunData, 'orgNm')
            this.reqParam.orgLevel = _.get(retrunData, 'orgLvl')
            this.reqParam.orgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.orgCd = ''
            this.reqParam.orgLevel = ''
            this.reqParam.orgCdLvl0 = ''
            this.reqParam.hldPlcId = ''
            this.reqParam.hldPlcNm = ''
            this.gridInit()
            this.delDisabled = true
            this.isSearch = false
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcoParam)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.reqParam.hldPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.hldPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return
            }
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.searchDealcoParam['orgCd'] = this.reqParam['orgCd']
            this.searchDealcoParam['orgNm'] = this.reqParam['orgNm']
            this.searchDealcoParam['orgLvl'] = this.reqParam['orgLevel']
            this.searchDealcoParam['dealcoCd'] = this.reqParam['hldPlcId']
            this.searchDealcoParam['dealcoNm'] = this.reqParam['hldPlcNm']

            if (!_.isEmpty(this.reqParam['hldPlcNm'])) {
                // 내부거래처조회
                this.getDealcosList()
            } else {
                // 팝업오픈
                this.basBcoDealcoShow = true
            }
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.reqParam.hldPlcId = ''
            this.gridInit()
            this.isSearch = false
            this.delDisabled = true
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            if (this.reqParam.hldPlcId != returnData.dealcoCd) {
                this.gridInit()
                this.isSearch = false
                this.delDisabled = true
            }
            this.reqParam.hldPlcId = _.get(returnData, 'dealcoCd')
            this.reqParam.hldPlcNm = _.get(returnData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================
    },
}
</script>
