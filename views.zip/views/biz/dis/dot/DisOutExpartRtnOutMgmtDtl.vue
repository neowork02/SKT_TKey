<!-----------------------------------------------
 * 업무그룹명: 출고관리
 * 서브업무명: 교/반품 출고관리상세
 * 설명: 교/반품 출고 상세 내역을 조회한다.
 * 작성자: P179890
 * 작성일: 2022.06.21
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>교/반품 출고관리상세</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="addProdPop"
                    :disabled="isNotNew"
                    >상품입력</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="addSwingProdPop"
                    :disabled="isNotNew"
                    >Swing 상품입력</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    :disabled="isNotNew"
                    @click="addDisProdPop"
                    >재고상품입력</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="aprvBtn"
                    v-if="false"
                    :objAuth="this.objAuth"
                    >승인</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="delBtn"
                    v-if="false"
                    :objAuth="this.objAuth"
                >
                    삭제
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :disabled="isNotNew"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :disabled="isNotNew && !isNotFixYn"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="listBtn"
                    :objAuth="this.objAuth"
                >
                    목록
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="출고예정일"
                        calType="D"
                        v-model="setDate"
                        :eRequired="true"
                        :disabled="isNotNew"
                        @change="dataChange"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        @enterKey="onAuthOrgTreeClick"
                        @appendIconClick="onAuthOrgTreeClick"
                        @input="onAuthOrgTreeInput"
                        :objAuth="this.objAuth"
                        :eRequired="true"
                        v-model="reqParam.orgNm"
                        :codeVal="reqParam.orgId"
                        :disabledAfter="true"
                        :disabled="isNotNew || searchDisable"
                    >
                    </TCComInputSearchText>
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="reqParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="반품처"
                        @enterKey="onOutDealClick"
                        @appendIconClick="onOutDealClick"
                        @input="onOutDealcoInput"
                        :eRequired="true"
                        :objAuth="this.objAuth"
                        v-model="reqParam.inPlcNm"
                        :codeVal="reqParam.inPlcId"
                        :disabledAfter="true"
                        :disabled="isNotNew"
                    >
                    </TCComInputSearchText>
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onOutDealReturnData"
                    />
                </div>
                <!-- //item 1-3 -->
            </div>
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00050"
                        labelName="출고구분"
                        :objAuth="this.objAuth"
                        v-model="reqParam.outCl"
                        :eRequired="true"
                        :disabled="isNotNew"
                        :filterFunc="filterFunc"
                        @change="outClComboChange"
                        ref="outClCombo"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="출고처"
                        @enterKey="onDealcoClick"
                        @appendIconClick="onDealcoClick"
                        @input="onDealcoInput"
                        :objAuth="this.objAuth"
                        :eRequired="true"
                        v-model="reqParam.outPlcNm"
                        :codeVal="reqParam.outPlcId"
                        :disabledAfter="true"
                        :disabled="isNotNew || searchDisable"
                    >
                    </TCComInputSearchText>
                    <!-- 내부거래처팝업(권한조직) -->
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchDealcoParam"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 2-2 -->
            </div>
            <!-- //Search_line 1 -->
        </div>

        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="교/반품출고상세 내역"
                :gridObj="this.gridObj"
                :isExceldown="isNotNew"
                :isDelRow="true"
                @excelDownBtn="exportGridBtn"
                @chkDelRowBtn="gridchkDelRowBtn"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                @onRowUpdated="onRowUpdated"
            />
        </div>
        <!-- //gridWrap -->

        <!-- Text area -->
        <div class="textareaLayer_wrap">
            <TCComTextArea
                v-model="outMaster.rmks"
                labelName="비고(출고사유)"
                class="boxtype"
                :rows="5"
                :disabled="isNotNew"
            />
        </div>
        <!-- //Text area -->
        <!-- 상품입력POPUP -->
        <DisDcoProdInsOutPopup
            v-if="showAddProdPop === true"
            :dialogShow.sync="showAddProdPop"
            :addProdData.sync="addProdPopParam"
            @returnVal="returnProdList"
        />
        <!-- //상품입력POPUP -->
        <!-- 상품입력(재고검색)POPUP -->
        <DisDcoProdInsDisSrchPopup
            v-if="showDisProdPop === true"
            :dialogShow.sync="showDisProdPop"
            :params="disProdParam"
            :prodOrgList="prodOrgList"
            @addDisProdList="returnProdList"
        />
        <!-- Swing상품입력POPUP -->
        <DisDcoSwingOutProdInsPopup
            v-if="showSwingOutProdPop === true"
            :dialogShow.sync="showSwingOutProdPop"
            :params="swingProdPopParam"
            :prodOrgList="prodOrgList"
            @addSwingProdList="returnProdList"
        />
        <!-- //상품입력(재고검색)POPUP -->
        <TCComAlert
            :headerText="'교/반품출고관리상세'"
            v-model="saveBool"
            :bodyText="alertBodyTxt"
            :size="400"
            :btnOkShow="false"
            @ok-click="saveComplete"
        ></TCComAlert>
    </div>
</template>

<script>
import { CommonGrid, CommonUtil, CommonMsg, CommonBizClosing } from '@/utils'
import { DisOutExpartRtnOutMgmtDtl_HEADER } from '@/const/grid/dis/dot/disOutExpartRtnOutMgmtDtlHeader'
import dotApi from '@/api/biz/dis/dot/disOutExpartRtnOutMgmtDtl'
import attachedFileApi from '@/api/common/attachedFile'
import commonApi from '@/api/common/prototype'
import DisDcoProdInsOutPopup from '@/views/biz/dis/dco/DisDcoProdInsOutPopup'
import DisDcoProdInsDisSrchPopup from '@/views/biz/dis/dco/DisDcoProdInsDisSrchPopup'
import DisDcoSwingOutProdInsPopup from '@/views/biz/dis/dco/DisDcoSwingOutProdInsPopup'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================내부거래처(권한조직)====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처(권한조직)==================

export default {
    name: 'DisOutExpartRtnOutMgmtDtl',
    mixins: [CommonMixin],
    components: {
        DisDcoProdInsOutPopup,
        DisDcoProdInsDisSrchPopup,
        BasBcoAuthOrgTreesPopup,
        BasBcoOutDealsPopup,
        BasBcoDealcosPopup,
        DisDcoSwingOutProdInsPopup,
    },
    data() {
        return {
            //====================조직 팝업====================
            authOrgParam: {},
            showBcoAuthOrgTrees: false,
            resultAuthOrgTreeRows: [],
            //====================조직 팝업====================
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false,
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '3X', // 거래처그룹
                dealcoClCd1: '30', // 거래처구분
            },
            resultOutDealRows: [],
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
            //====================내부거래처(권한 조직))====================
            basBcoDealcoShow: false,
            searchDealcoParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY',
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC',
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한 조직)==================
            searchDisable: false,
            btnDisable: false,
            isNotNew: false,
            isNotFixYn: false,
            saveBool: false,
            isDateChange: false,
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            alertHeadTxt: '교/반품출고관리상세',
            alertBodyTxt: '',
            objAuth: {},
            params: {},
            fvUserTyp: '1',
            view: DisOutExpartRtnOutMgmtDtl_HEADER,
            listSearch: {},
            outMaster: {},
            prodSerNumList: [],
            prodOrgList: [],
            disProdParam: {},
            searchParam: {},
            reqParam: {
                outSchdDt: '', // 출고예정일
                inPlcId: '', // 반품처코드
                inPlcNm: '', // 반품처명
                outPlcId: '', // 출고처코드
                outPlcNm: '', // 출고처명
                orgId: '', // 조직
                orgNm: '', // 조직명
                orgLevel: '', //조직레벨
                outCl: '201', // 출고구분
            },
            showAddProdPop: false,
            showDisProdPop: false,
            showSwingOutProdPop: false,
            addProdPopParam: {},
            swingProdPopParam: {},
        }
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, true, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.onEditCommit = this.onEditCommit
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.setEditOptions({
            eppendable: true,
        })

        this.getCommCodeList('ZBAS_C_00500', 'mdlClCd') // 단말기구분
        // 기타출고관리화면에서 넘어온 파라미터
        this.listSearch = this.$route.params.search
        this.params = this.$route.params
        if (!_.isEmpty(this.$route.params.outMgmtNo)) {
            // 상세 조회
            this.isNotNew = true
            this.getOutSchdDtlList()
        } else {
            // 신규
            this.init()
        }
    },
    computed: {
        setDate: {
            get() {
                return this.reqParam.outSchdDt
            },
            set(val) {
                this.reqParam.outSchdDt = val
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.reqParam.basMth = CommonUtil.onlyNumber(val).substr(0, 6)
                // 내부거래처 기준년월 파라미터 set
                this.searchDealcoParam.basDay = CommonUtil.onlyNumber(
                    val
                ).substr(0, 8)
                return val
            },
        },
    },
    methods: {
        init() {
            this.reqParam.outSchdDt = moment(new Date()).format('YYYY-MM-DD') // 출고예정일
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['orgId'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLevel'] = this.orgInfo['orgLvl']

                this.reqParam['outPlcId'] = this.userInfo['dealcoCd']
                this.reqParam['outPlcNm'] = this.userInfo['dealcoNm']

                this.searchDisable = true
            } else {
                this.reqParam['orgId'] = this.listSearch['orgId']
                this.reqParam['orgNm'] = this.listSearch['orgNm']
                this.reqParam['orgLevel'] = this.listSearch['orgLevel']

                this.reqParam['outPlcId'] = this.listSearch['outPlcId']
                this.reqParam['outPlcNm'] = this.listSearch['outPlcNm']

                this.searchDisable = false
            }

            if (!_.isEmpty(this.userInfo['userTyp'])) {
                this.fvUserTyp = this.userInfo['userTyp'] // 사용자종류
            }
        },
        // 그리드 rowUpdate 이벤트
        onRowUpdated(provider, row) {
            const rowData = provider.getJsonRow(row)

            const unitPrc = rowData['unitPrc'] // 단가
            let rowIndexs = []

            const rowAllData = provider.getJsonRows(0, -1)

            rowAllData.forEach((item, i) => {
                if (
                    item.colorCd == rowData.colorCd &&
                    item.prodCd == rowData.prodCd
                ) {
                    rowIndexs.push(i)
                }
            })

            rowIndexs.forEach((item) => {
                if (isNaN(unitPrc)) {
                    provider.setValue(item, 'amt', 0)
                    provider.setValue(item, 'unitPrc', 0)
                } else {
                    provider.setValue(item, 'amt', unitPrc)
                    provider.setValue(item, 'unitPrc', unitPrc)
                }
            })
        },
        // 그리드 editCommit 이벤트
        onEditCommit(grid) {
            grid.editOptions.commitByCell = true
        },
        gridSetData() {
            // CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(0, 10000, '', '')
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dot/disOutExpartRtnOutMgmtDtlExcels',
                this.searchParam
            )
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            if (
                this.outMaster['outFixYn'] == 'Y' &&
                !_.isEmpty(this.outMaster['outFixDt'])
            ) {
                this.openAlert(
                    CommonMsg.getMessage(
                        'MSG_00022',
                        '이미 출고확정된 데이터이므로'
                    )
                )
                return
            }
            this.gridHeaderObj.chkDelRow(this.gridData)
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj) // 초기화 함수
            this.init()
        },
        //승인 버튼 이벤트
        async aprvBtn() {
            // MSG_00063: ' %s 저장하시겠습니까?'
            const confirm = await this.showTcComConfirm(
                CommonMsg.getMessage('MSG_00070', '승인')
            )

            if (confirm) {
                // 승인처리
                this.outMaster.outSchdDt = CommonUtil.onlyNumber(
                    this.outMaster.outSchdDt
                )
                this.outMaster.progId = 'DisOutExpartRtnOutMgmtDtl'

                const aprvData = {
                    outMaster: this.outMaster,
                    prodSerNumList: this.prodSerNumList,
                }
                dotApi.outAprvOp(aprvData).then((res) => {
                    // 정상등록
                    if (res === 1) {
                        this.alertBodyTxt = CommonMsg.getMessage('MSG_00990')
                        this.saveBool = true
                    }
                })
            }
        },
        async delBtn() {
            if (_.isEmpty(this.outMaster.outMgmtNo)) {
                // MSG_00022 -  %s 삭제할 수 없습니다.
                this.openAlert(
                    CommonMsg.getMessage(
                        'MSG_00022',
                        '등록되지 않은 데이터이므로'
                    )
                )
                return
            }
            const delConfirm = await this.showTcComConfirm(
                CommonMsg.getMessage('MSG_00102', '전체')
            )

            if (delConfirm) {
                if (this.gridData.delRows != '') {
                    this.gridData.delRows.forEach((data) => {
                        // 삭제된상품 append
                        this.gridObj.dataProvider.insertRow(
                            this.gridObj.gridView.getItemCount(),
                            data
                        )
                        this.gridData.delRows = ''
                    })
                }
                this.outMaster.progId = 'DisOutExpartRtnOutMgmtDtl'
                this.outMaster.outSchdDt = CommonUtil.onlyNumber(
                    this.outMaster.outSchdDt
                )
                // 삭제로직처리
                const deleteParam = {
                    outMaster: this.outMaster,
                    prodSerNumList: this.gridObj.dataProvider.getJsonRows(),
                }
                dotApi.deleteOutSchd(deleteParam).then((res) => {
                    // 정상삭제
                    if (res === 1) {
                        this.alertBodyTxt = CommonMsg.getMessage('MSG_00990')
                        this.saveBool = true
                    }
                })
            }
        },
        //저장
        async saveBtn() {
            let prodSerNumList = []

            if (!_.isEmpty(this.outMaster.outMgmtNo)) {
                if (this.gridData.delRows == '') {
                    this.openAlert(CommonMsg.getMessage('MSG_00071', ''))
                    return
                }
                const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
                if (_.isEmpty(rowData)) {
                    this.openAlert(CommonMsg.getMessage('MSG_00114'))
                    this.gridObj.setRows(this.gridData.delRows)
                    this.gridData.delRows = ''
                    return
                }
                prodSerNumList = this.gridData.delRows
            } else {
                const createdRows =
                    this.gridObj.dataProvider.getStateRows('created')

                if (createdRows.length == 0) {
                    this.openAlert(CommonMsg.getMessage('MSG_00071', ''))
                    return
                }

                // 반품출고시 임직원이 아닌 경우 처리 불가능하도록 제한
                // 전자결제의 경우 임직원인 경우만 처리가 가능함
                if (this.reqParam.outCl == '201' && this.fvUserTyp != '1') {
                    this.openAlert(
                        '사용자의 소속구분이 임직원이 아닌 경우, 전자결재 연동이 불가합니다.'
                    )
                    return
                }
                const sOutSchdDt = CommonUtil.onlyNumber(
                    this.reqParam.outSchdDt
                )
                // 마감일 체크
                const clsStatus = await CommonBizClosing.getClsStatus(
                    'D',
                    sOutSchdDt,
                    'STK'
                )
                if (clsStatus && 'CLS' == clsStatus.clsStCd) {
                    this.openAlert(CommonMsg.getMessage('MSG_00185', ''))
                    return
                }
                if (sOutSchdDt > moment().add(30, 'days').format('YYYYMMDD')) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00099', '출고예정일')
                    )
                    return
                }
                if (_.isEmpty(this.reqParam.outCl)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00047', '출고구분을')
                    )
                    return
                }

                if (_.isEmpty(this.reqParam.orgId)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00121', '조직;저장')
                    )
                    return
                }

                if (_.isEmpty(this.reqParam.outPlcId)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00121', '출고처;저장')
                    )
                    return
                }

                if (_.isEmpty(this.reqParam.inPlcId)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00121', '반품처;저장')
                    )
                    return
                }

                for (var i = 0; i < createdRows.length; i++) {
                    let rowData = this.gridObj.dataProvider.getJsonRow(
                        createdRows[i]
                    )
                    if (rowData['unitPrc'] == null || rowData['unitPrc'] == 0) {
                        this.openAlert(
                            CommonMsg.getMessage(
                                'MSG_00124',
                                (createdRows[i] + 1).toString() + ';금액'
                            )
                        )
                        return
                    }
                }

                createdRows.forEach((i) => {
                    prodSerNumList.push(this.gridObj.dataProvider.getJsonRow(i))
                })
            }

            // MSG_00063: ' %s 저장하시겠습니까?'
            const confirm = await this.showTcComConfirm(
                CommonMsg.getMessage('MSG_00063', '')
            )

            if (confirm) {
                // 로직처리
                this.saveOutSchd(prodSerNumList)
            }
        },
        // 출고등록
        saveOutSchd(prodList) {
            this.outMaster.outPlcId = this.reqParam.outPlcId
            this.outMaster.outPlcNm = this.reqParam.outPlcNm
            this.outMaster.inPlcId = this.reqParam.inPlcId
            this.outMaster.inPlcNm = this.reqParam.inPlcNm
            this.outMaster.outSchdDt = CommonUtil.onlyNumber(
                this.reqParam.outSchdDt
            )
            this.outMaster.outCl = this.reqParam.outCl
            this.outMaster.outClNm = this.$refs.outClCombo.getValueText
            this.outMaster.progId = 'DisOutExpartRtnOutMgmtDtl'

            const saveData = {
                outMaster: this.outMaster,
                prodSerNumList: prodList,
            }
            dotApi.saveOutSchd(saveData).then((res) => {
                // 정상등록
                if (res === 1) {
                    this.alertBodyTxt = CommonMsg.getMessage('MSG_00990')
                    this.saveBool = true
                }
            })
        },
        saveComplete() {
            // 출고등록완료 - 교/반품출고관리 화면 이동
            this.listBtn()
        },
        //목록
        listBtn() {
            this.$router.push({
                name: '/dis/dot/DisOutExpartRtnOutMgmt',
                params: { search: this.listSearch },
            })
        },
        //출고 마스터/상세 조회
        getOutSchdDtlList: function () {
            this.searchParam = {
                outMgmtNo: this.params.outMgmtNo,
                outPlcId: this.params.outPlcId,
                outCl: this.params.outCl,
            }

            dotApi.getOutSchdDtlList(this.searchParam).then((res) => {
                // 출고마스터
                this.outMaster = res.result.outMaster
                this.reqParam = { ...this.outMaster }

                // 그리드 단가컬럼 수정불가 처리
                this.gridObj.gridView.setColumnProperty(
                    'unitPrc',
                    'editable',
                    false
                )
                // 디테일 리스트
                this.prodSerNumList = res.result.prodSerNumList

                this.gridObj.setRows(this.prodSerNumList)

                // TODO 임시 승인버튼 삭졔
                if (
                    !_.isEmpty(this.outMaster['outFixYn']) &&
                    _.isEmpty(this.outMaster['outFixDt']) &&
                    this.outMaster['outFixYn'] == 'N' &&
                    this.outMaster['outCl'] == '201'
                ) {
                    // 출고예정상태 && 반품출고일 경우 승인버튼 활성화
                    this.isNotFixYn = true
                }
            })
        },

        // validation 체크
        isPopValidChk(flag) {
            if (flag == 'addProdPop' || flag == 'addSwingProdPop') {
                // 상품입력 || Swing상품입력
                if (_.isEmpty(this.reqParam.outSchdDt)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00083', '출고예정일')
                    )
                    return false
                }
                if (_.isEmpty(this.reqParam.outCl)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00083', '출고구분')
                    )
                    return false
                }
                if (flag == 'addSwingProdPop') {
                    if (this.reqParam.outCl != '202') {
                        this.openAlert(CommonMsg.getMessage('MSG_00129'))
                        return false
                    }
                }

                if (_.isEmpty(this.reqParam.orgId)) {
                    this.openAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                    this.openAlert('조직(을)를 입력하여 주십시오.')
                    return false
                }
            }
            if (_.isEmpty(this.reqParam.outPlcId)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '출고처'))
                return false
            }
            if (_.isEmpty(this.reqParam.inPlcId)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '반품처'))
                return false
            }
            return true
        },
        // 출고구분comboBox filter
        filterFunc(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] === '201' || item['commCdVal'] === '202'
            )
        },
        // 공통코드 조회 함수
        getCommCodeList(codeId, columnId) {
            commonApi.getCommonCodeList(codeId).then((res) => {
                let columnValues = []
                let columnLabels = []
                if (res.length) {
                    res.forEach((data) => {
                        columnValues.push(data.commCdVal)
                        columnLabels.push(data.commCdValNm)
                    })
                }
                // 그리드 컬럼 콤보박스 데이터 설정
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'values',
                    columnValues
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'labels',
                    columnLabels
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'lookupDisplay',
                    true
                )
            })
        },
        async dataChange(val) {
            if (!this.isNotNew && this.isDateChange && !_.isEmpty(val)) {
                // 마감일 체크
                const clsStatus = await CommonBizClosing.getClsStatus(
                    'D',
                    CommonUtil.onlyNumber(val),
                    'STK'
                )
                if (clsStatus && 'CLS' == clsStatus.clsStCd) {
                    this.openAlert(CommonMsg.getMessage('MSG_00185', ''))
                    this.reqParam.outSchdDt = ''
                    return
                }
            }
            this.isDateChange = true
        },
        // 상품입력팝업 호출
        addProdPop() {
            // validation
            if (!this.isPopValidChk('addProdPop')) {
                return false
            }
            // 상품입력팝업 파라미터 set
            this.addProdPopParam = {
                aplyDt: this.reqParam.outSchdDt,
                inOutCl: this.reqParam.outCl,
                outPlcId: this.reqParam.outPlcId,
                parentList: this.gridObj.dataProvider.getJsonRows(0, -1),
            }
            this.showAddProdPop = true
        },
        // Swing 상품입력 호출
        addSwingProdPop() {
            // validation
            if (!this.isPopValidChk('addSwingProdPop')) {
                return false
            }
            // Swing상품입력팝업 파라미터 set
            this.swingProdPopParam = {
                inOutCl: this.reqParam.outCl,
                inOutClNm: this.$refs.outClCombo.getValueText,
                outPlcId: this.reqParam.outPlcId,
                outPlcNm: this.reqParam.outPlcNm,
                orgId: this.reqParam.orgId,
                orgNm: this.reqParam.orgNm,
                orgLevel: this.reqParam.orgLevel,
            }
            this.prodOrgList = this.gridObj.dataProvider.getJsonRows(0, -1)
            this.showSwingOutProdPop = true
        },
        // 재고상품입력팝업 호출
        addDisProdPop() {
            if (!this.isPopValidChk('addDisProdPop')) {
                return false
            }
            // 재고상품입력 팝업 파라미터 set
            this.disProdParam = {
                outPlcId: this.reqParam.outPlcId, // 출고처ID
                outPlcNm: this.reqParam.outPlcNm, // 출고처명
                outSchdDt: this.reqParam.outSchdDt, // 출고예정일
                outCl: this.reqParam.outCl, // 출고구분
                FV_IN_DEAL_CO_CL1: this.userInfo.dealcoClCd1,
            }
            this.prodOrgList = this.gridObj.dataProvider.getJsonRows(0, -1)
            this.showDisProdPop = true
        },
        returnProdList(returnVal) {
            if (returnVal.length > 0) {
                returnVal.forEach((data) => {
                    // 상품 append
                    this.gridObj.dataProvider.insertRow(
                        this.gridObj.gridView.getItemCount(),
                        data
                    )
                })
            }
        },
        // Alert창 호출 하수
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        outClComboChange(val) {
            // 그리드 초기화
            if (val == '201') {
                this.searchDealcoParam.dealcoGrpCd = 'ZZ,AY,YY'
            } else if (val == '202') {
                this.searchDealcoParam.dealcoGrpCd = 'ZZ,AY'
            }
            this.gridObj.gridInit()
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.authOrgParam)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.orgId = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLevel = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon / 엔터 클릭 이벤트 처리
        onAuthOrgTreeClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            this.authOrgParam['orgNm'] = this.reqParam['orgNm']
            this.authOrgParam['orgCd'] = this.reqParam['orgId']
            this.authOrgParam['orgLvl'] = this.reqParam['orgLevel']
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            if (
                !_.isEmpty(this.reqParam.orgId) &&
                this.reqParam.orgId != retrunData.orgCd
            ) {
                this.reqParam.outPlcId = ''
                this.reqParam.outPlcNm = ''
                this.gridObj.gridInit()
            }
            this.reqParam.orgId = _.get(retrunData, 'orgCd')
            this.reqParam.orgNm = _.get(retrunData, 'orgNm')
            this.reqParam.orgLevel = _.get(retrunData, 'orgLvl')
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.orgId = ''
            this.reqParam.orgLevel = ''
            this.reqParam.outPlcId = ''
            this.reqParam.outPlcNm = ''
            this.gridObj.gridInit()
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.inPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.inPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon / enter 클릭 이벤트 처리
        onOutDealClick() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            this.searchOutDealParam['dealcoCd'] = this.reqParam['inPlcId'] // 반품처코드
            this.searchOutDealParam['dealcoNm'] = this.reqParam['inPlcNm'] // 반품처명
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            if (!_.isEmpty(this.reqParam.inPlcNm)) {
                this.getOutDealList()
            } else {
                this.showBcoOutDeals = true
            }
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            this.reqParam.inPlcId = _.get(retrunData, 'dealcoCd')
            this.reqParam.inPlcNm = _.get(retrunData, 'dealcoNm')
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onOutDealcoInput() {
            this.reqParam.inPlcId = ''
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcoParam)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.reqParam.outPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.outPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoClick() {
            if (_.isEmpty(this.reqParam['orgId'])) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return
            }

            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.searchDealcoParam['orgCd'] = this.reqParam['orgId']
            this.searchDealcoParam['orgNm'] = this.reqParam['orgNm']
            this.searchDealcoParam['orgLvl'] = this.reqParam['orgLevel']
            this.searchDealcoParam['dealcoCd'] = this.reqParam['outPlcId']
            this.searchDealcoParam['dealcoNm'] = this.reqParam['outPlcNm']
            if (!_.isEmpty(this.reqParam['outPlcNm'])) {
                // 내부거래처조회
                this.getDealcosList()
            } else {
                // 팝업오픈
                this.basBcoDealcoShow = true
            }
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            this.reqParam.outPlcId = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            if (this.reqParam.outPlcId != returnData.dealcoCd) {
                this.gridObj.gridInit()
            }
            this.reqParam.outPlcId = _.get(returnData, 'dealcoCd')
            this.reqParam.outPlcNm = _.get(returnData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================
    },
}
</script>
