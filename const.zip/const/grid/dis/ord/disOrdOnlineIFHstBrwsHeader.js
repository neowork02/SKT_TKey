import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'brwsClNm',
            dataType: ValueType.TEXT, // 조회구분명
        },
        {
            fieldName: 'ifDt',
            dataType: ValueType.TEXT, // IF일자
        },
        {
            fieldName: 'tifTpsOrdSeq',
            dataType: ValueType.TEXT, // 전송순번
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 수정일시
        },
        {
            fieldName: 'trmsCl',
            dataType: ValueType.TEXT, // 전송구분
        },
        {
            fieldName: 'ordId',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'pickSlipNo',
            dataType: ValueType.TEXT, // 작업지시번호
        },
        {
            fieldName: 'ordProdStNm',
            dataType: ValueType.TEXT, // 주문진행상태명
        },
        {
            fieldName: 'ordMthdNm',
            dataType: ValueType.TEXT, // 주문방식명
        },
        {
            fieldName: 'svcClNm',
            dataType: ValueType.TEXT, // 개통구분명
        },
        {
            fieldName: 'saleChrgrUserId',
            dataType: ValueType.TEXT, // 영업담당사용자ID
        },
        {
            fieldName: 'salePlcCd',
            dataType: ValueType.TEXT, // 판매처코드
        },
        {
            fieldName: 'salePlcNm',
            dataType: ValueType.TEXT, // 판매처명
        },
        {
            fieldName: 'spSalBrNm',
            dataType: ValueType.TEXT, // 특판처명
        },
        {
            fieldName: 'saleClNm',
            dataType: ValueType.TEXT, // 판매구분명
        },
        {
            fieldName: 'dlvClNm',
            dataType: ValueType.TEXT, // 배송구분명
        },
        {
            fieldName: 'dlvCoNm',
            dataType: ValueType.TEXT, // 배송사명
        },
        {
            fieldName: 'waybillNo',
            dataType: ValueType.TEXT, // 송장번호
        },
        {
            fieldName: 'sendRcvStNm',
            dataType: ValueType.TEXT, // 전송상태명
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, // 비고
        },
    ],
    columns: [
        {
            name: 'brwsClNm',
            fieldName: 'brwsClNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '구분',
            },
        },
        {
            name: 'ifDt',
            fieldName: 'ifDt',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'IF일자',
            },
        },
        {
            name: 'tifTpsOrdSeq',
            fieldName: 'tifTpsOrdSeq',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '전송일련번호',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '120',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '전송일시',
            },
        },
        {
            name: 'trmsCl',
            fieldName: 'trmsCl',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '전송구분',
            },
        },
        {
            name: 'ordId',
            fieldName: 'ordId',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문번호',
            },
        },
        {
            name: 'pickSlipNo',
            fieldName: 'pickSlipNo',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '작업지시번호',
            },
        },
        {
            name: 'ordProdStNm',
            fieldName: 'ordProdStNm',
            type: 'data',
            width: '120',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문진행상태',
            },
        },
        {
            name: 'ordMthdNm',
            fieldName: 'ordMthdNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문방식',
            },
        },
        {
            name: 'svcClNm',
            fieldName: 'svcClNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '개통구분',
            },
        },
        {
            name: 'saleChrgrUserId',
            fieldName: 'saleChrgrUserId',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매담당',
            },
        },
        {
            name: 'salePlcCd',
            fieldName: 'salePlcCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매처코드',
            },
        },
        {
            name: 'salePlcNm',
            fieldName: 'salePlcNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '판매처명',
            },
        },
        {
            name: 'spSalBrNm',
            fieldName: 'spSalBrNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '특판처명',
            },
        },
        {
            name: 'saleClNm',
            fieldName: 'saleClNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매구분',
            },
        },
        {
            name: 'dlvClNm',
            fieldName: 'dlvClNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '배송구분',
            },
        },
        {
            name: 'dlvCoNm',
            fieldName: 'dlvCoNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '배송사',
            },
        },
        {
            name: 'waybillNo',
            fieldName: 'waybillNo',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '송장번호',
            },
        },
        {
            name: 'sendRcvStNm',
            fieldName: 'sendRcvStNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '전송상태',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '비고',
            },
        },
    ],
}

export const DETAIL_GRID_HEADER = {
    fields: [
        {
            fieldName: 'NO',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'boxNum1',
            dataType: ValueType.TEXT, // BOX번호1
        },
        {
            fieldName: 'boxNum2',
            dataType: ValueType.TEXT, // BOX번호2
        },
        {
            fieldName: 'serNumMatchDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 일련번호매칭일자
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'NO',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            numberFormat: '##0',
            header: {
                text: 'No',
            },
            editor: {
                textReadOnly: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '상품모델코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '상품모델명',
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상코드',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상명',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'boxNum1',
            fieldName: 'boxNum1',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX1',
            },
        },
        {
            name: 'boxNum2',
            fieldName: 'boxNum2',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX2',
            },
        },
        {
            name: 'serNumMatchDt',
            fieldName: 'serNumMatchDt',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '일련번호매칭일',
            },
        },
    ],
}
