<script>
import TCButton from '@/components/TCButton'
import TCRealGrid from '@/components/TCRealGrid'
import { G_HEADER } from '@/const/grid/acc/aco/addPatrDtlListHead'
import { TEST_DATA } from '@/const/grid/testData'
import acoApi from '@/api/biz/acc/aco'
import { CommonUtil, FileUtil } from '@/utils'

export default {
    name: 'Home',
    components: {
        TCRealGrid,
        TCButton,
    },
    data() {
        return {
            list01: [],
            view: G_HEADER,
            formData: {
                actorId: 10,
                firstName: 'kim',
                lastName: 'an na',
                pageSize: 10,
                pageNum: 0,
            },
        }
    },
    methods: {
        callApi: function () {
            // 공통 유틸 사용.
            alert(CommonUtil.validPhoneNo(1234))
            alert(FileUtil.formatSize(14))

            const formData = this.formData

            acoApi.getDemServiceList(formData).then((resultData) => {
                this.list01 = resultData
                this.$refs.grid1.setRows(this.list01)
            })
        },
        loadData01: function () {
            this.list01 = TEST_DATA
            this.$refs.grid1.setRows(this.list01)
        },
        initSearchedList() {
            alert('a')
        },
    },
}
</script>

<template>
    <div class="home">
        <h3>vue2 스타일 컴포넌트 - 로컬 데이터</h3>
        <TCRealGrid
            id="grid1"
            ref="grid1"
            :fields="view.fields"
            :columns="view.columns"
        />
        <button @click="loadData01">로컬 Data Load</button>
        <button @click="callApi">[api]</button>
        <br />
        <TCButton
            cls="btn btn-gray right"
            isIcon="N"
            title="[공통버튼]"
            @click="initSearchedList"
        />
    </div>
</template>

<style scoped></style>
