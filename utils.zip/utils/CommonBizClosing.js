/* eslint-disable no-useless-escape */

/*****************************************
 * 업무그룹명: 공통업무
 * 서브업무명: 공통 Utils
 * 설명: 공통 Utils 기능
 * 작성자: 홍길동
 * 작성일: 2022.02.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
 *****************************************/
import _ from 'lodash'
import store from '@/store'
import CommonUtil from './CommonUtil'
import api from '@/api/biz/bas/bco/basBcoSysClsInfo'
export default {
    /**
     * 마감일자 마감여부 조회
     * @param {*} monthDayCl 일마감/월마감 구분(D:일마감, M:월마감)
     * @param {*} strdDt 마감일자
     * @param {*} workClCd 업무구분(ACC:정산, SLS:판매, STK:재고)
     * @param {*} orgCd 조직코드
     */
    async getClsStatus(monthDayCl, strdDt, workClCd, orgCd) {
        var result = false
        if (monthDayCl != 'D' && monthDayCl != 'M') {
            store.dispatch('showTcComAlert', {
                message:
                    '일마감/월마감 구분은 필수입니다.\n[D:일마감 M:월마감]',
                options: {
                    header: '마감여부',
                    size: '550',
                    confirmLabel: 'OK',
                },
            })
        }
        if (_.isEmpty(strdDt)) {
            if (workClCd === 'D') {
                store.dispatch('showTcComAlert', {
                    message: '마감일자는 필수입니다.',
                    options: {
                        header: '마감여부',
                        size: '550',
                        confirmLabel: 'OK',
                    },
                })
            } else {
                store.dispatch('showTcComAlert', {
                    message: '마감월은 필수입니다.',
                    options: {
                        header: '마감여부',
                        size: '550',
                        confirmLabel: 'OK',
                    },
                })
            }
        }
        if (_.isEmpty(workClCd)) {
            store.dispatch('showTcComAlert', {
                message: '업무구분은 필수입니다.',
                options: {
                    header: '마감여부',
                    size: '550',
                    confirmLabel: 'OK',
                },
            })
        }
        if (_.isEmpty(null)) {
            orgCd = '*'
        }

        var searchData = {}
        searchData.gubun = monthDayCl
        searchData.strdDt = strdDt
        searchData.orgCd = orgCd
        searchData.workClCd = workClCd
        await api.getCloseBisDayMth(searchData).then((resultData) => {
            console.log(resultData)
            //result = resultData.clsStCd === 'CLS'
            result = resultData
        })
        return result
    },
    async getMonthCloseYn(yyyyMM, orgCd, closeType) {
        var result = ''
        if (
            _.isEmpty(yyyyMM) ||
            !CommonUtil.validDateType('01', yyyyMM.replaceAll('-', ''))
        ) {
            store.dispatch('showTcComAlert', {
                message: '마감년월은 필수값으로 년월(YYYYMM)의 형태입니다.',
                options: {
                    header: '마감여부',
                    size: '550',
                    confirmLabel: 'OK',
                },
            })
            return false
        }

        var target = '01,02,03'
        if (
            _.isEmpty(closeType) ||
            closeType.length != 2 ||
            target.indexOf(closeType) == -1
        ) {
            store.dispatch('showTcComAlert', {
                message:
                    '마감업무구분은 필수값으로\n(01:월마감, 02:판매수수료회계마감, 03:회계월마감)의<br>값중 하나입니다.',
                options: {
                    header: '마감여부',
                    size: '550',
                    confirmLabel: 'OK',
                },
            })
            return false
        }
        if (_.isEmpty(orgCd)) {
            store.dispatch('showTcComAlert', {
                message: '조직은 필수값입니다.',
                options: {
                    header: '마감여부',
                    size: '550',
                    confirmLabel: 'OK',
                },
            })
            return false
        }
        var searchData = {}
        searchData.gubun = closeType
        searchData.strdDt = yyyyMM
        searchData.orgCd = orgCd

        await api.getMonthCloseYn(searchData).then((resultData) => {
            console.log(resultData)
            if (resultData === undefined) return
            result = resultData.monthCloseYn
        })
        return result
    },
}
