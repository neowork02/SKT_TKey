<script>
export default {
    props: ['minTime', 'maxTime', 'val'],
    data() {
        return {}
    },
}
</script>

<template>
    <div class="input-wrap">
        <input type="time" :min="minTime" :max="maxTime" :value="val" />
    </div>
</template>
