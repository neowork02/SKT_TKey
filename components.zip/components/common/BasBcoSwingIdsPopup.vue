<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">Swing ID 검색 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchSwingIdForm.ukeyId"
                                    labelName="Swing ID"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchSwingIdForm.ukeyNm"
                                    labelName="Swing 사용자명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 1-3 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="swingIdsGridHeader"
                            ref="swingIdsGridHeader"
                            :gridObj="gridObj"
                        />
                        <TCRealGrid
                            id="swingIdsGrid"
                            ref="swingIdsGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { basBcoSwingIdHeader } from '@/const/grid/bas/bco/basBcoSwingIdHeader'
import basBcoSwingIdsApi from '@/api/biz/bas/bco/basBcoSwingIds'
import CommonMixin from '@/mixins'
export default {
    name: 'BasBcoSwingIdsPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: this.gridSetData(),
            headerText: '',
            objAuth: {},
            view: basBcoSwingIdHeader,
            content: '',
            gridObj: {},
            gridHeaderObj: {},
            findRowParam: {
                userNm: '',
            },
            searchSwingIdForm: {
                ukeyId: '', // Swing ID
                ukeyNm: '', // Swing 사용자명
                ukeyUserId: '', // Swing User ID
            },
        }
    },

    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.swingIdsGrid
        this.gridHeaderObj = this.$refs.swingIdsGridHeader
        this.initGrid()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('### watch parentParam')
                this.findRowParam.userNm = value['userNm']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        //GridSetData
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(0, 0, '', '')
        },
        async initGrid() {
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            //this.gridObj.gridView.displayOptions.selectStyle = 'rows'
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false, false)

            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        getSwingIdList() {
            basBcoSwingIdsApi
                .getSwingIdList(this.searchSwingIdForm)
                .then((res) => {
                    console.log('getSwingIdList : ', res)
                    this.gridObj.setRows(res)
                    this.findRowSelect()
                })
        },
        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('Swing ID를 선택해주세요.', {
                    header: 'Swing ID 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })

                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },
        onSearch() {
            if (
                this.searchSwingIdForm.ukeyId === '' &&
                this.searchSwingIdForm.ukeyNm === ''
            ) {
                this.showTcComAlert(
                    'Swing ID나 Swing 사용자명 중 하나는 입력해야 합니다.'
                )
                return false
            }
            if (
                this.searchSwingIdForm.ukeyId != '' &&
                this.searchSwingIdForm.ukeyId.length < 2
            ) {
                this.showTcComAlert('Swing ID는 2자리 이상 입력하십시오.')
                return false
            }
            if (
                this.searchSwingIdForm.ukeyNm != '' &&
                this.searchSwingIdForm.ukeyNm.length < 2
            ) {
                this.showTcComAlert('Swing 사용자명은 2자리 이상 입력하십시오.')
                return false
            }
            this.getSwingIdList()
        },

        onEnterKey() {
            this.onSearch()
        },
        findRowSelect() {
            if (this.findRowParam.userNm === '') return false
            let fields = ['ukeyIdNm']
            let values = [this.findRowParam.userNm]
            let options = {
                fields: fields,
                values: values,
                wrap: true,
                faetialMathc: true,
            }
            // let index = this.gridObj.gridView.searchCell(options)
            //let index = this.gridObj.gridView.searchDataRow(options)
            let index = this.gridObj.dataProvider.searchDataRow(options)
            console.log('index:%s', index)
            this.gridObj.gridView.setCurrent({ itemIndex: index })
        },
    },
}
</script>
