import { ValueType } from 'realgrid'

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'asgnDt',
            dataType: ValueType.TEXT, //일자
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'sknAsgnQty',
            dataType: ValueType.TEXT, //SKN배정수량
        },
        {
            fieldName: 'ordQty',
            dataType: ValueType.TEXT, //주문수량
        },
        {
            fieldName: 'ordYn',
            dataType: ValueType.TEXT, //주문여부
        },
        {
            fieldName: 'ordAsgnQty',
            dataType: ValueType.TEXT, //주문배정수량
        },
        {
            fieldName: 'crdtAmt',
            dataType: ValueType.TEXT, //여신금액
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.TEXT, //단가
        },
    ],
    columns: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점',
                showTooltip: false,
            },
        },
        {
            name: 'asgnDt',
            fieldName: 'asgnDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일자',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'sknAsgnQty',
            fieldName: 'sknAsgnQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN배정수량',
                showTooltip: false,
            },
        },
        {
            name: 'ordQty',
            fieldName: 'ordQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문수량',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'ordYn',
            fieldName: 'ordYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'ordAsgnQty',
            fieldName: 'ordAsgnQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문배정수량',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'crdtAmt',
            fieldName: 'crdtAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신금액',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
            visible: false,
        },
    ],
}

export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'sknDelvPlcCd',
            dataType: ValueType.TEXT, //배송지코드
        },
        {
            fieldName: 'sknDelvPlcNm',
            dataType: ValueType.TEXT, //배송지명
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'asgnDt',
            dataType: ValueType.TEXT, //배정일
        },
        {
            fieldName: 'dirTakeYn',
            dataType: ValueType.TEXT, //직접인수여부
        },
        {
            fieldName: 'tdayDlvYn',
            dataType: ValueType.TEXT, //당일배송여부
        },
        {
            fieldName: 'sknTrmsYn',
            dataType: ValueType.TEXT, //SKN전송여부
        },
        {
            fieldName: 'ordAsgnQty',
            dataType: ValueType.NUMBER, //주문관리수량
        },
        {
            fieldName: 'sumOrdAsgnQty',
            dataType: ValueType.NUMBER, //주문관리수량
        },
        {
            fieldName: 'sknCrdtLimit',
            dataType: ValueType.TEXT, //잔여여신
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER, //단가
        },
        {
            fieldName: 'amtPrc',
            dataType: ValueType.NUMBER, //가격
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.NUMBER, //요청자ID
        },
    ],
    columns: [
        {
            name: 'sknDelvPlcCd',
            fieldName: 'sknDelvPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배송지코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sknDelvPlcNm',
            fieldName: 'sknDelvPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배송지명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
            editable: false,
            footer: {
                text: '합계',
                styleName: 'center-column',
            },
            footerStyles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'asgnDt',
            fieldName: 'asgnDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'dirTakeYn',
            fieldName: 'dirTakeYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '직접인수여부',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tdayDlvYn',
            fieldName: 'tdayDlvYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '당일배송여부',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'dirTakeYn',
            fieldName: 'dirTakeYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '직접인수여부',
                showTooltip: false,
            },
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
        },
        {
            name: 'ordAsgnQty',
            fieldName: 'ordAsgnQty',
            type: 'number',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문관리수량',
                textAlignment: 'right',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
                valueCallback: function (grid) {
                    let sumOrdAsgnQty = grid.getSummary('sumOrdAsgnQty', 'sum')
                    let avg = sumOrdAsgnQty / 15
                    if (isNaN(avg)) {
                        return ''
                    } else {
                        return avg
                    }
                },
            },
        },
        {
            name: 'sumOrdAsgnQty',
            fieldName: 'sumOrdAsgnQty',
            type: 'number',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문관리수량',
                textAlignment: 'right',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
            numberFormat: '#,##0',
            visible: false,
        },
        {
            name: 'sknCrdtLimit',
            fieldName: 'sknCrdtLimit',
            type: 'data',
            styles: {
                textAlignment: 'right',
            },
            header: {
                text: '잔여여신',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            editable: false,
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'right',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            editable: false,
        },
        {
            name: 'amtPrc',
            fieldName: 'amtPrc',
            type: 'number',
            valueExpression: "values['ordAsgnQty'] * values['unitPrc']",
            styles: {
                textAlignment: 'right',
            },
            header: {
                text: '가격',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            editable: false,
        },
    ],
}

export const GRID_HEADER11 = {
    fields: [
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직명
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, //레벨0조직코드
        },
        {
            fieldName: 'lvOrgNm',
            dataType: ValueType.TEXT, //레벨0조직명
        },
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT, //레벨1조직코드
        },
        {
            fieldName: 'lvOrgNm1',
            dataType: ValueType.TEXT, //레벨1조직명
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, //레벨2조직코드
        },
        {
            fieldName: 'lvOrgNm2',
            dataType: ValueType.TEXT, //레벨2조직명
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT, //레벨3조직코드
        },
        {
            fieldName: 'lvOrgNm3',
            dataType: ValueType.TEXT, //레벨3조직명
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, //위탁창고코드
        },
        {
            fieldName: 'asgnDt',
            dataType: ValueType.TEXT, //일자
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'disQty',
            dataType: ValueType.TEXT, //보유수량
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT, //삭제여부
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, //수정카운트
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.TEXT, //단가
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '관리조직',
                showTooltip: false,
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점명',
                showTooltip: false,
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '위탁창고코드',
                showTooltip: false,
            },
        },
        {
            name: 'asgnDt',
            fieldName: 'asgnDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일자',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'disQty',
            fieldName: 'disQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유수량',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_HEADER22 = {
    fields: [
        {
            fieldName: 'sknDelvDealcdCd',
            dataType: ValueType.TEXT, //배송지코드
        },
        {
            fieldName: 'sknDelvDealcdNm',
            dataType: ValueType.TEXT, //배송지명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'dirTakeYn',
            dataType: ValueType.TEXT, //직접인수여부
        },
        {
            fieldName: 'ordAsgnQty',
            dataType: ValueType.TEXT, //주문관리수량
        },
        {
            fieldName: 'sknCrdtLimit',
            dataType: ValueType.TEXT, //잔여여신
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.TEXT, //단가
        },
        {
            fieldName: 'amtPrc',
            dataType: ValueType.TEXT, //가격
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'asgnDt',
            dataType: ValueType.TEXT, //배정일자
        },
        {
            fieldName: 'tdayDlvYn',
            dataType: ValueType.TEXT, //당일배송여부
        },
        {
            fieldName: 'sknTranYn',
            dataType: ValueType.TEXT, //SKN전송여부
        },
        {
            fieldName: 'fidcYn',
            dataType: ValueType.TEXT, //수탁여부
        },
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, //순번
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT, //요청자ID
        },
    ],
    columns: [
        {
            name: 'sknDelvDealcdCd',
            fieldName: 'sknDelvDealcdCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배송지코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sknDelvDealcdNm',
            fieldName: 'sknDelvDealcdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배송지명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dirTakeYn',
            fieldName: 'dirTakeYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '직접인수여부',
                showTooltip: false,
            },
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
        },
        {
            name: 'ordAsgnQty',
            fieldName: 'ordAsgnQty',
            type: 'number',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문관리수량',
                textAlignment: 'right',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
            numberFormat: '#,##0',
            // footer: {
            //     expression: 'sum',
            //     numberFormat: '#,##0',
            //     valueCallback: function (grid) {
            //         let sumOrdAsgnQty = grid.getSummary('sumOrdAsgnQty', 'sum')
            //         let avg = sumOrdAsgnQty / 15
            //         if (isNaN(avg)) {
            //             return ''
            //         } else {
            //             return avg
            //         }
            //     },
            // },
        },
        {
            name: 'sknCrdtLimit',
            fieldName: 'sknCrdtLimit',
            type: 'data',
            styles: {
                textAlignment: 'right',
            },
            header: {
                text: '잔여여신',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            editable: false,
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'right',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            editable: false,
        },
        {
            name: 'amtPrc',
            fieldName: 'amtPrc',
            type: 'number',
            // valueExpression: "values['ordAsgnQty'] * values['unitPrc']",
            styles: {
                textAlignment: 'right',
            },
            header: {
                text: '가격',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            editable: false,
        },
    ],
}
