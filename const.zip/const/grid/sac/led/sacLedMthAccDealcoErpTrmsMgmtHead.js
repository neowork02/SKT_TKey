import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsDt', // 정산월
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 정산처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1', // 거래처구분 코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm1', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmNm', // 전송구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsAmt', // 금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dealcoEndYn', // 종료여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqYn', // 요청
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqDtm', // 요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId', // 요청자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsYn', // 전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsDtm', // 전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn', // 거래종료여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNm', // 전송요청사용자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsYnNm', // 전송결과명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'trmsDt',
            fieldName: 'trmsDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산월',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'accShopCd',
            fieldName: 'accShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처매장코드',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처코드',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처',
        },
        {
            name: 'dealcoClNm1',
            fieldName: 'dealcoClNm1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처구분',
        },
        {
            name: 'trmsItmNm',
            fieldName: 'trmsItmNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송구분',
        },
        {
            name: 'trmsAmt',
            fieldName: 'trmsAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '금액',
            numberFormat: '#,##0',
        },
        {
            name: 'dealcoEndYn',
            fieldName: 'dealcoEndYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '종료여부',
        },
        {
            name: 'trmsReqYn',
            fieldName: 'trmsReqYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청',
        },
        {
            name: 'trmsReqDtm',
            fieldName: 'trmsReqDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '요청일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'reqUserId',
            fieldName: 'reqUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청자',
        },
        {
            name: 'trmsYnNm',
            fieldName: 'trmsYnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송결과',
        },
        {
            name: 'trmsDtm',
            fieldName: 'trmsDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
    ],
}
