import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        { fieldName: 'dealcoRgstClNm', dataType: ValueType.TEXT }, // 거래처등록구분명
        { fieldName: 'dealcoGrpNm', dataType: ValueType.TEXT }, // 거래처그룹명
        { fieldName: 'dealcoClNm1', dataType: ValueType.TEXT }, // 거래처구분코드명
        { fieldName: 'dealcoCd', dataType: ValueType.TEXT }, // 거래처코드
        { fieldName: 'dealcoNm', dataType: ValueType.TEXT }, // 거래처명
        { fieldName: 'modUserNm', dataType: ValueType.TEXT }, // 처리자
        { fieldName: 'modDtm', dataType: ValueType.TEXT }, // 처리일시
        { fieldName: 'effStaDtm', dataType: ValueType.TEXT }, // 유효시작일시
        { fieldName: 'effEndDtm', dataType: ValueType.TEXT }, // 유효종료일시

        { fieldName: 'hstSeq', dataType: ValueType.TEXT }, // 이력순번
        { fieldName: 'dealcoClCd1', dataType: ValueType.TEXT }, // 거래처구분
        { fieldName: 'dealcoGrpCd', dataType: ValueType.TEXT }, // 거래처그룹
        { fieldName: 'dealcoRgstClCd', dataType: ValueType.TEXT }, // 거래처등록구분
        { fieldName: 'delYn', dataType: ValueType.TEXT }, // 사용여부
    ],
    columns: [
        {
            name: 'dealcoRgstClNm',
            fieldName: 'dealcoRgstClNm',
            type: 'data',
            header: { text: '거래처등록구분명' },
            editable: false,
        },
        {
            name: 'dealcoGrpNm',
            fieldName: 'dealcoGrpNm',
            type: 'data',
            header: { text: '거래처그룹' },
            editable: false,
        },
        {
            name: 'dealcoClNm1',
            fieldName: 'dealcoClNm1',
            type: 'data',
            header: { text: '거래처구분' },
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: { text: '거래처코드' },
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: { text: '거래처명' },
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            header: {
                text: '처리자',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            editable: false,
            lookupDisplay: true,
            type: 'data',

            styles: {
                textAlignment: 'center',
                datetimeFormat: 'yyyy-MM-dd HH:mm:ss',
            },
            header: {
                text: '처리일시',
                showTooltip: false,
            },
        },
        {
            name: 'effStaDtm',
            fieldName: 'effStaDtm',
            editable: false,
            lookupDisplay: true,
            type: 'data',
            // styles: {
            //     textAlignment: 'center',
            //     datetimeFormat: 'yyyy-MM-dd HH:mm:ss',
            // },
            header: {
                text: '유효시작일시',
                showTooltip: false,
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'effEndDtm',
            fieldName: 'effEndDtm',
            editable: false,
            lookupDisplay: true,
            type: 'data',
            // styles: {
            //     textAlignment: 'center',
            //     datetimeFormat: 'yyyy-MM-dd HH:mm:ss',
            // },
            header: {
                text: '유효종료일시',
                showTooltip: false,
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'delYn',
            fieldName: 'delYn',
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            editable: false,
        },
    ],
    layout: [
        'dealcoRgstClNm',
        'dealcoGrpNm',
        'dealcoClNm1',
        'dealcoCd',
        'dealcoNm',
        'modUserNm',
        'modDtm',
        'effStaDtm',
        'effEndDtm',
    ],
}
