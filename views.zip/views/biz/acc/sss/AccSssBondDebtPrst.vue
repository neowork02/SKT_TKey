<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 관계사채권채무현황<전사>
 * 설명: 조회,상세 
 * 작성자: P180190
 * 작성일: 2022.07.19
------------------------------------------------>
<template>
    <div class="content">
        <h1>관계사채권채무현황&lt;전사&gt;</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="init()"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        v-model="org"
                        labelName="영업센터"
                        placeholder="전사"
                        :objAuth="objAuth"
                        :disabled="true"
                    ></TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        v-model="accYm_"
                    >
                    </TCComDatePicker>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="관계사채권채무현황<전사> 목록"
                :gridObj="gridObj"
                :isExceldown="true"
                @excelDownBtn="downloadExcelAll"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <!-- Backend에서 넘어오는 값이 없어 주석처리함 
                         <TCComPaging
                        :totalPage="gridData.totalPage"
                        :apiFunc="getSktCmmsOrgList"
                        :rowCnt="rowCnt"
                        @input="chgRowCnt"
                    /> -->

            <AccSssBondDebtPrstDtl
                v-if="popup.adjustDtl.showBool === true"
                ref="popup"
                :dialogShow.sync="popup.adjustDtl.showBool"
                :popupParams.sync="popupParams"
            />
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
import {
    // CommonGrid,
    CommonUtil,
} from '@/utils'
import moment from 'moment'
//====================상세팝업====================
import AccSssBondDebtPrstDtl from '@/views/biz/acc/sss/AccSssBondDebtPrstDtl'
import BondDebtApi from '@/api/biz/acc/sss/AccSssBondDebtPrst'
import { GRID_HEADER } from '@/const/grid/acc/sss/AccSssBondDebtPrstGrid'
import CommonMixin from '@/mixins'
export default {
    name: 'AccSssBondDebtPrst',
    title: '관계사채권채무현황<전사>',
    components: {
        AccSssBondDebtPrstDtl,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,

            //Grid
            objAuth: {},
            tabDefault: {},
            // gridData: {},
            gridObj: {},
            gridHeaderObj: {},

            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            accYm_: moment(new Date()).format('YYYY-MM'),
            accYm: moment(new Date()).format('YYYY-MM'),
            org: '',

            //요청 파라미터
            searchFormData: {
                srchAccYm: '',
            },

            popupParams: {},
            popup: {
                adjustDtl: {
                    showBool: false,
                },
            },
        }
    },
    mounted() {
        // 첫번째 그리드 세팅
        this.grid = this.$refs.grid
        this.gridHeader = this.$refs.gridHeader
        this.grid.setGridState(false, false, false, true)
        this.$refs.grid.gridView.setColumnLayout(this.view.layout) //그리드 Header Layout 세팅하기
        this.grid.gridView.displayOptions.selectionStyle = 'rows'
        this.grid.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.$refs.grid.gridView.onCellDblClicked = this.onCellDblClicked
    },
    computed: {},
    watch: {},
    created() {
        // this.gridData = this.gridSetData()
    },
    methods: {
        // 초기화
        init: function () {
            this.accYm_ = moment(new Date()).format('YYYY-MM')
            this.$refs.grid.setRows([])
        },

        // gridSetData(rowCnt1) {
        //     return new CommonGrid(0, rowCnt1, '', '')
        // },

        // //페이지 표시 행의수 변경처리
        // chgRowCnt1(val) {
        //     this.rowCnt1 = val
        // },

        //================================================
        // :::: 전체 조회 ::::
        // getDebtBondList
        //================================================
        onSearch: function () {
            const srchAccYm = this.accYm_
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
            } else {
                this.searchFormData.srchAccYm = CommonUtil.onlyNumber(
                    this.accYm_
                )
                this.searchForms = { ...this.searchFormData }
                this.getDebtBondList(this.searchForms)
                console.log('관계사채권채무현황<전사> 전체조회 ::::::: 시작')
            }
        },

        getDebtBondList() {
            BondDebtApi.getDebtBondList(this.searchForms).then((res) => {
                if (res) {
                    console.log(
                        '관계사채권채무현황<전사>(조직) 전체조회 ::::::: ',
                        res
                    )
                    this.grid.setRows(res.gridList)
                    console.log(res.gridList)
                    this.grid.setGridIndicator()
                    console.log('관계사채권채무현황<전사> 전체조회 ::::::: 끝')
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },
        //================================================
        // 상세 페이지 POPUP
        //================================================
        onCellDblClicked() {
            this.grid.gridView.onCellDblClicked = (grid, clickData) => {
                this.popup.adjustDtl.popupParams = rowData
                var rowData = grid.getValues(clickData.itemIndex)
                console.log(clickData.dataRow)
                this.popupParams = { ...rowData }
                this.popupParams.srchAccYm = this.accYm_
                this.popup.adjustDtl.showBool = true
            }
        },

        //================================================
        // EXCEL DOWNLOAD
        //================================================
        downloadExcelAll: function () {
            this.searchFormData.srchAccYm = CommonUtil.onlyNumber(this.accYm_)
            BondDebtApi.downloadDebtBondListExcel(this.searchFormData)
            console.log('엑셀다운로드 :::::::')
        },

        // // 팝업 닫으면 부모페이지 재조회
        // onReAccSssBondDebtPrstDtl(retVal) {
        //     if (retVal) {
        //         console.log('retrunData: ', retVal)
        //         // this.accYm_ = retVal
        //         this.onSearch()
        //     }
        // },
    },
}
</script>
