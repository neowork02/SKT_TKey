import '@mdi/font/css/materialdesignicons.css' // Ensure you are using css-loader
import 'font-awesome/css/font-awesome.min.css' // Ensure you are using css-loader
import Vue from 'vue'
import Vuetify from 'vuetify/lib/framework'
//import 'material-design-icons-iconfont/dist/material-design-icons.css' // Ensure you are using css-loader

/*Vue.use(Vuetify)*/
Vue.use(Vuetify, {})

export default new Vuetify({
    icons: {
        iconfont: 'mdi', // default - only for display purposes
    },
    theme: {
        themes: {
            light: {
                primary: '#2A3342',
                secondary: '#1B222E',
                accent: '#d81d1f',
                success: '#2586ee',
                info: '#ffaa2c',
                point: '#d81d1f',
                error: '#d81d1f',
                btn1: '#bbbbbb',
                btn2: '#2A3342',
                basictit: '#222222',
                basicsub: '#444444',
                basiccont: '#666666',
                basiccontlight: '#999999',
                basiccontlight2: '#dddddd',
                tabcolor: '#efa5a5',
                treepoint: '#ff6e6e',
            },
        },
    },
})
