<template>
    <div v-if="this.isGridBizRgstInfo1">
        <!-- SubTit  -->
        <div class="stitHead">
            <h4 class="subTit">사업자정보</h4>
        </div>
        <!-- //SubTit -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="bizRgstInfo.perBizClCd"
                        labelName="사업자구분"
                        :itemList="zbasC00400"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :eRequired="true"
                        @change="changeBiz"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.bizNo"
                        :inputRuleType="CONSTANTS.INPUTRULE_NUM"
                        labelName="사업자번호"
                        :eRequired="true"
                        :disabled="isBizDisabled"
                        :maxlength="13"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 1-2 -->
                <div class="formitem div4" v-if="!isBiz">
                    <TCComCheckBox
                        labelName="외국인여부"
                        v-model="bizRgstInfo.foreigner"
                        itemText="text"
                        itemValue="value"
                        :itemList="[{ value: 'Y', text: '' }]"
                        @change="changeForeigner"
                        :objAuth="objAuth"
                    ></TCComCheckBox>
                </div>
                <div class="formitem div4"></div>
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 1-3 -->
                <div class="formitem div4" v-if="isForeigner">
                    <TCComComboBox
                        v-model="bizRgstInfo.visitQualCd"
                        labelName="체류자격"
                        :itemList="zbasC00710"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div4" v-if="isForeigner">
                    <TCComDatePicker
                        v-model="bizRgstInfo.visitStaDt"
                        labelName="체류기간"
                        calType="DP"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 1-4 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.repUserNm"
                        labelName="대표자명"
                        :eRequired="true"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.repUserNm2"
                        labelName="대표자명2"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 1-4 -->
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.bizConNm"
                        labelName="업태"
                        :eRequired="true"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.typOfBizNm"
                        labelName="종목"
                        :eRequired="true"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="bizRgstInfo.taxTypCd"
                        :itemList="zbasC00230"
                        labelName="과세구분"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :eRequired="true"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 2-3 -->
                <!-- item 2-4 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.taxTypClNm"
                        labelName="과세유형"
                        @input="setData"
                        :objAuth="objAuth"
                        :disabled="true"
                    />
                </div>
                <!-- //item 2-4 -->
                <div class="formitem div4"></div>
                <div class="formitem div4"></div>
            </div>
            <!-- //Search_line 2 -->
            <!-- Search_line 3 -->
            <div class="searchform">
                <!-- item 3-1 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.tradeNm"
                        labelName="상호"
                        :eRequired="true"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 3-1 -->
                <!-- item 3-2 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.repMblPhonNo"
                        labelName="대표이동전화"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 3-2 -->
                <!-- item 3-3 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.telNo"
                        labelName="대표전화"
                        :eRequired="true"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 3-3 -->
                <!-- item 3-4 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.faxNo"
                        labelName="대표Fax"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 3-4 -->
            </div>
            <!-- //Search_line 3 -->

            <!-- Search_line 3 -->
            <div class="searchform">
                <!-- item 4-1 -->
                <div class="formitem div2">
                    <!--  label + 멀티폼_E-mail -->
                    <div class="multiFormEmail">
                        <div class="coltit">
                            <TCComLabel
                                labelName="Email"
                                :eRequired="true"
                                labelClass="line2"
                            />
                        </div>
                        <div class="col1">
                            <TCComTextField
                                v-model="bizRgstInfo.email1"
                                @input="setData"
                                :objAuth="objAuth"
                            />
                        </div>
                        <div class="col0">@</div>
                        <div class="col2">
                            <TCComTextField
                                v-model="bizRgstInfo.email2"
                                :disabled="isEmail"
                                @input="setData"
                                :objAuth="objAuth"
                            />
                        </div>
                        <div class="col3">
                            <TCComComboBox
                                v-model="bizRgstInfo.email3"
                                :addBlankItem="true"
                                blankItemText="선택"
                                blankItemValue=""
                                :eRequired="true"
                                :itemList="emailList"
                                ref="emailAcc1"
                                @change="changeEmail"
                                :objAuth="objAuth"
                            />
                        </div>
                    </div>
                    <!-- //label + 멀티폼_E-mail -->
                </div>
                <!-- //item 4-1 -->
                <!-- item 4-2 -->
                <div class="formitem div2">
                    <TCComRadioBox
                        v-model="bizRgstInfo.taxPrdCd"
                        labelName="세금계산서 발행주기"
                        :eRequired="true"
                        :itemList="taxPrdCdList"
                        labelClass="line2"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>

                <!-- //item 4-2 -->
            </div>
            <!-- //Search_line 4 -->
            <!-- Search_line 6 -->
            <div class="searchform">
                <!-- item 6-1 -->
                <div class="formitem div1">
                    <!-- label + 멀티폼_주소 -->
                    <div class="multiFormAddressType2">
                        <div class="col1">
                            <TCComInputSearch
                                labelName="사업장주소"
                                @appendIconClick="onNewZipSrchClick"
                                v-model="bizRgstInfo.zipCd"
                                @input="setData"
                                :objAuth="objAuth"
                            />
                            <BasBcoNewZipSrchPopup1
                                v-if="showBcoNewZipSrch"
                                :rows="resultNewZipSrchRows"
                                :dialogShow.sync="showBcoNewZipSrch"
                                :parentParam="searchNewZipSrchParam"
                                @confirm="onNewZipSrchSReturnData"
                            />
                        </div>
                        <div class="col2">
                            <TCComTextField
                                class="inBlock w100"
                                v-model="bizRgstInfo.addr"
                                :disabled="true"
                                @input="setData"
                                :objAuth="objAuth"
                            />
                        </div>
                        <div class="col3">
                            <TCComTextField
                                class="inBlock w100"
                                v-model="bizRgstInfo.dtlAddr"
                                @input="setData"
                                :objAuth="objAuth"
                            />
                        </div>
                        <div class="colbtn">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="복사"
                                @click="clickCopy"
                            />
                        </div>
                    </div>
                    <!-- // label + 멀티폼_주소 -->
                </div>
                <!-- //item 6-1 -->
            </div>
            <!-- //Search_line 6 -->
            <!-- Search_line 7 -->
            <div class="searchform">
                <!-- item 7-1 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="bizRgstInfo.spClsBizClNm"
                        labelName="휴페업상태"
                        :disabled="true"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 7-1 -->
                <!-- item 7-2 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        v-model="bizRgstInfo.spClsBizDt"
                        labelName="휴페업일자"
                        :disabled="true"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 7-2 -->
                <!-- item 7-3 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        v-model="bizRgstInfo.spClsOpDt"
                        labelName="휴페업조회일자"
                        :disabled="true"
                        @input="setData"
                        :objAuth="objAuth"
                    />
                </div>
                <!-- //item 7-3 -->
            </div>
            <!-- //Search_line 7 -->
        </div>
        <!-- //Search_div -->
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/tDealcoMgmt/helpers'
import _ from 'lodash'
import { mapGetters } from 'vuex'
import CommonMixin from '@/mixins'
//====================우편번호팝업====================
import BasBcoNewZipSrchPopup1 from '@/views/biz/bas/bco/BasBcoNewZipSrchPopup'
import basBcoNewZipSrchApi from '@/api/biz/bas/bco/basBcoNewZipSrch'
//====================//우편번호팝업====================

export default {
    name: 'BizRgstInfoContainer',
    components: { BasBcoNewZipSrchPopup1 },
    mixins: [CommonMixin],
    props: {},
    async created() {
        this.emailList = this.emailAcc
    },
    data() {
        return {
            objAuth: {},

            isBiz: true,
            isBizDisabled: true,
            isEmail: true,
            isForeigner: false,
            emailList: [],
            bizRgstInfo: {
                perBizClCd: '',
                bizNo: '',
                foreigner: [],
                visitQualCd: '',
                visitStaDt: ['', ''],
                repUserNm: '',
                repUserNm2: '',
                bizConNm: '',
                typOfBizNm: '',
                taxTypCd: '',
                taxTypClNm: '',
                tradeNm: '',
                repMblPhonNo: '',
                telNo: '',
                faxNo: '',
                email1: '',
                email2: '',
                email3: '',
                taxPrdCd: '',
                addr: '',
                dtlAddr: '',
                zipCd: '',
                spClsBizClNm: '',
                spClsBizDt: '',
                spClsOpDt: '',
            },
            storeKey: 'bizRgstInfoData',

            //====================우편번호팝업관련====================
            showBcoNewZipSrch: false, // 팝업 오픈 여부
            searchNewZipSrchParam: {
                addr: '',
                dtlAddr: '',
            },
            resultNewZipSrchRows: [],
            //====================//우편번호팝업관련==================
            isUptBizRgst: false,
        }
    },
    computed: {
        ...serviceComputed,
        ...mapGetters(['CONSTANTS']),
        reqParam: {
            get() {
                return this.reqParams
            },
        },

        //==================== 상세데이터 ==================
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
        //==================== //상세데이터 ==================
        ////////////////// 공통코드 조회
        dealCoGrp: {
            get() {
                return this.DEAL_CO_GRP // 거래처그룹
            },
        },
        zbasC00240: {
            get() {
                return this.ZBAS_C_00240 // 거래처구분
            },
        },
        zbasC00510: {
            get() {
                return this.ZBAS_C_00510 // 거래처유형 (판매점구분)
            },
        },
        zbasC00570: {
            get() {
                return this.ZBAS_C_00570 // 거래처유형 (직영점구분)
            },
        },
        zbasC00530: {
            get() {
                return this.ZBAS_C_00530 // 거래처분류
            },
        },
        zbasC00590: {
            get() {
                return this.ZBAS_C_00590 // 거래처분류 (직영점2차점 거래처분류)
            },
        },
        zbasC00110: {
            get() {
                return this.ZBAS_C_00110 // 전자결재 진행여부
            },
        },
        zbasC00130: {
            get() {
                return this.ZBAS_C_00130 // 전자결재 진행여부
            },
        },
        zbasC00120: {
            get() {
                return this.ZBAS_C_00120 // 전자결재 진행여부
            },
        },
        zbasC00400: {
            get() {
                return this.ZBAS_C_00400 //
            },
        },
        zbasC00710: {
            get() {
                return this.ZBAS_C_00710 //
            },
        },
        zbasC00230: {
            get() {
                return this.ZBAS_C_00230 //
            },
        },
        spClsBizClCd: {
            get() {
                return this.SP_CLS_BIZ_CL_CD // 전자결재 진행여부
            },
        },
        comYn: {
            get() {
                return this.COM_YN // 전자결재 진행여부
            },
        },
        emailAcc: {
            get() {
                return this.EMAIL_ACC // 이메일
            },
        },
        taxPrdCdList: {
            get() {
                return this.TAX_PRD_CD
            },
        },
        ////////////////// 공통코드 조회
        isGridBizRgstInfo1: {
            get() {
                return this.isGridBizRgstInfo
            },
        },
    },
    mounted() {
        this.initData()
    },
    methods: {
        ...serviceMethods,
        initData() {
            this.bizRgstInfo = {
                perBizClCd: '',
                bizNo: '',
                foreigner: [],
                visitQualCd: '',
                visitStaDt: ['', ''],
                repUserNm: '',
                repUserNm2: '',
                bizConNm: '',
                typOfBizNm: '',
                taxTypCd: '',
                taxTypClNm: '',
                tradeNm: '',
                repMblPhonNo: '',
                telNo: '',
                faxNo: '',
                email1: '',
                email2: '',
                email3: '',
                taxPrdCd: '',
                addr: '',
                dtlAddr: '',
                zipCd: '',
                spClsBizClNm: '',
                spClsBizDt: '',
                spClsOpDt: '',
            }
            this.isUptBizRgst = false
        },
        setData() {
            let params = { ...this.bizRgstInfo }

            if (!_.isEmpty(this.bizRgstInfoData)) {
                let checkKeys = [
                    'repUserNm', // 대표자명
                    'bizConNm', // 업태
                    'typOfBizNm', // 종목
                    'taxTypCd', // 과세구분
                    'tradeNm', // 상호
                    'repMblPhonNo', // 대표이동전화
                    'faxNo', // 대표FAX
                    'taxPrdCd', // 세금계산서발행주기
                    'zipCd', // 사업장주소
                ]

                checkKeys.some((key) => {
                    if (
                        !_.isEmpty(this.bizRgstInfoDataOld) &&
                        !_.isEqual(
                            this.bizRgstInfoDataOld[key],
                            this.bizRgstInfoData[key]
                        )
                    ) {
                        this.isUptBizRgst = true
                        return true
                    } else {
                        if (_.isEmpty(this.bizRgstInfoDataOld)) {
                            this.storeSet('bizRgstInfoDataOld', params)
                        }

                        this.isUptBizRgst = false
                    }
                })
            }

            this.storeSet('isBizRgst', this.isUptBizRgst)
            this.storeSet(this.storeKey, params)
        },

        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },

        changeBiz(code) {
            if (_.isEmpty(code) || !_.isEmpty(this.bizRgstInfo.bizNo)) {
                this.isBizDisabled = true
            } else {
                this.isBizDisabled = false
            }
            if (_.isEqual(code, '1')) {
                this.isBiz = false
                //this.bizRgstInfo.bizNo = ''

                this.bizRgstInfo.foreigner = []
                this.isForeigner = false
            } else if (_.isEqual(code, '2') || _.isEmpty(code)) {
                this.isBiz = true
                //this.bizRgstInfo.bizNo = ''
                this.bizRgstInfo.foreigner = []
                this.isForeigner = false
            }
            let params = { ...this.bizRgstInfo }
            this.storeSet(this.storeKey, params)
        },
        changeForeigner(code) {
            if (_.isEqual(code[0], 'Y')) {
                this.isForeigner = true
            } else {
                this.isForeigner = false
            }
        },
        changeEmail(code) {
            _.forEach(this.emailList, (data) => {
                if (_.isEqual(code, data.commCdVal)) {
                    this.bizRgstInfo.email2 = data.commCdValNm
                }
            })
            if (_.isEqual(code, '99')) {
                this.isEmail = false
                this.bizRgstInfo.email2 = ''
            } else {
                this.isEmail = true
            }
            let param = { ...this.bizRgstInfo }
            this.storeSet(this.storeKey, param)
        },

        //===================== 우편번호팝업관련 methods ================================
        clickCopy() {
            this.bizRgstInfo.zipCd = this.strdInfoData.signZipCd
            this.bizRgstInfo.addr = this.strdInfoData.signAddr
            this.bizRgstInfo.dtlAddr = this.strdInfoData.signDtlAddr
            let param = { ...this.bizRgstInfo }
            this.storeSet(this.storeKey, param)
        },
        getZipList() {
            let searchParam = {}
            searchParam['streetNm'] = this.bizRgstInfo.addr
            basBcoNewZipSrchApi.getNewZipCode(searchParam).then((res) => {
                if (!_.isEmpty(res)) {
                    this.bizRgstInfo.addr = _.get(res[0], 'streetNm')
                    this.bizRgstInfo.dtlAddr = _.get(res[0], 'siGunGuBldnNm')
                } else {
                    this.resultNewZipSrchRows = res
                    this.searchNewZipSrchParam.addr = this.bizRgstInfo.addr
                    this.searchNewZipSrchParam.dtlAddr =
                        this.bizRgstInfo.dtlAddr
                    this.showBcoAgencys = true
                }
            })
        },

        // 사용자 TextField 돋보기 Icon 이벤트 처리
        onNewZipSrchClick() {
            if (_.isEqual(this.reqParam.ifYn, 'Y')) return
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultNewZipSrchRows = []
            if (!_.isEmpty(this.bizRgstInfo.addr)) {
                // API 호출
                //this.getZipList()
            } else {
                this.searchNewZipSrchParam.addr = this.bizRgstInfo.addr
                this.searchNewZipSrchParam.dtlAddr = this.bizRgstInfo.dtlAddr

                this.showBcoNewZipSrch = true
            }
        },

        // 주소 TextField 엔터키 이벤트 처리
        onNewZipSrchEnterKey() {
            // 주소 팝업 Row 설정 Prop 변수 초기화
            this.resultNewZipSrchRows = []
            // 검색조건 주소 빈값이면 알림창 오픈
            if (_.isEmpty(this.bizRgstInfo.addr)) {
                this.showTcComAlert('사업장주소를 입력해주세요.')
                return false
            }
            // 주소 정보 조회
            this.getZipList()
        },

        replaceStreetNm(returnData, path) {
            let street
            if (!_.isEmpty(path)) {
                street = _.get(returnData, path) + ' '
            }
            return street
        },
        // 사용자 팝업 리턴 이벤트 처리
        onNewZipSrchSReturnData(returnData) {
            this.bizRgstInfo.zipCd = _.get(returnData, 'zipNum')
            this.bizRgstInfo.addr = _.get(returnData, 'rdAddr1')
            this.bizRgstInfo.dtlAddr = _.get(returnData, 'rdAddr2')
            let param = { ...this.bizRgstInfo }
            this.storeSet(this.storeKey, param)
        },
        //===================== //사용자영업담당자팝업관련 methods ================================
    },
    watch: {
        basPrmDealcoDtlVo: {
            handler: function (values) {
                let detailData = this.bizRgstInfo // 데이터 Set

                _.forEach(Object.keys(detailData), (key) => {
                    if (!_.isEmpty(key)) {
                        // 기본정보셋팅
                        let value = values[key]
                        let isValue = false
                        //let currentDate = moment(new Date()).format('YYYY-MM-DD')
                        if (
                            _.isEqual(value, undefined) ||
                            _.isEqual(value, null) ||
                            _.isEqual(value, '')
                        ) {
                            if (typeof detailData[key] === 'object') {
                                value = []
                            } else {
                                value = ''
                            }
                        } else {
                            isValue = true
                        }

                        // 필터정보셋팅
                        if (_.isEqual(key, 'visitStaDt')) {
                            detailData[key] = isValue ? value : ['', '']
                        } else {
                            detailData[key] = value
                        }
                    }
                })

                let param = { ...detailData }
                this.storeSet('bizRgstInfoDataOld', param)
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
