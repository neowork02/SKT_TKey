/*****************************************
* 업무 그룹명 : 기준정보>대리점검색
* 서브 업무명 : 대리점검색
* 설 명 : 대리점검색 Grid 헤더 정보
* 작 성 자 : 양현모
* 작 성 일 : 2022.04.19
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 양현모  / 2022.04.19
* 변경사유/내역 : 
* ---------------------------------------
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const BAS_BCO_AGENCYS_HEADER = {
    fields: [
        {
            fieldName: 'agencyClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'operDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'aplyEndDt',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'agencyClCd',
            fieldName: 'agencyClCd',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '대리점구분',
            },
        },
        {
            name: 'agencyTypCd',
            fieldName: 'agencyTypCd',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '대리점유형',
            },
        },
        {
            name: 'operDealcoNm',
            fieldName: 'operDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '운영사',
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: {
                text: '대리점코드',
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '대리점명',
            },
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            type: 'data',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '적용시작일',
            },
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            type: 'data',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '적용종료일',
            },
        },
    ],
}
