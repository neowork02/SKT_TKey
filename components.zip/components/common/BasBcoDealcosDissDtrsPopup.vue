<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1400px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">내부거래처-재고이동용입고처</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="searchParam.orgNm"
                                    :codeVal.sync="searchParam.orgCd"
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :eRequired="true"
                                    @enterKey="onDisOrgTreeEnterKey"
                                    @appendIconClick="onDisOrgTreeIconClick"
                                    @input="onDisOrgTreeInput"
                                />
                                <BasBcoDisOrgTreesPopup
                                    v-if="showBcoDisOrgTrees"
                                    :parentParam="searchPopParam"
                                    :rows="resultDisOrgTreeRows"
                                    :dialogShow.sync="showBcoDisOrgTrees"
                                    @confirm="onDisOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div4">
                                <TCComMultiComboBox
                                    v-model="ckParam.dealcoRgstClCd"
                                    :itemList="getDealcoRgstClList"
                                    labelName="거래처등록구분"
                                ></TCComMultiComboBox>
                            </div>
                            <div class="formitem div4">
                                <TCComMultiComboBox
                                    v-model="ckParam.dealcoGrpCd"
                                    :itemList="getDealcoGrpList"
                                    labelName="거래처그룹"
                                ></TCComMultiComboBox>
                            </div>
                            <div class="formitem div4">
                                <TCComMultiComboBox
                                    v-model="ckParam.dealcoClCd1"
                                    :itemList="getDealcoGubunList"
                                    labelName="거래처구분"
                                ></TCComMultiComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComComboBox
                                    v-model="searchParam.dealcoClCd2"
                                    labelName="거래처유형"
                                    :itemList="dealcoClCd2List"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParam.dealcoNm"
                                    labelName="거래처명"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComCheckBox
                                    labelName="정산처리여부"
                                    :itemList="chkData"
                                    v-model="ckParam.onlyAccDeaCoCd"
                                    :disabled="isDisabledOnlyAccDeaCoCd"
                                ></TCComCheckBox>
                            </div>
                            <div class="formitem div4">
                                <TCComCheckBox
                                    labelName="거래종료포함"
                                    :itemList="chkData"
                                    v-model="ckParam.dealEndYn"
                                ></TCComCheckBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2"></div>
                            <div class="formitem div2">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="gridWrap">
                        <TCRealGrid
                            id="grid1"
                            ref="grid1"
                            :editable="true"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>

                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonGrid, CommonUtil } from '@/utils'
//import CommonMsg from '@/utils/CommonMsg'
import { HEADER } from '@/const/grid/bas/bco/BasBcoDealcosDissDtrsHeader'
import API from '@/api/biz/bas/bco/BasBcoDealcosDissDtrs'
import commonApi from '@/api/common/commonCode'
import _ from 'lodash'

//====================재고이동용내부조직팝업(권한)팝업====================
import BasBcoDisOrgTreesPopup from '@/components/common/BasBcoDisOrgTreesPopup'
import basBcoDisOrgTreesApi from '@/api/biz/bas/bco/basBcoDisOrgTrees'
//====================//재고이동용내부조직팝업(권한)팝업====================

export default {
    name: 'BasBcoInrDealcosPopup',
    mixins: [CommonMixin],
    components: {
        BasBcoDisOrgTreesPopup,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },

    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            selectedItem: '',
            isDisabledOnlyAccDeaCoCd: false,
            dealcoRgstClList: [], // 내부거래처등록구분
            dealcoGrpList: [], // 거래처그룹
            dealcoGubunList: [], // 거래처구분
            dealcoClCd2List: [], // 거래처유형

            // 재고이동용입고처
            searchParam: {
                orgLvl: '', //세션레벨
                orgCd: '', //재고이동용입고처orgCd
                orgNm: '',
                dealcoRgstClCd: '', // 내부거래처등록구분
                dealcoGrpCd: '', // 내부거래처그룹
                dealcoClCd1: '', // 내부거래처구분
                dealcoClCd2: '2', //거래처유형
                //dealCd: '', // 내부거래처코드
                dealcoCd: '', //거래처코드
                //sktChnlCd: '', //채널코드
                dealcoNm: '', // 내부거래처명
                onlyAccDeaCoCd: '',
                dealEndYn: '', //거래종료여부
                //basDay: '', //기준년월
                //reqYn: '', //선택여부
                onlyDisUse: '', //재고이동용입고처여부
            },
            ckParam: {
                onlyAccDeaCoCd: [],
                dealEndYn: [], //거래종료
                dealcoRgstClCd: [], // 내부거래처등록구분
                dealcoGrpCd: [],
                dealcoClCd1: [],
            },
            chkData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '',
                },
            ],

            resultProdsRows: [],
            //====================재고이동용내부조직팝업(권한)팝업관련====================
            showBcoDisOrgTrees: false, // 재고이동용내부조직팝업(권한) 팝업 오픈 여부
            searchPopParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 재고이동용내부조직팝업(권한)코드
                orgNm: '', // 재고이동용내부조직팝업(권한)명
                orgLvl: '', // 디스플레이제한레벨
                sLvlList: '', //선택가능레벨 '2,3' : as-is 와동일하게 쉼표로 나열
                all: '', //전체검색여부 Y or null , N..
            },
            resultDisOrgTreeRows: [], // 재고이동용내부조직팝업(권한) 팝업 오픈 여부
            //====================//재고이동용내부조직팝업(권한)팝업관련==================
        }
    },

    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        getDealcoRgstClList() {
            return this.dealcoRgstClList.filter(
                (item) => item.addInfo1 !== 'ETC'
            )
        },
        getDealcoGrpList() {
            let resultList = []
            _.forEach(this.ckParam.dealcoRgstClCd, (data) => {
                const filterList = this.dealcoGrpList.filter(
                    (item) => item.addInfo2 === 'Y' && item.addInfo5 === data
                )
                resultList = [...resultList, ...filterList]
            })
            // console.log('resultList: ', resultList)
            return resultList
        },
        getDealcoGubunList() {
            let resultList = []
            _.forEach(this.ckParam.dealcoGrpCd, (data) => {
                const filterList = this.dealcoGubunList.filter(
                    (item) => item.addInfo1 === data
                )
                resultList = [...resultList, ...filterList]
            })
            // console.log('resultList: ', resultList)
            return resultList
        },
    },

    watch: {
        parentParam: {
            handler: function (value) {
                //거래처코드

                if (
                    (value['dealEndYn'] !== '') == undefined
                        ? ''
                        : value['dealEndYn']
                ) {
                    this.ckParam.dealEndYn = [
                        value['dealEndYn'] == undefined
                            ? ''
                            : value['dealEndYn'],
                    ] //거래종료
                }
                this.searchParam.saleStopYN =
                    value['saleStopYN'] == undefined ? '' : value['saleStopYN'] //판매정지포함여부
                this.searchParam.orgLvl =
                    value['orgLvl'] == undefined ? '' : value['orgLvl'] //조직레벨
                this.searchParam.orgCd =
                    value['orgCd'] == undefined ? '' : value['orgCd'] //조직코드
                this.searchParam.orgNm =
                    value['orgNm'] == undefined ? '' : value['orgNm'] //조직명

                // 2022.10.07 요구사항으로 거래처등록구분 추가
                const dealcoRgstClCd = !value['dealcoRgstClCd']
                    ? ''
                    : value['dealcoRgstClCd']
                if (dealcoRgstClCd !== '') {
                    this.ckParam.dealcoRgstClCd = dealcoRgstClCd.split(',')
                }

                let dealcoGrpCd =
                    value['dealcoGrpCd'] == undefined
                        ? ''
                        : value['dealcoGrpCd'] //거래처구분코드
                if (dealcoGrpCd !== '') {
                    this.ckParam.dealcoGrpCd = dealcoGrpCd.split(',')
                }

                let dealcoClCd1 =
                    value['dealcoClCd1'] == undefined
                        ? ''
                        : value['dealcoClCd1'] //거래처구분코드
                if (dealcoClCd1 !== '') {
                    this.ckParam.dealcoClCd1 = dealcoClCd1.split(',')
                }

                this.searchParam.dealcoClCd2 =
                    value['dealcoClCd2'] == undefined
                        ? ''
                        : value['dealcoClCd2'] //거래처유형코드
                this.searchParam.dealcoNm =
                    value['dealcoNm'] == undefined ? '' : value['dealcoNm'] //거래처명
                this.searchParam.dealcoCd =
                    value['dealcoCd'] == undefined ? '' : value['dealcoCd'] //거래처코드
                this.searchParam.sktChnlCd =
                    value['sktChnlCd'] == undefined ? '' : value['sktChnlCd'] //채널코드
                this.searchParam.onlyDisUse =
                    value['onlyDisUse'] == undefined ? '' : value['onlyDisUse'] //재고전용여부

                if (
                    (value['onlyAccDeaCoCd'] !== '') == undefined
                        ? ''
                        : value['onlyAccDeaCoCd']
                ) {
                    this.ckParam.onlyAccDeaCoCd = [value['onlyAccDeaCoCd']] //정산처리여부
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        getDealcoGrpList: {
            handler: function (value) {
                const dealcoGrpCdList = []
                _.forEach(value, (item) => {
                    dealcoGrpCdList.push(item.commCdVal)
                })
                this.ckParam.dealcoGrpCd = dealcoGrpCdList
            },
            deep: true, // 속성 내부까지 감시
            immediate: false, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        getDealcoGubunList: {
            handler: function (value) {
                const dealcoGubunList = []
                _.forEach(value, (item) => {
                    dealcoGubunList.push(item.commCdVal)
                })
                this.ckParam.dealcoClCd1 = dealcoGubunList
            },
            deep: true, // 속성 내부까지 감시
            immediate: false, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },

    async mounted() {
        this.gridObj = this.$refs.grid1
        // this.gridHeaderObj = this.$refs.gridHeader1
        await this.setBaseData()
        this.setDealcoData()
        this.initGrid()
    },

    methods: {
        init() {
            this.gridData = this.gridSetData()

            if (this.rows.length > 0) {
                if ('Y' === String(this.ckParam.onlyAccDeaCoCd)) {
                    this.isDisabledOnlyAccDealCoCd = true
                }
            } else {
                if (this.searchParam.orgCd === this.orgInfo.orgCd) {
                    this.searchParam.orgNm = this.orgInfo.orgNm
                    this.searchParam.orgLvl = this.orgInfo.orgLvl
                }
            }
        },
        async setBaseData() {
            // 2022.10.07 요구사항으로 거래처등록구분 추가
            this.dealcoRgstClList = await this.getCommCodeList(
                'DEALCO_RGST_CL_CD'
            )
            this.dealcoGrpList = await this.getCommCodeList('DEAL_CO_GRP')
            this.dealcoGubunList = await this.getCommCodeList('ZBAS_C_00240')
            this.dealcoClCd2List = await this.getCommCodeList('ZBAS_C_00110')
        },
        setDealcoData() {
            _.forEach(this.ckParam.dealcoGrpCd, (data) => {
                const findData = _.find(
                    this.dealcoGrpList,
                    (item) => item.commCdVal === data
                )
                if (!this.ckParam.dealcoRgstClCd.includes(findData.addInfo5))
                    this.ckParam.dealcoRgstClCd = [
                        ...this.ckParam.dealcoRgstClCd,
                        findData.addInfo5,
                    ]
            })
        },
        async initGrid() {
            // const commDealcoGrpNm = await this.getCommCodeList('DEAL_CO_GRP')
            // const commDealCoClCd1Nm = await this.getCommCodeList('ZBAS_C_00240')
            // const commDealCoClCd2Nm = await this.getCommCodeList('ZBAS_C_00110')

            this.gridObj.gridView.columnByName('dealcoGrpCd').values =
                CommonUtil.convListToGridLovValues(
                    this.dealcoGrpList,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('dealcoGrpCd').labels =
                CommonUtil.convListToGridLovLabels(
                    this.dealcoGrpList,
                    'commCdValNm'
                )

            this.gridObj.gridView.columnByName('dealcoClCd1').values =
                CommonUtil.convListToGridLovValues(
                    this.dealcoGubunList,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('dealcoClCd1').labels =
                CommonUtil.convListToGridLovLabels(
                    this.dealcoGubunList,
                    'commCdValNm'
                )

            this.gridObj.gridView.columnByName('dealcoClCd2').values =
                CommonUtil.convListToGridLovValues(
                    this.dealcoClCd2List,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('dealcoClCd2').labels =
                CommonUtil.convListToGridLovLabels(
                    this.dealcoClCd2List,
                    'commCdValNm'
                )
            this.gridObj.setGridState(true)
            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                this.selectDataRow = clickData.dataRow
                //빈곳클릭시작업없음
                if (undefined == this.selectDataRow) {
                    return
                }

                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        onInput(node) {
            console.log('input: ', node)
        },
        onActive(node) {
            console.log('active: ', node)
            if (node.length > 0) {
                this.selectedItem = _.clone(node[0])
            }
        },
        onOpen(node) {
            console.log('open: ', node)
        },
        //GridSet Init
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },

        onChange(value) {
            console.log('onChange: ', value)
        },

        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            // if (!_.isEmpty(this.reqParam)) {
            //     this.getProdsList()
            //     this.basBcoProdsShow = true
            // } else {
            //     this.basBcoProdsShow = true
            // }
        },

        //조회 이벤트
        getList() {
            console.log('this.reqParam : ', this.searchParam)

            //##백앤드String으로 받게 되어있음
            // 2022.10.07 요구사항으로 거래처등록구분 추가
            this.searchParam.dealcoRgstClCd = String(
                this.ckParam.dealcoRgstClCd
            )
            //거래처그룹
            this.searchParam.dealcoGrpCd = String(this.ckParam.dealcoGrpCd)
            //거래처구분
            this.searchParam.dealcoClCd1 = String(this.ckParam.dealcoClCd1)

            //정산처리여부
            this.searchParam.onlyAccDeaCoCd = String(
                this.ckParam.onlyAccDeaCoCd
            )

            //체크박스거래종료
            this.searchParam.dealEndYn = String(this.ckParam.dealEndYn)

            //##백앤드String으로 받게 되어있음

            API.getList(this.searchParam).then((resultData) => {
                console.log('resultData : ', resultData.length)
                // INDEX 셋팅

                if (resultData.length > 0) {
                    for (let index = 0; index < resultData.length; index++) {
                        resultData[index].NO = index + 1
                    }
                }

                /*
                else if (resultData.length === 0) {
                    alert('데이터가 없습니다')
                }
                */
                // Get Row Data
                this.gridObj.setRows(resultData)

                console.log('조회완료')
            })
        },

        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            // this.resultProdsRows = []
            // // 검색조건 상품명이 빈값이면 알림창 오픈
            // if (_.isEmpty(this.searchProdForm.prodCd)) {
            //     this.onProdsIconClick()
            // }
            // // 상품팝업 정보 조회
            // this.getProdsList()
        },

        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            // this.reqParam.cdiv_fullOrgNm = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            // this.reqParam.cdiv_fullOrg = _.get(retrunData, 'cdiv_fullOrg')
            // this.reqParam.cdiv_fullOrgNm = _.get(retrunData, 'cdiv_fullOrgNm')
        },
        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('거래처를 선택해주세요.')
                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )

            console.log(jsonData)
            this.$emit('confirm', jsonData)
            this.onClose()

            // let copy1 = this.clone(this.selectedItem)
            // this.$emit('confirm', copy1)
            // this.onClose()
        },

        clone(obj) {
            if (null == obj || 'object' != typeof obj) return obj
            let copy = Object.create(null)
            for (let attr in obj) {
                if (obj.hasOwnProperty.call(obj, attr)) copy[attr] = obj[attr]
            }
            return copy
        },

        onClose() {
            this.activeOpen = false
        },

        onSearch() {
            if ('' != this.searchParam.orgLvl) {
                if (2 > this.searchParam.orgLvl) {
                    this.showTcComAlert('본사사업부로 조회할수 없습니다.')
                    return
                }
            }
            if (_.isEmpty(this.searchParam.orgCd)) {
                this.showTcComAlert('조직을 선택해주세요.')
                return
            }
            this.getList()
        },

        onEnterKey() {
            this.onSearch()
        },

        //===================== 재고이동용내부조직팝업(권한)팝업관련 methods ================================
        // 재고이동용내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 재고이동용내부조직팝업(권한) 팝업 오픈
        setDisOrgTreeListParam() {
            this.searchPopParam.orgNm = this.searchParam.orgNm
            //기준년월에 따라 조직파라미터변경
            this.searchPopParam.basMth = CommonUtil.replaceDash(
                this.searchParam.basDayTemp
            )
        },
        getDisOrgTreeList() {
            basBcoDisOrgTreesApi
                .getDisOrgTreeList(this.searchPopParam)
                .then((res) => {
                    console.log('getDisOrgTreeList then : ', res)
                    // 검색된 재고이동용내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 재고이동용내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 재고이동용내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchParam.basMth = _.get(res[0], 'basMth')
                        this.searchParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchParam.orgNm = _.get(res[0], 'orgNm')
                        this.searchParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultDisOrgTreeRows = res
                        this.showBcoDisOrgTrees = true
                    }
                })
        },
        // 재고이동용내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onDisOrgTreeIconClick() {
            // 재고이동용내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultDisOrgTreeRows = []
            // 검색조건 재고이동용내부조직팝업(권한)명이 빈값이 아니면 재고이동용내부조직팝업(권한) 정보 조회
            // 그 이외는 재고이동용내부조직팝업(권한) 팝업 오픈
            this.setDisOrgTreeListParam()
            if (!_.isEmpty(this.searchParam.orgNm)) {
                this.getDisOrgTreeList()
            } else {
                this.showBcoDisOrgTrees = true
            }
        },
        // 재고이동용내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onDisOrgTreeEnterKey() {
            // 재고이동용내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultDisOrgTreeRows = []
            // 검색조건 재고이동용내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showTcComAlert(
                    '재고이동용내부조직팝업(권한)명을 입력해주세요.'
                )
                return
            }
            // 재고이동용내부조직팝업(권한) 정보 조회
            this.setDisOrgTreeListParam()
            this.getDisOrgTreeList()
        },
        // 재고이동용내부조직팝업(권한) TextField Input 이벤트 처리
        onDisOrgTreeInput() {
            // 입력되는 값이 있으면 재고이동용내부조직팝업(권한) 코드 초기화
            this.searchParam.orgCd = ''
        },
        // 재고이동용내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onDisOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchParam.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //재고이동용내부조직팝업(권한)팝업관련 methods ================================
    },
}
</script>
<style>
.box1 {
    height: 400px;
    overflow-y: scroll;
}
</style>
