/*****************************************
* 업무 그룹명 : 게시판
* 서브 업무명 : 게시판
* 설 명 : 게시판 Grid 헤더 정보
* 작 성 자 : 배수현
* 작 성 일 : 2022.00.00
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 배수현  / 2022.00.00
* 변경사유/내역 : 
* ---------------------------------------
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const BAS_BBS_LIST_NOTICE_HEADER = {
    fields: [
        {
            fieldName: 'textTitle',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'readCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bbsNo',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'textTitle',
            fieldName: 'textTitle',
            type: 'data',
            editable: false,
            width: 300,
            styles: {
                textAlignment: 'center',
            },
            styleName: 'left-column',
            header: {
                text: '제목',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            width: 40,
            header: {
                text: '작성자',
            },
        },
        {
            name: 'readCnt',
            fieldName: 'readCnt',
            type: 'data',
            width: 30,
            header: {
                text: '조회수',
            },
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            width: 70,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '작성일시',
            },
        },
        {
            name: 'bbsNo',
            fieldName: 'bbsNo',
            type: 'data',
            header: {
                text: '게시판번호',
            },
            visible: false,
        },
    ],
}

export const BAS_BBS_LIST_POL_HEADER = {
    fields: [
        {
            fieldName: 'bbsTypeCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsSendYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'textTitle',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'readCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bbsNo',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'bbsTypeCd',
            fieldName: 'bbsTypeCd',
            type: 'data',
            header: {
                text: '정책게시판구분',
            },
        },
        {
            name: 'smsSendYn',
            fieldName: 'smsSendYn',
            type: 'data',
            width: 40,
            header: {
                text: '문자전송여부',
            },
        },
        {
            name: 'textTitle',
            fieldName: 'textTitle',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            styleName: 'left-column',
            width: 300,
            header: {
                text: '제목',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            width: 40,
            header: {
                text: '작성자',
            },
        },

        {
            name: 'readCnt',
            fieldName: 'readCnt',
            type: 'data',
            width: 30,
            header: {
                text: '조회수',
            },
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '작성일시',
            },
        },
        {
            name: 'bbsNo',
            fieldName: 'bbsNo',
            type: 'data',
            width: 70,
            header: {
                text: '게시판번호',
            },
            visible: false,
        },
    ],
}

export const BAS_BBS_LIST_SST_HEADER = {
    fields: [
        {
            fieldName: 'textTitle',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'readCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bbsNo',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'textTitle',
            fieldName: 'textTitle',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            styleName: 'left-column',
            width: 300,
            header: {
                text: '제목',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            width: 40,
            header: {
                text: '작성자',
            },
        },
        {
            name: 'readCnt',
            fieldName: 'readCnt',
            type: 'data',
            width: 30,
            header: {
                text: '조회수',
            },
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            width: 70,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '작성일시',
            },
        },
        {
            name: 'bbsNo',
            fieldName: 'bbsNo',
            type: 'data',
            header: {
                text: '게시판번호',
            },
            visible: false,
        },
    ],
}
export const BAS_BBS_LIST_IPM_HEADER = {
    fields: [
        {
            fieldName: 'textTitle',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'readCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bbsNo',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'textTitle',
            fieldName: 'textTitle',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            styleName: 'left-column',
            width: 300,
            header: {
                text: '제목',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            width: 40,
            header: {
                text: '작성자',
            },
        },
        {
            name: 'readCnt',
            fieldName: 'readCnt',
            type: 'data',
            width: 30,
            header: {
                text: '조회수',
            },
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            width: 70,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '작성일시',
            },
        },
        {
            name: 'bbsNo',
            fieldName: 'bbsNo',
            type: 'data',
            header: {
                text: '게시판번호',
            },
            visible: false,
        },
    ],
}
export const BAS_BBS_REG_HEADER = {
    fields: [
        {
            fieldName: '__rowState',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'noticeYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bbsTypeCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'titleColorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'textTitle',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bbsDtl',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'noticeYn',
            fieldName: 'noticeYn',
            type: 'data',
            header: {
                text: '공지사항여부',
            },
        },
        {
            name: 'bbsTypeCd',
            fieldName: 'bbsTypeCd',
            type: 'data',
            header: {
                text: '게시판구분',
            },
        },
        {
            name: 'titleColorNm',
            fieldName: 'titleColorNm',
            type: 'data',
            header: {
                text: '제목색상',
            },
        },
        {
            name: 'textTitle',
            fieldName: 'textTitle',
            type: 'data',
            header: {
                text: '제목',
            },
        },
        {
            name: 'bbsDtl',
            fieldName: 'bbsDtl',
            type: 'data',
            header: {
                text: '글내용',
            },
        },
    ],
}
export const STORE_LIST_HEADER = {
    fields: [
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: {
                text: '매장명',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            editable: false,
            header: {
                text: '거래처코드',
            },
            visible: false,
        },
    ],
}
export const USER_LIST_HEADER = {
    fields: [
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            header: {
                text: '사용자명',
            },
        },
        {
            name: 'userId',
            fieldName: 'userId',
            type: 'data',
            editable: false,
            header: {
                text: '사용자아이디',
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            header: {
                text: '소속조직',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: {
                text: '거래처명',
            },
        },
    ],
}

export const USER_CHK_LIST_HEADER = {
    fields: [
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            header: {
                text: '사용자명',
            },
        },
        {
            name: 'userId',
            fieldName: 'userId',
            type: 'data',
            editable: false,
            header: {
                text: '사용자아이디',
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            header: {
                text: '소속조직',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: {
                text: '거래처명',
            },
        },
    ],
}

export const CSV_HEADER = {
    fields: [
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'userId',
            fieldName: 'userId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '아이디',
                showTooltip: false,
            },
        },
    ],
}

export const USER_SEARCH_HEADER = {
    fields: [
        {
            fieldName: 'bbsTypeCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bbsTargetUser',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'viewYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'viewDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'bbsTypeCd',
            fieldName: 'bbsTypeCd',
            type: 'data',
            header: {
                text: '게시글타입',
            },
        },
        {
            name: 'bbsTargetUser',
            fieldName: 'bbsTargetUser',
            type: 'data',
            header: {
                text: '대상자ID',
            },
        },
        {
            name: 'viewYn',
            fieldName: 'viewYn',
            type: 'data',
            header: {
                text: '확인여부',
            },
        },
        {
            name: 'viewDtm',
            fieldName: 'viewDtm',
            type: 'data',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '최근확인일시',
            },
        },
    ],
}
