<template>
    <TCComDialog :dialogShow.sync="activeOpenColor" size="1500px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">수작업카드입금정산 엑셀업로드</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div2">
                                <TCComFileInput
                                    :accept="'.xls,.xlsx'"
                                    labelName="첨부파일"
                                    @change="onChangeExcelFile"
                                ></TCComFileInput>
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div4">
                                <TCComDatePicker
                                    labelName="정산일"
                                    calType="D"
                                    v-model="searchParams.searchFixDt_"
                                    @change="checkChangeFixDt"
                                >
                                </TCComDatePicker>
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 :오른쪽 정렬 버튼 영역 -->
                            <div class="formitem div4">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_save"
                                            labelName="엑셀반영"
                                            @click="onSave"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 1-3 :오른쪽 정렬 버튼 영역 -->
                        </div>
                        <!-- //Search_line 1 -->
                    </div>
                    <!-- //Search_div -->

                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="popGridHeader1"
                            ref="popGridHeader1"
                            :gridObj="gridObj"
                            gridTitle="카드입금정산 엑셀업로드"
                        >
                            <!-- TCRealGridHeader 영역에 양식다운로드 추가버튼_오른쪽 -->
                            <template #gridBtnArea>
                                <TCComButton
                                    :Vuetify="false"
                                    eClass="btn_noline btn_ty04"
                                    eAttr="ico_exeldown"
                                    labelName="양식다운로드"
                                    @click="onDownExcelUpTemplate"
                                />
                            </template>
                        </TCRealGridHeader>
                        <TCRealGrid
                            id="popGrid1"
                            ref="popGrid1"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>
                    <!-- //gridWrap -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="onClose"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
import moment from 'moment'
import attachApi from '@/api/common/attachedFile'
import pacApi from '@/api/biz/acc/pac'
import CommonMixin from '@/mixins'
import { AccUtil } from '@/views/biz/acc'
import { AccExcelUpload } from '@/views/biz/acc'
import { GRID_HEADER } from '@/const/grid/acc/pac/AccPacHndopCardDpstAccMgmtExcelPopupGrid'

export default {
    name: 'AccPacHndopCardDpstAccMgmtExcelPopup',
    title: '수작업카드입금정산관리 카드정산엑셀업로드 팝업',
    mixins: [CommonMixin],
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list: [],
            gridObj: {},
            searchParams: {
                saveType: 'CONFIRM',
                searchFixDt_: moment().format('YYYY-MM-DD'),
                searchFixDt: moment().format('YYYYMMDD'),
                checkedRows: [],
            },
            requiredExcelGrid: {
                fixDt: '정산일',
                saleMgmtNo: '수납관리번호',
                saleMgmtSeq: '변경순번',
                payMgmtNo: '수납번호',
                payAmt: '수납금액',
                dpstAccAmt: '입금금액',
                dpstAccCmmsAmt: '수수료',
            },

            accPacCloseYm: '',
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpenColor: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        'searchParams.searchFixDt_'(newVal) {
            var _newVal = newVal
            if (!_.isEmpty(newVal)) {
                _newVal = newVal.replace(/-/g, '')
            }

            this.searchParams.searchFixDt = _newVal
        },
    },
    mounted() {
        console.log('excelPopup')
        this.gridObj = this.$refs.popGrid1
        this.gridObj.setGridState(false, false, false, false)
        // 마감일자 조회
        this.getAccPac()
    },
    methods: {
        onClose: function () {
            this.activeOpenColor = false
        },
        onReset: function () {
            this.list = []
            this.gridObj.setRows(this.list)
        },

        async getAccPac() {
            pacApi.getLastAccPacCloseYm().then((res) => {
                this.accPacCloseYm = res.maxClSdt
                console.log('this.accPacCloseYm', this.accPacCloseYm)
            })
        },
        async onSave() {
            console.log('조회된', this.accPacCloseYm)
            console.log('입력된', this.searchParams.searchFixDt)
            this.searchParams.checkedRows = []

            if (this.accPacCloseYm >= this.searchParams.searchFixDt) {
                this.showTcComAlert(
                    '정산일은 최종 일마감 일자 [' +
                        moment(this.accPacCloseYm).format('YYYY-MM-DD') +
                        '] 보다 커야 합니다.'
                )
                return
            }

            this.list.map((rowData) => {
                if (AccUtil.isEmpty(rowData.errDesc)) {
                    this.searchParams.checkedRows.push(rowData)
                }
            })

            if (this.searchParams.checkedRows.length == 0) {
                await this.showTcComAlert('정상적인 데이터가 한건도 없습니다.')
                return
            }

            const confirmMsg2 = await this.showTcComConfirm(
                '오류사항이 발생된 행은 업로드시 자동제외합니다. 계속하시겠습니까?'
            )
            if (!confirmMsg2) {
                return
            }

            pacApi
                .saveAccPacHndopCardDpstAccMgmtList(this.searchParams)
                .then((res) => {
                    if (res.resultCode == 'SUCCESS') {
                        this.showTcComAlert('반영되었습니다.')
                    } else if (res.resultCode == 'FAIL') {
                        this.showTcComAlert(res.resultMessage)
                    }
                    this.$parent.onSearch()
                    this.onClose()
                })
        },
        onDownExcelUpTemplate: function () {
            attachApi.downloadSampleFile('421') //  수작업카드입금정산엑셀업로드양식
        },
        onChangeExcelFile: function (f) {
            var tabNum = 1
            var pageType = 'card'
            AccExcelUpload.onChange(
                pageType,
                tabNum,
                f,
                this.view.columns,
                this.onReset,
                this.callbackExcelUpload
            )
        },
        /**
         * 엑셀업로드 파일을 선택한 이후에 실행되는 callback 함수
         */
        async callbackExcelUpload(list) {
            if (list) {
                for (var i = 0; i < list.length; i++) {
                    // 날짜타입 컬럼인 경우 날짜형식으로 변경
                    // if (!AccUtil.isEmpty(list[i].fixDt)) {
                    //     list[i].fixDt = AccUtil.dateToFormat(
                    //         new Date(list[i].fixDt),
                    //         'YYYYMMDD'
                    //     )
                    // }
                    // if (!AccUtil.isEmpty(list[i].payDtm)) {
                    //     list[i].payDtm = AccUtil.dateToFormat(
                    //         new Date(list[i].payDtm),
                    //         'YYYYMMDD'
                    //     )
                    // }

                    // 필수항목 체크
                    var checkRequired = AccExcelUpload.getCheckRequired(
                        list[i],
                        this.requiredExcelGrid
                    )
                    if (checkRequired.isPass == false) {
                        list[i].errDesc = checkRequired.errMsg
                        continue
                    }

                    // 정산일 체크
                    if (this.searchParams.searchFixDt != list[i].fixDt) {
                        list[i].errColumn = 'payAmt'
                        list[i].errDesc =
                            '엑셀의 정산일과 화면의 정산일이 동일해야 합니다.'
                        continue
                    }

                    // 금액이 숫자인지 체크
                    if (
                        isNaN(list[i].payAmt) ||
                        isNaN(list[i].dpstAccAmt) ||
                        isNaN(list[i].dpstAccCmmsAmt)
                    ) {
                        list[i].errDesc = '금액은 숫자만 입력해 주세요.'
                        continue
                    }

                    // 금액 일치여부 체크
                    if (
                        Number(list[i].payAmt) !=
                        Number(list[i].dpstAccAmt) +
                            Number(list[i].dpstAccCmmsAmt)
                    ) {
                        list[i].errDesc =
                            '[입금금액+수수료]는 수납금액과 동일해야 합니다.'
                        continue
                    }

                    // 수수료가 0 이하인지 체크
                    if (
                        Number(list[i].payAmt) > 0 &&
                        Number(list[i].dpstAccCmmsAmt) < 0
                    ) {
                        list[i].errDesc =
                            '수수료를 다시 한번 확인해 주세요. 0보다 커야합니다.'
                        continue
                    }

                    // 수수료가 4% 초과인지 체크
                    if (
                        Math.abs(list[i].payAmt) * 0.04 <
                        Math.abs(list[i].dpstAccCmmsAmt)
                    ) {
                        list[i].errDesc =
                            '수수료를 다시 한번 확인해 주세요. 수납금액의 4%를 초과할 수 없습니다.'
                        continue
                    }

                    await pacApi.getCardAccListByExcel(list[i]).then((res) => {
                        if (AccUtil.isEmpty(res)) {
                            list[i].errDesc =
                                '조건에 맞는 대상 데이터가 존재하지 않습니다.'
                            return
                        }
                        if ('N' != res.fixYn) {
                            list[i].errDesc = '미확정된 내역이 아닙니다.'
                            return
                        }
                        if ('N' == res.modYn) {
                            list[i].errDesc = '일마감일자보다 커야 합니다.'
                            return
                        }
                    })
                }

                this.list = list
                this.gridObj.setRows(this.list)
            }

            // document.getElementById('fileInput').value = ''
        },
        /**
         * 정산일 변경시 체크
         */
        checkChangeFixDt(fixDt) {
            var isChange = false
            var searchFixDt = AccUtil.dateToFormat(new Date(fixDt), 'YYYYMMDD')
            this.list.map((json) => {
                if (json.fixDt != searchFixDt) {
                    json.errColumn = 'fixDt'
                    json.errDesc = '정산일이 동일해야 합니다.'
                    isChange = true
                } else {
                    if (json.errColumn == 'fixDt') {
                        json.errColumn = ''
                        json.errDesc = ''
                        isChange = true
                    }
                }
            })

            if (isChange) {
                this.gridObj.setRows(this.list)
            }
        },
    },
}
</script>
