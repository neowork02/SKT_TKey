/*****************************************
 * 업무 그룹명 : 판매관리
 * 서브 업무명 : 소매매출-소매/위탁매출수납관리상세
 * 설 명 : 소매/위탁매출수납관리상세 Grid 헤더
 * 작 성 자 : 양현모
 * 작 성 일 : 2022.07.18
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const SALE_PAY_DTL_HEADER = {
    fields: [
        {
            fieldName: 'saleChgDtm',
            dataType: ValueType.TEXT, // 매출일
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, // 판매관리번호
        },
        {
            fieldName: 'cntrctMgmtNum',
            dataType: ValueType.TEXT, // 계약관리번호
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, // 서비스관리번호
        },
        {
            fieldName: 'custNm',
            dataType: ValueType.TEXT, // 고객명
        },
        {
            fieldName: 'svcNum',
            dataType: ValueType.TEXT, // 개통번호
        },
        {
            fieldName: 'dsNetCd',
            dataType: ValueType.TEXT, // 약정조건
        },
        {
            fieldName: 'saleDtlTyp',
            dataType: ValueType.TEXT, // 판매유형
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT, // 요금제
        },
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, // 수납관리번호
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, // 정산처코드 As-is : stlPlc
        },
        {
            fieldName: 'objAmt',
            dataType: ValueType.NUMBER, // 수납대상금액
        },
        {
            fieldName: 'dealCoCl',
            dataType: ValueType.TEXT, // 거래처구분코드
        },
        {
            fieldName: 'orgYn',
            dataType: ValueType.TEXT, // 판매처여부
        },
        {
            fieldName: 'saleClCd',
            dataType: ValueType.TEXT, // 판매구분코드
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT, // 판매변경순번
        },
        {
            fieldName: 'payTyp',
            dataType: ValueType.TEXT, // 수납유형
        },
        {
            fieldName: 'paySt',
            dataType: ValueType.TEXT, // 수납상태
        },
        {
            fieldName: 'procCl',
            dataType: ValueType.TEXT, // 처리상태
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, // 수납일자
        },
        {
            fieldName: 'prodSaleNo',
            dataType: ValueType.TEXT, // 상품판매번호
        },
        {
            fieldName: 'gnrlPaymentYn',
            dataType: ValueType.TEXT, // 수납여부
        },
        {
            fieldName: 'pkgSaleNo',
            dataType: ValueType.TEXT, // 패키지주문번호
        },
        {
            fieldName: 'lastYn',
            dataType: ValueType.TEXT, // 서비스관리최종이력여부
        },
        {
            fieldName: 'mdlNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'taxTyp',
            dataType: ValueType.TEXT, // 과세유형
        },
        {
            fieldName: 'cancelPayDtm',
            dataType: ValueType.TEXT, // 수납취소일
        },
        {
            fieldName: 'cancelRmks',
            dataType: ValueType.TEXT, // 비고
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT, // 거래처구분코드
        },
        {
            fieldName: 'ordId',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'webOrdNo',
            dataType: ValueType.TEXT, // 웹주문번호
        },
        {
            fieldName: 'ordMgmtNo',
            dataType: ValueType.TEXT, // 주문관리번호
        },
        {
            fieldName: 'ordDpstSeq',
            dataType: ValueType.TEXT, // 주문입금순번
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, // 수납대상금액BO
        },
    ],
    columns: [
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            width: '100',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '매출일',
            },
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            width: '100',
            header: {
                text: '판매관리번호',
            },
        },
        {
            name: 'cntrctMgmtNum',
            fieldName: 'cntrctMgmtNum',
            type: 'data',
            width: '100',
            header: {
                text: '계약관리번호',
            },
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            width: '100',
            header: {
                text: '서비스관리번호',
            },
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            width: '100',
            header: {
                text: '고객명',
            },
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            width: '100',
            header: {
                text: '개통번호',
            },
        },
        {
            name: 'dsNetCd',
            fieldName: 'dsNetCd',
            type: 'data',
            width: '100',
            header: {
                text: '약정조건',
            },
        },
        {
            name: 'saleDtlTyp',
            fieldName: 'saleDtlTyp',
            type: 'data',
            width: '120',
            header: {
                text: '판매유형',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            width: '100',
            header: {
                text: '요금제',
            },
        },
    ],
}

export const PAY_REQ_DTL_HEADER = {
    fields: [
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, // 판매관리번호
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델
        },
        {
            fieldName: 'eqpSerNo',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'twdOrdNum',
            dataType: ValueType.TEXT, // (TWD)주문번호
        },
        {
            fieldName: 'mdlPolSalePrc',
            dataType: ValueType.NUMBER, // 고객부담금
        },
        {
            fieldName: 'mdlCashSalePrc',
            dataType: ValueType.NUMBER, // 매출금액
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, // 수납일
        },
        {
            fieldName: 'payMgmtNo',
            dataType: ValueType.TEXT, // 수납번호
        },
        {
            fieldName: 'payMthdCd',
            dataType: ValueType.TEXT, // 수납방법
        },
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, // 수납관리번호
        },
        {
            fieldName: 'saleClCd',
            dataType: ValueType.TEXT, // 판매구분코드
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT, // 판매처리순번
        },
        {
            fieldName: 'disClCd',
            dataType: ValueType.TEXT, // 재고구분코드
        },
        {
            fieldName: 'ordId',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'webOrdNo',
            dataType: ValueType.TEXT, // 웹주문번호
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 처리자ID
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 수정일시
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT, //  처리자
        },
        {
            fieldName: 'payTyp',
            dataType: ValueType.TEXT, // 수납유형
        },
    ],
    columns: [
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '판매관리번호',
            },
            footer: {
                text: '수납대상금액',
            },
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            editable: false,
            header: {
                text: '모델',
            },
        },
        {
            name: 'eqpSerNo',
            fieldName: 'eqpSerNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'twdOrdNum',
            fieldName: 'twdOrdNum',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '(TWD)주문번호',
            },
        },
        {
            name: 'mdlPolSalePrc',
            fieldName: 'mdlPolSalePrc',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            editable: false,
            header: {
                text: '고객부담금',
            },
        },
        {
            name: 'mdlCashSalePrc',
            fieldName: 'mdlCashSalePrc',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            editable: true,
            header: {
                text: '매출금액',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            // 2022.12.30 이정현M 위탁일때도 수정가능하게 변경
            // styleCallback(grid, dataCell) {
            //     const ret = { editable: true }
            //     const itemIndex = dataCell.index.itemIndex
            //     const payTyp = grid.getValue(itemIndex, 'payTyp') ?? ''

            //     if (payTyp === '위탁') {
            //         ret.editable = false
            //     }

            //     return ret
            // },
        },
    ],
    footerLayout: [
        {
            name: 'footerGroup',
            header: { visible: false },
            direction: 'horizontal',
            items: [
                {
                    column: 'gnrlSaleNo',
                    footerUserSpans: [{ colspan: 6 }],
                },
            ],
        },
        'prodClCd',
        'prodNm',
        'eqpSerNo',
        'twdOrdNum',
        'mdlPolSalePrc',
        'mdlCashSalePrc',
    ],
}

export const PAY_DTL_HEADER = {
    fields: [
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, // 수납관리번호
        },
        {
            fieldName: 'payMgmtNo',
            dataType: ValueType.TEXT, // 수납번호
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, // 수납날짜
        },
        {
            fieldName: 'payAmt',
            dataType: ValueType.NUMBER, // 수납금액
        },
        {
            fieldName: 'payMthdCd',
            dataType: ValueType.TEXT, // 수납방법
        },
        {
            fieldName: 'cardAprvNo',
            dataType: ValueType.TEXT, // 카드승인번호
        },
        {
            fieldName: 'refNo',
            dataType: ValueType.TEXT, // 레퍼런스번호
        },
        {
            fieldName: 'cardCoCd',
            dataType: ValueType.TEXT, // 카드사
        },
        {
            fieldName: 'unpayBamt',
            dataType: ValueType.NUMBER, // 미수납잔액
        },
        {
            fieldName: 'ediYn',
            dataType: ValueType.TEXT, // 수납구분
        },
        {
            fieldName: 'issueSignType',
            dataType: ValueType.TEXT, // 현금영수증 발행정보
        },
        {
            fieldName: 'statConf',
            dataType: ValueType.TEXT, // 발행번호
        },
        {
            fieldName: 'giftCardTypCd',
            dataType: ValueType.TEXT, // 상품권권종 As-is : giftCardTyp
        },
        {
            fieldName: 'giftCardCnt',
            dataType: ValueType.NUMBER, // 상품권매수
        },
        {
            fieldName: 'giftCardAmt',
            dataType: ValueType.NUMBER, // 금액
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, // 비고
        },
        {
            fieldName: 'tmpUnbay',
            dataType: ValueType.NUMBER, // TMPUNBAY
        },
        {
            fieldName: 'cardAprvDtm',
            dataType: ValueType.TEXT, // 카드승인날짜 As-is : cardAprvDt
        },
        {
            fieldName: 'trmsDtm',
            dataType: ValueType.TEXT, // 거래일시
        },
        {
            fieldName: 'cardEqpNo',
            dataType: ValueType.TEXT, // 카드단말기번호
        },
        {
            fieldName: 'payCl',
            dataType: ValueType.TEXT, // 수납구분
        },
        {
            fieldName: 'giftCardFlag',
            dataType: ValueType.TEXT, // 상품권여부
        },
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT, // 체크
        },
        {
            fieldName: 'saleMgmtSeq',
            dataType: ValueType.TEXT, // 수납관리순번
        },
        {
            fieldName: 'dpstAccAmt',
            dataType: ValueType.TEXT, // 입금정산금액
        },
        {
            fieldName: 'dpstAccCmmsAmt',
            dataType: ValueType.TEXT, // 입금정산수수료
        },
        {
            fieldName: 'fixYn',
            dataType: ValueType.TEXT, // 정산여부
        },
        {
            fieldName: 'fixDt',
            dataType: ValueType.TEXT, // 정산일
        },
        {
            fieldName: 'cnclFixYn',
            dataType: ValueType.TEXT, // 카드취소정산여부
        },
        {
            fieldName: 'cnclFixDt',
            dataType: ValueType.TEXT, // 카드취소정산일자
        },
        {
            fieldName: 'webOrdNo',
            dataType: ValueType.TEXT, // 웹주문번호
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT, // 삭제여부
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, // 수정횟수
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT, // 처리자ID
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 수정자ID
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 수정일시
        },
        {
            fieldName: 'ordMgmtNo',
            dataType: ValueType.TEXT, // 주문관리번호
        },
        {
            fieldName: 'ordId',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'ordDpstSeq',
            dataType: ValueType.TEXT, // 주문순번
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, // 판매관리번호
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT, // 판매관리순번
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, // 정산처코드
        },
        {
            fieldName: 'bankCardCoCd',
            dataType: ValueType.TEXT, // 은행카드사코드
        },
        {
            fieldName: 'vrAcntNo',
            dataType: ValueType.TEXT, // 가상계좌번호
        },
        {
            fieldName: 'ncRecStatus',
            dataType: ValueType.TEXT, // 레코드추가수정삭제판별용
        },
    ],
    columns: [
        {
            name: 'saleMgmtNo',
            fieldName: 'saleMgmtNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '수납관리번호',
            },
        },
        {
            name: 'payMgmtNo',
            fieldName: 'payMgmtNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '수납번호',
            },
        },
        {
            name: 'payAmt',
            fieldName: 'payAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '수납금액',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const ediYn = grid.getValue(itemIndex, 'ediYn') ?? ''
                const payMgmtNo = grid.getValue(itemIndex, 'payMgmtNo') ?? ''
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''
                const payAmt = dataCell.value ?? 0

                if (ediYn === 'Y') {
                    ret.editable = false
                } else if (payMgmtNo.length > 5) {
                    ret.editable = false
                } else if (payMthdCd === 'PM03') {
                    ret.editable = false
                } else if (payAmt < 0) {
                    ret.editable = false
                } else {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'payMthdCd',
            fieldName: 'payMthdCd',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '수납방법',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const ediYn = grid.getValue(itemIndex, 'ediYn') ?? ''

                if (ediYn !== 'Y') {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'cardAprvNo',
            fieldName: 'cardAprvNo',
            type: 'data',
            width: '100',
            header: {
                text: '카드승인번호',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                // 수납구분 카드 인 경우
                if (payMthdCd === 'PM04') {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'refNo',
            fieldName: 'refNo',
            type: 'data',
            width: '100',
            header: {
                text: '레퍼런스번호',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                // 수납구분 카드 인 경우
                if (payMthdCd === 'PM04') {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'cardCoCd',
            fieldName: 'cardCoCd',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '카드사',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                // 수납구분 카드 인 경우
                if (payMthdCd === 'PM04') {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'unpayBamt',
            fieldName: 'unpayBamt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            editable: false,
            header: {
                text: '미수납잔액',
            },
        },
        {
            name: 'ediYn',
            fieldName: 'ediYn',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            editable: false,
            header: {
                text: '수납구분',
            },
        },
        {
            name: 'issueSignType',
            fieldName: 'issueSignType',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '발행구분',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                // 수납구분 현금/상품권 인 경우
                if (payMthdCd === 'PM01' || payMthdCd === 'PM03') {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'statConf',
            fieldName: 'statConf',
            type: 'data',
            width: '100',
            header: {
                text: '발행번호',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''
                const issueSignType =
                    grid.getValue(itemIndex, 'issueSignType') ?? ''

                // 수납구분 현금/상품권 인 경우
                if (payMthdCd === 'PM01' || payMthdCd === 'PM03') {
                    // 발행구분 빈값 또는 무기명인 경우
                    if (issueSignType === '' || issueSignType === '6') {
                        ret.editable = false
                    } else {
                        ret.editable = true
                    }
                }

                return ret
            },
        },
        {
            name: 'giftCardTypCd',
            fieldName: 'giftCardTypCd',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '권종',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                // 수납구분 상품권인 경우
                if (payMthdCd === 'PM03') {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'giftCardCnt',
            fieldName: 'giftCardCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '매수',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                // 수납구분 상품권인 경우
                if (payMthdCd === 'PM03') {
                    ret.editable = true
                }
                return ret
            },
        },
        {
            name: 'giftCardAmt',
            fieldName: 'giftCardAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            editable: false,
            header: {
                text: '금액',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '비고',
            },
        },
    ],
    headerLayout: [
        'saleMgmtNo',
        'payMgmtNo',
        'payAmt',
        'payMthdCd',
        'cardAprvNo',
        'refNo',
        'cardCoCd',
        'unpayBamt',
        'ediYn',
        {
            name: '현금영수증 발행정보',
            direction: 'horizontal',
            items: ['issueSignType', 'statConf'],
        },
        {
            name: '상품권',
            direction: 'horizontal',
            items: ['giftCardTypCd', 'giftCardCnt', 'giftCardAmt'],
        },
        'rmks',
    ],
}
