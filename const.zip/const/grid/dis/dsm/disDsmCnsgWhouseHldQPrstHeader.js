import { ValueType } from 'realgrid'

export const DisDsmCnsgWhouseHldQPrst_GRID_HEADER = {
    fields: [
        {
            fieldName: 'asgnDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', // 일자
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, // 대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, // 대리점명
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 관리조직
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'fixCrdtPrchsPrc',
            dataType: ValueType.NUMBER, // 상품매입가
        },
        {
            fieldName: 'fixCashPrchsPrc',
            dataType: ValueType.NUMBER, // 실제매입가
        },
        {
            fieldName: 'disQty',
            dataType: ValueType.NUMBER, // 보유수량
        },
    ],
    columns: [
        {
            name: 'asgnDt',
            fieldName: 'asgnDt',
            header: {
                text: '일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점명',
                showTooltip: false,
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '관리조직',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'fixCrdtPrchsPrc',
            fieldName: 'fixCrdtPrchsPrc',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '상품매입가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'fixCashPrchsPrc',
            fieldName: 'fixCashPrchsPrc',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '실제매입가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'disQty',
            fieldName: 'disQty',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '보유수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
    ],
}
