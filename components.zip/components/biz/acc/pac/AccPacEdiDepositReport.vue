<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccPacEdiAccMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <AccGridTable
        ref="accGridTable"
        isEditable
        isColumnNo
        :offset="['btn-excelDownload']"
        :gridMeta="GRID_HEADER"
        :data="data"
        :pagingInfo="pagingInfo"
        :exportInfo="{
            uri: `/api/v1/backend-max/resource/acc/pac/card-dpsts-excel-download`,
            query: query,
        }"
        @dblClickCell="dblClickCell"
        @movePage="movePage"
        @changePageSize="changePageSize"
    />
</template>

<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import { GRID_HEADER } from '@/const/grid/acc/pac/accPacEdiDepositReportGrid'

export default {
    name: 'AccPacEdiDepositReport',
    mixins: [CommonMixin, accMixin],
    components: {
        AccGridTable,
    },
    props: {
        data: {
            default: () => [],
        },

        pagingInfo: {
            default: () => ({
                totalPageCnt: 0,
            }),
        },

        query: {
            default: () => ({}),
        },
    },
    data() {
        return {
            GRID_HEADER,
        }
    },
    created() {},
    methods: {
        dblClickCell(row, rowIdx, rowInfo) {
            this.$emit(
                'dblClickCell',
                Object.assign({}, row),
                Object.assign({}, rowIdx),
                Object.assign({}, rowInfo)
            )
        },

        movePage(query) {
            this.$emit('movePage', query)
        },
        changePageSize(query) {
            this.$emit('changePageSize', query)
        },
    },
}
</script>
