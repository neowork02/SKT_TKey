import { ValueType } from 'realgrid'

export const DisOpnOpenStMgmtProdRgst_GRID_HEADER = {
    fields: [
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT, //제조사ID
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER, //단가
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'openYn',
            dataType: ValueType.TEXT, //개봉여부
        },
        {
            fieldName: 'toOpenYn',
            dataType: ValueType.TEXT, //상태변경
        },
        {
            fieldName: 'mdlClCd',
            dataType: ValueType.TEXT, //단말기구분코드
        },
        {
            fieldName: 'prchTyp',
            dataType: ValueType.TEXT, //구매유형코드
        },
        {
            fieldName: 'regYn',
            dataType: ValueType.NUMBER, //구매유형코드
        },
    ],
    columns: [
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                lookupDisplay: true,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사ID',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
            },
            header: {
                text: '불량여부',
            },
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
            },
            header: {
                text: '재고상태',
            },
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'openYn',
            fieldName: 'openYn',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개봉여부',
                showTooltip: false,
            },
        },
        {
            name: 'toOpenYn',
            fieldName: 'toOpenYn',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '미개봉여부',
                showTooltip: false,
            },
        },
        {
            name: 'mdlClCd',
            fieldName: 'mdlClCd',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분코드',
                showTooltip: false,
            },
        },
        {
            name: 'prchTyp',
            fieldName: 'prchTyp',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구매유형코드',
                showTooltip: false,
            },
        },
        {
            name: 'regYn',
            fieldName: 'regYn',
            type: 'data',
            visible: false,
        },
    ],
}
