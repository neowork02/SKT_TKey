import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'pagingSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ondmndId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pgmNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtmView',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'execDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'execStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dloadDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'docId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'execCondDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fileNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dataCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'url',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'screenId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fileType',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condVal1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condVal2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condVal3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condVal4',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'pagingSeq',
            fieldName: 'pagingSeq',
            header: {
                text: 'No.',
            },
            editable: false,
            width: 40,
        },
        {
            name: 'opTypCd',
            fieldName: 'opTypCd',
            header: {
                text: '업무유형',
            },
            width: 100,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            editable: false,
        },
        {
            name: 'ondmndId',
            fieldName: 'ondmndId',
            header: {
                text: '작업ID',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'pgmNm',
            fieldName: 'pgmNm',
            header: {
                text: '프로그래명',
            },
            width: 150,
            editable: false,
        },
        {
            name: 'insDtmView',
            fieldName: 'insDtmView',
            header: {
                text: '작업요청일시',
            },
            width: 150,
            editable: false,
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            header: {
                text: '작업요청일시1',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'execDtm',
            fieldName: 'execDtm',
            header: {
                text: '작업수행일시',
            },
            width: 150,
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '작업종료일시',
            },
            width: 150,
            editable: false,
        },
        {
            name: 'execStCd',
            fieldName: 'execStCd',
            header: {
                text: '진행상태',
            },
            width: 100,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            editable: false,
        },
        {
            name: 'dloadDtm',
            fieldName: 'dloadDtm',
            header: {
                text: '다운로드일시',
            },
            width: 150,
            editable: false,
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            header: {
                text: '처리자ID',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'docId',
            fieldName: 'docId',
            header: {
                text: '문서ID',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'execCondDesc',
            fieldName: 'execCondDesc',
            header: {
                text: '조회조건',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'fileNm',
            fieldName: 'fileNm',
            header: {
                text: '파일정보',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'dataCnt',
            fieldName: 'dataCnt',
            header: {
                text: '데이타건수',
            },
            editable: false,
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            header: {
                text: '처리자',
            },
            editable: false,
        },
        {
            name: 'url',
            fieldName: 'url',
            header: {
                text: 'URL',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condVal1',
            fieldName: 'condVal1',
            header: {
                text: '조회조건1',
            },
            editable: false,
            width: 100,
        },
        {
            name: 'condVal2',
            fieldName: 'condVal2',
            header: {
                text: '조회조건2',
            },
            editable: false,
            width: 100,
        },
        {
            name: 'condVal3',
            fieldName: 'condVal3',
            header: {
                text: '조회조건3',
            },
            editable: false,
            width: 100,
        },
        {
            name: 'condVal4',
            fieldName: 'condVal4',
            header: {
                text: '조회조건4',
            },
            editable: false,
            width: 100,
        },
    ],
}
