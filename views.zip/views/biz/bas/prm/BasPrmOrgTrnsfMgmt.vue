<!-----------------------------------------------
 * 업무그룹명: 기준정보>거래처 조직 이관 관리
 * 서브업무명: 거래처관리
 * 설명: 거래처관리 조회/입력/수정/삭제 한다.
 * 작성자: P180291
 * 작성일: 2022.05.09
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>거래처 조직 이관 관리</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="btn_del_OnClick"
                    :objAuth="this.objAuth"
                    :disabled="delDisable"
                >
                    삭제
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave"
                    :objAuth="this.objAuth"
                    :disabled="saveDisable"
                >
                    저장
                </TCComButton>
            </li>
        </ul>
        <!-- searchLayer_wrap  STA-->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        v-model="reqYm"
                        :eRequired="true"
                        labelName="조회년월"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                        @change="dateChange"
                        :calType="calType5"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="div_search.dealcoNm"
                        :codeVal.sync="div_search.dealcoCd"
                        labelName="거래처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="div_search"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <span class="itemtit">처리상태</span>
                    <TCComComboBox
                        :itemList="ds_procStCd"
                        labelName=""
                        v-model="div_search.procStCd"
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>
            </div>
        </div>
        <!-- searchLayer_wrap  END-->

        <!-- searchLayer_wrap STA 엑셀업로드 -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComFileInput
                        v-model="files"
                        labelName="파일선택"
                        @change="onFilesChange"
                    ></TCComFileInput>
                </div>
                <div class="formitem div4_6">
                    <div class="rightArea btn">
                        <span class="inner">
                            <TCComButton
                                labelName="오류검증"
                                eClass="btn_s btn_ty03"
                                eAttr="ico_verification"
                                :Vuetify="false"
                                :disabled="errVerithDisable"
                                @click="errCheck"
                            />
                            <TCComButton
                                labelName="오류일괄제거"
                                eClass="btn_s btn_ty03"
                                eAttr="ico_del"
                                :Vuetify="false"
                                :disabled="errDeleteDisable"
                                @click="errClear"
                            />
                            <TCComButton
                                labelName="양식다운로드"
                                eClass="btn_s btn_ty03"
                                eAttr="ico_save"
                                :Vuetify="false"
                                @click="excelTemplateDownBtn"
                            />
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <!-- searchLayer_wrap END 엑셀업로드 -->

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="거래처 조직 이관 목록"
                :gridObj="gridObj"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :editable="false"
                :updatable="false"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getBasPrmOrgTrnsList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<script>
// import { CommonGrid, FileUtil } from '@/utils'
import { CommonGrid } from '@/utils'
// import * as XLSX from 'xlsx'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'
import { msgTxt } from '@/const/msg.Properties.js'
import { HEADER } from '@/const/grid/bas/prm/BasPrmOrgTrnsfMgmtHeader'
import attachedFileApi from '@/api/common/attachedFile'
import API from '@/api/biz/bas/prm/basPrmOrgTrnsfMgmt'
//====================내부거래처(권한조직)====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처(권한조직)==================
export default {
    name: 'BasPrmOrgTrnsfMgmt',
    mixins: [CommonMixin],

    components: {
        BasBcoDealcosPop,
    },
    async created() {
        //화면초기 로딩시 바로 검색
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            calType5: 'M', //'D'
            reqYm: '',
            div_search: {
                reqYm: '',
                dealcoCd: '',
                dealcoNm: '',
                procStCd: '',
                pageNum: '',
                pageSize: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
            },
            ds_procStCd: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '대기',
                },
                {
                    commCdVal: 'P',
                    commCdValNm: '실행',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: '완료',
                },
                {
                    commCdVal: 'E',
                    commCdValNm: 'EROOR',
                },
            ],
            delDisable: true,
            //====================Grid====================
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            rowCnt: 15,
            //====================Grid====================
            //====================FILE====================
            files: null,

            errDeleteDisable: null,
            saveDisable: true,
            errVerithDisable: null,
            fvFile: 0, //0 엑셀업로드가 아님, 1: 엑셀업로드
            //====================FILE====================
            //====================내부거래처(권한조직)====================
            showBasBcoDealcos: false,
            // searchForm: {
            //     dealcoCd: '', // 거래처코드
            //     dealcoNm: '', // 거래처명
            // },
            resultDealcoRows: [],
            //====================//내부거래처(권한조직)==================
        }
    },
    mounted() {
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, true, false)
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
    },
    methods: {
        // 초기화
        onResetPage: function () {
            console.log('🚀  onResetPage()')
            this.errDeleteDisable = false // 오류일괄제거버튼 활성화
            this.errVerithDisable = false // 오류검증버튼 활성화
            this.delDisable = true
            this.saveDisable = true // 저장버튼 비활성화
            this.fvFile = 0
            ;(this.div_search = {
                reqYm: '',
                dealcoCd: '',
                dealcoNm: '',
                procStCd: '',
                pageNum: '',
                pageSize: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
            }),
                this.initData()
            this.gridData = this.gridSetData()
            this.gridObj.dataProvider.clearRows()
        },
        // 조회년월 변경시
        async dateChange() {
            console.log('dateChange')

            this.onSearch()
        },
        //조회 버튼 이벤트
        onSearch() {
            console.log('🚀  onSearch()')
            this.gridObj.totalPage = 0 // 이전페이지정보 초기화
            this.getBasPrmOrgTrnsList(1)
        },

        //API 호출
        getBasPrmOrgTrnsList: function (pageNum) {
            console.log('🚀  onSearch()')

            if (_.isEmpty(this.reqYm)) {
                this.showTcComAlert('조회년월은 필수 입력 사항입니다.')
                return
            }
            this.div_search.pageNum = pageNum
            this.div_search.pageSize = this.rowCnt
            this.div_search.reqYm = this.reqYm.replace(/-/g, '')
            API.getBasPrmOrgTrnsList(this.div_search).then((result) => {
                if (result.gridList) {
                    this.gridObj.setRows(result.gridList)
                    this.delDisable = false
                    // 페이징 관련
                    this.gridObj.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
            })
        },
        //저장 버튼 이벤트
        onSave: function () {
            console.log('🚀  onSave()')

            if (this.fvFile == 1) {
                const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
                if (rowData.length === 0) {
                    // msgTxt.MSG_00071
                    this.openAlert('처리할 대상이 없습니다.') // '처리할 대상이 없습니다.'
                    return
                }
                console.log(
                    '🚀 ~ file: BasPrmOrgTrnsfMgmt.vue ~ onSave fvFile 1',
                    rowData
                )
                this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                    if (confirm) {
                        API.savePrmOrgTrnsf(rowData).then((res) => {
                            if (res === 1) {
                                this.showTcComAlert('저장 되었습니다.')
                                this.onResetPage()
                                this.onSearch()
                            }
                        })
                    }
                })
            } else {
                this.showTcComAlert('엑셀 업로드일 경우 저장 가능합니다.')
                return
            }
        },
        async initData() {
            let today = moment(new Date()).format('YYYY-MM')
            this.reqYm = today
            // 근무지코드 조회
            this.div_search.dealcoCd = this.userInfo.dealcoCd
            this.div_search.dealcoNm = this.userInfo.dealcoNm
            this.div_search.orgCd = this.orgInfo.orgCd
            this.div_search.orgNm = this.orgInfo.orgNm
            this.div_search.orgLvl = this.orgInfo.orgLvl
        },
        // 행삭제
        btn_del_OnClick() {
            console.log('🚀  onClickDownload()')
            let jsonData = []
            this.gridObj.gridView.commit()
            if (this.fvFile == 1) {
                return this.showTcComAlert(`조회 후 삭제 가능합니다..`)
            }

            const checkRows = this.gridObj.gridView.getCheckedRows(true)

            if (checkRows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                checkRows.forEach((row) => {
                    jsonData.push(this.gridObj.dataProvider.getJsonRow(row))
                })
            }

            this.showTcComConfirm('삭제하시겠습니까?').then((confirm) => {
                if (confirm) {
                    API.delPrmOrgTrnsf(jsonData).then((res) => {
                        if (res === 1) {
                            this.showTcComAlert('삭제 되었습니다.')
                            this.onResetPage()
                            this.onSearch()
                        }
                    })
                }
            })
        },
        //엑셀다운로드
        onClickDownload() {
            console.log('🚀  onClickDownload()')
            const rowCount = this.gridObj.dataProvider.getRowCount()
            this.div_search.reqYm = this.reqYm.replace(/-/g, '')
            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            if (this.fvFile == 1) {
                return this.showTcComAlert(
                    `엑셀 업로드시 엑셀 다운로드는 불가 합니다..`
                )
            }
            this.div_search.reqYm = this.reqYm.replace(/-/g, '')
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/prm/excelPrmOrgTrnsf',
                this.div_search
            )
        },

        gridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
            this.onSearch()
        },

        //===================== 엑셀업로드 관련 methods ================================\

        onFilesChange: function (files) {
            this.onResetPage()
            this.fvFile = 1
            this.errDeleteDisable = true // 오류일괄제거버튼 비활성화
            this.errVerithDisable = false // 오류검증버튼 활성화
            this.saveDisable = true // 저장버튼 비활성화
            this.excelUploadFile(files)
        },
        excelUploadFile(files) {
            this.gridObj.gridInit()
            this.errChk = false

            if (files == null) return
            const form = new FormData()
            form.append('files', files)

            API.excelTcipMac(form).then((res) => {
                if (res.length == 0) {
                    this.showTcComAlert(
                        '업로드 문서에 처리 할 데이터가 없습니다.\n업로드 문서를 확인하시기 바랍니다.'
                    )
                } else if (res.length > 3000) {
                    this.showTcComAlert(
                        '1회당 업로드 데이터는 3000건까지 가능합니다.'
                    )
                } else {
                    this.gridObj.setRows(res)
                }
            })

            // const f = files
            // if (!_.isUndefined(f) && !_.isNull(f)) {
            //     const reader = new FileReader()
            //     // const name = f.name

            //     reader.onload = (e) => {
            //         const data = e.target.result

            //         // Array Buffer인 경우 base64로 변환 처리
            //         const arr = FileUtil.arrayBufferFixdata(data)
            //         const workbook = XLSX.read(FileUtil.encodeBase64(arr), {
            //             type: 'base64',
            //             cellText: true,
            //             cellDates: true,
            //         })
            //         // 워크북 처리(1줄 헤더 포함 처리)
            //         this.processWorkbook(workbook)
            //     }
            //     // binary
            //     // reader.readAsBinaryString(f)
            //     // Array Buffer
            //     reader.readAsArrayBuffer(f)
            // }
        },
        // // 워크북 처리(1줄 헤더 포함 처리)
        // processWorkbook(wb) {
        //     const output = FileUtil.excelTojson(wb, {
        //         raw: false,
        //     })
        //     const sheetNames = Object.keys(output)
        //     if (sheetNames.length) {
        //         const colsObj = output[sheetNames][0]
        //         if (colsObj) {
        //             const data = output[sheetNames]
        //             console.log('processWorkbook: ', output[sheetNames])
        //             if (data.length > 3000) {
        //                 this.showTcComAlert(
        //                     '1회당 업로드 데이터는 3000건까지 가능합니다.'
        //                 )
        //                 return
        //             } else {
        //                 this.gridObj.gridView.commit()
        //             }
        //             const mappedData = data.map((item) => {
        //                 return {
        //                     reqYm: item['요청년월'],
        //                     dealcoCd: item['거래처코드'],
        //                     orgCd: item['조직ID'],
        //                 }
        //             })
        //             this.gridObj.dataProvider.fillJsonData(mappedData, {})
        //         }
        //     } else {
        //         this.openAlert(msgTxt.MSG_00106)
        //         this.errDeleteDisable = true // 오류일괄제거버튼 비활성화
        //         this.errVerithDisable = true // 오류검증버튼 비활성화
        //     }
        // },

        // 오류검증 버튼 이벤트
        errCheck: function () {
            if (this.fvFile == 0) {
                this.openAlert(msgTxt.MSG_00106)
                return
            }

            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)

            if (rowData.length == 0) {
                this.openAlert(msgTxt.MSG_00106)
                return
            }
            console.log('result List : ', rowData)
            API.errorChkExcel(rowData).then((res) => {
                this.errDeleteDisable = false // 오류일괄제거버튼 활성화
                this.errVerithDisable = true // 오류검증버튼 비활성화
                this.gridObj.setRows(res)
            })
        },
        // Alert창 호출
        openAlert(alertBodyTxt) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: '450',
            })
        },
        // 오류일괄제거 버튼 이벤트
        errClear: function () {
            if (this.fvFile == 0) {
                this.openAlert(msgTxt.MSG_00106)
                return
            }

            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.(데이터 없음)')
                return
            }
            if (_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('처리할 데이터가 없습니다.(에러 없음)')
                this.saveDisable = false // 저장버튼 활성화
                this.errDeleteDisable = true // 오류일괄제거버튼 비활성화
            } else {
                this.gridObj.dataProvider.removeRows(this.getErrRow())
                this.saveDisable = false // 저장버튼 활성화
                this.errDeleteDisable = true // 오류일괄제거버튼 비활성화
            }
        },

        //오류ROW 조회
        getErrRow() {
            let errRow = []
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            rowData.forEach((data, i) => {
                if (!_.isEmpty(_.get(data, 'errorLog'))) {
                    errRow.push(i)
                }
            })
            return errRow
        },
        //양식다운로드
        excelTemplateDownBtn() {
            attachedFileApi.downloadSampleFile('506')
        },
        //===================== 엑셀업로드 관련 methods ================================
        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.div_search).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.div_search.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.div_search.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.div_search.dealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.div_search.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-전체조직명 입력해주세요.'
                return
            }
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.div_search.dealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.div_search.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.div_search.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직)팝업관련 methods ================================
    },
}
</script>
