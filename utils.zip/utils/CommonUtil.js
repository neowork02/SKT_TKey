/* eslint-disable no-useless-escape */

/*****************************************
 * 업무그룹명: 공통업무
 * 서브업무명: 공통 Utils
 * 설명: 공통 Utils 기능
 * 작성자: 홍길동
 * 작성일: 2022.02.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
 *****************************************/
import _ from 'lodash'
import moment from 'moment'
import store from '@/store'
export default {
    convertSecToRemainingTimeStr(sec) {
        return (
            parseInt(sec / 60)
                .toString()
                .padStart(2, '0') +
            ':' +
            (sec % 60).toString().padStart(2, '0')
        )
    },

    validEmail(email) {
        const re =
            /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        return re.test(email)
    },

    validPhoneNo(phoneNo) {
        const re =
            /^(01[016789]{1}|02|0[3-9]{1}[0-9]{1})-?[0-9]{3,4}-?[0-9]{4}$/
        return re.test(phoneNo)
    },

    validNotHyphenPhoneNo(phoneNo) {
        const re = /^(01[016789]{1}|02|0[3-9]{1}[0-9]{1})?[0-9]{3,4}?[0-9]{4}$/
        return re.test(phoneNo)
    },

    validNotHyphenJuminNo(juminNo) {
        const re =
            /^\d{2}([0]\d|[1][0-2])([0][1-9]|[1-2]\d|[3][0-1])*[1-8]\d{6}$/
        return re.test(juminNo)
    },

    validBizNo(bizNo) {
        // const numberMap = bizNo
        //     .replace(/-/gi, '')
        //     .split('')
        //     .map((d) => {
        //         return parseInt(d, 10)
        //     })

        // if (numberMap.length === 10) {
        //     const keyArr = [1, 3, 7, 1, 3, 7, 1, 3, 5]
        //     let chkSum = 0

        //     keyArr.forEach((d, i) => {
        //         chkSum += d * numberMap[i]
        //     })

        //     chkSum += parseInt((keyArr[8] * numberMap[8]) / 10, 10)
        //     return Math.floor(numberMap[9]) === (10 - (chkSum % 10)) % 10
        // }

        // return false
        const re = /^([0-9]{3})-?([0-9]{2})-?([0-9]{5})$/
        return re.test(bizNo)
    },

    replacePhoneNo(phoneNo) {
        return phoneNo.replace(/[^0-9 ]/g, '')
    },

    maskingEmail(email) {
        var len = email.split('@')[0].length - 3
        return email.replace(new RegExp('.(?=.{0,' + len + '}@)', 'g'), '*')
    },

    appendHyphenPhoneNo(phoneNo) {
        return phoneNo
            .replace(/[^0-9]/g, '')
            .replace(
                /(^02|^0505|^1[0-9]{3}|^0[0-9]{2})([0-9]+)?([0-9]{4})$/,
                '$1-$2-$3'
            )
            .replace('--', '-')
    },

    defaultString(str, defaultVal) {
        return str ? str.trim() : defaultVal ? defaultVal : ''
    },

    defaultObj(obj, key, defaultObj) {
        defaultObj = defaultObj ? defaultObj : ''
        return obj ? (obj[key] ? obj[key] : defaultObj) : defaultObj
    },

    defaultObjString(obj, key, defaultVal) {
        defaultVal = this.defaultString(defaultVal)
        return obj
            ? obj[key] && obj[key].trim() !== ''
                ? obj[key]
                : defaultVal
            : defaultVal
    },

    defaultObjUndefinedString(obj, key, defaultVal) {
        defaultVal = this.defaultString(defaultVal)
        return obj
            ? obj[key] !== undefined
                ? obj[key]
                : defaultVal
            : defaultVal
    },

    onlyNumber(str, isNumberType) {
        str = str.replace(/[^\d]/g, '')
        return isNumberType ? Number(str) : str
    },

    onlyString(str) {
        return str.replace(/[\d]/g, '')
    },

    commaString(str) {
        return str.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    },

    wrapString(str, wrapStr) {
        let resultArray = []
        str = this.defaultString(str)

        if (str !== '') {
            resultArray.push(wrapStr)
            resultArray.push(str)
            resultArray.push(wrapStr)
        }

        return resultArray.join('')
    },

    encodeURIComponent(str) {
        return encodeURIComponent(str)
            .replace(/\(/g, '%28')
            .replace(/\)/g, '%29')
    },

    encodeParams(obj) {
        obj = Object.assign({}, obj)

        Object.keys(obj).forEach((key) => {
            obj[key] = this.encodeURIComponent(obj[key])
        })

        return obj
    },

    replaceNewLine(str) {
        return this.defaultString(str).replace(/(?:\r\n|\r|\n)/g, '<br />')
    },

    split(str, sep) {
        return str && str !== '' ? str.split(sep) : []
    },

    isNotEmptyObject(obj) {
        return obj && Object.keys(obj).length > 0 && obj.constructor === Object
            ? true
            : false
    },

    containBlankSpace(str) {
        return str ? /\s/g.test(str) : false
    },

    removeBlankSpace(str) {
        return str ? str.replace(/\s/gi, '') : str
    },

    getByteLength(s, b, i, c) {
        for (
            b = i = 0;
            (c = s.charCodeAt(i++));
            b += c >> 11 ? 3 : c >> 7 ? 2 : 1
        );
        return b
    },

    cutByteLength(str, len) {
        let size = 0
        for (let i = 0; i < str.length; i++) {
            size += str.charCodeAt(i) > 128 ? 3 : 1
            if (size > len) {
                return str.substring(0, i)
            }
        }
        return str
    },

    cutByteLengthWithEllipsis(str, len, ellipsis) {
        len = Number(len)
        if (this.getByteLength(str) > len) {
            str =
                this.cutByteLength(str, len) +
                this.defaultString(ellipsis, '...')
        }

        return str
    },

    customCutByteLength(str, len) {
        let size = 0
        for (let i = 0; i < str.length; i++) {
            size += str.charCodeAt(i) > 128 ? 3 : 1
            if (size > len) {
                return str.substring(0, i) + '...'
            }
        }
        return str
    },

    validDate(str) {
        let datatimeRegexp = /[0-9]{4}-[0-9]{2}-[0-9]{2}/
        if (!datatimeRegexp.test(str)) {
            return false
        }
        return true
    },

    validCidr(str) {
        let exp =
            /^(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]?|0)\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]?|0)\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]?|0)\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]?|0)(\/([1-9]|[1-2][0-9]|3[0-2])){1}$/
        let regex = new RegExp(exp)

        return regex.test(str)
    },

    onlyNumberWithExclueds(e, excludeArr) {
        // 숫자 또는 excludeArr에 포함된 문자만 하용
        if (e.keyCode < 48 || e.keyCode > 57) {
            if (excludeArr != undefined && Array.isArray(excludeArr)) {
                e.returnValue = excludeArr.includes(e.key)
            } else {
                e.returnValue = false
            }
        }
    },
    /*************************************************
     * 현재 페이지 초기화
     * obj   : router Object
     *************************************************/
    clearPage(obj, paramObj, gridObj = '') {
        Object.assign(obj.$data[paramObj], obj.$options.data()[paramObj])
        if (gridObj) gridObj.dataProvider.clearRows()
    },
    /*************************************************
     * 문자열 특정위치 치환
     * input    : Text
     * index    : 위치
     * character : 치환할 문자
     *************************************************/
    replaceAt(input, index, character) {
        return (
            input.substr(0, index) +
            character +
            input.substr(index + character.length)
        )
    },
    /*************************************************
     * 메세지 %s 문자열 특정위치 치환
     * txt  : 메세지내용
     * ext1 : 치환할 내용1
     * ext2 : 치환할 내용2
     * ext3 : 치환할 내용3
     *************************************************/
    replaceMsg(txt, ext1 = '', ext2 = '', ext3 = '') {
        var findTxt = ext1
        if (findTxt) {
            let pos = 0
            let cnt = 0
            while (typeof x === 'undefined') {
                let foundPos = txt.indexOf('%s', pos)
                if (foundPos >= 0) {
                    txt =
                        txt.substr(0, foundPos) +
                        findTxt +
                        txt.substr(foundPos + 2, txt.length)
                    if (cnt == 0) findTxt = ext2
                    if (cnt == 1) findTxt = ext3
                    cnt++
                } else if (foundPos == -1) break
                pos = foundPos + 1
            }
        }
        return txt
    },

    replaceJosnStr(jsonStr) {
        var val = ''
        if (jsonStr != undefined) {
            if (jsonStr[0] != undefined)
                val = JSON.stringify(jsonStr).replace(/[\[\]\/]/gim, '') + ','
            else val = ''
        } else {
            val = ''
        }
        return val
    },

    /*************************************************
     * 유형별 날짜 검증
     * type    : 검증 날짜 유형
     *            01(기본값)->YYYYMM, 02->YYYYMMDD,
     *            03->YYYYMMDD~YYYYMMDD
     * strDate : 날짜값
     *************************************************/
    validDateType(type, strDate) {
        let ret = true
        if (type == '' || type == null) {
            type = '01'
        }
        if (strDate == '' || strDate == null) {
            strDate = ''
        }

        let datatimeRegexp = ''

        if (type == '01') {
            datatimeRegexp = /^[0-9]{4}[0-9]{2}$/
            if (!datatimeRegexp.test(strDate)) {
                ret = false
            }
        }
        if (type == '02') {
            datatimeRegexp = /^[0-9]{4}[0-9]{2}[0-9]{2}$/
            if (!datatimeRegexp.test(strDate)) {
                ret = false
            }
        }
        if (type == '03') {
            datatimeRegexp =
                /^[0-9]{4}[0-9]{2}[0-9]{2}~[0-9]{4}[0-9]{2}[0-9]{2}$/
            if (!datatimeRegexp.test(strDate)) {
                ret = false
            }
        }

        return ret
    },

    /*************************************************
     * 날짜 검증
     * type    : 검증 날짜 유형
     *            M: 날짜(월)
     *            S: 날짜+시간(초) (yyyyMMddhhmmss)
     * value : 날짜값(YYYY-MM-DD)
     *************************************************/
    checkDate(type, value) {
        let bRet = false
        let dateRegexp = ''

        if (type === 'M') {
            dateRegexp = /^\d{4}-(0[1-9]|1[012])$/
            if (!dateRegexp.test(value)) {
                bRet = true
            }
        } else if (type === 'S') {
            dateRegexp =
                /^([0-9]{4})(-?)(1[0-2]|0[1-9])\2(3[01]|0[1-9]|[12][0-9])$/
            if (!dateRegexp.test(value.substring(0, 8))) {
                return true
            }

            dateRegexp = /^(2[0-3]|[01][0-9]):?([0-5][0-9]):?([0-5][0-9])$/
            if (!dateRegexp.test(value.substring(8, 14))) {
                return true
            }
        } else {
            dateRegexp = /^\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/
            if (!dateRegexp.test(value)) {
                bRet = true
            }
        }
        return bRet
    },

    /*************************************************
     * 문자열 Dash(-) 제거
     * val : 값
     *************************************************/
    replaceDash(val) {
        if (!val) return ''
        return val.replace(/-/gi, '')
    },
    /*************************************************
     * Date에 Dash(-) 추가
     * val : 값
     *************************************************/
    addDashDate(val) {
        let rtnVal = ''
        if (!_.isEmpty(val)) {
            if (val.length == 6) {
                rtnVal = val.substring(0, 4) + '-' + val.substring(4, 6)
            } else if (val.length == 8) {
                rtnVal =
                    val.substring(0, 4) +
                    '-' +
                    val.substring(4, 6) +
                    '-' +
                    val.substring(6, 8)
            } else {
                rtnVal = val
            }
        }

        return rtnVal
    },

    /*************************************************
     * 오브젝트 배열을 그리드 lov에 맞게 컨버전 (라벨)
     * data : 오브젝트 배열
     * key : JSON 키
     * blankType : blank Type
     *************************************************/
    convListToGridLovLabels(data, key, blankType) {
        let result = []
        let blank = ''
        if (!_.isEmpty(blankType)) {
            if (blankType == 'SELECT') {
                blank = '선택'
            } else if (blankType == 'ALL') {
                blank = '전체'
            }
        }
        result.push(blank)

        _.forEach(data, (item) => {
            result.push(item[key])
        })
        return result
    },

    /*************************************************
     * 오브젝트 배열을 그리드 lov에 맞게 컨버전 (값)
     * data : 오브젝트 배열
     * key : JSON 키
     * blankType : blank Type
     *************************************************/
    convListToGridLovValues(data, key, blankType) {
        let result = []
        let blank = ''
        if (!_.isEmpty(blankType)) {
            if (blankType == 'SELECT' || blankType == 'ALL') {
                blank = ''
            }
        }
        result.push(blank)

        _.forEach(data, (item) => {
            result.push(item[key])
        })
        return result
    },

    /*************************************************
     * base64 convert - Font를 Convert하기 위한 함수
     * url : Font Path
     * split : split
     *************************************************/
    async base64convert(url, split) {
        const data = await fetch(url)
        const blob = await data.blob()
        return new Promise((resolve) => {
            const reader = new FileReader()
            reader.readAsDataURL(blob)
            reader.onloadend = () => {
                const base64data = reader.result
                resolve(split ? base64data.split(',')[1] : base64data)
            }
        })
    },

    //
    /*************************************************
     * 민감단어 포함여부 체크
     * strTargetText : 체크대상 Text
     *************************************************/
    chkRmks(strTargetText) {
        let isOk = true

        // - 공백 개행  제거
        let source = strTargetText.replace('-', '')
        source = source.replace(' ', '')
        source = source.replace('/', '')
        source = source.replace('\n', '')
        source = source.replace('\r', '')
        source = source.toUpperCase()

        let pattern = /[0-9][0-9][0-1][0-9][0-3][0-9][1-8][0-9]{6}/
        let pattern2 = /[0-9]{11}/

        let customerInfoWord = store.getters['rmks/customerInfoWord']
        let forbidden = store.getters['rmks/forbiddenWord']
        for (let i = 0; i < forbidden.length; i++) {
            if (source.indexOf(forbidden[i].commCdVal) >= 0) {
                store.dispatch('showTcComAlert', {
                    message: '사용 할 수 없는 단어가 포함되어 있습니다.',
                    options: {
                        header: '금지단어체크',
                        size: '500',
                        confirmLabel: 'OK',
                    },
                })
                isOk = false
                break
            }
        }
        if (pattern.test(source) > 0) {
            store.dispatch('showTcComAlert', {
                message:
                    '고객의 개인정보를 보관하는일은 법적인 책임을 지게 될 수 있습니다.',
                options: {
                    header: '고객정보체크',
                    size: '550',
                    confirmLabel: 'OK',
                },
            })
            isOk = false
        } else if (pattern2.test(source) > 0) {
            for (let i = 0; i < customerInfoWord.length; i++) {
                if (source.indexOf(customerInfoWord[i].commCdVal) >= 0) {
                    store.dispatch('showTcComAlert', {
                        message:
                            '고객의 개인정보를 보관하는일은 법적인 책임을 지게 될 수 있습니다.',
                        options: {
                            header: '고객정보체크',
                            size: '550',
                            confirmLabel: 'OK',
                        },
                    })
                    isOk = false
                    break
                }
            }
        }
        return isOk
    },

    /*************************************************
     * menuInfo Store GET Top Menu
     * menuInfo : Store menuInfo
     *************************************************/
    getTopMenu(menuInfo) {
        let topMenu = []
        for (let i = 0; i < menuInfo.length; i++) {
            if (menuInfo[i].menuLvlCd == 1) {
                topMenu.push(menuInfo[i])
                console.log(menuInfo[i].menuNm)
            }
        }
        return topMenu
    },
    /*************************************************
     * Object 권한체크를 위한 함수(Button / Tab)
     * authInfo : Store AuthInfo
     * path : Screen Path
     * attr : Object 명
     *************************************************/
    setObjAuth(path, attr) {
        let objAuth = store.getters['auth/objAuthList']
        let authInfo = store.getters['login/authInfo']
        //Store에 있는 값 대신..
        let authYn = false
        let pathAuth = ''
        pathAuth = _.find(authInfo, { screenUrl: path }) // 화면URL에 해당하는 속성권한 찾기
        if (pathAuth != undefined && pathAuth.authDtlInfoVo.length > 0) {
            //화면ID에 해당하는 속성권한을 체크
            for (let i in pathAuth.authDtlInfoVo) {
                let objAttr = _.find(objAuth, {
                    commCdVal: attr.replace(/ /g, ''),
                })
                if (
                    objAttr != undefined &&
                    objAttr.commCdValNm == pathAuth.authDtlInfoVo[i]
                ) {
                    if (pathAuth.authDtlInfoVo[i]) {
                        authYn = true
                    }
                }
            }
        }
        return authYn
    },
    /*************************************************
     * Object 권한여부 가져오는 함수
     * path : Screen Path
     * attr : Object 명
     *************************************************/
    getObjAuth(path, attr) {
        let objAuth = store.getters['auth/objAuthList']
        let authInfo = store.getters['login/authInfo']
        //Store에 있는 값 대신..
        // let authArr = [
        //     {
        //         screenUrl: '/ui-sample/TestPage',
        //         authDtlInfoVo: [1, 2, 3, 33],
        //     },
        // ]
        let authYn = 'Y'
        let pathAuth = ''
        pathAuth = _.find(authInfo, { screenUrl: path }) // 화면ID에 해당하는 속성권한 찾기
        if (pathAuth != undefined && pathAuth.authDtlInfoVo.length > 0) {
            //화면ID에 해당하는 속성권한을 체크
            for (let i in pathAuth.authDtlInfoVo) {
                let objAttr = _.find(objAuth, {
                    commCdVal: attr.replace(/ /g, ''),
                })
                if (
                    objAttr != undefined &&
                    objAttr.commCdValNm == pathAuth.authDtlInfoVo[i]
                ) {
                    if (pathAuth.authDtlInfoVo[i]) {
                        authYn = 'N'
                    }
                }
            }
        }
        console.log('authYn:', authYn)
        return authYn
    },
    /*************************************************
     * 파일 확장자 명 추출
     * orignFileName : 파일명
     *************************************************/
    getExtensionName(orignFileName) {
        const fileLength = orignFileName.length
        const lastDot = orignFileName.lastIndexOf('.')
        const fileExt = orignFileName
            .substring(lastDot + 1, fileLength)
            .toLowerCase()
        return fileExt
    },

    /*************************************************
     * 확장자 제외한 파일명 추출
     * orignFileName : 파일명
     *************************************************/
    getFileName(orignFileName) {
        const lastDot = orignFileName.lastIndexOf('.')
        const fileName = orignFileName.substring(0, lastDot)
        return fileName
    },

    /*************************************************
     * 오늘날짜 구하기
     *************************************************/
    getToday(format = 'YYYYMMDD') {
        return moment().format(format)
    },

    /*************************************************
     * 내일날짜 구하기
     *************************************************/
    getNextday(format = 'YYYYMMDD') {
        return moment(new Date()).add(1, 'days').format(format)
    },

    /*************************************************
     * 현재년도 구하기
     *************************************************/
    getCurrentYear() {
        return moment().format('YYYY')
    },

    /*************************************************
     * 현재월 구하기
     *************************************************/
    getCurrentMonth(format = 'YYYYMM') {
        return moment().format(format)
    },

    /*************************************************
     * 이전월 구하기
     *************************************************/
    getPrevMonth(format = 'YYYYMM') {
        return moment().subtract(1, 'months').format(format)
    },

    /*************************************************
     * 달의 시작일 구하기
     *************************************************/
    getStartDay(format = 'YYYYMMDD') {
        return moment().startOf('month').format(format)
    },

    /*************************************************
     * 달의 마지막일 구하기
     *************************************************/
    getEndDay(format = 'YYYYMMDD') {
        return moment().endOf('month').format(format)
    },

    /*************************************************
     * 현재날짜에서 날짜 더하기
     *************************************************/
    getAddDay(addDay, format = 'YYYYMMDD') {
        return moment().add(addDay, 'days').format(format)
    },

    /*************************************************
     * 현재날짜에서 날짜 빼기
     *************************************************/
    getSubtractDay(subtractDay, format = 'YYYYMMDD') {
        return moment().subtract(subtractDay, 'days').format(format)
    },

    /*************************************************
     * 현재월에서 월 빼기
     * subtractMonth : 빼기 할 월
     *************************************************/
    getSubtractMonth(subtractMonth, format = 'YYYYMM') {
        return moment().subtract(subtractMonth, 'months').format(format)
    },

    /*************************************************
     * 특정일자의 내일날짜 구하기
     * pDay : 특정일자
     *************************************************/
    getDayNextday(pDay, format = 'YYYYMMDD') {
        return moment(pDay).add(1, 'days').format(format)
    },

    /*************************************************
     * 특정일자에서 날짜 더하기
     * pDay : 특정일자
     *************************************************/
    getDayAddDay(pDay, addDay, format = 'YYYYMMDD') {
        return moment(pDay).add(addDay, 'days').format(format)
    },

    /*************************************************
     * 특정일자에서 날짜 빼기
     * pDay : 특정일자
     *************************************************/
    getDaySubtractDay(pDay, subtractDay, format = 'YYYYMMDD') {
        return moment(pDay).subtract(subtractDay, 'days').format(format)
    },

    /*************************************************
     * 특정일자의 월 구하기
     * pDay : 특정일자
     *************************************************/
    getDayMonth(pDay, format = 'YYYYMM') {
        return moment(pDay).format(format)
    },

    /*************************************************
     * 특정일자의 달의 시작일 구하기
     * pDay : 특정일자
     *************************************************/
    getDayStartDay(pDay, format = 'YYYYMMDD') {
        return moment(pDay).startOf('month').format(format)
    },

    /*************************************************
     * 특정일자의 달의 마지막일 구하기
     * pDay : 특정일자
     *************************************************/
    getDayEndDay(pDay, format = 'YYYYMMDD') {
        return moment(pDay).endOf('month').format(format)
    },

    /*************************************************
     * 특정일자의 월 더하기
     * pDay : 특정일자
     * addMonth : 추가할 월
     *************************************************/
    getMonthNextMonth(pDay, addMonth, format = 'YYYYMM') {
        return moment(pDay).add(addMonth, 'months').format(format)
    },

    /*************************************************
     * 특정일자의 월 빼기
     * pDay : 특정일자
     * subtractMonth : 빼기 할 월
     *************************************************/
    getMonthPrevMonth(pDay, subtractMonth, format = 'YYYYMM') {
        return moment(pDay).subtract(subtractMonth, 'months').format(format)
    },

    /*************************************************
     * 특정일자의 날짜포맷지정
     * pDay : 특정일자
     * format : 포맷
     *************************************************/
    getDayFormat(pDay, format) {
        return moment(pDay).format(format)
    },

    /*************************************************
     * 날짜 기간 계산
     * to : to 날짜
     * from : from 날짜
     *************************************************/
    getDiffDate(to, from, format = 'YYYYMMDD') {
        if (!to || !from) return ''
        return moment(to, format).diff(moment(from, format), 'days')
    },

    /*************************************************
     * 월수 계산
     * to : to 날짜
     * from : from 날짜
     *************************************************/
    getDiffMonth(to, from, format = 'YYYYMMDD') {
        if (!to || !from) return ''
        return moment(to, format).diff(moment(from, format), 'months') + 1
    },

    /*************************************************
     * 월2자리 변경
     * month : 월
     *************************************************/
    getMonthFormat(month) {
        if (month.length == 1) {
            return '0' + month
        } else {
            return month
        }
    },

    /*************************************************
     * 날짜 Valid 체크
     * pDay : 특정날짜
     * format : 포맷
     *************************************************/
    checkValidDate(pDay, format = 'YYYYMMDD') {
        return moment(pDay, format).isValid()
    },

    /*************************************************
     * json 문자열에서 문서보안 관련 문자열이 있는지 검색
     * jsonObj : json object
     *************************************************/
    checkJsonStrDocSecurity(jsonObj) {
        const arrSearch = ['SCDSA00', 'u0000']
        let result = false
        for (let i = 0; i < arrSearch.length; i++) {
            result = JSON.stringify(jsonObj).includes(arrSearch[i])
            if (result) {
                break
            }
        }
        return result
    },

    /*************************************************
     * 두 값을 비교
     * 좌측 값과 우측 값 동일: 0
     * 좌측 값이 클 경우: -1
     * 우측 값이 클 경우: 1
     * data1 : 좌측 값
     * data2 : 우측 값
     *************************************************/
    checkNumCompare(data1, data2) {
        let nRetValue = 1
        const leftData = Number(data1)
        const rightData = Number(data2)

        if (leftData === rightData) {
            nRetValue = 0
        } else if (leftData > rightData) {
            nRetValue = -1
        }

        return nRetValue
    },
    convertHierarchical(array, parentProp, childrenProp) {
        var map = {}
        for (var i = 0; i < array.length; i++) {
            var obj = array[i]
            obj.children = []

            map[obj[childrenProp]] = obj

            var parent = obj[parentProp] || '-'
            if (!map[parent]) {
                map[parent] = {
                    children: [],
                    file: 'plus',
                }
            }

            map[parent].children.push(obj)
        }

        for (let prop in map) {
            if (map[prop].children.length === 0) {
                delete map[prop].children
                map[prop]['file'] = 'last'
            }
        }
        console.log('tree:', map['-'].children)
        return map['-'].children
    },
    //접속 브라우저 확인
    getBrowserInfo() {
        const agent = window.navigator.userAgent.toLowerCase()
        let browserName
        switch (true) {
            case agent.indexOf('edge') > -1:
                browserName = 'Edge' // MS 엣지
                break
            case agent.indexOf('edg/') > -1:
                browserName = 'Edge' // 크롬 기반 엣지
                break
            case agent.indexOf('opr') > -1 && !!window.opr:
                browserName = 'Opera' // 오페라
                break
            case agent.indexOf('chrome') > -1 && !!window.chrome:
                browserName = 'Chrome' // 크롬
                break
            case agent.indexOf('trident') > -1:
                browserName = 'MS IE' // 익스플로러
                break
            case agent.indexOf('firefox') > -1:
                browserName = 'Mozilla Firefox' // 파이어 폭스
                break
            case agent.indexOf('safari') > -1:
                browserName = 'Safari' // 사파리
                break
            default:
                browserName = 'other' // 기타
        }
        return browserName
    },
    //모바일 여부 체크
    isMobile() {
        const user = navigator.userAgent
        let isCheck = false

        if (user.indexOf('iPhone') > -1 || user.indexOf('Android') > -1) {
            isCheck = true
        }

        return isCheck
    },
}
