<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 통합미수금 관리 수납대상집계
 * 설명: 조회, 저장
 * 작성자: P180190
 * 작성일: 2022.11.17
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">통합미수금관리-입금처리</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="거래처"
                                    v-model="popupParams.dealcoCd"
                                    :editable="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="거래처명"
                                    v-model="popupParams.dealcoNm"
                                    :editable="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                        </div>
                    </div>

                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader"
                            ref="gridHeader"
                            gridTitle="수납내역"
                            :gridObj="gridObj"
                            :isAddRow="true"
                            :isDelRow="true"
                            @addRowBtn="gridAddRowBtn"
                            @chkDelRowBtn="gridDelRowBtn"
                        >
                        </TCRealGridHeader>
                        <TCRealGrid
                            id="popupGrid"
                            ref="popupGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                            :editable="true"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                </div>
                <!-- // Bottom BTN Group -->
                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose"
                    >닫기</a
                >
                <!--//Close BTN-->
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { GRID_HEADER } from '@/const/grid/acc/sac/AccSacIntgUnpdMgmtDpstProcGrid'
import intgUnpdMgmtApi from '@/api/biz/acc/sac/AccSacIntgUnpdMgmt'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'AccSacIntgUnpdMgmtDpstProc',
    title: '통합미수금관리-입금처리 팝업',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            gridData: {},
            gridObj: {},
            objAuth: {},
            view: GRID_HEADER,

            popupParams: {
                dpstDt: '',
                dealcoCd: '',
                dealcoNm: '',
                matchKey: '',
            },

            param: {
                dealcoCd: '',
                matchKey: '',
                dpstProcList: [],
            },

            //행 추가 입력된 데이터 리스트
            gridDatas: [],
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {},
    mounted() {
        this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState(false, true, false, true)
        this.popupParams = this.parentParam
        this.gridObj.gridView.setRowIndicator({
            zeroBase: false,
            visible: true,
            displayValue: 'index',
        })
        console.log('this.popupParams:::::::::::::::::', this.popupParams)
        this.onSearch()
    },
    methods: {
        onSearch() {
            this.popupParams.dpstDt = moment(this.popupParams.baseDt).format(
                'YYYYMMDD'
            )
            console.log('this.popupParams', this.popupParams)
            intgUnpdMgmtApi.getDpstProc(this.popupParams).then((res) => {
                if (res) {
                    this.gridObj.setRows(res.gridList)
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },
        gridAddRowBtn: function () {
            this.gridObj.gridView.commit()
            let focuscell = this.gridObj.gridView.getCurrent()

            // //행추가 기본값 세팅하기
            this.defaultJson = {}
            var addVal = ['', 0, '']
            focuscell = this.gridObj.dataProvider.addRow(addVal)
            this.gridObj.gridView.setCurrent({
                itemIndex: focuscell,
                column: '입금일자',
            })
        },

        gridDelRowBtn: function () {
            let focuscell = this.gridObj.gridView.getCurrent()
            let rowState = this.gridObj.dataProvider.getRowState(
                focuscell.dataRow
            )
            if (rowState == 'created') {
                this.gridObj.dataProvider.removeRow(focuscell.dataRow)
            } else {
                this.showTcComAlert('삭제할수 없는 행입니다.')
            }
        },

        onConfirm() {
            //임금내역 저장 처리
            this.gridObj.gridView.commit()
            this.gridDatas = []
            this.gridDatas = this.gridObj.setModifyData(this.gridDatas)
            this.param.dpstProcList = this.gridDatas.saveRows
            this.param.dealcoCd = this.popupParams.dealcoCd
            this.param.matchKey = this.popupParams.matchKey
            console.log('저장 파람:::::', this.param)
            if (this.param.dpstProcList.length > 0) {
                for (var i = 0; i < this.param.dpstProcList.length; i++) {
                    console.log(
                        'dpstProcList[i].dpstAmt:::::',
                        this.param.dpstProcList[i].dpstAmt
                    )
                    if (_.isEmpty(this.param.dpstProcList[i].dpstDt)) {
                        this.showTcComAlert('입금일자를 입력해주십시오.')
                        return
                    }
                    if (
                        this.param.dpstProcList[i].dpstAmt <= 0 ||
                        this.param.dpstProcList[i].dpstAmt == undefined
                    ) {
                        this.showTcComAlert('입금금액을 입력해주십시오.')
                        return
                    }
                    this.param.dpstProcList[i].dpstDt = moment(
                        this.param.dpstProcList[i].dpstDt
                    ).format('YYYYMMDD')
                }
                intgUnpdMgmtApi.saveDpstProc(this.param).then((res) => {
                    console.log(res)
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    this.$emit('confirm', this.popupParams.matchKey)
                    this.onClose()
                })
            } else {
                this.showTcComAlert('추가된 데이터가 없습니다.')
                return
            }
        },

        onClose() {
            this.activeOpen = false
        },
    },
}
</script>
