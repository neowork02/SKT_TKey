<!-----------------------------------------------
 * 업무그룹명: 기준정보>대리점검색
 * 서브업무명: 대리점검색
 * 설명: 대리점검색 Popup 컴포넌트
 * 작성자: 양현모
 * 작성일: 2022.04.19
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">대리점팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    v-model="searchParam.agencyTypCd"
                                    codeId="AGENCY_TYP"
                                    labelName="대리점유형"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :disabled="isDisabledAgencyTypCd"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParam.agencyCd"
                                    labelName="대리점코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParam.agencyNm"
                                    labelName="대리점명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <!-- // input -->
                        </div>
                        <!-- // Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComDatePicker
                                    v-model="searchParam.searchDateModel"
                                    labelName="조회기준일"
                                    :objAuth="objAuth"
                                ></TCComDatePicker>
                            </div>
                            <div class="formitem div3"></div>
                            <!-- item 2-4 -->
                            <div class="formitem div3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- // Search_line 2 -->
                    </div>
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">대리점 목록</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="agencyGrid"
                                ref="agencyGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                                @hook:mounted="gridMounted"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { BAS_BCO_AGENCYS_HEADER } from '@/const/grid/bas/bco/basBcoAgencysHeader'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
import commonApi from '@/api/common/commonCode'
import moment from 'moment'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'BasBcoAgencysPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: BAS_BCO_AGENCYS_HEADER,
            headerText: '',
            isDisabledAgencyTypCd: false,
            searchParam: {
                agencyRgstCl: '', // 대리점등록구분
                agencyTypCd: '', // 대리점유형
                agencyPtn: '', // 대리점구분코드
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
                searchDateModel: '', // 조회기준일(v-model)
                searchDate: '', // 조회기준일
            },
        }
    },
    computed: {
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchParam.agencyNm =
                    value['agencyNm'] == undefined ? '' : value['agencyNm']
                this.searchParam.agencyCd =
                    value['agencyCd'] == undefined ? '' : value['agencyCd']
                this.searchParam.agencyTypCd =
                    value['agencyTypCd'] == undefined
                        ? ''
                        : value['agencyTypCd']
                this.searchParam.searchDateModel =
                    value['searchDate'] == undefined ? '' : value['searchDate']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },
    async mounted() {
        this.gridObj = this.$refs.agencyGrid // Grid Object 설정
        this.initGrid()
    },
    methods: {
        init() {
            this.gridData = this.gridSetData()
            if (_.isEmpty(this.searchParam.searchDateModel)) {
                this.searchParam.searchDateModel = moment().format('YYYY-MM-DD')
            }
            if (this.searchParam.agencyTypCd.length > 0) {
                this.isDisabledAgencyTypCd = true
                //this.onSearch()
            }
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async initGrid() {
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false)
            const commAgencyPtn = await this.getCommCodeList('AGENCY_PTN')
            const commAgencyTyp = await this.getCommCodeList('AGENCY_TYP')

            // 대리점 구분 lOV
            this.gridObj.gridView.columnByName('agencyClCd').values =
                CommonUtil.convListToGridLovValues(commAgencyPtn, 'commCdVal')
            this.gridObj.gridView.columnByName('agencyClCd').labels =
                CommonUtil.convListToGridLovLabels(commAgencyPtn, 'commCdValNm')
            // 대리점 유형 lOV
            this.gridObj.gridView.columnByName('agencyTypCd').values =
                CommonUtil.convListToGridLovValues(commAgencyTyp, 'commCdVal')
            this.gridObj.gridView.columnByName('agencyTypCd').labels =
                CommonUtil.convListToGridLovLabels(commAgencyTyp, 'commCdValNm')
            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },

        gridMounted() {
            console.log('gridMounted')
        },

        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        getAgencyList() {
            this.searchParam.searchDate = CommonUtil.replaceDash(
                this.searchParam.searchDateModel
            )

            basBcoAgencysApi.getAgencyList(this.searchParam).then((res) => {
                console.log('getAgencyList then : ', res)
                this.gridObj.setRows(res)
            })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('대리점을 선택해주세요.', {
                    header: '대리점 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenAgency = false
        },

        onSearch() {
            this.getAgencyList()
        },

        onEnterKey() {
            this.onSearch()
        },
    },
}
</script>
