import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        /*
        {
            fieldName: 'reqYn',
            dataType: ValueType.TEXT,
        },
        */
        {
            fieldName: 'sktAgencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCdLvl1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCdLvl2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCdLvl3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStatus',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNmTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoRgstClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqCnt',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        /*
        {
            name: 'reqYn',
            fieldName: 'reqYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청여부',
            },
        },
        */
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
            },
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서브대리점코드',
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '거래처명',
            },
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채널코드',
            },
        },
        /*
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업부',
            },
        },
        {
            name: 'orgCd1',
            fieldName: 'orgCd1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당',
            },
        },
        {
            name: 'orgCd2',
            fieldName: 'orgCd2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업팀',
            },
        },
        {
            name: 'orgCd3',
            fieldName: 'orgCd3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업파트',
            },
        },
*/
        {
            name: 'orgNmTree',
            fieldName: 'orgNmTree',
            type: 'data',
            width: 350,
            styleName: 'left-column',
            header: {
                text: '조직',
            },
        },
        {
            name: 'dealcoRgstClCd',
            fieldName: 'dealcoRgstClCd',
            type: 'data',
            header: {
                text: '거래처등록구분',
            },
        },
        {
            name: 'dealcoGrpCd',
            fieldName: 'dealcoGrpCd',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처그룹',
            },
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분1',
            },
        },
        {
            name: 'dealcoClCd2',
            fieldName: 'dealcoClCd2',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처유형',
            },
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처코드',
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고보유처코드',
            },
        },
        {
            name: 'dealEndYn',
            fieldName: 'dealEndYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래상태',
            },
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래상태',
            },
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '거래게시일',
            },
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '거래종료일',
            },
        },
        {
            name: 'reqCnt',
            fieldName: 'reqCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '진행여부',
            },
        },
    ],
}
