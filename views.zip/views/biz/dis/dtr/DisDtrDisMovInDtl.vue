<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 이동입고확정등록[DISDTR00800]
 * 설명: 이동입고 확정등록한다.
 * 작성자: P179229
 * 작성일: 2022.06.08
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>이동입고확정등록</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="listBtn"
                    :objAuth="this.objAuth"
                >
                    목록
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="입고확정일"
                        calType="D"
                        v-model="setDate"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="masterParam.outDealcoNm"
                        :codeVal.sync="masterParam.outDealcoCd"
                        labelName="출고처"
                        :objAuth="objAuth"
                        :disabled="true"
                        :disabledAfter="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="masterParam.inDealcoNm"
                        :codeVal.sync="masterParam.inDealcoCd"
                        labelName="입고처"
                        :objAuth="objAuth"
                        :disabled="true"
                        :disabledAfter="true"
                    />
                </div>
            </div>
        </div>
        <!-- // Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="재고이동입고 내역"
                :gridObj="this.gridObj"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            >
                <template #gridElementArea>
                    <TCComInput
                        labelName="일련번호"
                        @enterKey="chkSerNum"
                        v-model="serNum"
                    />
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :editable="true"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div>
        <!-- //gridWrap -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { DisDtrDisMovInDtlGRID_HEADER } from '@/const/grid/dis/dtr/disDtrDisMovInDtlHeader'
import disDtrDisMovInDtlApi from '@/api/biz/dis/dtr/disDtrMovInDtl'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'DisDtrDisMovOutDtl',
    mixins: [CommonMixin],
    components: {},
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: DisDtrDisMovInDtlGRID_HEADER,
            fromDt: '',
            listSearch: {},
            dtlData: {},
            serNum: '',
            barInfoList: [],
            masterParam: {
                outFixDt: '', //출고일
                outOrgCd: '', //출고조직id
                outOrgNm: '', //출고조직명
                outDealcoCd: '', // 출고처
                outDealcoNm: '', // 출고처명
                inFixDt: '', //입고확정일
                inOrgCd: '', //입고조직id
                inOrgNm: '', //입고조직명
                inDealcoCd: '', // 입고처
                inDealcoNm: '', // 입고처명
            },
        }
    },
    computed: {
        setDate: {
            get() {
                return this.fromDt
            },
            set(val) {
                this.masterParam.inFixDt = CommonUtil.replaceDash(val)
                return val
            },
        },
    },
    created() {
        // 화면 default설정
        this.defaultSet()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.onColumnCheckedChanged =
            this.onColumnCheckedChanged
        this.gridObj.gridView.onCellEdited = this.onCellEdited
        // 리스트 검색조건
        this.listSearch = this.$route.params.search
        this.dtlData = this.$route.params.datas
        //재고이동출고 마스터/상세조회
        this.masterParam = { ...this.dtlData }
        this.getDisDtrDisMovInDtlLists()
        //바코드 정보 조회
        this.getBarInfoList()
    },
    methods: {
        defaultSet() {
            this.gridData = this.gridSetData()
            //검색영역
            this.fromDt = moment(new Date()).format('YYYY-MM-DD') // 출고일
        },
        gridSetData: function () {
            // CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(-1, 10, '', '')
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'masterParam')
        },
        //엑셀다운로드
        onClickDownload() {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dtr/disDtrDisMovInDtlExcelList',
                this.masterParam
            )
        },
        //전체 바코드 정보 조회
        getBarInfoList: function () {
            disDtrDisMovInDtlApi.getBarInfoList().then((res) => {
                res.disDtrBarInfoListVo.forEach((data) => {
                    const barInfo = {}
                    barInfo.prodClCd = _.get(data, 'prodClCd')
                    barInfo.barCdTypCd = _.get(data, 'barCdTypCd')
                    barInfo.allLenCnt = _.get(data, 'allLenCnt')
                    barInfo.serNumStaLenCnt = _.get(data, 'serNumStaLenCnt')
                    barInfo.serNumLenCnt = _.get(data, 'serNumLenCnt')
                    this.barInfoList.push(barInfo)
                })
            })
        },
        //저장
        saveBtn: function () {
            this.gridObj.gridView.commit()
            const rowCount = this.gridObj.dataProvider.getRowCount()
            let saveData = []

            for (var i = 0; i < rowCount; i++) {
                var rowData = this.gridObj.dataProvider.getJsonRow(i)
                if (_.get(rowData, 'inFixYn') != _.get(rowData, 'inFixYnOrg')) {
                    rowData.inFixDt = this.masterParam.inFixDt
                    rowData.inDealcoCd = this.masterParam.inDealcoCd
                    rowData.outDealcoCd = this.masterParam.outDealcoCd
                    saveData.push(rowData)
                }
            }
            if (_.isEmpty(saveData)) {
                this.showTcComAlert('처리할 대상이 없습니다.')
                return
            }
            if (
                this.masterParam.inFixDt <
                moment(this.masterParam.outFixDt).format('YYYYMMDD')
            ) {
                this.showTcComAlert(
                    '입고확정일은 출고확정일 [' +
                        moment(this.masterParam.outFixDt).format('YYYY-MM-DD') +
                        '] 보다 과거로 입력할 수 없습니다.'
                )
                return
            }
            if (
                moment(new Date()).format('YYYYMMDD').substr(0, 6) >
                this.masterParam.inFixDt.substr(0, 6)
            ) {
                this.showTcComAlert('현재월 이전으로는 입력이 불가합니다.')
                return
            }
            if (
                this.masterParam.inFixDt >
                moment().add(30, 'days').format('YYYYMMDD')
            ) {
                this.showTcComAlert(
                    '입고확정일(은)는 현재일자보다 + 30일 이상 일자는 선택 할 수 없습니다'
                )
                return
            }
            this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    disDtrDisMovInDtlApi
                        .saveDisDtrDisMovInDtl(saveData)
                        .then((res) => {
                            // 정상등록
                            if (res === 1) {
                                this.listBtn()
                            }
                        })
                }
            })
        },
        //목록
        listBtn() {
            this.$router.push({
                name: '/dis/dtr/DisDtrDisMovIn',
                params: { search: this.listSearch },
            })
        },
        //재고이동출고 목록 조회
        getDisDtrDisMovInDtlLists: function () {
            disDtrDisMovInDtlApi
                .getDisDtrDisMovInDtlLists(this.masterParam)
                .then((res) => {
                    //Get Row Data
                    this.gridObj.setRows(res.disDtrDisMovInProdListVo)
                })
        },
        onColumnCheckedChanged(grid, column, checked) {
            if (column.name === 'inFixYn') {
                const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
                if (checked) {
                    rowData.forEach((data, i) => {
                        this.gridObj.gridView.setValue(i, 'inFixYn', 'Y')
                    })
                } else {
                    rowData.forEach((data, i) => {
                        var row = this.gridObj.dataProvider.getJsonRow(i)
                        if (!this.chkInFixAvail(row)) {
                            this.gridObj.gridView.setValue(i, 'inFixYn', 'Y')
                        } else {
                            this.gridObj.gridView.setValue(i, 'inFixYn', 'N')
                        }
                    })
                }
                this.gridObj.gridView.commit()
            }
        },
        onCellEdited(grid, itemIndex) {
            this.gridObj.gridView.commit()
            var row = this.gridObj.dataProvider.getJsonRow(itemIndex)
            if (!this.chkInFixAvail(row)) {
                this.showTcComAlert('입고취소가 불가능합니다.')
                grid.setValue(itemIndex, 'inFixYn', 'Y')
            }
        },
        //입력된 일련번호로 체크처리
        chkSerNum: function () {
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            let chk = false
            rowData.forEach((data, i) => {
                var row = this.gridObj.dataProvider.getJsonRow(i)
                if (this.serNumValidChk(row)) {
                    if (_.get(row, 'inFixYn') === 'Y') {
                        if (!this.chkInFixAvail(row)) {
                            this.showTcComAlert('입고취소가 불가능합니다.')
                            this.gridObj.gridView.setValue(i, 'inFixYn', 'Y')
                        } else {
                            this.gridObj.gridView.setValue(i, 'inFixYn', 'N')
                        }
                    } else {
                        this.gridObj.gridView.setValue(i, 'inFixYn', 'Y')
                    }
                    this.serNum = ''
                    chk = true
                }
            })
            if (!chk) {
                this.showTcComAlert(
                    '[' +
                        this.serNum +
                        '] 목록에서 일치하는 일련번호가 없습니다.'
                )
                this.serNum = ''
            }
        },
        //일련번호 체크
        serNumValidChk(row) {
            let ret = false
            if (_.get(row, 'serNum') === this.serNum) {
                ret = true
            } else {
                this.barInfoList.forEach((barInfo) => {
                    if (
                        _.get(barInfo, 'prodClCd') === _.get(row, 'prodClCd') &&
                        _.get(barInfo, 'barCdTypCd') ===
                            _.get(row, 'barCdTypCd') &&
                        this.serNum.length == _.get(barInfo, 'allLenCnt')
                    ) {
                        if (
                            _.get(row, 'serNum') ===
                            this.serNum.substr(
                                _.get(barInfo, 'serNumStaLenCnt') - 1,
                                _.get(barInfo, 'serNumLenCnt')
                            )
                        ) {
                            ret = true
                        }
                    }
                })
            }
            return ret
        },
        //이동입고취소 가능여부 체크
        chkInFixAvail(row) {
            if (
                _.get(row, 'inFixYnOrg') == 'Y' &&
                (_.get(row, 'badYn') != _.get(row, 'disBadYn') ||
                    _.get(row, 'disStCd') != _.get(row, 'disDisStCd') ||
                    this.masterParam.inDealcoCd != _.get(row, 'disDealcoCd') ||
                    _.get(row, 'disLastInoutClCd') != '300' ||
                    _.get(row, 'disLastInoutDtlClCd') != '302' ||
                    _.get(row, 'mthCloseMovInYn') === 'Y')
            ) {
                return false
            } else {
                return true
            }
        },
    },
}
</script>
