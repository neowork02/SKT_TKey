export default Object.freeze({
    SYSTEM_NM: 'T.key-taka',
    INPUTRULE_EN: 'EN',
    INPUTRULE_UPEN: 'UPEN',
    INPUTRULE_HAN: 'H',
    INPUTRULE_NUM: 'N',
    INPUTFORMAT_TEL: 'TEL',
    INPUTFORMAT_BIZ: 'BIZ',
    PORTAL_URL: 'https://www.jungboboho.com',
})
