<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : RmtAccAccRptExcelUpload.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="statusShow" size="1500px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">정산 Report 파일 업로드</p>

                <div class="layerCont">
                    <AccSearchField
                        ref="accSearchField"
                        :offset="[
                            'btn-right-reset',
                            'btn-right-save',
                            'btn-right-close',
                            'search-accMth',
                            { slotSearch: `selectedForm` },
                            { slotSearch: `selectFile` },
                            { slotSearch: `downloadForm` },
                        ]"
                        :initValue="initValue"
                        @reset="resetForm"
                        @save="saveForm"
                        @close="closePopup"
                    >
                        <template slot="selectedForm" slot-scope="slotProps">
                            <div
                                class="formitem"
                                :class="`div${slotProps.divideCellCount}`"
                            >
                                <TCComComboBox
                                    labelName="정산구분"
                                    itemText="label"
                                    itemValue="value"
                                    :itemList="tableSelectorList"
                                    v-model="tableSelector"
                                    class="typeSelect"
                                    @change="changeTableSelector"
                                />
                            </div>
                        </template>

                        <template slot="selectFile" slot-scope="slotProps">
                            <div
                                class="formitem"
                                :class="`div${slotProps.divideCellCount}`"
                            >
                                <AccFileLoader
                                    ref="accFileLoader"
                                    labelName="파일선택"
                                    v-model="accFileLoaderModel"
                                    @load="loadExcel"
                                />
                            </div>
                        </template>

                        <template slot="downloadForm" slot-scope="slotProps">
                            <div
                                class="formitem"
                                :class="`div${slotProps.divideCellCount}`"
                            >
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_save"
                                            labelName="양식다운로드"
                                            @click="downloadForm"
                                        />
                                    </span>
                                </div>
                            </div>
                        </template>
                    </AccSearchField>

                    <AccGridTable
                        ref="accGridTable"
                        isColumnNo
                        :offset="[]"
                        :gridMeta="selectedGridHeader"
                        :data="formUploader.data"
                    />

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom"></div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <button
                        type="button"
                        class="layerClose b-close"
                        @click="closePopup"
                    >
                        닫기
                    </button>
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>
<script>
import CommonMixin from '@/mixins'

import { CommonUtil } from '@/utils'
// import { getCalcDays, getTodayDate, gridMetaUtil } from '@/utils/accUtil'
import { getCalcDays, getTodayDate } from '@/utils/accUtil'

import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'
import AccFileLoader from '@/components/biz/common/acc/AccFileLoader'

import { GRID_HEADER as GRID_HEADER_SUMLIST } from '@/const/grid/rmt/acc/rmtAccAccRptSumListGrid'
import { GRID_HEADER as GRID_HEADER_WIRELESS } from '@/const/grid/rmt/acc/rmtAccAccRptWirelessGrid'
import { GRID_HEADER as GRID_HEADER_CABLE } from '@/const/grid/rmt/acc/rmtAccAccRptCableGrid'
import { GRID_HEADER as GRID_HEADER_INFRA } from '@/const/grid/rmt/acc/rmtAccAccRptInfraGrid'
import { GRID_HEADER as GRID_HEADER_RESETTLEMENT } from '@/const/grid/rmt/acc/rmtAccAccRptReSettlementGrid'
import { GRID_HEADER as GRID_HEADER_SALEUNLOCK } from '@/const/grid/rmt/acc/rmtAccAccRptSaleUnlockGrid'
import { GRID_HEADER as GRID_HEADER_TOTAL } from '@/const/grid/rmt/acc/rmtAccAccRptTotalGrid'
import { GRID_HEADER as GRID_HEADER_SYNERGY } from '@/const/grid/rmt/acc/rmtAccAccRptSynergyGrid'
import { GRID_HEADER as GRID_HEADER_QUICK } from '@/const/grid/rmt/acc/rmtAccAccRptQuickGrid'

import rmtApi from '@/api/biz/rmt/acc'
import attachApi from '@/api/common/attachedFile'

export default {
    name: 'RmtAccAccRpt',
    mixins: [CommonMixin],
    components: { AccSearchField, AccGridTable, AccFileLoader },
    props: {
        status: {
            default: false,
        },

        curTabIdx: {
            default: 0,
        },
    },
    data() {
        return {
            initValue: {
                accMth: getCalcDays(
                    'today',
                    { count: -1, per: 'months' },
                    'YYYY-MM'
                ),
                pageSize: 15,
                pageNum: 1,
            },

            accFileLoaderModel: null,
            tableSelector: 0,
            tableSelectorList: [
                { label: '무선', value: 1 },
                { label: '유선', value: 2 },
                { label: 'INFRA', value: 3 },
                { label: '재정산', value: 4 },
                { label: '공기기판매', value: 5 },
                { label: '요약', value: 0 },
                { label: '종합', value: 6 },
                { label: '참고1', value: 7 },
                { label: '참고2', value: 8 },
            ],

            formUploader: {
                type: null,
                headerInfo: {},
                query: {},
                data: [],
            },

            selectedGridHeader: {
                columns: [],
                fields: [],
                layout: [],
            },

            files: null,
        }
    },
    computed: {
        statusShow: {
            get() {
                return this.status
            },
            set(value) {
                this.$emit('update:status', value)
            },
        },

        selectedAccClCd() {
            let accClCd

            switch (this.tableSelector) {
                case 0: // 요약
                    accClCd = 6
                    break

                case 1: // 무선
                    accClCd = 1
                    break

                case 2: // 유선
                    accClCd = 2
                    break

                case 3: // 인프라
                    accClCd = 3
                    break

                case 4: // 재정산
                    accClCd = 4
                    break

                case 5: // 공기기판매
                    accClCd = 5
                    break

                case 6: // 종합
                    accClCd = 7
                    break

                case 7: // 시너지
                    accClCd = 8
                    break

                case 8: // 퀵비지원
                    accClCd = 9
                    break
            }

            return accClCd
        },

        // 부가 헤더정보를 포함하기로 약속한 정산구분
        isHeaderInfo() {
            let status = false

            switch (this.tableSelector) {
                // 요약, 무선, 유선, 인프라, 종합
                case 0:
                case 1:
                case 2:
                case 3:
                case 6:
                case 7:
                case 8:
                    // 배열의 0번은 부가헤더정보
                    status = true
                    break
            }

            return status
        },
    },
    watch: {
        curTabIdx: {
            immediate: true,
            handler(value) {
                this.tableSelector = value
            },
        },
    },

    created() {
        this.initPage()
    },
    mounted() {},
    methods: {
        initPage() {
            // 헤더정보 갱신
            this.SELECTED_GRID_HEADER()
        },

        closePopup() {
            this.statusShow = false
        },

        loadExcel(xlsData, files) {
            if (!xlsData) {
                this.resetFileUploader()
                return
            }

            this.files = files
            // console.log('KYJ1 xlsData ====> ', xlsData)

            //=================================================================================
            //  문서보안을 해제하기 위해 선택한 업로드대상 파일을 서버로 보낸다
            const multipartForm = new FormData()

            multipartForm.append('files', this.files)
            multipartForm.append(
                `admAppendFileList[0].fileNm`,
                CommonUtil.getFileName(this.files.name)
            )
            multipartForm.append(
                `admAppendFileList[0].fileType`,
                CommonUtil.getExtensionName(this.files.name)
            )
            multipartForm.append(`accClCd`, this.selectedAccClCd)

            this.formUploader.query = multipartForm
            //=================================================================================

            rmtApi.excelUploadParse(this.formUploader.query).then((res) => {
                xlsData.data = res

                if (xlsData.data) {
                    this.gridDataSet(xlsData)
                }
            })
        },
        gridDataSet(xlsData) {
            // 헤더정보 갱신
            this.SELECTED_GRID_HEADER()

            const listData = xlsData.data

            if (this.isHeaderInfo) {
                // 배열의 0번은 부가헤더정보
                this.formUploader.headerInfo = listData[0] || {}
                this.formUploader.headerInfo.titleYn = 'Y'

                // 첫줄 삭제
                listData.shift()

                // 엑셀 첫줄을 그리드헤더에 반영
                Object.keys(this.formUploader.headerInfo).forEach(
                    (fieldName) => {
                        this.selectedGridHeader.columns.some((column, idx) => {
                            let status =
                                column.header &&
                                column.header.text.toLowerCase() ==
                                    fieldName.toLowerCase()

                            if (idx == 34) {
                                // console.log(
                                //     '34번 갑니다!',
                                //     column.header,
                                //     fieldName
                                // )
                            }
                            if (status) {
                                column.header.text =
                                    this.formUploader.headerInfo[fieldName]
                            }

                            return status
                        })
                    }
                )
            }

            this.$set(this.formUploader, 'data', listData)
            this.formUploader.query = {}
        },

        resetForm() {
            this.resetFileUploader()
            this.$emit('reset')
        },

        resetFileUploader() {
            this.files = null
            this.formUploader.type = null
            this.formUploader.data = []
            this.formUploader.query = {}

            this.$refs.accFileLoader.clearFile()
        },

        // 저장 시 데이터내용을 object 로 전송
        saveForm(query) {
            // 무선,공기기판매 이면 binary 형태로 전송
            if (this.selectedAccClCd == 1 || this.selectedAccClCd == 5) {
                return this.saveExcelForm(query)
            } else {
                let listData

                if (!this.formUploader.data.length) {
                    return this.showTcComAlert(`저장할 데이터가 없습니다.`)
                }

                // 부가헤더정보 필요한 경우에
                if (this.isHeaderInfo) {
                    listData = [
                        this.formUploader.headerInfo,
                        ...this.formUploader.data,
                    ]
                } else {
                    listData = [...this.formUploader.data]
                }

                // 그리드 데이터에 부가정보를 추가
                listData.forEach((row) => {
                    Object.assign(
                        row,
                        this.formUploader.query,
                        { ...query },
                        {
                            accClCd: this.selectedAccClCd,
                            matchKey: getTodayDate('hhmmSSSS'),
                        }
                    )
                })

                Object.assign(this.formUploader.query, query, {
                    accClCd: this.selectedAccClCd,
                    inRmtAccAccRptVoList: listData,
                    matchKey: getTodayDate('hhmmSSSS'),
                })

                console.log('저장 시 query', this.formUploader.query)

                // 불필요한 것들 삭제
                delete this.formUploader.query.pageNum
                delete this.formUploader.query.pageSize

                this.postSaveReports()
            }
        },

        // 저장 시 데이터내용을 엑셀파일 binary 형태로 전송
        saveExcelForm(query) {
            const multipartForm = new FormData()

            if (!this.files) {
                return this.showTcComAlert(`저장할 데이터가 없습니다.`)
            }

            multipartForm.append('files', this.files)
            multipartForm.append(
                `admAppendFileList[0].fileNm`,
                CommonUtil.getFileName(this.files.name)
            )
            multipartForm.append(
                `admAppendFileList[0].fileType`,
                CommonUtil.getExtensionName(this.files.name)
            )
            multipartForm.append(`admAppendFileList[0].screenId`, 'BASODM00100')

            multipartForm.append(`admAppendFileList[0].docId`, '')
            multipartForm.append(`admAppendFileList[0].__rowState`, 'created')
            multipartForm.append(`accMth`, query.accMth)
            multipartForm.append(`accClCd`, this.selectedAccClCd)
            multipartForm.append(`matchKey`, getTodayDate('hhmmSSSS'))

            this.formUploader.query = multipartForm
            this.formUploader.type = 'binary'

            this.postSaveReports()
        },

        downloadForm() {
            switch (this.tableSelector) {
                case 0: // 요약
                    attachApi.downloadSampleFile('415')
                    break
                case 1: // 무선
                    attachApi.downloadSampleFile('410')
                    break
                case 2: // 유선
                    attachApi.downloadSampleFile('411')
                    break
                case 3: // 인프라
                    attachApi.downloadSampleFile('412')
                    break
                case 4: // 재정산
                    attachApi.downloadSampleFile('413')
                    break
                case 5: // 공기기판매
                    attachApi.downloadSampleFile('414')
                    break
                case 6: // 종합
                    attachApi.downloadSampleFile('416')
                    break
                case 7: // 참고1
                    attachApi.downloadSampleFile('418')
                    break
                case 8: // 참고2
                    attachApi.downloadSampleFile('419')
                    break
            }
        },

        changeTableSelector() {
            // 데이터 초기화
            this.resetFileUploader()

            // 그리드 헤더정보 변경
            this.SELECTED_GRID_HEADER()
        },

        SELECTED_GRID_HEADER() {
            let cloneGridHeader = {}

            switch (this.tableSelector) {
                case 0: // 요약
                    cloneGridHeader = JSON.parse(
                        JSON.stringify(GRID_HEADER_SUMLIST)
                    )
                    break
                case 1: // 무선
                    cloneGridHeader = JSON.parse(
                        JSON.stringify(GRID_HEADER_WIRELESS)
                    )
                    break
                case 2: // 유선
                    cloneGridHeader = JSON.parse(
                        JSON.stringify(GRID_HEADER_CABLE)
                    )
                    break
                case 3: // 인프라
                    cloneGridHeader = JSON.parse(
                        JSON.stringify(GRID_HEADER_INFRA)
                    )
                    break
                case 4: // 재정산
                    cloneGridHeader = JSON.parse(
                        JSON.stringify(GRID_HEADER_RESETTLEMENT)
                    )
                    break
                case 5: // 공기기판매
                    cloneGridHeader = JSON.parse(
                        JSON.stringify(GRID_HEADER_SALEUNLOCK)
                    )
                    break
                case 6: // 종합
                    cloneGridHeader = JSON.parse(
                        JSON.stringify(GRID_HEADER_TOTAL)
                    )
                    break
                case 7: // 시너지
                    cloneGridHeader = JSON.parse(
                        JSON.stringify(GRID_HEADER_SYNERGY)
                    )
                    break
                case 8: // 퀵비지원
                    cloneGridHeader = JSON.parse(
                        JSON.stringify(GRID_HEADER_QUICK)
                    )
                    break
            }

            if (this.tableSelector != 0) {
                // 2개 바꿀꺼니깐 2까지만 카운트
                let count = 0
                cloneGridHeader.columns.forEach((column) => {
                    if (column.header && column.header.text == '조직') {
                        column.visible = false
                    }

                    if (column.header && column.header.text == '영업담당자') {
                        column.visible = false
                    }

                    count++
                    if (count == 2) return true
                })
            }

            // layout 이 없으면
            if (!cloneGridHeader.layout.length) {
                cloneGridHeader.columns.forEach((column) =>
                    cloneGridHeader.layout.push(column.fieldName)
                )
            }

            cloneGridHeader.contextStyle = `height: 300px`

            this.selectedGridHeader = { ...cloneGridHeader }
        },

        postSaveReports() {
            if (this.formUploader.type == 'binary') {
                return rmtApi
                    .postRmtAccReportsUpload(this.formUploader.query)
                    .then(() => {
                        this.resetFileUploader()
                        this.showTcComAlert(
                            `기준정보 > 기타 > 대용량자료요청 화면에서 처리결과를 확인하십시오.`
                        )
                        // return this.showTcComAlert(`정상적으로 저장되었습니다.`)
                    })
                // .finally(() => {
                //     this.showTcComAlert(
                //         `기준정보 > 기타 > 대용량자료요청 화면에서 처리결과를 확인하십시오.`
                //     )
                //     this.resetFileUploader()
                // })
            } else {
                return rmtApi
                    .postRmtAccReports(this.formUploader.query)
                    .then((res) => {
                        console.log(res)
                        this.resetFileUploader()

                        return this.showTcComAlert(`정상적으로 저장되었습니다.`)
                    })
            }
        },
    },
}
</script>
