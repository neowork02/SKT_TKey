import { ValueType } from 'realgrid'

export const DisOaoEtcOutMgmt_GRID_HEADER = {
    fields: [
        {
            fieldName: 'outPlcNm',
            dataType: ValueType.TEXT, // 출고처
        },
        {
            fieldName: 'outSktCd',
            dataType: ValueType.TEXT, // 출고처매장코드
        },
        {
            fieldName: 'inPlcNm',
            dataType: ValueType.TEXT, // 반품처
        },
        {
            fieldName: 'inSktCd',
            dataType: ValueType.TEXT, // 반품처매장코드
        },
        {
            fieldName: 'outClNm',
            dataType: ValueType.TEXT, // 출고구분
        },
        {
            fieldName: 'earvProcYn',
            dataType: ValueType.TEXT, // 전자결재처리여부
        },
        {
            fieldName: 'outSchdDt',
            dataType: ValueType.TEXT, // 출고예정일
        },
        {
            fieldName: 'outQty',
            dataType: ValueType.TEXT, // 출고예정수량
        },
        {
            fieldName: 'outFixDt',
            dataType: ValueType.TEXT, // 출고확정일
        },
        {
            fieldName: 'outFixYn',
            dataType: ValueType.TEXT, // 출고확정
        },
        {
            fieldName: 'outFixYnOrg',
            dataType: ValueType.TEXT, // 출고확정
        },
        {
            fieldName: 'outFixDtOrg',
            dataType: ValueType.TEXT, // 출고확정일
        },
        {
            fieldName: 'outMgmtNo',
            dataType: ValueType.TEXT, // 출고관리번호
        },
        {
            fieldName: 'outCl',
            dataType: ValueType.TEXT, // 출고구분
        },
        {
            fieldName: 'orgId',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'inPlcId',
            dataType: ValueType.TEXT, // 반품처코드
        },
        {
            fieldName: 'outPlcId',
            dataType: ValueType.TEXT, // 출고처코드
        },
    ],
    columns: [
        {
            name: 'outSktCd',
            fieldName: 'outSktCd',
            type: 'data',
            editable: false,
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcId',
            fieldName: 'outPlcId',
            type: 'data',
            editable: false,
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcNm',
            fieldName: 'outPlcNm',
            type: 'data',
            editable: false,
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처',
                showTooltip: false,
            },
        },
        {
            name: 'inSktCd',
            fieldName: 'inSktCd',
            type: 'data',
            editable: false,
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반품처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcId',
            fieldName: 'inPlcId',
            type: 'data',
            editable: false,
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반품처코드',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcNm',
            fieldName: 'inPlcNm',
            type: 'data',
            editable: false,
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반품처',
                showTooltip: false,
            },
        },
        {
            name: 'outClNm',
            fieldName: 'outClNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고구분',
                showTooltip: false,
            },
        },
        {
            name: 'earvProcYn',
            fieldName: 'earvProcYn',
            type: 'data',
            editable: false,
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '승인처리여부',
                showTooltip: false,
            },
        },
        {
            name: 'outSchdDt',
            fieldName: 'outSchdDt',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고등록일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'outQty',
            fieldName: 'outQty',
            type: 'data',
            editable: false,
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고등록수량',
                showTooltip: false,
            },
        },
        {
            name: 'outFixDt',
            fieldName: 'outFixDt',
            editable: false,
            header: {
                text: '출고승인일',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            styleCallback(grid, dataCell) {
                let ret = {}
                const outFixYn = grid.getValue(
                    dataCell.index.itemIndex,
                    'outFixYn'
                )
                const outFixYnOrg = grid.getValue(
                    dataCell.index.itemIndex,
                    'outFixYnOrg'
                )
                if (outFixYn == 'Y' && outFixYnOrg == 'N') {
                    ret.editable = true
                } else {
                    ret.editable = false
                }
                return ret
            },
        },
        {
            name: 'outFixYn',
            fieldName: 'outFixYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고확정',
            },
            lookupDisplay: true,
            values: ['Y', 'N'],
            labels: ['출고', '미출고'],
        },
        {
            name: 'outFixYnOrg',
            fieldName: 'outFixYnOrg',
            type: 'data',
            visible: false,
            header: {
                text: '출고확정',
            },
        },
        {
            name: 'outFixDtOrg',
            fieldName: 'outFixDtOrg',
            type: 'data',
            visible: false,
            header: {
                text: '출고확정일',
            },
        },
        {
            name: 'outMgmtNo',
            fieldName: 'outMgmtNo',
            type: 'data',
            visible: false,
            header: {
                text: '출고관리번호',
            },
        },
        {
            name: 'outMgmtNo',
            fieldName: 'outMgmtNo',
            type: 'data',
            visible: false,
            header: {
                text: '출고구분',
            },
        },
        {
            name: 'orgId',
            fieldName: 'orgId',
            type: 'data',
            visible: false,
            header: {
                text: '조직코드',
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            visible: false,
            header: {
                text: '조직명',
            },
        },
        {
            name: 'inPlcId',
            fieldName: 'inPlcId',
            type: 'data',
            visible: false,
            header: {
                text: '반품처코드',
            },
        },
        {
            name: 'outPlcId',
            fieldName: 'outPlcId',
            type: 'data',
            visible: false,
            header: {
                text: '출고처코드',
            },
        },
    ],
}
