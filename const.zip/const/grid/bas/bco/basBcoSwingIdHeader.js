import { ValueType } from 'realgrid'

export const basBcoSwingIdHeader = {
    fields: [
        {
            fieldName: 'ukeyId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeyIdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeyUserId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'ukeyId',
            fieldName: 'ukeyId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing ID',
            },
        },
        {
            name: 'ukeyIdNm',
            fieldName: 'ukeyIdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing ID명',
            },
        },
        {
            name: 'ukeyUserId',
            fieldName: 'ukeyUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing User ID',
            },
        },
    ],
}
