/*****************************************
 * 업무 그룹명 : 판매관리
 * 서브 업무명 : 소매매출-카드승인내역
 * 설 명 : 카드승인내역 Grid 헤더
 * 작 성 자 : 양현모
 * 작 성 일 : 2022.07.18
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const CARD_APPR_HEADER = {
    fields: [
        {
            fieldName: 'trmsDtm',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'cardEqpNo',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'dealSeqNo',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'aprvDt',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'aprvNum',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'joinbrNo',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'dealClCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'dealAmt',
            dataType: ValueType.NUMBER, //
        },
        {
            fieldName: 'cmms',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'tax',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'istmtPrd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'isueCoCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'isuecoNm',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'prchCoCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'prchCoNm',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'cardRpsCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'custNm',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'rpsCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'rpsMsg',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'payOpDt',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'aprvCnclPsblYn',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'cnclDtm',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'rmk',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'orgNm2',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'orgNm3',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'orgNm4',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'refNo',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, // 조직 트리
        },
    ],
    columns: [
        // {
        //     name: 'orgNm2',
        //     fieldName: 'orgNm2',
        //     type: 'data',
        //     width: '100',
        //     editable: false,
        //     header: {
        //         text: '담당',
        //     },
        // },
        // {
        //     name: 'orgNm3',
        //     fieldName: 'orgNm3',
        //     type: 'data',
        //     width: '100',
        //     editable: false,
        //     header: {
        //         text: '팀',
        //     },
        // },
        // {
        //     name: 'orgNm4',
        //     fieldName: 'orgNm4',
        //     type: 'data',
        //     width: '100',
        //     editable: false,
        //     header: {
        //         text: '파트',
        //     },
        // },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '300',
            styleName: 'left-column',
            editable: false,
            header: {
                text: '조직',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '내부거래처',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'trmsDtm',
            fieldName: 'trmsDtm',
            type: 'data',
            width: '100',
            editable: false,
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
            header: {
                text: '거래일시',
            },
        },
        {
            name: 'isuecoNm',
            fieldName: 'isuecoNm',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '카드사명',
            },
        },
        {
            name: 'aprvNum',
            fieldName: 'aprvNum',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '승인번호',
            },
        },
        {
            name: 'dealAmt',
            fieldName: 'dealAmt',
            type: 'data',
            width: '100',
            editable: false,
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '승인금액',
            },
        },
        {
            name: 'cardEqpNo',
            fieldName: 'cardEqpNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: 'CAT ID',
            },
        },
        {
            name: 'aprvDt',
            fieldName: 'aprvDt',
            type: 'data',
            width: '100',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '승인일자',
            },
        },
        {
            name: 'dealClCd',
            fieldName: 'dealClCd',
            type: 'data',
            width: '100',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '거래구분',
            },
        },
        {
            name: 'refNo',
            fieldName: 'refNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '레퍼런스번호',
            },
        },
        {
            name: 'istmtPrd',
            fieldName: 'istmtPrd',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '할부개월',
            },
        },
        {
            name: 'joinbrNo',
            fieldName: 'joinbrNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '가맹점번호',
            },
        },
        {
            name: 'rpsMsg',
            fieldName: 'rpsMsg',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '응답메시지',
            },
        },
        {
            name: 'rmk',
            fieldName: 'rmk',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '비고',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '처리자',
            },
        },
    ],
}
