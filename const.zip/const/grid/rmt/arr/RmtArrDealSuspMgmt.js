import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'rowNum', // 순번
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'orgCd', // 조직
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealCoCl1Nm', // 거래처구분
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'pcode', // p코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealStatus', // 거래상태
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealStaDt', // 거래개시일
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealEndDt', // 거래종료일
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'saleChrgr', // 영업담당
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealSusp', // 거래정지대상여부
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'overBondAmt', // 연체채권(A)
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'toDpstAmt', // 입금(B) 21일~
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'toRcvbAmt', // 기타채권(C) 21일~
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'bondBalAmt', // 채권잔액(A+B+C)
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'tsaleQty', // T판매실적
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'fixCnsgCmms', // 판매수수료
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'stopDt', // 정지일
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'stopClrDt', // 정지해제일
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            editable: false,
            header: '순번',
            type: 'data',
            width: '50',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            header: '조직코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: '조직',
            editable: false,
            type: 'data',
            width: '380',
            styleName: 'left-column',
        },
        {
            name: 'dealCoCl1Nm',
            fieldName: 'dealCoCl1Nm',
            header: '거래처구분',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            header: '거래처코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: '거래처명',
            editable: false,
            type: 'data',
            width: '120',
            styleName: 'left-column',
        },
        {
            name: 'pcode',
            fieldName: 'pcode',
            header: '매장코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            header: '거래상태',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            editable: false,
            header: {
                text: '거래개시일',
                showTooltip: false,
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            editable: false,
            header: {
                text: '거래종료일',
                showTooltip: false,
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'saleChrgr',
            fieldName: 'saleChrgr',
            editable: false,
            header: '영업담당',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealSusp',
            fieldName: 'dealSusp',
            editable: false,
            header: {
                text: '거래정지\n대상여부',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
        },

        {
            name: 'overBondAmt',
            fieldName: 'overBondAmt',
            editable: false,
            header: {
                text: '연체채권\n(A)~',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '120',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toDpstAmt',
            fieldName: 'toDpstAmt',
            editable: false,
            header: {
                text: '입금(B)\n21일~',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '120',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'toRcvbAmt',
            fieldName: 'toRcvbAmt',
            editable: false,
            header: {
                text: '기타채권(C)\n21일~',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '120',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'bondBalAmt',
            fieldName: 'bondBalAmt',
            editable: false,
            header: {
                text: '채권잔액\n(A+B+C)',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '120',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'tsaleQty',
            fieldName: 'tsaleQty',
            editable: false,
            header: 'T판매실적',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'fixCnsgCmms',
            fieldName: 'fixCnsgCmms',
            editable: false,
            header: '판매수수료',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'stopDt',
            fieldName: 'stopDt',
            editable: false,
            header: '정지일',
            type: 'data',
            width: '100',
            dataType: ValueType.TEXT,
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'stopClrDt',
            fieldName: 'stopClrDt',
            editable: false,
            header: '정지해제일',
            type: 'data',
            width: '100',
            dataType: ValueType.TEXT,
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
    layout: [
        'rowNum',

        'orgNm',
        //'orgCd',
        'pcode',
        'dealcoCd',
        'dealcoNm',
        'dealCoCl1Nm',
        'dealStatus',
        'dealStaDt',
        'dealEndDt',
        'saleChrgr',
        'dealSusp',
        'overBondAmt',
        'toDpstAmt',
        'toRcvbAmt',
        'bondBalAmt',
        'tsaleQty',
        'fixCnsgCmms',
        'stopDt',
        'stopClrDt',
    ],
}
