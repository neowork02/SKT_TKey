import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'pagingSeq', // 줄번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyYn', // 등록여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyYnNm', // 등록여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'untClNm', // 일반/연합대리점구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktOrgCd', // SKT본부코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktSubCd', // SKT본부서브점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktOrgNm', // SKT본부명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cntrOrgCd', // SKT센터코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cntrSubCd', // SKT센터서브점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cntrOrgNm', // SKT센터명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm', // 대리점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencySubCd', // 대리점서브점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'endDt', // 완료일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repUserId', // 대표자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repUserNm', // 대표자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizNo', // 사업자등록번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zipCd', // 우편주소
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addr', // 주소
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chrgUserNm', // 담당자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chrgUserEmail', // 이메일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chrgUserTelNo', // 전화번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chrgUserMblTelNo', // 이동전화번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'faxNo', // 번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizConNm', // 업태명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizTypNm', // 종목명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'pagingSeq',
            fieldName: 'pagingSeq',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'NO',
                showTooltip: false,
            },
        },
        {
            name: 'aplyYn',
            fieldName: 'aplyYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록여부',
                showTooltip: false,
            },
        },
        {
            name: 'aplyYnNm',
            fieldName: 'aplyYnNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록여부',
                showTooltip: false,
            },
        },
        {
            name: 'untClNm',
            fieldName: 'untClNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점구분',
                showTooltip: false,
            },
        },
        {
            name: 'mktOrgCd',
            fieldName: 'mktOrgCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT본부코드',
                showTooltip: false,
            },
        },
        {
            name: 'mktSubCd',
            fieldName: 'mktSubCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT본부서브점코드',
                showTooltip: false,
            },
        },
        {
            name: 'mktOrgNm',
            fieldName: 'mktOrgNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT본부명',
                showTooltip: false,
            },
        },
        {
            name: 'cntrOrgCd',
            fieldName: 'cntrOrgCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT센터코드',
                showTooltip: false,
            },
        },
        {
            name: 'cntrSubCd',
            fieldName: 'cntrSubCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT센터서브점코드',
                showTooltip: false,
            },
        },
        {
            name: 'cntrOrgNm',
            fieldName: 'cntrOrgNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT센터명',
                showTooltip: false,
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직코드',
                showTooltip: false,
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직명',
                showTooltip: false,
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점명',
                showTooltip: false,
            },
        },
        {
            name: 'agencySubCd',
            fieldName: 'agencySubCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점서브점코드',
                showTooltip: false,
            },
        },
        {
            name: 'endDt',
            fieldName: 'endDt',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '완료일자',
                showTooltip: false,
            },
        },
        {
            name: 'repUserId',
            fieldName: 'repUserId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표자ID',
                showTooltip: false,
            },
        },
        {
            name: 'repUserNm',
            fieldName: 'repUserNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표자명',
                showTooltip: false,
            },
        },

        {
            name: 'bizNo',
            fieldName: 'bizNo',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업자등록번호',
                showTooltip: false,
            },
        },
        {
            name: 'zipCd',
            fieldName: 'zipCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '우편주소',
                showTooltip: false,
            },
        },
        {
            name: 'addr',
            fieldName: 'addr',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주소',
                showTooltip: false,
            },
        },
        {
            name: 'chrgUserNm',
            fieldName: 'chrgUserNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '담당자명',
                showTooltip: false,
            },
        },
        {
            name: 'chrgUserEmail',
            fieldName: 'chrgUserEmail',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이메일',
                showTooltip: false,
            },
        },
        {
            name: 'chrgUserTelNo',
            fieldName: 'chrgUserTelNo',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전화번호',
                showTooltip: false,
            },
        },
        {
            name: 'chrgUserMblTelNo',
            fieldName: 'chrgUserMblTelNo',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동전화번호',
                showTooltip: false,
            },
        },
        {
            name: 'faxNo',
            fieldName: 'faxNo',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'FAX번호',
                showTooltip: false,
            },
        },
        {
            name: 'bizConNm',
            fieldName: 'bizConNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '업태명',
                showTooltip: false,
            },
        },
        {
            name: 'bizTypNm',
            fieldName: 'bizTypNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '종목명',
                showTooltip: false,
            },
        },
    ],
}
