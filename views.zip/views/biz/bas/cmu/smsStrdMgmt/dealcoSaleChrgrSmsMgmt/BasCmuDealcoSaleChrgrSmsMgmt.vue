<!-----------------------------------------------
 * 업무그룹명: 기준정보>기타
 * 서브업무명: SMS기준관리-거래처영업담당자관리SMS전송
 * 설명: SMS기준관리-거래처영업담당자관리SMS전송 조회/입력/수정/삭제 한다.
 * 작성자: P180392
 * 작성일: 2022.05.26
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <!-- <div class="content"> -->
    <div>
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/cmu/smsStrdMgmt/dealcoSaleChrgrSmsMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/cmu/smsStrdMgmt/dealcoSaleChrgrSmsMgmt'

export default {
    name: 'BasCmuDealcoSaleChrgrSmsMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (
            this.$store.hasModule('bas.cmu.dealcoSaleChrgrSmsMgmtStore') != true
        ) {
            this.$store.registerModule(
                'bas.cmu.dealcoSaleChrgrSmsMgmtStore',
                store
            )
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (
            this.$store.hasModule('bas.cmu.dealcoSaleChrgrSmsMgmtStore') == true
        ) {
            this.$store.unregisterModule('bas.cmu.dealcoSaleChrgrSmsMgmtStore')
        }
    },

    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>

<style></style>
