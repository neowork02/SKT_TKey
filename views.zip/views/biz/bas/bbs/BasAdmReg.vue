<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">게시판 등록</p>
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap mt20">
                        <div class="searchform">
                            <div class="formitem div3_3">
                                <div class="arrayType">
                                    <div class="formitem div2">
                                        <TCComInput
                                            v-model="regPopUp.bbsTypeNm"
                                            labelName="게시판구분"
                                            :disabled="disableEl"
                                        />
                                    </div>
                                    <div class="col0">
                                        <TCComCheckBox
                                            v-model="ckParam.noticeYn"
                                            @click="onclick"
                                            :itemList="[
                                                {
                                                    commCdVal: 'Y',
                                                    commCdValNm: '',
                                                },
                                            ]"
                                        />
                                    </div>
                                    <div class="col0">
                                        <span class="basicTxt mgl-5">
                                            <span class="color-red"
                                                >공지글</span
                                            >
                                            (체크하면 리스트 최상단에 나오게
                                            됩니다.)</span
                                        >
                                    </div>
                                    <!-- <div class="formitem div3">
                                        <TCComComboBox
                                            v-model="regPopUp.titleColorNm"
                                            labelName="제목색상"
                                            itemText="text"
                                            itemValue="value"
                                            :itemList="itemList2"
                                            :objAuth="objAuth"
                                        ></TCComComboBox>
                                    </div> -->
                                </div>
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div1">
                                <div class="arrayType">
                                    <div class="col75">
                                        <TCComInput
                                            v-model="regPopUp.textTitle"
                                            labelName="제목"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="regPopUp.bbsDtl"
                                    labelName="내용"
                                    class="boxtype"
                                    :rows="10"
                                />
                            </div>
                        </div>
                    </div>
                    <AttachedBoardFileAdd
                        ref="attachedFileAdd"
                        :fileList="fileSearchList"
                        @file-change="onFileAddChange"
                        gridHeight="100px"
                    ></AttachedBoardFileAdd>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <div class="right">
                            <TCComButton
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onConfirm"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onClose"
                                >닫기</TCComButton
                            >
                        </div>
                    </div>

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<style lang="scss" scoped>
// .btn_area_bottom::v-deep {
//     display: block;
//     float: none;
//     overflow: hidden;

//     .left {
//         float: left;
//     }

//     .right {
//         float: right;
//     }
// }
// .btn_dschk {
//     position: absolute;
//     top: 30px;
// }
// .btn_dschk p {
//     display: inline-block;
// }
</style>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import AttachedBoardFileAdd from '@/components/common/AttachedBoardFileAdd'
import basBbsRegMgmtApi from '@/api/biz/bas/bbs/basBbsMgmt'

import _ from 'lodash'

export default {
    name: 'BasBbsRegMgmt',
    mixins: [CommonMixin],
    components: { AttachedBoardFileAdd },
    props: {
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            gridStyle: {
                height: '100px', //그리드 높이 조절
            },
            gridObj: {},
            gridHeaderbj: {},
            checkbox: true,
            objAuth: {},
            //  파일첨부
            userGrpNmList: [],
            grpCdList: [],
            admAppendFileList: [],
            formData: new FormData(),
            fileSearchList: [],
            disableEl: true,
            bbsTypeCd: '',
            inputValue2: '20',
            regPopUp: {
                noticeYn: '',
                bbsTypeCd: '',
                bbsTypeNm: '',
                titleColorNm: '',
                textTitle: '',
                bbsDtl: '',
                dealcoNm: '', // 매장명
                dealcoCd: '', // 매장코드
                userNm: '', // 대상사용자ID
                userId: '', // 사용자ID
                docId: '',
                insUserNm: '',
                screenId: 'BASBBS00001',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
            },
            ckParam: {},
            showNext: false,
            showAllUserbtn: false,
        }
    },
    mounted() {
        if (this.$parent.guideTab == 0) {
            this.regPopUp.bbsTypeNm = '대리점공지사항'
            this.regPopUp.bbsTypeCd = 'N'
        }
        if (this.$parent.guideTab == 1) {
            this.regPopUp.bbsTypeNm = '정책게시판'
        }
        if (this.$parent.guideTab == 2) {
            this.regPopUp.bbsTypeNm = '시스템공지사항'
            this.regPopUp.bbsTypeCd = 'A'
        }
        if (this.$parent.guideTab == 3) {
            this.regPopUp.bbsTypeNm = '기능개선요청게시판'
            this.regPopUp.bbsTypeCd = 'I'
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        onclick: function () {
            //console.log(this.ckParam.noticeYn)
        },
        onClose: function () {
            this.activeOpen = false
        },
        allCheck() {
            this.ckParam.userNm = '전체'
        },

        async saveBasBbsMgmt() {
            this.ckParam.userId = '-1'
            this.regPopUp.noticeYn = String(this.ckParam.noticeYn)
            this.regPopUp.dealcoNm = String(this.ckParam.dealcoNm)
            this.regPopUp.dealcoCd = String(this.ckParam.dealcoCd)
            this.regPopUp.userId = String(this.ckParam.userId)
            this.regPopUp.userNm = String(this.ckParam.userNm)

            this.regPopUp.__rowState = 'created'
            await basBbsRegMgmtApi
                .postBasBbsMgmt(this.regPopUp)
                .then((resultData) => {
                    console.log('resultData', resultData)

                    this.showTcComAlert('저장되었습니다.')
                    /*
                    if (this.regPopUp.bbsTypeCd == 'N') {
                        //정책게시판
                        this.$parent.getBasBbsMgmtList0()
                    }
                    if (this.regPopUp.bbsTypeCd == 'A') {
                        this.$parent.getBasBbsMgmtList2() //시스템공지
                    }
                    if (this.regPopUp.bbsTypeCd == 'I') {
                        //기능개선
                        this.$parent.getBasBbsMgmtList3()
                    }
                    */
                    this.onClose()
                    this.$emit('confirm', true)
                })
        },
        async onConfirm() {
            if (_.isEmpty(this.regPopUp.textTitle)) {
                this.showTcComAlert('제목을 입력해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            if (_.isEmpty(this.regPopUp.bbsDtl)) {
                this.showTcComAlert('내용을 입력해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            await this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    //  첨부파일 저장
                    // console.log('!!!!!!!', this.regPopUp)
                    basBbsRegMgmtApi
                        .saveAttachFile(this.formData)
                        .then((resultData) => {
                            if (resultData != null) {
                                this.regPopUp.docId = resultData[0].docId
                            }
                            //  문의상세내용 저장
                            this.saveBasBbsMgmt()
                        })
                }
            })
        },
        onFileAddChange(files) {
            this.formData = new FormData()
            const addFileLength = files.addFile.length

            _.forEach(files.addFile, (item, index) => {
                this.formData.append('files', item.file)
                this.formData.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].screenId`,
                    'BASBBS00001'
                )
                this.formData.append(
                    `admAppendFileList[${index}].docId`,
                    this.regPopUp.docId === undefined ? '' : this.regPopUp.docId
                )
                this.formData.append(
                    `admAppendFileList[${index}].__rowState`,
                    'created'
                )
            })
            _.forEach(files.delFile, (item, index) => {
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].filePathNm`,
                    item.filePathNm
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].fileType`,
                    item.fileType
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].screenId`,
                    item.screenId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].docId`,
                    item.docId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].__rowState`,
                    'deleted'
                )
            })
        },
    },
}
</script>
