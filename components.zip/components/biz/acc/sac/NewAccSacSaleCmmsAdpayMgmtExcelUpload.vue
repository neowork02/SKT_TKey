<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : NewAccSacSaleCmmsAdpayMgmtExcelUpload.vue
 * 설명: 
 * 작성자: P180190
 * 작성일: 2022.09.20
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog
        :dialogShow.sync="NewAccSacSaleCmmsAdpayMgmtExcelUploadShow"
        size="1000px"
    >
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">판매수수료선지급업로드</p>

                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComFileInput
                                    v-model="files"
                                    labelName="첨부파일"
                                    @change="onFilesChange"
                                ></TCComFileInput>
                            </div>
                            <div
                                class="formitem div2"
                                style="margin-top: -14px"
                            >
                                <button
                                    type="button"
                                    class="btn_s btn_ty03"
                                    @click="clickValidate"
                                >
                                    오류검증
                                </button>
                                <button
                                    type="button"
                                    class="btn_s btn_ty03"
                                    :disabled="!isValid"
                                    @click="submit"
                                >
                                    엑셀반영
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader1"
                            ref="gridHeader1"
                            gridTitle="판매수수료선지급 엑셀업로드"
                            :isExceldown="true"
                            :gridObj="gridObj"
                            @excelDownBtn="excelDownload"
                        >
                        </TCRealGridHeader>
                        <TCRealGrid
                            id="grid1"
                            ref="grid1"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom"></div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <button
                        type="button"
                        class="layerClose b-close"
                        @click="closePopup"
                    >
                        닫기
                    </button>
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>
<script>
import CommonMixin from '@/mixins'
import { FileUtil, CommonUtil } from '@/utils'
import moment from 'moment'
import _ from 'lodash'
import * as XLSX from 'xlsx'
import { GRID_HEADER } from '@/const/grid/acc/sac/newAccSacSaleCmmsAdpayMgmtExcelUploadGrid'

import adpayApi from '@/api/biz/acc/sac/NewAccSacSaleCmmsAdpayMgmt'

export default {
    name: 'newAccSacSaleCmmsAdpayMgmtExcelUpload',
    mixins: [CommonMixin],
    components: {},
    props: {
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },

    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,
            file: [],
            files: [],
            isValid: false,

            //Grid
            objAuth: {},
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
        }
    },

    computed: {
        NewAccSacSaleCmmsAdpayMgmtExcelUploadShow: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },

    watch: {},

    created() {},
    mounted() {
        // grid 기본세팅
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, false)
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: '번호',
        })
    },
    methods: {
        closePopup() {
            this.data = []
            this.fileValue = null
            this.isValid = false
            this.NewAccSacSaleCmmsAdpayMgmtExcelUploadShow = false

            this.$emit('close', this.paramAccYm)
        },

        excelUploadFile(files) {
            const f = files
            if (!_.isUndefined(f) && !_.isNull(f)) {
                const reader = new FileReader()
                reader.onload = (e) => {
                    const data = e.target.result
                    // Array Buffer인 경우 base64로 변환 처리
                    const arr = FileUtil.arrayBufferFixdata(data)
                    const workbook = XLSX.read(FileUtil.encodeBase64(arr), {
                        type: 'base64',
                        cellText: true,
                        cellDates: true,
                    })
                    // 워크북 처리(1줄 헤더 포함 처리)
                    this.processWorkbook(workbook)
                    // 워크북 처리(멀티 헤더 제외 처리)
                    //this.processWorkbookNotHeader(workbook)
                }
                reader.readAsArrayBuffer(f)
            }
        },
        // 워크북 처리(1줄 헤더 포함 처리)
        processWorkbook(wb) {
            const output = FileUtil.excelTojson(wb)
            const sheetNames = Object.keys(output)

            if (sheetNames.length) {
                const colsObj = output[sheetNames[0]]
                if (colsObj) {
                    const data = output[sheetNames]
                    console.log('processWorkbook: ', data)
                    if (CommonUtil.checkJsonStrDocSecurity(data)) {
                        this.showTcComAlert(
                            '문서보안 엑셀 파일입니다.\n확인 후 다시 업로드해주세요.'
                        )
                        return
                    }
                    const mappedData = data.map((item) => {
                        return {
                            accSt: item['정산상태'],
                            orgCd: item['영업파트코드'],
                            orgNm: item['영업파트'],
                            accDealcoCd: item['정산처'],
                            accDealcoNm: item['정산처명'],
                            preAccAmt: item['선지급금액'],
                            errDesc: item['오류내용'],
                            accCl: item['정산구분'],
                        }
                    })
                    this.gridObj.dataProvider.fillJsonData(mappedData, {})
                }
            }
        },

        onFilesChange(files) {
            this.excelUploadFile(files)

            // this.data.forEach((arr) => (arr.errDesc = ''))
            this.file = files
            console.log('onFilesChange:::::', files)
        },

        //  오류검증
        clickValidate() {
            if (this.files.length == 0) {
                this.showTcComAlert(
                    '업로드 문서에 처리 할 데이터가 없습니다.\n업로드 문서를 확인하시기 바랍니다.'
                )
                return
            }
            return adpayApi
                .postAccSacAccsExcelCheck({
                    // excelCheckVoList: this.accGridTable.getAllRow(),
                    excelCheckVoList: this.gridObj.dataProvider.getJsonRows(
                        0,
                        -1
                    ),
                })
                .then((res) => {
                    this.gridObj.setRows(res)
                    console.log('res', res)
                    // res.forEach((row) => {
                    // console.log(row)
                    // if (row.errDesc == null) {
                    this.isValid = true
                    this.files = res
                    // }
                    // })
                    console.log('files', this.files)
                })
        },

        excelDownload() {
            const date = moment(new Date()).format('YY-MM-DD-hhmm')
            this.gridHeaderObj.exportSampleGrid(
                '판매수수료선지급업로드' + date + '.xlsx'
            )
        },

        //  엑셀반영
        async submit() {
            if (
                await this.showTcComConfirm(
                    '오류사항이 발생된 행은 업로드 시 자동 제외 합니다. \n계속 하시겠습니까?'
                )
            ) {
                const rows = []
                this.files.forEach((arr) => {
                    console.log('arr.errDesc::::', arr.errDesc)
                    if (arr.errDesc == null) {
                        rows.push(
                            Object.assign(arr, {
                                payReqDt: moment(new Date()).format('YYYYMMDD'),
                                accMth: moment(this.popupParams.accMth).format(
                                    'YYYYMM'
                                ),
                            })
                        )
                        console.log('arr.errDesc::::', arr.errDesc)
                    }
                })
                return adpayApi
                    .postAccSacAccsExcelUpload({ excelInputVoList: rows })
                    .then((res) => {
                        console.log('res', res)
                        this.showTcComAlert('정상적으로 처리되었습니다.')
                        this.closePopup()
                    })
            }
        },
    },
}
</script>
