import { ValueType } from 'realgrid'

export const DEP_HEADER = {
    fields: [
        {
            fieldName: 'NO',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'uuid',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'progId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'progNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'typNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'progUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'depObjYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'depDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'depClNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'NO',
            header: {
                text: 'NO',
                excelName: 'NO',
            },
            editable: false,
            sortable: false,
            visible: true,
            width: '30',
        },
        {
            name: 'reqDt',
            fieldName: 'reqDt',
            header: {
                text: '요청일자',
                excelName: '요청일자',
            },
            editable: false,
            sortable: false,
            visible: false,
            width: '10',
        },
        {
            name: 'uuid',
            fieldName: 'uuid',
            header: {
                text: 'uuid',
                excelName: 'uuid',
            },
            editable: false,
            sortable: false,
            visible: false,
            width: '10',
        },
        {
            name: 'bizClCd',
            fieldName: 'bizClCd',
            header: {
                text: '업무구분',
                excelName: '업무구분',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '80',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'progId',
            fieldName: 'progId',
            header: {
                text: '프로그램ID',
                excelName: '프로그램ID',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '100',
        },
        {
            name: 'progNm',
            fieldName: 'progNm',
            header: {
                text: '프로그램명',
                excelName: '프로그램명',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '200',
        },
        {
            name: 'typNm',
            fieldName: 'typNm',
            header: {
                text: '구분',
                excelName: '구분',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: ['', '화면', 'JAVA', '배치', 'Function', 'Procedure'], //화면, JAVA, 배치, Function, Procedure
                labels: [
                    '선택',
                    '화면',
                    'JAVA',
                    '배치',
                    'Function',
                    'Procedure',
                ], //화면, JAVA, 배치, Function, Procedure
            },
        },
        {
            name: 'progUserNm',
            fieldName: 'progUserNm',
            header: {
                text: '담당자',
                excelName: '담당자',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '100',
        },
        {
            name: 'depObjYn',
            fieldName: 'depObjYn',
            header: {
                text: '배포대상여부',
                excelName: '배포대상여부',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '80',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 2,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
            displayCallback(grid, index, value) {
                let rtVal = 'N'
                if (value == 'Y') rtVal = 'Y'
                return rtVal
            },
        },
        {
            name: 'depDt',
            fieldName: 'depDt',
            header: {
                text: '배포일시',
                excelName: '배포일시',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '120',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'depClNm',
            fieldName: 'depClNm',
            header: {
                text: '신규/변경', //'배포상태',
                excelName: '신규/변경', //'배포상태',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '80',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 2,
                domainOnly: true,
                textReadOnly: true,
                values: ['신규', '변경'],
                labels: ['신규', '변경'],
            },
        },
    ],
}

export const TEST_HEADER = {
    fields: [
        {
            fieldName: 'NO',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'uuid',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'progId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'itemSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'vrfTestTxt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'preCondTxt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'devTestRslt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'devTestDtl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'piTestRslt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'piTestDtl',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'NO',
            header: {
                text: 'NO',
                excelName: 'NO',
            },
            editable: false,
            sortable: false,
            visible: true,
            width: '20',
        },
        {
            name: 'reqDt',
            fieldName: 'reqDt',
            header: {
                text: '요청일자',
                excelName: '요청일자',
            },
            editable: false,
            sortable: false,
            visible: false,
            width: '10',
        },
        {
            name: 'uuid',
            fieldName: 'uuid',
            header: {
                text: 'uuid',
                excelName: 'uuid',
            },
            editable: false,
            sortable: false,
            visible: false,
            width: '10',
        },
        {
            name: 'progId',
            fieldName: 'progId',
            header: {
                text: '프로그램ID',
                excelName: '프로그램ID',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '100',
        },
        {
            name: 'itemSeq',
            fieldName: 'itemSeq',
            header: {
                text: '항목SEQ',
                excelName: '항목SEQ',
            },
            editable: false,
            sortable: false,
            visible: false,
            width: '10',
        },
        {
            name: 'vrfTestTxt',
            fieldName: 'vrfTestTxt',
            header: {
                text: '점검내용',
                excelName: '점검내용',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '150',
            editor: {
                type: 'multiline',
            },
            styleName: 'multiline-editor',
        },
        {
            name: 'preCondTxt',
            fieldName: 'preCondTxt',
            header: {
                text: '입력값',
                excelName: '입력값',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '100',
            editor: {
                type: 'multiline',
            },
            styleName: 'multiline-editor',
        },
        {
            name: 'devTestRslt',
            fieldName: 'devTestRslt',
            header: {
                text: '결과', //'1차테스트_결과',
                excelName: '1차테스트_결과',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '50',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 2,
                domainOnly: true,
                textReadOnly: true,
                values: ['PASS', 'FAIL'],
                labels: ['PASS', 'FAIL'],
            },
        },
        {
            name: 'devTestDtl',
            fieldName: 'devTestDtl',
            header: {
                text: '오류/수정 내용', //'1차테스트_내용',
                excelName: '1차테스트_내용',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '150',
            editor: {
                type: 'multiline',
            },
            styleName: 'multiline-editor',
        },
        {
            name: 'piTestRslt',
            fieldName: 'piTestRslt',
            header: {
                text: '결과', //'2차테스트_결과',
                excelName: '2차테스트_결과',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '50',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 2,
                domainOnly: true,
                textReadOnly: true,
                values: ['PASS', 'FAIL'],
                labels: ['PASS', 'FAIL'],
            },
        },
        {
            name: 'piTestDtl',
            fieldName: 'piTestDtl',
            header: {
                text: '오류/수정 내용', //'2차테스트_내용',
                excelName: '2차테스트_내용',
            },
            editable: true,
            sortable: false,
            visible: true,
            width: '150',
            editor: {
                type: 'multiline',
            },
            styleName: 'multiline-editor',
        },
    ],
}
