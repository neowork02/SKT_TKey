import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('rmt.enc.salePopupStore', Object.keys(state)),
    ...mapGetters('rmt.enc.salePopupStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('rmt.enc.salePopupStore', Object.keys(actions)),
    ...mapMutations('rmt.enc.salePopupStore', Object.keys(mutations)),
}
