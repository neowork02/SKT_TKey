<template>
    <div class="content">
        <h1>개인정보파일다운로드이력</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearchClick"
                >
                    조회
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5_1">
                    <TCComComboBox
                        labelName="구분"
                        v-model="searchParam.gubun"
                        :itemList="downupList"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div3">
                    <TCComDatePicker
                        calType="DP"
                        v-model="searchDate"
                        labelName="기간"
                        :eRequired="true"
                    ></TCComDatePicker>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="agencyDownGridHeader"
                ref="agencyDownGridHeader"
                gridTitle="목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="false"
            />
            <TCRealGrid
                id="agencyDownGrid"
                ref="agencyDownGrid"
                :fields="agencyDownHeader.fields"
                :columns="agencyDownHeader.columns"
                :editable="true"
                :updatable="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getAgencyDownList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="onChgRowCnt"
            />
            <BasAdmInfsAgencyDownDtlPopup
                v-if="showBasAdmInfsAgencyDownDtl"
                :dialogShow.sync="showBasAdmInfsAgencyDownDtl"
                :parentParam="selectedGridRow"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid, CommonMsg } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import { AGENCY_DOWN_HEADER } from '@/const/grid/bas/adm/basAdmInfsAgencyDownHeader'
import basAdmInfsAgencyDownApi from '@/api/biz/bas/adm/basAdmInfsAgencyDownApi'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'BasAdmInfsAgencyDown',
    components: {
        BasAdmInfsAgencyDownDtlPopup: () =>
            import('./BasAdmInfsAgencyDownDtlPopup'),
    },
    mixins: [CommonMixin],

    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            agencyDownHeader: AGENCY_DOWN_HEADER,
            downupList: [
                { commCdVal: 'U', commCdValNm: '업로드' },
                { commCdVal: 'D', commCdValNm: '다운로드' },
            ],
            searchDate: [],
            rowCnt: 15,
            //각각 엘리먼트 컴포넌트 v-model
            searchParam: {
                gubun: '', // 구분
                fromDt: '', // 조회날짜 from
                toDt: '', // 조회날짜 to
                pageNum: 1,
                pageSize: 15,
            },
            showBasAdmInfsAgencyDownDtl: false,
            selectedGridRow: {},
        }
    },

    watch: {
        // 조회날짜 동기화
        searchDate: {
            handler() {
                this.searchParam.fromDt = this.searchDate[0]
                this.searchParam.toDt = this.searchDate[1]
            },
            deep: true, // 속성 내부까지 감시
            immediate: false, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },

    created() {
        this.init()
    },

    mounted() {
        // console.log('menuInfo', this.menuInfo) //메뉴정보
        // console.log('orgInfo', this.orgInfo) //조직정보
        // console.log('userInfo', this.userInfo) //사용자정보
        // console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        this.gridObj = this.$refs.agencyDownGrid
        this.gridHeaderObj = this.$refs.agencyDownGridHeader
        this.gridObj.setGridState(true, false, false, false)
        this.setGridEvent()
    },

    methods: {
        init: function () {
            this.gridData = this.gridSetData()
            // 조회날짜
            this.searchParam.fromDt = CommonUtil.getToday('YYYY-MM-DD')
            this.searchParam.toDt = CommonUtil.getToday('YYYY-MM-DD')
            this.searchDate = [this.searchParam.fromDt, this.searchParam.toDt]
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        setGridEvent() {
            this.gridObj.gridView.onCellClicked = (grid, clickData) => {
                console.log('onCellClicked: ', clickData)
                const column = clickData.column
                const dataRow = clickData.dataRow
                if (clickData.cellType === 'data') {
                    if (column === 'opDtm') {
                        this.selectedGridRow = grid
                            .getDataSource()
                            .getJsonRow(dataRow)
                        this.showBasAdmInfsAgencyDownDtl = true
                    }
                }
            }
        },

        // 날짜 기간 체크
        chkValidDateFromTo(bSameMonth, nInterValDay) {
            const fromDt = CommonUtil.replaceDash(this.searchParam.fromDt)
            const toDt = CommonUtil.replaceDash(this.searchParam.toDt)

            if (_.isEmpty(fromDt)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '시작일시')
                )
                this.$refs.searchDate.sDateFocus()
                return false
            }
            if (_.isEmpty(toDt)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '종료일시')
                )
                this.$refs.searchDate.eDateFocus()
                return false
            }

            const chkNumCompare = CommonUtil.checkNumCompare(fromDt, toDt)
            if (chkNumCompare === -1) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00095', '종료일시;시작일시')
                )
                this.$refs.searchDate.sDateFocus()
                return false
            }

            if (bSameMonth && bSameMonth === true) {
                if (fromDt.substr(0, 6) != toDt.substr(0, 6)) {
                    this.showTcComAlert(
                        '동일한 월에 대해서만 조회가 가능합니다.'
                    )
                    return false
                }
            }

            if (nInterValDay && nInterValDay > 0) {
                const diffDate = CommonUtil.getDiffDate(toDt, fromDt)
                if (diffDate > nInterValDay) {
                    this.showTcComAlert(
                        `${nInterValDay}일을 초과 설정하실 수 없습니다.`
                    )
                    this.$refs.searchDate.eDateFocus()
                    return false
                }
            }

            return true
        },

        // 페이지 표시 행의 수 변경처리
        onChgRowCnt(val) {
            this.rowCnt = val
        },

        //조회 버튼 이벤트
        onSearchClick() {
            // 조회기관 체크
            if (!this.chkValidDateFromTo(true, 0)) {
                return
            }
            this.gridData.totalPage = 0
            this.getAgencyDownList()
        },

        getAgencyDownList(pageNum) {
            this.searchParam.fromDt = CommonUtil.replaceDash(
                this.searchParam.fromDt
            )
            this.searchParam.toDt = CommonUtil.replaceDash(
                this.searchParam.toDt
            )
            this.searchParam.pageNum = pageNum ?? 1
            this.searchParam.pageSize = this.rowCnt

            // 페이징 조회
            basAdmInfsAgencyDownApi
                .getAgencyDownList(this.searchParam)
                .then((result) => {
                    this.gridObj.dataProvider.setRows(result.gridList)
                    // 페이징 관련
                    // 순번(역순)이 필요한경우 계산하는 함수
                    this.gridObj.setGridIndicator(result.pagingDto)
                    // 초기화
                    this.gridData = this.gridSetData()
                    // 총페이지수
                    this.gridData.totalPage = result.pagingDto.totalPageCnt
                    // Grid Row 가져올때 페이지정보 Setting
                    this.gridHeaderObj.setPageCount(result.pagingDto)
                })
        },
    },
}
</script>
