'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: 'wrtDt',
        editable: false,
        header: { text: '* 전기일' },
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'org2Nm',
        editable: false,
        header: { text: '사업담당' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'org3Nm',
        editable: false,
        header: { text: '영업팀' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'org4Id',
        editable: false,
        header: { text: '영업파트ID' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'org4Nm',
        editable: false,
        header: { text: '영업파트' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'stlPlc',
        editable: false,
        header: { text: '정산처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'stlPlcNm',
        editable: false,
        header: { text: '정산처명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'salePlc',
        editable: false,
        header: { text: '* 판매처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'salePlcNm',
        readOnly: false,
        header: { text: '판매처명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'amtCd',
        editable: false,
        visible: false,
        header: { text: '* 금액구분코드' },
        type: 'data',
        width: -1,
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'amtCdNm',
        editable: false,
        header: { text: '금액구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'smrtPackAmt',
        editable: false,
        header: { text: '* 금액' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'opDt',
        editable: false,
        header: { text: '처리일' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'opUserId',
        editable: false,
        header: { text: '처리자ID' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'opUserNm',
        editable: false,
        header: { text: '처리자명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    // {
    //     fieldName: 'amtCd',
    //     header: { text: '업로드코드' },
    //     visible: false,
    // },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {
    resultGridDto: {
        gridList: [
            {
                wrtDt: '20200101',
                org2Nm: '22',
                org3Nm: '33',
                stlPlcNm: '44',
                stlPlc: '1aaa',
                smrtPackAmt: '1200213012',
            },
            {
                wrtDt: '20200101',
                org2Nm: '22',
                org3Nm: '33',
                stlPlcNm: '44',
                stlPlc: '1aaa',
                smrtPackAmt: '1200213012',
            },
            {
                wrtDt: '20200101',
                org2Nm: '22',
                org3Nm: '33',
                stlPlcNm: '44',
                stlPlc: '1aaa',
                smrtPackAmt: '1200213012',
            },
            {
                wrtDt: '20200101',
                org2Nm: '22',
                org3Nm: '33',
                stlPlcNm: '44',
                stlPlc: '1aaa',
                smrtPackAmt: '1200213012',
            },
        ],

        pagingDto: {
            pageNum: 1,
            pageSize: 15,
            totalDataCnt: 75,
            totalPageCnt: 5,
        },
    },
}

export { GRID_HEADER, MOCK_DATA }
