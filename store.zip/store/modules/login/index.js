export default {
    namespaced: true,
    state: {
        _authInfo: [],
        _orgInfo: {},
        _userInfo: {},
    },
    actions: {
        setAuthInfo({ commit }, authInfo) {
            commit('SET_AUTH_INFO', authInfo)
        },
        setOrgInfo({ commit }, orgInfo) {
            commit('SET_ORG_INFO', orgInfo)
        },
        setUserInfo({ commit }, userInfo) {
            commit('SET_USER_INFO', userInfo)
        },
    },
    getters: {
        authInfo: (state) => {
            return state._authInfo
        },
        orgInfo: (state) => {
            return state._orgInfo
        },
        userInfo: (state) => {
            return state._userInfo
        },
    },
    mutations: {
        SET_AUTH_INFO: (state, payload) => {
            state._authInfo = payload.authInfo
        },
        SET_ORG_INFO: (state, payload) => {
            state._orgInfo = payload.orgInfo
        },
        SET_USER_INFO: (state, payload) => {
            state._userInfo = payload.userInfo
        },
    },
}
