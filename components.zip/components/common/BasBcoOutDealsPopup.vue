<!-----------------------------------------------
 * 업무그룹명: 기준정보>외부거래처검색
 * 서브업무명: 외부거래처검색
 * 설명: 외부거래처검색 Popup 컴포넌트
 * 작성자: 김태훈
 * 작성일: 2022.05.12
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpenOutDeal" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">외부거래처</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    v-model="searchOutDealParam.dealcoGrpCd"
                                    codeId="DEAL_CO_GRP"
                                    labelName="외부거래처그룹"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :filterFunc="filterFunc"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComComboBox
                                    v-model="searchOutDealParam.dealcoClCd1"
                                    codeId="ZBAS_C_00240"
                                    labelName="외부거래처구분"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3"></div>
                            <!-- // input -->
                        </div>
                        <!-- // Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchOutDealParam.dealcoCd"
                                    labelName="외부거래처코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchOutDealParam.dealcoNm"
                                    labelName="외부거래처점명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <!-- item 2-4 -->
                            <div class="formitem div3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- // Search_line 2 -->
                    </div>
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">외부거래처 목록</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="outDealGrid"
                                ref="outDealGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                                @hook:mounted="gridMounted"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { BAS_BCO_OUT_DEAL_HEADER } from '@/const/grid/bas/bco/basBcoOutDealsHeader'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
import commonApi from '@/api/common/commonCode'
import CommonMixin from '@/mixins'
// import _ from 'lodash'

export default {
    name: 'BasBcoOutDealsPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: BAS_BCO_OUT_DEAL_HEADER,
            headerText: '',
            searchOutDealParam: {
                dealcoGrpCd: '', // 외부거래처그룹
                dealcoClCd1: '', // 외부거래처구분
                dealcoCd: '', // 외부거래처코드
                dealcoNm: '', // 외부거래처명
            },
        }
    },
    computed: {
        activeOpenOutDeal: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchOutDealParam.dealcoGrpCd =
                    value['dealcoGrpCd'] == undefined
                        ? ''
                        : value['dealcoGrpCd'] // 외부거래처그룹
                this.searchOutDealParam.dealcoClCd1 =
                    value['dealcoClCd1'] == undefined
                        ? ''
                        : value['dealcoClCd1'] // 외부거래처구분
                this.searchOutDealParam.dealcoCd =
                    value['dealcoCd'] == undefined ? '' : value['dealcoCd'] // 외부거래처코드
                this.searchOutDealParam.dealcoNm =
                    value['dealcoNm'] == undefined ? '' : value['dealcoNm'] // 외부거래처명
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },
    async mounted() {
        this.gridObj = this.$refs.outDealGrid // Grid Object 설정
        this.initGrid()
    },
    methods: {
        init() {
            this.gridData = this.gridSetData()
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false, false)
            const commDealCoGrp = await this.getCommCodeList('DEAL_CO_GRP')
            const commDealcoClCd1 = await this.getCommCodeList('ZBAS_C_00240')

            // 외부거래처그룹 구분 lOV
            this.gridObj.gridView.columnByName('dealcoGrpCd').values =
                CommonUtil.convListToGridLovValues(commDealCoGrp, 'commCdVal')
            this.gridObj.gridView.columnByName('dealcoGrpCd').labels =
                CommonUtil.convListToGridLovLabels(commDealCoGrp, 'commCdValNm')
            // 외부거래처구분 유형 lOV
            this.gridObj.gridView.columnByName('dealcoClCd1').values =
                CommonUtil.convListToGridLovValues(commDealcoClCd1, 'commCdVal')
            this.gridObj.gridView.columnByName('dealcoClCd1').labels =
                CommonUtil.convListToGridLovLabels(
                    commDealcoClCd1,
                    'commCdValNm'
                )

            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },

        gridMounted() {
            console.log('gridMounted')
        },

        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    console.log('getOutDealList then : ', res)
                    this.gridObj.setRows(res)
                })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('외부거래처를 선택해주세요.', {
                    header: '외부거래처 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenOutDeal = false
        },

        onSearch() {
            this.getOutDealList()
        },

        onEnterKey() {
            this.onSearch()
        },

        filterFunc(items) {
            return items.filter((items) => items['addInfo3'] === 'Y')
        },
    },
}
</script>
