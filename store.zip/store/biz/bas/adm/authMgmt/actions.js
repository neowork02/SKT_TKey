import api from '@/api/biz/bas/adm/basAdmAuthMgmt'
import types from './mutation-types'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    showAlert_({ commit }, { title, message }) {
        commit(types.DEFAULT_ASSIGN, {
            key: 'alertHeaderText',
            value: title,
        })
        commit(types.DEFAULT_ASSIGN, {
            key: 'alertBodyText',
            value: message,
        })
        commit(types.DEFAULT_ASSIGN, {
            key: 'alertShow',
            value: true,
        })
    },
    toasting_({ commit }, { message }) {
        commit(types.DEFAULT_ASSIGN, {
            key: 'snackbar',
            value: true,
        })
        commit(types.DEFAULT_ASSIGN, {
            key: 'snackbarText',
            value: message,
        })
    },
    async getUserGrpNmList_({ commit }, { attcClCd }) {
        let resultData

        await api
            .getUserGrpNmList_(attcClCd)
            .then((data) => {
                resultData = data

                commit(types.DEFAULT_ASSIGN, {
                    key: 'userGrpNmList',
                    value: resultData,
                })
            })
            .catch((error) => {
                throw error
            })
        return resultData
    },
    async getBasAdmAuthMgmtList_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum
        console.log(
            '🚀 ~ file: actions.js ~ line 87 ~ searchParams',
            searchParams
        )
        await api
            .getBasAdmAuthMgmtList_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ line 97 ~ .then ~ data',
                    data
                )
                console.log('data.gridList -> ', data.gridList)
                commit(types.DEFAULT_ASSIGN, {
                    key: 'resultListAdm',
                    value: data.gridList,
                })

                resultData = data
                console.log('resultData -> ', resultData)
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },

    async getBasAdmMenuAuthMgmtList_({ commit }) {
        let resultData

        await api
            .getBasAdmMenuAuthMgmtList_({})
            .then((data) => {
                console.log('data.gridList -> ', data.gridList)
                commit(types.DEFAULT_ASSIGN, {
                    key: 'resultListAdmMenu',
                    value: data.gridList,
                })

                resultData = data
                console.log('resultData -> ', resultData)
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },
    //, commit
    async getBasAdmMenuTadmAuthLst_({ state }) {
        let resultData
        let searchParams = state.tadmAuthParam

        console.log('getBasAdmMenuTadmAuthLst_ searchParams', searchParams)
        await api
            .getBasAdmMenuTadmAuthLst_({ searchParams })
            .then((data) => {
                resultData = data
                console.log('resultData -> ', resultData)
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },

    async getBasAdmMenuAuthMenuMgmtDtl_({ state, commit }) {
        let resultData
        let searchParams = state.menuAuthMgmtParam
        console.log('searchParams --> ', searchParams)
        await api
            .getBasAdmMenuAuthMenuMgmtDtl_({ searchParams })
            .then((data) => {
                console.log('data.gridList -> ', data.gridList)
                commit(types.DEFAULT_ASSIGN, {
                    key: 'resultListAdmMenuDtl',
                    value: data.gridList,
                })

                resultData = data
                console.log('resultData -> ', resultData)
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },

    async rgstBasAdmAuthMgmt_({ state }) {
        let result = 0
        let params = state.params
        await api
            .rgstBasAdmAuthMgmt_({ params })
            .then((data) => {
                console.log('rgstBasAdmAuthMgmt_ data -> ', data)
                result = data
            })
            .catch((error) => {
                throw error
            })
        console.log('result -> ', result)
        return result
    },

    async uptBasAdmAuthMgmt_({ state }) {
        let result = 0
        let params = state.params
        await api
            .uptBasAdmAuthMgmt_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
    async delBasAdmAuthMgmt_({ state }) {
        let result = 0
        let params = state.params
        await api
            .delBasAdmAuthMgmt_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },

    async copyBasAdmAuthMgmt_({ state }) {
        let result = 0
        let params = state.params
        await api
            .copyBasAdmAuthMgmt_({ params })
            .then((data) => {
                console.log('copyBasAdmAuthMgmt_ data -> ', data)
                result = data
            })
            .catch((error) => {
                throw error
            })
        console.log('result -> ', result)
        return result
    },

    async rgstBasAdmAuthMenuMgmt_({ state }) {
        let result = 0
        let params = state.menuParams
        await api
            .rgstBasAdmAuthMenuMgmt_({ params })
            .then((data) => {
                console.log('rgstBasAdmAuthMenuMgmt_ data -> ', data)
                result = data
            })
            .catch((error) => {
                throw error
            })
        console.log('result -> ', result)
        return result
    },

    async rgstBasAdmAuthMgmtUser_({ state }) {
        let result = 0
        let params = state.saveParams
        await api
            .rgstBasAdmAuthMgmtUser_({ params })
            .then((data) => {
                console.log('rgstBasAdmAuthMgmtUser_ data -> ', data)
                result = data
            })
            .catch((error) => {
                throw error
            })
        console.log('result -> ', result)
        return result
    },

    // eslint-disable-next-line no-unused-vars
    async getAuthMgmtUserList_({ state, commit }, { param }) {
        let resultData
        let searchParams = param

        await api.getAuthMgmtUserList_({ searchParams }).then((data) => {
            console.log('getAuthMgmtUserList_ ->', data)
            resultData = data
        })

        let userIncludes = resultData
            .filter((item) => item.isAuth === 'Y')
            .map((object) => ({
                ...object,
                origin: 'in',
            }))

        commit(types.DEFAULT_ASSIGN, {
            key: 'resultList',
            value: userIncludes,
        })

        let userExcludes = resultData
            .filter((item) => item.isAuth === 'N')
            .map((object) => ({
                ...object,
                origin: 'ex',
            }))

        commit(types.DEFAULT_ASSIGN, {
            key: 'resultListAll',
            value: userExcludes,
        })

        return resultData
    },
    // async getAuthMgmtUserList2_({ state, commit }, { param }) {
    //     let resultData
    //     let searchParams = param
    //
    //     await api.getAuthMgmtUserList2_({ searchParams }).then((data) => {
    //         console.log('getAuthMgmtUserList_ ->', data)
    //         resultData = data
    //     })
    //
    //     let userIncludes = resultData
    //         .filter(
    //             (item) =>
    //                 item.userGrpCd === searchParams.userGrpCd &&
    //                 item.effDateYn === 'N' && // 만료기간이 안된 유저인 경우
    //                 item.exDelYn === 'N' // 삭제가 안된 유저인 경우
    //             //item.userId === item.exUserId && // 매핑된 아이디와 미매핑된 아이디가 같은 경우 매핑된 유저
    //             //item.effDateYn === 'N' && // 만료기간이 안된 유저인 경우
    //             //item.exDelYn === 'N' // 삭제가 안된 유저인 경우
    //         )
    //         .map((object) => ({
    //             ...object,
    //             origin: 'in',
    //         }))
    //
    //     commit(types.DEFAULT_ASSIGN, {
    //         key: 'resultList',
    //         value: userIncludes,
    //     })
    //
    //     let userExcludes = resultData
    //         .filter(
    //             (item) =>
    //                 item.userGrpCd !== searchParams.userGrpCd &&
    //                 (item.exUserId === '미매핑' ||
    //                     item.effDateYn === 'Y' || // 만료기간이 만료된 유저인 경우
    //                     item.effDateYn === '' ||
    //                     item.exDelYn === 'Y')
    //             /*
    //                 item.userId != item.exUserId ||
    //                 item.exUserId === null || // 매핑된 아이디와 미매핑된 아이디가 다른 경우 미매핑된 유저 또는 미매핑된 유저가 null인 경우
    //                 item.effDateYn === 'Y' || // 만료기간이 만료된 유저인 경우
    //                 item.exDelYn === 'Y' ||
    //                 item.exDelYn === null // 삭제가 된 유저인 경우 또는 null
    //
    //                  */
    //         )
    //         .map((object) => ({
    //             ...object,
    //             origin: 'ex',
    //         }))
    //
    //     commit(types.DEFAULT_ASSIGN, {
    //         key: 'resultListAll',
    //         value: userExcludes,
    //     })
    //
    //     return resultData
    // },
}
