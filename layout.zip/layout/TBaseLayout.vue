<template>
    <div class="wrap">
        <TBaseHeader></TBaseHeader>
        <!-- ##### container  #####-->
        <div class="container">
            <TBaseLeft></TBaseLeft>
            <TBaseContent> </TBaseContent>
            <!-- <TBaseFooter></TBaseFooter> -->
        </div>
    </div>
</template>

<script>
import TBaseHeader from '@/layout/TBaseHeader'
import TBaseLeft from '@/layout/TBaseLeft'
import TBaseContent from '@/layout/TBaseContent'
// import TBaseFooter from '@/layout/TBaseFooter'

export default {
    components: {
        TBaseContent,
        // TBaseFooter,
        TBaseHeader,
        TBaseLeft,
    },
}
</script>
<style></style>
