import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('sal.smg.shSdSalePrstStore', Object.keys(state)),
    ...mapGetters('sal.smg.shSdSalePrstStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('sal.smg.shSdSalePrstStore', Object.keys(actions)),
    ...mapMutations('sal.smg.shSdSalePrstStore', Object.keys(mutations)),
}
