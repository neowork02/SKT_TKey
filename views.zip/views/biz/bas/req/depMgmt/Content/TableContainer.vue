<template lang="">
    <div class="gridWrap">
        <TCRealGridHeader
            id="depMgmtGridHeader2"
            ref="depMgmtGridHeader2"
            gridTitle="목록"
            :gridObj="gridObj"
            :isPageRows="true"
            :isExceldown="false"
            :isNextPage="false"
            :isPageCnt="false"
            :editable="true"
            :isAddRow="false"
            :isDelRow="false"
            :addData="this.addData"
            @excelDownBtn="excelDownBtn"
            @addRowBtn="this.gridAddRowBtn"
            @chkDelRowBtn="this.gridchkDelRowBtn"
        >
            <template #gridBtnArea>
                <!--PS&M 만 사용 -->
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_basic"
                    labelName="검증시나리오 등록"
                    @click="vrfPopup"
                />
                <!--TDCS운영팀 사용 ??, 대리점사용자는 2차테스트 부분만 사용  -->
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_basic"
                    labelName="상세 등록"
                    @click="depProgressPopup"
                />
                <!-- MNO IT개발팀 만 사용-->
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_basic"
                    labelName="배포완료 처리"
                    @click="depCompletePopup"
                />
                <!-- MNO IT개발팀 만 사용-->
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_basic"
                    labelName="취소 처리"
                    @click="depCancelPopup"
                />
                <!-- <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_exeldown"
                    labelName="다운로드"
                    @click="excelDetailDownBtn"
                /> -->
            </template>
        </TCRealGridHeader>
        <TCRealGrid
            id="depMgmtGrid2"
            ref="depMgmtGrid2"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
        <!-- <TCComPaging
            :totalPage="paging1.totalPageCnt"
            :apiFunc="pageMove"
            :rowCnt="paging1.pageSize"
            @input="pageSizeChange"
        /> -->
        <Detail1Popup
            v-if="showPopup1"
            :parentParam="searchPopup1"
            :rows="resultPopup1Rows"
            :dialogShow.sync="showPopup1"
            @confirm="onPopup1ReturnData"
        />
        <Detail2Popup
            v-if="showPopup2"
            :parentParam="searchPopup2"
            :rows="resultPopup2Rows"
            :dialogShow.sync="showPopup2"
            @confirm="onPopup2ReturnData"
        />
        <Detail0Popup
            v-if="showPopup0"
            :parentParam="searchPopup0"
            :rows="resultPopup0Rows"
            :dialogShow.sync="showPopup0"
            @confirm="onPopup0ReturnData"
        />
        <Detail9Popup
            v-if="showPopup9"
            :parentParam="searchPopup9"
            :rows="resultPopup9Rows"
            :dialogShow.sync="showPopup9"
            @confirm="onPopup9ReturnData"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/depMgmt/helpers'
import { GRID_HEADER } from '@/const/grid/bas/req/basReqDepMgmtHeader'
import { CommonGrid } from '@/utils'
import CommonMsg from '@/utils/CommonMsg'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
// eslint-disable-next-line no-unused-vars
import attachedFileApi from '@/api/common/attachedFile'
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
//====================팝업1 팝업====================
import Detail1Popup from './Detail1Popup'
import Detail2Popup from './Detail2Popup'
//====================//팝업1 팝업====================
//====================//팝업0 팝업====================
import Detail0Popup from '@/views/biz/bas/req/docRgst/BasReqDocRgst.vue'
//====================//팝업0 팝업====================
//====================//팝업9 팝업====================
import Detail9Popup from '@/views/biz/bas/req/depRgst/BasReqDepRgst.vue'
//====================//팝업9 팝업====================
import CommonMixin from '@/mixins'
export default {
    mixins: [CommonMixin],
    components: {
        Detail1Popup,
        Detail2Popup,
        Detail0Popup,
        Detail9Popup,
    },
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '380px', //그리드 높이 조절
            },
            view: GRID_HEADER,
            layout: [
                'NO', //순번을 위한 가상컬럼
            ],
            /** 2. Grid 표현 영역 */
            gridDetailLayout: [
                //'chk',
                'NO', //순번을 위한 가상컬럼
                'reqTitle', //요건명
                'devTestYn', //1차테스트여부
                'piTestYn', //2차테스트여부
                'testCnt',
                'depCnt',
                'depSchdDt', //배포예정일자
                'depDt', //배포완료일자
                'reqClCd', //요청구분
                'reqStNm', //진행상태
                'reqUserNmMsk',
                'devClCd', //개발담당자
                //'reqUserId', //요청자
                'reqDt', //요청일자
                //'uuid', //uuid
                //'itDocNo', //IT지원요청서
                //'reqDtl', //요건상세
                //'reqUserNm', //요청자명
                //'reqOrgCd', //요청자조직
                //'reqUserEmail', //요청자메일
                //'expEndDt', //완료예상일자
                //'reqDocId', //요구사항첨부문서Id
                //'aprvOrgCd', //승인조직
                //'aprvDtl', //고려사항/제한조건
                //'aprvUserId', //승인자
                //'rejOrgCd', //반려조직
                //'rejDtl', //반려사유
                //'rejUserId', //반려자
                //'vrfSnro', //검증시나리오

                //'reqOrgNm', //요청자조직명
                //'reqMblPhonNo', //요청자핸드폰번호
                //'aprvUserNm', //승인자명
                //'aprvOrgNm', //승인조직명
                //'rejUserNm', //반려자명
                //'rejOrgNm', //반려조직명
            ],
            addData: [],
            //행추가,수정시 필수 입력 컬럼
            requiredCols: [],
            popupRowIndex: '',
            //====================팝업1 팝업관련====================
            showPopup1: false, // 팝업1 팝업 오픈 여부
            searchPopup1: {},
            resultPopup1Rows: [], // 팝업1 팝업 오픈 여부
            //====================//팝업1 팝업관련==================
            //====================팝업2 팝업관련====================
            showPopup2: false, // 팝업2 팝업 오픈 여부
            searchPopup2: {},
            resultPopup2Rows: [], // 팝업2 팝업 오픈 여부
            //====================//팝업2 팝업관련==================
            //====================팝업0 팝업관련====================
            showPopup0: false, // 팝업0 팝업 오픈 여부
            searchPopup0: {},
            resultPopup0Rows: [], // 팝업0 팝업 오픈 여부
            //====================//팝업0 팝업관련==================
            //====================팝업0 팝업관련====================
            showPopup9: false, // 팝업9 팝업 오픈 여부
            searchPopup9: {},
            resultPopup9Rows: [], // 팝업9 팝업 오픈 여부
            //====================//팝업9 팝업관련==================
        }
    },
    async mounted() {
        //체크바
        // this.$refs.depMgmtGrid2.gridView.setCheckBar({
        //     visible: true,
        // })
        this.gridObj = this.$refs.depMgmtGrid2
        this.gridHeaderObj = this.$refs.depMgmtGridHeader2
        this.gridObj.gridView.setColumnLayout(this.gridDetailLayout)
        this.gridObj.gridView.setCopyOptions({
            singleMode: true,
            includeHeaderText: false,
        })

        /*
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         */
        //this.$refs.depMgmtGrid2.setGridState(true, true, true, false)
        //    this.gridObj.setGridState()
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(true, false, false, false)

        //체크바
        this.$refs.depMgmtGrid2.gridView.setCheckBar({
            visible: true,
        })
        this.$refs.depMgmtGrid2.gridView.checkBar.fieldName = 'chk'

        //편집가능
        this.$refs.depMgmtGrid2.gridView.setEditOptions({
            editable: true,
            updatable: true,
        })
        //컬럼 고정
        // this.gridObj.gridView.setFixedOptions({
        //     colCount: 7,
        // })

        //특정컬럼 속성변경
        //this.gridObj.gridView.columnByName('NO').visible = false
        this.gridObj.gridView.columnByName('NO').editable = false

        //컬럼 크기 자동
        this.$refs.depMgmtGrid2.gridView.displayOptions.fitStyle = 'even' //'none' //

        //this.gridObj.gridView.summaryMode = 'aggregate' //footer 합계 표시

        this.$refs.depMgmtGrid2.gridView.onCellDblClicked = (
            grid,
            clickData
        ) => {
            console.log('onCellDblClicked', clickData.dataRow)
            this.gridPopup(clickData.dataRow, clickData.column)
        }
        // this.$refs.depMgmtGrid2.gridView.onCellClicked = (grid, clickData) => {
        //     console.log('onCellClicked: ' + JSON.stringify(clickData))
        //     const col = clickData.column
        //     if (
        //         col == 'reqUserNm' ||
        //         col == 'reqUserId' ||
        //         col == 'reqUserNmMsk'
        //     ) {
        //         this.gridPopup(clickData.dataRow, clickData.column)
        //     }
        // }
    },
    computed: {
        ...serviceComputed,
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        popupOpenNew1: {
            get() {
                return this.popupOpenNew
            },
        },
    },
    methods: {
        ...serviceMethods,
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 9999, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
            this.gridObj.gridView.clearCurrent() //선택해제
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging',
                value: { ...this.paging, pageSize: pageSize },
            })
            if (this.paging1.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        excelDownBtn: function () {
            // let par1 = {
            //     ..._.clone(this.searchParams),
            //     exDownloadName: `SOR배포관리_${moment(new Date()).format(
            //         'YYYYMMDDHHmmss'
            //     )}`,
            // }
            // attachedFileApi.downLoadFile(
            //     '/api/v1/backend-long/resource/bas/req/tpay-result-list-excel',
            //     par1
            // )
        },
        excelDetailDownBtn: function () {
            // let par1 = {
            //     ..._.clone(this.searchParams),
            //     exDownloadName: `SOR배포관리_상세_${moment(new Date()).format(
            //         'YYYYMMDDHHmmss'
            //     )}`,
            // }
            // attachedFileApi.downLoadFile(
            //     '/api/v1/backend-long/resource/bas/req/tpay-result-paging-list-excel',
            //     par1
            // )
        },
        vrfPopup() {
            //<!--PS&M 만 사용 -->

            const chk1 = this.gridObj.dataProvider.getJsonRows().filter((x) => {
                return x['chk'] == 'true' && x['reqStNm'] == '진행'
            })
            console.log(
                'approve data',
                this.gridObj.dataProvider.getJsonRows(),
                chk1
            )
            if (chk1.length == 0) {
                this.showTcComAlert(
                    '검증시나리오 입력 처리할 건을 한개 선택하세요.<br/>([진행상태: 진행] 건 만 가능)'
                )
                return
            }

            //검증 시나리오 팝업
            let popPar1 = {
                chkList: chk1,
            }
            this.resultPopup1Rows = []
            this.showPopup1 = true
            this.searchPopup1 = popPar1 //TODO
            console.log('Popup1 param', this.searchPopup1)
        },
        depCompletePopup() {
            //<!-- MNO IT개발팀 만 사용-->
            const chk1 = this.gridObj.dataProvider.getJsonRows().filter((x) => {
                return (
                    x['chk'] == 'true' &&
                    x['reqStNm'] == '진행' &&
                    x['devTestYn'] == 'Y' &&
                    x['piTestYn'] == 'Y'
                )
            })
            console.log(
                'approve data',
                this.gridObj.dataProvider.getJsonRows(),
                chk1
            )
            if (chk1.length == 0) {
                this.showTcComAlert(
                    '배포완료 처리할 건을 선택하세요.<br/>([진행상태: 진행 이면서 테스트 완료] 건 만 가능)'
                )
                return
            }

            //배포완료 처리 팝업
            let popPar1 = {
                chkList: chk1,
                reqStNm: '배포',
            }
            this.resultPopup2Rows = []
            this.showPopup2 = true
            this.searchPopup2 = popPar1 //TODO
            console.log('Popup2 param', this.searchPopup2)
        },
        depCancelPopup() {
            //<!-- MNO IT개발팀 만 사용-->
            const chk1 = this.gridObj.dataProvider.getJsonRows().filter((x) => {
                return (
                    x['chk'] == 'true' &&
                    x['reqStNm'] == '진행' &&
                    x['devTestYn'] == 'Y' &&
                    x['piTestYn'] == 'Y'
                )
            })
            console.log(
                'approve data',
                this.gridObj.dataProvider.getJsonRows(),
                chk1
            )
            if (chk1.length == 0) {
                this.showTcComAlert(
                    '취소 처리할 건을 선택하세요.<br/>([진행상태: 진행 이면서 테스트 완료] 건 만 가능)'
                )
                return
            }

            //취소 처리 팝업
            let popPar1 = {
                chkList: chk1,
                reqStNm: '취소',
            }
            this.resultPopup2Rows = []
            this.showPopup2 = true
            this.searchPopup2 = popPar1 //TODO
            console.log('Popup2 param', this.searchPopup2)
        },
        depProgressPopup() {
            //<!--TDCS운영팀 사용 ??, 대리점사용자는 2차테스트 부분만 사용  -->
            const chk1 = this.gridObj.dataProvider.getJsonRows().filter((x) => {
                return x['chk'] == 'true' && x['reqStNm'] == '진행'
            })
            console.log(
                'devProgress data',
                this.gridObj.dataProvider.getJsonRows(),
                chk1
            )
            if (chk1.length == 0) {
                this.showTcComAlert(
                    '상세 등록 처리할 건을 한개 선택하세요.<br/>([진행상태: 진행] 건 만 가능)'
                )
                return
            }

            // 상세 등록 팝업
            const rowData1 = chk1[0]

            let readOnly1 = true
            let mode1 = 'dep'
            if (rowData1['reqStNm'] == '진행') {
                readOnly1 = false
            } else if (rowData1['reqStNm'] != '진행') {
                readOnly1 = true
            }
            let popPar1 = {
                readOnly: readOnly1, //readOnly1  //상세등록 조회 true //수정 false
                mode: mode1, //'dep', //배포,테스트 그리드 수정
                reqDt: rowData1.reqDt,
                uuid: rowData1.uuid,
            }
            this.resultPopup9Rows = []
            this.searchPopup9 = popPar1
            this.showPopup9 = true
            console.log('Popup9 param', this.searchPopup9)
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            this.gridHeaderObj.setPageCount(this.paging)
        },
        gridAddRowBtn: function () {
            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            let focuscell = this.gridObj.gridView.getCurrent()
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
        },
        gridDelRowBtn: function () {
            // not used
            console.log('del current row')
            this.gridData.gridRows = this.gridHeaderObj.selDelRow()
        },
        gridchkDelRowBtn: function () {
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        // eslint-disable-next-line no-unused-vars
        async gridPopup(row, col, val) {
            const rowData1 = this.gridObj.dataProvider.getJsonRow(row)

            if (
                col == 'reqUserNm' ||
                col == 'reqUserId' ||
                col == 'reqUserNmMsk' ||
                col == 'reqDt' ||
                col == 'devClCd'
            ) {
                //요건서 조회 팝업
                let popPar1 = {
                    readOnly: true, //readOnly1  //요건서 조회 true // 요건서 수정 false
                    mode: 'req', //'req', //요건서 수정 //dev : 요건서 수정(개발팀)
                    reqDt: rowData1.reqDt,
                    uuid: rowData1.uuid,
                }
                this.resultPopup0Rows = []
                this.searchPopup0 = popPar1
                this.showPopup0 = true
                console.log('Popup0 param', this.searchPopup0)
            } else if (col == 'NO' || col == 'reqTitle') {
                //<!--TDCS운영팀 사용 ??, 대리점사용자는 2차테스트 부분만 사용  -->
                // 상세 등록 팝업
                let readOnly1 = true
                let mode1 = 'dep'
                if (rowData1['reqStNm'] == '진행') {
                    //<!--TDCS운영팀 사용 ??, 대리점사용자는 2차테스트 부분만 사용  -->
                    readOnly1 = false
                } else if (rowData1['reqStNm'] != '진행') {
                    readOnly1 = true
                }
                let popPar1 = {
                    readOnly: readOnly1, //readOnly1  //상세등록 조회 true //수정 false
                    mode: mode1, //'dep', //배포,테스트 그리드 수정
                    reqDt: rowData1.reqDt,
                    uuid: rowData1.uuid,
                }
                this.resultPopup9Rows = []
                this.searchPopup9 = popPar1
                this.showPopup9 = true
                console.log('Popup9 param', this.searchPopup9)
            }
        },
        // 팝업1 팝업 리턴 이벤트 처리
        async onPopup1ReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     retrunData.orgCd
            // )
            this.$emit('Refresh', '') //next paging api call
        },
        // 팝업2 팝업 리턴 이벤트 처리
        async onPopup2ReturnData(retrunData) {
            console.log('retrunData2: ', retrunData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     retrunData.orgCd
            // )
            this.$emit('Refresh', '') //next paging api call
        },
        // 팝업0 팝업 리턴 이벤트 처리
        async onPopup0ReturnData(retrunData) {
            console.log('retrunData0: ', retrunData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     retrunData.orgCd
            // )
            if (retrunData) this.$emit('Refresh', '') //next paging api call
        },
        async onPopup9ReturnData(retrunData) {
            console.log('retrunData0: ', retrunData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     retrunData.orgCd
            // )
            if (retrunData) this.$emit('Refresh', '') //next paging api call
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        resultList1(val, oldVal) {
            //console.log('resultList1 watched: ', val, oldVal, this.pageSize)
            this.gridObj.gridView.commit()
            this.gridObj.setRows(this.resultList1)

            //순번처리
            //let pageInfo = { ...this.paging1, type: 'paging' } //페이징의 경우
            let pageInfo = {} //페이징이 없는경우
            pageInfo.type = 'noPaging' //페이징이 없는경우
            pageInfo.totalDataCnt = this.resultList1.length //페이징이 없는경우

            this.gridObj.setGridIndicator(pageInfo, { sort: 'DESC' }) //역순으로 번호가 보임
            this.gridObj.gridView.clearCurrent() //선택해제
        },
        // eslint-disable-next-line no-unused-vars
        paging1(val, oldVal) {
            //console.log('paging1 watched: ', val)
            this.SetPaging()
        },
        // eslint-disable-next-line no-unused-vars
        popupOpenNew1(val, oldVal) {
            if (val) {
                console.log('popupOpenNew1')
                this.searchPopup0 = {} //추가
                this.showPopup0 = true
            }
        },
    },
}
</script>
