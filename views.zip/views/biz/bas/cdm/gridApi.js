import send from '@/api/axios-tdcs'

export default {
    getSwingIfList(ds_condition) {
        return send({
            method: 'get',
            url: '/api/v1/backend/bas/cdm/swingIfs',
            params: ds_condition,
        }).catch((err) => {
            alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
            console.log(err)
        })
    },
    saveIfTable(ds_condition) {
        return send({
            method: 'put',
            url: '/api/v1/backend/bas/cdm/saveIfTable',
            data: ds_condition,
        }).catch((err) => {
            alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
            console.log(err)
        })
    },
}
