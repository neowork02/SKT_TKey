import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'workShopNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            header: {
                text: '변경일자',
            },
        },
        /*
        {
            name: 'lvOrgNm1',
            fieldName: 'lvOrgNm1',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업부',
            },
        },
        {
            name: 'lvOrgNm2',
            fieldName: 'lvOrgNm2',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당',
            },
        },
        {
            name: 'lvOrgNm3',
            fieldName: 'lvOrgNm3',
            header: {
                text: '영업팀',
            },
        },
        {
            name: 'lvOrgNm4',
            fieldName: 'lvOrgNm4',
            header: {
                text: '영업파트',
            },
        },
        */
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            width: 300,
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'workShopNm',
            fieldName: 'workShopNm',
            header: {
                text: '근무지',
            },
        },
        {
            name: 'dealcoClNm1',
            fieldName: 'dealcoClNm1',
            header: {
                text: '근무지구분',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '처리일시',
            },
        },
    ],
}
