import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'pagingSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyRgstClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'operCmpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cnsgHldPlcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disAsgnYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wlClYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'operDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeyOrgClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeySubCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'pagingSeq',
            fieldName: 'pagingSeq',
            header: {
                text: 'No.',
            },
            width: 40,
            editable: false,
        },
        {
            name: 'agencyRgstClCd',
            fieldName: 'agencyRgstClCd',
            header: {
                text: '등록구분',
            },
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true

                    //대리점코드 입력 유형 변경
                    let agencyCd1 = grid._view.columnByName('agencyCd')
                    let agencyNm1 = grid._view.columnByName('agencyNm')
                    if (dataCell.value == 'UKEY') {
                        agencyCd1.editable = false
                        agencyCd1.button = 'action'
                        agencyCd1.buttonVisibility = 'default'
                        agencyNm1.editable = false
                    } else if (dataCell.value == 'USER') {
                        agencyCd1.editable = true
                        agencyCd1.button = 'none'
                        agencyCd1.buttonVisibility = ''
                        agencyNm1.editable = true
                    } else {
                        agencyCd1.editable = false
                        agencyNm1.editable = false
                    }
                } else {
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'agencyClCd',
            fieldName: 'agencyClCd',
            header: {
                text: '대리점구분',
            },
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true
                } else {
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'agencyTypCd',
            fieldName: 'agencyTypCd',
            header: {
                text: '대리점유형',
            },
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'operCmpNm',
            fieldName: 'operCmpNm',
            header: {
                text: '운영사',
            },
            button: 'action',
            editable: false,
            buttonVisibility: 'default',
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            header: {
                text: '대리점코드',
            },
            editor: {
                textCase: 'upper',
                maxLength: 10,
            },
            editable: false,
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    //ret.editable = true
                    let gender = grid.getValue(
                        dataCell.index.itemIndex,
                        'agencyRgstClCd'
                    )
                    console.log('대리점구분', gender)
                } else {
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            header: {
                text: '대리점명',
            },
            width: 150,
            editor: {
                maxLength: 100,
            },
            editable: false,
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    //ret.editable = true
                } else {
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: {
                text: '관리조직',
            },
            width: 150,
            button: 'action',
            editable: false,
            buttonVisibility: 'default',
        },
        {
            name: 'cnsgHldPlcCd',
            fieldName: 'cnsgHldPlcCd',
            header: {
                text: '위탁창고',
            },
            editor: {
                textCase: 'upper',
                maxLength: 10,
            },
            // validations: [
            //     {
            //         criteria: 'value is not empty',
            //         message: '이름은 반드시 필요합니다.',
            //         mode: 'always',
            //         level: 'error',
            //     },
            // ],
        },
        {
            name: 'disAsgnYn',
            fieldName: 'disAsgnYn',
            header: {
                text: '자동배정',
            },
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'wlClYn',
            fieldName: 'wlClYn',
            header: {
                text: '유선이용여부',
            },
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            header: {
                text: '적용시작일자',
            },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            header: {
                text: '적용종료일자',
            },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            header: {
                text: '처리자ID',
            },
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            header: {
                text: '처리자',
            },
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '처리일시',
            },
            editable: false,
            width: 200,
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            header: {
                text: '처리자ID',
            },
            editable: false,
        },
        {
            name: 'operDealcoCd',
            fieldName: 'operDealcoCd',
            header: {
                text: '정책운영사코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            header: {
                text: '관리대리점코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'ukeyOrgClCd',
            fieldName: 'ukeyOrgClCd',
            header: {
                text: 'UKEY대리점구분코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'ukeySubCd',
            fieldName: 'ukeySubCd',
            header: {
                text: 'UKEY서브점코드',
            },
            editable: false,
            visible: false,
        },
    ],
}

export const SKT_AGENCYS_HEADER = {
    fields: [
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeyOrgClCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            header: {
                text: 'SKT대리점코드',
            },
            editable: false,
            width: 100,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: {
                text: 'SKT대리점명',
            },
            editable: false,
            width: 200,
        },
        {
            name: 'ukeyOrgClCd',
            fieldName: 'ukeyOrgClCd',
            header: {
                text: 'SKT대리점구분코드',
            },
            editable: false,
            visible: false,
        },
    ],
}
