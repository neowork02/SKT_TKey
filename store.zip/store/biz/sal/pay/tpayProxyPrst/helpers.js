import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('sal.pay.tpayProxyPrstStore', Object.keys(state)),
    ...mapGetters('sal.pay.tpayProxyPrstStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('sal.pay.tpayProxyPrstStore', Object.keys(actions)),
    ...mapMutations('sal.pay.tpayProxyPrstStore', Object.keys(mutations)),
}
