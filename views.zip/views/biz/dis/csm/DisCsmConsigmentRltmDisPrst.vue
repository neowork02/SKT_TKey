<!-----------------------------------------------
 * 업무 그룹명 : 재고 수탁재고관리>수탁재고관리현황
 * 서브 업무명 : 수탁실시간재고현황
 * 설 명 : 수탁실시간재고현황을 조회한다.
 * 작 성 자 : P180182
 * 작 성 일 : 2022.05.31
 * Copyright ⓒ SK TELECOM. All Right Reserved
 ------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>수탁 실시간 재고 현황</h1>
        <!-- //Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left"></li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="iniBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <!-- //Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        labelName="기준일자"
                        :eRequired="true"
                        v-model="strdDt"
                        @change="onPrdChange"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.orgNm"
                        :codeVal.sync="reqParam.orgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :objAuth="objAuth"
                        @enterKey="onOrgTreeIconClick"
                        @appendIconClick="onOrgTreeIconClick"
                        @input="onOrgTreeInput"
                        :disabled="orgDisabled"
                        :disabledAfter="true"
                        :eRequired="true"
                    />
                    <BasBcoOrgTreesPopup
                        v-if="showBcoOrgTrees"
                        :parentParam="reqParam"
                        :rows="resultOrgTreeRows"
                        :dialogShow.sync="showBcoOrgTrees"
                        @confirm="onOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="영업담당"
                        :objAuth="this.objAuth"
                        v-model="reqParam.chrgrId"
                        :itemList="chrgrList"
                        itemText="chrgrNm"
                        itemValue="chrgrId"
                        :addBlankItem="true"
                        blankItemText="전체"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.hldDealcoNm"
                        :codeVal.sync="reqParam.hldDealcoCd"
                        labelName="보유처"
                        placeholder="입력해주세요"
                        :objAuth="objAuth"
                        @enterKey="onDealcoIconClick"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                        :disabled="dealcoDisabled"
                        :disabledAfter="true"
                    />
                    <BasBcoDealcosPopup
                        v-if="showBasBcoDealcos"
                        :parentParam="searchDealcosForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 1-4 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        :objAuth="this.objAuth"
                        v-model="reqParam.prodClCd"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="모델"
                        placeholder="입력해주세요"
                        @enterKey="onProdsIconClick"
                        @appendIconClick="onProdsIconClick"
                        @input="onProdsInput"
                        :objAuth="objAuth"
                        v-model="reqParam.prodNm"
                        :codeVal="reqParam.prodCd"
                        :disabledAfter="true"
                    >
                    </TCComInputSearchText>
                    <BasBcoProdsPopup
                        v-if="showProdPopup"
                        :dialogShow.sync="showProdPopup"
                        :parentParam="reqParam"
                        :rows="resultProdsRows"
                        @confirm="onProdsReturnData"
                    />
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="시연재고여부"
                        :objAuth="this.objAuth"
                        v-model="reqParam.demoYn"
                        :itemList="demoYnList"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-3 -->
                <!-- item 2-4 -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="개봉구분"
                        :objAuth="this.objAuth"
                        v-model="reqParam.openYn"
                        :itemList="openYnList"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-4 -->
            </div>
            <!-- //Search_line 2 -->
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{
                            ' btn_ty_exp_active ': active,
                        }"
                        @click="active = !active"
                    >
                    </v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="active">
                    <!-- Search_line 3 -->
                    <div class="searchform">
                        <!-- item 3-1 -->
                        <div class="formitem div4">
                            <TCComComboBox
                                codeId="ZDIS_C_00100"
                                labelName="재고상태"
                                :objAuth="this.objAuth"
                                v-model="reqParam.disStCd"
                                :addBlankItem="true"
                                :blankItemText="'전체'"
                            ></TCComComboBox>
                        </div>
                        <!-- //item 3-1 -->
                        <!-- item 3-2 -->
                        <div class="formitem div4">
                            <TCComComboBox
                                codeId="ZDIS_C_00520"
                                labelName="배송구분"
                                :objAuth="this.objAuth"
                                v-model="reqParam.dlvStCd"
                                :addBlankItem="true"
                                :blankItemText="'전체'"
                            ></TCComComboBox>
                        </div>
                        <!-- //item 3-2 -->
                        <!-- item 3-3 -->
                        <div class="formitem div4">
                            <TCComComboBox
                                codeId="ZDIS_C_00090"
                                labelName="불량여부"
                                :objAuth="this.objAuth"
                                v-model="reqParam.badYn"
                                :addBlankItem="true"
                                :blankItemText="'전체'"
                                :filterFunc="filterbadYnFunc"
                            ></TCComComboBox>
                        </div>
                        <!-- //item 3-3 -->
                        <!-- item 3-4 -->
                        <div class="formitem div4">
                            <TCComInput
                                v-model="reqParam.serNum"
                                labelName="일련번호"
                                :objAuth="this.objAuth"
                            ></TCComInput>
                        </div>
                        <!-- //item 3-4 -->
                    </div>
                    <!-- //Search_line 3 -->
                </div>
            </v-expand-transition>
        </div>
        <!-- //Search_div -->

        <!-- gridWrap -->
        <TCComTab
            :tab.sync="tabIndex"
            :items="items"
            :itemName="itemName"
            :objAuth="this.objAuth"
            sliderSize="8"
            :cKey="0"
            @click="onActiveTabClick"
        >
            <template #item1>
                <!-- Grid Default Sample -->
                <TCRealGridHeader
                    id="gridHeader1"
                    ref="gridHeader1"
                    :gridObj="gridObj1"
                    :isPageRows="true"
                    :isExceldown="true"
                    :isNextPage="true"
                    :isPageCnt="true"
                    class="notit"
                    @excelDownBtn="excelDownBtn"
                />
                <TCRealGrid
                    id="grid1"
                    ref="grid1"
                    :fields="gridHeader1.fields"
                    :columns="gridHeader1.columns"
                />
                <TCComPaging
                    :totalPage="gridData1.totalPage"
                    :apiFunc="getRltmDisPrstDtlList"
                    :gridObj="gridObj1"
                    :rowCnt="rowCnt1"
                    @input="chgRowCnt1"
                />
            </template>
            <template #item2>
                <!-- Grid Grouping Sample -->
                <TCRealGridHeader
                    id="gridHeader2"
                    ref="gridHeader2"
                    :gridObj="gridObj2"
                    :isPageRows="true"
                    :isExceldown="true"
                    :isNextPage="true"
                    :isPageCnt="true"
                    class="notit"
                    @excelDownBtn="excelDownBtn"
                />
                <TCRealGrid
                    id="grid2"
                    ref="grid2"
                    :fields="gridHeader2.fields"
                    :columns="gridHeader2.columns"
                    @hook:mounted="tabGridMounted"
                />
                <TCComPaging
                    :totalPage="gridData2.totalPage"
                    :apiFunc="getRltmDisPrstList"
                    :gridObj="gridObj2"
                    :rowCnt="rowCnt2"
                    @input="chgRowCnt2"
                />
            </template>
        </TCComTab>
        <!-- //gridWrap -->

        <!-- Popup -->
        <DtlPopup
            v-if="showDtlPopup"
            ref="popup"
            :dialogShow.sync="showDtlPopup"
            :parentParam="popupParam"
        />
        <!-- Popup -->
    </div>
</template>
<script>
import {
    DETAIL_GRID_HEADER,
    GRID_HEADER,
    DETAIL_GRID_LAYOUT,
    GRID_LAYOUT,
} from '@/const/grid/dis/csm/disCsmConsigmentRltmDisPrstHeader.js'
import DtlPopup from './DisCsmConsigmentRltmDisPrstDtlPopup'
import restApi from '@/api/biz/dis/csm/disCsmConsigmentRltmDisPrst.js'
import rltmDisPrstRestApi from '@/api/biz/dis/dsm/disDsmRltmDisPrst.js'
import attachedFileApi from '@/api/common/attachedFile'
import { CommonGrid, CommonUtil } from '@/utils'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'
//====================내부조직팝업(전체)팝업====================
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
import basBcoOrgTreesApi from '@/api/biz/bas/bco/basBcoOrgTrees'
//====================//내부조직팝업(전체)팝업====================
//====================내부거래처-권한조직====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================

export default {
    name: 'DisCsmConsigmentRltmDisPrst',
    mixins: [CommonMixin],
    components: {
        DtlPopup,
        BasBcoOrgTreesPopup,
        BasBcoDealcosPopup,
        BasBcoProdsPopup,
    },
    data() {
        return {
            gridHeader1: DETAIL_GRID_HEADER,
            gridHeader2: GRID_HEADER,
            gridData1: {},
            gridData2: {},
            gridObj1: {},
            gridObj2: {},
            gridHeaderObj1: {},
            gridHeaderObj2: {},
            tabIndex: 0,
            items: ['item1', 'item2'],
            itemName: ['일련번호 단위', '재고 현황'],
            indicatorOpt: { sort: 'ASC' },
            objAuth: {},
            active: false,
            rowCnt1: 15,
            rowCnt2: 15,
            searchForms: {},
            strdDt: '',
            chrgrList: [
                {
                    chrgrId: '',
                    chrgrNm: '',
                },
            ],
            openYnList: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: '개봉',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '미개봉',
                },
            ],
            demoYnList: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
            reqParam: {
                // 요청파라미터
                strdYm: '', // 기준년월
                staDt: '', // 시작일자
                strdDt: '', // 기준일자
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLvl: '', // 조직레벨
                chrgrId: '', // 담당자ID
                hldDealcoCd: '', // 보유처코드
                hldDealcoNm: '', // 보유처명
                prodClCd: '', // 상품구분코드
                disStCd: '', // 재고상태코드
                dlvStCd: '', // 배송상태코드
                openYn: '', // 개봉여부
                demoYn: '', // 시연여부
                badYn: '', // 불량여부
                serNum: '', // 일련번호
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
                allBrwsYn: '', // 전체조회여부
            },
            popupParam: {
                strdYm: '', // 기준년월
                staDt: '', // 시작일자
                strdDt: '', // 기준일자
                orgCd: '', // 조직코드
                orgLvl: '', // 조직레벨
                chrgrId: '', // 담당자ID
                hldDealcoCd: '', // 보유처코드
                prodClCd: '', // 상품구분코드
                disStCd: '', // 재고상태코드
                dlvStCd: '', // 배송상태코드
                openYn: '', // 개봉여부
                demoYn: '', // 시연여부
                badYn: '', // 불량여부
                serNum: '', // 일련번호
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
                colorCd: '', // 색상코드
                lvOrgCd: '', // 레벨0조직코드
                lvOrgCd1: '', // 레벨1조직코드
                lvOrgCd2: '', // 레벨2조직코드
                lvOrgCd3: '', // 레벨3조직코드
            },
            mountedYn: false,
            showDtlPopup: false,
            //====================내부조직팝업(전체)팝업관련====================
            orgDisabled: false,
            showBcoOrgTrees: false,
            resultOrgTreeRows: [],
            //====================//내부조직팝업(전체)팝업관련==================
            //====================내부거래처-권한조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchDealcosForm: {
                basDay: '', // 기준년월
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLvl: '', // 조직레벨
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '', // 거래처그룹
                dealcoClCd1: '', // 거래처구분
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================
            //====================상품팝업관련====================
            showProdPopup: false,
            resultProdsRows: [],
            //====================//상품팝업관련==================
        }
    },
    watch: {},
    computed: {},
    created() {
        this.gridData1 = this.gridSetData(this.rowCnt1)
        this.gridData2 = this.gridSetData(this.rowCnt2)
    },
    mounted() {
        this.gridObj1 = this.$refs.grid1
        this.gridHeaderObj1 = this.$refs.gridHeader1
        this.gridObj1.setGridState(true)
        this.gridObj1.gridView.setColumnLayout(DETAIL_GRID_LAYOUT)

        this.defaultSet()
    },
    methods: {
        // 화면 default 설정
        defaultSet() {
            // 최초 기준일자 포맷 설정
            this.strdDt = moment(new Date()).format('YYYY-MM-DD')

            // 기준일자에 따른 조회관련일자
            this.onPrdChange(this.strdDt)

            // 탭 기본값
            this.onActiveTabClick(0)

            this.reqParam.strdYm = moment(new Date())
                .add(-1, 'months')
                .format('YYYYMM') // 최근재고마감년월
            this.reqParam.staDt = moment(new Date()).format('YYYYMM01') // 시작일자
            this.reqParam.allBrwsYn = 'Y' // 전체조회여부

            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLvl'] = this.orgInfo['orgLvl']

                this.searchDealcosForm['orgCd'] = this.reqParam['orgCd']
                this.searchDealcosForm['orgNm'] = this.reqParam['orgNm']
                this.searchDealcosForm['orgLvl'] = this.reqParam['orgLvl']

                // 조직의 영업담당자 조회
                this.getSaleChrgrList()

                this.reqParam['hldDealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['hldDealcoNm'] = this.userInfo['dealcoNm']

                this.orgDisabled = true
                this.dealcoDisabled = true
            }
        },
        // Grid Init
        gridSetData(rowCnt) {
            // CommonGrid(현재페이지 번호, 총 페이지, Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(0, rowCnt, '', '')
        },
        // 페이지 표시 행의수 변경처리
        chgRowCnt1(val) {
            this.rowCnt1 = val
        },
        chgRowCnt2(val) {
            this.rowCnt2 = val
        },
        // 불량여부 필터
        filterbadYnFunc(items) {
            return items.filter(
                (item) => item['commCdVal'] == '01' || item['commCdVal'] == '02'
            )
        },
        //2번째 탭 클릭시 그리드 Mounted 후 실행
        //@hook:mounted
        tabGridMounted() {
            this.gridObj2 = this.$refs.grid2
            this.gridHeaderObj2 = this.$refs.gridHeader2
            this.gridObj2.setGridState(true)
            this.gridObj2.gridView.setColumnLayout(GRID_LAYOUT)
            this.gridObj2.gridView.onCellClicked = this.onCellClicked

            this.mountedYn = true
        },
        // 영업담당자 조회
        getSaleChrgrList() {
            this.chrgrList = []
            rltmDisPrstRestApi.getSaleChrgrList(this.reqParam).then((res) => {
                if (!_.isEmpty(res.gridList)) {
                    this.chrgrList = res.gridList
                } else {
                    this.chrgrList = [
                        {
                            chrgrId: '',
                            chrgrNm: '',
                        },
                    ]
                }
            })
        },
        // 초기화 버튼 이벤트
        iniBtn() {
            this.active = false

            this.gridData1 = this.gridSetData(this.rowCnt1)
            this.gridObj1.gridInit()
            this.gridHeaderObj1.setPageCount({ totalDataCnt: 0 })

            if (this.mountedYn) {
                this.gridData2 = this.gridSetData(this.rowCnt2)
                this.gridObj2.gridInit()
                this.gridHeaderObj2.setPageCount({ totalDataCnt: 0 })
            }

            CommonUtil.clearPage(this, 'reqParam')
            this.defaultSet()
        },
        // 조회 버튼 이벤트
        searchBtn() {
            this.reqParam.strdDt = this.strdDt.replaceAll('-', '') // 기준일자

            // validation 체크
            if (!this.isValidChk()) return false

            // 첫 조회시 표시할 행의 갯수
            this.searchForms = { ...this.reqParam }
            this.searchForms.pageNum = 1 // 첫번째 페이지

            if (this.tabIndex == 0) {
                this.searchForms.pageSize = this.rowCnt1
                this.gridData1.totalPage = 0
                this.getRltmDisPrstDtlList(this.searchForms.pageNum)
            } else {
                this.searchForms.pageSize = this.rowCnt2
                this.gridData2.totalPage = 0
                this.getRltmDisPrstList(this.searchForms.pageNum)
            }
        },
        // 수탁실시간재고현황 상세 조회
        getRltmDisPrstDtlList(page) {
            this.searchForms.pageNum = page

            restApi.getRltmDisPrstDtlList(this.searchForms).then((res) => {
                this.gridObj1.setRows(res.gridList)
                this.gridObj1.setGridIndicator(res.pagingDto, this.indicatorOpt) // 순번이 필요한경우 계산하는 함수
                this.gridData1 = this.gridSetData(this.rowCnt1) // 초기화
                this.gridData1.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj1.setPageCount(res.pagingDto) // Grid Row 가져올때 페이지정보 Setting
            })
        },
        // 수탁실시간재고현황 조회
        getRltmDisPrstList(page) {
            this.searchForms.pageNum = page

            restApi.getRltmDisPrstList(this.searchForms).then((res) => {
                this.gridObj2.setRows(res.gridList)
                this.gridObj2.setGridIndicator(res.pagingDto, this.indicatorOpt) // 순번이 필요한경우 계산하는 함수
                this.gridData2 = this.gridSetData(this.rowCnt2) // 초기화
                this.gridData2.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj2.setPageCount(res.pagingDto) // Grid Row 가져올때 페이지정보 Setting
            })
        },
        // Validation 체크
        isValidChk() {
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 입력해 주십시오.')
                return false
            }

            if (_.isEmpty(this.reqParam.strdDt)) {
                this.showTcComAlert('기준일자를 입력해 주십시오.')
                return false
            }

            if (this.reqParam.strdDt < '20151101') {
                this.showTcComAlert('2015년 11월 이전 조회는 할 수 없습니다.')
                return false
            }
            return true
        },
        // 기준일자 변경 이벤트
        onPrdChange(value) {
            const strdVal = value.replaceAll('-', '')
            this.reqParam.basMth = strdVal.substring(0, 6)
            this.searchDealcosForm.basDay = strdVal
        },
        // 탭 버튼 이벤트
        onActiveTabClick(tabIndex) {
            this.tabIndex = tabIndex
        },
        // Grid ExcelDown
        excelDownBtn() {
            let rowCount = 0

            if (this.tabIndex == 0) {
                rowCount = this.gridObj1.dataProvider.getRowCount()
            } else {
                rowCount = this.gridObj2.dataProvider.getRowCount()
            }

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            let url =
                this.tabIndex == 0
                    ? 'consigment-real-times-inventory-detail-excel-download'
                    : 'consigment-real-times-inventory-excel-download'

            attachedFileApi.downLoadFile(
                '/api/v1/backend-max/resource/dis/csm/' + url,
                this.reqParam
            )
        },
        // 그리드 선택 이벤트
        onCellClicked(grid, clickData) {
            // 그리드 선택 데이터
            if (clickData.dataRow == undefined) return

            this.popupParam = grid.getValues(clickData.itemIndex)
            this.popupParam.strdYm = this.reqParam.strdYm
            this.popupParam.staDt = this.reqParam.staDt
            this.popupParam.strdDt = this.reqParam.strdDt
            this.popupParam.orgCd = this.reqParam.orgCd
            this.popupParam.orgLvl = this.reqParam.orgLvl
            this.popupParam.disStCd = this.reqParam.disStCd
            this.popupParam.dlvStCd = this.reqParam.dlvStCd
            this.popupParam.openYn = this.reqParam.openYn
            this.popupParam.demoYn = this.reqParam.demoYn
            this.popupParam.badYn = this.reqParam.badYn
            this.popupParam.serNum = this.reqParam.serNum

            // 팝업열기
            this.showDtlPopup = true
        },
        //===================== 내부조직팝업(전체)팝업관련 methods ================================
        // 내부조직팝업(전체) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(전체) 팝업 오픈
        getOrgTreeList() {
            basBcoOrgTreesApi.getOrgTreeList(this.reqParam).then((res) => {
                // 검색된 내부조직팝업(전체) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(전체) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(전체) 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.orgCd = _.get(res[0], 'orgCd')
                    this.reqParam.orgNm = _.get(res[0], 'orgNm')
                    this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                } else {
                    this.resultOrgTreeRows = res
                    this.showBcoOrgTrees = true
                }
            })
        },
        // 내부조직팝업(전체) TextField 돋보기 Icon 이벤트 처리
        onOrgTreeIconClick() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이 아니면 내부조직팝업(전체) 정보 조회
            // 그 이외는 내부조직팝업(전체) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getOrgTreeList()
            } else {
                this.showBcoOrgTrees = true
            }
        },
        // 내부조직팝업(전체) TextField Input 이벤트 처리
        onOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(전체) 코드 초기화
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onOrgTreeReturnData(retrunData) {
            this.reqParam.orgCd = _.get(retrunData, 'orgCd')
            this.reqParam.orgNm = _.get(retrunData, 'orgNm')
            this.reqParam.orgLvl = _.get(retrunData, 'orgLvl')

            // 조직정보 변경 시 내부거래처 팝업 param 세팅
            this.searchDealcosForm.orgCd = this.reqParam.orgCd
            this.searchDealcosForm.orgNm = this.reqParam.orgNm
            this.searchDealcosForm.orgLvl = this.reqParam.orgLvl

            // 조직정보 변경 시 거래처 초기화
            this.reqParam.hldDealcoCd = this.userInfo['dealcoCd']
            this.reqParam.hldDealcoNm = this.userInfo['dealcoNm']

            // 조직의 영업담당자 조회
            this.getSaleChrgrList()
        },
        //===================== //내부조직팝업(전체)팝업관련 methods ================================
        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcosForm)
                .then((res) => {
                    // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.hldDealcoCd = _.get(res[0], 'dealcoCd')
                        this.reqParam.hldDealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultDealcoRows = res
                        this.showBasBcoDealcos = true
                    }
                })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하신 후 조회 하시기 바랍니다.')
                return
            }

            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.searchDealcosForm.dealcoCd = this.reqParam.hldDealcoCd
            this.searchDealcosForm.dealcoNm = this.reqParam.hldDealcoNm
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.hldDealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.reqParam.hldDealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            this.reqParam.hldDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.hldDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================
        //===================== 상품팝업관련 methods ================================
        // 상품 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 상품팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.reqParam).then((res) => {
                if (res.length === 1) {
                    this.reqParam.prodCd = _.get(res[0], 'prodCd')
                    this.reqParam.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.showProdPopup = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이 아니면 상품 정보 조회
            // 그 이외는 상품팝업 오픈
            if (!_.isEmpty(this.reqParam.prodNm)) {
                this.getProdsList()
            } else {
                this.showProdPopup = true
            }
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 상품팝업 코드 초기화
            this.reqParam.prodCd = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            this.reqParam.prodCd = _.get(retrunData, 'prodCd')
            this.reqParam.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
