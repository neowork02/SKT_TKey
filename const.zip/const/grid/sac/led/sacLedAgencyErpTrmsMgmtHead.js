import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 사용여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 대리점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 정산처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 서브코드(정산처코드)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmCd', // 전송구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmNm', // 전송구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqYn', // 요청
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqDtm', // 요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsYn', // 전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsYnNm', // 전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsDtm', // 전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsAmt', // 전송금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            width: '70',
            header: '대리점코드',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            header: '대리점명',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            width: '70',
            header: '서브점코드',
        },
        {
            name: 'trmsItmCd',
            fieldName: 'trmsItmCd',
            type: 'data',
            width: '70',
            header: '전송구분',
        },
        {
            name: 'trmsItmNm',
            fieldName: 'trmsItmNm',
            type: 'data',
            header: '전송구분명',
        },
        {
            name: 'trmsReqYn',
            fieldName: 'trmsReqYn',
            type: 'data',
            width: '70',
            header: '요청',
        },
        {
            name: 'trmsReqDtm',
            fieldName: 'trmsReqDtm',
            type: 'data',
            header: '요청일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'trmsYnNm',
            fieldName: 'trmsYnNm',
            type: 'data',
            width: '70',
            header: '전송여부',
        },
        {
            name: 'trmsDtm',
            fieldName: 'trmsDtm',
            type: 'data',
            header: '전송일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'trmsAmt',
            fieldName: 'trmsAmt',
            type: 'data',
            header: '금액',
            numberFormat: '#,##0',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            header: '비고',
        },
    ],
}
