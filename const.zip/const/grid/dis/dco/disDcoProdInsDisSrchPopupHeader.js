import { ValueType } from 'realgrid'

export const DisDcoProdInsDisSrchPopup_GRID_HEADER = {
    fields: [
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT, //제조사ID
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'disHldDay',
            dataType: ValueType.NUMBER, //보유일수
        },
        {
            fieldName: 'curCnt',
            dataType: ValueType.NUMBER, //현재고
        },
        {
            fieldName: 'movCnt',
            dataType: ValueType.NUMBER, //수량
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER, //단가
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'mdlClCd',
            dataType: ValueType.TEXT, //단말기구분코드
        },
        {
            fieldName: 'prchTyp',
            dataType: ValueType.TEXT, //구매유형코드
        },
        {
            fieldName: 'outQty',
            dataType: ValueType.NUMBER, //출고수량
        },
        {
            fieldName: 'outCl',
            dataType: ValueType.NUMBER, //출고구분
        },
        {
            fieldName: 'movSeq',
            dataType: ValueType.TEXT, //이동순번
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.NUMBER, //수정횟수
        },
        {
            fieldName: 'saleAmt',
            dataType: ValueType.NUMBER, //할인가격
        },
        {
            fieldName: 'fixUnitSalePrc',
            dataType: ValueType.NUMBER, //확정판매단가
        },
        {
            fieldName: 'fixCrdtPrchsPrc',
            dataType: ValueType.NUMBER, //확정여신매입가격
        },
        {
            fieldName: 'disAmt',
            dataType: ValueType.NUMBER, //재고가격
        },
        {
            fieldName: 'fdisAmt',
            dataType: ValueType.NUMBER, //재고가격
        },
        {
            fieldName: 'movChk',
            dataType: ValueType.TEXT, //이동체크
        },
        {
            fieldName: 'mdlClNm',
            dataType: ValueType.TEXT, //단말기구분명
        },
        {
            fieldName: 'regYn',
            dataType: ValueType.NUMBER, //등록여부
        },
    ],
    columns: [
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                lookupDisplay: true,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사ID',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: 150,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
            },
            header: {
                text: '불량여부',
            },
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
            },
            header: {
                text: '재고상태',
            },
        },
        {
            name: 'disHldDay',
            fieldName: 'disHldDay',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유일수',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'curCnt',
            fieldName: 'curCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현재고',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'movCnt',
            fieldName: 'movCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'mdlClCd',
            fieldName: 'mdlClCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'prchTyp',
            fieldName: 'prchTyp',
            type: 'data',
            visible: false,
        },
        {
            name: 'outQty',
            fieldName: 'outQty',
            type: 'data',
            visible: false,
        },
        {
            name: 'outCl',
            fieldName: 'outCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'movSeq',
            fieldName: 'movSeq',
            type: 'data',
            visible: false,
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            type: 'data',
            visible: false,
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            type: 'data',
            visible: false,
        },
        {
            name: 'fixUnitSalePrc',
            fieldName: 'fixUnitSalePrc',
            type: 'data',
            visible: false,
        },
        {
            name: 'fixCrdtPrchsPrc',
            fieldName: 'fixCrdtPrchsPrc',
            type: 'data',
            visible: false,
        },
        {
            name: 'disAmt',
            fieldName: 'disAmt',
            type: 'data',
            visible: false,
        },
        {
            name: 'fdisAmt',
            fieldName: 'fdisAmt',
            type: 'data',
            visible: false,
        },
        {
            name: 'movChk',
            fieldName: 'movChk',
            type: 'data',
            visible: false,
        },
        {
            name: 'mdlClNm',
            fieldName: 'mdlClNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'regYn',
            fieldName: 'regYn',
            visible: false,
            type: 'data',
        },
    ],
}
