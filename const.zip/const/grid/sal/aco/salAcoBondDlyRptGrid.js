/*****************************************
 * 업무그룹명: 일정산
 * 서브업무명: 도매일정산
 * 설명: 일정산-도매일정산-채권일보 Grid 헤더
 * 작성자: P179234
 * 작성일: 2022.08.24
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'clsDt',
            dataType: ValueType.TEXT, // 마감일자
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, //조직트리
        },
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT, // 사업담당코드
        },
        {
            fieldName: 'bizChrgOrgNm',
            dataType: ValueType.TEXT, // 사업담당명
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT, // 영업팀코드
        },
        {
            fieldName: 'teamOrgNm',
            dataType: ValueType.TEXT, // 영업팀명
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 영업파트코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 영업파트명
        },
        {
            fieldName: 'dealCoClNm1',
            dataType: ValueType.TEXT, // 거래처구분
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, // 정산처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, // 거래처
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, // 채널코드
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT, // 담당자명
        },
        {
            fieldName: 'dealEndDt',
            dataType: ValueType.TEXT, // 거래종료일
        },
        {
            fieldName: 'bfBondAmt',
            dataType: ValueType.NUMBER, // 전일채권잔액
        },
        {
            fieldName: 'tdayFeesAmt',
            dataType: ValueType.NUMBER, // SKT수납
        },
        {
            fieldName: 'tdayCashAmt',
            dataType: ValueType.NUMBER, // 현금매출
        },
        {
            fieldName: 'toFreeAmt',
            dataType: ValueType.NUMBER, // 공기기매출
        },
        {
            fieldName: 'toEtcmAmt',
            dataType: ValueType.NUMBER, // 기타수납
        },
        {
            fieldName: 'tdayTecoAmt',
            dataType: ValueType.NUMBER, // T에코환수
        },
        {
            fieldName: 'tdayDpstAmt',
            dataType: ValueType.NUMBER, // 본사송금
        },
        {
            fieldName: 'tdayRfndAmt',
            dataType: ValueType.NUMBER, // 오입금환불
        },
        {
            fieldName: 'tdayPpayAmt',
            dataType: ValueType.NUMBER, // 선급금
        },
        {
            fieldName: 'tdayRcvbAmt',
            dataType: ValueType.NUMBER, // 기타미수금
        },
        {
            fieldName: 'tdayPayblAmt',
            dataType: ValueType.NUMBER, // 발생
        },
        {
            fieldName: 'toExpsAmt',
            dataType: ValueType.NUMBER, // 지출
        },
        {
            fieldName: 'tdayBondBamt',
            dataType: ValueType.NUMBER, // 당일채권잔액
        },
    ],
    columns: [
        {
            name: 'clsDt',
            fieldName: 'clsDt',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '마감일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',

            styles: {
                textAlignment: 'center',
            },
            header: '매장코드',
        },
        {
            name: 'bizChrgOrgCd',
            fieldName: 'bizChrgOrgCd',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '사업담당',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'bizChrgOrgNm',
            fieldName: 'bizChrgOrgNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '사업담당',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'teamOrgCd',
            fieldName: 'teamOrgNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '영업팀',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'teamOrgNm',
            fieldName: 'teamOrgNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '영업팀',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '영업파트',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '영업파트',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'dealCoClNm1',
            fieldName: 'dealCoClNm1',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '거래처',
                showTooltip: false,
            },
            footer: {
                text: '계',
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '채널코드',
                showTooltip: false,
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '담당자명',
                showTooltip: false,
            },
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '거래종료일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'bfBondAmt',
            fieldName: 'bfBondAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '전일채권잔액',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayFeesAmt',
            fieldName: 'tdayFeesAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: 'SKT수납',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayCashAmt',
            fieldName: 'tdayCashAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '현금매출',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toFreeAmt',
            fieldName: 'toFreeAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '공기기매출',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toEtcmAmt',
            fieldName: 'toEtcmAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '기타수납',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayTecoAmt',
            fieldName: 'tdayTecoAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: 'T에코환수',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayDpstAmt',
            fieldName: 'tdayDpstAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '본사송금',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayRfndAmt',
            fieldName: 'tdayRfndAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '오입금환불',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayPpayAmt',
            fieldName: 'tdayPpayAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '선급금',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayRcvbAmt',
            fieldName: 'tdayRcvbAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '기타미수금',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayPayblAmt',
            fieldName: 'tdayPayblAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '발생',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toExpsAmt',
            fieldName: 'toExpsAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '지출',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayBondBamt',
            fieldName: 'tdayBondBamt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '당일채권잔액',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
    ],
    layout: [
        'clsDt',
        'treeOrgNm',
        'sktCd',
        'dealCoClNm1',
        'accDealcoCd',
        'agencyCd',
        'dealcoNm',
        'userNm',
        'dealEndDt',
        'bfBondAmt',
        {
            name: '당일채권증가',
            direction: 'horizontal',
            items: [
                'tdayFeesAmt',
                'tdayCashAmt',
                'toFreeAmt',
                'toEtcmAmt',
                'tdayTecoAmt',
            ],
        },
        'tdayDpstAmt',
        'tdayRfndAmt',
        'tdayPpayAmt',
        'tdayRcvbAmt',
        {
            name: '미지급금',
            direction: 'horizontal',
            items: ['tdayPayblAmt', 'toExpsAmt'],
        },
        'tdayBondBamt',
    ],
}
