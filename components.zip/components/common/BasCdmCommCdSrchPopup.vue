<!-----------------------------------------------
 * 업무그룹명: 기준정보>공통코드검색
 * 서브업무명: 기준정보>공통코드검색
 * 설명: 기준정보>공통코드검색 Popup 컴포넌트
 * 작성자: 이창석
 * 작성일: 2022.05.09
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpenCdmCommCdSrch" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">공통코드검색 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    v-model="searchCommCdSrchParam.condition"
                                    :itemList="conditionList"
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchCommCdSrchParam.value"
                                    labelName="검색값"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>

                            <div class="formitem div3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- // input -->
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">공통코드검색 목록</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="cdmCommCdSrchGrid"
                                ref="cdmCommCdSrchGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                                @hook:mounted="gridMounted"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
//import { CommonGrid, CommonUtil } from '@/utils'
import { CommonGrid } from '@/utils'
import { BAS_CDM_COMMCDSRCH_HEADER } from '@/const/grid/bas/cdm/basCdmCommCdSrchHeader'
import basCdmCommCdSrchApi from '@/api/biz/bas/cdm/basCdmCommCdSrch'
import CommonMixin from '@/mixins'
//import commonApi from '@/api/common/commonCode'
//import _ from 'lodash'

export default {
    name: 'BasCdmCommCdSrchPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: BAS_CDM_COMMCDSRCH_HEADER,
            conditionList: [
                {
                    commCdVal: '1',
                    commCdValNm: '공통코드ID',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '공통코드명',
                },
            ],
            headerText: '',
            searchCommCdSrchParam: {
                condition: '1',
                value: '', // 코드구분
            },
        }
    },
    computed: {
        activeOpenCdmCommCdSrch: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                //검색구분
                this.searchCommCdSrchParam.condition =
                    value['condition'] == undefined ? '1' : value['condition']
                //검색어
                this.searchCommCdSrchParam.value =
                    value['value'] == undefined ? '' : value['value']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },
    mounted() {
        this.gridObj = this.$refs.cdmCommCdSrchGrid // Grid Object 설정
        this.initGrid()
        this.getCommCdSrchList()

        //컬럼전체채우기
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
    },
    methods: {
        init() {
            this.gridData = this.gridSetData()
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            this.gridObj.setGridState(false, false, false)
            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        gridMounted() {
            console.log('gridMounted')
        },
        getCommCdSrchList() {
            /*
            this.searchCommCdSrchParam.value = CommonUtil.replaceDash(
                this.searchCommCdSrchParam.value
            )
            */
            basCdmCommCdSrchApi
                .getCommCdSrchList(this.searchCommCdSrchParam)
                .then((res) => {
                    console.log('getCommCdSrchList then : ', res)
                    this.gridObj.setRows(res)
                })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()

            if (current.dataRow === -1) {
                this.showTcComAlert('공통코드를 선택해주세요.', {
                    header: '공통코드 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )

            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenCdmCommCdSrch = false
        },

        onSearch() {
            this.getCommCdSrchList()
        },

        onEnterKey() {
            this.onSearch()
        },
    },
}
</script>
