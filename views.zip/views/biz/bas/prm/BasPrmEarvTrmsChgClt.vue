<template>
    <div class="content">
        <!-- Popup -->
        <div class="pt-5">
            <v-btn outlined class="btn_ty mr-2" @click="dialogClicked"
                ><span class="text_lower"
                    >전자결재 전송 변경&담보 갱신(popup)</span
                ></v-btn
            >

            <!-- popup -->
            <!-- <v-dialog max-width="1000px" scrollable v-model="dialog">
                <template v-slot:activator=""> </template>
            </v-dialog> -->
            <BasPrmEarvTrmsChgCltRenewalPopup
                v-if="localDialogShow === true"
                ref="popup"
                :dialogShow.sync="localDialogShow"
            />
            <!--//popup -->
        </div>
        <!-- //popup -->
    </div>
</template>

<script>
// import TCRealGrid from '@/components/TCRealGrid'
//import { SAMPLE_D_DATA } from '@/const/grid/sample/sampleGridData'
import { GRID_D_HEADER } from '@/const/grid/sample/sampleGrid'

import BasPrmEarvTrmsChgCltRenewalPopup from './BasPrmEarvTrmsChgCltRenewalPopup'
export default {
    name: 'Home',
    components: {
        BasPrmEarvTrmsChgCltRenewalPopup,
    },

    data() {
        return {
            localDialogShow: false,
            codeIDView: true,
            codeIDViewVal: '',
            dialog: false,
            value1: '',
            value2: '',
            list01: [],
            list02: [],
            view: GRID_D_HEADER,
            radio1: '1',
            radio2: '2',
            checked1: true,
            checked2: false,
            input: '',
            input11: '',
            input12: '',
            input13: '',
            input14: '',
            input15: '',
            input21: '',
            input22: '',
            input23: '',
            input24: '',
            input25: '',
            input26: '',
            input27: '',
            checkbox: true,

            radios: null,
            options: [
                {
                    value: 'Option1',
                    label: 'Option1',
                },
                {
                    value: 'Option2',
                    label: 'Option2',
                    disabled: true,
                },
                {
                    value: 'Option3',
                    label: 'Option3',
                },
                {
                    value: 'Option4',
                    label: 'Option4',
                },
                {
                    value: 'Option5',
                    label: 'Option5',
                },
            ],
            items: ['Option1', 'Option2', 'Option3', 'Option4'],
            value: '',
        }
    },
    mounted() {
        //this.$refs.grid1.setRows(SAMPLE_D_DATA)
    },
    methods: {
        //팝업열기
        dialogClicked: function () {
            this.localDialogShow = true
        },
    },
}
</script>
