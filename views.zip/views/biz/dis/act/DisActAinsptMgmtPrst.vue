<!-----------------------------------------------
 * 업무그룹명: 재고실사관리
 * 서브업무명: 재고실사관리현황
 * 설명: 재고실사현황을 조회한다.
 * 작성자: P179890
 * 작성일: 2022.07.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<!-- 
-->
<template>
    <div class="content">
        <!-- Tit -->
        <h1>재고실사관리현황</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="getDisActualMgmtList"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="기준일자"
                        :eRequired="true"
                        :calType="calType"
                        v-model="setDate"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        @enterKey="onAuthOrgTreeIconClick"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :objAuth="this.objAuth"
                        v-model="reqParam.orgNm"
                        :codeVal="reqParam.orgCd"
                        :disabledAfter="true"
                        :eRequired="true"
                        :disabled="searchDisable"
                    >
                    </TCComInputSearchText>
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="reqParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="보유처"
                        @enterKey="onDealcoIconClick"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                        :objAuth="this.objAuth"
                        v-model="reqParam.hldPlcNm"
                        :codeVal="reqParam.hldPlcId"
                        :disabledAfter="true"
                        :disabled="searchDisable"
                    >
                    </TCComInputSearchText>
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchDealcoParam"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 1-3 -->
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- //Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="재고실사현황내역"
                :gridObj="gridObj"
                :isExceldown="true"
                :isPageRows="true"
                @excelDownBtn="exportGridBtn"
            />
            <!-- // SubTit -->
            <!-- gridWrap -->
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
        </div>
        <DisActAinsptMgmtDtlPopup
            v-if="showAinsptMgmtDtlPopup === true"
            :dialogShow.sync="showAinsptMgmtDtlPopup"
            :params="dtlPopupParam"
        />
    </div>
</template>

<!--style scoped>
</style-->
<script>
import { DisActAinsptMgmtPrst_GRID_HEADER } from '@/const/grid/dis/act/disActAinsptMgmtPrstHeader.js'
import actApi from '@/api/biz/dis/act/disActAinsptMgmtPrst.js'
import attachedFileApi from '@/api/common/attachedFile'
import { CommonUtil, CommonMsg } from '@/utils'
import moment from 'moment'
import CommonMixin from '@/mixins'
import _ from 'lodash'
import DisActAinsptMgmtDtlPopup from '@/views/biz/dis/act/DisActAinsptMgmtDtlPopup'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================내부거래처(권한조직)====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'

export default {
    name: 'DisActAinsptMgmtPrst',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
        DisActAinsptMgmtDtlPopup,
    },
    data() {
        return {
            //====================조직 팝업====================
            authOrgParam: {},
            showBcoAuthOrgTrees: false,
            resultAuthOrgTreeRows: [],
            //====================조직 팝업====================
            //====================내부거래처(권한 조직))====================
            basBcoDealcoShow: false,
            searchDealcoParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY',
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC',
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한 조직)==================
            searchDisable: false,
            showAinsptMgmtDtlPopup: false,
            alertHeadTxt: '재고실사관리현황',
            alertBodyTxt: '',
            calType: 'DP',
            dtlPopupParam: {},
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            view: DisActAinsptMgmtPrst_GRID_HEADER,
            objAuth: {},
            searchForms: {},
            addProdPopParam: {},
            showAddProdPop: false,
            reqParam: {
                // 요청파라미터
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLevel: '', // 조직레벨
                orgCdLvl0: '', // 레벨0조직코드
                fromDt: '', // 기준시작일
                toDt: '', // 기준종료일
                hldPlcId: '', // 보유처코드
                hldPlcNm: '', // 보유처명
            },
            gridStyle: {
                height: '450px', //그리드 높이 조절
            },
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.fromDt, this.reqParam.toDt]
            },
            set(val) {
                this.reqParam.fromDt = val[0]
                this.reqParam.toDt = val[1]
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.reqParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchDealcoParam.basDay = CommonUtil.onlyNumber(
                    val[1]
                ).substr(0, 8)
                return val
            },
        },
    },
    watch: {},
    created() {},
    mounted() {
        // New T.key+ 보유
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked
        this.init()
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.fromDt = moment(new Date()).format('YYYY-MM-01') // 개봉지시일 from
            this.reqParam.toDt = moment(new Date()).format('YYYY-MM-DD') // 개봉지시일 to
            // 세션정보 set
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                // 출고처
                this.reqParam['hldPlcId'] = this.userInfo['dealcoCd']
                this.reqParam['hldPlcNm'] = this.userInfo['dealcoNm']
                // 조직
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLevel'] = this.orgInfo['orgLvl']
                this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']

                if (this.userInfo['attcClCd'] == '4') {
                    this.searchDisable = true
                }
            } else {
                this.searchDisable = false
            }
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
        },
        // Grid ExcelDown
        exportGridBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()
            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/act/disActualMgmtExcels',
                this.searchForms
            )
        },
        // 초기화 버튼 이벤트
        clearPage() {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.init()
        },
        onCellDblClicked(grid, clickData) {
            if (clickData?.dataRow >= 0) {
                const rowData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                // 재고실사관리상세 팝업 호출
                this.dtlPopupParam = {
                    strdDt: rowData['strdDt'],
                    hldPlcId: rowData['hldPlcId'],
                    hldPlcNm: rowData['hldPlcNm'],
                    orgCd: rowData['orgCd'],
                    orgNm: rowData['orgNm'],
                    orgLevel: rowData['orgLevel'],
                    orgCdLvl0: rowData['lvOrgCd'],
                }
                this.showAinsptMgmtDtlPopup = true
            }
        },
        isValidChk() {
            if (_.isEmpty(this.reqParam.fromDt)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '기준시작일'))
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.fromDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            if (_.isEmpty(this.reqParam.toDt)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '기준종료일'))
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.toDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            if (
                this.reqParam.fromDt.substr(0, 7) !==
                this.reqParam.toDt.substr(0, 7)
            ) {
                this.openAlert('시작일자와 종료일자을 동일한 월로 지정하세요.')
                return false
            }
            if (
                this.reqParam.fromDt.replaceAll('-', '') >
                this.reqParam.toDt.replaceAll('-', '')
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_01026')) // '조회시작일이 조회종료일보다 이전이어야 합니다.'
                return false
            }
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.openAlert(CommonMsg.getMessage('MSG_00121', '조직;조회')) // '조회시작일이 조회종료일보다 이전이어야 합니다.'
                return false
            }
            return true
        },
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        getDisActualMgmtList() {
            if (!this.isValidChk()) {
                return false
            }

            this.searchForms = { ...this.reqParam }
            this.searchForms.fromDt = CommonUtil.onlyNumber(
                this.searchForms.fromDt
            )
            this.searchForms.toDt = CommonUtil.onlyNumber(this.searchForms.toDt)
            actApi.getDisActualMgmtList(this.searchForms).then((res) => {
                // 재고실사현황
                this.gridObj.setRows(res.gridList)
                this.gridHeaderObj.setPageCount({
                    totalDataCnt: res.gridList.length,
                })
            })
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.authOrgParam)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLevel = _.get(res[0], 'orgLvl')
                        this.reqParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            this.authOrgParam['orgNm'] = this.reqParam['orgNm']
            this.authOrgParam['orgCd'] = this.reqParam['orgCd']
            this.authOrgParam['orgLvl'] = this.reqParam['orgLevel']
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            if (
                !_.isEmpty(this.reqParam.orgCd) &&
                this.reqParam.orgCd != retrunData.orgCd
            ) {
                this.reqParam.hldPlcId = ''
                this.reqParam.hldPlcNm = ''
            }
            this.reqParam.orgCd = _.get(retrunData, 'orgCd')
            this.reqParam.orgNm = _.get(retrunData, 'orgNm')
            this.reqParam.orgLevel = _.get(retrunData, 'orgLvl')
            this.reqParam.orgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.orgCd = ''
            this.reqParam.orgLevel = ''
            this.reqParam.orgCdLvl0 = ''
            this.reqParam.hldPlcId = ''
            this.reqParam.hldPlcNm = ''
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcoParam)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.reqParam.hldPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.hldPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return
            }
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.searchDealcoParam['orgCd'] = this.reqParam['orgCd']
            this.searchDealcoParam['orgNm'] = this.reqParam['orgNm']
            this.searchDealcoParam['orgLvl'] = this.reqParam['orgLevel']
            this.searchDealcoParam['dealcoCd'] = this.reqParam['hldPlcId']
            this.searchDealcoParam['dealcoNm'] = this.reqParam['hldPlcNm']
            if (!_.isEmpty(this.reqParam['hldPlcNm'])) {
                // 내부거래처조회
                this.getDealcosList()
            } else {
                // 팝업오픈
                this.basBcoDealcoShow = true
            }
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.reqParam.hldPlcId = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            this.reqParam.hldPlcId = _.get(returnData, 'dealcoCd')
            this.reqParam.hldPlcNm = _.get(returnData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================
    },
}
</script>
