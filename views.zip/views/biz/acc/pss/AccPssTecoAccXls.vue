<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1500px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">T에코폰 정산 파일 UPLOAD</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="downloadExcelSample"
                                >엑셀양식 다운로드</TCComButton
                            >
                        </li>
                        <li class="right">
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="init"
                                >초기화</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="search"
                                >조회</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onSave"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onDel"
                                >삭제</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onClose"
                                >닫기</TCComButton
                            >
                        </li>
                    </ul>
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div5">
                                <TCComDatePicker
                                    calType="M"
                                    v-model="searchParams.accYm_"
                                    labelName="정산월"
                                    :eRequired="true"
                                >
                                </TCComDatePicker>
                            </div>
                            <div class="formitem div2">
                                <TCComFileInput
                                    v-model="searchParams.files"
                                    labelName="파일선택"
                                    @change="onFilesChange"
                                    :eRequired="false"
                                ></TCComFileInput>
                            </div>
                            <!-- // input -->
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeader1"
                                ref="gridHeader1"
                                gridTitle="파일내역"
                                :isPageRows="true"
                                :gridObj="gridObj"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid1"
                                ref="grid1"
                                :editable="false"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>
                    <TCComPaging
                        :totalPage="gridData.totalPage"
                        :apiFunc="getTEcoExcelListByAccYm"
                        :rowCnt="rowCnt"
                        @input="chgRowCnt"
                    />
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
import moment from 'moment'
import attachApi from '@/api/common/attachedFile'
// import { prototype } from '@/views/prototype/js/prototype'
import CommonMixin from '@/mixins'
import { CommonGrid, CommonUtil } from '@/utils'
// import * as XLSX from 'xlsx'
import tecoApi from '@/api/biz/acc/pss/accPssTecoAccXls'
import { GRID_HEADER } from '@/const/grid/acc/pss/AccPssTecoAccXlsGrid'

export default {
    name: 'AccPssTecoAccXls',
    mixins: [CommonMixin],
    title: 'T에코폰 정산 파일 UPLOAD',
    props: {
        searchFormData: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list: [],
            gridData: this.gridSetData(this.rowcnt),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '350px', //그리드 높이 조절
            },

            searchForms: {},
            tecoAccXlsList: [],
            resultData: '',
            res: {},
            // forms: new prototype(),
            rowCnt: 15,
            // activePage: 1, // 현재페이지

            searchParams: {
                accYm_: moment(new Date()).format('YYYY-MM'), // 정산월
                srchAccYm: moment(new Date()).format('YYYY-MM'), // 정산월,
                accYm: moment(new Date()).format('YYYY-MM'), // 정산월,
                pageSize: '',
                pageNum: 1,
            },
            requiredGrid: {
                svcMgmtNum: '시리얼번호',
            },
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParamExcel: {
            handler: function () {
                // this.searchParams.accYm_ = value['srchAccYm']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        // this.init()
    },
    mounted() {
        console.log('mounted')

        // grid 기본세팅
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, false)
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: '번호',
        })
    },
    methods: {
        //엑셀 업로드 초기화 버튼 이벤트
        inintexcel() {
            this.resultData = ''
            this.list = []
            // this.gridObj.setRows(this.list)
        },
        //초기화 버튼 이벤트
        init: function () {
            this.initParam()
            this.resultData = ''
            this.list = []
            this.gridObj.setRows(this.list)
        },
        initParam() {
            this.searchParams = {
                accYm_: moment(new Date()).format('YYYY-MM'),
                accYm: moment(new Date()).format('YYYY-MM'),
                srchAccYm: moment(new Date()).format('YYYY-MM'),
            }
        },
        gridSetData: function (rowCnt) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, rowCnt, '', '')
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        //조회 - srchAccYm 정산월
        search() {
            // this.gridData.totalPage = 0 // 이전페이지정보 초기화
            // this.getPproductListList(this.forms.pageNum)
            const srchAccYm = this.searchParams.accYm_
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
                return false
            } else {
                this.searchForms = { ...this.searchParams }
                this.searchForms.pageSize = this.rowCnt
                this.searchForms.pageNum = 1 //첫번째 페이지
                this.searchForms.srchAccYm = CommonUtil.onlyNumber(
                    this.searchParams.accYm_
                )
                this.getTEcoExcelListByAccYm(this.searchForms.pageNum)
                console.log('전체리스트조회 ::::::: 시작')
            }
        },

        async getTEcoExcelListByAccYm(page) {
            this.searchForms.pageNum = page
            await tecoApi
                .getTEcoExcelListByAccYm(this.searchForms)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        this.forms = this.searchForms
                        console.log(res.gridList)
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator(res.pagingDto) //순번이 필요한경우 계산하는 함수
                        this.gridData = this.gridSetData() //초기화
                        this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                        //Grid Row 가져올때 총건수 Setting
                        this.gridHeaderObj.setPageCount(res.pagingDto)
                        this.inintexcel()
                        this.searchParams.files = ''
                        console.log(res.gridList)
                        console.log('전체리스트조회 ::::::: 끝')
                    }
                    if (res !== undefined && res.gridList.length == 0) {
                        this.showTcComAlert('조회된 데이터가 없습니다')
                    }
                })
        },

        //저장 - accYm 정산월
        async onSave() {
            const accYm = this.searchParams.accYm_
            console.log(accYm)
            if (_.isEmpty(accYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
                return false
            }
            if (_.isEmpty(this.list)) {
                this.showTcComAlert('저장대상을 확인하세요.')
                return false
            }
            const confirm = await this.showTcComConfirm(
                'Excel 자료 ' + this.list.length + '건을 UPLOAD 하시겠습니까?',
                {
                    header: '확인창',
                    size: '300',
                    confirmLabel: '확인',
                    cancelLabel: '취소',
                }
            )

            if (confirm) {
                this.searchForms = { ...this.searchParams }
                this.searchForms.accYm = CommonUtil.onlyNumber(
                    this.searchParams.accYm_
                )
                this.searchForms.tecoAccXlsList = []
                var rowCount = this.gridObj.dataProvider.getRowCount()
                if (rowCount > 0) {
                    for (var i = 0; i < rowCount; i++) {
                        this.searchForms.tecoAccXlsList.push(
                            this.gridObj.dataProvider.getOutputRow(
                                {
                                    datetimeFormat: 'yyyyMMdd',
                                },
                                i
                            )
                        )
                    }
                }
                return tecoApi
                    .addTEchoExcelList(this.searchForms)
                    .then((resultData) => {
                        if (resultData) {
                            console.log('resultData', resultData)
                            console.log(this.list.length + '저장 완료.')
                            this.showTcComAlert(
                                this.list.length + '건 저장 완료'
                            )
                            this.search()
                        }
                    })
                // .catch((err) => {
                //     this.showTcComAlert(
                //         'T에코금액이 총정산액2+차감+비용보전과 일치하지 않는 거래처가 있습니다.'
                //     )
                //     console.log(err)
                // })
            }
        },

        excelUploadFile(files) {
            if (!_.isUndefined(files) && !_.isNull(files)) {
                const formData = new FormData()
                formData.append('files', files)
                tecoApi.excelUpload(formData).then((res) => {
                    console.log('res', res)
                    this.callbackExcelUpload(res)
                })
            }
        },

        /**
         * 엑셀업로드 파일을 선택한 이후에 실행되는 callback 함수
         */
        callbackExcelUpload: function (list) {
            // validate체크하여 정상인 경우 list에 push한다.
            if (list) {
                for (var i = 0; i < list.length; i++) {
                    // 날짜 형태 text 로 변경
                    list[i].aplyDt = moment(list[i].aplyDt).format('YYYYMMDD')
                    list[i].cnslDt = moment(list[i].cnslDt).format('YYYYMMDD')
                    list[i].fieldJudeDt = moment(list[i].fieldJudeDt).format(
                        'YYYYMMDD'
                    )
                    list[i].chgDt = moment(list[i].chgDt).format('YYYYMMDD')
                    // list에 push한다.
                    this.list.push(list[i])
                    console.log('this.list', this.list)
                }
            }
            this.gridObj.dataProvider.fillJsonData(this.list, {})
        },

        //삭제 - accYm 정산월
        async onDel() {
            const accYm = this.searchParams.accYm_
            if (_.isEmpty(accYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
                return false
            }
            const confirm = await this.showTcComConfirm(
                '정산대상' +
                    this.searchParams.accYm_ +
                    '월의 업로드 자료를 삭제하시겠습니까?',
                {
                    header: '확인창',
                    size: '300',
                    confirmLabel: '확인',
                    cancelLabel: '취소',
                }
            )
            console.log('showTcComConfirm confirm: ', confirm)
            if (confirm) {
                this.searchForms = { ...this.searchParams }
                this.searchForms.accYm = CommonUtil.onlyNumber(
                    this.searchParams.accYm_
                )
                this.deleteTEchoExcelList()
            }
        },
        async deleteTEchoExcelList() {
            await tecoApi.deleteTEchoExcelList(this.searchForms).then((res) => {
                console.log(res)
                if (res) {
                    console.log(res)
                    // this.getTEcoExcelListByAccYm(this.searchForms)
                    this.showTcComAlert(
                        this.searchParams.accYm_ + '월 데이터 삭제 완료'
                    )
                    this.search()
                } else {
                    this.showTcComAlert('삭제 실패하였습니다.')
                }
            })
        },

        onClose: function () {
            const paramAccYm = this.searchParams.accYm_
            this.$emit('confirm', paramAccYm)
            this.activeOpenAgency = false
        },
        onFilesChange: function (files) {
            this.inintexcel()
            this.excelUploadFile(files)
        },

        downloadExcelSample() {
            attachApi.downloadSampleFile('424')
        },
    },
}
</script>
