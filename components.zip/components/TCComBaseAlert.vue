<!-----------------------------------------------
 * 업무그룹명: Alert 컴포넌트(Store)
 * 서브업무명: Alert 공통함수(Store)
 * 설명: Alert 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.05.13
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <v-dialog persistent :max-width="size" v-model="alertShow">
        <template v-slot:default>
            <div class="layerPop">
                <!-- Popup_tit -->
                <p class="popTitle noDraggable">
                    {{ header }}
                </p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont alert">
                    <!-- textbox -->
                    <div class="text-box">
                        <p v-html="alertMessage" />
                    </div>
                    <!-- //textbox -->
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose">
                        <!-- 닫기 -->
                    </a>
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
                <!-- Popup_BTN :하단 버튼 1개 -->
                <div class="popBtn">
                    <!-- <TCComButton
                        :Vuetify="false"
                        :labelName="confirmLabel"
                        class="btn_bottom full"
                        @click="onConfirm"
                    >
                    </TCComButton> -->
                    <button
                        ref="alertBtn"
                        type="button"
                        class="btn_bottom full"
                        @click="onConfirm"
                    >
                        <span>{{ confirmLabel }}</span>
                    </button>
                </div>
                <!-- //Popup_BTN  :하단 버튼 1개-->
            </div>
        </template>
    </v-dialog>
</template>

<script>
import _ from 'lodash'
export default {
    inheritAttrs: false,
    name: 'TCComBaseAlert',
    components: {},
    props: {},

    data() {
        return {}
    },
    computed: {
        size() {
            let res = '360'
            const size = _.get(this.$store.getters['tcComAlertOptions'], 'size')
            if (!_.isEmpty(size)) {
                res = size + 'px'
            }
            return res
        },
        alertMessage() {
            return this.$store.getters['tcComAlertMessage']
        },
        getAlertOptions() {
            return this.$store.getters['tcComAlertOptions']
        },
        alertShow() {
            this.$nextTick(() => {
                if (this.$store.getters['tcComAlertShow'] === true) {
                    this.$refs.alertBtn.focus()
                }
            })
            return this.$store.getters['tcComAlertShow']
        },
        header() {
            let header = _.get(this.getAlertOptions, 'header')
            if (_.isEmpty(header)) {
                header = '알림'
            }
            return header
        },
        confirmLabel() {
            let confirmLabel = _.get(this.getAlertOptions, 'confirmLabel')
            if (_.isEmpty(confirmLabel)) {
                confirmLabel = '확인'
            }
            return confirmLabel
        },
    },
    // props 동적 제어
    watch: {},
    created() {},
    mounted() {},
    methods: {
        onClose() {
            this.$store.dispatch('closeTcComAlert')
        },
        onConfirm() {
            this.$store.dispatch('closeTcComAlert')
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
