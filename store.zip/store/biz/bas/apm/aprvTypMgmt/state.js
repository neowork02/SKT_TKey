export default {
    //alert message
    alertShow: false,
    alertHeaderText: '',
    alertBodyText: '',
    loadingShow: false,
    snackbar: false,
    snackbarText: '',
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 30,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 30, //전체 조회:9999
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    saveAction: false,
    saveDoneA: false,
    saveDoneB: false,

    commDropDown: {},

    commCdIds: [],
    resultList: [],
    resultListCopy: [],

    searchParams: {},
}
