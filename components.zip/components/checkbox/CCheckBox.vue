<script>
export default {
    name: 'CCheckBox',

    model: {
        prop: 'isChecked',
    },

    props: {
        isChecked: { type: Boolean },
        label: { type: String, default: '' },
        width: { type: String, default: '20' },
        height: { type: String, default: '20' },
        fontSize: { type: String, default: '13' },
        fontColor: { type: String, default: '#444' },
        align: { type: String, default: 'center' },
    },

    data: () => ({
        selected: false,
    }),

    watch: {
        isChecked() {
            this.selected = this.isChecked
        },
    },

    mounted() {
        this.selected = this.isChecked
    },

    computed: {
        computedCheckboxImage() {
            if (this.isChecked)
                return this.$store.getters['global/imgUrlPrefix'] + 'chk_on.png'
            else
                return (
                    this.$store.getters['global/imgUrlPrefix'] + 'chk_off.png'
                )
        },
        computedLabelStyle() {
            return {
                'font-size': this.fontSize + 'px',
                color: this.fontColor,
            }
        },
    },

    methods: {
        click() {
            this.selected = !this.selected
            this.$emit('input', this.selected)
            this.$emit('click')
        },
    },
}
</script>

<template>
    <div>
        <v-row no-gutters :justify="align">
            <div class="justify-center">
                <v-img
                    class="c-checkbox-main"
                    :src="computedCheckboxImage"
                    @click="click"
                />
            </div>
            <div
                class="ml-2 c-checkbox-label"
                v-if="label !== ''"
                :style="computedLabelStyle"
                @click="click"
            >
                {{ label }}
            </div>
        </v-row>
    </div>
</template>

<style>
.c-checkbox-main .v-image__image,
.c-checkbox-main {
    cursor: pointer;
    min-width: 20px !important;
    max-width: 20px !important;
    min-height: 20px !important;
    max-height: 20px !important;
}
.c-checkbox-label {
    cursor: pointer;
    padding-top: 2px;
    max-width: 100%;
}
</style>
