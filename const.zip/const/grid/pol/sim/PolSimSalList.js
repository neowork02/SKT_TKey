import { ValueType } from 'realgrid'

export const GRID_SAL_INFO = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'calAmt',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            width: '100',
            header: {
                text: '판매번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'gnrlSaleChgSeq',
            fieldName: 'gnrlSaleChgSeq',
            type: 'data',
            width: '80',
            header: {
                text: '변경순번',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'svcDtm',
            fieldName: 'svcDtm',
            type: 'data',
            width: '120',
            header: {
                text: '개통일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            width: '120',
            header: {
                text: '매출일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            width: '100',
            header: {
                text: '판매변경일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'saleStNm',
            fieldName: 'saleStNm',
            type: 'data',
            width: '100',
            header: {
                text: '판매상태',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'svcTypNm',
            fieldName: 'svcTypNm',
            type: 'data',
            width: '120',
            header: {
                text: '개통유형',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'calAmt',
            fieldName: 'calAmt',
            type: 'data',
            width: '130',
            header: {
                text: '산출금액',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
            styleName: 'right-column',
            editable: false,
        },
    ],
}
