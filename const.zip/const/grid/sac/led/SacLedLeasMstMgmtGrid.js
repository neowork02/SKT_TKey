'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil, filter } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: 'fixYn',
        editable: false,
        header: { text: '확정여부' },
        type: 'data',
        dataType: ValueType.TEXT,
        displayCallback: filter.grid.fixYn,
    },
    {
        fieldName: 'dealCoCl1Grp',
        editable: false,
        header: { text: '거래처그룹' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'dealcoCl1Nm',
        editable: false,
        header: { text: '거래처구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'dealcoCd',
        editable: false,
        header: { text: '정산처코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'dealcoNm',
        editable: false,
        header: { text: '정산처명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    // {
    //     fieldName: 'orgId2Nm',
    //     editable: false,
    //     header: { text: '사업담당' },
    //     type: 'data',
    //     dataType: ValueType.TEXT,
    // },
    // {
    //     fieldName: 'orgId3Nm',
    //     editable: false,
    //     header: { text: '사업팀' },
    //     type: 'data',
    //     dataType: ValueType.TEXT,
    // },
    // {
    //     fieldName: 'newOrgNm',
    //     editable: false,
    //     header: { text: '영업PT' },
    //     type: 'data',
    //     dataType: ValueType.TEXT,
    // },
    {
        fieldName: 'orgTree',
        editable: false,
        header: { text: '조직' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'sktAgencyCd',
        editable: false,
        header: { text: 'U.KEY대리점' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'sktSubCd',
        editable: false,
        header: { text: 'U.KEY서브점' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ccCd',
        editable: true,
        header: {
            text: 'CC코드',
            styleName: 'editable',
        },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'subleStDt',
        editable: true,
        editor: { type: 'date' },
        header: { text: '전대차 계약시작일', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'subleEdDt',
        editable: true,
        editor: { type: 'date' },
        header: { text: '전대차 계약종료일', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'grtAmt',
        editable: true,
        header: { text: '전대차 보증금', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'erpSubleGrt',
        editable: false,
        header: { text: '임차마스터 전대차 보증금' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'grtAgrmtYn',
        editable: false,
        header: { text: '보증금 일치여부' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'grtAnnuRt',
        editable: false,
        header: { text: '보증금 연리(%)' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'grtAnnuAmt',
        editable: false,
        header: { text: '보증금 연리(월)' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'grtAnnuUpdAmt',
        editable: true,
        header: { text: '보증금 연리(월) 보정액', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'shopGrtIntAmt',
        editable: false,
        header: { text: '매장보증금 월이자(정산)' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'ppsCmmsPayRt',
        editable: true,
        header: { text: 'PPS수수료 지급률', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'newMgtPayRt',
        editable: true,
        header: { text: '신규관리수수료 지급률', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'chgMgtPayRt',
        editable: true,
        header: { text: '기변관리수수료 지급률', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'opCmmsPayRt',
        editable: true,
        header: { text: '업무처리수수료지급률', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'wireMgtPayRt',
        editable: true,
        header: { text: '유선 관리수수료 지급률', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'wireCollPayRt',
        editable: true,
        header: { text: '유선 모집수수료 지급률', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'wrwlCombPayRt',
        editable: true,
        header: { text: '유무선 결합수수료 지급률', styleName: 'editable' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'clsYm',
        header: { text: '정산월(숨김)' },
        visible: false,
    },
    {
        fieldName: 'accDealcoCd',
        header: { text: '정산처(숨김)' },
        visible: false,
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {
    orgLevel: null,
    orgCd: null,
    searchCoClOrgCd: null,
    mskMonth: null,
    dealCoCl1: '',
    dealCoNm: null,
    dealCoCd: null,
    subCode: null,
    yymm: null,
    trmsItem: null,
    trmsYn: null,
    budat: null,
    leasMstMgmtVoList: null,
    mthLedListByDealVoList: null,
    resultGridDto: {
        gridList: [
            {
                fixYn: '',
                dealCoCl1Grp: '그룹',
                subleStDt: '2021-10-10',
                subleEdDt: '2021-10-10',
                subleGrt: '10202020',
            },
            {
                fixYn: '',
                dealCoCl1Grp: '그룹',
                subleStDt: '2021-10-10',
                subleEdDt: '2021-10-10',
                subleGrt: '10202020',
            },
            {
                fixYn: 'N',
                dealCoCl1Grp: 'FIX가 N',
                subleStDt: '2021-10-10',
                subleEdDt: '2021-10-10',
                subleGrt: '10202020',
            },
            {
                fixYn: 'N',
                dealCoCl1Grp: 'FIX가 N',
                subleStDt: '2021-10-10',
                subleEdDt: '2021-10-10',
                subleGrt: '10202020',
            },
            {
                fixYn: 'Y',
                dealCoCl1Grp: '그룹',
                subleStDt: '2021-10-10',
                subleEdDt: '2021-10-10',
                subleGrt: '10202020',
            },
            {
                fixYn: '',
                dealCoCl1Grp: '그룹',
                subleStDt: '2021-10-10',
                subleEdDt: '2021-10-10',
                subleGrt: '10202020',
            },
        ],
        pagingDto: {
            pageSize: 15,
            pageNum: 1,
            totalPageCnt: 31,
            totalDataCnt: 310,
        },
    },
    dcode: null,
}

export { GRID_HEADER, MOCK_DATA }
