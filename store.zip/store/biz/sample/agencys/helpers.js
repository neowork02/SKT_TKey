import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('sample.agencysStore', Object.keys(state)),
    ...mapGetters('sample.agencysStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('sample.agencysStore', Object.keys(actions)),
    ...mapMutations('sample.agencysStore', Object.keys(mutations)),
}
