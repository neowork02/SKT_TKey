<!-----------------------------------------------
 * 업무그룹명: Input 컴포넌트
 * 서브업무명: Input 컴포넌트
 * 설명: Input 컴포넌트및 공통함수 
 * 작성자: 최고운
 * 작성일: 2022.04.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <v-text-field
        ref="tcComTextField"
        v-model="dValue"
        v-maska="masking"
        outlined
        dense
        :type="type === 'password' ? 'password' : 'text'"
        :size="size"
        :maxlength="maxlength"
        :style="cSize"
        :placeholder="placeholder"
        :readonly="readonly"
        :disabled="disabled"
        :rules="cInputRuleInfo"
        :single-line="singleLine"
        :suffix="suffix"
        :prefix="prefix"
        :autofocus="autofocus"
        :clearable="clearable"
        :class="eClass"
        @input="emitInput"
        @click="emitClick"
        @change="emitChange"
        @blur="emitBlur"
        @focus="emitFocus"
        @keydown="emitKeyDown"
        @keydown.enter="emitKeyDownEnter"
        @keyup.enter="emitKeyUpEnter"
        @mousedown="emitMouseDown"
        @click:clear="emitClearClick"
        :reverse="textReverse"
    >
        <template v-slot:append>
            <slot name="append"> </slot>
        </template>
    </v-text-field>
</template>
<style lang="scss" scoped>
// scss source
</style>
<script>
import { maska } from 'maska'
import _ from 'lodash'

export default {
    directives: {
        maska,
    },
    inheritAttrs: false,
    name: 'TCComTextField',
    components: {},
    props: {
        // 입력값,양방향 바인딩
        value: { type: [String, Number], default: '', required: false },
        // Type
        type: { type: String, default: 'text', required: false },
        // 넓이
        size: { type: Number, default: null, required: false },
        // 입력값 허용 길이
        maxlength: { type: Number, default: null, required: false },
        // 입력형식 유형
        inputRuleType: { type: String, default: '', required: false },
        // placeholder 제어
        placeholder: { type: String, default: '', required: false },
        // 접미사 텍스트 표시
        suffix: { type: String, default: '', required: false },
        // 접두사 텍스트 표시
        prefix: { type: String, default: '', required: false },
        // Enables autofocus
        autofocus: { type: Boolean, default: false, required: false },
        // 입력 지우기 기능 추가
        clearable: { type: Boolean, default: false, required: false },
        // mask 기능
        mask: { type: [String, Array], default: '', required: false },
        //필수입력여부
        eRequired: { type: Boolean, default: false, required: false },
        //readonly
        readonly: { type: Boolean, default: false, required: false },
        //disabled
        disabled: { type: Boolean, default: false, required: false },
        // auth
        objAuth: { type: Object, default: () => {}, required: false },
        // single-line
        singleLine: { type: Boolean, default: false, required: false },
        // 콤마 포맷
        commaFormat: { type: Boolean, default: false, required: false },
        // Rate 포맷
        rateFormat: { type: Boolean, default: false, required: false },
        // 포맷설정 TEL / BIZ...
        formatType: { type: String, default: '', required: false },
        // Style Class
        eClass: { type: String, default: '', required: false },
        //text align right 여부
        textReverse: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            dValue: '',
            dInputRuleType: '',
            // 전체 입력 허용
            dRuleInfoDefault: [
                () => {
                    // 전체허용
                    return true
                },
            ],
            // 영어&숫자만 입력 허용
            dRuleInfoEN: [
                (v) => {
                    let res = false
                    // 영문&숫자 허용
                    if (/^[a-zA-Z0-9]*$/.test(v) == true) {
                        res = true
                    } else {
                        // console.log('user_id_rule-', this.dValue)
                        const regExp = /[^0-9a-zA-Z]/g
                        this.dValue = this.dValue.replace(regExp, '')
                    }
                    return res
                },
            ],
            // 영어(대문자)&숫자만 입력 허용
            dRuleInfoUpperEN: [
                (v) => {
                    let res = false
                    // 영문&숫자 허용
                    if (/^[A-Z0-9]*$/.test(v) == true) {
                        res = true
                    } else {
                        // console.log('user_id_rule-', this.dValue)
                        const regExp = /[^0-9A-Z]/g
                        this.dValue = this.dValue.replace(regExp, '')
                    }
                    return res
                },
            ],
            // 한글만 입력 허용
            dRuleInfoH: [
                (v) => {
                    let res = false
                    if (/^[ㄱ-ㅎ|가-힣]*$/.test(v) == true) {
                        res = true
                    } else {
                        const regExp = /[^ㄱ-ㅎ|가-힣]/g
                        this.dValue = this.dValue.replace(regExp, '')
                    }
                    return res
                },
            ],
            // 숫자만 입력 허용
            dRuleInfoN: [
                (v) => {
                    let res = false
                    if (/^[0-9]*$/.test(v) == true) {
                        res = true
                    } else {
                        const regExp = /[^0-9]/g
                        this.dValue = this.dValue.replace(regExp, '')
                    }
                    return res
                },
            ],
        }
    },
    computed: {
        cInputRuleInfo() {
            let res = this.dRuleInfoDefault
            if (this.dInputRuleType == 'EN') {
                res = this.dRuleInfoEN
            } else if (this.dInputRuleType == 'H') {
                res = this.dRuleInfoH
            } else if (this.dInputRuleType == 'N') {
                res = this.dRuleInfoN
            } else if (this.dInputRuleType == 'UPEN') {
                res = this.dRuleInfoUpperEN
            }
            return res
        },
        cSize() {
            let res = 'width:auto;'
            if (!_.isEmpty(this.size)) {
                res = 'width:' + this.dSize + '%;'
            }
            return res
        },
        masking() {
            if (!_.isEmpty(this.mask)) {
                return {
                    mask: this.mask.toString(),
                    tokens: { H: { pattern: /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/ } },
                }
            }
            return ''
        },
    },
    // props 동적 제어
    watch: {
        value: function () {
            this.dValue = this.commaFormat
                ? this.setComma(this.value)
                : this.rateFormat
                ? Number(this.value).toFixed(2)
                : this.formatType
                ? this.setHyphen(this.value)
                : this.value
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.dValue = this.commaFormat
                ? this.setComma(this.value)
                : this.rateFormat
                ? Number(this.value).toFixed(2)
                : this.formatType
                ? this.setHyphen(this.value)
                : this.value

            this.dInputRuleType = this.inputRuleType
        },
        setHyphen(v) {
            let hyphenVal = v
            if (this.formatType == 'TEL') {
                hyphenVal = String(v)
                    .replace(/[^0-9]/g, '')
                    .replace(
                        /^(0[2-8][0-5]?|01[01346-9])-?([1-9]{1}[0-9]{2,3})-?([0-9]{4})$/,
                        `$1-$2-$3`
                    )
            } else if (this.formatType == 'BIZ') {
                hyphenVal = String(v)
                    .replace(/[^0-9]/g, '')
                    .replace(/([0-9]{3})-?([0-9]{2})-?([0-9]{5})/, `$1-$2-$3`)
            }
            return hyphenVal
        },
        setComma(v) {
            return String(v)
                .replace(/,/gi, '')
                .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        },
        removeComma(v) {
            return String(v).replace(/,/gi, '')
        },
        inputFocus() {
            this.$refs.tcComTextField.focus()
        },
        emitInput(value) {
            this.$emit(
                'input',
                this.commaFormat || this.formatType
                    ? this.removeComma(value)
                    : value
            )
        },
        emitClick(ev) {
            this.$emit('click', ev)
        },
        emitChange(value) {
            this.emitInput(value)
            this.$emit('change', value)
        },
        emitBlur(ev) {
            this.$emit('blur', ev)
        },
        emitFocus(ev) {
            ev.target.select() //focus이벤트가 발생할때마다 전체선택
            this.$emit('focus', ev)
        },
        emitKeyDown(ev) {
            if (this.type === 'number') {
                const code = ev.keyCode
                if ((code < 48 || code > 57) && (code < 96 || code > 105)) {
                    if (
                        code !== 110 &&
                        code !== 190 &&
                        code !== 9 &&
                        code !== 36 &&
                        code !== 35 &&
                        code !== 37 &&
                        code !== 39 &&
                        code !== 8 &&
                        code !== 46 &&
                        !ev.ctrlKey &&
                        !ev.altKey
                    ) {
                        // 기본 이벤트의 자동 실행을 중단 시킴
                        ev.preventDefault()
                    }
                }
            }
            this.$emit('key-down', ev)
        },
        emitKeyDownEnter(ev) {
            ev.preventDefault()
            this.$emit('enterKey', ev)
        },
        emitKeyUpEnter(ev) {
            ev.preventDefault()
            this.$emit('enterKeyUp', ev)
        },
        emitMouseDown(ev) {
            this.$emit('mouse-down', ev)
        },
        emitClearClick(ev) {
            this.$emit('clear-click', ev)
        },
    },
}
</script>
