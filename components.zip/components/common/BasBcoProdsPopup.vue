<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">상품팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    codeId="ZBAS_C_00010"
                                    labelName="상품구분"
                                    :objAuth="objAuth"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    v-model="searchProdForm.prodClCd"
                                    :disabled="isDisabledProdClCd"
                                ></TCComComboBox>
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 
                            <div class="formitem div3">
                                <TCComComboBox
                                    :itemList="codeYn"
                                    itemText="codeVal"
                                    itemValue="codeId"
                                    labelName="SKT운영여부"
                                    :objAuth="objAuth"
                                    v-model="searchProdForm.sktOperYn"
                                ></TCComComboBox>
                            </div>
                            -->
                            <!-- // item 1-2 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    :itemList="codeYn"
                                    itemText="codeVal"
                                    itemValue="codeId"
                                    labelName="사용여부"
                                    :objAuth="objAuth"
                                    v-model="searchProdForm.useYn"
                                ></TCComComboBox>
                            </div>
                            <!-- // item 1-2 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComCheckBox
                                    labelName="대표모델여부"
                                    :objAuth="objAuth"
                                    :itemList="chkData"
                                    v-model="ckParam.repProdYn"
                                ></TCComCheckBox>
                            </div>
                            <!-- // item 1-2 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchProdForm.prodCd"
                                    labelName="모델코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchProdForm.prodNm"
                                    labelName="모델명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 2-2 -->
                            <!-- item 2-3 
                            <div class="formitem div3"></div>
                            -->
                            <!-- //item 2-3 -->
                            <!-- item 2-4 -->
                            <div class="formitem div3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="prodsGridHeader"
                            ref="prodsGridHeader"
                            :gridObj="gridObj"
                        />
                        <TCRealGrid
                            id="prodsGrid"
                            ref="prodsGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { basBcoProdsHeader } from '@/const/grid/bas/bco/basBcoProdsHeader'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
import commonApi from '@/api/common/commonCode'
import CommonMixin from '@/mixins'
import _ from 'lodash'
export default {
    name: 'BasBcoProdsPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: this.gridSetData(),
            headerText: '',
            objAuth: {},
            view: basBcoProdsHeader,
            codeYn: [
                {
                    codeId: '',
                    codeVal: '전체',
                },
                {
                    codeId: 'Y',
                    codeVal: 'Y',
                },
                {
                    codeId: 'N',
                    codeVal: 'N',
                },
            ],
            chkData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '',
                },
            ],
            content: '',
            gridObj: {},
            gridHeaderObj: {},
            searchProdForm: {
                prodClCd: '', // 상품구분
                sktOperYn: '', // SKT운영여부
                useYn: '', // 사용여부
                prodCd: '', // 모델코드
                prodNm: '', // 모델명
                sktAgencyYn: '', //대리점별운영상품관리테이블사용여부
                repProdYn: '', //대표모델여부
            },
            ckParam: {
                repProdYn: [], //대표모델여부
            },
            isDisabledProdClCd: false,
        }
    },

    async mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.prodsGrid
        this.gridHeaderObj = this.$refs.prodsGridHeader
        this.initGrid()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchProdForm.prodCd =
                    value['prodCd'] == undefined ? '' : value['prodCd'] //모델코드
                this.searchProdForm.prodNm =
                    value['prodNm'] == undefined ? '' : value['prodNm'] //모델명
                this.searchProdForm.prodClCd =
                    value['prodClCd'] == undefined ? '' : value['prodClCd'] //상품구분
                this.searchProdForm.sktOperYn =
                    value['sktOperYn'] == undefined ? '' : value['sktOperYn'] //skt운영여부
                this.searchProdForm.useYn =
                    value['useYn'] == undefined ? '' : value['useYn'] //사용여부
                this.searchProdForm.sktAgencyYn =
                    value['sktAgencyYn'] == undefined
                        ? ''
                        : value['sktAgencyYn'] //대리점별운영상품관리테이블사용여부

                if (
                    ('' != value['repProdYn']) == undefined
                        ? ''
                        : value['repProdYn']
                ) {
                    this.ckParam.repProdYn = [
                        value['repProdYn'] == undefined
                            ? ''
                            : value['repProdYn'],
                    ] //대표모델여부
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        //GridSetData
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        init() {
            if (
                this.searchProdForm.prodNm.length > 0 &&
                this.rows.length == 0
            ) {
                this.onSearch()
            }

            // 선처리 자동조회에서 조건 데이타 구성
            //alert('this.rows.length:' + this.rows.length)
            if (this.rows.length > 0) {
                /*                
                alert(
                    '(!_.isEmpty(this.searchProdForm.prodClCd):' +
                        !_.isEmpty(this.searchProdForm.prodClCd)
                )
*/
                if (!_.isEmpty(this.searchProdForm.prodClCd)) {
                    this.isDisabledProdClCd = true
                } else {
                    this.isDisabledProdClCd = false
                    this.searchProdForm.prodClCd = ''
                }
            }
        },
        async initGrid() {
            this.gridObj.setGridState(false, false, false)
            const commProdClCdList = await this.getCommCodeList('ZBAS_C_00010') // 상품구분
            const commEqpClCdList = await this.getCommCodeList('ZBAS_C_00500') // 단말기구붐
            const commProdChrticCd1List = await this.getCommCodeList(
                'ZBAS_C_00020'
            ) // 상품특성1(할부지원 단말기 구분)
            const commProdChrticCd2List = await this.getCommCodeList(
                'ZBAS_C_00030'
            ) // 상품특성2(단말기 재고구분)

            this.gridObj.gridView.columnByName('prodClCd').values =
                CommonUtil.convListToGridLovValues(
                    commProdClCdList,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('prodClCd').labels =
                CommonUtil.convListToGridLovLabels(
                    commProdClCdList,
                    'commCdValNm'
                )

            this.gridObj.gridView.columnByName('eqpClCd').values =
                CommonUtil.convListToGridLovValues(commEqpClCdList, 'commCdVal')
            this.gridObj.gridView.columnByName('eqpClCd').labels =
                CommonUtil.convListToGridLovLabels(
                    commEqpClCdList,
                    'commCdValNm'
                )

            this.gridObj.gridView.columnByName('prodChrticCd1').values =
                CommonUtil.convListToGridLovValues(
                    commProdChrticCd1List,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('prodChrticCd1').labels =
                CommonUtil.convListToGridLovLabels(
                    commProdChrticCd1List,
                    'commCdValNm'
                )

            this.gridObj.gridView.columnByName('prodChrticCd2').values =
                CommonUtil.convListToGridLovValues(
                    commProdChrticCd2List,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('prodChrticCd2').labels =
                CommonUtil.convListToGridLovLabels(
                    commProdChrticCd2List,
                    'commCdValNm'
                )

            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                console.log('clickData.dataRow::', clickData)
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )

                this.$emit('confirm', jsonData)
                this.onClose()
            }
            this.init()
        },
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },
        getProdsList() {
            //대표모델여부
            this.searchProdForm.repProdYn = String(this.ckParam.repProdYn)

            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                console.log('getProdsList : ', res)
                this.gridObj.setRows(res)
            })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('상품을 선택해주세요.', {
                    header: '상품',
                    size: '500',
                    confirmLabel: 'OK',
                })
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        onSearch() {
            this.getProdsList()
        },

        onEnterKey() {
            this.onSearch()
        },
    },
}
</script>
