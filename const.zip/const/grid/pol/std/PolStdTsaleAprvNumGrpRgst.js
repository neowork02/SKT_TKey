import { ValueType } from 'realgrid'

export let OBJSALEAPRVNOGRID_PROPERTYINFO = {
    fields: [
        {
            fieldName: 'dataState', // 데이터상태코드(inserted, updated)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
            booleanFormat: 'N:Y',
        },
        {
            fieldName: 'mgmtNo', // 관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvNo', // 영업승인번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvNm', // 영업승인명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCdNm', // 대리점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt', // 시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt', // 종료일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn', // 사용여부
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        // {
        //     name: 'chk',
        //     fieldName: 'chk',
        //     type: 'data',
        //     width: '90',
        //     header: {
        //         text: '체크',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: true,
        // },
        {
            name: 'mgmtNo',
            fieldName: 'mgmtNo',
            type: 'data',
            width: '90',
            header: {
                text: '관리번호',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'saleAprvNo',
            fieldName: 'saleAprvNo',
            type: 'data',
            width: '120',
            header: {
                text: '영업승인번호',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'saleAprvNm',
            fieldName: 'saleAprvNm',
            type: 'data',
            width: '240',
            header: {
                text: '영업승인번호명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            width: '90',
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'agencyCdNm',
            fieldName: 'agencyCdNm',
            type: 'data',
            width: '160',
            header: {
                text: '대리점명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            type: 'data',
            width: '90',
            header: {
                text: '시작일',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            type: 'data',
            width: '90',
            header: {
                text: '종료일',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            width: '70',
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                // dropDownCount: 4,
                // displayLabels: 'valueLabel',
                // textReadOnly: true
            },
        },
    ],

    layout: [
        'mgmtNo', // 관리번호
        'saleAprvNo', // 영업승인번호
        'saleAprvNm', // 영업승인번호명
        'agencyCd', // 대리점코드
        'agencyCdNm', // 대리점명
        'aplyStaDt', // 시작일
        'aplyEndDt', // 종료일
        'useYn', // 사용여부
    ],
}

export let APLYSALEAPRVNOGRID_PROPERTYINFO = {
    fields: [
        {
            fieldName: 'dataState', // 데이터상태코드(inserted, updated)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
            booleanFormat: 'N:Y',
        },
        {
            fieldName: 'mgmtNo', // 관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvNo', // 영업승인번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvNm', // 영업승인명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCdNm', // 대리점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt', // 시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt', // 종료일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn', // 사용여부
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        // {
        //     name: 'chk',
        //     fieldName: 'chk',
        //     type: 'data',
        //     width: '90',
        //     header: {
        //         text: '체크',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        {
            name: 'mgmtNo',
            fieldName: 'mgmtNo',
            type: 'data',
            width: '90',
            header: {
                text: '관리번호',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'saleAprvNo',
            fieldName: 'saleAprvNo',
            type: 'data',
            width: '120',
            header: {
                text: '영업승인번호',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'saleAprvNm',
            fieldName: 'saleAprvNm',
            type: 'data',
            width: '240',
            header: {
                text: '영업승인번호명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            width: '90',
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'agencyCdNm',
            fieldName: 'agencyCdNm',
            type: 'data',
            width: '160',
            header: {
                text: '대리점명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            type: 'data',
            width: '90',
            header: {
                text: '시작일',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            type: 'data',
            width: '90',
            header: {
                text: '종료일',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            width: '70',
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                // dropDownCount: 4,
                // displayLabels: 'valueLabel',
                // textReadOnly: true
            },
        },
    ],

    layout: [
        'chk',
        'mgmtNo', // 관리번호
        'saleAprvNo', // 영업승인번호
        'saleAprvNm', // 영업승인번호명
        'agencyCd', // 대리점코드
        'agencyCdNm', // 대리점명
        'aplyStaDt', // 시작일
        'aplyEndDt', // 종료일
        'useYn', // 사용여부
    ],
}
