<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">적용일자 일괄변경</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <span class="iteminput">
                                    <TCComDatePicker
                                        calType="D"
                                        v-model="aplyStaDt"
                                        labelName="시작일자"
                                        :eRequired="true"
                                    />
                                </span>
                            </div>

                            <div class="formitem div2">
                                <span class="itemtit line2"
                                    >시작일자 변경여부</span
                                >

                                <span class="iteminput">
                                    <div class="radioWrap">
                                        <v-checkbox
                                            v-model="ds_detail.staChk"
                                            color="point"
                                            label=""
                                            class=""
                                            :on-icon="'mdi-checkbox-marked'"
                                            :off-icon="'mdi-checkbox-blank-outline'"
                                        >
                                        </v-checkbox>
                                    </div>
                                </span>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <span class="iteminput">
                                    <TCComDatePicker
                                        calType="D"
                                        v-model="aplyEndDt"
                                        labelName="종료일자"
                                        :eRequired="true"
                                    />
                                </span>
                            </div>

                            <div class="formitem div2">
                                <span class="itemtit line2"
                                    >종료일자 변경여부</span
                                >

                                <span class="iteminput">
                                    <div class="radioWrap">
                                        <v-checkbox
                                            v-model="ds_detail.endChk"
                                            color="point"
                                            label=""
                                            class=""
                                            :on-icon="'mdi-checkbox-marked'"
                                            :off-icon="'mdi-checkbox-blank-outline'"
                                        >
                                        </v-checkbox>
                                    </div>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Bottom BTN Group -->

                    <div class="btn_area_bottom">
                        <!-- BTN -->

                        <v-btn
                            large
                            class="btn_ty02"
                            @click="onConfirm"
                            :objAuth="objAuth"
                            >확인</v-btn
                        >
                        <v-btn
                            large
                            class="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                            >닫기</v-btn
                        >
                        <!-- // BTN -->
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
            </div>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
export default {
    name: 'BasPrmAplyDtBatChgPopup',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            showAlertBool: false,
            headerText: '',
            alertBodyText: '',

            objAuth: {},

            ds_detail: {
                newAplyStaDt: '',
                oldAplyStaDt: '',
                newAplyEndDt: '',
                oldAplyEndDt: '',
                staChk: '',
                endChk: '',
            },
            parentData: [],
            aplyStaDt: '',
            aplyEndDt: '',
        }
    },

    mounted() {},
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentData', value)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        aplyStaDt: function (newVal, oldVal) {
            console.log('watch aplyStaDt', newVal, oldVal)
            this.ds_detail.newAplyStaDt = newVal
            this.ds_detail.oldAplyStaDt = oldVal
        },
        aplyEndDt: function (newVal, oldVal) {
            console.log('watch aplyEndDt', newVal, oldVal)
            this.ds_detail.newAplyEndDt = newVal
            this.ds_detail.oldAplyEndDt = oldVal
        },
    },
    methods: {
        async initGrid() {},

        onConfirm() {
            // if (this.ds_detail.GetUpdate() == false) {
            //     alert(MSG_00133) // 변경사항이 없습니다
            //     return false
            // }

            if (this.ds_detail.staChk) {
                this.ds_detail.staChk = 'Y'
            } else {
                this.ds_detail.staChk = ''
            }
            if (this.ds_detail.endChk) {
                this.ds_detail.endChk = 'Y'
            } else {
                this.ds_detail.endChk = ''
            }
            console.log(' this.ds_detail', this.ds_detail)
            if (
                this.ds_detail.newAplyStaDt != this.ds_detail.oldAplyStaDt &&
                this.ds_detail.staChk != 'Y'
            ) {
                alert('시작일자 변경여부 체크 바랍니다.')
                return
            }

            if (
                this.ds_detail.newAplyEndDt != this.ds_detail.oldAplyEndDt &&
                this.ds_detail.endChk != 'Y'
            ) {
                alert('종료일자 변경여부 체크 바랍니다.')
                return
            }

            if (
                this.ds_detail.staChk == 'Y' &&
                _.isEmpty(this.ds_detail.newAplyStaDt)
            ) {
                alert('시작일자 입력 바랍니다.')
                return
            }
            if (
                this.ds_detail.endChk == 'Y' &&
                _.isEmpty(this.ds_detail.newAplyEndDt)
            ) {
                alert('종료일자 입력 바랍니다.')
                return
            }

            this.$emit('confirm', this.ds_detail)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        onChange(e) {
            console.log('eChange::::', e)
        },
    },
}
</script>
