/*****************************************
* 업무 그룹명 : 정책
* 서브 업무명 : B영업일수관리
* 설 명 : B영업일수관리 REST API
* 작 성 자 :
* 작 성 일 : 2022.03.28
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 김병희 / 2022.03.28
* 변경사유/내역 : 
======================================
*****************************************/
/**************************************************************************************************************
 * 가상데이터 선언 영역
 **************************************************************************************************************/
import send from '@/api/axios-tdcs'
import _ from 'lodash'

export default {
    namespaced: true,
    state: {
        dsBsaleDayMgmtList: {
            type: Array,
            default: null,
        },
        dsCondition: {
            saleDt: '',
            saleWght: '',
            hdayClCd: '',
        },
        dsHdayClCdItems: [],
        // {
        //     commCdVal: '1',
        //     commCdValNm: '평일',
        // },
        // {
        //     commCdVal: '2',
        //     commCdValNm: '휴일',
        // },
        // {
        //     commCdVal: '3',
        //     commCdValNm: '일요일',
        // },
        // {
        //     commCdVal: '4',
        //     commCdValNm: '월요일',
        // },
        // {
        //     commCdVal: '5',
        //     commCdValNm: '화요일',
        // },
        // {
        //     commCdVal: '6',
        //     commCdValNm: '수요일',
        // },
        // {
        //     commCdVal: '7',
        //     commCdValNm: '목요일',
        // },
        // {
        //     commCdVal: '8',
        //     commCdValNm: '금요일',
        // },
        // {
        //     commCdVal: '9',
        //     commCdValNm: '토요일',
        // },
        dsHdayClCdGrid: {
            values: [],
            labels: [],
        },
    },
    mutations: {
        setInit(state, payload) {
            console.log('setInit[mutations]::::', payload)
            _.forEach(payload, (item) => {
                if (item.commCdId == 'HDAY_CL') {
                    state.dsHdayClCdItems.push(item)
                }
            })
            state.dsHdayClCdItems.unshift({
                commCdVal: '',
                commCdValNm: '선택',
            })
        },
        setDsCondition(state, payload) {
            state.dsCondition = payload
        },
        setDsHdayClCdItems(state, payload) {
            state.dsHdayClCdItems = payload
            // 휴일 콤보 정의
            state.dsHdayClCd.unshift({ commCdVal: '', commCdValNm: '선택' })

            state.dsHdayClCdGrid['values'].push('')
            state.dsHdayClCdGrid['labels'].push('선택')
            _.forEach(payload, (item) => {
                state.dsHdayClCdGrid['values'].push(item.commCdVal)
                state.dsHdayClCdGrid['labels'].push(item.commCdValNm)
            })
        },
        setDsBsaleDayMgmtList(state, payload) {
            state.dsBsaleDayMgmtList = payload
        },
    },
    actions: {
        async getInit({ commit }, payload) {
            console.log('getInit::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'post',
                    url: '/api/v1/backend/pol/com/getCommCdMgmtList',
                    data: payload,
                })
                    .then((res) => {
                        console.log('getInit[then]', res)
                        commit('setInit', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
        async getBsaleDayMgmtList({ commit }, payload) {
            console.log('getInit::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'get',
                    url: '/api/v1/backend/pol/stb/getBsaleDayMgmtList',
                    params: payload,
                })
                    .then((res) => {
                        console.log('getBsaleDayMgmtList[then]', res)
                        commit('setDsBsaleDayMgmtList', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
        async saveBsaleDayMgmt({ commit }, payload) {
            console.log('getInit::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'post',
                    url: '/api/v1/backend/pol/stb/saveBsaleDayMgmt',
                    data: {
                        saleDayMgmtList: payload,
                    },
                })
                    .then((res) => {
                        console.log('saveBsaleDayMgmt[then]', res)
                        commit(res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
    },

    // 월별 B영업일수내역 조회(묵업데이터)
    // getBsaleDayMgmtList1(params) {
    //     console.log('getBsaleDayMgmtList::::', params)

    //     return new Promise((resolve) => {
    //         let res = MOCKUP_DATA.getBsaleDayMgmtList

    //         resolve(res)
    //     })
    // },

    // // 월별 B영업일수내역 조회
    // getBsaleDayMgmtList(params) {
    //     return send({
    //         method: 'get',
    //         url: '/api/v1/backend/pol/stb/getBsaleDayMgmtList',
    //         params: params,
    //     }).catch((err) => {
    //         alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
    //         console.log(err)
    //     })
    // },
    // // 월별 B영업일수 저장
    // async saveBsaleDayMgmt(params) {
    //     console.log('api data = ' + JSON.stringify(params))
    //     return await new Promise((resolve, reject) => {
    //         console.log(resolve)
    //         send.post('/api/v1/backend/pol/stb/saveBsaleDayMgmt', {
    //             param: {
    //                 saleDayMgmtList: params,
    //             },
    //         })
    //             .then((res) => {
    //                 resolve(res)
    //             })
    //             .catch((err) => {
    //                 alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
    //                 reject(err)
    //             })
    //     })
    // },
}
