<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 재고이동요청
 * 설명: 재고이동요청을 조회한다.
 * 작성자: P179229
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>재고이동요청</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="dtlBtn"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="요청일"
                        calType="DP"
                        v-model="setDate"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        v-model="reqParam.prodClCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00500"
                        labelName="단말기구분"
                        v-model="reqParam.eqpClCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00660"
                        labelName="진행상태"
                        v-model="reqParam.reqStCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
        </div>
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="재고이동요청 내역"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisDtrDisMovReqIns"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <!-- //gridWrap -->
        <!-- popup -->
        <DisDtrDisMovReqInDtlPopup
            v-if="showDisDtrDisMovReqInDtl === true"
            ref="popup"
            :dialogShow.sync="showDisDtrDisMovReqInDtl"
            :dtlData.sync="dtlParam"
        />
        <!-- //popup -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { DisDtrDisMovReqInGRID_HEADER } from '@/const/grid/dis/dtr/disDtrDisMovReqInHeader'
import disDtrDisMovReqInApi from '@/api/biz/dis/dtr/disDtrMovReqIn'
import attachedFileApi from '@/api/common/attachedFile'
import DisDtrDisMovReqInDtlPopup from './DisDtrDisMovReqInDtlPopup'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'DisDtrDisMovReqIn',
    mixins: [CommonMixin],
    components: {
        DisDtrDisMovReqInDtlPopup,
    },
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            indicatorOpt: { sort: 'ASC' },
            objAuth: {},
            view: DisDtrDisMovReqInGRID_HEADER,
            showDisDtrDisMovReqInDtl: false,
            reqParam: {
                fromDt: '', //from일자
                toDt: '', //to일자
                prodClCd: '', //상품구분
                eqpClCd: '', //단말기구분
                reqStCd: '', //진행상태
                orgCd: '', //조직id
                orgNm: '', //조직명
                orgLvl: '', //조직level
                orgCdLvl0: '', //조직레벨0조직코드
                dealcoCd: '', // 요청거래처
                dealcoNm: '', // 요청거래처명
            },
            serchParam: {},
            dtlParam: {},
            rowCnt: 15,
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.fromDt, this.reqParam.toDt]
            },
            set(val) {
                this.reqParam.fromDt = val[0]
                this.reqParam.toDt = val[1]
                return val
            },
        },
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(true, false, false)
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked
        this.init()
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.fromDt = moment(new Date()).format('YYYY-MM-01') // 입고일 from
            this.reqParam.toDt = moment(new Date()).format('YYYY-MM-DD') // 입고일 to
            //세션처리
            if (!_.isEmpty(this.orgInfo['orgCd'])) {
                this.reqParam['outOrgCd'] = this.orgInfo['orgCd']
                this.reqParam['outOrgNm'] = this.orgInfo['orgNm']
                this.reqParam['outOrgLvl'] = this.orgInfo['orgLvl']
                this.reqParam['outOrgCdLvl0'] = this.orgInfo['orgCdLvl0']
            }
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['dealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['dealcoNm'] = this.userInfo['dealcoNm']
            }
            this.reqParam['userId'] = this.userInfo['userId']
            this.reqParam['userNm'] = this.userInfo['userNm']
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam')
            this.init()
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dtr/disDtrDisMovReqInExcelList',
                this.searchForm
            )
        },
        //리스트 조회
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            this.searchForm = { ...this.reqParam }
            this.searchForm.fromDt = CommonUtil.replaceDash(
                this.searchForm.fromDt
            )
            this.searchForm.toDt = CommonUtil.replaceDash(this.searchForm.toDt)
            //첫 조회시 표시할 행의 갯수
            this.searchForm.pageSize = this.rowCnt
            this.searchForm.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getDisDtrDisMovReqIns(this.searchForm.pageNum)
        },
        getDisDtrDisMovReqIns(page) {
            this.searchForm.pageNum = page
            disDtrDisMovReqInApi
                .getDisDtrDisMovReqIn(this.searchForm)
                .then((res) => {
                    //Get Row Data
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator(
                        res.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(res.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                })
        },
        isValidChk() {
            let validFromDt = CommonUtil.replaceDash(this.reqParam.fromDt)
            let validToDt = CommonUtil.replaceDash(this.reqParam.toDt)
            if (_.isEmpty(validFromDt)) {
                this.showTcComAlert('요청일자의 시작일(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(validToDt)) {
                this.showTcComAlert('요청일자의 종료일(을)를 입력해 주십시오.')
                return false
            }
            if (validFromDt.substr(0, 6) !== validToDt.substr(0, 6)) {
                this.showTcComAlert(
                    '요청 시작일자와 종료일자를 동일한 월로 지정하세요.'
                )
                return false
            }
            if (validFromDt > validToDt) {
                this.showTcComAlert('요청일자의 시작일이 종료일보다 큽니다.')
                return false
            }
            return true
        },
        dtlBtn: function () {
            this.dtlParam = Object.assign({}, this.reqParam)
            this.dtlParam.reqDealcoNm = this.reqParam.dealcoNm
            this.showDisDtrDisMovReqInDtl = true
        },
        onCellDblClicked(grid, clickData) {
            if (clickData?.dataRow >= 0) {
                const cellData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.dtlParam = Object.assign({}, this.reqParam)
                this.dtlParam.reqMgmtNo = _.get(cellData, 'reqMgmtNo')
                this.showDisDtrDisMovReqInDtl = true
            }
        },
    },
}
</script>
