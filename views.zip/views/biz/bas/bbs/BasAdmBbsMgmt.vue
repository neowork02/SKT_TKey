<template>
    <div class="content">
        <!-- Tit -->
        <h1>{{ this.CONSTANTS.SYSTEM_NM }} 게시판</h1>
        <!-- // Tit -->

        <AdmRgstPopup
            v-if="showAdmBbsRegPop"
            ref="popup"
            :dialogShow.sync="showAdmBbsRegPop"
        />
        <DetailPopup
            v-if="showBasBbsDetailMgmt === true"
            ref="popup"
            :dialogShow.sync="showBasBbsDetailMgmt"
            :popupParams.sync="popupParams"
        />
        <!--  <ul class="btn_area top">
          <li class="right">
                <TCComButton eClass="btn_ty01" @click="initBtn"
                    >초기화</TCComButton
                >
                <TCComButton eClass="btn_ty01" @click="onSearch"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    @click="newBoard"
                    v-show="showRegBtn"
                    >등록</TCComButton
                >
            </li>
        </ul> -->
        <!-- Search_div -->
        <TCComTab
            :tab.sync="guideTab"
            :items="items"
            :itemName="itemName"
            :tabColor="tabColor"
            :textColor="textColor"
            :centered="centered"
            :grow="grow"
            :height="height"
            :hideSlider="hideSlider"
            :sliderColor="sliderColor"
            :vertical="vertical"
            :objAuth="objAuth"
            sliderSize="8"
            :cKey="0"
        >
            <template #Template1>
                <div class="searchLayer_wrap mt20">
                    <div class="searchform">
                        <!-- item 1-1 -->
                        <div class="formitem div4">
                            <TCComDatePicker
                                calType="D"
                                labelName="등록일자"
                                :eRequired="false"
                                v-model="forms.insDtm"
                            />
                        </div>
                        <!-- //item 1-1 -->
                        <!-- item 1-2 -->
                        <div class="formitem div4">
                            <TCComInput
                                labelName="제목"
                                v-model="forms.textTitle"
                            >
                            </TCComInput>
                        </div>
                        <div class="formitem div4">
                            <TCComInput labelName="내용" v-model="forms.bbsDtl">
                            </TCComInput>
                        </div>
                        <!-- //item 1-2 -->
                    </div>
                </div>
                <div class="gridWrap">
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="시스템공지사항"
                        :gridObj="gridObj"
                    >
                        <!-- TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                        <template #gridElementArea>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="initBtn"
                                labelName="초기화"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="onSearch"
                                labelName="조회"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_addedit"
                                @click="newBoard"
                                labelName="신규"
                            />
                        </template>
                        <!-- //TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :editable="true"
                        :movable="false"
                        :columnMovable="false"
                        :fields="view.fields"
                        :columns="view.columns"
                        :isGridReSize="true"
                    />
                </div>
                <div class="wpagingWrap">
                    <TCComPaging
                        :totalPage="gridData.totalPage"
                        :apiFunc="getBasBbsAdmMgmtList"
                        :rowCnt="rowCnt"
                        @input="chgRowCnt"
                    />
                </div>
            </template>
            <template #Template2>
                <div class="searchLayer_wrap mt20">
                    <div class="searchform">
                        <!-- item 1-1 -->
                        <div class="formitem div4">
                            <TCComDatePicker
                                calType="D"
                                labelName="등록일자"
                                :eRequired="false"
                                v-model="forms.insDtm"
                            />
                        </div>
                        <!-- //item 1-1 -->
                        <!-- item 1-2 -->
                        <div class="formitem div4">
                            <TCComInput
                                labelName="제목"
                                v-model="forms.textTitle"
                            >
                            </TCComInput>
                        </div>
                        <div class="formitem div4">
                            <TCComInput labelName="내용" v-model="forms.bbsDtl">
                            </TCComInput>
                        </div>
                        <!-- //item 1-2 -->
                    </div>
                </div>
                <div class="gridWrap">
                    <TCRealGridHeader
                        id="gridHeader2"
                        ref="gridHeader2"
                        gridTitle="기능개선요청게시판"
                        :gridObj="gridObj2"
                    >
                        <!-- TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                        <template #gridElementArea>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="initBtn"
                                labelName="초기화"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="onSearch"
                                labelName="조회"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_addedit"
                                @click="newBoard"
                                labelName="신규"
                            />
                        </template>
                        <!-- //TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid2"
                        ref="grid2"
                        :editable="true"
                        :movable="false"
                        :columnMovable="false"
                        :fields="view2.fields"
                        :columns="view2.columns"
                        :isGridReSize="true"
                        @hook:mounted="tabGridMounted"
                    />
                </div>
                <div class="wpagingWrap">
                    <TCComPaging
                        :totalPage="gridData2.totalPage"
                        :apiFunc="getBasBbsAdmMgmtList2"
                        :rowCnt2="rowCnt2"
                        @input="chgRowCnt2"
                    />
                </div>
            </template>
        </TCComTab>
    </div>
</template>

<style>
/* @import '@/node_modules/realgrid/dist/realgrid-style.css'; */
</style>

<script>
import { CommonGrid } from '@/utils'
import {
    BAS_BBS_LIST_SST_HEADER,
    BAS_BBS_LIST_IPM_HEADER,
} from '@/const/grid/bas/bbs/basBbsMgmtHeader'
// import _ from 'lodash'
import CommonMixin from '@/mixins'
import basBbsMgmtApi from '@/api/biz/bas/bbs/basBbsMgmt'
import AdmRgstPopup from '@/views/biz/bas/bbs/BasAdmReg'
import DetailPopup from '@/views/biz/bas/bbs/BasBbsDetailMgmt'
//import store from '@/store/biz/bas/bco/agencysMgmt'
export default {
    name: 'BasBbsMgmt',
    mixins: [CommonMixin],
    components: { AdmRgstPopup, DetailPopup },
    data() {
        return {
            guideTab: 0,
            items: ['Template1', 'Template2'],
            itemName: ['시스템공지사항', '기능개선요청게시판'],
            itemList4: ['제목', '내용', '제목+내용'],
            search: '',
            tabColor: '',
            textColor: '',
            height: '',
            sliderColor: '',
            centered: false,
            grow: false,
            hideSlider: false,
            vertical: false,
            rowCnt: 15,
            rowCnt2: 15,
            activePage: 1, // 현재페이지
            //Grid Class init
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            gridData2: {},
            gridObj2: {},
            gridHeaderObj2: {},
            view: BAS_BBS_LIST_SST_HEADER,
            view2: BAS_BBS_LIST_IPM_HEADER,
            toggleActive: false,
            showRegBtn: true,
            showTab: true,
            objAuth: {},
            forms: {},
            popupParams: {
                bbsNo: '',
                bbsTypeCd: '',
                bbsDtl: '',
                textTitle: '',
                insDtm: '',
            },
            showNext: false,
            showAdmBbsRegPop: false,
            showBasBbsDetailMgmt: false,
        }
    },

    mounted() {
        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            if ('data' === clickData.cellType) {
                this.grdListOnCellblClick(clickData.dataRow)
            }
        }
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        //Default false
        this.gridObj.setGridState(true, false, false, false)
        this.getBasBbsAdmMgmtList(1)
    },
    computed: {},
    methods: {
        init: function () {
            this.gridData = this.gridSetData()
        },
        async newBoard() {
            if (this.guideTab == 0) {
                this.bbsTypeCd = 'A'
            } else if (this.guideTab == 1) {
                this.bbsTypeCd = 'I'
            }
            this.showAdmBbsRegPop = true
        },
        initBtn() {
            this.forms.bbsDtl = ''
            this.forms.textTitle = ''
            this.forms.insDtm = ''
            if (this.guideTab == 0) {
                this.getBasBbsAdmMgmtList()
            }
            if (this.guideTab == 1) {
                this.getBasBbsAdmMgmtList2()
            }
        },
        onSearch() {
            if (this.guideTab == 0) {
                this.bbsTypeCd = 'A'
                this.getBasBbsAdmMgmtList()
            } else if (this.guideTab == 1) {
                this.bbsTypeCd = 'I'
                this.getBasBbsAdmMgmtList2()
            }
        },
        //@hook:mounted
        tabGridMounted() {
            this.gridObj2 = this.$refs.grid2
            this.gridHeaderObj2 = this.$refs.gridHeader2
            this.gridObj2.setGridState(true, false, false, false)
            this.gridObj2.gridView.onCellClicked = (grid2, clickData) => {
                if ('data' === clickData.cellType) {
                    this.grdListOnCellblClick1(clickData.dataRow)
                }
            }
            this.getBasBbsAdmMgmtList2()

            //this.popupParams.bbsTypeCd = 'D'
        },
        grdListOnCellblClick: function (dataRow) {
            this.popupParams.bbsNo = this.gridObj.gridView.getValue(
                dataRow,
                'bbsNo'
            )
            this.showBasBbsDetailMgmt = true
        },
        grdListOnCellblClick1: function (dataRow) {
            this.popupParams.bbsNo = this.gridObj2.gridView.getValue(
                dataRow,
                'bbsNo'
            )
            this.showBasBbsDetailMgmt = true
        },
        //Grid Init
        gridSetData: function (rowCnt) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, rowCnt, '', '')
        },
        gridSetData2: function (rowCnt2) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, rowCnt2, '', '')
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        chgRowCnt2(val) {
            this.rowCnt2 = val
        },
        // API 호출
        getBasBbsAdmMgmtList(page) {
            this.forms.pageSize = this.rowCnt
            this.forms.pageNum = page //첫번째 페이지
            this.forms.bbsTypeCd = 'A'
            basBbsMgmtApi
                .getBasBbsAdmMgmtList(this.forms)
                .then((resultData) => {
                    console.log('resultData', resultData)
                    this.gridObj.setRows(resultData.gridList)
                    this.gridObj.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    // //Grid Row 가져올때 총건수 Setting
                    this.gridHeaderObj.setPageCount(resultData.pagingDto)

                    //this.gridObj.gridView.setRowStyleCallback()
                })
        },
        // API 호출
        getBasBbsAdmMgmtList2(page) {
            this.forms.pageSize = this.rowCnt2
            this.forms.pageNum = page //두번째 페이지
            this.forms.bbsTypeCd = 'I'
            basBbsMgmtApi
                .getBasBbsAdmMgmtList(this.forms)
                .then((resultData) => {
                    console.log('resultData', resultData)
                    this.gridObj2.setRows(resultData.gridList)
                    this.gridObj2.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData2 = this.gridSetData2() //초기화
                    this.gridData2.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    //Grid Row 가져올때 총건수 Setting
                    this.gridHeaderObj2.setPageCount(resultData.pagingDto)
                })
        },
    },
}
</script>
