import { ValueType } from 'realgrid'

export const AGENCY_DOWN_HEADER = {
    fields: [
        {
            fieldName: 'seq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'excelMenuId',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'agencyYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stateCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stateNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fileNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'typeCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'typeNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyName',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'stateNm',
            fieldName: 'stateNm',
            header: {
                text: '상태명',
            },
            editable: false,
        },
        {
            name: 'typeNm',
            fieldName: 'typeNm',
            header: {
                text: 'Down/Up',
            },
            editable: false,
        },
        {
            name: 'agencyName',
            fieldName: 'agencyName',
            header: {
                text: '업체명',
            },
            editable: false,
        },
        {
            name: 'reqUserNm',
            fieldName: 'reqUserNm',
            header: {
                text: '성명',
            },
            editable: false,
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            header: {
                text: '일시',
            },
            editable: false,
        },
        {
            name: 'opDtm',
            fieldName: 'opDtm',
            header: {
                text: '개인정보항목',
            },
            editable: false,
            styleCallback() {
                const ret = { styleName: 'underLine' }
                return ret
            },
            displayCallback() {
                return '팝업'
            },
        },
    ],
}

export const AGENCY_DOWN_DTL_HEADER = {
    fields: [
        {
            fieldName: 'seq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'excelColIdx',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'excelItemNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'excelItemNm',
            fieldName: 'excelItemNm',
            header: {
                text: '개인정보항목',
            },
            editable: false,
        },
        {
            name: 'excelColIdx',
            fieldName: 'excelColIdx',
            header: {
                text: '열',
            },
            editable: false,
        },
    ],
}
