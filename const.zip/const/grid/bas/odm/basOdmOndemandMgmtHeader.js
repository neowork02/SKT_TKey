import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pagingSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ondmndId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'progId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'batId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pgmNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId5',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm5',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId6',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm6',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId7',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm7',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId8',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm8',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId9',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm9',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId10',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm10',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: ' ',
            },
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: 'true',
                falseValues: 'false',
            },
            width: 30,
        },
        {
            name: 'pagingSeq',
            fieldName: 'pagingSeq',
            header: {
                text: 'No.',
            },
            editable: false,
            width: 40,
        },
        {
            name: 'ondmndId',
            fieldName: 'ondmndId',
            header: {
                text: 'OndemandID',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'opTypCd',
            fieldName: 'opTypCd',
            header: {
                text: '업무유형',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'opTypNm',
            fieldName: 'opTypNm',
            header: {
                text: '업무유형',
            },
            editable: false,
            width: 40,
        },
        {
            name: 'progId',
            fieldName: 'progId',
            header: {
                text: '프로그램ID',
            },
            editable: false,
            width: 100,
        },
        {
            name: 'batId',
            fieldName: 'batId',
            header: {
                text: '배치쉘프로그램ID',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'pgmNm',
            fieldName: 'pgmNm',
            header: {
                text: '작업설명(프로그램명)',
            },
            type: 'data',
            styleName: 'left-column',
            editable: false,
            width: 220,
        },
        {
            name: 'rgstDt',
            fieldName: 'rgstDt',
            header: {
                text: '등록일자',
            },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editable: false,
            width: 80,
        },
        {
            name: 'condCnt',
            fieldName: 'condCnt',
            header: {
                text: '조건수',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condId1',
            fieldName: 'condId1',
            header: {
                text: '조건ID1',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm1',
            fieldName: 'condNm1',
            header: {
                text: '조건명1',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condId2',
            fieldName: 'condId2',
            header: {
                text: '조건ID2',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm2',
            fieldName: 'condNm2',
            header: {
                text: '조건명2',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condId3',
            fieldName: 'condId3',
            header: {
                text: '조건ID3',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm3',
            fieldName: 'condNm3',
            header: {
                text: '조건명3',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condId4',
            fieldName: 'condId4',
            header: {
                text: '조건ID4',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm4',
            fieldName: 'condNm4',
            header: {
                text: '조건명4',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condId5',
            fieldName: 'condId5',
            header: {
                text: '조건ID5',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm5',
            fieldName: 'condNm5',
            header: {
                text: '조건명5',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condId6',
            fieldName: 'condId6',
            header: {
                text: '조건ID6',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm6',
            fieldName: 'condNm6',
            header: {
                text: '조건명6',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condId7',
            fieldName: 'condId7',
            header: {
                text: '조건ID7',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm7',
            fieldName: 'condNm7',
            header: {
                text: '조건명7',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condId8',
            fieldName: 'condId8',
            header: {
                text: '조건ID8',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm8',
            fieldName: 'condNm8',
            header: {
                text: '조건명8',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condId9',
            fieldName: 'condId9',
            header: {
                text: '조건ID9',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm9',
            fieldName: 'condNm9',
            header: {
                text: '조건명9',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condId10',
            fieldName: 'condId10',
            header: {
                text: '조건ID10',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm10',
            fieldName: 'condNm10',
            header: {
                text: '조건명10',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condNm',
            fieldName: 'condNm',
            header: {
                text: '조회조건',
            },
            type: 'data',
            styleName: 'left-column',
            editable: false,
            width: 400,
            // eslint-disable-next-line no-unused-vars
            displayCallback(grid, index, value) {
                let conArr = []
                conArr.push(grid.getValue(index.itemIndex, 'condNm1'))
                conArr.push(grid.getValue(index.itemIndex, 'condNm2'))
                conArr.push(grid.getValue(index.itemIndex, 'condNm3'))
                conArr.push(grid.getValue(index.itemIndex, 'condNm4'))
                conArr.push(grid.getValue(index.itemIndex, 'condNm5'))
                conArr.push(grid.getValue(index.itemIndex, 'condNm6'))
                conArr.push(grid.getValue(index.itemIndex, 'condNm7'))
                conArr.push(grid.getValue(index.itemIndex, 'condNm8'))
                conArr.push(grid.getValue(index.itemIndex, 'condNm9'))
                conArr.push(grid.getValue(index.itemIndex, 'condNm10'))
                return conArr.filter((x) => x != null && x != '').join(',')
            },
        },
        {
            name: 'delYn',
            fieldName: 'delYn',
            header: {
                text: '사용여부',
            },
            width: 40,
        },
    ],
}

export const DETAIL_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condLen',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: ' ',
            },
            // renderer: {
            //     type: 'check',
            //     shape: 'box',
            //     editable: true,
            //     startEditOnClick: true,
            //     trueValues: 'true',
            //     falseValues: 'false',
            // },
            // width: 30,
            visible: false,
        },
        {
            name: 'condNm',
            fieldName: 'condNm',
            header: {
                text: '조건',
            },
            editable: false,
            visible: true,
            width: 200,
        },
        {
            name: 'condId',
            fieldName: 'condId',
            header: {
                text: '조건Id',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condTypCd',
            fieldName: 'condTypCd',
            header: {
                text: 'TYPE CODE',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condTypNm',
            fieldName: 'condTypNm',
            header: {
                text: 'TYPE',
            },
            editable: false,
            visible: true,
        },
        {
            name: 'condLen',
            fieldName: 'condLen',
            header: {
                text: 'LENGTH',
            },
            editable: false,
            visible: true,
            width: 60,
        },
    ],
}

export const EXEC_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pagingSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condLen',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'condVal',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: ' ',
            },
            // renderer: {
            //     type: 'check',
            //     shape: 'box',
            //     editable: true,
            //     startEditOnClick: true,
            //     trueValues: 'true',
            //     falseValues: 'false',
            // },
            // width: 30,
            visible: false,
        },
        {
            name: 'pagingSeq',
            fieldName: 'pagingSeq',
            header: {
                text: '번호',
            },
            editable: false,
            width: 40,
        },
        {
            name: 'condNm',
            fieldName: 'condNm',
            header: {
                text: '조건',
            },
            editable: false,
            visible: true,
            width: 200,
        },
        {
            name: 'condId',
            fieldName: 'condId',
            header: {
                text: '조건Id',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condTypCd',
            fieldName: 'condTypCd',
            header: {
                text: 'TYPE CODE',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condTypNm',
            fieldName: 'condTypNm',
            header: {
                text: 'TYPE',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'condLen',
            fieldName: 'condLen',
            header: {
                text: 'LENGTH',
            },
            editable: false,
            visible: true,
            width: 60,
        },
        {
            name: 'condVal',
            fieldName: 'condVal',
            header: {
                text: '조회값',
            },
            editor: {
                //textCase: 'upper',
                maxLength: 14,
            },
            editable: true,
            visible: true,
            width: 200,
        },
    ],
}
