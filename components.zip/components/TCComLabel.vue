<!-----------------------------------------------
 * 업무그룹명: Label 컴포넌트
 * 서브업무명: Label 공통함수
 * 설명: Label 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.04.14
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <span v-if="this.labelName" class="itemtit" :class="labelClass">
        <span v-if="this.eRequired" class="emph_txt">* </span>
        {{ labelName }}
    </span>
</template>

<script>
export default {
    inheritAttrs: false,
    name: 'TCComLabel',
    components: {},
    props: {
        // 텍스트 내용
        labelName: { type: String, default: '', required: true },
        labelClass: { type: String, default: '', required: false },
        eRequired: { type: Boolean, default: false, required: false },
        // 왼쪽 아이콘
        leftIcon: { type: String, default: '', required: false },
        // 오른쪽 아이콘
        rightIcon: { type: String, default: '', required: false },
    },

    data() {
        return {}
    },
    computed: {},
    // props 동적 제어
    watch: {},
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {},
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
