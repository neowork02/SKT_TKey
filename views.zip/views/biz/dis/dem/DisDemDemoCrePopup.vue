<!-----------------------------------------------
 * 업무그룹명: 시연재고등록팝업
 * 서브업무명: 시연재고등록팝업
 * 설명: 시연재고등록한다.
 * 작성자: P179234
 * 작성일: 2022.04.05
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">시연재고등록</p>
                <div class="layerCont">
                    <div class="stitHead pop">
                        <h4 class="subTit">시연기기등록</h4>
                        <span class="stitBtnRef2">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="init"
                                :objAuth="objAuth"
                            >
                                초기화
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="serNumChk()"
                                :objAuth="objAuth"
                            >
                                조회
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="saveDemo()"
                                :objAuth="objAuth"
                            >
                                저장
                            </TCComButton>
                            <!-- <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="closeBtn"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton> -->
                        </span>
                    </div>
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :codeVal.sync="reqParam.orgCd"
                                    :disabledAfter="true"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    :disabled="orgDisabled"
                                    v-model="reqParam.orgNm"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="reqParam.hldDealcoNm"
                                    :codeVal.sync="reqParam.hldDealcoCd"
                                    labelName="보유처"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    :disabled="dealcoDisabled"
                                    @enterKey="onDealcoEnterKey"
                                    @appendIconClick="onDealcoIconClick"
                                    @input="onDealcoInput"
                                />
                                <BasBcoDealcosPop
                                    v-if="showBasBcoDealcos"
                                    :parentParam="searchForm"
                                    :rows="resultDealcoRows"
                                    :dialogShow.sync="showBasBcoDealcos"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="등록일자"
                                    calType="D"
                                    :disabled="true"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="setDate"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="일련번호"
                                    :disabled="isEditNum"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.serNum"
                                    @enterKey="serNumChk()"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="판매금액"
                                    :disabled="isEdit"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.saleAmt"
                                    :commaFormat="true"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="모델"
                                    :disabled="true"
                                    :eRequired="false"
                                    :objAuth="objAuth"
                                    v-model="reqParam.prodNm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="등록자"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.modUserNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="실제매입가"
                                    :disabled="true"
                                    :eRequired="false"
                                    :objAuth="objAuth"
                                    v-model="reqParam.realAmt"
                                    :commaFormat="true"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="판매가능일"
                                    calType="D"
                                    :disabled="isEdit"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.salePosDt"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="색상"
                                    :disabled="true"
                                    :eRequired="false"
                                    :objAuth="objAuth"
                                    v-model="reqParam.colorNm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    labelName="비고"
                                    :rows="5"
                                    v-model="reqParam.rmks"
                                    :disabled="isEdit"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="closeBtn"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                </div>
                <!-- 재고상품 리스트 조회 -->
                <DisDsmProdHstBrwsSerNumPopup
                    v-if="showPopupSerNum === true"
                    ref="popup"
                    :dialogShow.sync="showPopupSerNum"
                    :popupParams.sync="popupParamsSerNum"
                    @confirm="onReturnDisDsmProdHstBrwsSerNum"
                />
            </div>
        </template>
    </TCComDialog>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 콜백 서비스 아이디
 * 4 저장 시 벨리데이셥 체크
 * 5 사용자 정의 파라메터 기반 공통팝업 호출
------------------------------------------------>
<script>
import moment from 'moment'
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import { Demo } from './js/disDemDemoDisMgmt.js'
// import dsmApi from '@/api/biz/dis/dsm/disDsmProdHstBrws'
import demApi from '@/api/biz/dis/dem/disDemDemoDisMgmt.js'
import _ from 'lodash'

import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'

//====================내부거래처-권한조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================
import DisDsmProdHstBrwsSerNumPopup from '@/views/biz/dis/dsm/DisDsmProdHstBrwsSerNumPopup'

export default {
    name: 'Home',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
        DisDsmProdHstBrwsSerNumPopup,
    },
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        parentParam: { type: Object, default: () => {}, required: false },
        demoInfo: {
            type: Boolean,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            isEdit: true,
            isEditNum: false,
            objAuth: {},
            Demo: Demo,
            reqParam: {
                orgCd: '',
                orgNm: '',
                hldDealcoCd: '',
                hldDealcoNm: '',
                demoRgstDt: '',
                serNum: '',
                saleAmt: 0,
                prodNm: '',
                colorCd: '',
                prodCd: '',
                modUserNm: '',
                realAmt: 0,
                salePosDt: '',
            },

            // 내부조직 관련
            orgDisabled: false,
            showBcoAuthOrgTrees: false,
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultAuthOrgTreeRows: [],
            // 보유처 관련
            showBcoOrgAgencys: false,
            //====================내부거래처-권한조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================

            //일련번호 조회팝업
            popupParamsSerNum: {},
            showPopupSerNum: false,
        }
    },
    mounted() {
        this.init()
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
                this.$emit('update:Demo', value)
            },
        },
        setDate: {
            get() {
                return this.reqParam.demoRgstDt
            },
            set(val) {
                this.reqParam.demoRgstDt = val

                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchParam.basMth = CommonUtil.onlyNumber(val).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val)
                return val
            },
        },
    },
    methods: {
        /* 초기화 */
        init() {
            this.reqParam = {
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                hldDealcoCd: '',
                hldDealcoNm: '',
                demoRgstDt: '',
                serNum: '',
                saleAmt: 0,
                colorCd: '',
                prodCd: '',
                prodNm: '',
                modUserNm: '',
                realAmt: 0,
                salePosDt: '',
            }
            this.reqParam = { ...this.parentParam }
            this.reqParam.serNum = ''

            this.isEdit = true
            this.isEditNum = false

            this.reqParam.modUserNm = this.userInfo['userNm']
            this.reqParam.demoRgstDt = moment(new Date()).format('YYYY-MM-DD')
            this.reqParam.salePosDt = moment(
                moment(new Date()).add(90, 'days')
            ).format('YYYY-MM-DD')

            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
        },
        serNumChk() {
            if (!this.fChkVal()) return

            const formData = {
                orgCd: this.reqParam.orgCd,
                orgLvl: this.reqParam.orgLvl,
                orgNm: this.reqParam.orgNm,
                hldDealcoCd: this.reqParam.hldDealcoCd,
                serNum: this.reqParam.serNum,
            }
            demApi.getDemoDisMgmt(formData).then((resultData) => {
                if (resultData && resultData.length > 1) {
                    this.popupParamsSerNum.params = formData
                    this.popupParamsSerNum.api = 'demoCre'
                    this.showPopupSerNum = true
                } else if (resultData && resultData.length == 1) {
                    const res = resultData[0]
                    this.isEdit = false
                    this.isEditNum = true
                    res.demoRgstDt = moment(new Date()).format('YYYY-MM-DD')
                    res.salePosDt = moment(
                        moment(new Date()).add(90, 'days')
                    ).format('YYYY-MM-DD')
                    this.reqParam = res
                    //조직정보
                    this.reqParam.orgLvl = formData.orgLvl
                    this.reqParam.orgCd = formData.orgCd
                    this.reqParam.orgNm = formData.orgNm
                    this.reqParam.saleAmt = this.reqParam.realAmt
                    this.reqParam.modUserNm = this.reqParam.oprNm
                    console.log(res)
                } else if (!resultData || resultData.length == 0) {
                    this.showTcComAlert(
                        '일련번호 <' +
                            this.reqParam.serNum +
                            '> 은(는) 시연재고등록 가능한 상품이 아닙니다.'
                    )
                }
            })
        },
        /* 시연재고 일련번호 조회 */
        searchDemo() {
            const orgLvl = this.reqParam.orgLvl
            const orgCd = this.reqParam.orgCd
            const orgNm = this.reqParam.orgNm

            const params = {
                orgLvl: this.reqParam.orgLvl,
                orgCd: this.reqParam.orgCd,
                orgNm: this.reqParam.orgNm,
                hldDealcoCd: this.reqParam.hldDealcoCd,
                serNum: this.reqParam.serNum,
                prodCd: this.reqParam.prodCd,
                colorCd: this.reqParam.colorCd,
            }

            demApi.getDemoDisMgmt(params).then((resultData) => {
                if (resultData) {
                    const res = resultData[0]
                    this.isEdit = false
                    this.isEditNum = true
                    res.demoRgstDt = moment(new Date()).format('YYYY-MM-DD')
                    res.salePosDt = moment(
                        moment(new Date()).add(90, 'days')
                    ).format('YYYY-MM-DD')
                    this.reqParam = res
                    //조직정보
                    this.reqParam.orgLvl = orgLvl
                    this.reqParam.orgCd = orgCd
                    this.reqParam.orgNm = orgNm
                    this.reqParam.saleAmt = this.reqParam.realAmt
                    this.reqParam.modUserNm = this.reqParam.oprNm
                } else {
                    this.showTcComAlert(
                        '일련번호 <' +
                            this.reqParam.serNum +
                            '> 은(는) 시연재고등록 가능한 상품이 아닙니다.'
                    )
                }
            })
        },
        onReturnDisDsmProdHstBrwsSerNum: function (retVal) {
            if (retVal.flag) {
                this.reqParam.serNum = retVal.data.serNum
                this.reqParam.colorCd = retVal.data.colorCd
                this.reqParam.prodCd = retVal.data.prodCd
                this.searchDemo()
            }
        },
        fChkVal() {
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 입력 해주세요.')
                return false
            } else if (_.isEmpty(this.reqParam.demoRgstDt)) {
                this.showTcComAlert('등록일자를 입력 해주세요.')
                return false
            } else if (_.isEmpty(this.reqParam.serNum)) {
                this.showTcComAlert('일련번호를 입력 해주세요.')
                return false
            }
            return true
        },
        /* 시연재고 저장 */
        saveDemo() {
            if (!this.fChkVal()) return

            if (
                _.isUndefined(this.reqParam.saleAmt) ||
                (_.isEmpty(this.reqParam.saleAmt) &&
                    typeof this.reqParam.saleAmt !== 'number') ||
                Number(this.reqParam.saleAmt) < 0
            ) {
                this.showTcComAlert('판매금액을 입력 해주세요.')
                return
            } else {
                this.reqParam.saleAmt = String(this.reqParam.saleAmt).replace(
                    /,/gi,
                    ''
                )
            }
            if (_.isEmpty(this.reqParam.salePosDt)) {
                this.showTcComAlert('판매가능일자를 입력 해주세요.')
                return
            }
            if (!CommonUtil.chkRmks(this.reqParam.rmks)) {
                return
            }
            this.reqParam.demoRgstDt = CommonUtil.onlyNumber(
                this.reqParam.demoRgstDt
            )
            this.reqParam.salePosDt = CommonUtil.onlyNumber(
                this.reqParam.salePosDt
            )
            const list = []
            list.push(this.reqParam)
            const formData = { rowDatas: list }

            console.log('sava data', formData)
            demApi.saveDemoDisRgsts(formData).then((res) => {
                console.log(res)
                this.$emit('confirm', true)
                this.activeOpen = false
            })
        },
        /* 조회 팝업 */
        btnClick() {
            console.log('cli ck')
        },
        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
        /* 팝업 창닫기 */
        closeBtn() {
            this.activeOpen = false
        },

        /* 내부조직팝업 */
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.reqParam.orgCd
            this.searchParam.orgNm = this.reqParam.orgNm
            this.searchParam.orgLvl = this.reqParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                        this.searchForm.orgCd = this.reqParam.orgCd
                        this.searchForm.orgNm = this.reqParam.orgNm
                        this.searchForm.orgLvl = this.reqParam.orgLvl
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        /* 내부조직팝업 - Icon 이벤트 처리 */
        onAuthOrgTreeIconClick() {
            this.resultAuthOrgTreeRows = []
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        /* 내부조직팝업 - TextField 엔터키 이벤트 처리 */
        onAuthOrgTreeEnterKey() {
            this.resultAuthOrgTreeRows = []
            if (_.isEmpty(this.reqParam.orgNm)) {
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return
            }
            this.getAuthOrgTreeList()
        },
        /* 내부조직팝업 - TextField Input 이벤트 이벤트 처리 */
        onAuthOrgTreeInput() {
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
        },
        /* 내부조직팝업 - 팝업 리턴 이벤트 이벤트 처리 */
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.orgLvl = _.get(returnData, 'orgLvl')
            this.searchForm.orgCd = this.reqParam.orgCd
            this.searchForm.orgNm = this.reqParam.orgNm
            this.searchForm.orgLvl = this.reqParam.orgLvl
        },
        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            this.searchForm.dealcoCd = this.reqParam.hldDealcoCd
            this.searchForm.dealcoNm = this.reqParam.hldDealcoNm
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.hldDealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.hldDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.dealcoNm)) {
                // this.searchForm.basDay = CommonUtil.replaceDash(this.rgstDt[1])
                this.getDealcosList()
                // this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.hldDealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-권한조직명 입력해주세요.'
                return
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.reqParam.hldDealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.reqParam.hldDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.hldDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================
    },
}
</script>
