export default {
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 30,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 30,
        totalPageCnt: 0,
        totalDataCnt: 0,
    }, //paging

    pagingDtl: {
        pageNum: 1, //fix
        pageSize: 0,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPagingDtl: {
        pageNum: 1, //fix
        pageSize: 30,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    saveAction: false,
    saveDoneA: false,
    saveDoneB: false,

    resultList: [],
    dltContent: [],
    resultDtlList: [],
    searchParams: {},
    searchParamsDtl: {},
    aprvTypNmList: [],

    requestParams: {},
    aprvUrlList: [], // 통합관리 urlList

    params: [],
}
