export default {
    getDefaultValue: function (flag) {
        console.log('accpaging')
        var val = ''
        // 한페이지당 보여줄 목록수
        if (flag == 'pageSize') {
            val = 15
        }
        // 페이지번호
        else if (flag == 'pageNum') {
            val = 1
        }
        // 이전페이지정보 초기화
        else if (flag == 'totalPage') {
            val = 0
        }

        return val
    },
    // searchAfter: function (gridObj, gridHeaderObj, gridData, pagingDto) {
    //     gridObj.setGridIndicator(pagingDto) //순번이 필요한경우 계산하는 함수
    //     gridData = this.gridSetData() //초기화
    //     gridData.totalPage = pagingDto.totalPageCnt // 총페이지수

    //     //Grid Row 가져올때 총건수 Setting
    //     gridHeaderObj.setPageCount(pagingDto)
    // },
}
