import { ValueType } from 'realgrid'

export const BasBcoProdAddresSrchGRID_HEADER = {
    fields: [
        {
            fieldName: 'addresName',
            dataType: ValueType.TEXT, //주소
        },
        {
            fieldName: 'gubun',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'selectDo',
            dataType: ValueType.TEXT, //시/도명
        },
        {
            fieldName: 'selectSi',
            dataType: ValueType.TEXT, //시/군/구명
        },
        {
            fieldName: 'stName',
            dataType: ValueType.TEXT, //도로명
        },
        {
            fieldName: 'bldName',
            dataType: ValueType.TEXT, //건물명
        },
    ],
    columns: [
        {
            name: 'addresName',
            fieldName: 'addresName',
            type: 'data',
            styleName: 'left-column',
            width: '240',
            header: {
                text: '주소',
                showTooltip: false,
            },
        },
        {
            name: 'gubun',
            fieldName: 'gubun',
            visible: false,
            type: 'data',
        },
        {
            name: 'selectDo',
            fieldName: 'selectDo',
            visible: false,
            type: 'data',
        },
        {
            name: 'selectSi',
            fieldName: 'selectSi',
            visible: false,
            type: 'data',
        },
        {
            name: 'stName',
            fieldName: 'stName',
            visible: false,
            type: 'data',
        },
        {
            name: 'bldName',
            fieldName: 'bldName',
            visible: false,
            type: 'data',
        },
    ],
}

export const BasBcoNewZipSrchGRID_HEADER = {
    fields: [
        {
            fieldName: 'rdAddr',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aftrAddr',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addr',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rdAddr1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rdAddr2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addrAftr1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addrAftr2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addrAftrEtc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'doNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ctNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bDngNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bRiNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lotSb',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lotMb',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hDngNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bldMb',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bldSb',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bldNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bldDng',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bldHo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bldFlr',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zipNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'basId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rdAddr',
            fieldName: 'rdAddr',
            type: 'data',
            styleName: 'left-column realgrid-pre-wrap',
            width: '240',
            header: {
                text: '도로명 주소',
                showTooltip: false,
            },
        },
        {
            name: 'aftrAddr',
            fieldName: 'aftrAddr',
            type: 'data',
            styleName: 'left-column realgrid-pre-wrap',
            width: '240',
            header: {
                text: '지번 주소',
                showTooltip: false,
            },
        },
        {
            name: 'addr',
            fieldName: 'addr',
            visible: false,
            type: 'data',
        },
        {
            name: 'rdAddr1',
            fieldName: 'rdAddr1',
            visible: false,
            type: 'data',
        },
        {
            name: 'rdAddr2',
            fieldName: 'rdAddr2',
            visible: false,
            type: 'data',
        },
        {
            name: 'addrAftr1',
            fieldName: 'addrAftr1',
            visible: false,
            type: 'data',
        },
        {
            name: 'addrAftr2',
            fieldName: 'addrAftr2',
            visible: false,
            type: 'data',
        },
        {
            name: 'addrAftrEtc',
            fieldName: 'addrAftrEtc',
            visible: false,
            type: 'data',
        },
        {
            name: 'doNm',
            fieldName: 'doNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'ctNm',
            fieldName: 'ctNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'bDngNm',
            fieldName: 'bDngNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'bRiNm',
            fieldName: 'bRiNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'lotSb',
            fieldName: 'lotSb',
            visible: false,
            type: 'data',
        },
        {
            name: 'lotMb',
            fieldName: 'lotMb',
            visible: false,
            type: 'data',
        },
        {
            name: 'hDngNm',
            fieldName: 'hDngNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'rdNm',
            fieldName: 'rdNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'bldMb',
            fieldName: 'bldMb',
            visible: false,
            type: 'data',
        },
        {
            name: 'bldSb',
            fieldName: 'bldSb',
            visible: false,
            type: 'data',
        },
        {
            name: 'bldNm',
            fieldName: 'bldNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'bldDng',
            fieldName: 'bldDng',
            visible: false,
            type: 'data',
        },
        {
            name: 'bldHo',
            fieldName: 'bldHo',
            visible: false,
            type: 'data',
        },
        {
            name: 'bldFlr',
            fieldName: 'bldFlr',
            visible: false,
            type: 'data',
        },
        {
            name: 'zipNum',
            fieldName: 'zipNum',
            visible: false,
            type: 'data',
        },
        {
            name: 'basId',
            fieldName: 'basId',
            visible: false,
            type: 'data',
        },
    ],
}
