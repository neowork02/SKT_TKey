<script>
export default {
    name: 'DatePicker',

    props: {
        value: { type: String, default: '', required: true },
        readonly: { type: Boolean, default: false, required: false },
        id: { type: String, default: '', required: false },
    },

    data() {
        return {
            dpMountYn: 'N',
            unformattedDate: this.value,
            formattedDate: this.value.replace(
                /(\d{4})(\d{2})(\d{2})/,
                '$1.$2.$3'
            ),
        }
    },

    watch: {
        value() {
            if (
                this.value.replace(/(\d{4})(\d{2})(\d{2})/, '$1.$2.$3') !==
                this.unformattedDate
            ) {
                this.unformattedDate = this.value.replace(
                    /(\d{4})(\d{2})(\d{2})/,
                    '$1.$2.$3'
                )
            }
        },
        readonly() {
            if (!this.readonly) {
                this.dpMount()
            } else {
                this.dpDestroy()
            }
        },
    },

    mounted() {
        if (!this.readonly) {
            this.dpMount()
        } else {
            this.dpDestroy()
        }

        // $(this.$refs.dp).daterangepicker(
        //   {
        //     singleDatePicker: true,
        //     showDropdowns: true,
        //     autoApply: true,
        //     locale: {
        //       format: 'YYYY.MM.DD'
        //     }
        //   },
        //   (s, e, l) => {
        //     this.unformattedDate = s.format('YYYYMMDD')
        //     this.$emit('input', this.unformattedDate)
        //   }
        // )
    },
    methods: {
        dpMount() {
            if (this.dpMountYn === 'Y') {
                return
            }
            /*
            $(this.$refs.dp).datepicker({
                dateFormat: 'yy.mm.dd',
                closeText: '닫기',
                prevText: '이전달',
                nextText: '다음달',
                currentText: '오늘',
                monthNames: [
                    '1월',
                    '2월',
                    '3월',
                    '4월',
                    '5월',
                    '6월',
                    '7월',
                    '8월',
                    '9월',
                    '10월',
                    '11월',
                    '12월',
                ],
                monthNamesShort: [
                    '1월',
                    '2월',
                    '3월',
                    '4월',
                    '5월',
                    '6월',
                    '7월',
                    '8월',
                    '9월',
                    '10월',
                    '11월',
                    '12월',
                ],
                dayNames: [
                    '일요일',
                    '월요일',
                    '화요일',
                    '수요일',
                    '목요일',
                    '금요일',
                    '토요일',
                ],
                dayNamesShort: ['일', '월', '화', '수', '목', '금', '토'],
                dayNamesMin: ['일', '월', '화', '수', '목', '금', '토'],
                weekHeader: '주',
                onSelect: (v) => {
                    this.unformattedDate = v.replaceAll('.', '')
                    this.$emit('input', this.unformattedDate)
                },
            })
            */
            this.dpMountYn = 'Y'
        },
        dpDestroy() {
            if (this.dpMountYn !== 'Y') {
                return
            }

            //$(this.$refs.dp).datepicker('destroy')
            this.dpMountYn = 'N'
        },
    },
}
</script>

<template>
    <div class="input_calendar mid">
        <input
            type="text"
            placeholder="연도/월/일"
            v-model="formattedDate"
            ref="dp"
            class="datepicker"
            :id="id"
            :readonly="readonly"
            autocomplete="off"
        />
        <button class="tbl_icon calendar">달력</button>
    </div>
</template>

<style>
.ui-datepicker .ui-state-default {
    border: 1px solid #ffffff !important;
    background: #ffffff !important;
    font-weight: normal;
    color: #454545;
    text-align: center !important;
}

.ui-datepicker .ui-state-active {
    background: #007fff !important;
}

.ui-datepicker .ui-datepicker-title {
    margin: 0 2.3em;
    line-height: 1.8em;
    text-align: center;
    font-size: 12.6px;
}
</style>
