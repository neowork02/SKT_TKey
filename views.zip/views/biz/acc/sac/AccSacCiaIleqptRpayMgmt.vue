<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccSacSaleCmmsAdpayMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <AccHeadline title="CIA미비 환수관리" />

        <AccSearchField
            ref="accSearchField"
            divideCellCount="3"
            :offset="[
                'btn-left-downloadForm',
                'btn-left-confirm',
                'btn-left-confirmCancel',
                'btn-right-reset',
                'btn-right-view',
                'btn-right-save',
                'btn-right-delete',
                'search-accMth',
                'search-orgCd',
                '!search-accDealcoCd',
                { slotSearch: 'search-barCdNum' },
                { slotSearch: 'search-backYn' },
                { slotSearch: 'search-ciaInsptClCd' },
            ]"
            :initValue="initValue"
            :popupParamOrgCd="popupParamOrgCd"
            :popupParamDealcoCd="popupParamDealcoCd"
            @changeAccMth="changeAccMth"
            @downloadForm="downloadForm"
            @confirm="confirmRow"
            @confirmCancel="confirmCancelForm"
            @reset="resetForm"
            @view="viewForm"
            @save="saveForm"
            @delete="deleteForm"
        >
            <template slot="search-barCdNum" slot-scope="slotProps">
                <div
                    class="formitem"
                    :class="`div${slotProps.divideCellCount}`"
                >
                    <TCComInput
                        labelName="계약서번호"
                        v-model="formGetCiaBacks.query.barCdNum"
                    />
                </div>
            </template>
            <template slot="search-backYn" slot-scope="slotProps">
                <div
                    class="formitem"
                    :class="`div${slotProps.divideCellCount}`"
                >
                    <TCComRadioBox
                        labelName="환수구분"
                        col="4"
                        v-model="formGetCiaBacks.query.backYn"
                        itemText="label"
                        itemValue="value"
                        :itemList="[
                            {
                                label: 'Y',
                                value: 1,
                            },
                            {
                                label: 'N',
                                value: 0,
                            },
                        ]"
                    ></TCComRadioBox>
                </div>
            </template>
            <template slot="search-ciaInsptClCd" slot-scope="slotProps">
                <div
                    class="formitem"
                    :class="`div${slotProps.divideCellCount}`"
                >
                    <TCComRadioBox
                        labelName="CIA심사구분"
                        col="4"
                        v-model="formGetCiaBacks.query.ciaInsptClCd"
                        itemText="label"
                        itemValue="value"
                        :itemList="[
                            {
                                label: '무선',
                                value: 1,
                            },
                            {
                                label: '유선',
                                value: 0,
                            },
                        ]"
                    ></TCComRadioBox>
                </div>
            </template>
        </AccSearchField>

        <AccGridTable
            ref="accGridTable"
            isCheckbox
            isEditable
            isColumnNo
            :offset="['btn-excelUpload', 'btn-excelDownload']"
            :gridMeta="GRID_HEADER"
            :data="formGetCiaBacks.data"
            :pagingInfo="formGetCiaBacks.pagingInfo"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/sac/cia-backs-excel-download`,
                query: formGetCiaBacks.query,
            }"
            @excelUpload="excelUpload"
            @movePage="movePage"
            @changePageSize="changePageSize"
        />
    </div>
</template>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import { getTodayDate, errorHandle, gridMetaUtil } from '@/utils/accUtil'

import AccHeadline from '@/components/biz/common/acc/AccHeadline'
import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import sacApi from '@/api/biz/acc/sac'
import attachApi from '@/api/common/attachedFile'

import {
    GRID_HEADER,
    MOCK_DATA,
} from '@/const/grid/acc/sac/AccSacCiaIleqptRpayMgmtGrid'

export default {
    name: 'AccSacSaleCmmsAdpayMgmt',
    mixins: [CommonMixin, accMixin],
    components: {
        AccHeadline,
        AccSearchField,
        AccGridTable,
    },
    data() {
        return {
            GRID_HEADER,

            initValue: {
                accMth: getTodayDate('YYYY-MM'),
                orgNm: 'PS&Marketing',
                orgCd: 'O00000',
                pageSize: 15,
                pageNum: 1,
            },

            formGetCiaBacks: {
                data: [],
                query: {},
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formPostCiaBacks: {
                query: {},
            },

            formDeleteCiaBacks: {
                query: {},
            },

            formPostFixBacks: {
                query: {},
            },

            formPostAccSacAccsExcelUpload: {
                query: {},
            },

            popupParamOrgCd: {
                basMth: '',
            },
            popupParamDealcoCd: {},
        }
    },

    computed: {
        accGridTable() {
            return this.$refs.accGridTable
        },
    },

    created() {
        this.initPage()
        console.log(sacApi, MOCK_DATA)
    },

    methods: {
        initPage() {
            // @TODO 권한이 정리된 후, 사용자에 따라 권한설정. CRUD
        },

        resetForm(query) {
            this.formGetCiaBacks.query = query
            this.formGetCiaBacks.data = []
        },

        viewForm(query) {
            // searchCoClOrgCd: O00000, // 조직
            // accMth: 202005, // 정산월
            // accPlc: 1, // 정산처
            // barCdNum: S0029707066, // 계약서 번호
            // backYn: 1, // 환수구분
            // ciaInsptClCd: 1 // 무선,유선

            if (!query.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }

            if (!query.accMth) {
                return this.showTcComAlert('정산월을 입력하십시오.')
            }

            Object.assign(this.formGetCiaBacks.query, query)
            this.getCiaBacks()
        },

        saveForm() {
            const rows = this.accGridTable.getChangedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`수정된 항목이 없습니다.`)
            } else {
                const invalidList = []
                rows.forEach((row) => {
                    if (row.backYn == 'N' && !row.rmks) {
                        invalidList.push({
                            msg: `환수적용여부가 N일 경우는 비고에 사유를 입력해야 합니다.`,
                            list: row,
                        })
                    }

                    if (!row.ciaInsptClCd) {
                        invalidList.push({
                            msg: `정산처[${row.accPlcNm}]의 CIA심사구분을 확인하십시오.`,
                            list: row,
                        })
                    }
                })

                if (invalidList.length) {
                    return invalidList.forEach((arr) =>
                        this.showTcComAlert(arr.msg)
                    )
                }

                this.formPostCiaBacks.query.ciaBackVoList = rows
                this.postCiaBacks().then(this.getCiaBacks)
            }
        },

        async deleteForm() {
            const rows = this.accGridTable.getCheckedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                const invalidList = []
                rows.forEach((row) => {
                    if (row.fixYn == 'Y') {
                        invalidList.push({
                            msg: '확정이 완료된 데이터는 삭제할 수 없습니다',
                            list: row,
                        })
                    }
                })

                if (invalidList.length) {
                    return invalidList.forEach((arr) =>
                        this.showTcComAlert(arr.msg)
                    )
                }

                if (
                    await this.showTcComConfirm(
                        '선택한 데이터를 삭제하시겠습니까?'
                    )
                ) {
                    this.formDeleteCiaBacks.query.ciaBackVoList = rows
                    return this.deleteCiaBacks().then(this.getCiaBacks)
                } else {
                    return this.showTcComAlert(`삭제가 취소되었습니다`)
                }
            }
        },

        confirmRow() {
            const rows = this.accGridTable.getCheckedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                const invalidList = []
                rows.forEach((row) => {
                    if (row.fixYn == 'Y') {
                        invalidList.push({
                            msg: `정산처[${row.accPlcNm}](은)는 확정이 이미 완료되었습니다`,
                            list: row,
                        })
                    }

                    if (row.backYn == 'N' && !row.rmks) {
                        invalidList.push({
                            msg: `환수적용여부가 N일 경우는 비고에 사유를 입력해야 합니다`,
                            list: row,
                        })
                    }

                    if (!row.ciaInsptClCd) {
                        invalidList.push({
                            msg: `정산처[${row.accPlcNm}]의 CIA심사구분을 확인하십시오`,
                            list: row,
                        })
                    }
                })

                if (invalidList.length) {
                    return invalidList.forEach((arr) =>
                        this.showTcComAlert(arr.msg)
                    )
                }

                this.formPostFixBacks.query.ciaBackVoList = rows
                return this.postFixBacks().then(this.getCiaBacks)
            }
        },

        confirmCancelForm() {
            const rows = this.accGridTable.getCheckedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                const invalidList = []
                rows.forEach((row) => {
                    if (row.fixYn == 'N') {
                        invalidList.push({
                            msg: `정산처[${row.accPlcNm}](은)는 확정되지 않았습니다`,
                            list: row,
                        })
                    }
                })

                if (invalidList.length) {
                    return invalidList.forEach((arr) =>
                        this.showTcComAlert(arr.msg)
                    )
                }

                this.formPostFixCancelBacks.query.ciaBackVoList = rows
                return this.postFixCancelBacks().then(this.getCiaBacks)
            }
        },

        downloadForm() {
            attachApi.downloadSampleFile('404')
        },

        excelUpload(xlsData) {
            const row = gridMetaUtil.xlsToGridData(this.GRID_HEADER, xlsData)
            this.formGetCiaBacks.data = row
            this.formGetCiaBacks.pagingInfo = {}
        },

        changeAccMth(date) {
            this.popupParamOrgCd.basMth = date
            this.popupParamDealcoCd.basDay = date
        },

        movePage(query) {
            Object.assign(this.formGetCiaBacks.query, query)
            this.getCiaBacks()
        },

        changePageSize(query) {
            this.accSearchField.setQuery(query)
            // Object.assign(this.formGetCiaBacks.query, query)
        },

        getCiaBacks() {
            // console.log('조회쿼리 =>', this.formGetCiaBacks.query)

            // this.formGetCiaBacks.data = [
            //     ...MOCK_DATA['accSacCiaIleqptRpayMgmtGridList'].gridList,
            // ]
            // this.formGetCiaBacks.pagingInfo =
            //     MOCK_DATA['accSacCiaIleqptRpayMgmtGridList'].pagingDto
            // return Promise.resolve()

            return sacApi
                .getCiaBacks(this.formGetCiaBacks.query)
                .then((res) => {
                    if (!res['accSacCiaIleqptRpayMgmtGridList']) return

                    this.formGetCiaBacks.data = [
                        ...res['accSacCiaIleqptRpayMgmtGridList'].gridList,
                    ]
                    this.formGetCiaBacks.pagingInfo =
                        res['accSacCiaIleqptRpayMgmtGridList'].pagingDto
                })
                .catch(errorHandle)
        },

        postCiaBacks() {
            return sacApi
                .postCiaBacks(this.formPostCiaBacks.query)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
                .catch(errorHandle)
        },

        deleteCiaBacks() {
            return sacApi
                .deleteCiaBacks(this.formDeleteCiaBacks.query)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
                .catch(errorHandle)
        },

        postFixBacks() {
            return sacApi
                .postFixBacks(this.formPostFixBacks.query)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
                .catch(errorHandle)
        },

        postFixCancelBacks() {
            return sacApi
                .postFixCancelBacks(this.formPostFixCancelBacks.query)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
                .catch(errorHandle)
        },
    },
}
</script>
