<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: Swing리포트
 * 설명: Swing리포트 조회
 * 작성자: P180190
 * 작성일: 2022.07.12
------------------------------------------------>
<template>
    <div class="content">
        <h1>Swing리포트</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onReset"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        v-model="searchParams.searchAccYm_"
                    >
                    </TCComDatePicker>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCComTab
                :tab.sync="tab.tabSync1"
                :items="['Template0', 'Template1', 'Template2', 'Template3']"
                :itemName="[
                    '영업월별집계목록',
                    '영업장별지급조정',
                    '위탁수수료',
                    '공제내역',
                ]"
                @click="onActiveTabClick"
                @change="onActiveTabChange"
                :cKey="0"
                sliderSize="8"
            >
                <template #Template0>
                    <TCRealGridHeader
                        id="gridHeader0"
                        ref="gridHeader0"
                        gridTitle="영업월별집계목록"
                        :gridObj="gridObj0"
                        :isPageRows="true"
                        :isNextPage="true"
                        :isPageCnt="true"
                        :isExceldown="true"
                        @excelDownBtn="downloadExcelAll(0)"
                    >
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid0"
                        ref="grid0"
                        :fields="view.fields0"
                        :columns="view.columns0"
                        :styles="gridStyle"
                    />
                    <TCComPaging
                        :totalPage="gridData0.totalPage"
                        :apiFunc="getSaleMthList"
                        :rowCnt="rowCnt0"
                        @input="chgRowCnt0"
                    />
                </template>
                <template #Template1>
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="영업장별지급조정"
                        :gridObj="gridObj1"
                        :isPageRows="true"
                        :isNextPage="true"
                        :isPageCnt="true"
                        :isExceldown="true"
                        @excelDownBtn="downloadExcelAll(1)"
                    >
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :fields="view.fields1"
                        :columns="view.columns1"
                        :styles="gridStyle"
                        @hook:mounted="tabGridMounted1"
                    />
                    <TCComPaging
                        :totalPage="gridData1.totalPage"
                        :apiFunc="getBrPayAdjList"
                        :rowCnt="rowCnt1"
                        @input="chgRowCnt1"
                    />
                </template>
                <template #Template2>
                    <TCRealGridHeader
                        id="gridHeader2"
                        ref="gridHeader2"
                        gridTitle="위탁수수료"
                        :gridObj="gridObj2"
                        :isPageRows="true"
                        :isNextPage="true"
                        :isPageCnt="true"
                        :isExceldown="true"
                        @excelDownBtn="downloadExcelAll(2)"
                    >
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid2"
                        ref="grid2"
                        :fields="view.fields2"
                        :columns="view.columns2"
                        :styles="gridStyle"
                        @hook:mounted="tabGridMounted2"
                    />
                    <TCComPaging
                        :totalPage="gridData2.totalPage"
                        :apiFunc="getConsignCmmsList"
                        :rowCnt="rowCnt2"
                        @input="chgRowCnt2"
                    />
                </template>
                <template #Template3>
                    <TCRealGridHeader
                        id="gridHeader3"
                        ref="gridHeader3"
                        gridTitle="공제내역"
                        :gridObj="gridObj3"
                        :isPageRows="true"
                        :isNextPage="true"
                        :isPageCnt="true"
                        :isExceldown="true"
                        @excelDownBtn="downloadExcelAll(3)"
                    >
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid3"
                        ref="grid3"
                        :fields="view.fields3"
                        :columns="view.columns3"
                        :styles="gridStyle"
                        @hook:mounted="tabGridMounted3"
                    />
                    <TCComPaging
                        :totalPage="gridData3.totalPage"
                        :apiFunc="getDedtDtlList"
                        :rowCnt="rowCnt3"
                        @input="chgRowCnt3"
                    />
                </template>
            </TCComTab>
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
import { CommonGrid, CommonMsg, CommonUtil } from '@/utils'
import moment from 'moment'
import swingApi from '@/api/biz/acc/sss/AccSssSwingRpt'
import { GRID_HEADER } from '@/const/grid/acc/sss/AccSssSwingRptGrid'
import CommonMixin from '@/mixins'

export default {
    name: 'AccSssSwingRpt',
    title: 'Swing리포트',
    mixins: [CommonMixin],
    components: {},
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            tabDefault: {},

            tab: {
                nowIndex: 0,
                tabSync1: 0,
            },

            //tab0
            list0: [],
            gridObj0: {},
            gridHeaderObj0: {},
            gridData0: {},
            rowCnt0: 15,

            //tab1
            list1: [],
            gridObj1: {},
            gridHeaderObj1: {},
            gridData1: {},
            rowCnt1: 15,

            //tab2
            list2: [],
            gridObj2: {},
            gridHeaderObj2: {},
            gridData2: {},
            rowCnt2: 15,

            //tab3
            list3: [],
            gridObj3: {},
            gridHeaderObj3: {},
            gridData3: {},
            rowCnt3: 15,

            /*그리드 스타일*/
            gridStyle: {
                height: '330px', //그리드 높이 조절
            },
            searchForms: {},

            searchParams: {
                searchAccYm_: moment(new Date()).format('YYYY-MM') /*정산월*/,
                searchAccYm: moment(new Date()).format(
                    'YYYYMM'
                ) /*정산월(날짜format제거)*/,
            },
        }
    },
    watch: {
        'searchParams.searchAccYm_'(newVal) {
            this.searchParams.searchAccYm = newVal
            if (!_.isEmpty(newVal)) {
                this.searchParams.searchAccYm = newVal.replace(/-/g, '')
                //searchAccYm_ 변경되면 searchAccYm 세팅
            }
        },
    },
    created() {
        this.gridData0 = this.gridSetData0()
        this.gridData1 = this.gridSetData1()
        this.gridData2 = this.gridSetData2()
        this.gridData3 = this.gridSetData3()
    },
    mounted() {
        // 초기화를 위해 초기값 변수에 저장하기
        this.tabDefault = _.cloneDeep(this.tab)
        this.searchParamsDefault = _.cloneDeep(this.searchParams)

        // tab0 그리드 mounted
        this.gridObj0 = this.$refs.grid0
        this.gridHeaderObj0 = this.$refs.gridHeader0
        this.$refs.grid0.setGridState(false, false, false, false)

        this.tab.nowIndex = 0
        this.tab.tabSync1 = 0
        this.searchParams.searchTabIndex = 0
    },
    methods: {
        // 텝 선택시 그리드 mounted
        tabGridMounted1() {
            this.gridObj1 = this.$refs.grid1
            this.gridHeaderObj1 = this.$refs.gridHeader1
            this.$refs.grid1.setGridState(false, false, false, false)
        },
        tabGridMounted2() {
            this.gridObj2 = this.$refs.grid2
            this.gridHeaderObj2 = this.$refs.gridHeader2
            this.$refs.grid2.setGridState(false, false, false, false)
        },
        tabGridMounted3() {
            this.gridObj3 = this.$refs.grid3
            this.gridHeaderObj3 = this.$refs.gridHeader3
            this.$refs.grid3.setGridState(false, false, false, false)
        },

        gridSetData0() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, this.rowCnt0, '', '')
        },

        gridSetData1() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, this.rowCnt1, '', '')
        },

        gridSetData2() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, this.rowCnt2, '', '')
        },

        gridSetData3() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, this.rowCnt3, '', '')
        },

        //페이지 표시 행의수 변경처리
        chgRowCnt0(val) {
            this.rowCnt0 = val
        },
        chgRowCnt1(val) {
            this.rowCnt1 = val
        },
        chgRowCnt2(val) {
            this.rowCnt2 = val
        },
        chgRowCnt3(val) {
            this.rowCnt3 = val
        },

        onActiveTabClick(tabIndex) {
            this.tab.nowIndex = tabIndex
            console.log(tabIndex)
        },

        // 초기화
        onReset: function () {
            // 첫Tab으로 다시 이동시키기
            this.tab.tabSync1 = 0

            // 변수 초기화
            this.searchParams = _.cloneDeep(this.searchParamsDefault)
            this.tab = _.cloneDeep(this.tabDefault)

            this.searchParams.searchTabIndex = this.tab.nowIndex

            //tab0 엘리먼트 초기화 & 그리드 초기화
            CommonUtil.clearPage(this, 'searchParams', this.gridObj0)
            this.gridData0 = {} //페이징 번호
            this.gridHeaderObj0.setPageCount(0) // 헤더 총데이터수

            //tab1
            CommonUtil.clearPage(this, 'searchParams', this.gridObj1)
            this.gridData1 = {} //페이징 번호
            this.gridHeaderObj1.setPageCount(0) // 헤더 총데이터수

            //tab2
            CommonUtil.clearPage(this, 'searchParams', this.gridObj2)
            this.gridData2 = {} //페이징 번호
            this.gridHeaderObj2.setPageCount(0) // 헤더 총데이터수

            //tab3
            CommonUtil.clearPage(this, 'searchParams', this.gridObj3)
            this.gridData3 = {} //페이징 번호
            this.gridHeaderObj3.setPageCount(0) // 헤더 총데이터수
        },

        setListGrid0: function (gridList, totalPageCnt, totalDataCnt) {
            this.gridObj0.setRows(gridList) // 그리드에 set
            this.gridData0 = this.gridSetData0() //
            this.gridData0.totalPage = totalPageCnt // 총페이지수
            this.gridHeaderObj0.setPageCount(totalDataCnt) // 총데이터수
        },
        setListGrid1: function (gridList1, totalPageCnt1, totalDataCnt1) {
            this.gridObj1.setRows(gridList1) // 그리드에 set
            this.gridData1 = this.gridSetData1()
            this.gridData1.totalPage = totalPageCnt1 // 총페이지수
            this.gridHeaderObj1.setPageCount(totalDataCnt1) // 총데이터수
        },

        setListGrid2: function (gridList2, totalPageCnt2, totalDataCnt2) {
            this.gridObj2.setRows(gridList2) // 그리드에 set
            this.gridData2 = this.gridSetData2()
            this.gridData2.totalPage = totalPageCnt2 // 총페이지수
            this.gridHeaderObj2.setPageCount(totalDataCnt2) // 총데이터수
        },
        setListGrid3: function (gridList3, totalPageCnt3, totalDataCnt3) {
            this.gridObj3.setRows(gridList3) // 그리드에 set
            this.gridData3 = this.gridSetData3()
            this.gridData3.totalPage = totalPageCnt3 // 총페이지수
            this.gridHeaderObj3.setPageCount(totalDataCnt3) // 총데이터수
        },

        // 정산월 입력 여부
        searchValidate: function () {
            var isResult = true
            if (_.isEmpty(this.searchParams.searchAccYm_)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_01001'))
                isResult = false
            }
            return isResult
        },

        //================================================
        // :::: 전체 조회 ::::
        //================================================
        onSearch: function () {
            if (this.searchValidate() == false) {
                return
            }
            this.searchParams.searchTabIndex = this.tab.nowIndex
            this.searchParams.rowCnt0 = this.gridData0.rowCnt0
            this.searchParams.rowCnt1 = this.gridData1.rowCnt1
            this.searchParams.rowCnt2 = this.gridData2.rowCnt2
            this.searchParams.rowCnt3 = this.gridData3.rowCnt3
            if (this.tab.nowIndex == 0) {
                this.searchParams.pageSize = this.rowCnt0
                this.getSaleMthList(this.searchParams.rowCnt0)
            }
            if (this.tab.nowIndex == 1) {
                this.searchParams.pageSize = this.rowCnt1
                this.getBrPayAdjList(this.searchParams.rowCnt1)
            }
            if (this.tab.nowIndex == 2) {
                this.searchParams.pageSize = this.rowCnt2
                this.getConsignCmmsList(this.searchParams.rowCnt2)
            }
            if (this.tab.nowIndex == 3) {
                this.searchParams.pageSize = this.rowCnt3
                this.getDedtDtlList(this.searchParams.rowCnt3)
            }

            // console.log('searchParams::::', searchParams)
        },
        // 영업월별집계목록 조회
        getSaleMthList(page) {
            this.searchParams.pageNum = page
            swingApi.getSaleMthList(this.searchParams).then((res0) => {
                if (res0) {
                    console.log('res0:::::::', res0)
                    this.list0 = res0
                    this.setListGrid0(
                        res0.gridList,
                        res0.pagingDto.totalPageCnt,
                        res0.pagingDto
                    )
                }
            })
        },
        // 영업장별지급조정
        getBrPayAdjList(page) {
            this.searchParams.pageNum = page
            swingApi.getBrPayAdjList(this.searchParams).then((res1) => {
                if (res1) {
                    console.log('res1:::::::', res1)
                    this.list1 = res1
                    this.setListGrid1(
                        res1.gridList,
                        res1.pagingDto.totalPageCnt,
                        res1.pagingDto
                    )
                }
            })
        },
        // 위탁수수료
        getConsignCmmsList(page) {
            this.searchParams.pageNum = page
            swingApi.getConsignCmmsList(this.searchParams).then((res2) => {
                if (res2) {
                    console.log('res2:::::::', res2)
                    this.list2 = res2
                    this.setListGrid2(
                        res2.gridList,
                        res2.pagingDto.totalPageCnt,
                        res2.pagingDto
                    )
                }
            })
        },
        // 공제내역
        getDedtDtlList(page) {
            this.searchParams.pageNum = page
            swingApi.getDedtDtlList(this.searchParams).then((res3) => {
                if (res3) {
                    console.log('res3:::::::', res3)
                    this.list3 = res3
                    this.setListGrid3(
                        res3.gridList,
                        res3.pagingDto.totalPageCnt,
                        res3.pagingDto
                    )
                }
            })
        },

        //================================================
        // EXCEL DOWNLOAD
        //================================================
        downloadExcelAll: function (tabNum) {
            swingApi.downloadSwingReportListExcel(this.searchParams, tabNum)
        },

        onActiveTabChange(tabIdx) {
            this.tab.nowIndex = tabIdx
            console.log(tabIdx)
        },
    },
}
</script>
