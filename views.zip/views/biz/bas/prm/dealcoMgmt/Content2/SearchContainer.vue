<template>
    <div>
        <!-- //================================버튼========================== -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="this.objAuth"
                    >초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchDataHstLst"
                    :objAuth="this.objAuth"
                    >이력조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                    >조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="newBtn"
                    :objAuth="this.objAuth"
                    >신규
                </TCComButton>
                <RgstPopup
                    v-if="rgstDialogShow"
                    ref="popup"
                    :dialogShow.sync="rgstDialogShow"
                />
            </li>
        </ul>
        <!-- //================================//버튼========================== -->
        <!-- //================================searchLayer_wrap========================== -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <!-- 소속조직 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchParam.orgNm"
                        :codeVal.sync="searchParam.orgCd"
                        labelName="소속조직"
                        placeholder="선택해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //소속조직 -->
                <!-- 거래처등록구분 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="searchParam.dealcoRgstClCd"
                        :eRequired="true"
                        labelName="거래처등록구분"
                        :itemList="dealcoRgstClCdList"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :filterFunc="filterRgstClCd"
                        @change="setDealcoGrpCd"
                    ></TCComComboBox>
                </div>
                <!-- //거래처등록구분 -->
                <!-- 거래처그룹 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="searchParam.dealcoGrpCd"
                        :eRequired="true"
                        labelName="거래처그룹"
                        :itemList="dealcoGrpCdList"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        @change="setDealcoClCd1"
                    ></TCComComboBox>
                </div>
                <!-- //거래처그룹 -->
                <!-- 거래처구분 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="searchParam.dealcoClCd1"
                        labelName="거래처구분"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="objAuth"
                        :itemList="dealcoClCd1List"
                        @change="changeDealcoCl2"
                    ></TCComComboBox>
                </div>
                <!-- //거래처구분 -->
            </div>
            <div class="searchform">
                <!-- 거래처유형 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="searchParam.dealcoClCd2"
                        labelName="거래처유형"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="objAuth"
                        :itemList="dealcoCl2List"
                    ></TCComComboBox>
                </div>
                <!-- //거래처유형 -->
                <!-- 거래상태 CTRL_RSN_CD -->
                <div class="formitem div4">
                    <TCComMultiComboBox
                        v-model="searchParam.dealStatus"
                        labelName="거래상태"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :itemList="zbasC00120"
                        :filterFunc="filterRsnCd"
                        :objAuth="objAuth"
                        @change="changeRsnCd"
                    ></TCComMultiComboBox>
                </div>
                <!-- //거래상태 -->
                <!-- I/F -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="searchParam.ifYn"
                        labelName="I/F"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="objAuth"
                        :itemList="comYn"
                    ></TCComComboBox>
                </div>
                <!-- //I/F -->
                <!-- 거래처코드 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="searchParam.dealcoCd"
                        labelName="거래처코드"
                        :objAuth="objAuth"
                        @enterKey="searchBtn"
                    ></TCComInput>
                </div>
                <!-- //거래처코드 -->
            </div>
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{ ' btn_ty_exp_active ': active }"
                        @click="active = !active"
                    ></v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="active">
                    <div class="searchform">
                        <!-- 거래처명 -->
                        <div class="formitem div4">
                            <TCComInput
                                v-model="searchParam.dealcoNm"
                                labelName="거래처명"
                                :objAuth="objAuth"
                                @enterKey="searchBtn"
                            ></TCComInput>
                        </div>
                        <!-- //거래처명 -->
                        <!-- 사업자번호 -->
                        <div class="formitem div4">
                            <TCComInput
                                v-model="searchParam.bizNo"
                                :maxlength="12"
                                labelName="사업자번호"
                                :objAuth="objAuth"
                                @enterKey="searchBtn"
                            ></TCComInput>
                        </div>
                        <!-- //사업자번호 -->
                        <!-- P코드 -->
                        <div class="formitem div4">
                            <TCComInput
                                v-model="searchParam.sktChnlCd"
                                labelName="P코드"
                                :objAuth="objAuth"
                                @enterKey="searchBtn"
                            ></TCComInput>
                        </div>
                        <!-- //P코드 -->
                        <!-- 담보최종등록 -->
                        <div class="formitem div4">
                            <TCComCheckBox
                                v-model="searchParam.lastMrtg"
                                labelName="담보최종등록"
                                :itemList="[
                                    { commCdVal: 'Y', commCdValNm: '' },
                                ]"
                                :objAuth="objAuth"
                            ></TCComCheckBox>
                        </div>
                        <!-- //담보최종등록 -->
                    </div>
                    <div class="searchform">
                        <!-- 휴폐업상태 -->
                        <div class="formitem div4">
                            <TCComComboBox
                                v-model="searchParam.spClsBizClCd"
                                labelName="휴폐업상태"
                                :itemList="spClsBizClCd"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                                :objAuth="objAuth"
                            ></TCComComboBox>
                        </div>
                        <!-- //휴폐업상태 -->
                        <!-- 조회일자 -->
                        <div class="formitem div2">
                            <div class="arrayType">
                                <div class="col35">
                                    <TCComComboBox
                                        labelName="조회일자"
                                        v-model="searchParam.dealEndYn"
                                        :itemList="searchDealEnd"
                                        :addBlankItem="true"
                                        blankItemText="전체"
                                        blankItemValue=""
                                        :objAuth="objAuth"
                                    ></TCComComboBox>
                                </div>
                                <div class="col60 mgl">
                                    <TCComDatePicker
                                        calType="DP"
                                        labelName=""
                                        v-model="dtm"
                                    />
                                </div>
                            </div>
                        </div>

                        <!--
<div class="formitem div5">
    <TCComDatePicker
        calType="D"
        v-model="searchParam.dtmFrom"
    >
    </TCComDatePicker>
</div>
~
<div class="formitem div5">
    <TCComDatePicker
        calType="D"
        v-model="searchParam.dtmTo"
    >
    </TCComDatePicker>
</div>
-->
                        <!-- //조회일자 -->
                        <!-- 검색대상 -->
                        <div class="formitem div2">
                            <div class="arrayType">
                                <div class="col35">
                                    <TCComComboBox
                                        labelName="검색대상"
                                        v-model="searchParam.searchTarget"
                                        :itemList="searchType"
                                        :addBlankItem="true"
                                        blankItemText="전체"
                                        blankItemValue=""
                                        :objAuth="objAuth"
                                    ></TCComComboBox>
                                </div>
                                <div class="col0">
                                    <TCComNoLabelInput
                                        v-model="searchParam.srchValue"
                                        :objAuth="objAuth"
                                        @enterKey="searchBtn"
                                    ></TCComNoLabelInput>
                                </div>
                                <div class="col0">
                                    <!-- 메세지 -->
                                    <span class="basicTxt">
                                        (검색대상→배송처,CAT
                                        ID,계좌,정산처,대표자)
                                    </span>
                                    <!-- //메세지 -->
                                </div>
                            </div>
                        </div>
                        <!-- //검색대상 -->
                    </div>
                </div>
            </v-expand-transition>
        </div>
        <!-- //================================//searchLayer_wrap========================== -->
    </div>
</template>

<script>
//================================공통기능==========================
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/tDealcoMgmt/helpers'
import { CommonGrid } from '@/utils'
import commonApi from '@/api/common/prototype'
import { msgTxt } from '@/const/msg.Properties'
import CommonUtil from '@/utils/CommonUtil'
import RgstPopup from './PopupContainer.vue'
import CommonMixin from '@/mixins'
import _ from 'lodash'
//================================//공통기능==========================

//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================

export default {
    components: {
        BasBcoAuthOrgTreesPopup,
        RgstPopup,
    },
    mixins: [CommonMixin],
    async created() {
        await this.initControls()
        await this.initData()
        // code 호출 후 store 적재
        await this.getCodeList()
    },
    data() {
        return {
            //====================공통기능====================
            objAuth: {},
            gridHeaderObj: {},
            gridObj: {},
            active: false,
            gridData: this.gridSetData(),
            rgstDialogShow: false,

            dealcoRgstClCdList: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처등록구분
            dealcoGrpCdList: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처그룹
            dealcoGrp: [{ commCdVal: '', commCdValNm: '선택' }], // 거래상태
            zbasC00240: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처구분
            zbasC00570: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처유형(직영점)
            zbasC00110: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처유형
            zbasC00120: [{ commCdVal: '', commCdValNm: '전체' }], // 거래상태
            spClsBizClCd: [{ commCdVal: '', commCdValNm: '전체' }], // 휴폐업상태
            comYn: [{ commCdVal: '', commCdValNm: '전체' }], // 사용여부
            dealcoClCd1List: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처구분
            dealcoCl2CodeData: '', // 거래처유형
            dealcoCl2List: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처유형
            searchParam: {
                deal_status_list: '', // 거래상태리스트
                sknDlvDealCoCd: '',
                dealcoGrpCd: '',
                dealcoRgstClCd: '',
                ifYn: '',
                acntNo: '',
                dealcoClCd1: '',
                dealcoClCd2: '',
                dealcoNm: '',
                dealcoCd: '',
                bizNo: '',
                sktChnlCd: '',
                accDealcoCd: '',
                repUserNm: '',
                searchGb: '',
                dtmFrom: '',
                dtmTo: '',
                catId: '',
                dealStatus: [],
                dealEndYn: '',
                lastMrtg: [],
                searchTarget: '',
                spClsBizClCd: '',
                orgCd: '',
                orgLvl: '',
                srchValue: '',
            },
            dtm: [],
            isDisabledDealcoCl2: true,

            searchDealEnd: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '거래개시일',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '거래종료일',
                },
            ],

            searchType: [
                {
                    commCdVal: '1',
                    commCdValNm: '배송처코드',
                },
                {
                    commCdVal: '2',
                    commCdValNm: 'CAT ID',
                },
                {
                    commCdVal: '3',
                    commCdValNm: '계좌번호',
                },
                {
                    commCdVal: '4',
                    commCdValNm: '정산처코드',
                },
                {
                    commCdVal: '5',
                    commCdValNm: '대표자명',
                },
            ],
            //====================//공통기능==================
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            headerText: '',
            //====================//내부조직팝업(권한)팝업관련==================
            isChk: false,
        }
    },
    computed: {
        ...serviceComputed,
        paging1: {
            get() {
                return this.paging
            },
        },
        initPaging1: {
            get() {
                return this.initPaging
            },
        },
    },
    methods: {
        //====================공통기능 methods====================
        ...serviceMethods,
        async initControls() {},
        async initData() {
            this.initParam()
            this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            this.defaultAssign_({
                key: 'paging_2',
                value: this.initPaging_2,
            })
            this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
            this.defaultAssign_({
                key: 'resultList_2',
                value: [],
            })
            this.defaultAssign_({
                key: 'searchParams',
                value: [],
            })
            this.defaultAssign_({
                key: 'hstInfo',
                value: {},
            })
            this.defaultAssign_({
                key: 'hstInfo2',
                value: {},
            })
        },
        initParam() {
            this.searchParam = {
                pageSize: '30',
                pageNum: 1,
                dealStatus: ['1'],
                dealEndYn: '',
                lastMrtg: [],
                searchTarget: '',
                spClsBizClCd: '',
                dealcoGrpCd: '',
                dealcoRgstClCd: '',
                ifYn: '',
                dealcoClCd1: '',
                dealcoClCd2: '',
                dtmFrom: '',
                dtmTo: '',
                sktChnlCd: '',
                orgCd: this.orgInfo.orgCd,
                orgLvl: this.orgInfo.orgLvl,
                orgNm: this.orgInfo.orgNm,
                srchValue: '',
                dealcoCd: this.userInfo.dealcoCd,
                dealcoNm: this.userInfo.dealcoNm,
            }
            this.dtm = [this.searchParam.dtmFrom, this.searchParam.dtmTo]
        },
        filterRgstClCd(items) {
            return items.filter((item) => !_.isEqual(item['addInfo1'], 'ETC'))
        },
        filterRsnCd(items) {
            return items.filter((item) => !_.isEqual(item['commCdVal'], '7'))
        },
        changeRsnCd(items) {
            _.forEach(items, (data) => {
                if (_.isEqual(data, '')) {
                    this.isChk = true
                    this.searchParam.dealStatus = []
                    this.searchParam.dealStatus[0] = ''
                } else if (!_.isEqual(data, '')) {
                    if (this.isChk) {
                        this.isChk = false
                        this.searchParam.dealStatus = []
                        this.searchParam.dealStatus[0] = data
                    }
                } else {
                    this.isChk = false
                }
            })
        },
        /////////////////////////
        getFilterCode(codeList, info, filterCode) {
            let rtnCode = []
            _.forEach(codeList, (data) => {
                if (_.isEqual(data[info], filterCode)) {
                    rtnCode.push(data)
                }
            })
            return rtnCode
        },
        /**
         * 거래처그룹코드 셋팅
         * DC : 매장공통
         * DS : 매장개별
         * EC : 기타공통
         * ES : 기타개별
         * @param dealcoRgstClCd : 거래처등록구분코드
         */
        async setDealcoGrpCd(dealcoRgstClCd) {
            let dealcoGrpCds = [{ commCdVal: '', commCdValNm: '전체' }]
            let dealcoClCd1s = [{ commCdVal: '', commCdValNm: '전체' }]
            const info = 'addInfo5' // 추가정보

            if (!_.isEmpty(dealcoRgstClCd)) {
                dealcoGrpCds = this.getFilterCode(
                    this.DEAL_CO_GRP, // 코드리스트
                    info, // 추가정보
                    dealcoRgstClCd // 필터코드
                )
                this.dealcoGrpCdList = dealcoGrpCds
            } else {
                this.dealcoGrpCdList = dealcoGrpCds
            }
            console.log('this.dealcoGrpCdList->', this.dealcoGrpCdList)
            this.dealcoClCd1List = dealcoClCd1s
        },

        /**
         * 거래처구분코드 셋팅
         * @param dealcoGrpCd : 거래처그룹코드
         */
        setDealcoClCd1(dealcoGrpCd) {
            let dealcoClCd1s = [{ commCdVal: '', commCdValNm: '전체' }]
            const info = 'addInfo1' // 추가정보
            if (!_.isEmpty(dealcoGrpCd)) {
                dealcoClCd1s = this.getFilterCode(
                    this.ZBAS_C_00240, // 코드리스트
                    info, // 추가정보
                    dealcoGrpCd // 필터코드
                )
                this.dealcoClCd1List = dealcoClCd1s
            } else {
                this.dealcoClCd1List = dealcoClCd1s
            }
        },

        /////////////////////////
        async initBtn() {
            await this.initData()
        },
        gridSetData() {
            return new CommonGrid(0, 30, '', '')
        },
        isValidation() {
            if (!this.isSrchValidation()) {
                // 검색대상
                return false
            } else if (!this.isDealDtValidation()) {
                // 조회일자
                return false
            } else if (!this.isDealcoValidation()) {
                // 거래처
                return false
            } else return this.isOrdValidation()
        },
        isDealcoValidation() {
            const dealcoGrpCd = this.searchParam.dealcoGrpCd // 거래처그룹코드
            const dealcoCd = this.searchParam.dealcoCd // 거래처코드
            const dealcoNm = this.searchParam.dealcoNm // 거래처명
            const bizNo = this.searchParam.bizNo // 사업자번호
            const sktChnlCd = this.searchParam.sktChnlCd // 거래처명
            const searchTarget = this.searchParam.searchTarget // 검색대상
            const srchValue = this.searchParam.srchValue // 검색대상내용
            const dtmFrom = this.searchParam.dtmFrom // 시작일
            const dtmTo = this.searchParam.dtmTo // 종료일
            const dealEndYn = this.searchParam.dealEndYn // 거래개시일 / 종료일

            if (
                _.isEmpty(dealcoCd) &&
                _.isEmpty(dealcoNm) &&
                _.isEmpty(bizNo) &&
                _.isEmpty(sktChnlCd) &&
                (_.isEmpty(searchTarget) || _.isEmpty(srchValue)) &&
                ((_.isEmpty(dtmFrom) && _.isEmpty(dtmTo)) ||
                    _.isEmpty(dealEndYn))
            ) {
                if (_.isEmpty(dealcoGrpCd)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(msgTxt.MSG_00047, '거래처그룹을')
                    )
                    return false
                }
            }
            return true
        },
        isSrchValidation() {
            const searchTarget = this.searchParam.searchTarget // 검색대상
            const srchValue = this.searchParam.srchValue // 검색대상내용

            if (!_.isEmpty(searchTarget)) {
                if (_.isEmpty(srchValue)) {
                    let text = ''
                    if (_.isEqual(searchTarget, '1')) {
                        text = '배송처코드'
                    } else if (_.isEqual(searchTarget, '2')) {
                        text = 'CAT ID'
                    } else if (_.isEqual(searchTarget, '3')) {
                        text = '계좌번호'
                    } else if (_.isEqual(searchTarget, '4')) {
                        text = '정산처코드'
                    } else if (_.isEqual(searchTarget, '5')) {
                        text = '대표자명'
                    }

                    this.showTcComAlert(
                        CommonUtil.replaceMsg(msgTxt.MSG_00083, text)
                    )
                    return false
                }
            } else {
                if (!_.isEmpty(srchValue)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(msgTxt.MSG_00047, '검색대상을')
                    )
                    return false
                }
            }
            return true
        },
        isOrdValidation() {
            const dealcoGrpCd = this.searchParam.dealcoGrpCd // 거래처그룹코드
            const ordCd = this.searchParam.orgCd // 내부조직팝업(권한)코드
            // 직영매장(AY), 하부망(YY), 물류창고(ZZ)
            if (
                _.isEqual(dealcoGrpCd, 'AY') ||
                _.isEqual(dealcoGrpCd, 'YY') ||
                _.isEqual(dealcoGrpCd, 'ZZ')
            ) {
                if (_.isEmpty(ordCd)) {
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(msgTxt.MSG_00047, '소속조직을')
                    )
                    return false
                }
            }
            return true
        },
        isDealDtValidation() {
            const dealEndYn = this.searchParam.dealEndYn // 거래개시일 / 종료일
            this.searchParam.dtmFrom = _.isEmpty(this.dtm[0]) ? '' : this.dtm[0]
            this.searchParam.dtmTo = _.isEmpty(this.dtm[1]) ? '' : this.dtm[1]

            const dtmFrom = this.searchParam.dtmFrom // 시작일
            const dtmTo = this.searchParam.dtmTo // 종료일

            if (!_.isEmpty(dealEndYn)) {
                if (dtmFrom.length < 8 || dtmTo.length < 8) {
                    let text = _.isEqual(dealEndYn, 'Y')
                        ? '거래개시일'
                        : '거래종료일'
                    this.showTcComAlert(
                        CommonUtil.replaceMsg(msgTxt.MSG_00083, text)
                    )
                    return false
                }
            } else {
                if (!_.isEmpty(dtmFrom) || !_.isEmpty(dtmTo)) {
                    this.showTcComAlert('조회일자 항목을 선택해주세요')
                    return false
                }
            }
            return true
        },
        async searchBtn() {
            this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })

            this.defaultAssign_({
                key: 'paging_2',
                value: this.initPaging_2,
            })

            // Validation check
            if (!this.isValidation()) {
                return false
            }

            let paramObj = { ...this.searchParam }
            paramObj.pageNum = this.paging1.pageNum
            paramObj.pageSize = this.initPaging1.pageSize
            paramObj.searchGb = this.searchParam.dealEndYn

            // 조회일자
            if (!_.isEmpty(this.searchParam.dealEndYn)) {
                paramObj.dtmFrom = this.searchParam.dtmFrom.replace(/-/g, '')
                paramObj.dtmTo = this.searchParam.dtmTo.replace(/-/g, '')
            }

            // 조회일자
            if (!_.isEmpty(this.searchParam.dealEndYn)) {
                paramObj.fromDt = this.searchParam.dtmFrom.replace(/-/g, '')
                paramObj.toDt = this.searchParam.dtmTo.replace(/-/g, '')
            }

            paramObj.deal_status_list = ''
            paramObj.dealStatus = ''
            if (!_.isEmpty(this.searchParam.dealStatus)) {
                if (this.searchParam.dealStatus.length > 0) {
                    let dealStatus = this.searchParam.dealStatus.sort().join()
                    paramObj.deal_status_list = dealStatus
                    paramObj.dealStatus = dealStatus
                }
            }

            if (_.isEmpty(this.searchParam.searchTarget)) {
                paramObj.searchTarget = ''
            }

            // 담보최종등록
            if (_.isEqual(this.searchParam.lastMrtg, 'Y')) {
                paramObj.lastMrtg = '1'
            } else {
                paramObj.lastMrtg = '0'
            }
            const searchTarget = this.searchParam.searchTarget
            const srchValue = this.searchParam.srchValue

            if (_.isEqual(searchTarget, '1')) {
                paramObj.sknDlvDealCoCd = srchValue // 배송처코드
            } else if (_.isEqual(searchTarget, '2')) {
                paramObj.catId = srchValue // catId
            } else if (_.isEqual(searchTarget, '3')) {
                paramObj.acntNo = srchValue // 계좌번호
            } else if (_.isEqual(searchTarget, '4')) {
                paramObj.accDealcoCd = srchValue // 정산처코드
            } else if (_.isEqual(searchTarget, '5')) {
                paramObj.repUserNm = srchValue // 대표자명
            }

            await this.defaultAssign_({
                key: 'searchParams',
                value: paramObj,
            })

            await this.defaultAssign_({
                key: 'refreshPaging',
                value: '',
            })

            await this.searchData()
        },
        async searchData() {
            if (_.isEqual(this.refreshPaging, '1')) {
                await this.searchDataNewLst()
            } else if (_.isEqual(this.refreshPaging, '2')) {
                await this.searchDataHstLst()
            } else {
                await this.searchDataNewLst()
                // await this.searchDataHstLst()
            }
        },
        async searchDataNewLst() {
            await this.loading(true)
            let data1
            await this.getBasPrmDealcoMgmtNewLst_()
                .then((data) => {
                    data1 = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    this.loading(false)
                    if (data1.gridList === null) {
                        this.showTcComAlert(
                            msgTxt.MSG_00039.replace(/%s/g, '거래처 목록')
                        )
                    }
                })
        },
        async searchDataHstLst() {
            if (_.isEmpty(this.hstInfo.dealcoCd)) return
            let paramObj = {}

            paramObj.pageNum = this.paging1.pageNum
            paramObj.pageSize = this.initPaging1.pageSize
            paramObj.dealcoCd = this.hstInfo.dealcoCd
            await this.defaultAssign_({
                key: 'hstParams',
                value: paramObj,
            })
            // if (_.isEmpty(this.searchParam.dealcoCd)) {
            //     this.defaultAssign_({
            //         key: 'hstParams',
            //         value: paramObj,
            //     })
            //     return false
            // }
            // this.defaultAssign_({
            //     key: 'hstParams',
            //     value: paramObj,
            // })

            await this.loading(true)
            let data1

            await this.getBasPrmDealcoMgmtHstLst_()
                .then((data) => {
                    data1 = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    this.loading(false)

                    if (data1.gridList === null) {
                        console.log(
                            msgTxt.MSG_00039.replace(/%s/g, '거래처 이력')
                        )
                    }
                })
        },
        async saveBtn() {},
        async newBtn() {
            this.rgstDialogShow = true
        },

        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        // 공통코드 store 등록
        async getCodeList() {
            const codeList = [
                'DEALCO_RGST_CL_CD',
                'DEAL_CO_GRP',
                'ZBAS_C_00240',
                'ZBAS_C_00510',
                'ZBAS_C_00570',
                'ZBAS_C_00530',
                'ZBAS_C_00590',
                'ZBAS_C_00110',
                'ZBAS_C_00130',
                'ZBAS_C_00120',
                'ZBAS_C_00400',
                'ZBAS_C_00710',
                'ZBAS_C_00230',
                'ZBAS_C_00410',
                'ZBAS_C_00420',
                'ZBAS_C_00200',
                'SP_CLS_BIZ_CL_CD',
                'COM_YN',
                'EMAIL_ACC',
                'TAX_PRD_CD',
                'CRD_TYP',
                'ACNT_CL_CD',
                'SKN_WHOUSE_CD',
            ]
            await _.forEach(codeList, (code) => {
                this.getCommCodeList(code)
            })
        },
        async getCommCodeList(codeId) {
            let data = ''

            await commonApi
                .getCommonCodeList(codeId)
                .then((res) => {
                    data = res
                })
                .finally(() => {
                    if (_.isEqual(codeId, 'DEALCO_RGST_CL_CD')) {
                        this.dealcoRgstClCdList = data
                    } else if (_.isEqual(codeId, 'DEAL_CO_GRP')) {
                        this.dealcoGrp = data
                    } else if (_.isEqual(codeId, 'ZBAS_C_00240')) {
                        this.zbasC00240 = data
                    } else if (_.isEqual(codeId, 'ZBAS_C_00570')) {
                        this.zbasC00570 = data
                    } else if (_.isEqual(codeId, 'ZBAS_C_00110')) {
                        this.zbasC00110 = data
                    } else if (_.isEqual(codeId, 'ZBAS_C_00120')) {
                        this.zbasC00120 = data
                    } else if (_.isEqual(codeId, 'SP_CLS_BIZ_CL_CD')) {
                        this.spClsBizClCd = data
                    } else if (_.isEqual(codeId, 'COM_YN')) {
                        this.comYn = data
                    }

                    this.defaultAssign_({
                        key: codeId,
                        value: data,
                    })
                })
        },
        //===================== 거래처그룹 methods ================================
        // 거래처그룹 Change 이벤트
        changeDealcoCl() {
            // 거래처그룹
            this.getDealcoClList() // 거래처 유형 조회
        },
        // 거래처구분 Change 이벤트
        changeDealcoCl2(dealcoClCd1) {
            this.getDealcoCl2Data(dealcoClCd1)
            this.getDealcoCl2DataList() // 거래처 유형 조회
        },
        // 거래처 유형 코드조회
        getDealcoCl2Data(dealcoClCd1) {
            let dealcoGrpCd = ''
            let addInfoYn = ''

            _.forEach(this.dealcoClCd1List, (data) => {
                if (_.isEqual(dealcoClCd1, data.commCdVal)) {
                    dealcoGrpCd = data.addInfo1
                    addInfoYn = data.addInfo4
                }
            })

            if (_.isEqual(dealcoGrpCd, 'AY')) {
                if (_.isEqual(addInfoYn, 'Y')) {
                    this.dealcoCl2CodeData = this.ZBAS_C_00110
                } else if (_.isEqual(addInfoYn, 'N')) {
                    this.dealcoCl2CodeData = this.ZBAS_C_00570
                }
                this.isDisabledDealcoCl2 = false
                this.searchParam.dealcoClCd2 = ''
            } else if (_.isEqual(dealcoGrpCd, 'YY')) {
                // 하부망
                this.dealcoCl2CodeData = this.ZBAS_C_00110
                this.isDisabledDealcoCl2 = false
                this.searchParam.dealcoClCd2 = ''
            } else if (_.isEqual(dealcoGrpCd, 'ZZ')) {
                // 물류창고
                this.dealcoCl2CodeData = this.ZBAS_C_00110
                this.isDisabledDealcoCl2 = false
                this.searchParam.dealcoClCd2 = ''
            }
        },
        // 거래처구분 조회 삭제예정
        getDealcoClList() {
            const defaultData = [{ commCdVal: '', commCdValNm: '선택' }]
            _.forEach(this.ZBAS_C_00240, (data) => {
                if (_.isEqual(data.addInfo1, this.searchParam.dealcoGrpCd)) {
                    defaultData.push(data)
                }
            })
            this.dealcoClCd1List = defaultData
            this.isDisabledDealcoCl2 = true
        },
        // 거래처유형 조회
        getDealcoCl2DataList() {
            const defaultData = [{ commCdVal: '', commCdValNm: '선택' }]
            _.forEach(this.dealcoCl2CodeData, (data) => {
                if (_.isEqual(this.searchParam.dealcoGrpCd, 'AY')) {
                    if (
                        _.isEqual(
                            data.addInfo1,
                            'Y' || _.isEmpty(data.addInfo1)
                        ) &&
                        _.isEqual(data.commCdId, 'ZBAS_C_00110')
                    ) {
                        defaultData.push(data)
                    } else if (_.isEqual(data.commCdId, 'ZBAS_C_00570')) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.searchParam.dealcoGrpCd, 'YY')) {
                    if (
                        _.isEqual(
                            data.addInfo2,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.searchParam.dealcoGrpCd, 'ZZ')) {
                    if (
                        _.isEqual(
                            data.addInfo3,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                }
            })

            this.dealcoCl2List = defaultData
        },
        //===================== //거래처그룹 methods ================================

        //====================//공통기능 methods==================
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (_.isEmpty(res)) {
                        this.searchParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchParam.orgNm = _.get(res[0], 'orgNm')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            //if (!_.isEmpty(this.searchParam.orgNm)) {
            //                this.getAuthOrgTreeList()
            //            } else {

            this.showBcoAuthOrgTrees = true
            //            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return false
            }

            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            //this.searchParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchParam.orgCd = _.get(returnData, 'orgCd')
            this.searchParam.orgNm = _.get(returnData, 'orgNm')
            this.searchParam.orgLvl = _.get(returnData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 거래처이력관리 methods ================================
    },
    watch: {},
}
</script>

<style scoped></style>
