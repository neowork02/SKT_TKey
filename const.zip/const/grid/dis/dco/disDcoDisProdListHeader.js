import { ValueType } from 'realgrid'

export const DisDcoDisProdListGRID_HEADER = {
    fields: [
        {
            fieldName: 'no',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'psAgencyNm',
            dataType: ValueType.TEXT, // 소속조직
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, // 재고보유처
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
    ],
    columns: [
        {
            name: 'no',
            fieldName: 'no',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '번호',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '100',
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'psAgencyNm',
            fieldName: 'psAgencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '소속조직',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고보유처',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
        },
    ],
}
