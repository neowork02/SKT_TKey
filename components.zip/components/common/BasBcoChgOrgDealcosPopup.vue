<template>
    <TCComDialog :dialogShow.sync="activeOpenChgOrgDealco" size="1400px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">내부거래처-조직이관요청</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="searchParam.orgNm"
                                    :codeVal.sync="searchParam.orgCd"
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :eRequired="true"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchPopParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div4">
                                <TCComMultiComboBox
                                    v-model="ckParam.dealcoRgstClCd"
                                    :itemList="getDealcoRgstClList"
                                    labelName="거래처등록구분"
                                ></TCComMultiComboBox>
                            </div>
                            <div class="formitem div4">
                                <TCComMultiComboBox
                                    v-model="ckParam.dealcoGrpCd"
                                    :itemList="getDealcoGrpList"
                                    labelName="거래처그룹"
                                ></TCComMultiComboBox>
                            </div>
                            <div class="formitem div4">
                                <TCComMultiComboBox
                                    v-model="ckParam.dealcoClCd1"
                                    :itemList="getDealcoGubunList"
                                    labelName="거래처구분"
                                ></TCComMultiComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComComboBox
                                    v-model="searchParam.dealcoClCd2"
                                    labelName="거래처유형"
                                    :itemList="dealcoClCd2List"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParam.dealcoNm"
                                    labelName="거래처명"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComCheckBox
                                    v-model="ckParam.onlyAccDeaCoCd"
                                    labelName="정산처리여부"
                                    :itemList="chkData"
                                    :disabled="isDisabledOnlyAccDeaCoCd"
                                ></TCComCheckBox>
                            </div>
                            <div class="formitem div4">
                                <TCComCheckBox
                                    v-model="ckParam.dealEndYn"
                                    labelName="거래종료포함"
                                    :itemList="chkData"
                                ></TCComCheckBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParam.dealcoCd"
                                    labelName="거래처코드"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParam.sktChnlCd"
                                    labelName="매장코드"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComDatePicker
                                    v-model="searchParam.basDayTemp"
                                    labelName="기준년월"
                                    calType="M"
                                ></TCComDatePicker>
                            </div>
                            <div class="formitem div4">
                                <TCComComboBox
                                    v-model="searchParam.reqYn"
                                    codeId="COM_YN"
                                    labelName="선택여부"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2"></div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2"></div>
                            <div class="formitem div2">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        >
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">내부거래처 목록</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="chgOrgDealcoGrid"
                                ref="chgOrgDealcoGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonGrid, CommonUtil } from '@/utils'
import { HEADER } from '@/const/grid/bas/bco/basBcoChgOrgDealcosHeader'
import basBcoChgOrgDealcosApi from '@/api/biz/bas/bco/basBcoChgOrgDealcos'
import commonApi from '@/api/common/commonCode'

import { SacCommon } from '@/views/biz/sac/js'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
import _ from 'lodash'

export default {
    name: 'BasBcoChgOrgDealcosPopup',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: HEADER,
            isDisabledOnlyAccDeaCoCd: false,
            dealcoRgstClList: [], // 내부거래처등록구분
            dealcoGrpList: [], // 거래처그룹
            dealcoGubunList: [], // 거래처구분
            dealcoClCd2List: [], // 거래처유형

            searchParam: {
                /*
                orgLvl: '', //세션레벨
                orgCd: '', //조회조건orgCd
                orgNm: '',
                dealcoGrpCd: '', // 내부거래처그룹
                dealcoClCd1: '', // 내부거래처구분
                dealcoClCd2: '2', //거래처유형
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                dealcoNm: '', // 내부거래처명
                onlyAccDeaCoCd: '',
                dealEndYn: '', //거래종료
                basDay: moment().format('YYYY-MM-DD'), //기준년월
                reqYn: '', //선택여부
                */

                orgLvl: '', //세션레벨
                orgCd: '', //조회조건orgCd
                orgNm: '',
                dealcoRgstClCd: '', // 내부거래처등록구분
                dealcoGrpCd: '', // 내부거래처그룹
                dealcoClCd1: '', // 내부거래처구분
                dealcoClCd2: '', //거래처유형
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                dealcoNm: '', // 내부거래처명
                onlyAccDeaCoCd: '',
                dealEndYn: '', //거래종료
                basDay: '', //기준년월
                basDayTemp: '',
                reqYn: '', //선택여부
                onlyDisUse: '',
            },
            ckParam: {
                onlyAccDeaCoCd: [],
                dealEndYn: [], //거래종료
                dealcoRgstClCd: [], // 내부거래처등록구분
                dealcoGrpCd: [],
                dealcoClCd1: [],
            },
            commChgOrgDealcoPtn: [],
            chkData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '',
                },
            ],
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchPopParam: {
                basMth: '', //예)202202, 2022-02 null이면 부모창현재월셋팅
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                vLevel: '', // 디스플레이제한레벨
                sLvlList: '', //선택가능레벨 '2,3' : as-is 와동일하게 쉼표로 나열
                all: 'Y', //전체검색여부 Y or null , N..
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
        }
    },
    computed: {
        activeOpenChgOrgDealco: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        getDealcoRgstClList() {
            return this.dealcoRgstClList.filter(
                (item) => item.addInfo1 !== 'ETC'
            )
        },
        getDealcoGrpList() {
            let resultList = []
            _.forEach(this.ckParam.dealcoRgstClCd, (data) => {
                const filterList = this.dealcoGrpList.filter(
                    (item) => item.addInfo2 === 'Y' && item.addInfo5 === data
                )
                resultList = [...resultList, ...filterList]
            })
            // console.log('resultList: ', resultList)
            return resultList
        },
        getDealcoGubunList() {
            let resultList = []
            _.forEach(this.ckParam.dealcoGrpCd, (data) => {
                const filterList = this.dealcoGubunList.filter(
                    (item) => item.addInfo1 === data
                )
                resultList = [...resultList, ...filterList]
            })
            // console.log('resultList: ', resultList)
            return resultList
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                if (
                    (value['dealEndYn'] !== '') == undefined
                        ? ''
                        : value['dealEndYn']
                ) {
                    this.ckParam.dealEndYn = [
                        value['dealEndYn'] == undefined
                            ? ''
                            : value['dealEndYn'],
                    ] //거래종료
                }
                this.searchParam.saleStopYN =
                    value['saleStopYN'] == undefined ? '' : value['saleStopYN'] //판매정지포함여부
                this.searchParam.orgLvl =
                    value['orgLvl'] == undefined ? '' : value['orgLvl'] //조직레벨
                this.searchParam.orgCd =
                    value['orgCd'] == undefined ? '' : value['orgCd'] //조직코드
                this.searchParam.orgNm =
                    value['orgNm'] == undefined ? '' : value['orgNm'] //조직명

                // 2022.10.07 요구사항으로 거래처등록구분 추가
                const dealcoRgstClCd = !value['dealcoRgstClCd']
                    ? ''
                    : value['dealcoRgstClCd']
                if (dealcoRgstClCd !== '') {
                    this.ckParam.dealcoRgstClCd = dealcoRgstClCd.split(',')
                }

                let dealcoGrpCd =
                    value['dealcoGrpCd'] == undefined
                        ? ''
                        : value['dealcoGrpCd'] //거래처구분코드
                if (dealcoGrpCd !== '') {
                    this.ckParam.dealcoGrpCd = dealcoGrpCd.split(',')
                }

                let dealcoClCd1 =
                    value['dealcoClCd1'] == undefined
                        ? ''
                        : value['dealcoClCd1'] //거래처구분코드
                if (dealcoClCd1 !== '') {
                    this.ckParam.dealcoClCd1 = dealcoClCd1.split(',')
                }

                this.searchParam.dealcoClCd2 =
                    value['dealcoClCd2'] == undefined
                        ? ''
                        : value['dealcoClCd2'] //거래처유형코드
                this.searchParam.dealcoNm =
                    value['dealcoNm'] == undefined ? '' : value['dealcoNm'] //거래처명
                this.searchParam.dealcoCd =
                    value['dealcoCd'] == undefined ? '' : value['dealcoCd'] //거래처코드
                this.searchParam.sktChnlCd =
                    value['sktChnlCd'] == undefined ? '' : value['sktChnlCd'] //채널코드
                this.searchParam.onlyDisUse =
                    value['onlyDisUse'] == undefined ? '' : value['onlyDisUse'] //재고전용여부

                if (
                    (value['onlyAccDeaCoCd'] !== '') == undefined
                        ? ''
                        : value['onlyAccDeaCoCd']
                ) {
                    this.ckParam.onlyAccDeaCoCd = [value['onlyAccDeaCoCd']] //정산처리여부
                }
                let basDay = value['basDay'] == undefined ? '' : value['basDay']
                basDay = CommonUtil.replaceDash(basDay)
                if (basDay.length < 6) {
                    basDay = CommonUtil.replaceDash(SacCommon.getToday())
                    basDay = basDay.substring(0, 6)
                    this.searchParam.basDayTemp = basDay
                } else if (basDay.length == 6) {
                    this.searchParam.basDayTemp = basDay
                } else {
                    basDay = basDay.substring(0, 6)
                    this.searchParam.basDayTemp = basDay
                }

                this.searchParam.reqYn =
                    value['reqYn'] == undefined ? '' : value['reqYn'] //선택여부
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        getDealcoGrpList: {
            handler: function (value) {
                const dealcoGrpCdList = []
                _.forEach(value, (item) => {
                    dealcoGrpCdList.push(item.commCdVal)
                })
                this.ckParam.dealcoGrpCd = dealcoGrpCdList
            },
            deep: true, // 속성 내부까지 감시
            immediate: false, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        getDealcoGubunList: {
            handler: function (value) {
                const dealcoGubunList = []
                _.forEach(value, (item) => {
                    dealcoGubunList.push(item.commCdVal)
                })
                this.ckParam.dealcoClCd1 = dealcoGubunList
            },
            deep: true, // 속성 내부까지 감시
            immediate: false, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },
    async mounted() {
        this.gridObj = this.$refs.chgOrgDealcoGrid // Grid Object 설정
        await this.setBaseData()
        this.setDealcoData()
        this.initGrid()

        // console.log('menuInfo', this.menuInfo) //메뉴정보
        // console.log('orgInfo', this.orgInfo) //조직정보
        // console.log('userInfo', this.userInfo) //사용자정보
        // console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        // this.searchPopParam.orgCd = this.orgInfo.orgCd
        //this.searchParam.orgLvl = this.orgInfo.orgLvl //세션레벨
    },
    methods: {
        init() {
            this.gridData = this.gridSetData()
            if (this.rows.length > 0) {
                if ('Y' === String(this.ckParam.onlyAccDeaCoCd)) {
                    this.isDisabledOnlyAccDealCoCd = true
                }
            } else {
                if (this.searchParam.orgCd === this.orgInfo.orgCd) {
                    this.searchParam.orgNm = this.orgInfo.orgNm
                    this.searchParam.orgLvl = this.orgInfo.orgLvl
                }
            }
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async setBaseData() {
            // 2022.10.07 요구사항으로 거래처등록구분 추가
            this.dealcoRgstClList = await this.getCommCodeList(
                'DEALCO_RGST_CL_CD'
            )
            this.dealcoGrpList = await this.getCommCodeList('DEAL_CO_GRP')
            this.dealcoGubunList = await this.getCommCodeList('ZBAS_C_00240')
            this.dealcoClCd2List = await this.getCommCodeList('ZBAS_C_00110')
        },
        setDealcoData() {
            _.forEach(this.ckParam.dealcoGrpCd, (data) => {
                const findData = _.find(
                    this.dealcoGrpList,
                    (item) => item.commCdVal === data
                )
                if (!this.ckParam.dealcoRgstClCd.includes(findData.addInfo5))
                    this.ckParam.dealcoRgstClCd = [
                        ...this.ckParam.dealcoRgstClCd,
                        findData.addInfo5,
                    ]
            })
        },
        async initGrid() {
            // const commDealcoGrpNm = await this.getCommCodeList('DEAL_CO_GRP')
            // const commDealCoClCd1Nm = await this.getCommCodeList('ZBAS_C_00240')
            // const commDealCoClCd2Nm = await this.getCommCodeList('ZBAS_C_00110')

            this.gridObj.gridView.columnByName('dealcoGrpCd').values =
                CommonUtil.convListToGridLovValues(
                    this.dealcoGrpList,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('dealcoGrpCd').labels =
                CommonUtil.convListToGridLovLabels(
                    this.dealcoGrpList,
                    'commCdValNm'
                )

            this.gridObj.gridView.columnByName('dealcoClCd1').values =
                CommonUtil.convListToGridLovValues(
                    this.dealcoGubunList,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('dealcoClCd1').labels =
                CommonUtil.convListToGridLovLabels(
                    this.dealcoGubunList,
                    'commCdValNm'
                )

            this.gridObj.gridView.columnByName('dealcoClCd2').values =
                CommonUtil.convListToGridLovValues(
                    this.dealcoClCd2List,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('dealcoClCd2').labels =
                CommonUtil.convListToGridLovLabels(
                    this.dealcoClCd2List,
                    'commCdValNm'
                )
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, true, true)
            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                this.selectDataRow = clickData.dataRow
                //빈곳클릭시작업없음
                if (undefined == this.selectDataRow) {
                    return
                }

                let jsonData = []
                jsonData.push(
                    this.gridObj.dataProvider.getJsonRow(clickData.dataRow)
                )

                /*
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                */

                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        /*
        gridMounted() {
            console.log('gridMounted')
        },
*/
        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        getChgOrgDealcoList() {
            //##백앤드String으로 받게 되어있음
            // 2022.10.07 요구사항으로 거래처등록구분 추가
            this.searchParam.dealcoRgstClCd = String(
                this.ckParam.dealcoRgstClCd
            )
            //거래처그룹
            this.searchParam.dealcoGrpCd = String(this.ckParam.dealcoGrpCd)
            //거래처구분
            this.searchParam.dealcoClCd1 = String(this.ckParam.dealcoClCd1)

            //정산처리여부
            this.searchParam.onlyAccDeaCoCd = String(
                this.ckParam.onlyAccDeaCoCd
            )
            //체크박스거래종료
            this.searchParam.dealEndYn = String(this.ckParam.dealEndYn)
            //##백앤드String으로 받게 되어있음

            this.searchParam.basDay = CommonUtil.replaceDash(
                this.searchParam.basDay
            )

            this.searchParam.searchDate = CommonUtil.replaceDash(
                this.searchParam.searchDateTemp
            )

            let basDayTemp = CommonUtil.replaceDash(this.searchParam.basDayTemp)

            if (_.isEmpty(basDayTemp)) {
                let today = SacCommon.getToday()
                this.searchParam.basDay = CommonUtil.replaceDash(today)
            } else {
                if (basDayTemp.length == 6) {
                    let lastDay = SacCommon.uf_monthLastDay(basDayTemp)
                    this.searchParam.basDay = basDayTemp + lastDay
                } else if (this.searchParam.basDayTemp.length > 6) {
                    let today = SacCommon.getToday()
                    this.searchParam.basDay = CommonUtil.replaceDash(today)
                }
            }

            this.searchParam.searchDate = CommonUtil.replaceDash(
                this.searchParam.searchDateTemp
            )

            basBcoChgOrgDealcosApi
                .getChgOrgDealcosList(this.searchParam)
                .then((res) => {
                    console.log('getChgOrgDealcosList then : ', res)
                    this.gridObj.setRows(res)
                })
        },

        onConfirm() {
            /*
            const current = this.gridObj.gridView.getCurrent()


            if (current.dataRow === -1) {
                this.showAlertBool = true
                this.headerText = '거래처 선택'
                this.alertBodyText = '거래처를 선택해주세요.'
                return
            }
            */

            let jsonData = []
            let checkedRows = this.gridObj.gridView.getCheckedRows()

            if (!checkedRows.length) {
                this.showTcComAlert('거래처를 선택해주세요.')
                return
            }

            for (var r in checkedRows) {
                jsonData.push(
                    this.gridObj.dataProvider.getJsonRow(checkedRows[r])
                )
            }

            /*
            const jsonData = this.gridObj.dataProvider.getJsonRow()
            */
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenChgOrgDealco = false
        },

        onSearch() {
            if ('' != this.searchParam.orgLvl) {
                if (2 > this.searchParam.orgLvl) {
                    this.showTcComAlert('본사사업부로 조회할수 없습니다.')
                    return
                }
            }
            if (_.isEmpty(this.searchParam.orgCd)) {
                this.showTcComAlert('조직을 선택해주세요.')
                return
            }
            this.getChgOrgDealcoList()
        },

        onEnterKey() {
            this.onSearch()
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        setAuthOrgTreeListParam() {
            this.searchPopParam.orgNm = this.searchParam.orgNm
            //기준년월에 따라 조직파라미터변경
            this.searchPopParam.basMth = CommonUtil.replaceDash(
                this.searchParam.basDayTemp
            )
        },
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchPopParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchParam.basMth = _.get(res[0], 'basMth')
                        this.searchParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchParam.orgNm = _.get(res[0], 'orgNm')
                        this.searchParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            this.setAuthOrgTreeListParam()
            if (!_.isEmpty(this.searchParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.setAuthOrgTreeListParam()
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchParam.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
    },
}
</script>
