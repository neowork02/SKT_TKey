<script>
export default {
    name: 'Radio',

    props: {
        value: { type: String, default: '', required: true },
        readonly: { type: Boolean, default: false, required: false },
        index: { type: Number, default: 0, required: false },
        option: {
            type: Array,
            required: true,
        },
    },

    data() {
        return {
            dpMountYn: 'N',
            dValue: this.value,
        }
    },

    watch: {
        readonly() {
            if (!this.readonly) {
                this.test()
            } else {
                //
            }
        },
    },

    mounted() {
        if (!this.readonly) {
            this.test()
        } else {
            //
        }
    },
    methods: {
        test() {
            if (this.dpMountYn === 'Y') {
                return
            }

            this.dpMountYn = 'Y'
        },
        EmitInput() {
            this.$emit('input', this.dValue)
        },
    },
}
</script>

<template>
    <div class="">
        <span type="radio" v-for="(item, index) in option" v-bind:key="index">
            {{ item.title }}
            <input
                type="radio"
                :value="item.value"
                :name="item.name"
                v-model="dValue"
                @change="EmitInput"
            />
        </span>
    </div>
</template>

<style>
.ui-Inputs .ui-state-default {
    border: 1px solid #ffffff !important;
    background: #ffffff !important;
    font-weight: normal;
    color: #454545;
    text-align: center !important;
}
</style>
