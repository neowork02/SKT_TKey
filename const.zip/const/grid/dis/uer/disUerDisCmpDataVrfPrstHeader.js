import { ValueType } from 'realgrid'

export const GRID_LAYOUT = [
    'cfmYm',
    'cfmCnt',
    'prodCd',
    'prodNm',
    'colorCd',
    'colorNm',
    'tkeyQty',
    'sknQty',
    {
        name: '그룹헤더',
        direction: 'horizontal',
        items: ['tkeyQtyNr'],
        header: {
            text: 'TkeyTaka',
        },
    },
    {
        name: '그룹헤더',
        direction: 'horizontal',
        items: ['sknQtyNr'],
        header: {
            text: 'SKN',
        },
    },
    'nrCnt',
    'cfmDt',
    'cfmId',
]

export const DisUerDisCmpDataVrfPrst_GRID_HEADER = {
    fields: [
        {
            fieldName: 'cfmYm',
            dataType: ValueType.TEXT, // 정책월
        },
        {
            fieldName: 'cfmCnt',
            dataType: ValueType.TEXT, // 차수
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'tkeyQty',
            dataType: ValueType.NUMBER, // T-key+ 현보유
        },
        {
            fieldName: 'sknQty',
            dataType: ValueType.NUMBER, // SKN보상대상
        },
        {
            fieldName: 'tkeyQtyNr',
            dataType: ValueType.NUMBER, // 현보유 누락(T-key+)
        },
        {
            fieldName: 'sknQtyNr',
            dataType: ValueType.NUMBER, // 현보유 누락(SKN)
        },
        {
            fieldName: 'nrCnt',
            dataType: ValueType.NUMBER, // 검증대상(수량)
        },
        {
            fieldName: 'cfmDt',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'cfmId',
            dataType: ValueType.TEXT, // 처리자
        },
    ],
    columns: [
        {
            name: 'cfmYm',
            fieldName: 'cfmYm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정책월',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'cfmCnt',
            fieldName: 'cfmCnt',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '차수',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'tkeyQty',
            fieldName: 'tkeyQty',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: 'TkeyTaka현보유',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'sknQty',
            fieldName: 'sknQty',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN보상대상',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tkeyWare',
            fieldName: 'tkeyWare',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'TkeyTaka위탁창고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'sknWare',
            fieldName: 'sknWare',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN위탁창고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tkeyQtyNr',
            fieldName: 'tkeyQtyNr',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '현보유 누락',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tkeyWareNr',
            fieldName: 'tkeyWareNr',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '위탁창고 누락',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'sknQtyNr',
            fieldName: 'sknQtyNr',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현보유 누락',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'sknWareNr',
            fieldName: 'sknWareNr',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '위탁창고 누락',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'nrCnt',
            fieldName: 'nrCnt',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '검증대상(수량)',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'cfmDt',
            fieldName: 'cfmDt',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'cfmId',
            fieldName: 'cfmId',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_LAYOUT2 = [
    'cfmYm',
    'cfmCnt',
    'prodCd',
    'prodNm',
    'colorCd',
    'colorNm',
    'tkeyWare',
    'sknWare',
    {
        name: '그룹헤더',
        direction: 'horizontal',
        items: ['tkeyWareNr'],
        header: {
            text: 'TkeyTaka',
        },
    },
    {
        name: '그룹헤더',
        direction: 'horizontal',
        items: ['sknWareNr'],
        header: {
            text: 'SKN',
        },
    },
    'nrCnt',
    'cfmDt',
    'cfmId',
]

export const DisUerDisCmpDataVrfPrst_GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'cfmYm',
            dataType: ValueType.TEXT, // 정책월
        },
        {
            fieldName: 'cfmCnt',
            dataType: ValueType.TEXT, // 차수
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'tkeyWare',
            dataType: ValueType.NUMBER, // T-key+ 위탁창고
        },
        {
            fieldName: 'sknWare',
            dataType: ValueType.NUMBER, // SKN위탁창고
        },
        {
            fieldName: 'tkeyWareNr',
            dataType: ValueType.NUMBER, // 위탁창고 누락(T-key+)
        },
        {
            fieldName: 'sknWareNr',
            dataType: ValueType.NUMBER, // 위탁창고 누락(SKN)
        },
        {
            fieldName: 'nrCnt',
            dataType: ValueType.NUMBER, // 검증대상(수량)
        },
        {
            fieldName: 'cfmDt',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'cfmId',
            dataType: ValueType.TEXT, // 처리자
        },
    ],
    columns: [
        {
            name: 'cfmYm',
            fieldName: 'cfmYm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정책월',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'cfmCnt',
            fieldName: 'cfmCnt',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '차수',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'tkeyWare',
            fieldName: 'tkeyWare',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'TkeyTaka위탁창고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'sknWare',
            fieldName: 'sknWare',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN위탁창고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tkeyWareNr',
            fieldName: 'tkeyWareNr',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '위탁창고 누락',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'sknWareNr',
            fieldName: 'sknWareNr',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '위탁창고 누락',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'nrCnt',
            fieldName: 'nrCnt',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '검증대상(수량)',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'cfmDt',
            fieldName: 'cfmDt',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'cfmId',
            fieldName: 'cfmId',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
    ],
}
