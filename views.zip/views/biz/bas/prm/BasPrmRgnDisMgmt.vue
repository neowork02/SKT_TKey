<template>
    <div class="content">
        <!-- Tit -->
        <h1>권역별 재고현황</h1>
        <!-- Top BTN  STA-->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clear"
                    :objAuth="objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <!-- Top BTN  END -->

        <!-- searchLayer_wrap STA (조회조건) -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        v-model="searchParam.strdDt"
                        :codeVal.sync="searchParam.strdDt"
                        labelName="기준일자"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div4">
                    <TCComMultiComboBox
                        v-model="searchParam.rgnCd"
                        labelName="권역"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        codeId="ZBAS_C_00820"
                        :objAuth="objAuth"
                    ></TCComMultiComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchDealcoParam.dealcoNm"
                        :codeVal.sync="searchDealcoParam.dealcoCd"
                        labelName="거래처코드"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchDealcoParam"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchProdForm.prodCd"
                        :codeVal.sync="searchProdForm.prodNm"
                        labelName="모델"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onProdsEnterKey"
                        @appendIconClick="onProdsIconClick"
                        @input="onProdsInput"
                    />
                    <BasBcoProdsPopup
                        v-if="basBcoProdsShow"
                        :parentParam="searchProdForm"
                        :rows="resultProdsRows"
                        :dialogShow.sync="basBcoProdsShow"
                        @confirm="onProdsReturnData"
                    />
                </div>
            </div>
        </div>
        <!-- searchLayer_wrap END (조회조건) -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="권역 별 재고현황"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @excelDownBtn="this.excelDown"
            />

            <TCRealGrid
                id="gridTable"
                ref="gridTable"
                :fields="gridTable.fields"
                :columns="gridTable.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData1.totalPage"
                :apiFunc="getRgnDisList"
                :rowCnt="rowCnt"
                :gridObj="gridObj1"
                @input="chgRowCnt1"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
// import CommonUtil from '@/utils/CommonUtil.js'
// import CommonMsg from '@/utils/CommonMsg'
import moment from 'moment'
import _ from 'lodash'
import { GRID_HEADER } from '@/const/grid/bas/prm/basPrmRgnDisMgmtHeader'
import API from '@/api/biz/bas/prm/basPrmRgnDisMgmt'
//====================내부거래처(권한조직)====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
//====================//내부거래처(권한조직)==================
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================
import CommonMixin from '@/mixins'

export default {
    name: 'BasPrmRgnDisMgmt',
    components: {
        BasBcoDealcosPopup,
        BasBcoProdsPopup,
    },
    async created() {
        // await this.initControls()
        await this.initData()
    },
    mixins: [CommonMixin],
    props: {},
    data() {
        return {
            objAuth: {},
            gridHeaderObj: {},
            gridObj: {},
            gridStyle: {
                height: '420px', //그리드 높이 조절
            },
            showNext: false,
            rgstDialogShow: false,
            gridTable: GRID_HEADER,
            //조회 조건 파라미터
            opDt: '',
            searchParam: {
                strdDt: '',
                rgnCd: [],
                hldDealcoCd: '',
                hldDealcoNm: '',
                prodCd: '',
                prodNm: '',
            },
            //====================내부거래처(권한 조직))====================
            basBcoDealcoShow: false,
            searchDealcoParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한 조직)==================
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            searchProdForm: {
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
            },
            resultProdsRows: [],
            //====================//상품팝업관련==================

            pageNum: 1,
            pageSize: 10,
            gridData1: this.gridSetData(),
            // paging
            rowCnt: 5, // 표시할 행의 갯수
            gridObj1: {},
            view: GRID_HEADER,
            layout: GRID_HEADER.layout,
        }
    },

    mounted() {
        this.initParam()
        this.gridObj = this.$refs.gridTable
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.setGridState(true, false, false, true)
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
    },

    computed: {
        paging1: {
            get() {
                return this.paging
            },
        },
    },
    methods: {
        /* 초기화 */
        clear() {
            this.initParam()
            this.gridObj.setRows({})
            return
        },
        async initData() {
            let today = moment(new Date()).format('YYYY-MM-DD')
            console.log(
                '🚀 ~ file: BASPRMRGNDISMGMT.vue ~ line 225 ~ today',
                today
            )
            this.opdt = today
            this.searchParam.strdDt = this.opDt
        },
        /* 파라미터 초기화*/
        initParam() {
            this.searchParam = {
                strdDt: this.opdt,
                rgnCd: [],
                hldDealcoCd: '',
                hldDealcoNm: '',
                prodCd: '',
                prodNm: '',
                pageSize: 10,
                pageNum: 1,
            }
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt1(val) {
            this.rowCnt = val
        },
        //GridSet Init
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        // 조회 BTN
        onSearch() {
            console.log('🚀 ~ file: BASPRMRGNDISMGMT.vue ~ line 263 ~ onSearch')
            this.gridData1.totalPage = 0
            this.getRgnDisList(1)
        },

        // 조회
        getRgnDisList(pageNum) {
            let paramObj = { ...this.searchParam }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt

            paramObj.rgnCd = ''
            //권역코드
            if (!_.isEmpty(this.searchParam.rgnCd)) {
                if (this.searchParam.rgnCd.length > 0) {
                    paramObj.rgnCd = this.searchParam.rgnCd.join()
                }
            }
            //모델코드
            if (!_.isEmpty(this.searchProdForm.prodCd)) {
                if (this.searchProdForm.prodCd.length > 0) {
                    paramObj.prodCd = this.searchProdForm.prodCd
                }
            }

            if (!_.isEmpty(this.searchDealcoParam.dealcoCd)) {
                if (this.searchDealcoParam.dealcoCd.length > 0) {
                    paramObj.hldDealcoCd = this.searchDealcoParam.dealcoCd
                }
            }
            console.log(
                '🚀 ~ file: BASPRMRGNDISMGMT.vue ~ line 263 ~ getRgnDisList',
                paramObj
            )
            API.getRgnDisList(paramObj).then((resultData) => {
                if (_.isEmpty(resultData.gridList)) {
                    alert('조회된 데이터가 없습니다')
                    return
                }
                this.gridObj.setRows(resultData.gridList)
                this.gridData1 = this.gridSetData() //초기화
                this.isShowNext(resultData.pagingDto)
                this.gridData1.totalPage = resultData.pagingDto.totalPageCnt
                // GridHeader (총 ?건)
                this.gridHeaderObj.setPageCount(resultData.pagingDto)
            })
        },
        /* 다음페이지 노출여부 */
        isShowNext(pageInfo) {
            this.showNext =
                pageInfo.totalDataCnt === pageInfo.pageSize ? true : false
        },
        /* 엑셀다운로드 */
        excelDown() {
            this.gridHeaderObj.exportGrid(
                `권역별재고현황${moment(new Date()).format(
                    'YYYYMMDDHHmmss'
                )}.xls`
            )
        },

        created() {
            this.init()
        },
        //===================== 내부거래처(권한조직)) methods ================================
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 팝업오픈
            this.basBcoDealcoShow = true
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchDealcoParam.dealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchDealcoParam.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.searchDealcoParam.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================

        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                console.log('getProdsList : ', res)
                if (res === undefined) return
                if (res.length === 1) {
                    this.searchProdForm.prodCd = _.get(res[0], 'prodCd')
                    this.searchProdForm.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.searchProdForm.prodCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchProdForm.prodCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchProdForm.prodNm = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchProdForm.prodCd = _.get(retrunData, 'prodCd')
            this.searchProdForm.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
    },

    watch: {
        paging1() {
            this.SetPaging()
        },
    },
}
</script>
