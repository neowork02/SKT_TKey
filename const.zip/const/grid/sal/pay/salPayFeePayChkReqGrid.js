/*****************************************
 * 업무그룹명: 판매관리
 * 서브업무명: 요금수납요청
 * 설명: 판매관리-수납-요금수납확인요청현황(SALPAY01000 )  그리드 헤더
 * 작성자: P180181
 * 작성일: 2022.10.28
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
 *****************************************/

import { ValueType } from 'realgrid'

export const GRIDHEADER = {
    fields: [
        {
            fieldName: 'reqId', // 순번
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, //회사구분코드
        },
        {
            fieldName: 'reqDealcoCd',
            dataType: ValueType.TEXT, //요청판매점코드
        },
        {
            fieldName: 'reqDealcoNm',
            dataType: ValueType.TEXT, //요청거래처명
        },
        {
            fieldName: 'sktChnlCd', // 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDt', // 요청일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqTm', // 요청시간
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procStCd', // 처리상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procStNm', // 처리상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNm', // 고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNum', // 이동전화번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNmMask', // 고객명(마스킹)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNumMask', // 이동전화번호(마스킹)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', // 서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDealcoMemo', // 판매점메모
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId', // 요청자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChageMonth1',
            dataType: ValueType.TEXT, //수납대상월1
        },
        {
            fieldName: 'sktChageAmt1',
            dataType: ValueType.NUMBER, // 수납대상금액1
        },
        {
            fieldName: 'sktChageMonth2',
            dataType: ValueType.TEXT, //수납대상월2
        },
        {
            fieldName: 'sktChageAmt2',
            dataType: ValueType.NUMBER, // 수납대상금액2
        },
        {
            fieldName: 'sktChageMonth3',
            dataType: ValueType.TEXT, //수납대상월3
        },
        {
            fieldName: 'sktChageAmt3',
            dataType: ValueType.NUMBER, // 수납대상금액3
        },
        {
            fieldName: 'answUserId', // 답변자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyRspDtm', // 대리점응답일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyMemo', // 대리점메모
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChageProcDtm', // 수납처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChageReqAmt', // 수납요청금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktChageReqDtm', // 수납요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChageReqMemo', // 수납요청메모
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'icasStCd', // ICAS조회상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId', // 입력사용자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm', // 입력일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 수정사용자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm', // 수정사용자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 수정일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqBtn', // 문의처리
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'reqDt',
            fieldName: 'reqDt',
            type: 'data',
            header: '요청일자',
            width: '100',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'reqTm',
            fieldName: 'reqTm',
            type: 'data',
            header: '요청시간',
            width: '100',
            editable: false,
            textFormat: '([0-9]{2})([0-9]{2})([0-9]{2})$;$1:$2:$3',
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            styleName: 'left-column',
            width: '100',
            header: '매장코드',
            editor: {
                type: 'text',
            },
        },
        {
            name: 'reqDealcoCd',
            fieldName: 'reqDealcoCd',
            type: 'data',
            styleName: 'left-column',
            width: '100',
            header: '거래처코드',
            editor: {
                type: 'text',
            },
        },
        {
            name: 'reqDealcoNm',
            fieldName: 'reqDealcoNm',
            type: 'data',
            styleName: 'left-column',
            width: '150',
            header: '요청거래처',
            editor: {
                type: 'text',
            },
        },
        {
            name: 'custNmMask',
            fieldName: 'custNmMask',
            type: 'data',
            styleName: 'left-column',
            width: '150',
            header: '고객명',
            editor: {
                type: 'text',
            },
        },
        {
            name: 'svcNumMask',
            fieldName: 'svcNumMask',
            type: 'data',
            header: '이동전화번호',
            editable: false,
        },
        {
            name: 'reqBtn',
            fieldName: 'reqBtn',
            width: '100',
            header: {
                text: '문의처리',
            },
            editable: false,
            renderer: {
                type: 'button',
            },
            visible: true,
            buttonVisibility: 'always',
        },
        {
            name: 'procStNm',
            fieldName: 'procStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '처리상태',
            editable: false,
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            header: '서비스관리번호',
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            header: '처리자',
            editable: false,
        },
    ],
}
