import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn3',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            editable: false,
            header: {
                text: '조직',
            },
            width: '400',
            // styleName: 'left-column',
        },
        {
            name: 'mblPhonNo1',
            fieldName: 'mblPhonNo1',
            header: {
                text: '권한',
            },
            editable: false,
        },
        {
            name: 'mblPhonNo2',
            fieldName: 'mblPhonNo2',
            header: {
                text: '담당자',
            },
            editable: false,
        },
        {
            name: 'smsYn1',
            fieldName: 'smsYn1',
            header: {
                text: '매장코드/매장명',
            },
            editable: false,
        },
        {
            name: 'smsYn2',
            fieldName: 'smsYn2',
            header: {
                text: '대표전화번호2',
            },
            editable: false,
        },
        {
            name: 'smsYn3',
            fieldName: 'smsYn3',
            header: {
                text: '전송여부',
            },
            editable: false,
        },
    ],
}

export const P_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn3',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            editable: false,
            header: {
                text: '조직',
            },
            width: '400',
            // styleName: 'left-column',
        },
        {
            name: 'mblPhonNo1',
            fieldName: 'mblPhonNo1',
            header: {
                text: '권한',
            },
            editable: false,
        },
        {
            name: 'mblPhonNo2',
            fieldName: 'mblPhonNo2',
            header: {
                text: '담당자명',
            },
            editable: false,
        },
        {
            name: 'smsYn1',
            fieldName: 'smsYn1',
            header: {
                text: '매장코드(P코드)',
            },
            editable: false,
        },
        {
            name: 'smsYn4',
            fieldName: 'smsYn4',
            header: {
                text: '매장명',
            },
            editable: false,
        },
        {
            name: 'smsYn2',
            fieldName: 'smsYn2',
            header: {
                text: '대표전화번호2',
            },
            editable: false,
        },
        {
            name: 'smsYn3',
            fieldName: 'smsYn3',
            header: {
                text: '전송여부',
            },
            editable: false,
        },
    ],
}
