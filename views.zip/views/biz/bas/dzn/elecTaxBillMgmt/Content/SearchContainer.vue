<template>
    <div>
        <ul class="btn_area top">
            <!-- <li class="left">
                <v-btn outlined class="btn_ty">삭제</v-btn>
            </li> -->
            <li class="right">
                <div class="rightBox">
                    <TCComButton
                        color="btn2"
                        eClass="btn_ty01"
                        @click="initBtn"
                        :objAuth="this.objAuth"
                    >
                        초기화
                    </TCComButton>
                    <TCComButton
                        color="btn2"
                        eClass="btn_ty01"
                        @click="searchBtn"
                        :objAuth="this.objAuth"
                    >
                        조회
                    </TCComButton>
                </div>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        v-model="schdDt"
                        :calType="calType5"
                        labelName="세금계산서일자"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="정발행여부"
                        v-model="formSearchParams.cmbTurnYn"
                        :objAuth="objAuth"
                        :itemList="this.cmbTurnYns"
                        itemText="codeName"
                        itemValue="codeValue"
                        @change="selectChange"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.dealCoCd"
                        labelName="거래처코드"
                        :size="150"
                        :maxlength="10"
                        :objAuth="this.objAuth"
                        inputRuleType="N"
                    ></TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.noBiz"
                        labelName="사업자번호"
                        :size="150"
                        :maxlength="10"
                        :objAuth="this.objAuth"
                        inputRuleType="N"
                    ></TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        :appendIconClass="''"
                        @appendIconClick="searchCommon('org')"
                        :objAuth="this.objAuth"
                        v-model="formSearchParams.orgNm"
                        :codeVal.sync="formSearchParams.orgId"
                        :disabledAfter="true"
                        @input="onAuthOrgTreeInput"
                    />
                </div>
                <div class="formitem div4" />
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.dealCoNm"
                        labelName="거래처명"
                        :size="150"
                        :maxlength="100"
                        :objAuth="this.objAuth"
                    ></TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.taxBilId"
                        labelName="요청번호"
                        :size="150"
                        :maxlength="100"
                        :objAuth="this.objAuth"
                    ></TCComInput>
                </div>
            </div>
        </div>
        <BasBcoAuthOrgTreesPopup
            v-if="showBcoAuthOrgTrees"
            :parentParam="popupParam"
            :rows="resultAuthOrgTreeRows"
            :dialogShow.sync="showBcoAuthOrgTrees"
            @confirm="onAuthOrgTreeReturnData"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/dzn/elecTaxBillMgmt/helpers'
import moment from 'moment'
//import CommonUtil from '@/utils/CommonUtil.js'
import { msgTxt } from '@/const/msg.Properties.js'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
//====================//내부조직팝업(권한)팝업====================

export default {
    components: {
        //TCComComboBox,
        BasBcoAuthOrgTreesPopup,
    },
    async created() {
        await this.initControls()
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            calType5: 'DP',
            cmbTurnYns: [
                {
                    codeValue: '',
                    codeName: '전체',
                },
                {
                    codeValue: 'Y',
                    codeName: '정발행',
                },
                {
                    codeValue: 'N',
                    codeName: '역발행',
                },
            ],
            schdDt: [],
            formSearchParams: {
                cmbTurnYn: '', //정발행여부
                orgNm: '', //조직아이디
                orgId: '111', //조직아이디
                orgLvl: '', //조직레벨
                dealCoCd: '', //거래처코드
                dealCoNm: '', //거래처명
                taxBilId: '', //요청번호
                noBiz: '', //사업자번호
                staInSchdDt: '', //세금계산서일자시작일
                endInSchdDt: '', //세금계산서일자마지막일
            },
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            popupParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
        }
    },
    computed: {
        ...serviceComputed,
        commCdIds1: {
            get() {
                return this.commCdIds
            },
            //set(value) {},
        },
    },
    methods: {
        ...serviceMethods,
        async initControls() {
            //await this.commonCodes_({ option: '전체' })
            //this.defaultAssign_({ key: 'plantCd', value: this.user.plantCd }); //watch call searchList()
        },
        async initData() {
            let mm01 = moment(new Date()).format('YYYY-MM-01')
            let today = moment(new Date()).format('YYYY-MM-DD')
            this.schdDt = [mm01, today]
            this.formSearchParams.cmbTurnYn = ''
            this.formSearchParams.orgNm = ''
            this.formSearchParams.orgId = '' //조직아이디
            this.formSearchParams.dealCoCd = '' //거래처코드
            this.formSearchParams.dealCoNm = '' //거래처명
            this.formSearchParams.taxBilId = '' //요청번호
            this.formSearchParams.noBiz = '' //사업자번호
            this.formSearchParams.staInSchdDt = '' //시작일
            this.formSearchParams.endInSchdDt = '' //마지막일
            this.DEFAULT_ASSIGN({
                key: 'paging',
                value: this.initPaging,
            })
            this.DEFAULT_ASSIGN({
                key: 'resultList',
                value: [],
            })
        },
        selectChange(val) {
            console.log('🚀 ~ file: selectChange ~ line 58 ~ selectChange', val)
        },
        searchCommon(flag) {
            // TODO 공통팝업 호출
            if (flag === 'mfact') {
                alert('제조사')
            } else if (flag === 'org') {
                //alert('조직')
                if (this.formSearchParams.orgNm == '') {
                    this.formSearchParams.orgId = ''
                }
                this.resultAuthOrgTreeRows = []
                this.showBcoAuthOrgTrees = true
            } else if (flag === 'prod') {
                alert('모델')
            } else if (flag === 'outPlc') {
                alert('보유처')
            }
        },
        async initBtn() {
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 122 ~ data ',
                this.$data
            )
            await this.initData()
            //CommonUtil.clearPage(this.$router)
        },
        async searchBtn() {
            let fromDt = new Date(this.schdDt[0])
            let toDt = new Date(this.schdDt[1])
            if (fromDt > toDt) {
                this.showAlert_({
                    title: '세금계산서일자 오류',
                    message: '시작일자가 마지막일자 보다 큽니다.',
                })
                return
            }
            if (
                moment(fromDt).format('YYYY-MM') !=
                moment(toDt).format('YYYY-MM')
            ) {
                this.showAlert_({
                    title: '세금계산서일자 오류',
                    message: '같은 월 검색만 됩니다.',
                })
                return
            }
            this.DEFAULT_ASSIGN({
                key: 'paging',
                value: this.initPaging,
            })
            this.formSearchParams.staInSchdDt = this.schdDt[0].replace(/-/g, '')
            this.formSearchParams.endInSchdDt = this.schdDt[1].replace(/-/g, '')
            this.DEFAULT_ASSIGN({
                key: 'searchParams',
                value: this.formSearchParams,
            })
            await this.searchData()
        },
        async searchData() {
            this.loading(true)
            let data1
            await this.getBasDznElecTaxBillMgmtList_()
                .then((data) => {
                    // console.log(
                    //     '🚀 ~ file: SearchContent.vue ~ line 51 ~ searchData ~ data',
                    //     data
                    // )
                    data1 = data
                })
                // .catch((error) => {
                //     Promise.reject(error)
                // })
                .finally(() => {
                    //this.$sf_toggleLoading(false);
                    console.log('🚀 ~ file: SearchContent.vue ~ finally')
                    this.loading(false)
                    if (data1 !== undefined && data1.gridList.length == 0) {
                        this.toasting(msgTxt.MSG_00039.replace(/%s/g, ''))
                    }
                })
        },
        async loading(val) {
            this.DEFAULT_ASSIGN({
                key: 'loadingShow',
                value: val,
            })
        },
        async toasting(val) {
            this.DEFAULT_ASSIGN({
                key: 'snackbar',
                value: true,
            })
            this.DEFAULT_ASSIGN({
                key: 'snackbarText',
                value: val,
            })
        },
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.formSearchParams.orgId = ''
        },
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.formSearchParams.orgNm = retrunData.orgNm
            this.formSearchParams.orgId = retrunData.orgCd
        },
    },
}
</script>
<style>
.rightBox {
    display: flex;
    flex-direction: row;
    gap: 0.5em;
    height: 35px;
}
.rightBox .iteminput {
    width: 150px !important;
    flex-direction: row;
    flex-grow: 1;
    flex-shrink: 1;
}
.rightBox .v-input__slot {
    width: 140px !important;
    flex-direction: row;
    flex-grow: 1;
    flex-shrink: 1;
}
</style>
