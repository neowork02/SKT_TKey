import { ValueType } from 'realgrid'

export const GRID_CRDT_EXCEL = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'no',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stdCrdtAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'eachCrdtAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totCrdtAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'crdtUse',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            renderer: {
                type: 'check',
                editable: true,
                falseValues: '0',
                trueValues: '1',
            },
            header: {
                text: '선택',
                showTooltip: false,
            },
            width: '50',
            checked: false,
        },
        {
            name: 'no',
            fieldName: 'no',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '번호',
                showTooltip: false,
            },
            editable: false,
            width: '50',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직명',
                showTooltip: false,
            },
            editable: false,
            width: '330',
            styleName: 'left-column',
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            editable: false,
            styleName: 'center-column',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처 코드',
                showTooltip: false,
            },
            editable: false,
            styleName: 'center-column',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            editable: false,
            styleName: 'left-column',
        },

        {
            name: 'stdCrdtAmt',
            fieldName: 'stdCrdtAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '기본담보금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'eachCrdtAmt',
            fieldName: 'eachCrdtAmt',
            type: 'data',
            header: {
                text: '* 특별여신적용금액',
                showTooltip: false,
            },
            width: '100',
            styleCallback(grid, dataCell) {
                let ret = {}
                let errMsg = grid.getValue(dataCell.index.itemIndex, 'errDesc')
                if (errMsg != '' && errMsg != null) {
                    // console.log('non editable', errMsg)
                    ret.editable = false
                } else {
                    // console.log('editable', errMsg)
                    ret.editor = {
                        type: 'number',
                        editFormat: '#,##0',
                    }
                }

                return ret
            },
            //editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'totCrdtAmt',
            fieldName: 'totCrdtAmt',
            type: 'data',
            width: '100',
            header: {
                text: '총여신금액',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
        },
        {
            name: 'crdtUse',
            fieldName: 'crdtUse',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신사용비율',
                showTooltip: false,
            },
            editable: false,
            styleName: 'right-column',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
            editor: {
                type: 'text',
            },
            styleName: 'left-column',
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            styles: {
                textAlignment: 'near',
            },
            header: {
                text: '오류사항',
                showTooltip: true,
            },
            width: '300',
            editable: false,
            styleName: 'left-column',
        },
        {
            name: 'aplyStaDtm',
            fieldName: 'aplyStaDtm',
            visible: false,
            type: 'data',
        },
        {
            name: 'aplyEndDtm',
            fieldName: 'aplyEndDtm',
            visible: false,
            type: 'data',
        },
    ],
}

export const GRID_POP_EXCEL = {
    fields: [
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'eachCrdtAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처 코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'eachCrdtAmt',
            fieldName: 'eachCrdtAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '특별여신적용금액',
                showTooltip: false,
            },

            numberFormat: '#,##0',
        },
    ],
}
