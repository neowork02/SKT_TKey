import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsDt', // 전송일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmNm', // 전송구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'amt', // 금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'trmsReqDtm', // 요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId', // 요청자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsYn', // 전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsDtm', // 전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNm', // 전송요청사용자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsYnNm', // 전송결과명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'trmsDt',
            fieldName: 'trmsDt',
            type: 'data',
            width: '80',
            header: '전송일자',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            width: '80',
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            header: '조직명',
        },
        {
            name: 'trmsItmNm',
            fieldName: 'trmsItmNm',
            type: 'data',
            width: '150',
            header: '전송구분',
        },
        {
            name: 'amt',
            fieldName: 'amt',
            type: 'data',
            header: '금액',
            width: '100',
            numberFormat: '#,##0',
        },
        {
            name: 'trmsReqDtm',
            fieldName: 'trmsReqDtm',
            type: 'data',
            width: '100',
            header: '요청일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'reqUserId',
            fieldName: 'reqUserId',
            type: 'data',
            width: '100',
            header: '요청자',
        },
        {
            name: 'trmsYnNm',
            fieldName: 'trmsYnNm',
            type: 'data',
            width: '70',
            header: '전송결과',
        },
        {
            name: 'trmsDtm',
            fieldName: 'trmsDtm',
            type: 'data',
            width: '100',
            header: '전송일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            header: '비고',
        },
    ],
}
