<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">SKT수수료정산등록</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="right">
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onReset"
                                >초기화</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onSave"
                                :disabled="onSaveDis"
                                >확정</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onDelete"
                                :disabled="onDeleteDis"
                                >삭제</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onClose"
                                >닫기</TCComButton
                            >
                        </li>
                    </ul>
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParams.srchAgencyNm"
                                    labelName="대리점"
                                    :objAuth="objAuth"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="M"
                                    v-model="accYm_"
                                    labelName="정산월"
                                    :eRequired="true"
                                    :disabled="true"
                                >
                                </TCComDatePicker>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParams.srchAccDealcoNm"
                                    labelName="정산처"
                                    :objAuth="objAuth"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParams.srchPsErpGrpNm"
                                    labelName="구분"
                                    :objAuth="objAuth"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeader2"
                                ref="gridHeader2"
                                gridTitle="SKT수수료 정산내역"
                                :gridObj="gridObj2"
                                :isExceldown="true"
                                @excelDownBtn="downloadDetailListExcel"
                            >
                                <template #gridElementArea>
                                    <TCComDatePicker
                                        labelName="확정일"
                                        calType="D"
                                        class="btn_noline btn_ty04"
                                        v-model="confirmDate_"
                                    />
                                </template>
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid2"
                                ref="grid2"
                                :editable="false"
                                :fields="view.fields"
                                :columns="view.columns"
                                :styles="gridStyle"
                            />
                        </div>
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeader3"
                                ref="gridHeader3"
                                gridTitle="SKT수수료 확정내역"
                                :gridObj="gridObj3"
                                :isExceldown="true"
                                @excelDownBtn="downloadExcelSub"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid3"
                                ref="grid3"
                                :editable="true"
                                :fields="view3.fields"
                                :columns="view3.columns"
                                :styles="gridStyle3"
                            />
                        </div>
                        <div class="textareaLayer_wrap">
                            <TCComTextArea
                                v-model="searchParams.rmks"
                                labelName="비고"
                                :rows="5"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
import { AccUtil } from '@/views/biz/acc'
import sktCmmApi from '@/api/biz/acc/sss/AccSssSktCmmsAccMgmt'
import { CommonGrid, CommonUtil } from '@/utils'
import {
    GRID_HEADER,
    GRID_HEADER1,
} from '@/const/grid/acc/sss/AccSssSktCmmsAccMgmtDtlGrid'

export default {
    name: 'AccSssSktCmmsAccMgmtDtl',
    mixins: [CommonMixin],
    title: 'SKT수수료정산등록',
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            view3: GRID_HEADER1,
            objAuth: {},
            fixInfo: [],
            gridData: this.gridSetData(this.rowcnt),
            gridData1: this.gridSetData(this.rowcnt),
            gridObj2: {},
            gridHeaderObj2: {},
            gridObj3: {},
            gridHeaderObj3: {},
            gridStyle: {
                height: '350px', //그리드 높이 조절
            },
            gridStyle3: {
                height: '23px', //그리드 높이 조절
            },

            searchForms: {},
            dtlParams: {
                mthInfo: {},
                dtlList: [],
            },
            res: {},
            rowCnt: 15,
            accYm_: '',
            confirmDate_: '',

            onDeleteDis: false,
            onSaveDis: false,
            accClsYn: '',
            erpTrmsDtm: '',

            searchParams: {
                srchAgencyNm: '', //대리점
                srchAccYm: '', // 정산월,
                srchAccDealcoNm: '', //정산처
                srchPsErpGrpNm: '', //구분
                rmks: '',
            },
        }
    },
    computed: {
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        console.log('mounted')
        this.searchForms.srchAccYm = moment(this.popupParams.srchAccYm).format(
            'YYYYMM'
        )
        //SKT 수수료 정산내역 grid 기본세팅
        this.gridObj2 = this.$refs.grid2
        this.gridHeaderObj2 = this.$refs.gridHeader2
        this.gridObj2.setGridState(false, false, false, true)
        this.gridObj2.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj2.gridView.displayOptions.syncGridHeight = 'always' // 자동높이조정
        this.gridObj2.gridView.setColumnLayout(this.view.layout) //그리드 Header Layout 세팅하기
        this.gridObj2.gridView.summaryMode = 'aggregate'

        //SKT 수수료 정산내역 grid 기본세팅
        this.gridObj3 = this.$refs.grid3
        this.gridHeaderObj3 = this.$refs.gridHeader3
        this.gridObj3.setGridState(false, false, false, false)
        this.gridObj3.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj2.gridView.displayOptions.syncGridHeight = 'always' // 자동높이조정
        this.gridObj3.gridView.setColumnLayout(this.view3.layout1) //그리드 Header Layout 세팅하기

        // 팝업 노출시 넘어온 파라미터로 조회하기
        this.onSearch()
    },
    watch: {
        searchParams(newVal) {
            this.searchParams = newVal
            if (!_.isEmpty(newVal)) {
                this.searchParams = newVal
            }
        },
    },
    methods: {
        gridSetData: function (rowCnt) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, rowCnt, '', '')
        },
        //================================================
        // 상세 조회 :::: getDetailList & getMthDetailList
        //================================================
        onSearch() {
            if (_.isEmpty(this.searchForms.srchAccYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
            }
            //부모페이지에서 가져오기
            //검색창
            this.accYm_ = moment(this.popupParams.srchAccYm).format('YYYY-MM')
            this.searchParams.srchAgencyNm = this.popupParams.agencyNm
            this.searchParams.srchAccDealcoNm = this.popupParams.srchAccDealcoNm
            this.searchParams.srchPsErpGrpNm = this.popupParams.psErpGrpNm
            this.erpTrmsDtm = this.popupParams.erpTrmsDtm
            this.sktTrmsDtm = this.popupParams.sktTrmsDtm
            this.fixYn = this.popupParams.fixYn
            //PARAM
            this.searchForms.srchAccYm = moment(
                this.popupParams.srchAccYm
            ).format('YYYYMM')
            this.searchForms.srchPsErpGrpCd = this.popupParams.psErpGrpCd
            this.searchForms.srchAgencyCd = this.popupParams.agencyCd
            this.searchForms.srchAccDealcoCd = this.popupParams.srchAccDealcoCd
            this.searchForms.srchFlag = this.popupParams.flag
            this.getDetailList(this.searchForms)
            console.log('상세 리스트조회 ::::::: 시작')
        },
        // SKT 수수료 정산내역 조회
        async getDetailList() {
            await sktCmmApi.getDetailList(this.searchForms).then((res) => {
                if (res) {
                    this.dtlParams.dtlList = res.gridList
                    this.gridObj2.setRows(res.gridList)
                    this.getMthDetailList(this.searchForms)
                }
            })
        },
        // SKT 수수료 확정내역 조회
        async getMthDetailList() {
            await sktCmmApi
                .getMthDetailList(this.searchForms)
                .then((result) => {
                    if (result) {
                        this.accClsYn = result.accClsYn
                        this.fixInfos = result.fixInfo

                        this.gridObj3.setRows([this.fixInfos])
                        this.gridObj3.dataProvider.setValue(
                            0,
                            'fixSplyPrct',
                            'SKT수수료공급가'
                        )
                        this.gridObj3.dataProvider.setValue(
                            0,
                            'fixVatAmtt',
                            'SKT수수료부가세'
                        )
                        this.gridObj3.dataProvider.setValue(
                            0,
                            'fixAmtt',
                            'SKT수수료확정금액'
                        )
                        if (!_.isEmpty(this.fixInfos.rmks)) {
                            this.searchParams.rmks = this.fixInfos.rmks
                        }
                        if (this.erpTrmsDtm != null || this.accClsYn == 'Y') {
                            this.showTcComAlert(
                                'ERP 전송 또는 월마감이 완료되었습니다. 확정/삭제 할 수 없습니다.'
                            )
                            this.onDeleteDis = true
                            this.onSaveDis = true
                            //확정이 되었으면 삭제만 가능
                        } else if (this.fixYn == 'Y') {
                            console.log('확정여부(fixYn)::::::::' + this.fixYn)
                            this.showTcComAlert('확정 완료되었습니다.')
                            this.onDeleteDis = false
                            this.onSaveDis = true
                        } else {
                            this.onDeleteDis = true
                            this.onSaveDis = false
                        }
                        //  확정일자 세팅
                        this.confirmDate_ = moment(
                            this.accYm_.replace(/-/g, '')
                        )
                            .endOf('month')
                            .format('YYYY-MM-DD')
                    } else {
                        this.showTcComAlert('정보를 불러오지 못했습니다.')
                    }
                })
        },
        //================================================
        // 확정::::
        //================================================
        onSave: function () {
            if (this.searchParams.accClsYn == 'Y') {
                this.showTcComAlert('월마감이 완료되어 확정할 수 없습니다.')
                return
            }

            // 수수료 확정내역 저장을 위한 합계 구하기
            // Swing금액 공급가
            let fixSplyPrc = this.gridObj2.gridView.getSummary(
                'sktTrmsSplyPrc',
                'sum'
            )
            let fixVatAmt = this.gridObj2.gridView.getSummary(
                'sktTrmsVatAmt',
                'sum'
            )
            // SKT수수료 확정 금액 구하기
            let fixSplyPrcSum = this.gridObj2.gridView.getSummary(
                'fixSplyPrc',
                'sum'
            )
            let fixVatAmtSum = this.gridObj2.gridView.getSummary(
                'fixVatAmt',
                'sum'
            )
            let fixAmt = fixSplyPrcSum + fixVatAmtSum

            this.showTcComConfirm('확정 하시겠습니까?').then((confirm) => {
                console.log('showTcComConfirm confirm: ', confirm)
                if (confirm) {
                    this.gridObj3.gridView.commit()
                    this.gridData = this.gridObj3.setModifyData(this.gridData)
                    // SKT수수료 확정내역 확정일자 세팅
                    this.dtlParams.mthInfo.confirmDate = this.confirmDate_
                    // SKT수수료 확정내역 금액 PARAM 부모화면에서 받기
                    this.dtlParams.mthInfo = this.popupParams
                    // SKT수수료 확정내역 금액 세팅
                    this.dtlParams.mthInfo.accDealcoCd =
                        this.searchForms.srchAccDealcoCd
                    this.dtlParams.mthInfo.fixSplyPrc = fixSplyPrc
                    this.dtlParams.mthInfo.fixVatAmt = fixVatAmt
                    this.dtlParams.mthInfo.fixAmt = fixAmt
                    // 각 수정/입력 비고 값 가져오기
                    this.dtlParams.mthInfo.fixSplyPrcRmks =
                        this.gridData.saveRows[0].fixSplyPrcRmks
                    this.dtlParams.mthInfo.fixVatRmks =
                        this.gridData.saveRows[0].fixVatRmks
                    this.dtlParams.mthInfo.fixAmtRmks =
                        this.gridData.saveRows[0].fixAmtRmks
                    this.dtlParams.mthInfo.rmks = this.searchParams.rmks
                    this.dtlParams.mthInfo.sktTrmsDtm = AccUtil.dateToFormat(
                        new Date(this.dtlParams.mthInfo.sktTrmsDtm),
                        'YYYYMMDD'
                    )
                    console.log(this.dtlParams.mthInfo)
                    sktCmmApi
                        .saveSktCmms(this.dtlParams)
                        .then((res) => {
                            console.log(res + '확정')
                            this.showTcComAlert(
                                'SKT 수수료 정산이 처리 되었습니다.'
                            )
                            this.onClose()
                        })
                        .catch((err) => {
                            console.log('확정실패', err)
                            this.showTcComAlert(
                                'SKT 수수료 처리 실패 하였습니다.'
                            )
                        })
                }
            })
        },

        //================================================
        // 삭제:::: deleteSktCmms
        //================================================
        onDelete: function () {
            if (this.searchParams.accClsYn == 'Y') {
                this.showTcComAlert('월마감이 완료되어 삭제할 수 없습니다.')
                return
            }
            this.showTcComConfirm('삭제 하시겠습니까?').then((confirm) => {
                console.log('showTcComConfirm confirm: ', confirm)
                if (confirm) {
                    this.dtlParams.mthInfo = this.fixInfos
                    this.dtlParams.mthInfo.accYm = CommonUtil.onlyNumber(
                        this.accYm_
                    )
                    this.dtlParams.mthInfo.agencyCd =
                        this.searchForms.srchAgencyCd
                    this.dtlParams.mthInfo.accDealcoCd =
                        this.searchForms.srchAccDealcoCd
                    this.dtlParams.mthInfo.psErpGrpCd =
                        this.searchForms.srchPsErpGrpCd
                    sktCmmApi
                        .deleteSktCmms(this.dtlParams)
                        .then((res) => {
                            console.log(res + '삭제완료')
                            this.showTcComAlert(
                                'SKT 수수료 삭제 처리 하였습니다.'
                            )
                            this.onClose()
                        })
                        .catch((err) => {
                            console.log('삭제실패', err)
                            this.showTcComAlert(
                                'SKT 수수료 처리 실패하였습니다.'
                            )
                        })
                }
            })
        },

        //================================================
        // EXCEL DOWNLOAD
        //================================================
        //SKT수수료정산관리(정산내역)
        downloadDetailListExcel: function () {
            sktCmmApi.downloadDetailListExcel(this.searchForms).then((res) => {
                console.log('정산내역 엑셀다운로드 ::::::: ', res)
                this.gridSetData(res)
            })
        },
        //SKT수수료정산관리(확정내역)
        downloadExcelSub: function () {
            sktCmmApi
                .downloadMthAccFixInfoExcel(this.searchForms)
                .then((res) => {
                    console.log('확정내역 엑셀다운로드 ::::::: ', res)
                    this.gridSetData(res)
                })
        },
        onReset: function () {
            this.onSearch()
        },
        onClose: function () {
            this.$emit('confirm', this.popupParams)
            this.activeOpenAgency = false
        },
    },
}
</script>
