<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">메뉴등록</p>
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap mt20">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComComboBox
                                    labelName="1차메뉴"
                                    v-model="forms.menuNo1"
                                    :codeVal.sync="forms.menuNo1"
                                    :objAuth="objAuth"
                                    :itemList="menuNmList1"
                                    @change="onChange1"
                                    itemText="menuNm"
                                    itemValue="menuNo"
                                    :eRequired="true"
                                    :disabled="menuNo1Dis"
                                >
                                </TCComComboBox>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="1차메뉴NO"
                                    v-model="forms.menuNo1"
                                    :disabled="true"
                                    :eRequired="true"
                                    placeholder="1차메뉴선택시자동입력"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComComboBox
                                    labelName="2차메뉴"
                                    v-model="forms.menuNo2"
                                    :codeVal.sync="forms.menuNo2"
                                    :itemList="menuNmList2"
                                    :objAuth="objAuth"
                                    @change="onChange2"
                                    itemText="menuSupNm"
                                    itemValue="menuSupNo"
                                    :addBlankItem="true"
                                    blankItemText="메뉴선택"
                                    blankItemValue=""
                                    :eRequired="true"
                                    :disabled="menuNo2Dis"
                                >
                                </TCComComboBox>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="2차메뉴NO"
                                    v-model="forms.menuNo2"
                                    :disabled="true"
                                    :eRequired="true"
                                    placeholder="2차메뉴선택시자동입력"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComComboBox
                                    labelName="3차메뉴"
                                    v-model="forms.menuNo3"
                                    :codeVal.sync="forms.menuNo3"
                                    @change="onChange3"
                                    :itemList="menuNmList3"
                                    :objAuth="objAuth"
                                    itemText="menuSupNm"
                                    itemValue="menuSupNo"
                                    :addBlankItem="true"
                                    blankItemText="메뉴선택"
                                    blankItemValue=""
                                    :disabled="menuNo3Dis"
                                >
                                </TCComComboBox>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="3차메뉴NO"
                                    v-model="forms.menuNo3"
                                    :disabled="true"
                                    placeholder="3차메뉴선택시자동입력"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="4차메뉴명"
                                    v-model="forms.menuNm4"
                                    :eRequired="true"
                                    placeholder="입력하세요"
                                    @input="onChange4"
                                ></TCComInput>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="4차메뉴NO"
                                    v-model="forms.menuNo4"
                                    inputRuleType="N"
                                    :eRequired="true"
                                    placeholder="입력하세요"
                                    @input="onChange4"
                                ></TCComInput>
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div1">
                                <span class="inner">
                                    <TCComInput
                                        labelName="4차메뉴URL"
                                        v-model="forms.menuUrl4"
                                        :eRequired="true"
                                        placeholder="입력하세요"
                                        @input="onChange4"
                                    ></TCComInput>
                                </span>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <span class="inner">
                                    <TCComInput
                                        labelName="SORT"
                                        v-model="forms.sortSeq"
                                        :eRequired="true"
                                        inputRuleType="N"
                                        placeholder="입력하세요"
                                    ></TCComInput>
                                </span>
                            </div>
                            <div class="formitem div2">
                                <span class="inner">
                                    <TCComInput
                                        labelName="프로그램ID"
                                        v-model="forms.screenId"
                                        placeholder="입력하세요"
                                    ></TCComInput>
                                </span>
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    v-model="ckParam.mblYn"
                                    labelName="모바일여부"
                                    label="선택하세요"
                                    :objAuth="objAuth"
                                    :itemList="itemList1"
                                >
                                </TCComRadioBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    v-model="ckParam.psYn"
                                    labelName="PS&M전용여부"
                                    label="선택하세요"
                                    :objAuth="objAuth"
                                    :itemList="itemList"
                                >
                                </TCComRadioBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    v-model="ckParam.useYn"
                                    labelName="사용여부"
                                    label="선택하세요"
                                    :objAuth="objAuth"
                                    :itemList="itemList1"
                                >
                                </TCComRadioBox>
                            </div>
                        </div>

                        <!--
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="forms.toDate"
                                    labelName="등록일시"
                                    :disabled="disableEl"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="forms.userNm"
                                    labelName="등록자"
                                    :disabled="disableEl"
                                />
                            </div>
                        </div>
                        -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <div class="right">
                            <!-- 등록버튼 -->
                            <TCComButton
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onInsert"
                                v-if="btInsertDis"
                                >저장</TCComButton
                            >
                            <!-- 수정버튼 -->
                            <TCComButton
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onUpdate"
                                v-if="btUpdateDis"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onClose"
                                >목록</TCComButton
                            >
                        </div>
                    </div>

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >

                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import moment from 'moment'
//====================1차메뉴명====================
import menuApi from '@/api/biz/bas/adm/BasAdmMenuMgmt'
//====================//1차메뉴명====================
import _ from 'lodash'
export default {
    name: 'BasAdmRgst',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
    },
    data() {
        return {
            gridObj: {},
            gridData: {},
            gridHeaderObj: {},
            objAuth: {},
            forms: {
                userNm: '',
                toDate: '',
                psYn: '',
                mblYn: '',
                useYn: '',
                menuNo1: '',
                menuNm1: '',
                menuNo2: '',
                menuNm2: '',
                menuNo3: '',
                menuNm3: '',
                menuNo4: '',
                menuNm4: '',
                bfMenuNo4: '',
                bfMenuUrl4: '',
                menuSupNo2: '',
                menuSupNo3: '',
                menuSupNo4: '',
                newMenuNm: '',
                supMenuNo: '',
                menuUrl: '',
                menuUrl4: '',
                sortSeq: '',
                screenId: '',
                readType: '',
            },
            ckParam: {
                psYn: 'Y',
                mblYn: 'N',
                useYn: 'Y',
            },

            itemList: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '사용',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '미사용',
                },
            ],
            itemList1: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
            disableEl: true,
            menuNmList1: [],
            menuNmList2: [],
            menuNmList3: [],
            //sameCd: 'N',
            readType: '',
            btInsertDis: true,
            btUpdateDis: true,
            menuNo1Dis: false,
            menuNo2Dis: false,
            menuNo3Dis: false,
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.forms.menuNo4 =
                    value['menuNo4'] == undefined ? '' : value['menuNo4']
                this.readType =
                    value['readType'] == undefined ? '' : value['readType']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {},
    mounted() {
        //this.forms.userNm = this.userInfo.userNm
        this.forms.toDate = moment(new Date()).format('YYYY-MM-DD h:mm:ss')

        //수정모드
        if ('U' == this.readType) {
            this.searchDetailMenu()
            //업데이트버튼활성
            this.btUpdateDis = true
            //인서트버튼제거
            this.btInsertDis = false

            this.menuNo1Dis = true
            this.menuNo2Dis = true
            this.menuNo3Dis = true

            //복사모드
        } else if ('B' == this.readType) {
            this.searchDetailMenu()
            //업데이트버튼제거
            this.btUpdateDis = false
            this.btInsertDis = true

            this.menuNo1Dis = true
            this.menuNo2Dis = true
            this.menuNo3Dis = true
        } else {
            //C:신규모드
            this.forms.menuNo4 = ''
            this.forms.menuNm4 = ''
            //업데이트버튼제거
            this.btUpdateDis = false
            this.btInsertDis = true
            //첫번째콤보박스로딩
            this.onInitChange()
        }
    },
    methods: {
        onClose() {
            this.activeOpen = false
        },
        onConfirm() {},
        /*
        onClick() {
            console.log('forms', this.forms)
        },
        */

        async searchDetailMenu() {
            await menuApi.searchDetailMenu(this.forms).then((resultData) => {
                console.log('resultData', resultData)
                //detail값 null 인경우 '' 로 변경처리
                //----------------------------------------
                let rData = resultData[0]
                this.forms = rData
                //--------------------------------------
                console.log('this.forms:', this.forms)
                console.log('this.forms.bfMenuNo4:', this.forms.bfMenuNo4)
                console.log('this.forms.bfMenuUrl4:', this.forms.bfMenuUrl4)

                //첫번째콤보박스로딩
                this.onInitChange()
                //1번코드를 넣어 2번메뉴나열
                this.onChange1(this.forms.menuNo1)
                //2번코드를 넣어 3번메뉴나열
                this.onChange2(this.forms.menuNo2)
                //3번코드를 넣는다
                this.onChange3(this.forms.menuNo3)
                //alert(this.forms.mblYn)
                this.ckParam.mblYn = this.forms.mblYn
                this.ckParam.psYn = this.forms.psYn
                this.ckParam.useYn = this.forms.useYn

                //복사모드일경우
                if ('B' == this.readType) {
                    this.forms.menuNo4 = ''
                    this.forms.menuNm4 = ''
                    this.forms.menuUrl4 = ''
                    this.forms.screenId = ''
                }
            })
        },
        async onInitChange() {
            await menuApi.getMemuLvlList(this.forms).then((resultData) => {
                let menuNmArr = [{ menuNo: '', menuNm: '메뉴선택' }] //1차메뉴이름
                resultData.forEach((v) => {
                    menuNmArr.push(v)
                })
                this.menuNmList1 = menuNmArr
            })
        },
        //1차콤보박스 선택시
        async onChange1(value) {
            if ('C' == this.readType) {
                this.forms.menuNo2 = ''
                this.forms.menuNm2 = ''
                this.forms.menuNo3 = ''
                this.forms.menuNm3 = ''
                this.menuNmList2 = []
                this.menuNmList3 = []
            }
            console.log('onChange1 value: ', value)
            //this.sameCd = 'N'
            //NO자동 추가
            this.forms.menuNo1 = value

            //DB
            this.forms.supMenuNo = value
            //가져올lvl
            this.forms.menuLvlCd = '2'

            await menuApi.getMemuLvlSupList(this.forms).then((resultData) => {
                console.log('resultData', resultData)
                let menuSupNmArr = []
                resultData.forEach((v) => {
                    menuSupNmArr.push(v)
                })

                this.menuNmList2 = menuSupNmArr
            })
        },
        //2차콤보박스선택시
        async onChange2(value) {
            if ('C' == this.readType) {
                this.forms.menuNo3 = ''
                this.forms.menuNm3 = ''
                this.menuNmList3 = []
            }

            console.log('onChange2 value: ', value)

            //NO자동 추가
            this.forms.menuNo2 = value

            //this.sameCd = 'N'
            this.forms.supMenuNo = value
            //가져올lvl
            this.forms.menuLvlCd = '3'
            let menuSupNmArr = []
            await menuApi.getMemuLvlSupList(this.forms).then((resultData) => {
                console.log('resultData', resultData)

                resultData.forEach((v) => {
                    menuSupNmArr.push(v)
                })

                this.menuNmList3 = menuSupNmArr
            })
        },
        //3차콤보박스선택시
        onChange3(value) {
            console.log('onChange3 value: ', value)

            //NO자동 추가
            this.forms.menuNo3 = value

            //this.sameCd = 'N'
            this.forms.supMenuNo = value
        },
        //신규
        onInsert() {
            if (!this.onValidate()) {
                return
            }
            this.forms.psYn = this.ckParam.psYn
            this.forms.mblYn = this.ckParam.mblYn
            this.forms.useYn = this.ckParam.useYn

            //부모 차수 저장.
            //3차코드존재 -> 부모3차 ,2차코드존재 -> 부모2차 ,1차코드존재 -> 불가
            if (this.forms.menuSupNo3) {
                this.forms.menuLvlCd = '3'
                this.forms.supMenuNo = this.forms.menuNo3
            } else {
                this.forms.menuLvlCd = '2'
                this.forms.supMenuNo = this.forms.menuNo2
            }
            //저장되는 메뉴는 무조건 4차메뉴
            this.forms.menuLvlCd = '4'
            this.forms.__rowState = 'created'
            let params = {}
            params = this.forms
            //console.log('=====>저장:', params)
            menuApi.saveMenuMgmt(params).then((resultData) => {
                console.log('resultData::', resultData)

                if ('Y' == resultData.menuNoSameYn) {
                    this.showTcComAlert('동일한 4차메뉴NO가 존재합니다.', {
                        header: '확인',
                        size: '500',
                        confirmLabel: 'OK',
                    })
                } else if ('Y' == resultData.menuUrlSameYn) {
                    this.showTcComAlert('동일한 4차메뉴URL이 존재합니다.', {
                        header: '확인',
                        size: '500',
                        confirmLabel: 'OK',
                    })
                } else {
                    this.$emit('confirm', resultData)
                    this.onClose()
                }

                //
            })
        },
        //수정
        onUpdate() {
            if (!this.onValidate()) {
                return
            }
            this.forms.psYn = this.ckParam.psYn
            this.forms.mblYn = this.ckParam.mblYn
            this.forms.useYn = this.ckParam.useYn

            //부모 차수 저장.
            //3차코드존재 -> 부모3차 ,2차코드존재 -> 부모2차 ,1차코드존재 -> 불가
            if (this.forms.menuSupNo3) {
                this.forms.menuLvlCd = '3'
                this.forms.supMenuNo = this.forms.menuNo3
            } else {
                this.forms.menuLvlCd = '2'
                this.forms.supMenuNo = this.forms.menuNo2
            }
            //저장되는 메뉴는 무조건 4차메뉴
            this.forms.menuLvlCd = '4'
            this.forms.__rowState = 'updated'
            let params = {}
            params = this.forms
            menuApi.saveMenuMgmt(params).then((resultData) => {
                console.log('resultData', resultData)

                if ('Y' == resultData.menuNoSameYn) {
                    this.showTcComAlert('동일한 4차메뉴NO가 존재합니다.', {
                        header: '확인',
                        size: '500',
                        confirmLabel: 'OK',
                    })
                } else if ('Y' == resultData.menuUrlSameYn) {
                    this.showTcComAlert('동일한 4차메뉴URL이 존재합니다.', {
                        header: '확인',
                        size: '500',
                        confirmLabel: 'OK',
                    })
                } else {
                    this.$emit('confirm', resultData)
                    this.onClose()
                }
            })
        },

        onChange4() {
            //변경시 중복확인 N으로 변경
            //this.sameCd = 'N'
        },
        onSameCk() {
            //중복확인 성공여부
            //this.sameCd = 'Y'
        },
        onValidate() {
            if (_.isEmpty(this.forms.menuNm4)) {
                this.showTcComAlert('4차 메뉴명을 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.forms.menuNo4)) {
                this.showTcComAlert('4차 메뉴NO를 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.forms.menuUrl4)) {
                this.showTcComAlert('4차 메뉴URL을 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.forms.sortSeq)) {
                this.showTcComAlert('SORT 을 입력해주세요.')
                return false
            }

            return true
        },
    },
}
</script>
