import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'inoutDt', // 발생일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDtlClCd', // 입출고상세구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDtlClNm', // 입출고상세구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOrgCd', // 출고조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOrgNm', // 출고조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd', // 출고레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm', // 출고레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd1', // 출고레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm1', // 출고레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd2', // 출고레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm2', // 출고레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd3', // 출고레벨3조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm3', // 출고레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outShopCd', // 출고처 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoCd', // 출고처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoNm', // 출고처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgCd', // 입고조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgNm', // 입고조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd', // 입고레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm', // 입고레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd1', // 입고레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm1', // 입고레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd2', // 입고레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm2', // 입고레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd3', // 입고레벨3조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm3', // 입고레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoCd', // 입고처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoNm', // 입고처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inShopCd', // 입고처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId', // 처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm', // 처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodInoutDtlNm', // 상세정보
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleNo', // 판매관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleNoSub', // 판매관리번호구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSalechgSeq', // 일반판매변경순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutClCd', // 입출고구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutMgmtNo', // 입출고관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutSeq', // 입출고순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd', // 제조사코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm', // 제조사명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd', // 상품구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm', // 상품구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum', // 일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 상품코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', // 색상코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badYn', // 불량여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badYnNm', // 불량여부명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disStCd', // 재고상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disStNm', // 재고상태명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disAmt', // 재고금액
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoCd', // 보유처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoNm', // 보유처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldShopCd', // 보유처 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldOrgCd', // 보유처 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldOrgNm', // 보유처 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldLvOrgCd', // 보유처 레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldLvOrgNm', // 보유처 레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldLvOrgCd1', // 보유처 레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldLvOrgNm1', // 보유처 레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldLvOrgCd2', // 보유처 레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldLvOrgNm2', // 보유처 레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldLvOrgCd3', // 보유처 레벨3조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldLvOrgNm3', // 보유처 레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsOrgCd', // 매입처 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsOrgNm', // 매입처 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsLvOrgCd', // 매입처 레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsLvOrgNm', // 매입처 레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsLvOrgCd1', // 매입처 레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsLvOrgNm1', // 매입처 레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsLvOrgCd2', // 매입처 레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsLvOrgNm2', // 매입처 레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsLvOrgCd3', // 매입처 레벨3조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsLvOrgNm3', // 매입처 레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchTypCd', // 구매유형코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchTypNm', // 구매유형명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'openYn', // 개봉여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'openYnNm', // 개봉여부명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'demoYn', // 시연여부
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'inoutDt',
            fieldName: 'inoutDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발생일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'inoutDtlClNm',
            fieldName: 'inoutDtlClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '구분',
        },
        {
            name: 'outOrgNm',
            fieldName: 'outOrgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: '출고조직',
        },
        {
            name: 'outShopCd',
            fieldName: 'outShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처\n매장코드',
                styleName: 'multi-line-css',
            },
        },
        {
            name: 'outDealcoCd',
            fieldName: 'outDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '출고처코드',
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '출고처',
        },
        {
            name: 'inOrgNm',
            fieldName: 'inOrgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: '입고조직',
        },
        {
            name: 'inShopCd',
            fieldName: 'inShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처\n매장코드',
                styleName: 'multi-line-css',
            },
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고처코드',
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '입고처',
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '처리자',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '처리일시',
        },

        {
            name: 'prodInoutDtlNm',
            fieldName: 'prodInoutDtlNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상세정보',
        },
    ],
}
