import { ValueType } from 'realgrid'

export const DisDtrDisMovPrstDtlGRID_HEADER = {
    fields: [
        {
            fieldName: 'movOutClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outFixDt',
            dataType: ValueType.DATETIME,
        },
        {
            fieldName: 'inFixDt',
            dataType: ValueType.DATETIME,
        },
        {
            fieldName: 'chrgrUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inChrgrUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleCnclClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleCnclDt',
            dataType: ValueType.DATETIME,
        },
        {
            fieldName: 'movOutAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'outOprId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOprId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'allMoveYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'movOutClNm',
            fieldName: 'movOutClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동구분',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outFixDt',
            fieldName: 'outFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            },
            width: '150',
        },
        {
            name: 'inFixDt',
            fieldName: 'inFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            },
            width: '150',
        },
        {
            name: 'chrgrUserNm',
            fieldName: 'chrgrUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처 영업담당',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outOrgNm',
            fieldName: 'outOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고조직',
                showTooltip: false,
            },
            width: '400',
        },
        {
            name: 'outDealcoCd',
            fieldName: 'outDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inChrgrUserNm',
            fieldName: 'inChrgrUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처 영업담당',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inOrgNm',
            fieldName: 'inOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고조직',
                showTooltip: false,
            },
            width: '400',
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'saleCnclClNm',
            fieldName: 'saleCnclClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매/반품',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'saleCnclDt',
            fieldName: 'saleCnclDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매(반품)일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
            footer: {
                text: '합계',
            },
            width: '100',
        },
        {
            name: 'movOutAmt',
            fieldName: 'movOutAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고금액',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
            width: '100',
        },
        {
            name: 'outOprId',
            fieldName: 'outOprId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고자',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inOprId',
            fieldName: 'inOprId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고자',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'disFlag',
            fieldName: 'disFlag',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고구분',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'allMoveYn',
            fieldName: 'allMoveYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일괄이동',
                showTooltip: false,
            },
            width: '100',
        },
    ],
}
