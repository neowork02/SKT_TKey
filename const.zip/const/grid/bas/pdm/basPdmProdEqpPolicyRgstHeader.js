import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'strdDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'telpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodPolNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodChrticNm3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodDtlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mstProdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'endDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lunarPhaseCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outAmt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dstrbYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badExceptYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tierNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodPolCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: '__rowState',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'strdDt',
            fieldName: 'strdDt',
            header: {
                text: 'TELP_기준일자',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            header: {
                text: 'TELP_모델',
            },
        },
        {
            name: 'telpNm',
            fieldName: 'telpNm',
            header: {
                text: 'TELP_명칭',
            },
            numberFormat: '',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            header: {
                text: 'TELP_제조사',
            },
        },
        {
            name: 'prodChrticNm1',
            fieldName: 'prodChrticNm1',
            header: {
                text: 'TELP_상품구분1',
            },
        },
        {
            name: 'prodPolNm',
            fieldName: 'prodPolNm',
            header: {
                text: 'TELP_단말정책',
            },
        },
        {
            name: 'prodChrticNm3',
            fieldName: 'prodChrticNm3',
            header: {
                text: 'TELP_상품구분3',
            },
        },
        {
            name: 'prodDtlNm',
            fieldName: 'prodDtlNm',
            header: {
                text: 'TELP_세부모델',
            },
        },
        {
            name: 'mstProdNm',
            fieldName: 'mstProdNm',
            header: {
                text: 'TELP_대표모델',
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            header: {
                text: 'TELP_출시일자',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'petNm',
            fieldName: 'petNm',
            header: {
                text: 'TELP_펫네임',
            },
        },
        {
            name: 'endDt',
            fieldName: 'endDt',
            header: {
                text: 'TELP_단종일자',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'lunarPhaseCd',
            fieldName: 'lunarPhaseCd',
            header: {
                text: 'TELP_월령',
            },
        },
        {
            name: 'outAmt',
            fieldName: 'outAmt',
            header: {
                text: 'TELP_출고가',
            },
        },
        {
            name: 'dstrbYn',
            fieldName: 'dstrbYn',
            header: {
                text: 'TELP_유통여부',
            },
        },
        {
            name: 'badExceptYn',
            fieldName: 'badExceptYn',
            header: {
                text: 'TELP_부진성 제외여부(삭제)',
            },
        },
        {
            name: 'tierNm',
            fieldName: 'tierNm',
            header: {
                text: 'TELP_TIER',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            header: {
                text: '모델코드',
            },
        },
        {
            name: 'prodPolCd',
            fieldName: 'prodPolCd',
            header: {
                text: '단말정책코드',
            },
        },
    ],
}
