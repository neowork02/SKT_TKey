import { ValueType } from 'realgrid'
import _ from 'lodash'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT, //사업담당코드
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT, //사업팀코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //PT
            // dataType: ValueType.TEXT, //조직
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //PT코드
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'pcode',
            dataType: ValueType.TEXT, //P코드
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, //정산처코드
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT, //정산처명
        },
        {
            fieldName: 'dealCoClCd1',
            dataType: ValueType.TEXT, //거래처구분코드1
        },
        {
            fieldName: 'dealCoClCd2',
            dataType: ValueType.TEXT, //거래처구분코드2
        },
        {
            fieldName: 'dealCoClNm2',
            dataType: ValueType.TEXT, //거래처유형
        },
        {
            fieldName: 'repDealcoCd',
            dataType: ValueType.TEXT, //대표거래처코드
        },
        {
            fieldName: 'repDealcoNm',
            dataType: ValueType.TEXT, //대표거래처명
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점
        },
        {
            fieldName: 'repSknDelvPlcCd',
            dataType: ValueType.TEXT, //대표배송지코드(T-key+)
        },
        {
            fieldName: 'repRcvSknDelvPlcCd',
            dataType: ValueType.TEXT, //대표배송지코드(SKN)
        },
        /*  {
            fieldName: 'rcvSknDelvPlcCd',
            dataType: ValueType.TEXT, //회신배송지코드
        }, */
        {
            fieldName: 'repSknDelvPlcNm',
            dataType: ValueType.TEXT, //대표배송지
        },
        {
            fieldName: 'normalYn',
            dataType: ValueType.TEXT, //거래처상태 정상여부
        },
        {
            fieldName: 'dealEndYn',
            dataType: ValueType.TEXT, //거래처상태 거래종료여부
        },
        {
            fieldName: 'payStopYn',
            dataType: ValueType.TEXT, //거래처상태 수납정지여부
        },
        {
            fieldName: 'outStopYn',
            dataType: ValueType.TEXT, //거래처상태 출고정지여부
        },
        {
            fieldName: 'saleStopYn',
            dataType: ValueType.TEXT, //거래처상태 판매정지여부
        },
        {
            fieldName: 'drwStopYn',
            dataType: ValueType.TEXT, //거래처상태 출금정지여부
        },
        {
            fieldName: 'dealStatus',
            dataType: ValueType.TEXT, //거래처상태 - 보여주기용
        },
        {
            fieldName: 'chrgrUserId',
            dataType: ValueType.TEXT, //영업담당자
        },
        {
            fieldName: 'effStaDt',
            dataType: ValueType.TEXT, //유효시작일자
        },
        {
            fieldName: 'effEndDt',
            dataType: ValueType.TEXT, //유효종료일자
        },
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, //순번
        },
        {
            fieldName: 'dealTypCd',
            dataType: ValueType.TEXT, //거래유형코드
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.BOOLEAN,
        },
    ],
    columns: [
        // {
        //     name: 'chkable',
        //     fieldName: 'chkable',
        //     width: '60',
        //     renderer: {
        //         type: 'check',
        //     },
        //     header: {
        //         text: '체크',
        //     },
        // },
        {
            name: 'bizChrgOrgCd',
            fieldName: 'bizChrgOrgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'teamOrgCd',
            fieldName: 'teamOrgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업팀코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직명',
                // text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
        },
        {
            name: 'pcode',
            fieldName: 'pcode',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'P코드',
                showTooltip: false,
            },
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처명',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoClCd1',
            fieldName: 'dealCoClCd1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분코드1',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'dealCoClCd2',
            fieldName: 'dealCoClCd2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분코드2',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'dealCoClNm2',
            fieldName: 'dealCoClNm2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처유형',
                showTooltip: false,
            },
        },
        {
            name: 'repDealcoCd',
            fieldName: 'repDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'repDealcoNm',
            fieldName: 'repDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표거래처명',
                showTooltip: false,
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점',
                showTooltip: false,
            },
        },
        {
            name: 'repSknDelvPlcCd',
            fieldName: 'repSknDelvPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표배송지코드',
                showTooltip: false,
            },
        },
        {
            name: 'repRcvSknDelvPlcCd',
            fieldName: 'repRcvSknDelvPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표배송지코드(SKN)',
                showTooltip: false,
            },
        },
        /* {
            name: 'rcvSknDelvPlcCd',
            fieldName: 'rcvSknDelvPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '회신배송지코드',
                showTooltip: false,
            },
        }, */
        {
            name: 'repSknDelvPlcNm',
            fieldName: 'repSknDelvPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표배송지명',
                showTooltip: false,
            },
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처상태',
                showTooltip: false,
            },
            displayCallback: function (grid, index) {
                let sResult = ''
                const normalYnTxt = grid.getValue(index.itemIndex, 'normalYn')
                const dealEndYnTxt = grid.getValue(index.itemIndex, 'dealEndYn')
                const payStopYnTxt = grid.getValue(index.itemIndex, 'payStopYn')
                const outStopYnTxt = grid.getValue(index.itemIndex, 'outStopYn')
                const saleStopYnTxt = grid.getValue(
                    index.itemIndex,
                    'saleStopYn'
                )
                const drwStopYnTxt = grid.getValue(index.itemIndex, 'drwStopYn')

                if (!_.isEmpty(payStopYnTxt)) {
                    if (payStopYnTxt.toUpperCase() == 'Y') {
                        sResult += ',수납정지'
                    }
                }
                if (!_.isEmpty(outStopYnTxt)) {
                    if (outStopYnTxt.toUpperCase() == 'Y') {
                        sResult += ',출고정지'
                    }
                }
                if (!_.isEmpty(saleStopYnTxt)) {
                    if (saleStopYnTxt.toUpperCase() == 'Y') {
                        sResult += ',판매정지'
                    }
                }
                if (!_.isEmpty(normalYnTxt)) {
                    if (normalYnTxt.toUpperCase() == 'Y') {
                        sResult += ',정상'
                    }
                }
                if (!_.isEmpty(drwStopYnTxt)) {
                    if (drwStopYnTxt.toUpperCase() == 'Y') {
                        sResult += ',출금정지'
                    }
                }
                if (!_.isEmpty(dealEndYnTxt)) {
                    if (dealEndYnTxt.toUpperCase() == 'Y') {
                        sResult += ',거래종료'
                    }
                }

                return sResult.substring(1, sResult.length)
            },
        },
        {
            name: 'chrgrUserId',
            fieldName: 'chrgrUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업담당자',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_HEADER_REGISTER = {
    fields: [
        {
            fieldName: 'no',
            dataType: ValueType.TEXT, //번호
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직명
        },
        {
            fieldName: 'lvOrgNm',
            dataType: ValueType.TEXT, //레벨0조직명
        },
        {
            fieldName: 'lvOrgNm1',
            dataType: ValueType.TEXT, //레벨1조직명
        },
        {
            fieldName: 'lvOrgNm2',
            dataType: ValueType.TEXT, //레벨2조직명
        },
        {
            fieldName: 'lvOrgNm3',
            dataType: ValueType.TEXT, //레벨3조직명
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'pCode',
            dataType: ValueType.TEXT, //P코드
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, //정산처코드
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT, //정산처명
        },
        {
            fieldName: 'dealcoClCd',
            dataType: ValueType.TEXT, //거래처유형코드
        },
        {
            fieldName: 'dealcoClNm',
            dataType: ValueType.TEXT, //거래처유형명
        },
        {
            fieldName: 'repDealcoCd',
            dataType: ValueType.TEXT, //대표거래처코드
        },
        {
            fieldName: 'repDealcoNm',
            dataType: ValueType.TEXT, //대표거래처명
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'repSknDelvPlcCd',
            dataType: ValueType.TEXT, //대표배송지코드(Tkey)
        },
        {
            fieldName: 'repRcvSknDelvPlcCd',
            dataType: ValueType.TEXT, //대표배송지코드(SKN)
        },
        {
            fieldName: 'repSknDelvPlcNm',
            dataType: ValueType.TEXT, //대표배송지명
        },
        {
            fieldName: 'dealcoSt',
            dataType: ValueType.TEXT, //거래처상태
        },
        {
            fieldName: 'chrgrUserId',
            dataType: ValueType.TEXT, //영업담당자
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //오류사항
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, //회사구분코드
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT, //처리자ID
        },
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, //순번
        },
        {
            fieldName: 'tdayProcYn',
            dataType: ValueType.TEXT, //당일처리여부
        },
    ],
    columns: [
        // {
        //     name: 'no',
        //     fieldName: 'no',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '번호',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직명',
                showTooltip: false,
            },
        },
        {
            name: 'lvOrgNm',
            fieldName: 'lvOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '레벨0조직명',
                showTooltip: false,
            },
        },
        {
            name: 'lvOrgNm1',
            fieldName: 'lvOrgNm1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '레벨1조직명',
                showTooltip: false,
            },
        },
        {
            name: 'lvOrgNm2',
            fieldName: 'lvOrgNm2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '레벨2조직명',
                showTooltip: false,
            },
        },
        {
            name: 'lvOrgNm3',
            fieldName: 'lvOrgNm3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '레벨3조직명',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
        },
        {
            name: 'pCode',
            fieldName: 'pCode',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'P코드',
                showTooltip: false,
            },
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처명',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoClCd',
            fieldName: 'dealcoClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처유형코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoClNm',
            fieldName: 'dealcoClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처유형명',
                showTooltip: false,
            },
        },
        {
            name: 'repDealcoCd',
            fieldName: 'repDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'repDealcoNm',
            fieldName: 'repDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표거래처명',
                showTooltip: false,
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점',
                showTooltip: false,
            },
        },
        {
            name: 'repSknDelvPlcCd',
            fieldName: 'repSknDelvPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표배송지코드',
                showTooltip: false,
            },
        },
        {
            name: 'repRcvSknDelvPlcCd',
            fieldName: 'repRcvSknDelvPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표배송지코드(SKN)',
                showTooltip: false,
            },
        },
        {
            name: 'repSknDelvPlcNm',
            fieldName: 'repSknDelvPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표배송지명',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoSt',
            fieldName: 'dealcoSt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처상태',
                showTooltip: false,
            },
        },
        {
            name: 'chrgrUserId',
            fieldName: 'chrgrUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업담당자',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류사항',
                showTooltip: false,
            },
        },
    ],
}
