<!-----------------------------------------------
 * 업무그룹명: 수탁매출입출고
 * 서브업무명: 상품입력(재고검색)팝업
 * 설명: 매출 재고상품을 조회한다.
 * 작성자: P179890
 * 작성일: 2022.06.06
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<!-- 
TODO 
-->
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">상품입력(재고검색)</p>
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="left"></li>
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="clearBtn"
                                >초기화</TCComButton
                            >
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="searchBtn"
                            >
                                조회
                            </TCComButton>
                            <!-- <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="closeBtn"
                            >
                                닫기
                            </TCComButton> -->
                        </li>
                    </ul>
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <span class="itemtit">매출출고일</span>
                                <TCComDatePicker
                                    :calType="calType"
                                    v-model="setDate"
                                >
                                </TCComDatePicker>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="출고처"
                                    :disabled="true"
                                    :eRequired="true"
                                    v-model="reqParam.outPlcNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComComboBox
                                    codeId="ZBAS_C_00010"
                                    labelName="상품구분"
                                    :objAuth="objAuth"
                                    v-model="reqParam.prodCl"
                                    :addBlankItem="true"
                                    :blankItemText="'전체'"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="일련번호"
                                    v-model="reqParam.serNum"
                                    @enterKey="searchBtn"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComComboBox
                                    codeId="ZBAS_C_00500"
                                    labelName="단말기구분"
                                    :objAuth="objAuth"
                                    v-model="reqParam.mdlClCd"
                                    :addBlankItem="true"
                                    :blankItemText="'전체'"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComComboBox
                                    labelName="제조사"
                                    :objAuth="objAuth"
                                    v-model="reqParam.mfactId"
                                    :addBlankItem="true"
                                    :blankItemText="'전체'"
                                    :autocomplete="true"
                                    :itemList="mfactComboList"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    labelName="모델"
                                    @enterKey="onProdsIconClick"
                                    @appendIconClick="onProdsIconClick"
                                    @input="reqParam.prodCd = ''"
                                    :objAuth="objAuth"
                                    v-model="reqParam.prodNm"
                                    :codeVal="reqParam.prodCd"
                                    :disabledAfter="true"
                                >
                                </TCComInputSearchText>
                                <BasBcoProdsPopup
                                    v-if="basBcoProdsShow === true"
                                    :dialogShow.sync="basBcoProdsShow"
                                    :parentParam="searchProdForm"
                                    :rows="resultProdsRows"
                                    @confirm="onProdsReturnData"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="popupGridHeader"
                            ref="gridHeader"
                            gridTitle="상품내역"
                            :gridObj="gridObj"
                            :isPageRows="true"
                        />
                        <TCRealGrid
                            id="popupGrid"
                            ref="grid"
                            :fields="view.fields"
                            :columns="view.columns"
                            :styles="gridStyle"
                        />
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="confirmBtn"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            :objAuth="objAuth"
                            @click="closeBtn()"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil, CommonMsg } from '@/utils'
import commonApi from '@/api/common/prototype'
import { DisCioDisSrchPopup_GRID_HEADER } from '@/const/grid/dis/cio/disCioDisSrchPopupHeader.js'
import cioApi from '@/api/biz/dis/cio/disCioConsigmentSaleRtnMgmtDtl.js'
import opnApi from '@/api/biz/dis/opn/disOpnOpenStMgmtProdRgst.js'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================

export default {
    name: 'DisIioSaleRtnDisSrchPopup',
    mixins: [CommonMixin],
    components: { BasBcoProdsPopup },
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        params: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
        prodOrgList: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        },
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        setDate: {
            get() {
                return [this.reqParam.fromDt, this.reqParam.toDt]
            },
            set(val) {
                this.reqParam.fromDt = val[0]
                this.reqParam.toDt = val[1]
                return val
            },
        },
    },
    data() {
        return {
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            searchProdForm: {
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
                prodClCd: '', //상품구분
                sktOperYn: '', //skt운영여부
                useYn: '', //사용여부
            },
            //====================//상품팝업관련==================
            objAuth: {},
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},
            view: DisCioDisSrchPopup_GRID_HEADER,
            searchForms: {},
            rowCnt: 15,
            removeCnt: 0,
            calType: 'DP',
            alertHeadTxt: '상품입력(재고검색)',
            gridStyle: {
                height: '300px', //그리드 높이 조절
            },
            mfactComboList: [],
            reqParam: {
                // 요청파라미터
                fromDt: '',
                toDt: '',
                outSchdDt: '', // 출고예정일
                outPlcId: '', // 출고처ID
                outPlcNm: '', // 출고처명
                mdlClCd: '', // 단말기구분
                prodCl: '', // 상품구분코드
                mfactId: '', // 제조사
                serNum: '', // 일련번호
                prodCd: '', // 모델코드
                prodNm: '', // 모델명
                prchTyp: '', // 구매유형
            },
        }
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.setRowStyleCallback(function (grid, item) {
            let ret = {}
            const regYn = grid.getValue(item.index, 'regYn')

            if (regYn == '1') {
                ret.editable = false
                ret.styleName = 'rg-fileuplod-error'
            }

            return ret
        })
        this.gridObj.gridView.setCheckableExpression(
            "values['regYn'] < 1",
            true
        )
        // 제조사조회
        this.getMfact()
        // 공통코드 조회 그리드 property 추가
        this.getCommCodeList('ZDIS_C_00090', 'badYn') // 불량여부
        this.getCommCodeList('ZDIS_C_00100', 'disSt') // 재고상태
        this.init()
    },
    methods: {
        init() {
            this.reqParam.fromDt = moment(new Date()).format('YYYY-MM-01') // 개봉지시일 from
            this.reqParam.toDt = moment(new Date()).format('YYYY-MM-DD') // 개봉지시일 to
            this.reqParam.outSchdDt = this.params['outSchdDt']
            this.reqParam.outPlcId = this.params['outPlcId']
            this.reqParam.outPlcNm = this.params['outPlcNm']
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
            // this.gridData.totalPage = 0
        },
        closeBtn() {
            this.activeOpen = false
        },
        //GridSetData
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(0, 15, '', '')
        },
        // 제조사 조회
        getMfact() {
            const mfactParam = { dealCoCl: '20' }
            opnApi.getMfact(mfactParam).then((res) => {
                this.mfactComboList = res
            })
        },
        // Validation 체크
        isValidChk() {
            if (_.isEmpty(this.reqParam.outPlcId)) {
                //MSG_00083: ' %s(을)를 입력 하여 주시기 바랍니다.',
                this.openAlert(CommonMsg.getMessage('MSG_00083', '출고처ID'))
                return false
            }
            if (_.isEmpty(this.reqParam.fromDt)) {
                //MSG_00083: ' %s(을)를 입력 하여 주시기 바랍니다.',
                this.openAlert(
                    CommonMsg.getMessage('MSG_00083', '출고시작일자')
                )
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.fromDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            if (_.isEmpty(this.reqParam.toDt)) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00083', '출고종료일자')
                )
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.toDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            if (
                this.reqParam.fromDt.substr(0, 7) !==
                this.reqParam.toDt.substr(0, 7)
            ) {
                this.openAlert('시작일자와 종료일자을 동일한 월로 지정하세요.')
                return false
            }
            if (
                this.reqParam.fromDt.replaceAll('-', '') >
                this.reqParam.toDt.replaceAll('-', '')
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_01026'))
                return false
            }
            return true
        },
        getCommCodeList(codeId, columnId) {
            commonApi.getCommonCodeList(codeId).then((res) => {
                let columnValues = []
                let columnLabels = []
                if (res.length) {
                    res.forEach((data) => {
                        columnValues.push(data.commCdVal)
                        columnLabels.push(data.commCdValNm)
                    })
                }
                // 그리드 컬럼 콤보박스 데이터 설정
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'values',
                    columnValues
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'labels',
                    columnLabels
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'lookupDisplay',
                    true
                )
            })
        },
        // 개봉상품등록 그리드에 선택된 상품 중복 제외
        setNewProd(prodList) {
            if (this.prodOrgList.length > 0) {
                for (var i = 0; i < this.prodOrgList.length; i++) {
                    for (var j = 0; j < prodList.length; j++) {
                        if (
                            this.prodOrgList[i].serNum == prodList[j].serNum &&
                            this.prodOrgList[i].colorCd ==
                                prodList[j].colorCd &&
                            this.prodOrgList[i].prodCd == prodList[j].prodCd
                        ) {
                            prodList[j].regYn = '1'
                        }
                    }
                }
            }
            return prodList
        },
        // 초기화 버튼 이벤트
        clearBtn() {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.init()
        },
        // 확인버튼
        confirmBtn() {
            var chkRow = this.gridObj.gridView.getCheckedRows(true)
            if (chkRow.length == 0) {
                this.openAlert(CommonMsg.getMessage('MSG_00134', '상품'))
                return
            }

            const chkProdList = []
            for (var i = 0; i < chkRow.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(chkRow[i], true)
                chkProdList.push(row)
            }
            this.$emit('addDisProdList', chkProdList)
            this.activeOpen = false
        },
        //조회 버튼 이벤트
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            //첫 조회시 표시할 행의 갯수
            this.searchForms = { ...this.reqParam }
            this.searchForms.fromDt = CommonUtil.onlyNumber(
                this.searchForms.fromDt
            )
            this.searchForms.toDt = CommonUtil.onlyNumber(this.searchForms.toDt)

            // 2022-09-06 페이징 삭제
            // this.searchForms.pageSize = this.rowCnt
            // this.searchForms.pageNum = 1 //첫번째 페이지
            // this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getEntrustedSaleRtnProdList()
        },
        getEntrustedSaleRtnProdList() {
            cioApi.getEntrustedSaleRtnProdList(this.searchForms).then((res) => {
                const girdList = this.setNewProd(res.gridList)
                this.gridObj.setRows(girdList)
                this.gridHeaderObj.setPageCount({
                    totalDataCnt: res.gridList.length,
                })

                // 2022-09-06 페이징 삭제
                // this.gridData = this.gridSetData() //초기화
                // this.gridObj.setGridIndicator(res.pagingDto) //순번이 필요한경우 계산하는 함수
                // this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수

                //Grid Row 가져올때 총건수 Setting
                // this.gridHeaderObj.setPageCount(res.pagingDto)
            })
        },
        // alert창 호출
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                if (res.length === 1) {
                    this.reqParam.prodCd = _.get(res[0], 'prodCd')
                    this.reqParam.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            this.searchProdForm['prodCd'] = this.reqParam['prodCd']
            this.searchProdForm['prodNm'] = this.reqParam['prodNm']
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.reqParam.prodNm)) {
                this.getProdsList()
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            this.reqParam.prodCd = _.get(retrunData, 'prodCd')
            this.reqParam.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
