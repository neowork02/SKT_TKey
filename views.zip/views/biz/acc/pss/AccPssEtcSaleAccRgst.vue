<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">대리점별 상세</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Top BTN -->
                    <ul class="btn_area pop">
                        <li class="left">
                            <TCComButton
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                :disabled="disabledBtnDel"
                                @click="delBtn"
                                >삭제</TCComButton
                            >
                        </li>
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="fSearch"
                                :objAuth="objAuth"
                            >
                                조회
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="closeTopBtn"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton>
                        </li>
                    </ul>
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                    <!-- // Top BTN -->
                    <div class="contBoth">
                        <div class="searchLayer_wrap">
                            <div class="searchform">
                                <div class="formitem div3">
                                    <TCComDatePicker
                                        labelName="정산월"
                                        calType="M"
                                        eClass="div2"
                                        v-model="searchFormData.accYm_"
                                        :disabled="true"
                                    >
                                    </TCComDatePicker>
                                </div>

                                <div class="formitem div3">
                                    <TCComInput
                                        labelName="대리점"
                                        :disabled="true"
                                        v-model="searchFormData.agencyNm"
                                        :disabledAfter="true"
                                    >
                                    </TCComInput>
                                </div>

                                <div class="formitem div3">
                                    <TCComComboBox
                                        labelName="상품구분"
                                        :itemList="arClCdItems"
                                        v-model="searchFormData.arClCd"
                                        :objAuth="objAuth"
                                        :disabled="true"
                                    ></TCComComboBox>
                                </div>
                            </div>
                        </div>
                        <!-- //Search_div -->
                    </div>
                    <div class="gridWrap">
                        <!-- SubTit -->
                        <TCRealGridHeader
                            id="popupGridHeader1"
                            ref="popupGridHeader1"
                            gridTitle="대리점별 상세"
                            :isExceldown="true"
                            :gridObj="gridObj"
                            :gridHeaderObj="gridHeaderObj"
                            @excelDownBtn="exportGridBtn"
                        />
                        <TCRealGrid
                            id="popupGrid1"
                            ref="popupGrid1"
                            :fields="view.fields"
                            :columns="view.columns"
                            :gridObj="gridObj"
                            :styles="gridStyle"
                        />
                    </div>
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { GRID_POP_HEADER } from '@/const/grid/acc/pss/AccPssEtcSaleAccRgstGrid'
import moment from 'moment'
import etcSaleApi from '@/api/biz/acc/pss/accPssEtcSaleAccMgmt'
import _ from 'lodash'
import CommonMixin from '@/mixins'
export default {
    name: 'accPssEtcSaleAccRgst',
    mixins: [CommonMixin],
    props: {
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            //Paging Class init
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '400px',
            },

            objAuth: {},
            list: [],
            etcProdAccDtl: [],
            view: GRID_POP_HEADER,
            localPersistent: true,
            disabledBtnDel: true,

            //alert창
            showAlertBool: false,
            alertBodyText: '',

            saveYn: '', //  삭제버튼 활성화여부

            searchFormData: {
                accYm: moment(new Date()).format('YYYY-MM'), // 정산월
                agencyCd: '',
                arClCd: '',
                items: [],
            },

            arClCdItems: [
                {
                    commCdVal: 'SAVE',
                    commCdValNm: '상품매출-SAVE카드',
                },
                {
                    commCdVal: 'SAF1',
                    commCdValNm: '상품매출-폰세이브',
                },
            ],
        }
    },
    created() {},
    mounted() {
        this.searchFormData.agencyCd = this.popupParams.agencyCd
        this.searchFormData.agencyNm = this.popupParams.agencyNm
        this.searchFormData.accYm_ = this.popupParams.accYm_
        this.searchFormData.accYm = this.popupParams.accYm
        this.searchFormData.arClCd = this.popupParams.arClCd

        /****************** Grid **********************/
        this.gridObj = this.$refs.popupGrid1
        this.gridHeaderObj = this.$refs.popupGridHeader1
        this.gridObj.setRows()
        /* this.gridObj.setGridState()*/
        this.gridObj.setGridState(false, false, false, true)
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.fInit()

        /****************** Event **********************/
        if (this.popupParams.saveYn == 'N') {
            this.disabledBtnDel = true
        } else {
            this.disabledBtnDel = false
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        // 닫기
        closeBtn: function () {
            this.activeOpen = false
            this.$emit('close')
        },
        closeTopBtn: function () {
            console.log('닫기')
            this.activeOpen = false
        },

        fInit: function () {
            this.searchFormData.wrtDt = ''
            this.etcProdAccDtl = []
            this.etcProdAccDtl.push({
                agencyCd: this.popupParams.agencyCd,
                arClCd: this.popupParams.arClCd,
                accYm: this.popupParams.accYm,
            })
            this.fSearch()
        },
        async fSearch() {
            if (_.isEmpty(this.popupParams.agencyCd)) {
                return
            }
            // this.etcProdAccDtl = []
            await etcSaleApi
                .getAccPssEtcSaleAccRgsts(this.searchFormData)
                .then((res) => {
                    this.etcProdAccDtl = res
                    this.$refs.popupGrid1.setRows(this.etcProdAccDtl)
                    console.log('etcProdAccDtl::::', this.etcProdAccDtl)
                })
        },
        exportGridBtn: function () {
            etcSaleApi
                .getAccPssEtcSaleAccRgstExcel(this.searchFormData)
                .then((res) => {
                    console.log('엑셀다운로드 ::::::: ', res)
                })
                .catch((err) => {
                    console.log('err::::', err)
                })
        },
        async delBtn() {
            // 처리 유형 1
            const confirm = await this.showTcComConfirm('삭제 하시겠습니까?')

            if (confirm) {
                this.deleteData()
            }
        },
        deleteData: function () {
            this.searchFormData.items = []
            var rowCount = this.gridObj.dataProvider.getRowCount()
            if (rowCount > 0) {
                for (var i = 0; i < rowCount; i++) {
                    this.searchFormData.items.push(
                        this.gridObj.dataProvider.getOutputRow(
                            { datetimeFormat: 'yyyyMM' },
                            i
                        )
                    )
                }
            }
            etcSaleApi.delEtcProdAcc(this.searchFormData).then((resultData) => {
                if (resultData) {
                    this.showTcComAlert('삭제되었습니다.')
                    this.closeBtn()
                }
            })
            // }
        },
        clearBtn: function () {
            this.fSearch()
        },
    },
}
</script>
