<!-----------------------------------------------
 * 업무그룹명: Swing입고상품팝업
 * 서브업무명: Swing입고상품팝업
 * 설명: Swing입고상품한다.
 * 작성자: P179234
 * 작성일: 2022.04.05
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">Swing입고상품</p>
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="left">
                            <TCComButton
                                eClass="btn_ty"
                                :eOutlined="true"
                                :objAuth="objAuth"
                                @click="check()"
                                >오류검증</TCComButton
                            >
                        </li>
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="searchSwingInProdIns()"
                                >조회</TCComButton
                            >
                        </li>
                    </ul>

                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="입고예정일"
                                    :calType="calType5"
                                    :eRequired="true"
                                    v-model="opDt"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="조직"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.orgNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="입고구분"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.inoutClNm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComComboBox
                                    labelName="반영여부"
                                    :itemList="searchCode[0]"
                                    :objAuth="objAuth"
                                    v-model="reqParam.reflYn"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader"
                            ref="gridHeader"
                            gridTitle="입고상품목록"
                            :gridObj="gridObj"
                            :isDelRow="true"
                            :isPageRows="true"
                            :isExceldown="true"
                            :isNextPage="true"
                            :isPageCnt="true"
                            @chkDelRowBtn="delRow"
                            @excelDownBtn="excelDown"
                        />
                        <TCRealGrid
                            id="gridField"
                            ref="gridField"
                            :fields="gridSet.fields"
                            :columns="gridSet.columns"
                            :styles="gridStyle"
                        />
                        <TCComPaging
                            :totalPage="gridData.totalPage"
                            :apiFunc="getDisDcoSwingInProdIns"
                            :gridObj="gridObj"
                        />
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :disabled="isChecked"
                            :eLarge="true"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import moment from 'moment'
import CommonMixin from '@/mixins'
import { CommonGrid, CommonUtil } from '@/utils'
import { GRID_HEADER } from '@/const/grid/dis/dco/disDcoSwingInProdInsPopupHeader.js'
import swingInProdInsApi from '@/api/biz/dis/dco/disDcoSwingInProdIns.js'

export default {
    name: 'DisDcoSwingInProdInsPop',
    mixins: [CommonMixin],
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        parentParam: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            objAuth: {},
            codeIDView: true,
            codeIDViewVal: '',
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridDataRaw: {},
            gridStyle: {
                height: '400px',
            },
            gridSet: GRID_HEADER,
            rowCnt: 15,
            opDt: [],
            searchForms: {},
            searchable: false,
            isChecked: true,
            calType5: 'DP',
            searchCode: [
                [
                    {
                        commCdVal: '' && 'N',
                        commCdValNm: 'N',
                    },
                    {
                        commCdVal: 'Y',
                        commCdValNm: 'Y',
                    },
                ],
            ],
            reqParam: {
                strdDt: '',
                endDt: '',
                orgCd: '',
                orgNm: '',
                orgLevel: '',
                inoutClCd: '',
                inoutClNm: '',
                reflYn: '',
            },
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
                this.$emit('update:Prod', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log(value)
                this.reqParam = {
                    strdDt: '',
                    endDt: '',
                    orgCd: value.orgCd,
                    orgNm: value.orgNm,
                    orgLevel: value.orgLvl,
                    inoutClCd: value.inClCd,
                    inoutClNm: value.inClNm,
                    dealcoCd: value.inDealcoCd,
                    dealcoNm: value.inDealcoNm,
                    reflYn: '',
                }
            },
            deep: true,
            immediate: true,
        },
        opDt: {
            handler: function (value) {
                this.searchable =
                    value[0] === '' || value[1] === '' ? false : true
            },
            deep: true,
            immediate: true,
        },
    },
    created() {
        this.opDt = [this.getFirstday(), this.getToday()]
    },
    mounted() {
        // this.init()
        this.setGrid()
    },
    methods: {
        /* 초기화 - 파라미터 */
        init() {
            this.newParam()
            this.opDt = [this.reqParam.strdDt, this.reqParam.endDt]
        },
        newParam() {
            this.reqParam = {
                strdDt: '',
                endDt: '',
                orgCd: '',
                orgNm: '',
                orgLevel: '',
                inoutClCd: '',
                inoutClNm: '',
                reflYn: '',
            }
        },
        /* 그리드 설정 - 오류없을 시 체크박스 수정가능 */
        setGrid() {
            this.gridObj = this.$refs.gridField
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.setGridState(false, false, true)
            this.gridObj.gridView.setRowIndicator({
                visible: true,
                headText: '번호',
            })
            this.gridObj.gridView.setCheckableExpression(
                "values['errDesc'] = '이상없음'",
                true
            )
        },
        /* 그리드 설정 */
        gridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        /* Swing입고상품 조회 - 최초 */
        searchSwingInProdIns() {
            const startMonth = this.opDt[0].substring(5, 7)
            const endMonth = this.opDt[1].substring(5, 7)

            if (this.searchable === false) {
                this.showTcComAlert('입고예정일은 필수값입니다.')
            } else if (startMonth !== endMonth) {
                this.showTcComAlert(
                    '입고예정일의 시작일과 종료일을 동일한 월로 지정해 주세요.'
                )
            } else {
                this.gridData.totalPage = 0
                this.searchForms = { ...this.reqParam }
                this.searchForms.pageSize = this.rowCnt
                this.searchForms.pageNum = 1
                this.searchForms.reflYn =
                    this.reqParam.reflYn === '' ? 'N' : this.reqParam.reflYn
                this.searchForms.strdDt = CommonUtil.onlyNumber(this.opDt[0])
                this.searchForms.endDt = CommonUtil.onlyNumber(this.opDt[1])
                this.getDisDcoSwingInProdIns(this.searchForms.pageNum)
            }
        },
        /* Swing입고상품 조회 - 페이징 */
        async getDisDcoSwingInProdIns(page) {
            this.searchForms.pageNum = page

            await swingInProdInsApi
                .getSwingInProdIns(this.searchForms)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator(res.pagingDto)
                        this.gridData = this.gridSetData()
                        this.gridData.totalPage = res.pagingDto.totalPageCnt
                        this.gridHeaderObj.setPageCount(res.pagingDto)
                        this.isChecked = true
                    }
                })
        },
        /* Swing입고상품 오류조회  */
        async getDisDcoSwingInProdCheck() {
            const arr = [...this.gridObj.dataProvider.getJsonRows()]
            let jsonData = []
            await arr.forEach((data) => {
                jsonData.push(data)
            })
            if (jsonData.length === 0) {
                this.showTcComAlert('처리할 대상이 없습니다.')
                return
            } else {
                this.showTcComAlert(
                    '오류사항이 발생된 상품은 체크가 비활성화 됩니다.'
                )
            }

            this.gridData.totalPage = 0
            await swingInProdInsApi
                .getSwingInProdInsCheck(jsonData)
                .then((res) => {
                    console.log(res)
                    const list = res.gridList
                    if (res) {
                        if (this.checkValaue(list) === 0) {
                            this.showTcComAlert('정상적인 데이터가 없습니다.')
                        }

                        this.gridObj.setRows(res.gridList)
                        this.gridData = this.gridSetData()
                        this.gridHeaderObj.setPageCount({ totalDataCnt: 15 })
                        this.isChecked = false
                    } else {
                        this.showTcComAlert('서버오류 발생했습니다.')
                    }
                })
        },
        /* 정상적인 데이터 유무 */
        checkValaue(list) {
            list.filter((data) => {
                console.log(data.errDesc)
                let num = 0
                if (data.errDesc === '이상없음') {
                    num++
                }
                return num
            })
        },
        /* 조회 팝업 */
        btnClick() {
            console.log('cli ck')
        },
        /* 현재일자 확인(yyyy-mm-dd)*/
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
        // 이번달 1일 yyyy-mm-01
        getFirstday: function () {
            var date = new Date()
            var year = date.getFullYear()
            var month = ('0' + (1 + date.getMonth())).slice(-2)

            return year + '-' + month + '-' + '01'
        },
        /* 확인 */
        onConfirm() {
            let jsonData = []
            const checked = this.gridObj.gridView.getCheckedRows()
            checked.forEach((check) => {
                const data = this.gridObj.dataProvider.getJsonRow(check)
                jsonData.push(data)
            })
            console.log(jsonData)
            if (jsonData.length === 0) {
                this.showTcComAlert('체크 등록 된 상품이 없습니다.')
            } else {
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        /* 팝업 창닫기 */
        onClose() {
            this.activeOpen = false
        },
        test(vale) {
            console.log('test value: ', vale)
        },
        /* 행삭제 */
        delRow() {
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        /* 엑셀다운로드 */
        excelDown() {
            this.gridHeaderObj.exportGrid('test.xls')
        },
        /* 오류검증 */
        check() {
            this.getDisDcoSwingInProdCheck()
        },
    },
}
</script>
