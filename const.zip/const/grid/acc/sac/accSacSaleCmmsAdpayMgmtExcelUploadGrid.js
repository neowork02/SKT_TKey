'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: 'accSt',
        editable: false,
        header: { text: '정산상태' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'orgCd',
        editable: false,
        header: { text: '영업파트코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'orgNm',
        editable: false,
        header: { text: '영업파트' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accDealcoCd',
        editable: false,
        header: { text: '정산처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accDealcoNm',
        editable: false,
        header: { text: '정산처명' },
        type: 'data',
        styleName: 'left-column',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'preAccAmt',
        editable: false,
        header: { text: '선지급금액' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'errDesc',
        editable: false,
        header: { text: '오류내용' },
        width: 500,
        type: 'data',
        styleName: 'left-column',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accCl',
        editable: false,
        header: { text: '정산구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {}

export { GRID_HEADER, MOCK_DATA }
