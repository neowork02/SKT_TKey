<template>
    <TCComDialog :dialogShow.sync="showBool" size="700px">
        <template #content>
            <TCComAlert
                v-model="showBool"
                headerText="Row 선택 필수"
                :bodyText="alertBodyText"
            ></TCComAlert>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">CSV양식</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">아이디</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="colorGrid"
                                ref="colorGrid"
                                :fields="view2.fields"
                                :columns="view2.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { CSV_HEADER } from '@/const/grid/bas/bbs/basBbsMgmtHeader'

export default {
    name: 'Home',
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        multiple: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            gridObj: {},
            objAuth: {},
            view2: CSV_HEADER,
            selectedData: {},
            alertBodyText: '',
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        showBool: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    created() {},
    mounted() {
        this.gridObj = this.$refs.colorGrid // Grid Object 설정
        this.initGrid()
        this.initGridRows()
    },
    methods: {
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false, false)
            // 그리드 이벤트 처리
            this.gridObj.gridView.onCurrentRowChanged = (
                grid,
                oldRow,
                newRow
            ) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(newRow)
                this.selectedData = jsonData
            }

            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        initGridRows() {
            const rows = [
                { userId: 'TDCS_01' },
                { userId: 'TDCS_02' },
                { userId: 'TDCS_03' },
                { userId: 'TDCS_04' },
                { userId: 'TDCS_05' },
                { userId: 'TDCS_06' },
                { userId: '...' },
            ]
            setTimeout(() => {
                this.gridObj.setRows(rows)
            }, 400)
        },
        onClose() {
            this.showBool = false
        },
    },
}
</script>
