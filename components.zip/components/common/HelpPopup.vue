<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">도움말- {{ currentMenuInfo.menuNm }}</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="gridWrap">
                        <!-- <v-img
                            max-height="281"
                            max-width="500"
                            :src="require('@/assets/logo.png')"
                        ></v-img> -->
                        <div class="errorPageWrap">
                            <div class="textBox">
                                <p class="tit">준비중입니다.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'

export default {
    name: 'BasBcoDealcosPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
    },

    data() {
        return {}
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        currentMenuInfo() {
            return this.$store.getters['menu/currentMenuInfo']
        },
    },
    watch: {},
    created() {},
    mounted() {},
    methods: {
        onClose() {
            this.activeOpen = false
        },
    },
}
</script>
