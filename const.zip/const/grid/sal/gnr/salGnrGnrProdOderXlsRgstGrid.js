/*****************************************
 * 업무 그룹명 : 판매관리
 * 서브 업무명 : 소매매출
 * 설 명 : 일반상품판매일관판매등록 Grid 헤더
 * 작 성 자 : 양현모
 * 작 성 일 : 2022.07.06
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const XLS_RGST_HEADER = {
    fields: [
        {
            fieldName: 'giveMthdCd',
            dataType: ValueType.TEXT, // 배송구분
        },
        {
            fieldName: 'twdOrdNo',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'eqpSerNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상
        },
        {
            fieldName: 'saleUprc',
            dataType: ValueType.NUMBER, // 판매단가
        },
        {
            fieldName: 'pgPayAmt',
            dataType: ValueType.NUMBER, // PG사
        },
        {
            fieldName: 'tfPtPayAmt',
            dataType: ValueType.NUMBER, // T가족포인트
        },
        {
            fieldName: 'tptPayAmt',
            dataType: ValueType.NUMBER, // T포인트
        },
        {
            fieldName: 'twdCpnPayAmt',
            dataType: ValueType.NUMBER, // TWD쿠폰
        },
        {
            fieldName: 'ocbPayAmt',
            dataType: ValueType.NUMBER, // OCB
        },
        {
            fieldName: 'error',
            dataType: ValueType.TEXT, // 오류
        },
    ],
    columns: [
        {
            name: 'giveMthdCd',
            fieldName: 'giveMthdCd',
            type: 'data',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            width: '100',
            header: {
                text: '배송구분',
            },
        },
        {
            name: 'twdOrdNo',
            fieldName: 'twdOrdNo',
            type: 'data',
            width: '120',
            header: {
                text: '주문번호',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            header: {
                text: '모델',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '100',
            header: {
                text: '모델코드',
            },
        },
        {
            name: 'eqpSerNum',
            fieldName: 'eqpSerNum',
            type: 'data',
            width: '100',
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            width: '100',
            header: {
                text: '색상',
            },
        },
        {
            name: 'saleUprc',
            fieldName: 'saleUprc',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '판매단가',
            },
        },
        {
            name: 'pgPayAmt',
            fieldName: 'pgPayAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'PG사',
            },
        },
        {
            name: 'tfPtPayAmt',
            fieldName: 'tfPtPayAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'T가족포인트',
            },
        },
        {
            name: 'tptPayAmt',
            fieldName: 'tptPayAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'T포인트',
            },
        },
        {
            name: 'twdCpnPayAmt',
            fieldName: 'twdCpnPayAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'TWD쿠폰',
            },
        },
        {
            name: 'ocbPayAmt',
            fieldName: 'ocbPayAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'OCB',
            },
        },
        {
            name: 'error',
            fieldName: 'error',
            type: 'data',
            width: '300',
            styleName: 'left-column',
            header: {
                text: '오류',
            },
        },
    ],
}

export const XLS_TEMPLATE_HEADER = {
    fields: [
        {
            fieldName: 'col0',
            dataType: ValueType.TEXT, // 배송구분
        },
        {
            fieldName: 'col1',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'col2',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'col3',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'col4',
            dataType: ValueType.TEXT, // 색상
        },
        {
            fieldName: 'col5',
            dataType: ValueType.TEXT, // 판매단가
        },
        {
            fieldName: 'col6',
            dataType: ValueType.TEXT, // PG사
        },
        {
            fieldName: 'col7',
            dataType: ValueType.TEXT, // T가족포인트
        },
        {
            fieldName: 'col8',
            dataType: ValueType.TEXT, // T포인트
        },
        {
            fieldName: 'col9',
            dataType: ValueType.TEXT, // TWD쿠폰
        },
        {
            fieldName: 'col10',
            dataType: ValueType.TEXT, // OKCashBack
        },
    ],
    columns: [
        {
            name: 'col0',
            fieldName: 'col0',
            type: 'data',
            width: '100',
            header: {
                text: '배송구분',
            },
        },
        {
            name: 'col1',
            fieldName: 'col1',
            type: 'data',
            width: '120',
            header: {
                text: '주문번호',
            },
        },
        {
            name: 'col2',
            fieldName: 'col2',
            type: 'data',
            width: '100',
            header: {
                text: '모델코드',
            },
        },
        {
            name: 'col3',
            fieldName: 'col3',
            type: 'data',
            width: '100',
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'col4',
            fieldName: 'col4',
            type: 'data',
            width: '100',
            header: {
                text: '색상',
            },
        },
        {
            name: 'col5',
            fieldName: 'col5',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '판매단가',
            },
        },
        {
            name: 'col6',
            fieldName: 'col6',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: 'PG사',
            },
        },
        {
            name: 'col7',
            fieldName: 'col7',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: 'T가족포인트',
            },
        },
        {
            name: 'col8',
            fieldName: 'col8',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: 'T포인트',
            },
        },
        {
            name: 'col9',
            fieldName: 'col9',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: 'TWD쿠폰',
            },
        },
        {
            name: 'col10',
            fieldName: 'col10',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: 'OKCashBack',
            },
        },
    ],
}
