import { ValueType } from 'realgrid'

export const IN_GRID_HEADER = {
    fields: [
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, // 레벨0조직코드
        },
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT, // 레벨1조직코드
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, // 레벨2조직코드
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT, // 레벨3조직코드
        },
        {
            fieldName: 'inMgmtNo',
            dataType: ValueType.TEXT, // 입고관리번호
        },
        {
            fieldName: 'ordMgmtNo',
            dataType: ValueType.TEXT, // 발주관리번호
        },
        {
            fieldName: 'inSchdDt',
            dataType: ValueType.TEXT, // 입고예정일자
        },
        {
            fieldName: 'bfPrchsDealcoCd',
            dataType: ValueType.TEXT, // 이전매입처코드
        },
        {
            fieldName: 'bfPrchsDealcoNm',
            dataType: ValueType.TEXT, // 이전매입처명
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT, // 입고처코드
        },
        {
            fieldName: 'inDealcoNm',
            dataType: ValueType.TEXT, // 입고처명
        },
        {
            fieldName: 'inClCd',
            dataType: ValueType.TEXT, // 입고구분코드
        },
        {
            fieldName: 'inClNm',
            dataType: ValueType.TEXT, // 입고구분명
        },
        {
            fieldName: 'inFixDt',
            dataType: ValueType.TEXT, // 입고확정일자
        },
        {
            fieldName: 'inStCd',
            dataType: ValueType.TEXT, // 입고상태코드
        },
        {
            fieldName: 'inStNm',
            dataType: ValueType.TEXT, // 입고상태명
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.NUMBER, // 입고수량
        },
        {
            fieldName: 'inFixQty',
            dataType: ValueType.NUMBER, // 입고확정수량
        },
    ],
    columns: [
        {
            name: 'inClNm',
            fieldName: 'inClNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입고구분',
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '조직',
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입고처코드',
            },
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입고처',
            },
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입고예정',
            },
        },
        {
            name: 'inFixQty',
            fieldName: 'inFixQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입고확정',
            },
        },
        {
            name: 'inStNm',
            fieldName: 'inStNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '입고상태',
            },
        },
        {
            name: 'inSchdDt',
            fieldName: 'inSchdDt',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입고예정일',
            },
        },
        {
            name: 'inFixDt',
            fieldName: 'inFixDt',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입고확정일',
            },
        },
        {
            name: 'bfPrchsDealcoCd',
            fieldName: 'bfPrchsDealcoCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '매입처코드',
            },
            visible: false,
        },
        {
            name: 'bfPrchsDealcoNm',
            fieldName: 'bfPrchsDealcoNm',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '매입처',
            },
        },
    ],
}

export const DTL_GRID_HEADER = {
    fields: [
        {
            fieldName: 'NO',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'inMgmtNo',
            dataType: ValueType.TEXT, // 입고관리번호
        },
        {
            fieldName: 'ordMgmtNo',
            dataType: ValueType.TEXT, // 발주관리번호
        },
        {
            fieldName: 'inSchdDt',
            dataType: ValueType.TEXT, // 입고예정일자
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT, // 입고처코드
        },
        {
            fieldName: 'aprvCondCd',
            dataType: ValueType.TEXT, // 결재조건코드
        },
        {
            fieldName: 'inClCd',
            dataType: ValueType.TEXT, // 입고구분코드
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, // 상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT, // 단말기구분코드
        },
        {
            fieldName: 'eqpClNm',
            dataType: ValueType.TEXT, // 단말기구분명
        },
        {
            fieldName: 'bfPrchsDealcoCd',
            dataType: ValueType.TEXT, // 이전매입처코드
        },
        {
            fieldName: 'bfColorCd',
            dataType: ValueType.TEXT, // 이전색상코드
        },
        {
            fieldName: 'bfColorNm',
            dataType: ValueType.TEXT, // 이전색상명
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, // 제조사명
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.NUMBER, // 입고수량
        },
        {
            fieldName: 'inFixQty',
            dataType: ValueType.NUMBER, // 입고확정수량
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'NO',
            type: 'data',
            width: '40',
            styleName: 'center-column',
            numberFormat: '##0',
            header: {
                text: 'No',
            },
            editor: {
                textReadOnly: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'eqpClNm',
            fieldName: 'eqpClNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '단말기구분',
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            width: '160',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '제조사',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '160',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '모델',
            },
        },
        {
            name: 'bfColorNm',
            fieldName: 'bfColorNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상',
            },
            footer: {
                text: '합계',
                styleName: 'center-column',
            },
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입고예정',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'inFixQty',
            fieldName: 'inFixQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입고확정',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],
}

export const SER_NUM_GRID_HEADER = {
    fields: [
        {
            fieldName: 'NO',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'inFixYn',
            dataType: ValueType.TEXT, // 입고확정여부
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'NO',
            type: 'data',
            width: '40',
            styleName: 'center-column',
            numberFormat: '##0',
            header: {
                text: 'No',
            },
            editor: {
                textReadOnly: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'inFixYn',
            fieldName: 'inFixYn',
            type: 'data',
            width: '40',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '확정',
            },
        },
    ],
}

export const UPLOAD_GRID_HEADER = {
    fields: [
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, // 거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, // 거래처명
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'chgColorCd',
            dataType: ValueType.TEXT, // 변경색상코드
        },
        {
            fieldName: 'errCtt',
            dataType: ValueType.TEXT, // 오류내용
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '조직',
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '거래처매장코드',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '거래처명',
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '상품코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '모델명',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '60',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '기존색상',
            },
        },
        {
            name: 'chgColorCd',
            fieldName: 'chgColorCd',
            type: 'data',
            width: '60',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '변경색상',
            },
        },
        {
            name: 'errCtt',
            fieldName: 'errCtt',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '오류사항',
            },
        },
    ],
}
