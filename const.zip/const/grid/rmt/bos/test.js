{
    fieldName: 'rowNum', // 순번
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'orgCd', // 조직코드
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'orgNm', // 조직
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'dealCoCl1Nm', // 거래처구분
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'dealcoCd', // 거래처코드
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'dealcoNm', // 거래처명
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'pCode', // 채널코드
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'dealStatus', // 거래상태
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'dealStaDt', // 거래개시일
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'dealEndDt', // 거래종료일
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'saleChrgr', // 영업담당
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'baseDt', // 날짜
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'overBondAmt', // 연체채권
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'bfBondAmt', // 전일채권잔액
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'toFeesAmt', // 당일채권증가_SKT수납
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'toCashAmt', // 당일채권증가_현금매출
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'toFreeAmt', // 당일채권증가_공기기매출
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'toRfndAmt', // 당일채권증가_오입금환불
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'toTecoAmt', // 당일채권증가_T에코환수
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'toRcvbAmt', // 당일채권증가_기타미수금
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'toDpstAmt', // 당일채권증가_입금
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'bondTotAmt', // 당일채권증가_당일합계
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'manualAdjAmt', // 수기조정
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'manualAdjRsn', // 수기조정사유
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'toBondAmt', // 당일채권잔액
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'saleCmms', // 판매수수료
    dataType: ValueType.NUMBER,
},

{
    fieldName: 'toExpsAmt', // 지출
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'toPpayAmt', // 선지급
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'base20BondAmt', // 20일기준채권잔액
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'baseEndBondAmt', // 말일기준채권잔액
    dataType: ValueType.NUMBER,
},
{
    fieldName: 'modYn', // 연체채권초과여부
    dataType: ValueType.NUMBER,
},