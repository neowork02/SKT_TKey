export default {
    loadingShow: false,
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 30,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 30,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },

    resultList: [],
    searchParams: {},

    DEALCO_RGST_CL_CD: [], // 거래처등록구분
    DEAL_CO_GRP: [], // 거래처그룹
    ZBAS_C_00240: [], // 거래처구분
}
