<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccMclOrgPrfitLsPrstLed.vue
 * 설명: 
 * 작성자: P180190
 * 작성일: 2022.12.29
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>조직별손익현황&lt;원장기준&gt;</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="resetForm"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="viewForm"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="마감월"
                        calType="M"
                        :eRequired="true"
                        v-model="clsMth_"
                        :objAuth="objAuth"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="조회일자"
                        calType="DP"
                        :eRequired="true"
                        v-model="dpstDt_"
                        :objAuth="objAuth"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formGetProfitLossBydept.query.salePlcNm"
                        :codeVal.sync="formGetProfitLossBydept.query.salePlc"
                        labelName="판매처"
                        :objAuth="objAuth"
                    />
                </div>
                <div class="formitem div4">
                    <TCComCheckBox
                        itemText="label"
                        itemValue="value"
                        label="0 제외"
                        :objAuth="objAuth"
                        :itemList="[
                            {
                                label: '0 제외',
                                value: '1',
                            },
                        ]"
                        v-model="zeroViewCheck"
                    />
                </div>
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="기준일"
                        calType="D"
                        :eRequired="true"
                        v-model="searchDtmTo_"
                        :objAuth="objAuth"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        placeholder="입력해주세요"
                        :eRequired="true"
                        :disabled="false"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :codeVal.sync="popupParamOrgCd.orgCd"
                        v-model="popupParamOrgCd.orgNm"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="popupParamOrgCd"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formGetProfitLossBydept.query.accPlc"
                        :codeVal.sync="formGetProfitLossBydept.query.accPlcNm"
                        labelName="정산처"
                        :objAuth="objAuth"
                    />
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <template>
                <TCRealGridHeader
                    id="gridHeader"
                    ref="gridHeader"
                    gridTitle="조직별손익현황"
                    :gridObj="gridObj"
                    :isExceldown="true"
                    @excelDownBtn="downloadProfitLossBydept"
                >
                </TCRealGridHeader>
                <TCRealGrid
                    id="grid"
                    ref="grid"
                    :editable="true"
                    :fields="view.fields"
                    :columns="view.columns"
                    :styles="gridStyle"
                />
                <AccMclOrgPrfitLsPrstLedAr
                    v-if="showOrgPrfitLsPrstLedAr"
                    :parentParam="ldgrPopupParam"
                    :dialogShow.sync="showOrgPrfitLsPrstLedAr"
                />
                <AccMclOrgPrfitLsPrstLedAp
                    v-if="showOrgPrfitLsPrstLedAp"
                    :parentParam="ldgrPopupParam"
                    :dialogShow.sync="showOrgPrfitLsPrstLedAp"
                />
            </template>
        </div>
    </div>
</template>
<style scoped>
:deep(.grid) .rg-body .rg-table tr td.emphasis,
:deep(.grid) .rg-fixed-body .rg-table tr td.emphasis {
    color: black;
    background: skyblue;
    font-weight: bold;
}
</style>
<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import accMixin from '@/mixins/accMixin'
import _ from 'lodash'
import moment from 'moment'
import mclApi from '@/api/biz/acc/mcl'

import AccMclOrgPrfitLsPrstLedAr from '@/views/biz/acc/mcl/AccMclOrgPrfitLsPrstLedAr' //매출원장팝업
import AccMclOrgPrfitLsPrstLedAp from '@/views/biz/acc/mcl/AccMclOrgPrfitLsPrstLedAp' //매입원장팝업
//====================내부조직팝업(권한)==============================================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================조직별대리점팝업================================================

import { GRID_HEADER } from '@/const/grid/acc/mcl/AccMclOrgPrfitLsPrstLedGrid'

export default {
    name: 'AccMclOrgPrfitLsPrstLed',
    mixins: [CommonMixin, accMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        AccMclOrgPrfitLsPrstLedAr,
        AccMclOrgPrfitLsPrstLedAp,
    },
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,

            GRID_HEADER,
            objAuth: {},
            gridObj: {},
            gridHeaderObj: {},

            popupParamOrgCd: {
                basMth: '',
                orgCd: '',
                orgNm: '',
            },

            formGetProfitLossBydept: {
                query: {
                    mccGb: 'CST',
                    clsMth: moment(new Date()).format('YYYYMM'),
                    frDt: moment(new Date())
                        .startOf('month')
                        .format('YYYYMMDD'),
                    toDt: moment(new Date()).endOf('month').format('YYYYMMDD'),
                    searchDtmTo: moment(new Date()).format('YYYYMMDD'),
                    searchCoClOrgCd: '',
                },
            },
            dpstDt_: [
                moment(new Date()).startOf('month').format('YYYY-MM-DD'),
                moment(new Date()).endOf('month').format('YYYY-MM-DD'),
            ],
            clsMth_: moment(new Date()).format('YYYY-MM'),
            searchDtmTo_: moment(new Date()).format('YYYY-MM-DD'),
            ldgrPopupParam: {},
            zeroViewCheck: [],
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================

            showOrgPrfitLsPrstLedAr: false,
            showOrgPrfitLsPrstLedAp: false,

            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
        }
    },

    computed: {},
    watch: {
        // 조회 변경 감지
        clsMth_: {
            handler: function (newArr) {
                if (!_.isEmpty(newArr)) {
                    this.formGetProfitLossBydept.query.clsMth = newArr.replace(
                        /-/g,
                        ''
                    )
                    this.popupParamOrgCd.basMth =
                        moment(newArr).format('YYYYMM')
                }
            },
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },

        dpstDt_: {
            handler: function (newArr) {
                if (!_.isEmpty(newArr[0])) {
                    this.formGetProfitLossBydept.query.frDt = newArr[0].replace(
                        /-/g,
                        ''
                    )

                    this.dpstDt_[1] = moment(newArr[0])
                        .endOf('month')
                        .format('YYYY-MM-DD')
                }
                if (!_.isEmpty(newArr[1])) {
                    this.formGetProfitLossBydept.query.toDt = newArr[1].replace(
                        /-/g,
                        ''
                    )
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        searchDtmTo_: {
            handler: function (newArr) {
                if (!_.isEmpty(newArr)) {
                    this.formGetProfitLossBydept.query.searchDtmTo =
                        newArr.replace(/-/g, '')
                }
            },
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },

    created() {},

    mounted() {
        this.initGrid()
    },
    methods: {
        async initGrid() {
            this.formGetProfitLossBydept.query.searchCoClOrgCd =
                this.orgInfo.orgCdLvl0

            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
            this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj.setGridState(false, false, false, true)

            this.gridObj.gridView.onCellDblClicked = (grid, rowInfo) => {
                if (rowInfo.dataRow === undefined || rowInfo.dataRow < 0) return

                const rowIdx = rowInfo.dataRow
                const row = this.getRowDataInIdx(rowIdx)

                console.log('row:::::', rowInfo.fieldIndex)
                this.ldgrPopupParam.searchGubun = '2' //  전기일
                this.ldgrPopupParam.searchDtFrom =
                    this.formGetProfitLossBydept.query.frDt
                this.ldgrPopupParam.searchDtTo =
                    this.formGetProfitLossBydept.query.toDt
                this.ldgrPopupParam.prchsDealcoCd =
                    this.formGetProfitLossBydept.query.salePlc === undefined
                        ? ''
                        : this.formGetProfitLossBydept.query.salePlc
                this.ldgrPopupParam.saleDealcoCd =
                    this.formGetProfitLossBydept.query.salePlc === undefined
                        ? ''
                        : this.formGetProfitLossBydept.query.salePlc
                this.ldgrPopupParam.accDealcoCd =
                    this.formGetProfitLossBydept.query.accPlc === undefined
                        ? ''
                        : this.formGetProfitLossBydept.query.accPlc
                this.ldgrPopupParam.orgCd =
                    this.formGetProfitLossBydept.query.orgCd === undefined
                        ? ''
                        : this.formGetProfitLossBydept.query.orgCd
                this.ldgrPopupParam.orgNm =
                    this.formGetProfitLossBydept.query.orgNm === undefined
                        ? ''
                        : this.formGetProfitLossBydept.query.orgNm
                this.ldgrPopupParam.orgLvl =
                    this.formGetProfitLossBydept.query.orgLvl === undefined
                        ? ''
                        : this.formGetProfitLossBydept.query.orgLvl
                this.ldgrPopupParam.searchDtTo =
                    this.formGetProfitLossBydept.query.toDt

                this.ldgrPopupParam.prchsClCd = row.arClCd
                this.ldgrPopupParam.arClCd = row.arClCd

                this.ldgrPopupParam.inClCd = ''
                this.ldgrPopupParam.saleClCd = ''

                if (row.clNm == '영업비용') {
                    if (row.arClNm != '소계' && row.arClNm.length > 0) {
                        if (
                            rowInfo.fieldIndex >= 6 &&
                            rowInfo.fieldIndex <= 8
                        ) {
                            //  추정값컬럼(공급가, 부가세, 계) 더블클릭
                            this.ldgrPopupParam.inClCd = 'PSG'
                        } else if (
                            rowInfo.fieldIndex >= 12 &&
                            rowInfo.fieldIndex <= 14
                        ) {
                            //  확정값컬럼(공급가, 부가세, 계) 더블클릭
                            this.ldgrPopupParam.inClCd = 'PSC'
                        }

                        if (row.arClCd == 'LEND') {
                            this.ldgrPopupParam.inClCd = 'LND'
                        }

                        if (row.arClCd == 'SLF1' || row.arClCd == 'SLF2') {
                            this.ldgrPopupParam.inClCd = 'OST'
                        }

                        //  매입원장 팝업 오픈
                        this.showOrgPrfitLsPrstLedAp = true
                    }
                } else {
                    if (row.arClNm != '소계' && row.arClNm.length > 0) {
                        if (
                            rowInfo.fieldIndex >= 6 &&
                            rowInfo.fieldIndex <= 8
                        ) {
                            //  추정값컬럼(공급가, 부가세, 계) 더블클릭
                            this.ldgrPopupParam.saleClCd = 'EST'
                        } else if (
                            rowInfo.fieldIndex >= 12 &&
                            rowInfo.fieldIndex <= 14
                        ) {
                            //  확정값컬럼(공급가, 부가세, 계) 더블클릭
                            this.ldgrPopupParam.saleClCd = 'ACC'
                        }

                        if (
                            row.arClCd == 'SIMF' ||
                            row.arClCd == 'FEES' ||
                            row.arClCd == 'APAY'
                        ) {
                            this.ldgrPopupParam.saleClCd = 'NOT'
                        }

                        if (row.arClCd == 'EMPT' || row.arClCd == 'SIME') {
                            this.ldgrPopupParam.saleClCd = 'DSL'
                        }

                        if (row.arClCd == 'NCSH' || row.arClCd == 'PAMT') {
                            this.ldgrPopupParam.saleClCd = 'EXP'
                        }

                        if (
                            row.arClCd == 'DIF1' ||
                            row.arClCd == 'DIF2' ||
                            row.arClCd == 'DIF3' ||
                            row.arClCd == 'DIF4'
                        ) {
                            this.ldgrPopupParam.saleClCd = 'ADJ'
                        }

                        //  매출원장 팝업 오픈
                        this.showOrgPrfitLsPrstLedAr = true
                    }
                }
            }
        },

        getRowDataInIdx(rowIdx) {
            let row = []
            if (rowIdx instanceof Array) {
                row = rowIdx.map((arr) =>
                    this.gridObj.dataProvider.getJsonRow(arr)
                )
            } else {
                row = this.gridObj.dataProvider.getJsonRow(rowIdx)
            }

            return this.changeDateOnGridformat(row)
        },

        changeDateOnGridformat(row) {
            let target = row

            if (!(target instanceof Array)) {
                target = [row]
            }

            target.forEach((arr) => {
                Object.keys(arr).forEach((key, idx) => {
                    if (arr[key] instanceof Date) {
                        const dataFormat =
                            this.gridMeta.columns[
                                idx
                            ].fieldDatetimeFormat.toUpperCase()
                        arr[key] = moment(arr[key]).format(dataFormat)
                    }
                })
            })

            return row
        },

        resetForm() {
            CommonUtil.clearPage(this, 'formGetProfitLossBydept', this.gridObj)
            this.popupParamOrgCd = {}
            this.formGetProfitLossBydept.query.searchCoClOrgCd =
                this.orgInfo.orgCdLvl0

            this.gridObj.gridView.orderBy([]) // 정렬 초기화

            this.dpstDt_ = [
                moment(new Date()).startOf('month').format('YYYY-MM-DD'),
                moment(new Date()).endOf('month').format('YYYY-MM-DD'),
            ]
            this.clsMth_ = moment(new Date()).format('YYYY-MM')
            this.searchDtmTo_ = moment(new Date()).format('YYYY-MM-DD')

            this.zeroViewCheck = []
        },

        viewForm() {
            if (this.zeroViewCheck) {
                this.formGetProfitLossBydept.query.zeroView =
                    this.zeroViewCheck[0]
            }

            return this.getProfitLossBydept()
        },

        getProfitLossBydept() {
            console.log('요청쿼리 =>', this.formGetProfitLossBydept.query)
            const setGridFooter = (data) => {
                this.gridObj.gridView.setFooters([
                    {
                        styleName: 'footer1',
                    },
                    {
                        styleName: 'footer2',
                    },
                    {
                        styleName: 'footer3',
                    },
                ])
                this.gridObj.gridView.columnByName('clNm').setFooters([
                    {
                        text: '매출총이익 ⑨',
                    },
                    {
                        text: '시장운영손익1 ⑪',
                    },
                    {
                        text: '시장운영손익2 ⑫',
                    },
                ])
                this.gridObj.gridView.columnByName('plClNm').setFooters([
                    {
                        text: '= ⑦ - ① - ⑧',
                    },
                    {
                        text: '= ⑨ - ⑩',
                    },
                    {
                        text: '= ⑪ - ①',
                    },
                ])
                let columns = [
                    'estNetAmt',
                    'estVatAmt',
                    'estSumAmt',
                    'erpEstNetAmt',
                    'erpEstVatAmt',
                    'erpEstSumAmt',
                    'accNetAmt',
                    'accVatAmt',
                    'accSumAmt',
                    'erpAccNetAmt',
                    'erpAccVatAmt',
                    'erpAccSumAmt',
                ]
                columns.forEach((arr) => {
                    // 위탁수수료의 합
                    let group1 = data
                        .filter((field) => field.plClNm == '위탁수수료 ①')
                        .reduce(
                            (acc, field) => (acc += parseInt(field[arr], 10)),
                            0
                        )

                    // 총매출액의 합
                    let group7 = data
                        .filter((field) => field.clNm == '총매출액')
                        .reduce(
                            (acc, field) => (acc += parseInt(field[arr], 10)),
                            0
                        )

                    // 매출원가의 합
                    let group8 = data
                        .filter((field) => field.clNm == '매출원가')
                        .reduce(
                            (acc, field) => (acc += parseInt(field[arr], 10)),
                            0
                        )

                    // 영업비용의 합
                    let group10 = data
                        .filter((field) => field.clNm == '영업비용')
                        .reduce(
                            (acc, field) => (acc += parseInt(field[arr], 10)),
                            0
                        )

                    // 매출총이익
                    let group9 = group7 - group1 - group8

                    // 시장운영손익1
                    let group11 = group9 - group10

                    // 시장운영손익2
                    let group12 = group11 - group1

                    this.gridObj.gridView.columnByName(arr).setFooters([
                        {
                            numberFormat: '#,###,###,###',
                            valueCallback: () => group9,
                        },
                        {
                            numberFormat: '#,###,###,###',
                            valueCallback: () => group11,
                        },
                        {
                            numberFormat: '#,###,###,###',
                            valueCallback: () => group12,
                        },
                    ])
                })
            }

            return mclApi
                .getProfitLossBydept(this.formGetProfitLossBydept.query)
                .then((res) => {
                    if (res) {
                        const data = [...res]
                        this.gridObj.setRows(res)
                        this.gridObj.gridView.groupBy(['clNm', 'plClNm'], false)
                        this.gridObj.gridView.setRowGroup({
                            footerStatement: 'SUM(${groupValue})',
                        })
                        setGridFooter(data)
                    }

                    return res
                })
        },
        downloadProfitLossBydept() {
            mclApi.downloadProfitLossBydept(this.formGetProfitLossBydept.query)
        },
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            console.log('this.popupParamOrgCd::::', this.popupParamOrgCd)
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.popupParamOrgCd)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res) {
                        if (res.length === 1) {
                            this.popupParamOrgCd.orgCd = _.get(res[0], 'orgCd')
                            this.popupParamOrgCd.orgNm = _.get(res[0], 'orgNm')
                            this.popupParamOrgCd.srchOrgLvl = _.get(
                                res[0],
                                'vLevel'
                            )
                            this.popupParamOrgCd.srchCoClOrgCd = _.get(
                                res[0],
                                'orgCdLvl0'
                            )
                            this.popupParamOrgCd.orgTree = _.get(
                                res[0],
                                'orgTree'
                            )
                        } else {
                            this.resultAuthOrgTreeRows = res
                            this.showBcoAuthOrgTrees = true
                        }
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.popupParamOrgCd.orgNm)) {
                this.getAuthOrgTreeList()
            }
            this.showBcoAuthOrgTrees = true
        },

        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.popupParamOrgCd.orgNm)) {
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.popupParamOrgCd.orgCd = ''
            this.popupParamOrgCd.srchOrgLvl = ''
            this.popupParamOrgCd.srchCoClOrgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            this.popupParamOrgCd.orgCd = _.get(returnData, 'orgCd')
            this.formGetProfitLossBydept.query.orgCd = _.get(
                returnData,
                'orgCd'
            )
            this.popupParamOrgCd.orgNm = _.get(returnData, 'orgNm')
            this.popupParamOrgCd.srchOrgLvl = _.get(returnData, 'orgLvl')
            this.formGetProfitLossBydept.query.orgLvl = _.get(
                returnData,
                'orgLvl'
            )
            this.popupParamOrgCd.srchCoClOrgCd = _.get(returnData, 'orgCdLvl0')
        },
    },
}
</script>
