import { ValueType } from 'realgrid'

export const GRID_INFO = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ictTs',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ictTsNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'openStDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'openEnDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'operCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'operNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'subjCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'subjNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polTypeCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polTypeNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstSchdYm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'vatCd',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'ictId',
            fieldName: 'ictId',
            type: 'data',
            width: '100',
            header: {
                text: 'B정책ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'ictTsNm',
            fieldName: 'ictTsNm',
            type: 'data',
            width: '80',
            header: {
                text: '차수',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        // {
        //     name: 'operNm',
        //     fieldName: 'operNm',
        //     type: 'data',
        //     width: '250',
        //     header: {
        //         text: '정책운영사',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     editable: false,
        // },
        {
            name: 'subjNm',
            fieldName: 'subjNm',
            type: 'data',
            width: '100',
            header: {
                text: '정책주관',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polTypeNm',
            fieldName: 'polTypeNm',
            type: 'data',
            width: '150',
            header: {
                text: '정책구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polNm',
            fieldName: 'polNm',
            type: 'data',
            width: '400',
            header: {
                text: '정책명칭',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'polStNm',
            fieldName: 'polStNm',
            type: 'data',
            width: '80',
            header: {
                text: '상태',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'openStDt',
            fieldName: 'openStDt',
            type: 'data',
            width: '150',
            header: {
                text: '개통시작일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'openEnDt',
            fieldName: 'openEnDt',
            type: 'data',
            width: '150',
            header: {
                text: '개통종료일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dpstSchdYm',
            fieldName: 'dpstSchdYm',
            type: 'data',
            width: '100',
            header: {
                text: '입금예정월',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            width: '80',
            header: {
                text: '작성자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '80',
            header: {
                text: '처리자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            width: '150',
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}
