<!-----------------------------------------------
 * 업무그룹명: 타사SMS전송 동의서
 * 서브업무명: 타사SMS전송 동의서
 * 설명: 유통대리점 타사SMS 사용 관리
 * 작성자: P140530
 * 작성일: 2022.11.25
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>타사 SMS전송 동의서</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    @click="openPop"
                    >신규</TCComButton
                >
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComDatePicker
                        labelName="등록일자"
                        calType="DP"
                        v-model="setDate"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="reqParam.agencyNm"
                        :codeVal.sync="reqParam.agencyCd"
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAgencyEnterKey"
                        @appendIconClick="onAgencyIconClick"
                        @input="onAgencyInput"
                    />
                    <BasBcoAgencysPopup
                        v-if="showBcoAgencys"
                        :parentParam="searchParam"
                        :rows="resultAgencyRows"
                        :dialogShow.sync="showBcoAgencys"
                        @confirm="onAgencyReturnData"
                    />
                </div>
                <div class="formitem div3">
                    <TCComComboBox
                        :itemList="this.agreeYnData"
                        labelName="동의여부"
                        v-model="reqParam.agreeYn"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
        </div>
        <!-- // Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="타사 SMS전송 동의서"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getOthrCoSmsTrmsAcDoc"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <!-- // gridWrap -->
        <!-- 등록popup -->
        <BasCmuOthrCoSmsTrmsAcDocPop
            ref="popup"
            v-if="showPop === true"
            :dialogShow.sync="showPop"
            :agencyInfo.sync="agencyInfo"
            @confirm="onReturnReSearch"
        />
        <!-- // 등록popup -->
    </div>
</template>
<script>
/**************************************************************************************************************
 * 공통 LIB import 영역
 **************************************************************************************************************/
import { CommonGrid, CommonUtil } from '@/utils'
import { GRID_HEADER } from '@/const/grid/bas/cmu/basCmuOthrCoSmsTrmsAcDoc'
import BasCmuOthrCoSmsTrmsAcDocApi from '@/api/biz/bas/cmu/basCmuOthrCoSmsTrmsAcDoc'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'
import BasCmuOthrCoSmsTrmsAcDocPop from './BasCmuOthrCoSmsTrmsAcDocPop'
//====================대리점팝업====================
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
//====================//대리점팝업====================

export default {
    name: 'BasCmuOthrCoSmsTrmsAcDoc',
    mixins: [CommonMixin],
    components: { BasBcoAgencysPopup, BasCmuOthrCoSmsTrmsAcDocPop },
    props: {},
    data() {
        return {
            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: this.gridSetData(),
            indicatorOpt: { sort: 'ASC' },
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            objAuth: {},
            view: GRID_HEADER,
            agreeYnData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '동의',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '동의안함',
                },
            ],

            reqParam: {
                fromDt: '', // from일자
                toDt: '', // to일자
                agencyCd: '', // 대리점코드
                agreeYn: '', // 동의여부
                orgCdLvl0: '', // 레벨0조직코드
            },
            serchParam: {},
            rowCnt: 15,

            // 팝업
            showPop: false,
            agencyInfo: {},

            //====================//내부조직팝업(권한)팝업관련==================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            searchParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
                searchDate: '', // 조회기준일
            },
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.fromDt, this.reqParam.toDt]
            },
            set(val) {
                this.reqParam.fromDt = val[0]
                this.reqParam.toDt = val[1]
                return val
            },
        },
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(true, false, false)
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        // 수정 버튼
        this.gridObj.gridView.onCellItemClicked = (grid, index, clickData) => {
            if (clickData.fieldName === 'updBtn') {
                const rowData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.agencyInfo = { ...rowData }
                this.agencyInfo.chkUpdateYn = 'Y'
                this.showPop = true
            }
        }
        this.init()
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.fromDt = moment(new Date()).format('YYYY-MM-01')
            this.reqParam.toDt = moment(new Date()).format('YYYY-MM-DD')
            // this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
        },
        onReturnReSearch(retVal) {
            if (retVal) {
                // 화면재조회
                this.searchBtn()
            }
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam') // 초기화 함수
            this.init()
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/cmu/basCmuOthrCoSmsTrmsAcDocExcel',
                this.searchForm
            )
        },
        //리스트 조회
        searchBtn: function () {
            // 조회 유효성체크
            if (!this.isValidChk()) {
                return false
            }

            this.searchForm = { ...this.reqParam }
            this.searchForm.fromDt = CommonUtil.replaceDash(
                this.searchForm.fromDt
            )
            this.searchForm.toDt = CommonUtil.replaceDash(this.searchForm.toDt)
            //첫 조회시 표시할 행의 갯수
            this.searchForm.pageSize = this.rowCnt
            this.searchForm.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getOthrCoSmsTrmsAcDoc(this.searchForm.pageNum)
        },
        getOthrCoSmsTrmsAcDoc(page) {
            this.searchForm.pageNum = page
            BasCmuOthrCoSmsTrmsAcDocApi.getBasCmuOthrCoSmsTrmsAcDoc(
                this.searchForm
            ).then((res) => {
                //Get Row Data
                this.gridObj.setRows(res.gridList)
                this.gridObj.setGridIndicator(res.pagingDto, this.indicatorOpt) //순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData() //초기화
                this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj.setPageCount(res.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                this.setReportButton() // 수정버튼 생성
            })
        },
        // 수정버튼 생성
        setReportButton() {
            const rowCount = this.gridObj.dataProvider.getRowCount()
            for (var i = 0; i < rowCount; i++) {
                this.gridObj.gridView.setValue(i, 'updBtn', '수정')
            }
            this.gridObj.gridView.commit()
        },
        // 조회 유효성체크
        isValidChk() {
            let validFromDt = CommonUtil.replaceDash(this.reqParam.fromDt)
            let validToDt = CommonUtil.replaceDash(this.reqParam.toDt)

            if (_.isEmpty(validFromDt)) {
                this.showTcComAlert(
                    '최초등록일자의 시작일(을)를 입력해 주십시오.'
                )
                return false
            }
            if (_.isEmpty(validToDt)) {
                this.showTcComAlert(
                    '최초등록일자의 종료일(을)를 입력해 주십시오.'
                )
                return false
            }
            if (validFromDt.substr(0, 6) !== validToDt.substr(0, 6)) {
                this.showTcComAlert(
                    '시작일자와 종료일자를 동일한 월로 지정하세요.'
                )
                return false
            }
            if (validFromDt > validToDt) {
                this.showTcComAlert('주문일자의 시작일이 종료일보다 큽니다.')
                return false
            }
            return true
        },
        // 신규등록
        openPop() {
            this.agencyInfo = {}
            this.showPop = true
        },
        //===================== 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getAgencyList() {
            this.searchParam.agencyCd = this.reqParam.agencyCd
            this.searchParam.agencyNm = this.reqParam.agencyNm
            this.searchParam.searchDate = moment(new Date()).format(
                'YYYY-MM-DD'
            )
            basBcoAgencysApi.getAgencyList(this.searchParam).then((res) => {
                // console.log('getAgencyList then : ', res)
                // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.agencyCd = _.get(res[0], 'agencyCd')
                    this.reqParam.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultAgencyRows = res
                    this.showBcoAgencys = true
                }
            })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAgencyList()
            } else {
                this.showBcoAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onAgencyEnterKey() {
            this.resultAgencyRows = []
            this.getAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.reqParam.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(retrunData) {
            // console.log('retrunData: ', retrunData)
            this.reqParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.reqParam.agencyNm = _.get(retrunData, 'agencyNm')
        },
        //===================== //대리점팝업관련 methods ================================
    },
}
</script>
