import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'rgnCd', // 권역코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgnNm', // 권역명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd', // 레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm', // 레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd1', // 레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1', // 레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd2', // 레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2', // 레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd3', // 레벨3조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm3', // 레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoShopCd', // 거래처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 모델코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 모델명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', // 색상코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'totDisQty', // 보유수량합계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdDisQty', // 보유수량 TD
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'shopDisQty', // 보유수량 매장
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'movIngTdQty', // 이동예정 이동중
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'movInTdQty', // 이동예정 입고
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tdSaleQty', // 출고확정 TD
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'shopSaleQty', // 출고확정 매장
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleSumQty', // 출고확정 합계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'strdDt', // 기준일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'strdTm', // 기준시각
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rgnCd',
            fieldName: 'rgnCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '권역코드',
        },
        {
            name: 'rgnNm',
            fieldName: 'rgnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '권역명',
        },
        // {
        //     name: 'orgCd',
        //     fieldName: 'orgCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '조직',
        // },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'dealcoShopCd',
            fieldName: 'dealcoShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매장코드',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처코드',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처명',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델코드',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델명',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '색상코드',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '색상명',
        },
        // 보유수량 - TD, 매장, 합계
        {
            name: 'tdDisQty',
            fieldName: 'tdDisQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,##0',
            header: 'TD',
        },
        {
            name: 'shopDisQty',
            fieldName: 'shopDisQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,##0',
            header: '매장',
        },
        {
            name: 'totDisQty',
            fieldName: 'totDisQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,##0',
            header: '합계',
        },
        // 이동예정 - 이동중, 입고
        {
            name: 'movIngTdQty',
            fieldName: 'movIngTdQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,##0',
            header: '이동출고',
        },
        {
            name: 'movInTdQty',
            fieldName: 'movInTdQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,##0',
            header: '입고',
        },
        // 출고확정 - TD, 매장, 합계
        {
            name: 'tdSaleQty',
            fieldName: 'tdSaleQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,##0',
            header: 'TD',
        },
        {
            name: 'shopSaleQty',
            fieldName: 'shopSaleQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,##0',
            header: '매장',
        },
        {
            name: 'saleSumQty',
            fieldName: 'saleSumQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,##0',
            header: '합계',
        },
    ],
    layout: [
        'rgnCd',
        'rgnNm',
        // 'orgCd',
        'orgNm',
        'dealcoShopCd',
        'dealcoCd',
        'dealcoNm',
        'prodCd',
        'prodNm',
        'colorCd',
        'colorNm',
        {
            name: '보유수량',
            direction: 'horizontal',
            items: ['tdDisQty', 'shopDisQty', 'totDisQty'],
        },
        {
            name: '이동예정',
            direction: 'horizontal',
            items: ['movIngTdQty', 'movInTdQty'],
        },
        {
            name: '출고확정',
            direction: 'horizontal',
            items: ['tdSaleQty', 'shopSaleQty', 'saleSumQty'],
        },
    ],
}
