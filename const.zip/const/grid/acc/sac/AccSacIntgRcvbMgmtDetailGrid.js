import { ValueType } from 'realgrid'

export const GRID_HEADER_DETAIL = {
    fields: [
        {
            fieldName: 'dpstSeq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dpstDt',
            dataType: ValueType.TEXT,
            Text: 'yyyyMMdd',
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'dpstAmt',
        //     dataType: ValueType.NUMBER,
        // },
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'dpstSeq',
            fieldName: 'dpstSeq',
            type: 'data',
            width: '150',
            header: { text: '입금순번' },
            numberFormat: '#,###,###,##0',
            editable: false,
        },
        {
            name: 'dpstDt',
            fieldName: 'dpstDt',
            type: 'data',
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: { text: '입금일자' },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyy-MM-dd',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true
                } else {
                    ret.editable = false
                }
                return ret
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '150',
            header: { text: '거래처' },
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '150',
            editable: true,
            header: {
                text: '거래처명',
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true

                    //조직코드 입력 유형 변경 행추가 때만 입력가능
                    let dealcoCd = grid._view.columnByName('dealcoNm')
                    dealcoCd.editable = true
                    dealcoCd.button = 'action'
                    dealcoCd.buttonVisibility = 'always'
                } else {
                    let dealcoCd = grid._view.columnByName('dealcoNm')
                    dealcoCd.editable = false
                    dealcoCd.button = 'none'
                    dealcoCd.buttonVisibility = ''
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        // {
        //     name: 'dpstAmt',
        //     fieldName: 'dpstAmt',
        //     type: 'data',
        //     header: { text: '입금금액' },
        //     width: '150',
        //     visible: false,
        //     styleName: 'right-column',
        //     numberFormat: '#,###,###,##0',
        //     footer: {
        //         expression: 'sum',
        //         numberFormat: '#,###,###,##0',
        //         styleName: 'right-column',
        //     },
        //     styleCallback(grid, dataCell) {
        //         let ret = {}
        //         if (
        //             dataCell.item.rowState == 'created' ||
        //             dataCell.item.rowState == 'appending' ||
        //             dataCell.item.rowState == 'inserting'
        //         ) {
        //             ret.editable = true
        //         } else {
        //             ret.editable = false
        //         }
        //         return ret
        //     },
        // },
        {
            name: 'saleMgmtNo',
            fieldName: 'saleMgmtNo',
            header: { text: '수납번호' },
            type: 'data',
            width: '150',
            editable: false,
            editor: {
                useEnterKey: true,
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    //ret.editable = true

                    //조직코드 입력 유형 변경 행추가 때만 입력가능
                    let saleMgmtNo = grid._view.columnByName('saleMgmtNo')
                    saleMgmtNo.editable = true
                    saleMgmtNo.button = 'action'
                    saleMgmtNo.buttonVisibility = 'always'
                } else {
                    let saleMgmtNo = grid._view.columnByName('saleMgmtNo')
                    saleMgmtNo.editable = true
                    saleMgmtNo.button = 'none'
                    saleMgmtNo.buttonVisibility = ''
                    ret.editable = true
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'dpstDealcoCd',
            fieldName: 'dpstDealcoCd',
            type: 'data',
            width: '150',
            header: { text: '수납의뢰처' },
            editable: false,
        },
        {
            name: 'dpstDealcoNm',
            fieldName: 'dpstDealcoNm',
            type: 'data',
            width: '150',
            header: { text: '수납의뢰처명' },
            editable: false,
        },
        {
            name: 'dpstAmt',
            fieldName: 'dpstAmt',
            type: 'data',
            header: { text: '금액' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true
                } else {
                    ret.editable = false
                }
                return ret
            },
        },

        {
            name: 'rmks',
            fieldName: 'rmks',
            header: { text: '비고' },
            type: 'data',
            width: '150',
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true
                } else {
                    ret.editable = false
                }
                return ret
            },
        },
    ],
}
