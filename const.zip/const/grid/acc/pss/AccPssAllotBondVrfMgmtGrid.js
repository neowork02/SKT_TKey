import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accMth',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opSaleOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accItmNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mdlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bondPrchAmtSwing',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bondPrchAmtTkey',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gapAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            width: '150',
            styles: { textAlignment: 'center' },
            header: { text: '대리점코드' },
        },
        {
            name: 'accMth',
            fieldName: 'accMth',
            type: 'data',
            width: '150',
            styles: { textAlignment: 'center' },
            header: { text: '정산월' },
            visible: false,
        },
        {
            name: 'opSaleOrgNm',
            fieldName: 'opSaleOrgNm',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            header: { text: '대리점명' },
        },
        {
            name: 'svcDt',
            fieldName: 'svcDt',
            type: 'data',
            header: { text: 'Swing개통일' },
            width: '150',
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'accItmNm',
            fieldName: 'accItmNm',
            type: 'data',
            styleName: 'left-column',
            styles: { textAlignment: 'center' },
            header: { text: '정산항목' },
            width: '150',
        },
        {
            name: 'mdlNm',
            fieldName: 'mdlNm',
            type: 'data',
            styleName: 'left-column',
            styles: { textAlignment: 'center' },
            header: { text: '모델명' },
            width: '150',
        },
        {
            name: 'serNo',
            fieldName: 'serNo',
            styleName: 'left-column',
            styles: { textAlignment: 'center' },
            header: { text: '일련번호' },
            groupFooter: {
                expression: 'sum',
                styleName: 'right-column',
            },
            footer: {
                text: '합계',
            },
            width: '150',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            width: '150',
            header: {
                text: '서비스 관리번호',
            },
        },
        {
            name: 'bondPrchAmtSwing',
            fieldName: 'bondPrchAmtSwing',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            width: '150',
            header: { text: 'Swing' },
            groupFooter: {
                expression: 'sum',
                numberFormat: '#,##0.0',
                styleName: 'right-column',
            },
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'bondPrchAmtTkey',
            fieldName: 'bondPrchAmtTkey',
            numberFormat: '#,###,###,##0',
            type: 'data',
            styleName: 'right-column',
            styles: { textAlignment: 'center' },
            header: { text: 'TKey taka' },
            width: '150',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'gapAmt',
            fieldName: 'gapAmt',
            numberFormat: '#,###,###,##0',
            type: 'data',
            styleName: 'right-column',
            styles: { textAlignment: 'center' },
            header: { text: '차이금액' },
            width: '150',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styleName: 'left-column',
            styles: { textAlignment: 'center' },
            header: { text: '비고' },
            width: '150',
        },
    ],
}
