import { ValueType } from 'realgrid'

export const TRMS_HEADER = {
    fields: [
        {
            fieldName: 'orgCd', //	 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', //	 대리점
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', //	정산처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accPlc', //	정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', //	정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zbudat', //	귀속일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zifdate', //	전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zgubun', //	전송구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ztrusr', //	전송자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zcnt', //	건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zconfirm', //	확정여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zconfdat', //	확정일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zconfusr', //	확정자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zdele', //	취소여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errlog', //	Error Log
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zitem', //	zitem
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chk', //	chk
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', //
            dataType: ValueType.TEXT,
        },
        ////////////// 20220620추가.
        {
            fieldName: 'canUserId', // 취소사용자 ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bukrs', // 회사코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mandt', // 클라이언트
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNm', // 전송요청사용자명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            header: '대리점코드',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            header: '대리점',
        },
        // {
        //     name: 'accShopCd',
        //     fieldName: 'accShopCd',
        //     type: 'data',
        //     width: '200',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '서브점매장코드',
        // },
        {
            name: 'accPlc',
            fieldName: 'accPlc',
            type: 'data',
            header: '서브점코드',
        },
        // {
        //     name: 'accDealcoNm',
        //     fieldName: 'accDealcoNm',
        //     type: 'data',
        //     width: '200',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '서브점명',
        // },
        {
            name: 'zbudat',
            fieldName: 'zbudat',
            type: 'data',
            header: '귀속일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },

        {
            name: 'zifdate',
            fieldName: 'zifdate',
            type: 'data',
            width: '150',
            header: '전송일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'zgubun',
            fieldName: 'zgubun',
            type: 'data',
            header: '전송구분',
        },
        {
            name: 'ztrusr',
            fieldName: 'ztrusr',
            type: 'data',
            header: '전송자',
        },
        {
            name: 'zcnt',
            fieldName: 'zcnt',
            type: 'data',
            header: '건수',
        },
        {
            name: 'zconfirm',
            fieldName: 'zconfirm',
            type: 'data',
            header: '확정여부',
            displayCallback: function (grid, index) {
                let resTxt = ''
                const zconfirm = grid.getValue(index.itemIndex, 'zconfirm')
                if ('0' == zconfirm) resTxt = '미수행'
                else if ('1' == zconfirm) resTxt = '전송에러'
                else if ('2' == zconfirm) resTxt = '전송성공'
                else if ('3' == zconfirm) resTxt = '확정에러'
                else if ('4' == zconfirm) resTxt = '확정성공'
                else if ('7' == zconfirm) resTxt = '예금주오류'

                return resTxt
            },
        },
        {
            name: 'zconfdat',
            fieldName: 'zconfdat',
            type: 'data',
            header: '확정일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'zconfusr',
            fieldName: 'zconfusr',
            type: 'data',
            header: '확정자',
        },
        {
            name: 'zdele',
            fieldName: 'zdele',
            type: 'data',
            header: '취소여부',
        },
        {
            name: 'errlog',
            fieldName: 'errlog',
            type: 'data',
            header: 'Error Log',
        },
    ],
}

export const TRMS_ORG_HEADER = {
    fields: [
        {
            fieldName: 'zbudat', //	귀속일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zgubun', //	 전송구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zifdate', //	 전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ztrusr', //  전송자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zcnt', //  건수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zconfirm', //  확정여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zconfdat', //  확정일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zconfusr', //  확정자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zdele', //  취소여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errlog', //  Error Log
            dataType: ValueType.TEXT,
        },
        {
            fieldName: ' accShopCd', //	 정산처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accPlcNm', //	 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accPlc', //	 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', //	 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', //	 조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zitem', //	zitem
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chk', //	chk
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', //
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNm', // 전송요청사용자명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            header: '조직명',
        },
        {
            name: 'accShopCd',
            fieldName: 'accShopCd',
            type: 'data',
            header: '정산처매장코드',
        },
        {
            name: 'accPlc',
            fieldName: 'accPlc',
            type: 'data',
            header: '정산처',
        },
        {
            name: 'accPlcNm',
            fieldName: 'accPlcNm',
            type: 'data',
            width: '150',
            header: '정산처명',
        },
        {
            name: 'zbudat',
            fieldName: 'zbudat',
            type: 'data',
            header: '귀속일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },

        {
            name: 'zifdate',
            fieldName: 'zifdate',
            type: 'data',
            width: '150',
            header: '전송일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },

        {
            name: 'zgubun',
            fieldName: 'zgubun',
            type: 'data',
            header: '전송구분',
        },
        {
            name: 'ztrusr',
            fieldName: 'ztrusr',
            type: 'data',
            header: '전송자',
        },
        {
            name: 'zcnt',
            fieldName: 'zcnt',
            type: 'data',
            header: '건수',
        },
        {
            name: 'zconfirm',
            fieldName: 'zconfirm',
            type: 'data',
            header: '확정여부',
            displayCallback: function (grid, index) {
                let resTxt = ''
                const zconfirm = grid.getValue(index.itemIndex, 'zconfirm')
                if ('0' == zconfirm) resTxt = '미수행'
                else if ('1' == zconfirm) resTxt = '전송에러'
                else if ('2' == zconfirm) resTxt = '전송성공'
                else if ('3' == zconfirm) resTxt = '확정에러'
                else if ('4' == zconfirm) resTxt = '확정성공'
                else if ('7' == zconfirm) resTxt = '예금주오류'

                return resTxt
            },
        },
        {
            name: 'zconfdat',
            fieldName: 'zconfdat',
            type: 'data',
            header: '확정일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'zconfusr',
            fieldName: 'zconfusr',
            type: 'data',
            header: '확정자',
        },
        {
            name: 'zdele',
            fieldName: 'zdele',
            type: 'data',
            header: '취소여부',
        },
        {
            name: 'errlog',
            fieldName: 'errlog',
            type: 'data',
            header: 'Error Log',
        },
    ],
}

export const G_HEADER2 = {
    fields: [
        {
            fieldName: 'zitem', // 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wrbtr', // 금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dealcocl1', // 구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accPlc', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'belnr', // 전표번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accCreateDt', //  전표생성일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zbelnr', // 취소전표번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cancelYn', //  취소여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errlog', //  ERROR LOG
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNm', // 전송요청사용자명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'zitem',
            fieldName: 'zitem',
            type: 'data',
            header: '순번',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'wrbtr',
            fieldName: 'wrbtr',
            type: 'data',
            header: '금액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'dealcocl1',
            fieldName: 'dealcocl1',
            type: 'data',
            header: '구분',
        },
        {
            name: 'accPlc',
            fieldName: 'accPlc',
            type: 'data',
            header: '거래처코드',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: '거래처명',
        },
        {
            name: 'belnr',
            fieldName: 'belnr',
            type: 'data',
            header: '전표번호',
        },
        {
            name: 'accCreateDt',
            fieldName: 'accCreateDt',
            type: 'data',
            header: '전표생성일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'zbelnr',
            fieldName: 'zbelnr',
            type: 'data',
            header: '취소전표번호',
        },
        {
            name: 'cancelYn',
            fieldName: 'cancelYn',
            type: 'data',
            header: '취소여부',
        },
        {
            name: 'errlog',
            fieldName: 'errlog',
            type: 'data',
            width: '200',
            header: 'ERROR LOG',
        },
    ],
}

export const G_HEADER3 = {
    fields: [
        {
            fieldName: 'zitemseq', // 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bschl', //전기키
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bschlNm', //전기키명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'umskz', //특별GL
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'regno', //정산처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hkont', //계정
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wrbtr', //금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'wmwst', //부가세
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mwskz', //세금코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sgtxt', //적요(TEXT)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errlog', //ERROR LOG
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zgcode', //직영점UKEY코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bupla', //영업센터코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'kostl', //코스트센터
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zterm', //지급조건
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zlspr', //지급보류키
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zlsch', //지급방법
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zfbdt', //지급기산일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bvtyp', //사용미정
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zrefer1', //참고1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zrefer2', //참고2
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zrefer3', //참고3
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zrefer4', //참고4
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zrefer5', //참고5
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'waers', //통화
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gsber', //사업영역
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNm', // 전송요청사용자명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'zitemseq',
            fieldName: 'zitemseq',
            type: 'data',
            header: '순번',
        },
        {
            name: 'bschl',
            fieldName: 'bschl',
            type: 'data',
            header: '전기키',
        },
        {
            name: 'bschlNm',
            fieldName: 'bschlNm',
            type: 'data',
            header: '전기키명',
        },
        {
            name: 'umskz',
            fieldName: 'umskz',
            type: 'data',
            header: '특별GL',
        },
        {
            name: 'regno',
            fieldName: 'regno',
            type: 'data',
            header: '정산처코드',
        },
        {
            name: 'hkont',
            fieldName: 'hkont',
            type: 'data',
            header: '계정',
        },
        {
            name: 'wrbtr',
            fieldName: 'wrbtr',
            type: 'data',
            header: '금액',
            numberFormat: '#,##0',
        },
        {
            name: 'wmwst',
            fieldName: 'wmwst',
            type: 'data',
            header: '부가세',
            numberFormat: '#,##0',
        },
        {
            name: 'mwskz',
            fieldName: 'mwskz',
            type: 'data',
            header: '세금코드',
        },
        {
            name: 'sgtxt',
            fieldName: 'sgtxt',
            type: 'data',
            header: '적요(TEXT)',
        },
        {
            name: 'errlog',
            fieldName: 'errlog',
            type: 'data',
            header: 'ERROR LOG',
        },
        {
            name: 'zgcode',
            fieldName: 'zgcode',
            type: 'data',
            header: '직영점UKEY코드',
        },
        {
            name: 'bupla',
            fieldName: 'bupla',
            type: 'data',
            header: '영업센터코드',
        },
        {
            name: 'kostl',
            fieldName: 'kostl',
            type: 'data',
            header: '코스트센터',
        },
        {
            name: 'zterm',
            fieldName: 'zterm',
            type: 'data',
            header: '지급조건',
        },
        {
            name: 'zlspr',
            fieldName: 'zlspr',
            type: 'data',
            header: '지급보류키',
        },
        {
            name: 'zlsch',
            fieldName: 'zlsch',
            type: 'data',
            header: '지급방법',
        },
        {
            name: 'zfbdt',
            fieldName: 'zfbdt',
            type: 'data',
            header: '지급기산일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'bvtyp',
            fieldName: 'bvtyp',
            type: 'data',
            header: '사용미정',
        },
        {
            name: 'zrefer1',
            fieldName: 'zrefer1',
            type: 'data',
            header: '참고1',
        },
        {
            name: 'zrefer2',
            fieldName: 'zrefer2',
            type: 'data',
            header: '참고2',
        },
        {
            name: 'zrefer3',
            fieldName: 'zrefer3',
            type: 'data',
            header: '참고3',
        },
        {
            name: 'zrefer4',
            fieldName: 'zrefer4',
            type: 'data',
            header: '참고4',
        },
        {
            name: 'zrefer5',
            fieldName: 'zrefer5',
            type: 'data',
            header: '참고5',
        },
        {
            name: 'waers',
            fieldName: 'waers',
            type: 'data',
            header: '통화',
        },
        {
            name: 'gsber',
            fieldName: 'gsber',
            type: 'data',
            header: '사업영역',
        },
    ],
}
