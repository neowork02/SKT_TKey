<template>
    <div v-if="this.isGridAcntInfo1">
        <!--    <div>-->
        <!-- SubTit  -->
        <div class="stitHead">
            <h4 class="subTit">계좌정보</h4>
        </div>
        <!-- //SubTit -->

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search (혼합형:조회조건내 타이틀 있는 경우) -->
            <!-- Search_line 7 -->
            <div class="searchform mgt-20">
                <p class="formTit">출금계좌</p>
                <div class="formitem div3">
                    <TCComComboBox
                        v-model="acntInfo.slcmDfryBankCd"
                        labelName="은행"
                        :eRequired="isSlcmAcnt"
                        :itemList="zbasC00420"
                        @input="setData"
                    />
                </div>
                <div class="formitem div3">
                    <TCComInput
                        v-model="acntInfo.slcmDfryAccNo"
                        labelName="계좌"
                        :eRequired="isSlcmAcnt"
                        @input="setData"
                    />
                </div>

                <div class="formitem div3">
                    <div class="arrayType btnType">
                        <div class="colinput">
                            <TCComInput
                                v-model="acntInfo.slcmDfryDepo"
                                labelName="예금주"
                                :eRequired="isSlcmAcnt"
                                @input="setData"
                            />
                        </div>
                        <div class="colbtn">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="조회"
                                @click="click"
                            />
                        </div>
                    </div>
                </div>
            </div>
            <div class="searchform vline">
                <p class="formTit">
                    <span>조회결과</span>
                    <span
                        class="color-red2"
                        v-text="acntInfo.slcmChk === 'Y' ? '일치' : '불일치'"
                    >
                    </span>
                </p>

                <div class="formitem div3">
                    <div class="arrayType btnType">
                        <div class="colinput">
                            <TCComInput
                                v-model="acntInfo.vrfDpstrNm"
                                labelName="예금주"
                                :disabled="true"
                                @input="setData"
                            />
                        </div>
                        <div class="colbtn">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="승인"
                                @click="click1"
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--        <div class="searchform pt-2 vline">-->
        <!-- SubTit_Type2 -->
        <div class="stitHead">
            <h2 class="subTit">요금계좌</h2>
            <span class="stitBtnRef type2">
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_approval"
                    :objAuth="objAuth"
                    labelName="가상계좌발급"
                    @click="acntInfoAdd"
                />
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_filesave"
                    labelName="입력저장"
                    :objAuth="objAuth"
                    @click="tempSave"
                />
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowadd"
                    labelName="행추가"
                    :objAuth="objAuth"
                    @click="gridAddRowBtn"
                />
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowdel"
                    labelName="행삭제"
                    :objAuth="objAuth"
                    @click="gridChkDelRowBtn"
                />
            </span>
        </div>
        <!-- //SubTit_Type2 -->
        <!-- <div class="searchform">
            <p class="formTit">요금계좌</p>
        </div>
        <div class="stitHead mgt-10">
            <span class="stitBtnRef notit mb10">
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_approval"
                    :objAuth="objAuth"
                    labelName="가상계좌발급"
                    @click="acntInfoAdd"
                /> -->
        <!--
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_filesave"
                    labelName="저장"
                    :objAuth="objAuth"
                    @click="gridSaveBtn"
                />
                -->
        <!-- 
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_filesave"
                    labelName="입력저장"
                    :objAuth="objAuth"
                    @click="tempSave"
                />
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowadd"
                    labelName="행추가"
                    :objAuth="objAuth"
                    @click="gridAddRowBtn"
                />
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowdel"
                    labelName="행삭제"
                    :objAuth="objAuth"
                    @click="gridChkDelRowBtn"
                />
            </span> -->
        <!-- //SubTit 
        </div>-->
        <!-- //Search_div -->
        <TCRealGrid
            id="gridAcnt"
            ref="gridAcnt"
            :editable="true"
            :movable="false"
            :columnMovable="false"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
        <p class="infoTxt">
            <span class="color-red">
                수정/등록 후 입력저장 버튼을 눌러야 반영이 됩니다.
            </span>
        </p>
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dealcoMgmt/helpers'
import _ from 'lodash'

import { CommonGrid, CommonUtil } from '@/utils'
import { GRID_ACNT_INFO } from '@/const/grid/bas/prm/basPrmDealcoMgmtHeader'
import CommonMixin from '@/mixins'

export default {
    name: 'AcntInfoContainer',
    mixins: [CommonMixin],
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            storeKey: 'acntInfoData',
            view: GRID_ACNT_INFO,
            //basPrmDealcoImagAccVoList: [], // 계좌정보
            imagAccDataList: [],
            isAccNo: false,
            acntInfo: {
                bankCd: '',
                acntNo: '',
                depoNm: '',
                vrfDpstrNm: '',

                slcmChk: 'N',
                isSlCmYn: '',
                isSlCmChk: '',
                slcmDfryBankCd: '',
                slcmDfryAccNo: '',
                slcmDfryDepoNm: '',
                slcmDfryDepo: '',
                slcmDfryDepoCheck: '',
                vrfDpstrYn: '',
            },

            isDtlAdd: false,
            acntParam: {},
            acntAccNoParam: {}, // 가상계좌정보
            gridStyle: {
                height: '130px', //그리드 높이 조절
            },
            objAuth: {},
            layout2: [
                'bankCd',
                'acntNo',
                'depoNm',
                'cmsCd',
                'modUserId',
                'modDtm',
            ],
            isAcntNo: false,
            clickStatus: null,
            iamgAccDataList: [],
            isSlcmAcnt: true,
            isUptAcntInfo: false,
        }
    },
    computed: {
        ...serviceComputed,
        //==================== 상세데이터 ==================
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
        basPrmDealcoImagAccVo: {
            get() {
                return this.basPrmDealcoImagAccListVo // 매장별가상계좌
            },
        },
        zbasC00410: {
            get() {
                return this.ZBAS_C_00410
            },
        },
        zbasC00420: {
            get() {
                return this.ZBAS_C_00420
            },
        },
        acntClCd: {
            get() {
                return this.ACNT_CL_CD
            },
        },
        //==================== //상세데이터 ==================
        isDisabledDataBankCdYn1: {
            get() {
                return this.isDisabledDataBankCdYn
            },
        },
        etcAddInfoData1: {
            get() {
                return this.etcAddInfoData
            },
        }, // 물류창고/직영점/하부망 추가정보
        basPrmDealcoImagAccList1: {
            get() {
                return this.basPrmDealcoImagAccList
            },
        },
        basPrmDealcoImagAccListNew1: {
            get() {
                return this.basPrmDealcoImagAccListNew
            },
        },
        isGridAcntInfo1: {
            get() {
                return this.isGridAcntInfo
            },
        },
    },
    mounted() {
        this.initData()
    },
    methods: {
        ...serviceMethods,
        initData() {
            this.acntInfo = {
                bankCd: '',
                acntNo: '',
                depoNm: '',
                vrfDpstrNm: '',
                slcmChk: 'N',
                isSlCmYn: '',
                isSlCmChk: '',
                slcmDfryBankCd: '',
                slcmDfryAccNo: '',
                slcmDfryDepoNm: '',
                slcmDfryDepo: '',
                slcmDfryDepoCheck: '',
                vrfDpstrYn: '',
            }
            this.isAccNo = false
            this.isSlcmAcnt = true
            this.isUptAcntInfo = false
        },
        setData() {
            let params = { ...this.acntInfo }
            if (!_.isEmpty(this.acntInfoData)) {
                const checkKeys = [
                    'slcmDfryBankCd',
                    'slcmDfryAccNo',
                    'slcmDfryDepo',
                    'slcmChk',
                    'isSlCmYn',
                    'isSlCmChk',
                ]

                checkKeys.some((key) => {
                    if (
                        !_.isEmpty(this.acntInfoDataOld) &&
                        !_.isEmpty(this.acntInfoData) &&
                        !_.isEqual(
                            this.acntInfoDataOld[key],
                            this.acntInfoData[key]
                        )
                    ) {
                        this.isUptAcntInfo = true
                        return true
                    } else {
                        if (_.isEmpty(this.acntInfoDataOld)) {
                            this.storeSet('acntInfoDataOld', params)
                        }
                        this.isUptAcntInfo = false
                    }
                })
            }

            this.storeSet('isAcntInfo', this.isUptAcntInfo)
            this.storeSet(this.storeKey, params)
        },

        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        isDisabled(key, isDisabled) {
            this.defaultAssign_({
                key: key,
                value: isDisabled,
            })
        },
        errorCellFocus(chkCell, message) {
            this.showTcComAlert(message)
            this.$refs.gridAcnt.validationChkGrid(chkCell)
        },
        validationCheck() {
            let index = this.$refs.gridAcnt.modifyGrid() //변경한 행 index 가져오기
            const chk = { index: -1, fieldName: '' }
            if (index.length) {
                for (let i = 0; i < index.length; i++) {
                    let row = this.$refs.gridAcnt.dataProvider.getJsonRow(
                        index[i],
                        true
                    )

                    if (!_.isEmpty(row.acntNo)) {
                        chk.index = index[i]
                        chk.fieldName = 'acntNo'

                        this.errorCellFocus(chk, '입력저장을 눌러주세요.')
                        return false
                    }

                    //코드 중복 체크
                    if (row.__rowState == 'created') {
                        let all1 = this.$refs.gridAcnt.dataProvider.getJsonRows(
                            0,
                            -1
                        )
                        let dup1 = all1.filter(
                            (e) => e.bankCd === row.bankCd // 은행코드
                        )
                        if (_.isEmpty(row.bankCd)) {
                            chk.index = index[i]
                            chk.fieldName = 'bankCd'
                            this.errorCellFocus(
                                chk,
                                this.$refs.gridAcnt.gridView.columnByField(
                                    chk.fieldName
                                ).header.text +
                                    ' 필수 입력 입니다. 은행을 선택해주세요.'
                            )
                            return false
                        }

                        //은행코드 체크
                        if (dup1.length > 1) {
                            chk.index = index[i]
                            chk.fieldName = 'bankCd'

                            this.errorCellFocus(chk, '중복된 은행 입니다')
                            return false
                        }

                        if (this.isAcntNo && !row['bankCd']) {
                            chk.index = index[i]
                            chk.fieldName = 'bankCd'

                            this.errorCellFocus(
                                chk,
                                this.$refs.gridAcnt.gridView.columnByField(
                                    chk.fieldName
                                ).header.text +
                                    ' 필수 입력 입니다. 은행을 선택해주세요.'
                            )
                            return false
                        }
                    }
                }
            } else {
                if (!this.gridData.delRows.length) {
                    // this.showTcComAlert(msgTxt.MSG_01002) // 저장할 데이타가 존재하지 않습니다.
                    this.showTcComAlert('발급받을 가상계좌가 없습니다.')
                    return false
                }
            }
            return true
        },

        GridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 5, '', '')
        },

        initAcntInfo() {
            this.gridObj = this.$refs.gridAcnt
            this.gridObj.gridView.setColumnLayout(this.layout2)
            this.gridObj.setGridState(false, false, true, false)
            this.gridObj.gridView.displayOptions.selectionStyle = 'rows'

            this.gridObj.gridView.columnByName('bankCd').values =
                CommonUtil.convListToGridLovValues(
                    this.zbasC00410,
                    'commCdVal',
                    'SELECT'
                )
            this.gridObj.gridView.columnByName('bankCd').labels =
                CommonUtil.convListToGridLovLabels(
                    this.zbasC00410,
                    'commCdValNm',
                    'SELECT'
                )

            if (!_.isEmpty(this.basPrmDealcoImagAccList1)) {
                let accList = []
                _.forEach(this.basPrmDealcoImagAccList1, (item) => {
                    let acntClCd = item.acntClCd
                    let slcmDfryBankCd = _.isEmpty(item.bankCd)
                        ? ''
                        : item.bankCd
                    let slcmDfryAccNo = _.isEmpty(item.acntNo)
                        ? ''
                        : item.acntNo
                    let slcmDfryDepo = _.isEmpty(item.depoNm) ? '' : item.depoNm
                    let slcmChk = _.isEmpty(item.slcmChk) ? '' : item.slcmChk
                    let isSlCmYn = _.isEmpty(item.isSlCmYn) ? '' : item.isSlCmYn
                    let isSlCmChk = _.isEmpty(item.isSlCmChk)
                        ? ''
                        : item.isSlCmChk

                    if (_.isEqual(acntClCd, '03')) {
                        this.acntInfo.slcmDfryBankCd = slcmDfryBankCd
                        this.acntInfo.slcmDfryAccNo = slcmDfryAccNo
                        this.acntInfo.slcmDfryDepo = slcmDfryDepo
                        //
                        // if (_.isEqual(slcmDfryDepo, this.acntInfo.vrfDpstrNm)) {
                        //     this.acntInfo.slcmChk = 'Y'
                        //     this.acntInfo.isSlCmYn = '1'
                        //     this.acntInfo.isSlCmChk = 'Y'
                        // }

                        let slcmDatas = {}
                        slcmDatas.slcmDfryBankCd = slcmDfryBankCd
                        slcmDatas.slcmDfryAccNo = slcmDfryAccNo
                        slcmDatas.slcmDfryDepo = slcmDfryDepo
                        slcmDatas.slcmChk = slcmChk
                        slcmDatas.isSlCmYn = isSlCmYn
                        slcmDatas.isSlCmChk = isSlCmChk

                        if (_.isEmpty(this.acntInfoDataOld.slcmDfryBankCd)) {
                            this.storeSet('acntInfoDataOld', slcmDatas)
                        }
                    } else {
                        accList.push(item)
                    }
                    this.setData()
                })

                this.gridObj.setRows(accList)
                this.gridObj.dataProvider.endUpdate()

                this.gridObj.gridView.onCellClicked = (grid, clickData) => {
                    if (typeof clickData.itemIndex !== 'undefined') {
                        _.forEach(GRID_ACNT_INFO.fields, (item) => {
                            const key = item.fieldName
                            this.acntInfo[key] = grid.getValue(
                                clickData.itemIndex,
                                key
                            )
                        })
                    }
                }
            }
            this.isDtlAdd = true
            // }
            //}

            return true
        },
        tempSave() {
            //let index = this.$refs.gridAcnt.modifyGrid() //변경한 행 index 가져오기
            // if (index.length == 0) {
            //     this.showTcComAlert(msgTxt.MSG_01002) // 저장할 데이타가 존재하지 않습니다.
            //     return false
            // }
            this.showTcComConfirm('입력저장 하시겠습니까?').then((confirm) => {
                if (!confirm) return false
                /*
                let save = []
                let setData = ['created', 'updated'] // 등록, 수정

                setData.forEach((key) => {
                    this.getJsonData(save, key)
                })
                */
                let rows = this.$refs.gridAcnt.dataProvider.getJsonRows()
                let newRows = []
                let isNullAcntNo = false
                rows.forEach((v) => {
                    if (_.isEmpty(v.acntNo)) {
                        this.showTcComAlert('가상계좌 발급을 진행해주세요.')
                        isNullAcntNo = true
                        return false
                    }
                    if (!_.isEmpty(v.modDtm)) {
                        // 수정사용자가 존재하면 update
                        v.__rowState = 'updated'
                    } else {
                        // 없으면 신규
                        v.__rowState = 'created'
                    }
                    newRows.push(v)
                })

                if (!isNullAcntNo) {
                    this.storeSet('basPrmDealcoImagAccList', newRows)
                }
            })
        },
        gridAddRowBtn: function () {
            let rowCnt = this.$refs.gridAcnt.dataProvider.getRowCount()
            this.$refs.gridAcnt.setGridState(false, false, true, false)
            if (rowCnt > 6) {
                this.showTcComAlert('최대 7개까지만 등록 가능합니다.')
                return
            } else {
                this.$refs.gridAcnt.dataProvider.addRow([])

                this.$refs.gridAcnt.gridView.columnByName('bankCd').values =
                    CommonUtil.convListToGridLovValues(
                        this.zbasC00410,
                        'commCdVal',
                        'SELECT'
                    )
                this.$refs.gridAcnt.gridView.columnByName('bankCd').labels =
                    CommonUtil.convListToGridLovLabels(
                        this.zbasC00410,
                        'commCdValNm',
                        'SELECT'
                    )

                this.$refs.gridAcnt.gridView.onEditCommit = (grid) => {
                    grid.editOptions.commitByCell = true
                }
                //}
            }
        },
        gridChkDelRowBtn: function () {
            let checkRows = this.$refs.gridAcnt.gridView.getCheckedRows(true)
            if (checkRows.length == 0) {
                this.showTcComAlert('삭제할 대상을 선택해 주세요.')
                return false
            }

            this.showTcComConfirm('삭제 하시겠습니까?').then((confirm) => {
                if (!confirm) return false

                this.$refs.gridAcnt.gridView.commit()
                let delRows = []

                let rows = this.$refs.gridAcnt.dataProvider.getJsonRows()

                if (checkRows.length >= 1) {
                    checkRows.forEach((n) => {
                        rows.forEach((v, i) => {
                            if (n === i) {
                                v.__rowState = 'deleted'
                                delRows.push(v)
                            }
                        })
                    })

                    /*
                    let accNewData = []
                    let accData = []

                    if (!_.isEmpty(this.basPrmDealcoImagAccListNew)) {
                        accNewData = [...this.basPrmDealcoImagAccListNew]
                    }

                    if (!_.isEmpty(this.basPrmDealcoImagAccList)) {
                        accData = [...this.basPrmDealcoImagAccList]
                    }

                    let addAccList = [...accNewData, ...accData]

                    // 기존데이터와 신규 데이터 unique 처리
                    const oriUnique = addAccList.filter((x, i, arr) => {
                        return (
                            arr.findIndex(
                                (item) => item.bankCd === x.bankCd
                            ) === i
                        )
                    })

                    const accList = oriUnique.filter((ori) => {
                        return !delRows.some((del) => del.bankCd === ori.bankCd)
                    })
                   */

                    this.objCnt -= checkRows.length
                    this.$refs.gridAcnt.dataProvider.beginUpdate()
                    this.$refs.gridAcnt.dataProvider.removeRows(checkRows)
                    this.$refs.gridAcnt.dataProvider.endUpdate()
                    this.$refs.gridAcnt.gridView.commit()

                    let newRows = this.$refs.gridAcnt.dataProvider.getJsonRows()

                    this.storeSet('basPrmDealcoImagAccList', newRows)

                    let newDelRows
                    if (!_.isEmpty(...this.basPrmDealcoImagAccListDel)) {
                        newDelRows = [
                            ...this.basPrmDealcoImagAccListDel,
                            ...delRows,
                        ]
                    } else {
                        newDelRows = delRows
                    }

                    this.storeSet('basPrmDealcoImagAccListDel', newDelRows) // 삭제된 항목

                    if (this.objCnt < 0) {
                        this.isDlvDealco = true
                        //this.initData()
                    }
                }
            })
        },
        getJsonData(save, type) {
            let rows = this.$refs.gridAcnt.dataProvider.getStateRows(type)

            for (let idx = 0; idx < rows.length; idx++) {
                let data = this.$refs.gridAcnt.dataProvider.getJsonRow(
                    rows[idx]
                )

                let acc = '04'
                let depoNm = _.isEmpty(data.depoNm) ? '' : data.depoNm
                let cmsCd = _.isEmpty(data.cmsCd) ? '' : data.cmsCd
                let bankCd = _.isEmpty(data.bankCd) ? '' : data.bankCd
                let acntNo = _.isEmpty(data.acntNo) ? '' : data.acntNo
                let __rowState = type

                // 가상 계좌번호가 없는경우에만 데이터 Set
                if (_.isEmpty(acntNo)) {
                    data.acc = acc
                    data.acntClCd = acc
                    data.depoNm = depoNm
                    data.cmsCd = cmsCd
                    data.bankCd = bankCd
                    data.__rowState = __rowState
                    save.push(data)
                }
            }
        },
        acntInfoAdd() {
            const dealCoGrp = this.etcAddInfoData1.dealcoGrpCd
            const dealCoCl1 = this.etcAddInfoData1.dealcoClCd1
            //const dealCoCl2 = this.etcAddInfoData1.dealcoClCd2

            if (_.isEmpty(this.etcAddInfoData1.orgCd)) {
                this.showTcComAlert('소속조직을 먼저 선택해야 합니다.')
                return false
                // 거래처그룹 : 직영매장, 거래처구분 : 직영위탁/자영위탁직영/대형유통망위탁 이 아닌 경우
            } else {
                if (
                    _.isEqual(dealCoGrp, 'AY') &&
                    (_.isEqual(dealCoCl1, 'AF') ||
                        _.isEqual(dealCoCl1, 'A6') ||
                        _.isEqual(dealCoCl1, 'A7'))
                ) {
                    this.showTcComAlert(
                        '직영위탁/자영위탁직영/대형유통망위탁이 아닌 경우 발급이 불가합니다.'
                    )
                    return false
                    // 거래처그룹 : 하부망, 거래처유형 : 2차점인 경우
                }
                // else if (
                //     _.isEqual(dealCoGrp, 'YY') &&
                //     _.isEqual(dealCoCl2, '2')
                // ) {
                //     isCheckPass = true
                //     this.showTcComAlert(
                //         '하부망, 2차점인 경우경우 발급이 불가합니다.'
                //     )
                //     return false
                // }

                this.isAcntNo = true
                if (!this.validationCheck()) {
                    return false
                }
                this.showTcComConfirm('발급 하시겠습니까?').then((confirm) => {
                    if (!confirm) return false
                    this.$refs.gridAcnt.gridView.commit()

                    let jsonData = []
                    const setData = ['created', 'updated'] // 등록, 수정

                    // 변경되는 데이터 조회
                    setData.forEach((key) => {
                        this.getJsonData(jsonData, key)
                    })

                    const key = 'basPrmDealcoDtlNewImgAccNoCondDto' // 가상계좌 변수명
                    let acntAccNoParam = {}
                    acntAccNoParam[key] = jsonData

                    this.defaultAssign_({
                        key: 'acntAccNoParams',
                        value: acntAccNoParam,
                    })

                    /*
                    this.defaultAssign_({
                        key: 'basPrmDealcoImagAccListNew',
                        value: data,
                    })
                   */

                    let data1
                    this.dealcoMgmtImgAccNO_()
                        .then((data) => {
                            if (_.isEmpty(data)) {
                                this.showTcComAlert('발급실패')
                            } else {
                                this.showTcComAlert('발급성공')

                                this.isAccNo = true
                            }
                            data1 = data
                            console.log('data1 ->', data1)
                        })
                        .catch((error) => {
                            Promise.reject(error)
                        })
                        .finally(() => {
                            this.defaultAssign_({
                                key: 'acntAccNoParams',
                                value: [],
                            })
                            //this.initAcntInfo()
                        })
                })
            }
        },
        click() {
            if (_.isEmpty(this.acntInfo.slcmDfryBankCd)) {
                this.showTcComAlert('출금은행을 선택해주세요.')
            } else if (_.isEmpty(this.acntInfo.slcmDfryAccNo)) {
                this.showTcComAlert('출금계좌를 입력해주세요.')
            } else if (_.isEmpty(this.acntInfo.slcmDfryDepo)) {
                this.showTcComAlert('예금주를 입력해주세요.')
            } else {
                let param = {}

                param.slcmDfryBankCd = this.acntInfo.slcmDfryBankCd
                param.slcmDfryAccNo = this.acntInfo.slcmDfryAccNo

                this.defaultAssign_({
                    key: 'slcmParams',
                    value: param,
                })

                let data1
                this.slcmDfrvDepo_()
                    .then((data) => {
                        // if (_.isEmpty(data)) {
                        //     this.showTcComAlert('조회실패')
                        // } else {
                        //     this.showTcComAlert('조회성공')
                        // }
                        data1 = data
                    })
                    .catch((error) => {
                        Promise.reject(error)
                    })
                    .finally(() => {
                        if (data1 !== null) {
                            this.acntInfo.slcmChk = 'N'
                            if (
                                _.isEqual(
                                    data1.slcmDfryDepoNm,
                                    this.acntInfo.slcmDfryDepo
                                )
                            ) {
                                this.acntInfo.slcmChk = 'Y'
                                this.acntInfo.isSlCmYn = '1'
                                this.acntInfo.isSlCmChk = 'Y'
                            } else {
                                this.acntInfo.isSlCmYn = '9'
                                this.acntInfo.isSlCmChk = 'N'
                            }
                            //this.acntInfo.slcmChk = data1.slcmDfryDepoYn
                            this.acntInfo.slcmDfryDepoCheck =
                                data1.slcmDfryDepoNm
                            this.acntInfo.vrfDpstrNm = data1.slcmDfryDepoNm
                        } else {
                            this.showTcComAlert(
                                '조회결과가 없습니다. 진행 할 수 없습니다'
                            )
                            this.acntInfo.isSlCmYn = '9'
                            this.acntInfo.isSlCmChk = 'N'
                        }
                        this.setData()
                        this.defaultAssign_({
                            key: 'slcmParams',
                            value: [],
                        })
                    })
            }
        },
        click1() {
            if (!_.isEmpty(this.acntInfo.vrfDpstrNm)) {
                if (_.isEqual(this.acntInfo.slcmChk, 'N')) {
                    this.showTcComConfirm(
                        '예금주가 다릅니다. \r\n 그대로 적용하시겠습니까?'
                    ).then((confirm) => {
                        if (!confirm) return false
                        this.acntInfo.slcmChk = 'Y'
                        this.acntInfo.isSlCmYn = '2'
                        this.acntInfo.isSlCmChk = 'Y'
                    })
                }
                this.setData()
            }
        },
        // 현재일자 확인(yyyymmdd)
        getToday() {
            const date = new Date()
            const year = date.getFullYear()
            let month = ('0' + (1 + date.getMonth())).slice(-2)
            let day = ('0' + date.getDate()).slice(-2)

            return year + month + day
        },
    },
    watch: {
        etcAddInfoData1: {
            handler: function (values) {
                if (_.isEqual(values['dealcoClCd2'], '3')) {
                    this.isSlcmAcnt = false
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },

        basPrmDealcoDtlVo: {
            handler: function (values) {
                let detailData = this.acntInfo // 데이터 Set

                _.forEach(Object.keys(detailData), (key) => {
                    if (!_.isEmpty(key)) {
                        // 기본정보셋팅
                        let value = values[key]
                        //let isValue = false
                        //let currentDate = moment(new Date()).format('YYYY-MM-DD')
                        if (
                            _.isEqual(value, undefined) ||
                            _.isEqual(value, null) ||
                            _.isEqual(value, '')
                        ) {
                            if (typeof detailData[key] === 'object') {
                                value = []
                            } else {
                                value = ''
                            }
                        } else {
                            //isValue = true
                        }
                        // 필터정보셋팅
                        detailData[key] = value
                    }
                })

                let param = { ...detailData }
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },

        basPrmDealcoImagAccList1: {
            handler: function (values) {
                if (!_.isEmpty(values) && this.isGridAcntInfo1) {
                    clearTimeout(this.clickStatus)
                    this.clickStatus = setTimeout(() => {
                        this.initAcntInfo()
                    }, 2000)
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
