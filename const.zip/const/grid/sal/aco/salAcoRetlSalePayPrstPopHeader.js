import { ValueType } from 'realgrid'

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, //조직트리
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //영업센터코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //영업센터
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, //정산처
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT, //정산처명
        },
        {
            fieldName: 'dealcoClNm1',
            dataType: ValueType.TEXT, //거래처구분
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, //수납일
        },
        {
            fieldName: 'payTypCd',
            dataType: ValueType.TEXT, //수납유형
        },
        {
            fieldName: 'opStCd',
            dataType: ValueType.TEXT, //수납상태
        },
        {
            fieldName: 'payClCd',
            dataType: ValueType.TEXT, //수납구분
        },
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, //수납관리번호
        },
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, //수납변경순번
        },
        {
            fieldName: 'payMthdCd',
            dataType: ValueType.TEXT, //수납방법
        },
        {
            fieldName: 'payAmt',
            dataType: ValueType.NUMBER, //수납금액
        },
        {
            fieldName: 'ediYn',
            dataType: ValueType.TEXT, //EDI사용여부
        },
        {
            fieldName: 'cardCoCd',
            dataType: ValueType.TEXT, //카드사
        },
        {
            fieldName: 'cardAprvNo',
            dataType: ValueType.TEXT, //카드승인번호
        },
        {
            fieldName: 'cardAprvDtm',
            dataType: ValueType.TEXT, //카드승인일
        },
        {
            fieldName: 'svcMgmtNums',
            dataType: ValueType.TEXT, //서비스관리번호
        },
        {
            fieldName: 'prodSaleNos',
            dataType: ValueType.TEXT, //일반상품판매번호
        },
        {
            fieldName: 'iotSvcMgmtNum',
            dataType: ValueType.TEXT, //IOT서비스관리번호
        },
        {
            fieldName: 'webOrdNo',
            dataType: ValueType.TEXT, //웹주문번호
        },
    ],
    columns: [
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',

            styles: {
                textAlignment: 'center',
            },
            header: '매장코드',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업센터코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업센터',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처',
                showTooltip: false,
            },
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처명',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoClNm1',
            fieldName: 'dealcoClNm1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납일',
                showTooltip: false,
            },
        },
        {
            name: 'payTypCd',
            fieldName: 'payTypCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납유형',
                showTooltip: false,
            },
        },
        {
            name: 'opStCd',
            fieldName: 'opStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납상태',
                showTooltip: false,
            },
        },
        {
            name: 'payClCd',
            fieldName: 'payClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납구분',
                showTooltip: false,
            },
        },
        {
            name: 'saleMgmtNo',
            fieldName: 'saleMgmtNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납변경순번',
                showTooltip: false,
            },
        },
        {
            name: 'payMthdCd',
            fieldName: 'payMthdCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납방법',
                showTooltip: false,
            },
        },
        {
            name: 'payAmt',
            fieldName: 'payAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '수납금액',
                showTooltip: false,
            },
        },
        {
            name: 'ediYn',
            fieldName: 'ediYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'EDI사용여부',
                showTooltip: false,
            },
        },
        {
            name: 'cardCoCd',
            fieldName: 'cardCoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '카드사',
                showTooltip: false,
            },
        },
        {
            name: 'cardAprvNo',
            fieldName: 'cardAprvNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '카드승인번호',
                showTooltip: false,
            },
        },
        {
            name: 'cardAprvDtm',
            fieldName: 'cardAprvDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '카드승인일',
                showTooltip: false,
            },
        },
        {
            name: 'svcMgmtNums',
            fieldName: 'svcMgmtNums',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'prodSaleNos',
            fieldName: 'prodSaleNos',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일반상품판매번호',
                showTooltip: false,
            },
        },
        {
            name: 'iotSvcMgmtNum',
            fieldName: 'iotSvcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'IOT서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'webOrdNo',
            fieldName: 'webOrdNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '웹주문번호',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, //조직트리
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //영업센터코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //영업센터
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, //정산처
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT, //정산처명
        },
        {
            fieldName: 'dealcoClNm1',
            dataType: ValueType.TEXT, //거래처구분
        },
        {
            fieldName: 'saleClNm',
            dataType: ValueType.TEXT, //판매형태
        },
        {
            fieldName: 'opStCd',
            dataType: ValueType.TEXT, //수납상태
        },
        {
            fieldName: 'saleChgHstClNm',
            dataType: ValueType.TEXT, //판매변경이력
        },
        {
            fieldName: 'saleChgDtm',
            dataType: ValueType.TEXT, //매출일
        },
        {
            fieldName: 'cashAmt',
            dataType: ValueType.NUMBER, //수납대상금액
        },
        {
            fieldName: 'saleDtm',
            dataType: ValueType.TEXT, //개통일시
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, //판매관리번호
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT, //판매변경순번
        },
        {
            fieldName: 'cntrctMgmtNum',
            dataType: ValueType.TEXT, //계약관리번호
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, //서비스관리번호
        },
        {
            fieldName: 'custNm',
            dataType: ValueType.TEXT, //고객명
        },
        {
            fieldName: 'svcNum',
            dataType: ValueType.TEXT, //개통번호
        },
        {
            fieldName: 'saleDtlTypNm',
            dataType: ValueType.TEXT, //판매유형상세
        },
    ],
    columns: [
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',

            styles: {
                textAlignment: 'center',
            },
            header: '매장코드',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업센터코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업센터',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처',
                showTooltip: false,
            },
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처명',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoClNm1',
            fieldName: 'dealcoClNm1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
        },
        {
            name: 'saleClNm',
            fieldName: 'saleClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매형태',
                showTooltip: false,
            },
        },
        {
            name: 'opStCd',
            fieldName: 'opStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납상태',
                showTooltip: false,
            },
        },
        {
            name: 'saleChgHstClNm',
            fieldName: 'saleChgHstClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매변경이력',
                showTooltip: false,
            },
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매출일',
                showTooltip: false,
            },
        },
        {
            name: 'cashAmt',
            fieldName: 'cashAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '수납대상금액',
                showTooltip: false,
            },
        },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통일시',
                showTooltip: false,
            },
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'gnrlSaleChgSeq',
            fieldName: 'gnrlSaleChgSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매변경순번',
                showTooltip: false,
            },
        },
        {
            name: 'cntrctMgmtNum',
            fieldName: 'cntrctMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '계약관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '고객명',
                showTooltip: false,
            },
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통번호',
                showTooltip: false,
            },
        },
        {
            name: 'saleDtlTypNm',
            fieldName: 'saleDtlTypNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매유형상세',
                showTooltip: false,
            },
        },
    ],
}
