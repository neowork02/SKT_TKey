<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccPacEdiAccMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <AccSearchField
        ref="accSearchField"
        :offset="[
            'btn-right-reset',
            'btn-right-view',
            { slotSearch: 'selectedMenu' },
            '!search-patmentDt-payDt',
            'search-orgCd',
            '!search-accDealcoCd',
            '!search-cardCoCd',
        ]"
        :initValue="initValue"
        :popupParamCardCoCd="popupParamCardCoCd"
        :popupParamOrgCd="popupParamOrgCd"
        :popupParamDealcoCd="popupParamDealcoCd"
        @reset="resetForm"
        @view="viewForm"
        @changeOrgCd="changeOrgCd"
        @changePatmentDtPayDt="changePatmentDtPayDt"
    >
        <template slot="selectedMenu" slot-scope="slotProps">
            <div class="formitem" :class="`div${slotProps.divideCellCount}`">
                <TCComComboBox
                    itemText="label"
                    itemValue="value"
                    :itemList="tabList"
                    labelName="조회구분"
                    v-model="activeTabIdx"
                ></TCComComboBox>
            </div>
        </template>
    </AccSearchField>
</template>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import { getTodayDate, getCalcDays, convertDate } from '@/utils/accUtil'

import AccSearchField from '@/components/biz/common/acc/AccSearchField'

import { distanceDate } from '@/utils/accUtil'

export default {
    name: 'AccPacEdiDepositDetailSearch',
    mixins: [CommonMixin, accMixin],
    components: { AccSearchField },
    props: {
        curTabIdx: {
            default: 0,
        },

        tabInfo: {
            default: () => ({}),
        },

        query: {
            default: () => ({}),
        },

        dtlInfo: {
            default: () => ({}),
        },
    },
    data() {
        const dateFormat = 'YYYY-MM-DD'

        return {
            initValue: {
                patmentDtPayDt: [
                    getTodayDate(dateFormat),
                    getCalcDays('today', { count: 2, per: 'days' }, dateFormat),
                ],
                patmentDtPayDtSel: 'patmentDt',
                pageSize: 15,
                pageNum: 1,
            },
            popupParamOrgCd: {
                basMth: '',
            },
            popupParamDealcoCd: {},
            popupParamCardCoCd: {
                commCdId: 'ZBAS_C_00050',
            },

            tabList: [],
        }
    },

    computed: {
        activeTabIdx: {
            get() {
                return this.curTabIdx
            },

            set(v) {
                this.$emit('update:curTabIdx', v)
            },
        },
    },

    created() {
        this.initPage()
    },

    activated() {},

    methods: {
        initPage() {
            this.tabList = this.tabInfo.label.map((arr, idx) => ({
                value: idx,
                label: arr,
            }))
        },

        resetForm(query) {
            this.$emit('reset', query)
        },

        async viewForm(query) {
            if (!query.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }

            if (distanceDate(query.payStaDtm, query.payEndDtm) < -31) {
                if (
                    !(await this.showTcComConfirm(
                        '조회기간이 31일을 초과합니다. \n과도하게 많은 데이타가 조회될 수 있습니다.\n계속 하시겠습니까?'
                    ))
                ) {
                    return this.showTcComAlert('조회가 취소되었습니다.')
                }
            }

            if (query.patmentDtPayDtSel == 'patmentDt') {
                query.guBun = 'PAY_DTM'
            } else {
                query.guBun = 'PAY_DT'
            }

            query.guBun2 = 'SEARCH'
            query.orgId = query.orgCd

            this.$emit('update:dtlInfo', {})
            this.$emit('view', query)
        },

        changeOrgCd(query) {
            const { orgCd, orgNm, orgLvl } = query

            this.popupParamDealcoCd.orgLvl = orgLvl
            this.popupParamDealcoCd.orgCd = orgCd
            this.popupParamDealcoCd.orgNm = orgNm

            this.popupParamOrgCd.orgCd = orgCd
            this.popupParamOrgCd.orgNm = orgNm
        },

        changePatmentDtPayDt(date) {
            const pickMonth = convertDate(date[1], 'YYYYMM')
            this.popupParamOrgCd.basMth = pickMonth
            this.popupParamDealcoCd.basDay = pickMonth
        },

        getQuery() {
            return this.accSearchField.getQuery()
        },

        setQuery(query) {
            this.accSearchField.setQuery(query)
        },
    },
}
</script>
