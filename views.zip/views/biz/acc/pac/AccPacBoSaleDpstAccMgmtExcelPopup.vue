<template>
    <TCComDialog :dialogShow.sync="activeOpenColor" size="1600px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">BO 매출/입금 정산관리</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- SubTit + BTN Right 정렬 -->
                    <div class="stitHead pop">
                        <h4 class="subTit">엑셀입력</h4>
                        <span class="stitBtnRef2">
                            <TCComButton eClass="btn_ty01" @click="onReset"
                                >초기화</TCComButton
                            >
                            <TCComButton eClass="btn_ty01" @click="onSave"
                                >저장</TCComButton
                            >
                            <TCComButton eClass="btn_ty01" @click="onClose"
                                >닫기</TCComButton
                            >
                        </span>
                    </div>
                    <!-- //SubTit + BTN Right 정렬-->

                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div2">
                                <TCComFileInput
                                    v-model="selectFile"
                                    labelName="파일선택"
                                    @change="onChangeExcelFile"
                                ></TCComFileInput>
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 :오른쪽 정렬 버튼 영역 -->
                            <div class="formitem div2">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_save"
                                            labelName="양식다운로드"
                                            @click="excelTemplateDown"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 1-2 :오른쪽 정렬 버튼 영역 -->
                        </div>
                        <!-- //Search_line 1 -->
                    </div>
                    <!-- //Search_div -->
                    <p class="infoTxt">
                        <span class="color-red">
                            양식 다운로드 버튼을 클릭하여 받으신 양식으로 입력
                            가능합니다.
                        </span>
                    </p>

                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="popGridHeader1"
                            ref="popGridHeader1"
                            :gridObj="popGridObj"
                            gridTitle="엑셀입력"
                        />
                        <TCRealGrid
                            id="popGrid1"
                            ref="popGrid1"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>
                    <!-- //gridWrap -->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
// import _ from 'lodash'
// import { CommonUtil } from '@/utils'
import attachApi from '@/api/common/attachedFile'
import CommonMixin from '@/mixins'
import pacApi from '@/api/biz/acc/pac'
import { AccUtil } from '@/views/biz/acc'
import { AccExcelUpload } from '@/views/biz/acc'
import { GRID_HEADER } from '@/const/grid/acc/pac/accPacBoSaleDpstAccMgmtExcelPopupGrid'

export default {
    name: 'AccPacBoSaleDpstAccMgmtExcelPopup',
    title: 'BO 매출/입금 정산관리 엑셀업로드 팝업',
    mixins: [CommonMixin],
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list: [],
            selectFile: null,
            popGridObj: {},
            popGridHeaderObj: {},
            searchParams: {
                searchPageType: 'PG-EXCEL-POPUP',
                checkedPgRows: [],
            },
            excelUp: {
                // 엑셀업로드 필수체크 컬럼 세팅
                required: {
                    dealClNm: '거래상태',
                    caDt: '승인일',
                    aprvNo: '승인번호',
                    aprvAmt: '거래금액',
                    cmms: '수수료',
                    dpstSchdAmt: '정산(예정)금액',
                    joinbrDealNo: '주문번호',
                    ordProd: '상품명',
                    ordrNm: '구매자',
                },
            },
        }
    },
    computed: {
        activeOpenColor: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        console.log('Excel Upload Popup')
        this.popGridObj = this.$refs.popGrid1
        this.popGridObj.setRows(this.list)
        this.popGridHeaderObj = this.$refs.popGridHeader1
        this.popGridObj.setGridState(false)
    },
    methods: {
        onReset() {
            console.log('초기화 함수호출')
            // CommonUtil.clearPage(this.$router) // 초기화 함수
            this.selectFile = ''
            this.popGridObj.setRows([])
        },
        onClose() {
            // 부모 함수 실행 후 팝업 닫기
            this.$parent.onSearch()
            this.activeOpenColor = false
        },
        async onSave() {
            if (this.list.length == 0) {
                this.showTcComAlert('저장할 데이터가 없습니다.')
                return
            }

            var saveLength = 0
            for (var i = 0; i < this.list.length; i++) {
                if (AccUtil.isEmpty(this.list.errMsg)) {
                    saveLength++
                }
            }

            if (saveLength == 0) {
                this.showTcComAlert(
                    '저장할 데이터가 없습니다.(오류사항이 있으면 저장할 수 없습니다.)'
                )
                return
            }

            this.searchParams.checkedPgRows = this.list

            await pacApi
                .saveAccPacBoSaleDpstAccMgmtList(this.searchParams)
                .then((res) => {
                    console.log(res)
                    if (res.resultCode == 'SUCCESS') {
                        this.showTcComAlert('저장되었습니다.')
                        this.onReset()
                    } else if (res.resultCode == 'FAIL') {
                        this.showTcComAlert(res.resultMessage)
                    }
                })
        },
        excelTemplateDown() {
            attachApi.downloadSampleFile('402')
        },
        /* 판매수수료조정 Tab의 엑셀업로드 파일 선택시 실행 */
        onChangeExcelFile(f) {
            AccExcelUpload.onChange(
                f,
                this.view.columns,
                function () {},
                this.callbackExcelUpload
            )
        },
        callbackExcelUpload(list) {
            this.list = []

            // validate체크하여 정상인 경우 list에 push, 아닌 경우 list2에 push한다.
            if (list) {
                for (var i = 0; i < list.length; i++) {
                    list[i].errMsg = ''

                    // 필수항목 체크
                    var checkRequired = AccExcelUpload.getCheckRequired(
                        list[i],
                        this.excelUp.required
                    )
                    if (checkRequired.isPass == false) {
                        list[i].errMsg = checkRequired.errMsg
                    }

                    // 숫자 컬럼인 경우, 콤마(,)를 제거한다.
                    list[i].aprvAmt = AccUtil.emptyCommaByNumber(
                        list[i].aprvAmt
                    )
                    list[i].cmms = AccUtil.emptyCommaByNumber(list[i].cmms)
                    list[i].dpstSchdAmt = AccUtil.emptyCommaByNumber(
                        list[i].dpstSchdAmt
                    )
                    list[i].cmmsFree = AccUtil.emptyCommaByNumber(
                        list[i].cmmsFree
                    )

                    // 숫자 체크
                    if (
                        AccUtil.isEmpty(list[i].errMsg) &&
                        isNaN(list[i].aprvAmt)
                    ) {
                        list[i].errMsg = '거래금액은 숫자만 입력해 주세요.'
                    }
                    if (
                        AccUtil.isEmpty(list[i].errMsg) &&
                        isNaN(list[i].cmms)
                    ) {
                        list[i].errMsg = '수수료는 숫자만 입력해 주세요.'
                    }
                    if (
                        AccUtil.isEmpty(list[i].errMsg) &&
                        isNaN(list[i].dpstSchdAmt)
                    ) {
                        list[i].errMsg =
                            '정산(예정)금액은 숫자만 입력해 주세요.'
                    }
                    if (
                        AccUtil.isEmpty(list[i].errMsg) &&
                        isNaN(list[i].cmmsFree)
                    ) {
                        list[i].errMsg = '무이자수수료는 숫자만 입력해 주세요.'
                    }

                    // 거래상태 컬럼의 값이 '승인' or '취소'로 입력되지 않았을 경우
                    if (
                        AccUtil.isEmpty(list[i].errMsg) &&
                        !AccUtil.isEmpty(list[i].dealClNm) &&
                        '/승인/취소/'.indexOf(list[i].dealClNm) == -1
                    ) {
                        list[i].errMsg =
                            '거래상태(승인/취소) 컬럼을 확인해 주세요.'
                    }

                    // 입력값이 정상인 경우는 checkedRows에 push한다.
                    this.list.push(list[i])
                }

                // 그리드에 목록을 출력한다.
                this.popGridObj.setRows(this.list)
            }
        },
    },
}
</script>
