import { ValueType } from 'realgrid'

export const DisActProdInsPopupGRID_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'qty',
            dataType: ValueType.NUMBER, //수량
        },
        {
            fieldName: 'barYn',
            dataType: ValueType.TEXT, //스캔여부
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'barCdTyp',
            dataType: ValueType.TEXT, //바코드타입
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mdlClCd',
            dataType: ValueType.TEXT, //단말기구분코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'mdlClNm',
            dataType: ValueType.TEXT, //단말기구분명
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직명
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'hldPlcId',
            dataType: ValueType.TEXT, //보유처코드
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, //보뮤처명
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            width: '100',
            editable: false,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            width: '150',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '120',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            editable: false,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
            },
            header: {
                text: '색상',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            editable: true,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량여부',
                showTooltip: false,
            },
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고상태',
                showTooltip: false,
            },
        },
        {
            name: 'qty',
            fieldName: 'qty',
            type: 'data',
            width: '80',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'barYn',
            fieldName: 'barYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '스캔여부',
                showTooltip: false,
            },
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            visible: false,
            type: 'data',
        },
        {
            name: 'barCdTyp',
            fieldName: 'barCdTyp',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            visible: false,
            type: 'data',
        },
        {
            name: 'mdlClCd',
            fieldName: 'mdlClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'mdlClNm',
            fieldName: 'mdlClNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'hldPlcId',
            fieldName: 'hldPlcId',
            visible: false,
            type: 'data',
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            visible: false,
            type: 'data',
        },
    ],
}
