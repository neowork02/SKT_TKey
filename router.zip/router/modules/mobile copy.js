import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

const routes = [
    {
        path: '/mobile',
        component: () =>
            import('@/views/mobile/home/MblMain') /* 모바일-메인 */,
    },
    {
        path: '/mobile/home/MblMenu',
        component: () =>
            import('@/views/mobile/home/MblMenu') /* 모바일-메뉴 */,
    },
    {
        path: '/mobile/home/MblMyMenu',
        component: () =>
            import('@/views/mobile/home/MblMyMenu') /* 나의메뉴설정 */,
    },
    {
        path: '/mobile/home/MblErrorPage',
        component: () =>
            import('@/views/mobile/home/MblErrorPage') /* 에러페이지 */,
    },
    {
        path: '/mobile/home/MblQuickSearch',
        component: () =>
            import('@/views/mobile/home/MblQuickSearch') /* 퀵서치 팝업 */,
    },
    {
        path: '/mobile/dis/MblDis01',
        component: () =>
            import('@/views/mobile/dis/MblDis01') /* 서브-SK네트웍스 입고 */,
    },
    {
        path: '/mobile/dis/MblDis02',
        component: () =>
            import(
                '@/views/mobile/dis/MblDis02'
            ) /* 서브-SK네트웍스 입고검색 */,
    },
    {
        path: '/mobile/bas/bbs/MblBasBbs01',
        component: () =>
            import(
                '@/views/mobile/bas/bbs/MblBasBbs01'
            ) /* 서브-공지사항(View) */,
    },
    {
        path: '/mobile/bas/bbs/MblBasBbs02',
        component: () =>
            import(
                '@/views/mobile/bas/bbs/MblBasBbs02'
            ) /* 서브-공지사항 리스트1 */,
    },
    {
        path: '/mobile/bas/bbs/MblBasBbs03',
        component: () =>
            import(
                '@/views/mobile/bas/bbs/MblBasBbs03'
            ) /* 서브-공지사항 리스트2 */,
    },
    {
        path: '/mobile/bas/bbs/MblBasBbs04',
        component: () =>
            import('@/views/mobile/bas/bbs/MblBasBbs04') /* 서브-글쓰기 */,
    },
    {
        path: '/mobile/bas/bbs/MblBasBbs05',
        component: () =>
            import('@/views/mobile/bas/bbs/MblBasBbs05') /* 서브-글수정 */,
    },
]

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch((err) => {
        if (err.name !== 'NavigationDuplicated') throw err
    })
}

export default routes
