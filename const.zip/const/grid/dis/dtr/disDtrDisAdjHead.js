import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'procDt', // 개통일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNm', // 고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNum', // 개통번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd', // 판매레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm', // 판매레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd1', // 판매레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm1', // 판매레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd2', // 판매레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm2', // 판매레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgCd3', // 판매레벨3조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inLvOrgNm3', // 판매레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgCd', // 판매조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgNm', // 판매조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoShopCd', // 거래처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd', // 판매처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoNm', // 판매처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleShopCd', // 판매처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd', // 상품구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm', // 상품구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClCd', // 단말기구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClNm', // 단말기구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd', // 제조사코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm', // 제조사명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 상품코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', // 색상코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum', // 일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoClCd1', // 이동전거래처구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealCoClNm', // 이동전거래처구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoCd', // 이동전보유처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoNm', // 이동전보유처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outShopCd', // 이동전보유처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd', // 이동전레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm', // 이동전레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd1', // 이동전레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm1', // 이동전레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd2', // 이동전레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm2', // 이동전레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgCd3', // 이동전레벨3조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outLvOrgNm3', // 이동전레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOrgCd', // 이동전조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOrgNm', // 이동전조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoClCd1', // 이동후거래처구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealCoClNm', // 이동후거래처구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoCd', // 이동후보유처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoNm', // 이동후보유처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inShopCd', // 이동후보유처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm', // 처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outFixDt', // 출고일자
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'procDt',
            fieldName: 'procDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '개통일자',
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '고객명',
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '개통번호',
        },
        {
            name: 'inOrgCd',
            fieldName: 'inOrgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '조직',
        },
        {
            name: 'inOrgNm',
            fieldName: 'inOrgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처코드',
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품구분',
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '단말기구분',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '제조사',
        },

        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '색상',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '일련번호',
        },
        {
            name: 'outDealCoClNm',
            fieldName: 'outDealCoClNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '이동전거래처구분',
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '이동전보유처',
        },
        {
            name: 'inDealCoClNm',
            fieldName: 'inDealCoClNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '이동후거래처구분',
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '이동후보유처',
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '처리자',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '처리일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
    ],
}
