import store from '@/store'
import _ from 'lodash'

export default (router) => {
    const menuInfo = store.getters['menu/menuInfo']
    const addRoutePages = []
    const regRoutes = router.getRoutes()

    menuInfo.forEach((menu) => {
        const menuUrl = menu.menuUrl
        const menuNo = menu.menuNo
        const menuNm = menu.menuNm
        const screenId = menu.screenId
        // const leftMenuYn = menu.topMenuYn
        let chkRoute = false

        // if (!_.isEmpty(menuUrl) && leftMenuYn === 'N') {
        if (!_.isEmpty(menuUrl)) {
            // 메뉴정보가 라우터에 설정이 되어 있는지 체크
            regRoutes.some((regRoute) => {
                if (regRoute.name === menuUrl) {
                    chkRoute = true
                    return true
                }
            })

            if (chkRoute === false) {
                let componentPath = menuUrl
                if (
                    menuUrl.indexOf('/:id') > -1 ||
                    menuUrl.indexOf('/:search') > -1
                ) {
                    componentPath = menuUrl.split('/:')[0] // userManagement/UserManagementDetail
                }
                addRoutePages.push({
                    path: menuUrl,
                    component: () => import(`@/views/biz${componentPath}.vue`),
                    name: menuUrl,
                    meta: {
                        menuNm: menuNm,
                        menuNo: menuNo,
                        screenId: screenId,
                    },
                    // props: true, 라우팅시 속성 의존성을 해제하려면 설정(/:id를 prop로 받을 수 있음)
                })
            }
        }
    })

    addRoutePages.forEach((routePage) => {
        router.addRoute('base', routePage)
    })
}
