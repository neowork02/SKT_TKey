import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'NO',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'rgnCd',
            dataType: ValueType.TEXT, //권역코드
        },
        {
            fieldName: 'rgnNm',
            dataType: ValueType.TEXT, //권역명
        },
        {
            fieldName: 'svcObjCd',
            dataType: ValueType.TEXT, //서비스대상코드
        },
        {
            fieldName: 'svcObjNm',
            dataType: ValueType.TEXT, //서비스대상명
        },
        {
            fieldName: 'sktLdongCd',
            dataType: ValueType.TEXT, //SKT법정동코드
        },
        {
            fieldName: 'ldongCd',
            dataType: ValueType.TEXT, //PS법정동코드
        },
        {
            fieldName: 'ldongNm',
            dataType: ValueType.TEXT, //PS법정동명
        },
        {
            fieldName: 'siDoCd',
            dataType: ValueType.TEXT, //시도코드
        },
        {
            fieldName: 'siDoNm',
            dataType: ValueType.TEXT, //시도명
        },
        {
            fieldName: 'siGunGuCd',
            dataType: ValueType.TEXT, //시군구코드
        },
        {
            fieldName: 'siGunGuNm',
            dataType: ValueType.TEXT, //시군구명
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //오류메세지
        },
        {
            fieldName: 'oldLdongCd',
            dataType: ValueType.TEXT, //이전PS법정동코드
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'NO',
            type: 'data',
            width: '40',
            editable: false,
            styleName: 'center-column',
            numberFormat: '##0',
            header: {
                text: 'No',
            },
        },
        {
            name: 'rgnCd',
            fieldName: 'rgnCd',
            type: 'data',
            width: '80',
            editable: false,
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '권역코드',
            },
        },
        {
            name: 'rgnNm',
            fieldName: 'rgnNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '권역명',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'svcObjCd',
            fieldName: 'svcObjCd',
            type: 'data',
            width: '80',
            editable: false,
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '서비스대상코드',
            },
        },
        {
            name: 'svcObjNm',
            fieldName: 'svcObjNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '서비스대상명',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 2,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'sktLdongCd',
            fieldName: 'sktLdongCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'SKT법정동코드',
            },
        },
        {
            name: 'ldongCd',
            fieldName: 'ldongCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'PS법정동코드',
            },
        },
        {
            name: 'ldongNm',
            fieldName: 'ldongNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'PS법정동명',
            },
        },
        {
            name: 'siDoCd',
            fieldName: 'siDoCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '시도코드',
            },
        },
        {
            name: 'siDoNm',
            fieldName: 'siDoNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '시도명',
            },
        },
        {
            name: 'siGunGuCd',
            fieldName: 'siGunGuCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '시군구코드',
            },
        },
        {
            name: 'siGunGuNm',
            fieldName: 'siGunGuNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '시군구명',
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '200',
            editable: false,
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '오류메시지',
            },
        },
        {
            name: 'oldLdongCd',
            fieldName: 'oldLdongCd',
            type: 'data',
            width: '100',
            visible: false,
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '이전PS법정동코드',
            },
        },
    ],

    //엑셀업로드 그리드용 columns
    columns2: [
        {
            name: 'rgnCd',
            fieldName: 'rgnCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '권역코드',
                showTooltip: false,
            },
        },
        {
            name: 'ldongNm',
            fieldName: 'ldongNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'PS법정동명',
                showTooltip: false,
            },
        },
        {
            name: 'svcObjCd',
            fieldName: 'svcObjCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스대상',
                showTooltip: false,
            },
        },
        {
            name: 'sktLdongCd',
            fieldName: 'sktLdongCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT법정동코드',
                showTooltip: false,
            },
        },
        {
            name: 'ldongCd',
            fieldName: 'ldongCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'PS법정동코드',
                showTooltip: false,
            },
        },
        {
            name: 'siDoNm',
            fieldName: 'siDoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시도명',
                showTooltip: false,
            },
        },
        {
            name: 'siDoCd',
            fieldName: 'siDoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시도코드',
                showTooltip: false,
            },
        },
        {
            name: 'siGunGuNm',
            fieldName: 'siGunGuNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시군구명',
                showTooltip: false,
            },
        },
        {
            name: 'siGunGuCd',
            fieldName: 'siGunGuCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시군구코드',
                showTooltip: false,
            },
        },
    ],
}
