<template>
    <div class="content">
        <h1>상품단말정책업로드</h1>
        <ul class="btn_area top">
            <!-- <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="onDelete"
                    >삭제</TCComButton
                >
            </li> -->
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        v-model="div_search.cal_yymm"
                        labelName="기준월"
                        :objAuth="objAuth"
                        calType="M"
                        @change="onSearch"
                    ></TCComDatePicker>
                </div>
                <div class="formitem div5_1">
                    <TCComComboBox
                        labelName="단말정책"
                        v-model="div_search.cmb_prod_pol"
                        :objAuth="this.objAuth"
                        codeId="ZBAS_C_00470"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        @change="onSearch"
                    ></TCComComboBox>
                </div>
                <div class="formitem div5_2">
                    <TCComInput
                        labelName="모델코드"
                        :objAuth="this.objAuth"
                        :disabled="false"
                        v-model="div_search.edt_prod_cd"
                        @enterKey="onSearch"
                    />
                </div>
                <div class="formitem div5_2">
                    <TCComInput
                        labelName="모델명"
                        :objAuth="this.objAuth"
                        :disabled="false"
                        v-model="div_search.edt_prod_nm"
                        @enterKey="onSearch"
                    />
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCComFileInput
                v-model="files"
                v-show="false"
                ref="fileExcelTemplate"
                @change="onFilesChange"
            ></TCComFileInput>
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="상품 단말정책 등록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isExcelup="true"
                :isPageCnt="true"
                :isNextPage="false"
                @excelUploadBtn="onExcelUpload"
                @excelDownBtn="onExcelDown"
            >
                <!--TCRealGridHeader 영역에 페이지 추가버튼_오른쪽 -->
                <template #gridBtnArea>
                    <TCComButton
                        :Vuetify="false"
                        eClass="btn_noline btn_ty04"
                        eAttr="ico_basic"
                        labelName="양식다운로드"
                        :objAuth="objAuth"
                        @click="onExcelTemplateDown"
                    />
                </template>
                <!-- //TCRealGridHeader 영역에 페이지 추가버튼_오른쪽 -->
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="onSearch"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<style></style>

<script>
// import { CommonGrid, FileUtil } from '@/utils'
import { CommonGrid } from '@/utils'
// import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
import attachedFileApi from '@/api/common/attachedFile'
import moment from 'moment'
// import _ from 'lodash'
// import * as XLSX from 'xlsx'
import { HEADER } from '@/const/grid/bas/pdm/basPdmProdEqpPolicyRgstHeader'
import API from '@/api/biz/bas/pdm/basPdmProdEqpPolicyRgst'
import CommonMixin from '@/mixins'

export default {
    name: 'BasPdmProdEqpPolicyRgst',
    components: {},
    mixins: [CommonMixin],

    data() {
        return {
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            rowCnt: 15,

            //각각 엘리먼트 컴포넌트 v-model
            div_search: {
                cal_yymm: moment(new Date()).format('YYYY-MM'),
                cmb_prod_pol: '', //상품구분코드
                edt_prod_cd: '',
                edt_prod_nm: '',
            },
            objAuth: {},
            selectedJsonData: {},
            selectedRow: '',
            prod_bar_cd_mgmt: [],
            files: null,
        }
    },

    created() {
        this.init()
        console.log('this.$route Detail: ', this.$route)
        // this.searchParam = this.$route.params.search
    },

    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        // 삭제버튼 보이기 (임시 기존: =='P13'으로 바꿔야함)

        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        // this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState(true)
        // 양식 샘플 데이터 설정
        // this.gridObj.dataProvider.setRows(
        //     this.basPdmProdEqpPolicyRgstTemplateData
        // )
        // this.gridObj.gridView.columnByName('allLenCnt').editable = false
        // this.gridObj.gridView.columnByName('mdlLenCnt').editable = false
        // this.gridObj.gridView.columnByName('colorLenCnt').editable = false
        // this.gridObj.gridView.columnByName('serNumLenCnt').editable = false

        this.gridObj.gridView.onCellEdited = (
            grid,
            itemIndex,
            dataRow,
            field
        ) => {
            // var column = grid.columnByField('accDealcoNm')
            this.gridObj.gridView.commit()
            const getData = grid.getValue(itemIndex, field)
            console.log('getData', getData)

            this.selectedJsonData =
                this.gridObj.dataProvider.getJsonRow(dataRow)
            console.log('selectedJsonData', this.selectedJsonData)
        }

        // 싱글클릭 시 저장데이터 SET
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            this.selectedJsonData = this.gridObj.dataProvider.getJsonRow(
                clickData.dataRow
            )
            this.selectedRow = clickData.dataRow
            console.log('saveparam set', this.selectedJsonData)
            console.log('clickData.dataRow', clickData.dataRow)
        }
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.gridSetData()
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
            this.getProdPolList(1)
        },

        //조회 버튼 이벤트
        onSearch: function () {
            this.gridData.totalPage = 0
            this.getProdPolList(1)
        },

        getProdPolList(pageNum) {
            let paramObj = {
                strdDt: this.div_search.cal_yymm.replace('-', ''), // 기준월
                prodPolNm: this.div_search.cmb_prod_pol, // 단말정책
                prodCd: this.div_search.edt_prod_cd, // 모델코드
                prodNm: this.div_search.edt_prod_nm, // 모델명
            }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt

            API.getProdPolList(paramObj).then((result) => {
                console.log('resultData : ', result)
                this.gridObj.setRows(result.gridList)
                this.gridData = this.gridSetData() //초기화
                this.isShowNext(result.pagingDto)
                this.gridData.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },
        /* 다음페이지 노출여부 */
        isShowNext(pageInfo) {
            this.showNext =
                pageInfo.totalDataCnt === pageInfo.pageSize ? true : false
        },

        //저장 버튼 이벤트
        onSave: function () {
            // let saveParam = {}
            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (rowData.length === 0) {
                // msgTxt.MSG_00071
                this.openAlert('처리할 대상이 없습니다.') // '처리할 대상이 없습니다.'
                return
            }
            API.saveProdPolList(rowData).then((result) => {
                console.log('result : ', result)
                if (result == 1) {
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    // 매핑정보 재조회
                    this.onSearch()
                } else {
                    this.showTcComAlert(result.message)
                }
            })
        },

        //삭제 버튼 이벤트
        // onDelete: function () {
        // let delParam = {
        //     prodClCd: this.selectedJsonData.prodClCd
        //         ? this.selectedJsonData.prodClCd
        //         : '',
        //     barCdTypCd: this.selectedJsonData.barCdTypCd
        //         ? this.selectedJsonData.barCdTypCd
        //         : '',
        //     allLenCnt: this.selectedJsonData.allLenCnt
        //         ? this.selectedJsonData.allLenCnt
        //         : '',
        // }
        // // this.gridObj.setRows(M_DATA)
        // API.delProductBarcodeList(delParam).then((resultData) => {
        //     console.log('resultData : ', resultData.length)
        // })
        // },

        // 초기화
        onResetPage() {
            this.fvFile = 0
            ;(this.div_search = {
                cal_yymm: moment(new Date()).format('YYYY-MM'),
                cmb_prod_pol: '', //상품구분코드
                edt_prod_cd: '',
                edt_prod_nm: '',
            }),
                this.init()
            this.gridData = this.gridSetData()
            this.gridObj.dataProvider.clearRows()
        },

        // 파일선택 버튼 이벤트
        onFilesChange(files) {
            // this.init(false)
            this.excelUploadFile(files)
        },
        excelUploadFile(files) {
            this.gridObj.gridInit()

            if (files == null) return
            const form = new FormData()
            form.append('files', files)
            API.parseExcel(form).then((res) => {
                if (res.length == 0) {
                    this.showTcComAlert(
                        '업로드 문서에 처리 할 데이터가 없습니다.\n업로드 문서를 확인하시기 바랍니다.'
                    )
                } else if (res.length > 3000) {
                    this.showTcComAlert(
                        '1회당 업로드 데이터는 3000건까지 가능합니다.'
                    )
                } else {
                    this.gridObj.setRows(res)
                }
            })
        },
        // excelUploadFile(files) {
        //     const f = files
        //     if (!_.isUndefined(f) && !_.isNull(f)) {
        //         const reader = new FileReader()

        //         reader.onload = (e) => {
        //             const data = e.target.result
        //             // Array Buffer인 경우 base64로 변환 처리
        //             const arr = FileUtil.arrayBufferFixdata(data)
        //             const workbook = XLSX.read(FileUtil.encodeBase64(arr), {
        //                 type: 'base64',
        //                 cellText: true,
        //                 cellDates: true,
        //             })
        //             // 워크북 처리(1줄 헤더 포함 처리)
        //             this.processWorkbook(workbook)
        //         }
        //         reader.readAsArrayBuffer(f)
        //     }
        // },
        // // 워크북 처리(1줄 헤더 포함 처리)
        // processWorkbook(wb) {
        //     const output = FileUtil.excelTojson(wb)
        //     const sheetNames = Object.keys(output)

        //     if (sheetNames.length) {
        //         const colsObj = output[sheetNames][0]
        //         if (colsObj) {
        //             const data = output[sheetNames]
        //             console.log('processWorkbook: ', data)
        //             if (CommonUtil.checkJsonStrDocSecurity(data)) {
        //                 this.showTcComAlert(
        //                     '문서보안 엑셀 파일입니다.\n확인 후 다시 업로드해주세요.'
        //                 )
        //                 return
        //             }

        //             const mappedData = data.map((item) => {
        //                 return {
        //                     strdDt: item['TELP_기준일자'],
        //                     prodNm: item['TELP_모델'],
        //                     telpNm: item['TELP_명칭'],
        //                     mfactNm: item['TELP_제조사'],
        //                     prodChrticNm1: item['TELP_상품구분1'],
        //                     prodPolNm: item['TELP_단말정책'],
        //                     prodChrticNm3: item['TELP_상품구분3'],
        //                     prodDtlNm: item['TELP_세부모델'],
        //                     mstProdNm: item['TELP_대표모델'],
        //                     mktgDt: item['TELP_출시일자'],
        //                     petNm: item['TELP_펫네임'],
        //                     endDt: item['TELP_단종일자'],
        //                     lunarPhaseCd: item['TELP_월령'],
        //                     outAmt: item['TELP_출고가'],
        //                     dstrbYn: item['TELP_유통여부'],
        //                     badExceptYn: item['TELP_부진성제외여부(삭제)'],
        //                     tierNm: item['TELP_TIER'],
        //                     prodCd: item['모델코드'],
        //                     prodPolCd: item['단말정책코드'],
        //                 }
        //             })
        //             this.gridObj.dataProvider.fillJsonData(mappedData, {
        //                 fillMode: 'append',
        //             })
        //         }
        //     }
        // },

        // 엑셀업로드
        onExcelUpload() {
            this.$refs.fileExcelTemplate.clearFileInputValue()
            this.gridObj.dataProvider.clearRows()
            this.$refs.fileExcelTemplate.fileInputClick()
        },

        // 양식다운로드
        onExcelTemplateDown() {
            attachedFileApi.downloadSampleFile('503')
        },

        onExcelDown() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            let paramObj = {
                strdDt: this.div_search.cal_yymm.replace('-', ''), // 기준월
                prodPolNm: this.div_search.cmb_prod_pol, // 단말정책
                prodCd: this.div_search.edt_prod_cd, // 모델코드
                prodNm: this.div_search.edt_prod_nm, // 모델명
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/pdm/prod-eqp-policy-excel',
                paramObj
            )
        },
    },
}
</script>
