<script>
export default {
    name: 'Inputs',
    props: {
        value: { type: String, default: '', required: false },
        readonly: { type: Boolean, default: false, required: false },
        size: { type: Number, default: 30, required: false },
        placeholder: { type: String, default: '', required: false },
        maxlength: { type: Number, default: 30, required: false },
        index: { type: Number, default: 30, required: false },
    },

    data() {
        return {
            dpMountYn: 'N',
            dValue: this.value,
        }
    },
    watch: {
        readonly() {
            if (!this.readonly) {
                this.test()
            } else {
                //
            }
        },
    },

    mounted() {
        if (!this.readonly) {
            this.test()
        } else {
            //
        }
    },
    methods: {
        test() {
            if (this.dpMountYn === 'Y') {
                return
            }

            this.dpMountYn = 'Y'
        },
        EmitInput() {
            this.$emit('input', this.dValue)
        },
    },
}
</script>

<template>
    <div class="">
        <input
            type="text"
            ref="dp"
            class="Inputs"
            autocomplete="off"
            :placeholder="placeholder"
            :readonly="readonly"
            :size="size"
            :index="index"
            :maxlength="maxlength"
            v-model="dValue"
            @input="EmitInput"
        />
    </div>
</template>

<style>
.ui-Inputs .ui-state-default {
    border: 1px solid #ffffff !important;
    background: #ffffff !important;
    font-weight: normal;
    color: #454545;
    text-align: center !important;
}
</style>
