<script>
export default {
    name: 'Check',

    props: {
        value: { type: Array, required: true },
        readonly: { type: Boolean, default: false, required: false },
        index: { type: Number, default: 0, required: false },
        option: {
            type: Array,
            required: true,
        },
    },

    data() {
        return {
            dpMountYn: 'N',
            dValue: this.value,
            chkArr: [],
        }
    },

    watch: {
        readonly() {
            if (!this.readonly) {
                this.test()
            } else {
                //
            }
        },
    },

    mounted() {
        if (!this.readonly) {
            this.test()
        } else {
            //
        }
    },
    methods: {
        test() {
            if (this.dpMountYn === 'Y') {
                return
            }

            this.dpMountYn = 'Y'
        },
        EmitInput() {
            this.$emit('input', this.chkArr)
        },
    },
}
</script>

<template>
    <div>
        <span v-for="item in option" v-bind:key="item.id">
            {{ item.title }}
            <input
                type="checkbox"
                :value="item.value"
                :name="item.name"
                v-model="chkArr"
                @change="EmitInput"
            />
        </span>
    </div>
</template>

<style>
.ui-Inputs .ui-state-default {
    border: 1px solid #ffffff !important;
    background: #ffffff !important;
    font-weight: normal;
    color: #454545;
    text-align: center !important;
}
</style>
