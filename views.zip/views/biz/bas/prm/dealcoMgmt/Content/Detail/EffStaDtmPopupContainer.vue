<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="900px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">거래처유효시작일시변경</p>

                <div class="layerCont">
                    <div class="stitHead">
                        <h4 class="subTit">거래처유효시작일시변경</h4>
                    </div>
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="dealcoCd"
                                    labelName="거래처코드"
                                    :disabled="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComDatePicker
                                    calType="DHM"
                                    v-model="effStaDtm"
                                    :disabled="true"
                                    :eRequired="true"
                                    labelName="기존유효시작일자"
                                    :hourVal.sync="effStaDtmHour"
                                    :minuVal.sync="effStaDtmMin"
                                    :objAuth="objAuth"
                                >
                                    <template #multiFrom>
                                        <div class="col9">
                                            <TCComTextField
                                                v-model="effStaDtmSec"
                                                :disabled="true"
                                                :maxlength="2"
                                                inputRuleType="N"
                                                :objAuth="objAuth"
                                            ></TCComTextField>
                                        </div>
                                        <div class="col0">초</div>
                                    </template>
                                </TCComDatePicker>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComDatePicker
                                    calType="DHM"
                                    v-model="newEffStaDtm"
                                    :eRequired="true"
                                    labelName="변경유효시작일자"
                                    :hourVal.sync="newEffStaDtmHour"
                                    :minuVal.sync="newEffStaDtmMin"
                                    :objAuth="objAuth"
                                >
                                    <template #multiFrom>
                                        <div class="col9">
                                            <TCComTextField
                                                v-model="newEffStaDtmSec"
                                                :maxlength="2"
                                                inputRuleType="N"
                                                :objAuth="objAuth"
                                            ></TCComTextField>
                                        </div>
                                        <div class="col0">초</div>
                                    </template>
                                </TCComDatePicker>
                            </div>
                        </div>
                    </div>

                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            @click="save"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="close"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="close"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dealcoMgmt/helpers'
import _ from 'lodash'

import CommonMixin from '@/mixins'
import { msgTxt } from '@/const/msg.Properties'

import { CommonUtil } from '@/utils'

export default {
    name: 'EffStaDtmPopupContainer',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        //parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            objAuth: {},
            dealcoCd: '', // 거래처코드
            hstSeq: '', // 거래처이력번호
            effStaDtm: '', // 유효시작일시
            effStaDtmHour: '', // 유효시작일시 (시)
            effStaDtmMin: '', // 유효시작일시 (분)
            effStaDtmSec: '', // 유효시작일시 (초)
            newEffStaDtm: '', // 변경유효시작일시
            newEffStaDtmHour: '', // 변경유효시작일시 (시)
            newEffStaDtmMin: '', // 변경유효시작일시 (분)
            newEffStaDtmSec: '', // 변경유효시작일시 (초)
        }
    },
    mounted() {},
    computed: {
        ...serviceComputed,
        hstInfo2_: {
            get() {
                return this.hstInfo2 // 거래처상세정보
            },
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        ...serviceMethods,
        save() {
            if (_.isEmpty(this.effStaDtm)) {
                this.showTcComAlert(
                    msgTxt.MSG_00083.replace(/%s/g, '유효시작일시')
                )
                return
            }
            let newEffStaDtmTime =
                this.appendZero(this.newEffStaDtmHour) +
                this.appendZero(this.newEffStaDtmMin) +
                this.appendZero(this.newEffStaDtmSec)

            let effStaDtmTime =
                this.appendZero(this.effStaDtmHour) +
                this.appendZero(this.effStaDtmMin) +
                this.appendZero(this.effStaDtmSec)

            if (!this.isTimeCheck(newEffStaDtmTime)) {
                this.showTcComAlert('시작시간이 유효하지 않습니다.')
                return
            }

            const newEffStaDtm1 = CommonUtil.onlyNumber(
                this.newEffStaDtm + newEffStaDtmTime
            )
            const effStaDtm1 = CommonUtil.onlyNumber(
                this.effStaDtm + effStaDtmTime
            )
            /*
            if (newEffStaDtm1 - effStaDtm1 < 2) {
                this.showTcComAlert(
                    '변경 유효시작일시는 ' +
                        this.effStaDtm +
                        ' ' +
                        this.effStaDtmHour +
                        ':' +
                        this.effStaDtmMin +
                        ':' +
                        this.effStaDtmSec +
                        '보다 작을 수 없습니다'
                )
                return
            }
*/
            if (newEffStaDtm1 - effStaDtm1 >= 0) {
                this.showTcComAlert(
                    '변경 유효시작일시는 기존 유효시작일시보다 클 수 없습니다.'
                )
                return
            }

            this.showTcComConfirm(
                '변경 정보는 현 시간부터 적용됩니다.\n\n변경하시겠습니까?'
            ).then((confirm) => {
                if (confirm) {
                    this.newEffStaDtmApi()
                }
            })
        },
        closeNewEffStaDtm() {
            this.defaultAssign_({
                key: 'effStaDtmParams',
                value: {},
            })
            this.close()
        },
        close() {
            this.activeOpen = false
        },
        isTimeCheck(time) {
            return /([01][0-9]|2[0-3])[0-5][0-9][0-5][0-9]/g.test(time)
        },
        appendZero(value) {
            if (value.length == 1) {
                return '0' + value
            } else {
                return value
            }
        },
        async newEffStaDtmApi() {
            let searchData = {}
            let newDtm =
                this.newEffStaDtm.replace(/-/g, '') +
                this.newEffStaDtmHour +
                this.newEffStaDtmMin +
                this.newEffStaDtmSec

            searchData.newEffStaDtm = newDtm
            searchData.dealcoCd = this.dealcoCd
            searchData.hstSeq = this.hstSeq

            this.defaultAssign_({
                key: 'effStaDtmParams',
                value: searchData,
            })

            await this.updateEffStaDtm_(searchData).then((resultData) => {
                console.log(resultData)
            })
        },
    },
    watch: {
        hstInfo2_: {
            handler: function (value) {
                if (!_.isEmpty(value)) {
                    this.dealcoCd = value['dealcoCd'] // 거래처코드
                    this.hstSeq = value['hstSeq'] // 거래처이력번호
                    let effStaDtm = value['effStaDtm']
                    this.effStaDtm = effStaDtm.substring(0, 8)
                    this.effStaDtmHour = effStaDtm.substring(8, 10)
                    this.effStaDtmMin = effStaDtm.substring(10, 12)
                    this.effStaDtmSec = effStaDtm.substring(12, 14)
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
