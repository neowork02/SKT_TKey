<template>
    <div class="div4_6 cont1 left">
        <TCRealGridHeader
            id="admAuthGridHeader2"
            ref="admAuthGridHeader2"
            gridTitle=""
            :gridObj="gridObj"
        />
        <TCRealGrid
            id="admAuthGrid2"
            ref="admAuthGrid2"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle2"
        />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/authMgmt/helpers'
import { CommonGrid } from '@/utils'

import { M_HEADER } from '@/const/grid/bas/adm/basAdmAuthMgmtHeader'
import _ from 'lodash'

import CommonMixin from '@/mixins'

export default {
    mixins: [CommonMixin],
    name: 'TableContainer1',
    components: {},
    data() {
        return {
            gridData: this.GridSetData(),
            gridStyle2: {
                height: '478px', //그리드 높이 조절
            },

            copyDialogShow: false,
            setupDialogShow: false,
            isBtn: false,
            gridObj: {},
            gridHeaderObj: {},
            view: M_HEADER,
            layout: [
                'attcClNm',
                'userGrpNm',
                'userGrpCd',
                'userGrpDesc',
                'sortSeq',
            ],
            isCurrentAuth: false,
            isClick: false,
            dtlParam: {
                userId: '',
                delYn: '',
                insDtm: '',
                insUserId: '',
                insUserNm: '',
                userGrpNm: '',
                modDtm: '',
                modUserId: '',
                modUserNm: '',
                sortSeq: '',
                updCnt: '',
                useYn: '',
                userGrpCd: '',
                userGrpDesc: '',
                lvOrgCd: '',
                authTypCd: '',
            },
        }
    },

    async mounted() {
        this.gridObj = this.$refs.admAuthGrid2
        this.gridHeaderObj = this.$refs.admAuthGridHeader2
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.setGridState(false)

        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

        await this.cellClicked()
        await this.cellDblClicked()
    },
    computed: {
        ...serviceComputed,
        resultListAdm1: {
            get() {
                return this.resultListAdm
            },
        },
    },
    methods: {
        ...serviceMethods,
        async init() {
            this.gridData = this.GridSetData()

            await this.defaultAssign_({
                key: 'currentAuth',
                value: [],
            })
        },

        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 30, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        async gridDataSet(grid, clickData) {
            if (typeof clickData.itemIndex !== 'undefined') {
                _.forEach(M_HEADER.fields, (item) => {
                    const key = item.fieldName

                    this.dtlParam[key] = grid.getValue(clickData.itemIndex, key)
                    let data = { ...this.dtlParam }
                    this.defaultAssign_({
                        key: 'newDtlParam',
                        value: data,
                    })
                })
            }
        },
        async initData() {
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
            await this.defaultAssign_({
                key: 'resultListAll',
                value: [],
            })
            this.defaultAssign_({
                key: 'currentAuth',
                value: [],
            })
        },
        async getUserList() {
            let param1 = {
                userGrpCd: this.dtlParam.userGrpCd,
                attcClCd: this.dtlParam.attcClCd,
                userNm: this.searchParams.userNm,
                orgNm: this.searchParams.orgNm,
            }
            await this.getAuthMgmtUserList_({
                param: param1,
            })
        },
        async cellClicked() {
            this.gridObj.gridView.onCellClicked = (grid, clickData) => {
                this.gridDataSet(grid, clickData)
                this.initData()
            }
        },
        async cellDblClicked() {
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                if (typeof clickData.itemIndex !== 'undefined') {
                    if (!this.isBtn) {
                        this.dtlParam = { ...this.newDtlParam }
                        this.dtlParam.type = 'searchUser'
                        this.isCurrentAuth = true
                        this.isBtn = true
                        this.defaultAssign_({
                            key: 'currentAuth',
                            value: this.isCurrentAuth ? this.dtlParam : [],
                        })
                        this.getUserList()
                    }
                }
                this.isBtn = false
            }
        },
    },
    watch: {
        resultListAdm1(val, oldVal) {
            console.log('resultListAdm1 watched: ', val, oldVal, this.pageSize)
            let body = val.map((object, index) => ({
                ...object,
                id: index,
                name: object.userGrpNm,
                rowState: 'readed',
            }))
            this.items = body
            this.gridObj.setRows(val)
        },
    },
}
</script>

<style scoped></style>
