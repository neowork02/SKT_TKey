import { ValueType } from 'realgrid'
export const GRID_HEADER_SWING = {
    fields: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opSaleOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accItmNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mdlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bondPrchsAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            width: '120',
            styles: { textAlignment: 'center' },
            header: { text: '대리점코드' },
        },
        {
            name: 'opSaleOrgNm',
            fieldName: 'opSaleOrgNm',
            type: 'data',
            width: '120',
            header: { text: '대리점명' },
        },
        {
            name: 'svcDt',
            fieldName: 'svcDt',
            type: 'data',
            header: { text: 'Swing개통일' },
            width: '120',
        },
        {
            name: 'accItmNm',
            fieldName: 'accItmNm',
            type: 'data',
            styles: { textAlignment: 'center' },
            header: { text: '정산항목' },
            width: '200',
        },
        {
            name: 'mdlNm',
            fieldName: 'mdlNm',
            type: 'data',
            styles: { textAlignment: 'center' },
            header: { text: '모델명' },
            width: '220',
        },
        {
            name: 'serNo',
            fieldName: 'serNo',
            styles: { textAlignment: 'center' },
            header: { text: '일련번호' },
            groupFooter: {
                expression: 'sum',
                styleName: 'right-column',
            },
            footer: {
                text: '합계',
            },
            width: '130',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            width: '130',
            header: {
                text: '서비스 관리번호',
            },
        },
        {
            name: 'bondPrchsAmt',
            fieldName: 'bondPrchsAmt',
            type: 'data',
            numberFormat: '#,###,###,##0',
            width: '130',
            header: { text: '할부채권금액' },
        },
    ],
}
export const GRID_HEADER_TKEY = {
    fields: [
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mdlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'allotSaleAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            width: '150',
            styles: { textAlignment: 'center' },
            header: { text: '판매번호' },
        },
        {
            name: 'gnrlSaleChgSeq',
            fieldName: 'gnrlSaleChgSeq',
            type: 'data',
            width: '100',
            styles: { textAlignment: 'center' },
            header: { text: '판매순번' },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            width: '100',
            styles: { textAlignment: 'center' },
            header: { text: '대리점코드' },
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            header: { text: '매출일자' },
            width: '120',
        },
        {
            name: 'mdlNm',
            fieldName: 'mdlNm',
            type: 'data',
            styles: { textAlignment: 'center' },
            header: { text: '모델명' },
            width: '300',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            styles: { textAlignment: 'center' },
            header: { text: '일련번호' },
            groupFooter: {
                expression: 'sum',
                styleName: 'right-column',
            },
            footer: {
                text: '합계',
            },
            width: '120',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            width: '130',
            header: {
                text: '서비스 관리번호',
            },
        },
        {
            name: 'allotSaleAmt',
            fieldName: 'allotSaleAmt',
            type: 'data',
            numberFormat: '#,###,###,##0',
            width: '150',
            header: { text: '할부금액' },
        },
    ],
}
