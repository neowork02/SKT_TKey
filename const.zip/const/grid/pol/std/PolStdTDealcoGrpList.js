import { ValueType } from 'realgrid'

export let GRID_PROPERTYINFO = {
    fields: [
        // {
        //     fieldName: 'no', // 순번
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'grpNo', // 그룹번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpNm', // 그룹명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn', // 사용여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'regDealCnt', // 거래처수
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'aplyStaDt', // 적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt', // 적용종료일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 거래처그룹설명비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm', // 처리자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 처리일시
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'grpNo',
            fieldName: 'grpNo',
            type: 'data',
            width: '60',
            header: {
                text: '그룹번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealcoGrpNm',
            fieldName: 'dealcoGrpNm',
            type: 'data',
            width: '160',
            header: {
                text: '그룹명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            width: '60',
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                textReadOnly: true,
            },
        },
        {
            name: 'regDealCnt',
            fieldName: 'regDealCnt',
            type: 'data',
            width: '60',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '거래처수',
                showTooltip: false,
            },
            editor: {
                type: 'number',
                editFormat: '#,##0',
            },
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            type: 'data',
            width: '90',
            header: {
                text: '적용시작일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            /* 날짜형식으로 보여주기 YYYY-MM-DD */
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editable: false,
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            type: 'data',
            width: '90',
            header: {
                text: '적용종료일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            /* 날짜형식으로 보여주기 YYYY-MM-DD */
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editable: false,
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '180',
            header: {
                text: '거래처그룹설명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '80',
            header: {
                text: '처리자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '110',
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],

    layout: [
        'grpNo', // 그룹번호
        'dealcoGrpNm', // 그룹명
        'useYn', // 사용여부
        'regDealCnt', // 거래처건수
        'aplyStaDtm', // 적용시작일자
        'aplyEndDtm', // 적용종료일자
        'rmks', // 거래처그룹설명비고
        'modUserId',
        'modUserNm',
        'modDtm',
    ],
}
