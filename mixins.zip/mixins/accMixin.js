export default {
    name: 'accMixin',
    data() {
        return {}
    },
    computed: {
        accSearchField() {
            return this.$refs.accSearchField
        },

        accGridTable() {
            return this.$refs.accGridTable
        },

        accFileLoader() {
            return this.$refs.accFileLoader
        },

        gridView() {
            return this.$refs.accGridTable.gridView
        },

        dataProvider() {
            return this.$refs.accGridTable.dataProvider
        },
    },
    methods: {},
}
