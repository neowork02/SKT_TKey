import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'erpCase',
            dataType: ValueType.TEXT, //회계처리대상
        },
        {
            fieldName: 'zconfirm',
            dataType: ValueType.TEXT, //확정여부
        },
        {
            fieldName: 'earvTypCd',
            dataType: ValueType.TEXT, //결재구분
        },
        {
            fieldName: 'eravStCd',
            dataType: ValueType.TEXT, //전송상태
        },
        {
            fieldName: 'bu',
            dataType: ValueType.TEXT, //사업부
        },
        {
            fieldName: 'dam',
            dataType: ValueType.TEXT, //사업담당
        },
        {
            fieldName: 'sen',
            dataType: ValueType.TEXT, //사업센터
        },
        {
            fieldName: 'pt',
            dataType: ValueType.TEXT, // 파트
        },
        {
            fieldName: 'dealCoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'dealCoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'drftrNm',
            dataType: ValueType.TEXT, //요청자
        },
        {
            fieldName: 'drftrId',
            dataType: ValueType.TEXT, //요청자사번
        },
        {
            fieldName: 'reqDt',
            dataType: ValueType.TEXT, //요청일시
        },
        {
            fieldName: 'aprvrDt',
            dataType: ValueType.TEXT, //결재처리일시
        },
        {
            fieldName: 'keyCode',
            dataType: ValueType.TEXT, //keycode
        },
        {
            fieldName: 'bizNum',
            dataType: ValueType.TEXT, //사업자등록번호
        },
        {
            fieldName: 'slcmDfryDepoNm',
            dataType: ValueType.TEXT, //사용자입력예금주
        },
        {
            fieldName: 'slcmDfryDepoCheckNm',
            dataType: ValueType.TEXT, //조회결과예금주
        },
        {
            fieldName: 'slcmChk',
            dataType: ValueType.TEXT, //예금주일치여부
        },
        {
            fieldName: 'errorLog',
            dataType: ValueType.TEXT, //에러로그
        },
    ],
    columns: [
        {
            name: 'erpCase',
            fieldName: 'erpCase',
            header: {
                text: '회계처리대상',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'zconfirm',
            fieldName: 'zconfirm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '확정여부',
                showTooltip: false,
            },
        },
        {
            name: 'earvTypCd',
            fieldName: 'earvTypCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '결재구분',
                showTooltip: false,
            },
        },
        {
            name: 'eravStCd',
            fieldName: 'eravStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전송상태',
                showTooltip: false,
            },
        },
        {
            name: 'bu',
            fieldName: 'bu',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업부',
                showTooltip: false,
            },
        },
        {
            name: 'dam',
            fieldName: 'dam',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '담당',
                showTooltip: false,
            },
        },
        {
            name: 'sen',
            fieldName: 'sen',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '센터',
                showTooltip: false,
            },
        },
        {
            name: 'pt',
            fieldName: 'pt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '파트',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoCd',
            fieldName: 'dealCoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoNm',
            fieldName: 'dealCoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
        },
        {
            name: 'bizNum',
            fieldName: 'bizNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업자등록번호',
                showTooltip: false,
            },
        },
        {
            name: 'slcmDfryDepoNm',
            fieldName: 'slcmDfryDepoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업자입력예금주',
                showTooltip: false,
            },
        },
        {
            name: 'slcmDfryDepoCheckNm',
            fieldName: 'slcmDfryDepoCheckNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조회결과예금주',
                showTooltip: false,
            },
        },
        {
            name: 'slcmChk',
            fieldName: 'slcmChk',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '예금주일치여부',
                showTooltip: false,
            },
        },
        {
            name: 'drftrNm',
            fieldName: 'drftrNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청자',
                showTooltip: false,
            },
        },
        {
            name: 'drftrId',
            fieldName: 'drftrId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청자사번',
                showTooltip: false,
            },
        },
        {
            name: 'reqDt',
            fieldName: 'reqDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청일시',
                showTooltip: false,
            },
        },
        {
            name: 'aprvrDt',
            fieldName: 'aprvrDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '결재처리일시',
                showTooltip: false,
            },
        },
        {
            name: 'errorLog',
            fieldName: 'errorLog',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'ERROR LOG',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_POP = {
    fields: [
        {
            fieldName: 'test1',
            dataType: ValueType.TEXT, //회계처리대상
        },
        {
            fieldName: 'test2',
            dataType: ValueType.TEXT, //확정여부
        },
    ],
    columns: [
        {
            name: 'test1',
            fieldName: 'test1',
            header: {
                text: '회계처리대상',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'test2',
            fieldName: 'test2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '확정여부',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_DTL = {
    fields: [
        {
            fieldName: 'erpCase',
            dataType: ValueType.TEXT, //회계처리대상
        },
        {
            fieldName: 'zconfirm',
            dataType: ValueType.TEXT, //확정여부
        },
        {
            fieldName: 'earvTypCd',
            dataType: ValueType.TEXT, //확정여부
        },
        {
            fieldName: 'eravStCd',
            dataType: ValueType.TEXT, //확정여부
        },
        {
            fieldName: 'dam',
            dataType: ValueType.TEXT, //확정여부
        },
    ],
    columns: [
        {
            name: 'erpCase',
            fieldName: 'erpCase',
            header: {
                text: '제목',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'zconfirm',
            fieldName: 'zconfirm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '작성자명',
                showTooltip: false,
            },
        },
        {
            name: 'earvTypCd',
            fieldName: 'earvTypCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'c',
                showTooltip: false,
            },
        },
        {
            name: 'eravStCd',
            fieldName: 'eravStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'a',
                showTooltip: false,
            },
        },
        {
            name: 'dam',
            fieldName: 'dam',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'b',
                showTooltip: false,
            },
        },
    ],
}
