<!-----------------------------------------------
 * 업무그룹명: 수탁관리
 * 서브업무명: 수탁_출고관리
 * 설명: 수탁_출고 내역을 조회한다.
 * 작성자: P179890
 * 작성일: 2022.07.25
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>수탁_출고관리</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="printReport"
                    :objAuth="this.objAuth"
                    >거래명세표</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="newBtn"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="this.objAuth"
                    v-show="false"
                >
                    저장
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="출고예정일"
                        :calType="calType"
                        :eRequired="true"
                        v-model="setDate"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        @enterKey="onAuthOrgTreeIconClick"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :eRequired="true"
                        :objAuth="this.objAuth"
                        v-model="reqParam.orgNm"
                        :codeVal="reqParam.orgId"
                        :disabledAfter="true"
                        :disabled="searchDisable"
                    >
                    </TCComInputSearchText>
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="reqParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="출고처"
                        @enterKey="onDealcoIconClick"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                        :objAuth="this.objAuth"
                        v-model="reqParam.outPlcNm"
                        :codeVal="reqParam.outPlcId"
                        :disabledAfter="true"
                        :disabled="searchDisable"
                    >
                    </TCComInputSearchText>
                    <!-- 내부거래처팝업(권한조직) -->
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchDealcoParam"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="반품처"
                        :appendIconClass="''"
                        @enterKey="onOutDealIconClick"
                        @appendIconClick="onOutDealIconClick"
                        @input="onOutDealcoInput"
                        :objAuth="this.objAuth"
                        v-model="reqParam.inPlcNm"
                        :codeVal="reqParam.inPlcId"
                        :disabledAfter="true"
                    >
                    </TCComInputSearchText>
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onOutDealReturnData"
                    />
                </div>
                <!-- //item 1-4 -->
            </div>
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00050"
                        labelName="출고구분"
                        :objAuth="this.objAuth"
                        v-model="reqParam.outCl"
                        :filterFunc="filterFunc"
                        :disabled="true"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="outFixComboItems"
                        labelName="출고확정"
                        :objAuth="this.objAuth"
                        v-model="reqParam.outFixYn"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-2 -->
                <div class="formitem div2"></div>
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- //Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="수탁_출고내역"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.exportGridBtn"
            >
                <template #gridBtnArea>
                    <TCComButton
                        :Vuetify="false"
                        eClass="btn_noline btn_ty04"
                        eAttr="ico_exeldown"
                        labelName="상세다운로드"
                        :objAuth="objAuth"
                        @click="exportGridDtlBtn"
                    />
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
                :editable="false"
                @onRowUpdated="onRowUpdated"
            />
        </div>
        <!-- //gridWrap -->
        <!-- 팝업 시작 -->
        <RealReportPopup
            v-if="reportShow"
            :parentParam="vievwParam"
            :dialogShow.sync="reportShow"
        />
    </div>
</template>

<!--style scoped>
</style-->
<script>
import { DisCooConsigmentOutMgmt_GRID_HEADER } from '@/const/grid/dis/coo/disCooConsigmentOutMgmtHeader.js'
import cooApi from '@/api/biz/dis/coo/disCooConsigmentOutMgmt.js'
import oaoApi from '@/api/biz/dis/oao/disOaoEtcOutMgmt.js'
import attachedFileApi from '@/api/common/attachedFile'
import { CommonGrid, CommonUtil, CommonBizClosing, CommonMsg } from '@/utils'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
import RealReportPopup from '@/components/common/RealReportPopup'
//====================거래명세서 리포트====================
import dealDtlfReport from '@/views/biz/dis/dco/DisDcoDealDtlf.json'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================내부거래처(권한조직)====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처(권한조직)==================

export default {
    name: 'DisCooConsigmentOutMgmt',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoOutDealsPopup,
        BasBcoDealcosPopup,
        RealReportPopup,
    },
    data() {
        return {
            //====================조직 팝업====================
            authOrgParam: {},
            showBcoAuthOrgTrees: false,
            resultAuthOrgTreeRows: [],
            //====================//조직 팝업====================
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false,
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '3X', // 거래처그룹
                dealcoClCd1: '30', // 거래처구분
            },
            resultOutDealRows: [],
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
            //====================내부거래처(권한 조직))====================
            basBcoDealcoShow: false,
            searchDealcoParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY',
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC',
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한 조직)==================
            searchDisable: false,
            alertHeadTxt: '수탁_출고관리',
            alertBodyTxt: '',
            calType: 'DP',
            view: DisCooConsigmentOutMgmt_GRID_HEADER,
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            rowCnt: 15,
            gridStyle: {
                height: '450px', //그리드 높이 조절
            },
            searchForms: {},
            inDtlParam: {},
            reportShow: false,
            vievwParam: {},
            reqParam: {
                // 요청파라미터
                staOutSchdDt: '', // 개봉지시일 from
                endOutSchdDt: '', // 개봉지시일 to
                outPlcId: '', // 출고처코드
                outPlcNm: '', // 출고처명
                inPlcId: '', // 반품처코드
                inPlcNm: '', // 반품처명
                outCl: '', // 출고구분
                outFixYn: '', // 출고확정
                orgId: '', // 조직코드
                orgLevel: '', // 조직레벨
                orgCdLvl0: '', // 레벨0조직코드
                orgNm: '', // 조직코드
            },
            // 출고확정 ComboBox Item
            outFixComboItems: [
                { commCdValNm: 'Y', commCdVal: 'Y' },
                { commCdValNm: 'N', commCdVal: 'N' },
            ],
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.staOutSchdDt, this.reqParam.endOutSchdDt]
            },
            set(val) {
                this.reqParam.staOutSchdDt = val[0]
                this.reqParam.endOutSchdDt = val[1]
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.reqParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchDealcoParam.basDay = CommonUtil.onlyNumber(
                    val[1]
                ).substr(0, 8)
                return val
            },
        },
    },
    watch: {},
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false)
        this.gridObj.gridView.setRowIndicator({ visible: true })

        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.onEditCommit = this.onEditCommit
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked

        if (CommonUtil.isNotEmptyObject(this.$route.params.search)) {
            this.reqParam = this.$route.params.search
            // 세션정보 set
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.searchDisable = true
            } else {
                this.searchDisable = false
            }
            this.searchBtn()
        } else {
            this.init()
        }
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.staOutSchdDt = moment(new Date()).format('YYYY-MM-01') // 출고예정일 from
            this.reqParam.endOutSchdDt = moment(new Date()).format('YYYY-MM-DD') // 출고예정일 to
            // 세션정보 set
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                // 출고처
                this.reqParam['outPlcId'] = this.userInfo['dealcoCd']
                this.reqParam['outPlcNm'] = this.userInfo['dealcoNm']
                // 조직
                this.reqParam['orgId'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLevel'] = this.orgInfo['orgLvl']
                this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.searchDisable = true
            } else {
                this.searchDisable = false
            }
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
            this.reqParam.outCl = '201' // 출고구분
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/coo/consigmentOutExcels',
                this.searchForms
            )
        },
        //상세 ExcelDown
        exportGridDtlBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/coo/consigmentOutAllExcels',
                this.searchForms
            )
        },
        // 저장
        async saveBtn() {
            const updateRows = this.gridObj.dataProvider.getStateRows('updated')
            if (updateRows.length === 0) {
                // msgTxt.MSG_00071
                this.openAlert(CommonMsg.getMessage('MSG_00071', ''))
                return
            }
            let saveData = []

            for (var i = 0; i < updateRows.length; i++) {
                let rowData = this.gridObj.dataProvider.getJsonRow(
                    updateRows[i]
                )

                // 출고확정
                if (rowData.outFixYn === 'Y') {
                    // 출고확정일자가 없을때
                    if (_.isEmpty(rowData.outFixDt)) {
                        this.openAlert(
                            CommonMsg.getMessage('MSG_00083', '출고확정일')
                        )
                        return
                    }

                    if (
                        CommonUtil.onlyNumber(rowData.outFixDt).length != 8 ||
                        !moment(
                            CommonUtil.onlyNumber(rowData.outFixDt),
                            'YYYYMMDD'
                        ).isValid()
                    ) {
                        this.openAlert(
                            CommonMsg.getMessage('MSG_00030', '출고확정일')
                        )
                        return
                    }
                }
                if (
                    !_.isEmpty(rowData.outFixDt) &&
                    CommonUtil.onlyNumber(rowData.outFixDt) <
                        CommonUtil.onlyNumber(rowData.outSchdDt)
                ) {
                    this.openAlert(
                        '출고확정일은 출고예정일 [ ' +
                            CommonUtil.addDashDate(rowData.outSchdDt) +
                            ' ] 보다 과거로 등록할 수 없습니다.'
                    )
                    return
                }
                rowData.progId = 'DisCooConsigmentOutMgmt'
                saveData.push(rowData)
            }

            console.log('saveData::', saveData)

            // msgTxt.MSG_00063
            const confirm = await this.showTcComConfirm(
                CommonMsg.getMessage('MSG_00063', '')
            )

            if (confirm) {
                // 로직처리
                cooApi.saveOutFix(saveData).then((res) => {
                    if (res === 1) {
                        this.openAlert(CommonMsg.getMessage('MSG_00990'))
                        this.getExpartRtnOutList()
                    }
                })
            }
        },
        //조회 버튼 이벤트
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            //첫 조회시 표시할 행의 갯수
            this.searchForms = { ...this.reqParam }
            this.searchForms.staOutSchdDt = CommonUtil.onlyNumber(
                this.searchForms.staOutSchdDt
            )
            this.searchForms.endOutSchdDt = CommonUtil.onlyNumber(
                this.searchForms.endOutSchdDt
            )
            this.getConsigmentOutList()
        },
        // 교/반품출고 내역 조회
        getConsigmentOutList() {
            cooApi.getConsigmentOutList(this.searchForms).then((res) => {
                this.gridObj.setRows(res.gridList)
                this.gridHeaderObj.setPageCount({
                    totalDataCnt: res.gridList.length,
                })
            })
        },
        // 초기화
        clearPage() {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.init()
        },
        // Validation 체크
        isValidChk() {
            if (_.isEmpty(this.reqParam.staOutSchdDt)) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00083', '출고예정시작일')
                )
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.staOutSchdDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            if (_.isEmpty(this.reqParam.endOutSchdDt)) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00083', '출고예정종료일')
                )
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.endOutSchdDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            if (
                this.reqParam.staOutSchdDt.substr(0, 7) !==
                this.reqParam.endOutSchdDt.substr(0, 7)
            ) {
                this.openAlert('시작일자와 종료일자을 동일한 월로 지정하세요.')
                return false
            }
            if (
                this.reqParam.staOutSchdDt.replaceAll('-', '') >
                this.reqParam.endOutSchdDt.replaceAll('-', '')
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_01026'))
                return false
            }
            if (_.isEmpty(this.reqParam.orgId)) {
                this.openAlert(CommonMsg.getMessage('MSG_00121', '조직;조회'))
                return false
            }
            return true
        },
        // 그리드 editCommit 이벤트
        onEditCommit(grid) {
            grid.editOptions.commitByCell = true
        },
        // 그리드 rowUpdate 이벤트
        async onRowUpdated(provider, row) {
            const rowData = provider.getJsonRow(row)

            if (!_.isEmpty(rowData.outFixDt) && rowData.outFixYn == 'Y') {
                // 마감일 체크
                const clsStatus = await CommonBizClosing.getClsStatus(
                    'D',
                    CommonUtil.onlyNumber(rowData.outFixDt),
                    'STK'
                )
                if (clsStatus && 'CLS' == clsStatus.clsStCd) {
                    this.openAlert(CommonMsg.getMessage('MSG_00185', ''))
                    this.gridObj.dataProvider.setValue(row, 'outFixDt', '')
                    return
                }

                if (
                    CommonUtil.onlyNumber(rowData.outFixDt) <
                    CommonUtil.onlyNumber(rowData.outSchdDt)
                ) {
                    this.gridObj.dataProvider.setValue(row, 'outFixDt', '')
                    this.openAlert(
                        '출고확정일은 출고예정일 [ ' +
                            CommonUtil.addDashDate(rowData.outSchdDt) +
                            ' ] 보다 과거로 등록할 수 없습니다.'
                    )
                    return
                }
            }

            // 출고확정 체크(확정)
            if (rowData.outFixYn == 'Y') {
                // 기존 출고확정인 경우
                if (rowData.outFixYnOrg == 'Y') {
                    // 기존의 출고확정일 set
                    this.gridObj.dataProvider.setValue(
                        row,
                        'outFixDt',
                        rowData.outFixDtOrg
                    )
                    // 행상태값 초기화
                    this.gridObj.dataProvider.setRowState(row, 'none', false)
                } else {
                    // 기존 출고미확정인경우
                    // 출고확정일 빈 값일 경우에만
                    if (_.isEmpty(rowData.outFixDt)) {
                        // 출고확정일 - 현재일자 set
                        this.gridObj.dataProvider.setValue(
                            row,
                            'outFixDt',
                            moment(new Date()).format('YYYYMMDD')
                        )
                    }
                }
            } else {
                // 출고확정 체크해제(미확정)
                this.gridObj.dataProvider.setValue(row, 'outFixDt', '')
                if (rowData.outFixYnOrg == 'N') {
                    this.gridObj.dataProvider.setRowState(row, 'none', false)
                }
            }
        },
        // 그리드 CellDblClick 이벤트
        onCellDblClicked(grid, clickData) {
            if (clickData?.dataRow >= 0) {
                const rowData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                if (
                    clickData.column != 'outFixDt' &&
                    clickData.column != 'outFixYn'
                ) {
                    //
                    // 타계정출고 등록 화면 호출
                    this.$router.push({
                        name: '/dis/coo/DisCooConsigmentOutMgmtDtl',
                        params: {
                            outMgmtNo: rowData['outMgmtNo'],
                            outCl: rowData['outCl'],
                            orgId: rowData['orgId'],
                            orgNm: rowData['orgNm'],
                            outPlcId: rowData['outPlcId'],
                            outPlcNm: rowData['outPlcNm'],
                            inPlcId: rowData['inPlcId'],
                            inPlcNm: rowData['inPlcNm'],
                            search: this.reqParam,
                        },
                    })
                }
            }
        },
        // 신규버튼 클릭 이벤트
        newBtn() {
            // 교/반품출고상세 화면 이동
            this.$router.push({
                name: '/dis/coo/DisCooConsigmentOutMgmtDtl',
                params: { search: this.reqParam },
            })
        },
        // Alert창 호출
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        // 거래명세서 - 리포트 출력
        printReport() {
            let current = this.gridObj.gridView.getCurrent()

            if (current.dataRow < 0) {
                this.openAlert(CommonMsg.getMessage('MSG_00084', '선택된 내용'))
                return
            }

            const rowData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow,
                true
            )
            if (rowData['outFixYnOrg'] != 'Y') {
                this.openAlert(
                    CommonMsg.getMessage(
                        'MSG_00139',
                        '출고확정을 처리 하신 후 조회'
                    )
                )
                return
            }

            const reportParam = {
                outMgmtNo: rowData['outMgmtNo'],
                inPlcId: rowData['inPlcId'],
                outPlcId: rowData['outPlcId'],
            }

            oaoApi.getEtcOutReport(reportParam).then((res) => {
                const reportData = {
                    master: {
                        values: [
                            {
                                mgmtNo: res.result.outMaster?.mgmtNo, // 관리번호
                                splyrBizNo: res.result.outMaster?.bizNo, // 공급자등록번호
                                splyrDealCoNm: res.result.outMaster?.dealcoNm, // 공급자상호
                                splyrNm: res.result.outMaster?.repUserNm, // 공급자성명
                                splyrAddr: res.result.outMaster?.addr, // 공급자사업장
                                splyrBizConNm: res.result.outMaster?.bizConNm, // 공급자업태
                                splyrTypOfBizNm:
                                    res.result.outMaster?.typOfBizNm, // 공급자종목
                                splyedBizNo: res.result.inMaster?.bizNo, // 공급받는자등록번호
                                splyedDealCoNm: res.result.inMaster?.dealcoNm, // 공급받는자상호
                                splyedNm: res.result.inMaster?.repUserNm, // 공급받는자성명
                                splyedAddr: res.result.inMaster?.addr, // 공급받는자사업장
                                splyedBizConNm: res.result.inMaster?.bizConNm, // 공급받는자업태
                                splyedTypOfBizNm:
                                    res.result.inMaster?.typOfBizNm, // 공급받는자종목
                            },
                        ],
                    },
                    detail: {
                        values: [...res.result.detail],
                    },
                }

                this.reportOpen(reportData)
            })
        },
        // 거래명세서 리포트 출력
        reportOpen(data) {
            this.vievwParam.report = dealDtlfReport
            this.vievwParam.data = data
            this.reportShow = true
        },
        // 출고구분comboBox filter
        filterFunc(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] === '201' || item['commCdVal'] === '202'
            )
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.authOrgParam)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.orgId = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLevel = _.get(res[0], 'orgLvl')
                        this.reqParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            this.authOrgParam['orgNm'] = this.reqParam['orgNm']
            this.authOrgParam['orgCd'] = this.reqParam['orgId']
            this.authOrgParam['orgLvl'] = this.reqParam['orgLevel']
            if (!_.isEmpty(this.reqParam.orgNm)) {
                // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
                this.getAuthOrgTreeList()
            } else {
                // 그 이외는 내부조직팝업(권한) 팝업 오픈
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            if (
                !_.isEmpty(this.reqParam.orgId) &&
                this.reqParam.orgId != retrunData.orgCd
            ) {
                this.reqParam.outPlcId = ''
                this.reqParam.outPlcNm = ''
            }
            this.reqParam.orgId = _.get(retrunData, 'orgCd')
            this.reqParam.orgNm = _.get(retrunData, 'orgNm')
            this.reqParam.orgLevel = _.get(retrunData, 'orgLvl')
            this.reqParam.orgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.orgId = ''
            this.reqParam.orgLevel = ''
            this.reqParam.orgCdLvl0 = ''
            this.reqParam.outPlcId = ''
            this.reqParam.outPlcNm = ''
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.inPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.inPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            this.searchOutDealParam['dealcoCd'] = this.reqParam['inPlcId'] // 반품처코드
            this.searchOutDealParam['dealcoNm'] = this.reqParam['inPlcNm'] // 반품처명
            if (!_.isEmpty(this.reqParam.inPlcNm)) {
                // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
                this.getOutDealList()
            } else {
                // 그 이외는 외부거래처 팝업 오픈
                this.showBcoOutDeals = true
            }
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            this.reqParam.inPlcId = _.get(retrunData, 'dealcoCd')
            this.reqParam.inPlcNm = _.get(retrunData, 'dealcoNm')
        },
        onOutDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.reqParam.inPlcId = ''
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcoParam)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.reqParam.outPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.outPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            if (_.isEmpty(this.reqParam.orgId)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return
            }
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.searchDealcoParam['orgCd'] = this.reqParam['orgId']
            this.searchDealcoParam['orgNm'] = this.reqParam['orgNm']
            this.searchDealcoParam['orgLvl'] = this.reqParam['orgLevel']
            this.searchDealcoParam['dealcoCd'] = this.reqParam['outPlcId']
            this.searchDealcoParam['dealcoNm'] = this.reqParam['outPlcNm']

            if (!_.isEmpty(this.reqParam['outPlcNm'])) {
                // 내부거래처조회
                this.getDealcosList()
            } else {
                // 팝업오픈
                this.basBcoDealcoShow = true
            }
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.reqParam.outPlcId = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            this.reqParam.outPlcId = _.get(returnData, 'dealcoCd')
            this.reqParam.outPlcNm = _.get(returnData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================
    },
}
</script>
