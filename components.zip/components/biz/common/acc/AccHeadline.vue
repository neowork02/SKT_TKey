<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccHeadline.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div>
        <!-- Tit -->
        <h1>{{ title }}</h1>
        <!--tooltip_도움말 -->
        <div class="tooltip_area tit" v-if="tooltip">
            <span class="tooltip_arrow"></span>
            <span class="tooltip">{{ tooltip }}</span>
        </div>
        <!-- //tooltip_도움말 -->
        <!-- // Tit -->
    </div>
</template>
<script>
export default {
    name: 'AccHeadline',
    props: {
        title: {
            default: '',
        },
        tooltip: {
            default: '',
        },
    },

    mounted() {},
}
</script>
