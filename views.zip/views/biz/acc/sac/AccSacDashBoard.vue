<template>
    <div class="dashBoard">
        <!-- SubTit -->
        <div class="stitHead">
            <!-- <h3 class="subTit">PS&M(보신각점)</h3> -->
            <h3 class="subTit">{{ orgInfo.orgNm }}</h3>
            <span class="stitBtnRef">
                <p>데이터 기준일 : {{ dateY }}년 {{ dateM }}월(전월)</p>
                <!-- <p>'데이터 기준일 : ' + data.date</p> -->
                <!-- <p>판매실적 / 무선실적 / <strong>무선실적 현황</strong></p> -->
            </span>
        </div>
        <!-- //SubTit -->

        <!-- dashLayer_wrap -->
        <div class="dashLayer_wrap">
            <!-- dashForm_line 1 -->
            <div class="dashForm">
                <div class="type div4">
                    <div class="boxArea">
                        <p class="tit">입금내역</p>
                        <p class="price">
                            {{ setComma(depositedList.totDepositAmt)
                            }}<span>원</span>
                        </p>
                    </div>
                </div>
                <div class="type div4">
                    <div class="boxArea">
                        <p class="tit">
                            {{ dashBoardListM.accMonth }}월 수수료 현황
                        </p>
                        <div class="chargeInfo">
                            <ul>
                                <li>
                                    <span class="tit">거래점 수</span>
                                    <p>
                                        {{ setComma(dashBoardListM.dealCnt)
                                        }}<span>개</span>
                                    </p>
                                </li>
                                <li>
                                    <span class="tit">금액</span>
                                    <p>
                                        {{ setComma(dashBoardListM.dealAmt)
                                        }}<span>원</span>
                                    </p>
                                </li>
                                <li>
                                    <span class="tit">객단가</span>
                                    <p>
                                        {{
                                            setComma(
                                                dashBoardListM.dealUntPrice
                                            )
                                        }}<span>원</span>
                                    </p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="type div4">
                    <div class="boxArea">
                        <div class="stor3">
                            <p class="tit">
                                {{ dashBoardList.accMonth }}월 수수료 현황
                            </p>
                            <div class="chargeInfo">
                                <ul>
                                    <li>
                                        <span class="tit">거래점 수</span>
                                        <p>
                                            {{ setComma(dashBoardList.dealCnt)
                                            }}<span>개</span>
                                        </p>
                                    </li>
                                    <li>
                                        <span class="tit">금액</span>
                                        <p>
                                            {{ setComma(dashBoardList.dealAmt)
                                            }}<span>원</span>
                                        </p>
                                    </li>
                                    <li>
                                        <span class="tit">객단가</span>
                                        <p>
                                            {{
                                                setComma(
                                                    dashBoardList.dealUntPrice
                                                )
                                            }}<span>원</span>
                                        </p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="type div4">
                    <div class="boxArea">
                        <p class="tit">정산지원 게시판 현황</p>
                        <div class="grid2-list">
                            <ul>
                                <li>
                                    <span>{{
                                        setComma(settlementList.totAnswCnt)
                                    }}</span>
                                    <p class="txt">요청</p>
                                </li>
                                <li>
                                    <span>{{
                                        setComma(settlementList.totReqCnt)
                                    }}</span>
                                    <p class="txt">답변</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- //dashForm_line 1 -->
        </div>
        <!-- //dashLayer_wrap -->
        <!-- dashLayer_wrap -->
        <div class="dashLayer_wrap">
            <div class="dashForm">
                <!-- [2022-10-19 수정] 위치이동 -->
                <div class="type div4">
                    <div class="listArea">
                        <ul>
                            <li class="backHeader">
                                <span class="tit">구분</span>
                                <span class="date">계산서금액</span>
                            </li>
                            <li>
                                <span class="tit">정산금</span>
                                <span class="date">{{
                                    setComma(depositedList.accAmt)
                                }}</span>
                            </li>
                            <li class="backGray">
                                <span class="tit">상계금액</span>
                                <span class="date">{{
                                    setComma(depositedList.totAmt)
                                }}</span>
                                <!-- toggleArea-->
                                <template>
                                    <button
                                        type="button"
                                        class="btn_plus"
                                        @click="active = !active"
                                        v-bind:class="{
                                            ' btn_minus ': active,
                                        }"
                                    ></button>
                                </template>
                                <v-expand-transition>
                                    <div class="toggleArea" v-show="active">
                                        <ul>
                                            <li>
                                                <span class="total"
                                                    >현금개통</span
                                                >
                                                <span class="price">{{
                                                    setComma(
                                                        depositedList.cashAmt
                                                    )
                                                }}</span>
                                            </li>
                                            <li>
                                                <span class="total"
                                                    >공기기청구(단말+USIM)</span
                                                >
                                                <span class="price">{{
                                                    setComma(
                                                        depositedList.mobilAmt
                                                    )
                                                }}</span>
                                            </li>
                                            <li>
                                                <span class="total"
                                                    >요금수납</span
                                                >
                                                <span class="price">{{
                                                    setComma(
                                                        depositedList.payAmt
                                                    )
                                                }}</span>
                                            </li>
                                            <li>
                                                <span class="total">입금</span>
                                                <span class="price">{{
                                                    setComma(
                                                        depositedList.dpstAmt
                                                    )
                                                }}</span>
                                            </li>
                                            <li>
                                                <span class="total"
                                                    >선지급</span
                                                >
                                                <span class="price">{{
                                                    setComma(
                                                        depositedList.preAmt
                                                    )
                                                }}</span>
                                            </li>
                                            <li>
                                                <span class="total"
                                                    >사고단말&T-ECO</span
                                                >
                                                <span class="price">{{
                                                    setComma(
                                                        setComma(
                                                            depositedList.riskAmt
                                                        )
                                                    )
                                                }}</span>
                                            </li>
                                            <li>
                                                <span class="total"
                                                    >오입금환불</span
                                                >
                                                <span class="price">{{
                                                    setComma(
                                                        depositedList.rfndAmt
                                                    )
                                                }}</span>
                                            </li>
                                            <li>
                                                <span class="total"
                                                    >현금개통</span
                                                >
                                                <span class="price">{{
                                                    setComma(
                                                        depositedList.cashAmt
                                                    )
                                                }}</span>
                                            </li>
                                        </ul>
                                    </div>
                                </v-expand-transition>
                                <!-- //toggleArea -->
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- [2022-10-19 수정] 위치이동 -->
                <div class="type div4">
                    <div class="listArea">
                        <ul>
                            <li class="backHeader">
                                <span class="tit">구분</span>
                                <span class="date">계산서금액</span>
                            </li>
                            <li
                                v-for="itemM in typeListM"
                                :key="itemM.accRptClCd"
                            >
                                <span class="tit">{{ itemM.accRptClNm }}</span>
                                <span class="date">{{
                                    setComma(itemM.amt)
                                }}</span>
                            </li>
                            <li class="backHeader">
                                <span class="tit">계</span>
                                <span class="date">{{
                                    setComma(dashBoardListM.dtlTotAmt)
                                }}</span>
                            </li>
                            <li
                                v-for="itemB in priceListM"
                                :key="itemB.accRptClCd"
                            >
                                <span class="tit">{{
                                    setComma(itemB.accRptClNm)
                                }}</span>
                                <span class="date">{{
                                    setComma(itemB.amt)
                                }}</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="type div4">
                    <div class="listArea">
                        <ul>
                            <li class="backHeader">
                                <span class="tit">구분</span>
                                <span class="date">계산서금액</span>
                            </li>
                            <li
                                v-for="itemC in typeList"
                                :key="itemC.accRptClCd"
                            >
                                <span class="tit">{{ itemC.accRptClNm }}</span>
                                <span class="date">{{
                                    setComma(itemC.amt)
                                }}</span>
                            </li>
                            <li class="backHeader">
                                <span class="tit">계</span>
                                <span class="date">{{
                                    setComma(dashBoardList.dtlTotAmt)
                                }}</span>
                            </li>
                            <li
                                v-for="itemD in priceList"
                                :key="itemD.accRptClCd"
                            >
                                <span class="tit">{{ itemD.accRptClNm }}</span>
                                <span class="date">{{
                                    setComma(itemD.amt)
                                }}</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="type div4">
                    <div class="listArea">
                        <!-- tablewrap -->
                        <div class="dashTblDefault mt0">
                            <table
                                cellpadding="0"
                                cellspacing="0"
                                class="thCenter"
                            >
                                <caption>
                                    테이블 제목 정보 입력
                                </caption>
                                <colgroup>
                                    <col style="width: auto%" />
                                    <col style="width: 27%" />
                                    <col style="width: 27%" />
                                </colgroup>
                                <thead>
                                    <tr>
                                        <th scope="col">구분</th>
                                        <th scope="col">요청</th>
                                        <th scope="col">완료</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        v-for="(
                                            itemE, index
                                        ) in settlementList.dtlList"
                                        :key="index + 'E'"
                                    >
                                        <td scope="row">
                                            {{ itemE.accQueDtlNm }}
                                        </td>
                                        <td scope="row" class="ar">
                                            {{ setComma(itemE.reqCnt) }}
                                        </td>
                                        <td class="ar">
                                            {{ setComma(itemE.answCnt) }}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- //tablewrap -->
                    </div>
                </div>
            </div>
        </div>
        <!-- //dashLayer_wrap -->

        <!-- 2022-09-30 수정 -->
        <div class="dashLayer_wrap">
            <!-- [2022-10-19 수정] dashForm_line:1줄일 경우 -->
            <div class="dashForm">
                <div class="type div1">
                    <div class="boxArea sal1">
                        <p class="tit ac">수납(현금/채권)현황</p>
                        <ul>
                            <li class="bgBlue">
                                <p class="subtit">SKT수납</p>
                                <p class="price">20,000,000</p>
                            </li>
                            <li class="bgBlue">
                                <p class="subtit">현금</p>
                                <p class="price">600,000</p>
                            </li>
                            <li class="bgBlue">
                                <p class="subtit">기타</p>
                                <p class="price">100,000</p>
                            </li>
                            <li class="bgPink">
                                <p class="subtit">송금</p>
                                <p class="price pointColor3">3,000</p>
                            </li>
                            <li class="bgBlue">
                                <p class="subtit">오입금환불</p>
                                <p class="price">800,000</p>
                            </li>
                            <li class="bgBlue">
                                <p class="subtit">선급금</p>
                                <p class="price">800,000</p>
                            </li>
                            <li class="bgBlue">
                                <p class="subtit">기타미수금</p>
                                <p class="price">800,000</p>
                            </li>
                            <li class="bgYellow">
                                <p class="subtit pointColor1">잔액</p>
                                <p class="price pointColor1">1,000,000</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- //2022-09-30 수정 -->
        </div>
    </div>
</template>

<script>
import axios from 'axios'
// import _ from 'lodash'
import send from '@/api/axios-tdcs'
import CommonMixin from '@/mixins'
import store from '@/store'
import moment from 'moment'

export default {
    name: 'Home',
    components: {},
    mixins: [CommonMixin],
    data() {
        return {
            show: false,
            expand: false,
            active: false,
            value: '',
            dashBoardList: {
                dealCnt: '',
                dealAmt: '',
                dealUntPrice: '',
                dtlTotAmt: '',
            },
            dashBoardListM: {
                dealCnt: '',
                dealAmt: '',
                dealUntPrice: '',
                dtlTotAmt: '',
            },
            settlementList: {
                totAnswCnt: '',
                totReqCnt: '',
            },
            depositedList: {
                totDepositAmt: '',
                accAmt: '',
                totAmt: '',
            },
            typeList: {},
            priceList: {},
            typeListM: {},
            priceListM: {},
            dateM: moment(new Date()).subtract(1, 'months').format('MM'),
            dateY: moment(new Date()).format('YYYY'),
            favoriteArray: [],
        }
    },
    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)
        console.log('mounted')
    },

    created() {
        console.log('created')
        store.dispatch('setApiLoading', true)
        this.getAccDashBoardApi()
    },
    methods: {
        async getAccDashBoardApi() {
            console.log(this.favoriteArray)
            store.dispatch('setApiLoading', true)
            console.log('setApiLoading true')
            axios
                .all([
                    axios.get(
                        '/api/v1/backend-max/acc/sac/dash-board/commission/1'
                    ),
                    axios.get(
                        '/api/v1/backend-max/acc/sac/dash-board/commission/0'
                    ),
                    axios.get(
                        '/api/v1/backend-max/acc/sac/dash-board/settlement-support-board'
                    ),
                    // axios.get(
                    //     '/api/v1/backend-max/acc/sac/dash-board/deposited-detail'
                    // ),
                ])
                .then(
                    await axios.spread(
                        (commission1, commission0, settlement) => {
                            // 전월 수수료 현황
                            console.log('commission1', commission1.data.result)
                            this.dashBoardListM = commission1.data.result
                            if (this.dashBoardListM.dtlList != null) {
                                // 리스트 자르기 '구분'
                                this.typeListM =
                                    this.dashBoardListM.dtlList.slice(0, 4)
                                // 리스트 자르기 '계'
                                this.priceListM =
                                    this.dashBoardListM.dtlList.slice(4, 6)
                            }
                            // 당월 수수료 현황
                            console.log('commission0', commission0.data.result)
                            this.dashBoardList = commission0.data.result
                            if (this.dashBoardList.dtlList != null) {
                                // 리스트 자르기 '구분'
                                this.typeList =
                                    this.dashBoardList.dtlList.slice(0, 4)
                                // 리스트 자르기 '계'
                                this.priceList =
                                    this.dashBoardList.dtlList.slice(4, 6)
                            }
                            // 정산지원 게시판 현황
                            console.log('settlement', settlement.data.result)
                            this.settlementList = settlement.data.result
                            // // // 입금내역
                            // console.log('deposited', deposited.data.result)
                            // this.depositedList = deposited.data.result
                            // if (
                            //     !_.isEmpty(
                            //         this.priceListM && this.dashBoardList
                            //     )
                            // ) {
                            //     store.dispatch('setApiLoading', false)
                            //     console.log('setApiLoading false')
                            // }
                        }
                    )
                )

            await this.getDeposited()
        },

        // 콤마 달기
        setComma(v) {
            return String(v)
                .replace(/,/gi, '')
                .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        },

        async getDeposited() {
            return await new Promise((resolve, reject) => {
                send({
                    method: 'get',
                    url: '/api/v1/backend-max/acc/sac/dash-board/deposited-detail',
                })
                    .then((result) => {
                        resolve(result)
                        this.depositedList = result
                        console.log('depositedList', this.depositedList)
                        console.log(this.userInfo)
                    })
                    .catch((err) => {
                        console.log(err)
                        reject(err)
                    })
            })
        },
    },
}
</script>
