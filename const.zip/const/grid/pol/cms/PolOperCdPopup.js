import { ValueType } from 'realgrid'

export let GRID_PROPERTYINFO = {
    fields: [
        {
            fieldName: 'dealcoCd', // 정책운영사코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 정책운영사
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoClNm',
            fieldName: 'dealcoClNm',
            type: 'data',
            width: '150',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '250',
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],

    layout: [
        'dealcoCd', // 거래처코드
        'dealcoClNm1', // 거래처구분
        'dealcoNm', // 거래처
    ],
}
