import { ValueType } from 'realgrid'

export const CHG_POPUP_HEADER = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modRsn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modRsnNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'endDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useStopDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dstrbEqpClCd',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'prodChrticCd1',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'prodChrticCd2',
        //     dataType: ValueType.TEXT,
        // },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            editable: false,
            header: {
                text: '모델코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            editable: false,
            header: {
                text: '모델',
            },
        },
        {
            name: 'modRsn',
            fieldName: 'modRsn',
            editable: false,
            header: {
                text: '변경사유',
            },
        },
        {
            name: 'modRsnNm',
            fieldName: 'modRsnNm',
            editable: false,
            header: {
                text: '변경사유',
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            editable: false,
            header: {
                text: '출시일',
            },
        },
        {
            name: 'endDt',
            fieldName: 'endDt',
            editable: false,
            header: {
                text: '단종일',
            },
        },
        {
            name: 'useStopDt',
            fieldName: 'useStopDt',
            editable: false,
            header: {
                text: '중지일',
            },
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            editable: false,
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            editable: false,
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'dealCoNm',
            fieldName: 'dealCoNm',
            editable: false,
            header: {
                text: '제조사',
            },
        },
        {
            name: 'dstrbEqpClCd',
            fieldName: 'dstrbEqpClCd',
            editable: false,
            header: {
                text: '유통단말기구분코드',
            },
        },
        // {
        //     name: 'prodChrtic1',
        //     fieldName: 'prodChrtic1',
        //     editable: false,
        //     header: {
        //         text: '상품 특성1',
        //     },
        // },
        // {
        //     name: 'prodChrtic2',
        //     fieldName: 'prodChrtic2',
        //     editable: false,
        //     header: {
        //         text: '상품 특성2',
        //     },
        // },
    ],
}
