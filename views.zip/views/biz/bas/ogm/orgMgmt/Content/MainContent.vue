<template>
    <div class="content">
        <!-- Tit -->
        <h1>조직관리</h1>
        <!-- // Tit -->
        <search-container ref="searchContainer" />
        <div class="contBoth">
            <!-- left area -->
            <div class="div4_6 cont1 left">
                <!-- Top BTN -->
                <org-btn-container />
                <!-- // Top BTN -->
                <!-- treeWrap_조직도 -->
                <treeview-container @Refresh="Refresh" />
                <!-- //treeWrap_조직도 -->
            </div>
            <!-- //left area -->

            <!-- right area -->
            <div class="div4_6 cont2 right">
                <div class="contBoth">
                    <!-- left area -->
                    <div class="div5_5 cont1-1 left">
                        <table-container
                            @PopupOpen="PopupOpen"
                            @Refresh="Refresh"
                        />
                    </div>
                    <!-- //left area -->

                    <!-- arrow area -->
                    <div class="div5_5 cont3">
                        <button-container />
                    </div>
                    <!-- //arrow area -->

                    <!-- right area -->
                    <div class="div5_5 cont1-1 right pl0">
                        <table-container2
                            @PopupOpen="PopupOpen"
                            @Refresh="Refresh"
                        />
                    </div>
                    <!-- //right area -->
                </div>
            </div>
            <!-- //right area -->
        </div>
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/ogm/orgMgmt/helpers'
import SearchContainer from './SearchContainer.vue'
import TableContainer from './TableContainer.vue'
import TableContainer2 from './TableContainer2.vue'
import ButtonContainer from './ButtonContainer.vue'
import TreeviewContainer from './TreeviewContainer.vue'
import OrgBtnContainer from './OrgBtnContainer.vue'

export default {
    components: {
        SearchContainer,
        TableContainer,
        TableContainer2,
        ButtonContainer,
        TreeviewContainer,
        OrgBtnContainer,
    },
    data() {
        return {
            objAuth: {},
        }
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        PopupOpen(param) {
            this.$refs.popupContainer.open(param)
        },
        Refresh() {
            this.$refs.searchContainer.searchData()
        },
    },
}
</script>

<style></style>
