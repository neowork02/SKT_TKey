<!-----------------------------------------------
 * 업무그룹명: 시연재고관리
 * 서브업무명: 시연재고관리
 * 설명: 시연재고관리한다.
 * 작성자: P179234
 * 작성일: 2022.04.05
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>시연재고관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    eClass="btn_ty"
                    :eOutlined="true"
                    :objAuth="objAuth"
                    @click="openPop(1)"
                    >엑셀업로드</TCComButton
                >
                <TCComButton
                    eClass="btn_ty"
                    :eOutlined="true"
                    :objAuth="objAuth"
                    @click="delDemo"
                    >시연등록해제</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="init"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="search()"
                    >조회</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="openPop(3)"
                    >신규</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="등록일자"
                        :calType="calType5"
                        :eRequired="true"
                        v-model="setDate"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        placeholder="입력해주세요"
                        :codeVal.sync="reqParam.orgCd"
                        :disabledAfter="true"
                        :eRequired="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        v-model="reqParam.orgNm"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="제조사"
                        :appendIconShow="true"
                        :appendIconClass="''"
                        :codeIDView="codeIDView"
                        :codeIDViewVal="codeIDViewVal"
                        :objAuth="objAuth"
                        v-model="reqParam.mfactCd"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="모델명"
                        :appendIconShow="false"
                        :appendIconClass="''"
                        :objAuth="objAuth"
                        v-model="reqParam.prodNm"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="일련번호"
                        :appendIconShow="false"
                        :appendIconClass="''"
                        :objAuth="objAuth"
                        v-model="reqParam.serNum"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="단말기구분"
                        codeId="ZBAS_C_00500"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        :blankItemText="'선택'"
                        blankItemValue=""
                        v-model="reqParam.eqpClCd"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="시연재고여부"
                        :itemList="searchCode[0]"
                        :objAuth="objAuth"
                        v-model="reqParam.demoYn"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="재고상태"
                        codeId="ZDIS_C_00100"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        :blankItemText="'선택'"
                        blankItemValue=""
                        v-model="reqParam.disStCd"
                    />
                </div>
            </div>
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{
                            ' btn_ty_exp_active ': active,
                        }"
                        @click="active = !active"
                    >
                    </v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="active">
                    <div class="searchform">
                        <div class="formitem div4">
                            <TCComInputSearchText
                                v-model="reqParam.hldDealcoNm"
                                :codeVal.sync="reqParam.hldDealcoCd"
                                labelName="보유처"
                                placeholder="입력해주세요"
                                :disabledAfter="true"
                                :objAuth="objAuth"
                                :disabled="dealcoDisabled"
                                @enterKey="onDealcoEnterKey"
                                @appendIconClick="onDealcoIconClick"
                                @input="onDealcoInput"
                            />
                            <BasBcoDealcosPop
                                v-if="showBasBcoDealcos"
                                :parentParam="searchForm"
                                :rows="resultDealcoRows"
                                :dialogShow.sync="showBasBcoDealcos"
                                @confirm="onDealcoReturnData"
                            />
                        </div>
                        <div class="formitem div4_6"></div>
                    </div>
                </div>
            </v-expand-transition>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeaderDemo"
                ref="gridHeaderDemo"
                gridTitle="시연재고관리"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="gridDemo"
                ref="gridDemo"
                :fields="gridSet.fields"
                :columns="gridSet.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisDemDemoDisMgmt"
                :gridObj="gridObj"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            />
        </div>
        <!-- 시연재고 해제 -->
        <DisDemDemoDelPop
            ref="popup"
            v-if="showDisDemDemoDelPop === true"
            :dialogShow.sync="showDisDemDemoDelPop"
            :parentParam="popupParamDel"
            :closeDemo.sync="demo"
        />
        <!-- 시연재고 신규 -->
        <DisDemDemoCrePop
            ref="popup"
            v-if="showDisDemDemoCrePop === true"
            :dialogShow.sync="showDisDemDemoCrePop"
            :demoInfo.sync="demoInfo"
            :parentParam="popupParamNew"
            @confirm="onReturnDisDemDemoCre"
        />
        <DisDemDemoDisMgmtRgst
            ref="popup"
            v-if="showDisDemDemoDisMgmtRgst === true"
            :dialogShow.sync="showDisDemDemoDisMgmtRgst"
            :parentParam="popupParam"
            @confirm="onReturnDisDemDemoDisMgmtRgst"
        />
    </div>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 엑셀 다운로드
 * 4 사용자 정의 파라메터 기반 공통 팝업 호출
 * 5 영업담당조회 -- as-is에서 사용안하는듯 
------------------------------------------------>
<script>
import { CommonGrid, CommonUtil } from '@/utils'
import CommonMixin from '@/mixins'
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
import DisDemDemoDelPop from './DisDemDemoDelPopup'
import DisDemDemoCrePop from './DisDemDemoCrePopup'
import { GRID_HEADER } from '@/const/grid/dis/dem/disDemDemoDisMgmtHeader.js'
import { Demo } from './js/disDemDemoDisMgmt.js'
import commonApi from '@/api/common/prototype'
import demApi from '@/api/biz/dis/dem/disDemDemoDisMgmt.js'
import moment from 'moment'
import _ from 'lodash'

import { SacCommon } from '@/views/biz/sac/js'
import attachedFileApi from '@/api/common/attachedFile'

import DisDemDemoDisMgmtRgst from './DisDemDemoDisMgmtRgst'

//====================내부거래처-권한조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================

export default {
    name: 'DisDemDemoMgmt',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        DisDemDemoDelPop,
        DisDemDemoCrePop,
        DisDemDemoDisMgmtRgst,
        BasBcoDealcosPop,
    },
    data() {
        return {
            objAuth: {},
            indicatorOpt: { sort: 'ASC' },
            codeIDView: true,
            codeIDViewVal: '',
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridDataRaw: {},
            gridStyle: {
                height: '500px',
            },
            searchForms: {},
            rowCnt: 15,
            showDisDemDemoDelPop: false,
            showDisDemDemoCrePop: false,
            gridSet: GRID_HEADER,
            demo: Demo,
            demoInfo: false,
            calType5: 'DP',
            reqParam: {
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                regStaDt: '',
                regEndDt: '',
                mfactCd: '',
                prodNm: '',
                serNum: '',
                mdlClCd: '',
                eqpClCd: '',
                demoYn: '',
                hldDealcoCd: '',
                hldDealcoNm: '',
                disStCd: '',
                pageSize: '',
                pageNum: 1,
            },
            searchCode: [
                [
                    {
                        commCdVal: '',
                        commCdValNm: '전체',
                    },
                    {
                        commCdVal: 'Y',
                        commCdValNm: 'Y',
                    },
                    {
                        commCdVal: 'N',
                        commCdValNm: 'N',
                    },
                ],
            ],
            active: false,
            searchable: false,
            // 내부조직 관련
            orgDisabled: false,
            showBcoAuthOrgTrees: false,
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultAuthOrgTreeRows: [],
            //
            showDisDemDemoDisMgmtRgst: false,
            // 엑셀업로드 파라미터
            popupParam: {},
            // 시연재고해제 파라미터
            popupParamDel: {},
            // 신규 파라미터
            popupParamNew: {},
            //====================내부거래처-권한조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.regStaDt, this.reqParam.regEndDt]
            },
            set(val) {
                this.reqParam.regStaDt = val[0]
                this.reqParam.regEndDt = val[1]

                this.searchable = val[0] === '' || val[1] === '' ? false : true

                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val[1])
                return val
            },
        },
    },
    mounted() {
        console.log('mounted')
        this.initParam()
        this.setGrid()
        this.getCommCodeList('ZBAS_C_00500', 'eqpClCd') // 단말기구분코드
        this.getCommCodeList('ZDIS_C_00100', 'disStCd') // 재고상태
    },
    methods: {
        /* 공통코드 */
        getCommCodeList(codeId, columnId) {
            commonApi.getCommonCodeList(codeId).then((res) => {
                let columnValues = []
                let columnLabels = []
                if (res.length) {
                    res.forEach((data) => {
                        columnValues.push(data.commCdVal)
                        columnLabels.push(data.commCdValNm)
                    })
                }
                // 그리드 컬럼 콤보박스 데이터 설정
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'values',
                    columnValues
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'labels',
                    columnLabels
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'lookupDisplay',
                    true
                )
            })
        },
        /* 초기화 */
        init() {
            this.initParam()
            this.reqParam.regStaDt = SacCommon.getFirstday()
            this.reqParam.regEndDt = SacCommon.getToday()
            this.setGrid()
        },
        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                regStaDt: '',
                regEndDt: '',
                mfactCd: '',
                prodNm: '',
                serNum: '',
                mdlClCd: '',
                eqpClCd: '',
                demoYn: '',
                hldDealcoCd: '',
                hldDealcoNm: '',
                disStCd: '',
                pageSize: '',
                pageNum: 1,
            }
            this.reqParam.regStaDt = SacCommon.getFirstday()
            this.reqParam.regEndDt = SacCommon.getToday()

            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLvl'] = this.orgInfo['orgLvl']
                // this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.reqParam['hldDealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['hldDealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.gridDemo
            this.gridHeaderObj = this.$refs.gridHeaderDemo
            this.gridObj.setGridState(true, false, true)
            //체크박스 사용 가능여부
            this.gridObj.gridView.setCheckableExpression(
                "values['demoYn']='Y'", // 백엔드 데이터 'Y'로 바뀔것임 ***
                true
            )
            this.$refs.gridDemo.gridView.displayOptions.selectionStyle = 'rows'
            this.gridObj.setRows({})
        },
        gridSetData() {
            return new CommonGrid(-1, this.rowCnt, 10, 0, '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        /* 팝업 시 단건 조회 */
        // searchDemo() {
        //     const current = this.$refs.gridDemo.gridView.getCurrent().itemIndex
        //     var data =
        //         current !== -1
        //             ? this.$refs.gridDemo.gridView.getValues(current)
        //             : {}
        //     this.demo = data
        // },
        /* 시연재고 조회 - 최초 */
        search() {
            const startMonth = this.reqParam.regStaDt.substring(5, 7)
            const endMonth = this.reqParam.regEndDt.substring(5, 7)

            if (this.searchable === false) {
                this.showTcComAlert('등록일자를 지정해주세요.')
            } else if (startMonth !== endMonth) {
                this.showTcComAlert(
                    '등록일자의 시작일과 종료일을 동일한 월로 지정해 주세요.'
                )
            } else if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 입력 해 주세요.')
            } else {
                this.gridData.totalPage = 0
                this.searchForms = { ...this.reqParam }
                this.searchForms.pageSize = this.rowCnt
                this.searchForms.pageNum = 1

                this.searchForms.regStaDt = CommonUtil.onlyNumber(
                    this.reqParam.regStaDt
                )
                this.searchForms.regEndDt = CommonUtil.onlyNumber(
                    this.reqParam.regEndDt
                )
                // testdata
                // const teatdata = {
                //     regStaDt: '20220201',
                //     regEndDt: '20220228',
                //     orgLvl: '3',
                //     orgCd: 'AB1442',
                //     pageSize: this.rowCnt,
                //     pageNum: 1,
                // }
                // this.searchForms = { ...teatdata }
                // testdata
                this.getDisDemDemoDisMgmt(this.searchForms.pageNum)
            }
        },
        /* 시연재고 조회 - 페이징호출 */
        async getDisDemDemoDisMgmt(page) {
            this.searchForms.pageNum = page

            await demApi.getDemoDisMgmts(this.searchForms).then((res) => {
                console.log(res)
                if (res) {
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator(
                        res.pagingDto,
                        this.indicatorOpt
                    )
                    this.gridData = this.gridSetData()
                    this.gridData.totalPage = res.pagingDto.totalPageCnt
                    this.gridHeaderObj.setPageCount(res.pagingDto)
                }
                // else {
                //     this.showTcComAlert(
                //         '시연재고 검색 정보를 불러오지 못했습니다.'
                //     )
                // }
            })
        },
        /* 시연재고 해제 */
        async delDemo() {
            let pDatas = []
            let rows = this.gridObj.gridView.getCheckedRows(true)
            for (let i in rows) {
                const jsonRow = this.gridObj.dataProvider.getJsonRow(rows[i])
                pDatas.push(jsonRow)
            }
            const formdata = {
                rowDatas: pDatas,
            }

            console.log('formdata 해제데이터 ====> ', formdata)
            demApi.setDemoDisCnclMgmts(formdata).then(() => {
                // 화면재조회
                this.search()
            })
        },
        /* 시연재고 팝업 - 엑셀업로드, 신규, 해제 */
        openPop(index) {
            if (index === 1) {
                this.showDisDemDemoDisMgmtRgst = true
            }
            // else if (index === 2) {
            //     this.popupParamDel = {
            //         ...this.reqParam,
            //         ...this.searchParam,
            //         ...this.searchForm,
            //     }
            //     this.showDisDemDemoDelPop = true
            // }
            else if (index === 3) {
                this.popupParamNew = { ...this.reqParam }
                console.log('this.popupParamNew >> ', this.popupParamNew)
                this.showDisDemDemoCrePop = true
            }
        },
        /* 엑셀다운로드 */
        onClickDownload() {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dem/demoDisMgmtsExcelDown',
                this.searchForms
            )
        },
        onReturnDisDemDemoCre(retVal) {
            if (retVal) {
                // 화면재조회
                this.search()
            }
        },
        // 엑셀업로드 종료 후
        onReturnDisDemDemoDisMgmtRgst(retVal) {
            if (retVal) {
                // 화면 재조회
                this.search()
            }
        },
        /* 내부조직팝업 */
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.reqParam.orgCd
            this.searchParam.orgNm = this.reqParam.orgNm
            this.searchParam.orgLvl = this.reqParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                        this.searchForm.orgCd = this.reqParam.orgCd
                        this.searchForm.orgNm = this.reqParam.orgNm
                        this.searchForm.orgLvl = this.reqParam.orgLvl
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        /* 내부조직팝업 - Icon 이벤트 처리 */
        onAuthOrgTreeIconClick() {
            this.resultAuthOrgTreeRows = []
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        /* 내부조직팝업 - TextField 엔터키 이벤트 처리 */
        onAuthOrgTreeEnterKey() {
            this.resultAuthOrgTreeRows = []
            // if (_.isEmpty(this.reqParam.orgNm)) {
            //     this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
            //     return
            // }
            this.getAuthOrgTreeList()
        },
        /* 내부조직팝업 - TextField Input 이벤트 이벤트 처리 */
        onAuthOrgTreeInput() {
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
        },
        /* 내부조직팝업 - 팝업 리턴 이벤트 이벤트 처리 */
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.orgLvl = _.get(returnData, 'orgLvl')
            this.searchForm.orgCd = this.reqParam.orgCd
            this.searchForm.orgNm = this.reqParam.orgNm
            this.searchForm.orgLvl = this.reqParam.orgLvl
        },
        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            this.searchForm.dealcoCd = this.reqParam.hldDealcoCd
            this.searchForm.dealcoNm = this.reqParam.hldDealcoNm
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.hldDealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.hldDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.dealcoNm)) {
                this.getDealcosList()
                // this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요.')
                return
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.reqParam.hldDealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.reqParam.hldDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.hldDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================
        /* 현재일자 확인(yyyy-mm-dd)*/
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
    },
}
</script>
