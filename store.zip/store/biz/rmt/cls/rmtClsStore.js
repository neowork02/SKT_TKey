/*****************************************
* 업무 그룹명 : 일마감요청
* 서브 업무명 : 일마감요청
* 설 명 : 일마감요청 Store
* 작 성 자 : 전현주
* 작 성 일 : 2022.10.07
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 
* 변경사유/내역 : 
======================================
*****************************************/
// import send from '@/api/axios-tdcs'
// import _ from 'lodash'
// import moment from 'moment'

export default {
    namespaced: true,
    state: {
        storeParam: {
            orgCd: '',
            orgNm: '',
            orgLvl: '',
            dealcoCl: '',
            dealcoNm: '',
            dealcoCd: '',
            agencyCd: '',
            agencyNm: '',
            clsCl: '',
            reqCd: '',
            procDt_: '',
        },
    },
    mutations: {
        setStoreParam(state, data) {
            state.storeParam = data
        },
    },
    actions: {},
    getters: {},
}
