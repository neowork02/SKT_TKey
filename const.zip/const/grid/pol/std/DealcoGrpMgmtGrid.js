import { ValueType } from 'realgrid'

export let GRID_PROPERTYINFO_LIST = {
    fields: [
        // {
        //     fieldName: 'no', // 순번
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'grpNo', // 그룹번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpNm', // 그룹명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn', // 사용여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'regDealCnt', // 거래처수
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'aplyStaDt', // 적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt', // 적용종료일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 거래처그룹설명비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm', // 처리자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 처리일시
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'grpNo',
            fieldName: 'grpNo',
            type: 'data',
            width: '60',
            header: {
                text: '그룹번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealcoGrpNm',
            fieldName: 'dealcoGrpNm',
            type: 'data',
            width: '160',
            header: {
                text: '그룹명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            width: '60',
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                textReadOnly: true,
            },
        },
        {
            name: 'regDealCnt',
            fieldName: 'regDealCnt',
            type: 'data',
            width: '60',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '거래처수',
                showTooltip: false,
            },
            editor: {
                type: 'number',
                editFormat: '#,##0',
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            footer: {
                expression: 'sum',
            },
        },
        // {
        //     name: 'aplyStaDt',
        //     fieldName: 'aplyStaDt',
        //     type: 'data',
        //     width: '90',
        //     header: {
        //         text: '적용시작일자',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     /* 날짜형식으로 보여주기 YYYY-MM-DD */
        //     textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        //     editable: false,
        // },
        // {
        //     name: 'aplyEndDt',
        //     fieldName: 'aplyEndDt',
        //     type: 'data',
        //     width: '90',
        //     header: {
        //         text: '적용종료일자',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     /* 날짜형식으로 보여주기 YYYY-MM-DD */
        //     textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        //     editable: false,
        // },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '180',
            header: {
                text: '거래처그룹설명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '80',
            header: {
                text: '처리자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '110',
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],

    layout: [
        'grpNo', // 그룹번호
        'dealcoGrpNm', // 그룹명
        'useYn', // 사용여부
        'regDealCnt', // 거래처건수
        'aplyStaDtm', // 적용시작일자
        'aplyEndDtm', // 적용종료일자
        'rmks', // 거래처그룹설명비고
        'modUserId',
        'modUserNm',
        'modDtm',
    ],
}

export let GRID_PROPERTYINFO_APLY = {
    fields: [
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
            booleanFormat: 'N:Y',
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'sktChnlCd', // 채널코드
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'lvOrgNm', // 조직레벨0
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1', // 조직레벨1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2', // 조직레벨2
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpCd', // 거래처그룹코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1', // 거래처구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd2', // 거래처유형코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoCd', // 재고보유처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn', // 거래상태
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        // {
        //     name: 'orgTree',
        //     fieldName: 'orgTree',
        //     type: 'data',
        //     width: '120',
        //     header: {
        //         text: '조직',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },

        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '120',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },

        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '80',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '120',
            header: {
                text: '거래처',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        // {
        //     name: 'sktChnlCd',
        //     fieldName: 'sktChnlCd',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '채널코드',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm',
        //     fieldName: 'lvOrgNm',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨0',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm1',
        //     fieldName: 'lvOrgNm1',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨1',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm2',
        //     fieldName: 'lvOrgNm2',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨2',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        {
            name: 'dealcoGrpCd',
            fieldName: 'dealcoGrpCd',
            type: 'data',
            width: '80',
            header: {
                text: '거래처그룹',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            type: 'data',
            width: '80',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'dealcoClCd2',
            fieldName: 'dealcoClCd2',
            type: 'data',
            width: '80',
            header: {
                text: '거래처유형',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '재고보유처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        {
            name: 'dealEndYn',
            fieldName: 'dealEndYn',
            type: 'data',
            width: '80',
            header: {
                text: '거래상태',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
    ],

    layout: [
        // 'orgTree', //조직
        'dealSktCd', //매장코드
        'dealcoCd', // 거래처코드
        'dealcoNm', // 거래처명
        // 'sktChnlCd', // 채널코드
        // 'lvOrgNm', // 조직레벨0
        // 'lvOrgNm1', // 조직레벨1
        // 'lvOrgNm2', // 조직레벨2
        'dealcoGrpCd', // 거래처그룹코드
        'dealcoClCd1', // 거래처구분코드
        'dealcoClCd2', // 거래처유형코드
        'accDealcoCd', // 정산처코드
        'hldDealcoCd', // 재고보유처코드
        'dealEndYn', // 거래상태
    ],
}

export let GRID_PROPERTYINFO_RGST = {
    fields: [
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
            booleanFormat: 'N:Y',
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'sktChnlCd', // 채널코드
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'lvOrgNm', // 조직레벨0
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1', // 조직레벨1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2', // 조직레벨2
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpCd', // 거래처그룹코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1', // 거래처구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd2', // 거래처유형코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoCd', // 재고보유처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn', // 거래상태
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            type: 'data',
            width: '120',
            header: {
                text: '조직',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },

        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '120',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '80',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '120',
            header: {
                text: '거래처',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        // {
        //     name: 'sktChnlCd',
        //     fieldName: 'sktChnlCd',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '채널코드',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm',
        //     fieldName: 'lvOrgNm',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨0',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm1',
        //     fieldName: 'lvOrgNm1',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨1',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        // {
        //     name: 'lvOrgNm2',
        //     fieldName: 'lvOrgNm2',
        //     type: 'data',
        //     width: '80',
        //     header: {
        //         text: '조직레벨2',
        //         showTooltip: false,
        //     },
        //     styleName: 'left-column',
        //     editable: false,
        // },
        {
            name: 'dealcoGrpCd',
            fieldName: 'dealcoGrpCd',
            type: 'data',
            width: '80',
            header: {
                text: '거래처그룹',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            type: 'data',
            width: '80',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'dealcoClCd2',
            fieldName: 'dealcoClCd2',
            type: 'data',
            width: '80',
            header: {
                text: '거래처유형',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '재고보유처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        {
            name: 'dealEndYn',
            fieldName: 'dealEndYn',
            type: 'data',
            width: '80',
            header: {
                text: '거래상태',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
    ],

    layout: [
        'dealcoCd', // 거래처코드
        'dealcoNm', // 거래처명
        // 'sktChnlCd', // 채널코드
        // 'lvOrgNm', // 조직레벨0
        // 'lvOrgNm1', // 조직레벨1
        // 'lvOrgNm2', // 조직레벨2
        'dealcoGrpCd', // 거래처그룹코드
        'dealcoClCd1', // 거래처구분코드
        'dealcoClCd2', // 거래처유형코드
        'accDealcoCd', // 정산처코드
        'hldDealcoCd', // 재고보유처코드
        'dealEndYn', // 거래상태
    ],
}
