import { ValueType } from 'realgrid'

export const DisDsmTovrRtDtlGRID_HEADER = {
    fields: [
        {
            fieldName: 'disTyp',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disAmt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsPlcIdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inPlcIdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disTerm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'movInDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disHldDay',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'demoYnNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'openYnNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badYnNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fstInAgencyNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'disTyp',
            fieldName: 'disTyp',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고이력',
                showTooltip: false,
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'disAmt',
            fieldName: 'disAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
        },
        {
            name: 'prchsPlcIdNm',
            fieldName: 'prchsPlcIdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매입처',
                showTooltip: false,
            },
        },
        {
            name: 'inFixDt',
            fieldName: 'inFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고날자',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcIdNm',
            fieldName: 'inPlcIdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처',
                showTooltip: false,
            },
        },
        {
            name: 'prchTypNm',
            fieldName: 'prchTypNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구매유형',
                showTooltip: false,
            },
        },
        {
            name: 'disTerm',
            fieldName: 'disTerm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고기간',
                showTooltip: false,
            },
        },
        {
            name: 'movInDt',
            fieldName: 'movInDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동일자',
                showTooltip: false,
            },
        },
        {
            name: 'disHldDay',
            fieldName: 'disHldDay',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유기간',
                showTooltip: false,
            },
        },
        {
            name: 'demoYnNm',
            fieldName: 'demoYnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '시연재고 여부',
                showTooltip: false,
            },
        },
        {
            name: 'openYnNm',
            fieldName: 'openYnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개봉구분',
                showTooltip: false,
            },
        },
        {
            name: 'badYnNm',
            fieldName: 'badYnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량여부',
                showTooltip: false,
            },
        },
        {
            name: 'badDt',
            fieldName: 'badDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량등록일',
                showTooltip: false,
            },
        },
        {
            name: 'disStNm',
            fieldName: 'disStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고상태',
                showTooltip: false,
            },
        },
        {
            name: 'fstInAgencyNm',
            fieldName: 'fstInAgencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초입고대리점',
                showTooltip: false,
            },
        },
    ],
}
