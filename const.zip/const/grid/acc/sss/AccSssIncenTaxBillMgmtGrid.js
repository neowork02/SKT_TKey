import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'accYm',
            dataType: ValueType.TEXT,
            Text: 'yyyyMM',
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc1',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt1',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totAmt1',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'erpTrnsYn1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrnsYn1Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chk2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc2',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt2',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totAmt2',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'erpTrnsYn2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrnsYn2Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sumSplyPrc',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sumVatAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sumTotAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'accYm',
            fieldName: 'accYm',
            type: 'data',
            header: { text: '정산월', excelName: '정산월' },
            width: '150',
            datetimeFormat: 'yyyy-MM',
            visible: false,
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점', excelName: '대리점' },
            width: '150',
            editable: false,
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: { text: '대리점명', excelName: '대리점명' },
            width: '200',
            editable: false,
            footer: {
                text: '합계',
            },
        },
        {
            name: 'splyPrc1',
            fieldName: 'splyPrc1',
            type: 'data',
            header: { text: '공급가', excelName: '공급가' },
            width: '110',
            editable: false,
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'vatAmt1',
            fieldName: 'vatAmt1',
            type: 'data',
            header: { text: '세액', excelName: '세액' },
            width: '110',
            numberFormat: '#,###,###,##0',
            editable: false,
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'totAmt1',
            fieldName: 'totAmt1',
            type: 'data',
            header: { text: '합계', excelName: '합계' },
            width: '110',
            editable: false,
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'erpTrnsYn1',
            fieldName: 'erpTrnsYn1',
            type: 'data',
            header: { text: 'ERP 전송여부코드', excelName: 'ERP 전송여부코드' },
            width: '150',
            editable: false,
            visible: false,
        },
        {
            name: 'erpTrnsYn1Nm',
            fieldName: 'erpTrnsYn1Nm',
            type: 'data',
            header: { text: 'ERP전송', excelName: 'ERP전송' },
            width: '100',
            editable: false,
        },
        {
            name: 'chk2',
            fieldName: 'chk2',
            width: '50',
            type: 'data',
            editable: false,
            renderer: {
                type: 'check',
                editable: true,
                trueValues: '1,Y',
                falseValues: '0,N',
            },
            header: {
                checkLocation: 'left',
                styleName: 'orange-column',
            },
            checked: false,
            styleCallback: function (grid, dataCell) {
                var ret = {}
                var chk2 = grid.getValue(dataCell.index.itemIndex, 'chk2')

                if (chk2 == 'E') {
                    ;(ret.renderer = { type: 'text' }), (ret.editable = false)
                }

                return ret
            },
            displayCallback: function () {
                return ''
            },
            footer: {
                text: '합계',
            },
        },
        {
            name: 'splyPrc2',
            fieldName: 'splyPrc2',
            type: 'data',
            header: { text: '공급가', excelName: '공급가' },
            width: '110',
            editable: false,
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'vatAmt2',
            fieldName: 'vatAmt2',
            type: 'data',
            header: { text: '세액', excelName: '세액' },
            width: '110',
            editable: false,
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'totAmt2',
            fieldName: 'totAmt2',
            type: 'data',
            header: { text: '합계', excelName: '합계' },
            width: '110',
            editable: false,
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'erpTrnsYn2',
            fieldName: 'erpTrnsYn2',
            type: 'data',
            header: { text: 'ERP 전송여부코드', excelName: 'ERP 전송여부코드' },
            width: '150',
            editable: false,
            visible: false,
        },
        {
            name: 'erpTrnsYn2Nm',
            fieldName: 'erpTrnsYn2Nm',
            type: 'data',
            header: { text: 'ERP전송', excelName: 'ERP전송' },
            width: '100',
            editable: false,
        },
        {
            name: 'sumSplyPrc',
            fieldName: 'sumSplyPrc',
            type: 'data',
            header: { text: '공급가', excelName: '공급가' },
            width: '110',
            editable: false,
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'sumVatAmt',
            fieldName: 'sumVatAmt',
            type: 'data',
            header: { text: '세액', excelName: '세액' },
            width: '110',
            editable: false,
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'sumTotAmt',
            fieldName: 'sumTotAmt',
            type: 'data',
            header: { text: '합계', excelName: '합계' },
            width: '110',
            editable: false,
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
    ],
    layout: [
        'agencyCd',
        'agencyNm',
        {
            name: 'amt1',
            direction: 'horizontal',
            items: ['splyPrc1', 'vatAmt1', 'totAmt1'],
            header: { text: '1차 발급' },
        },
        'erpTrnsYn1Nm',
        'chk2',
        {
            name: 'amt2',
            direction: 'horizontal',
            items: ['splyPrc2', 'vatAmt2', 'totAmt2'],
            header: { text: '2차 발급' },
        },
        'erpTrnsYn2Nm',
        {
            name: 'amtSum',
            direction: 'horizontal',
            items: ['sumSplyPrc', 'sumVatAmt', 'sumTotAmt'],
            header: { text: '인센티브합계' },
        },
    ],
}
