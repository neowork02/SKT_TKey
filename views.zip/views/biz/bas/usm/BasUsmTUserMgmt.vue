<template>
    <div class="content">
        <TCComAlert
            v-model="showAlertBool"
            :headerText="headerText"
            :bodyText="alertBodyText"
        ></TCComAlert>
        <!-- Tit -->
        <h1>사용자관리</h1>
        <!-- // Tit -->

        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <!--
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onShowUsmCurnt"
                    >테스트버튼</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onShowUsmInfoUpdate"
                    >테스트버튼2</TCComButton
                >
                -->
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <!--
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onUserRgstClick"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
                -->
                <BasUsmTUserRgst
                    v-if="showBasUsmTUserRgst"
                    :parentParam="searchUsmUserRgstParam"
                    :rows="resultUsmUserRgstRows"
                    :dialogShow.sync="showBasUsmTUserRgst"
                />
                <!-- 사용자현행화팝업 -->
                <BasUsmCurntPopup
                    v-if="showUsmCurnt"
                    :parentParam="searchCurntParam"
                    :rows="resultCurntRows"
                    :dialogShow.sync="showUsmCurnt"
                    @confirm="onUsmCurntReturnData"
                />
                <!-- 사용자정보업데이트팝업 -->
                <BasUsmInfoUpdatePopup
                    v-if="showUsmInfoUpdate"
                    :parentParam="searchInfoUpdateParam"
                    :rows="resultInfoUpdateRows"
                    :dialogShow.sync="showUsmInfoUpdate"
                    @confirm="onUsmInfoUpdateReturnData"
                />
            </li>
        </ul>
        <!-- // Top BTN -->

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- <div class="formitem div5_1">
                     as-is 하드코딩 
                     <TCComComboBox
                        :itemList="this.ds_searchCon"
                        labelName="조회조건"
                        v-model="div_search.cmbSchCon"
                        :objAuth="this.objAuth"
                        @change="cmb_SchCon_OnChanged"
                    ></TCComComboBox> 
                </div> -->
                <!-- <div class="formitem div5_1" v-show="userGrpShow">
                    <TCComComboBox
                        codeId="ZBAS_C_00250"
                        labelName="사용자그룹"
                        v-model="div_search.cmb_UserGrp"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div> -->
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="attcCatList"
                        v-model="div_search.attcClCd"
                        labelName="소속유형"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        @change="cmb_attcCat_OnChanged"
                        :eRequired="true"
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>

                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="commUserGrpList"
                        v-model="div_search.userGrp"
                        labelName="권한그룹"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="objAuth"
                        :disabled="disabledUserGrp"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchAuthOrgTreeParam.orgNm"
                        :codeVal.sync="searchAuthOrgTreeParam.orgCd"
                        labelName="조직구분"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :eRequired="true"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchAuthOrgTreeParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="div_search.edt_UserId"
                        labelName="사용자 ID"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
            </div>

            <div class="searchform">
                <div class="formitem div4" v-show="userNmShow">
                    <TCComInput
                        v-model="div_search.edt_UserNm"
                        labelName="성명"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
                <!-- <div class="formitem div5_1" v-show="userCdShow">
                    <TCComInput
                        v-model="div_search.edt_UserCd"
                        labelName="사번"
                        :objAuth="objAuth"
                    >
                    </TCComInput>
                </div> -->

                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="ds_effYn"
                        labelName="유효사용자여부"
                        v-model="div_search.cmbEffUserYn"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>

                <!--<div class="formitem div5_1">
                     <TCComRadioBox
                        v-model="div_search.rdo_SearchCl"
                        :itemList="ds_SearchCl"
                        labelName="조직구분"
                        :objAuth="this.objAuth"
                    ></TCComRadioBox> 
                </div>-->

                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchForm.dealcoNm"
                        :codeVal.sync="searchForm.dealcoCd"
                        labelName="근무지"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                        :disabled="this.dealcoDisabled"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>

                <div class="formitem div4">
                    <TCComInput
                        v-model="div_search.edtPortalId"
                        labelName="통합 LOGIN ID"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
            </div>
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{ ' btn_ty_exp_active ': toggleActive }"
                        @click="toggleActive = !toggleActive"
                    >
                    </v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="toggleActive">
                    <div class="searchform">
                        <div class="formitem div4">
                            <TCComInput
                                v-model="div_search.sktId"
                                labelName="Swing ID"
                                :objAuth="objAuth"
                                @enterKey="onSearch"
                            >
                            </TCComInput>
                        </div>
                        <div class="formitem div4">
                            <TCComInput
                                v-model="div_search.edit0"
                                labelName="연락처"
                                :objAuth="objAuth"
                                @enterKey="onSearch"
                            >
                            </TCComInput>
                        </div>
                        <div class="formitem div2"></div>
                    </div>
                </div>
            </v-expand-transition>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="사용자목록"
                :gridObj="gridObj1"
                :isPageRows="true"
                :isExceldown="true"
                :isPageCnt="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :editable="true"
                :movable="false"
                :columnMovable="false"
                :fields="view.fields"
                :columns="view.columns"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="gridData1.totalPage"
                :apiFunc="getUserList"
                :rowCnt="rowCnt"
                :gridObj="gridObj1"
                @input="chgRowCnt1"
            />
        </div>
        <!--
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader2"
                ref="gridHeader2"
                gridTitle="통합SSO 사용자 정보"
                :gridObj="gridObj2"
                :isPageRows="true"
                :isPageCnt="true"
            />
            <TCRealGrid
                id="grid2"
                ref="grid2"
                :editable="true"
                :movable="false"
                :columnMovable="false"
                :fields="view2.fields"
                :columns="view2.columns"
                :styles="gridStyle"
            />
        </div>
        -->
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
// import commonApi from '@/api/common/commonCode'
import { HEADER, HEADER2 } from '@/const/grid/bas/usm/basUsmTUserMgmtHeader'
import API from '@/api/biz/bas/usm/basUsmUserMgmt'
import _ from 'lodash'
import CommonMixin from '@/mixins'
import attachedFileApi from '@/api/common/attachedFile'
//====================사용자등록팝업====================
import BasUsmTUserRgst from '@/views/biz/bas/usm/BasUsmTUserRgst'
//====================사용자등록팝업====================
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처(권한조직)====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처(권한조직)==================
//====================//사용자 현행화 팝업==================
import BasUsmCurntPopup from '@/views/biz/bas/usm/BasUsmCurntPopup'
//====================//사용자 현행화 팝업==================
import BasUsmInfoUpdatePopup from '@/views/biz/bas/usm/BasUsmInfoUpdatePopup'

export default {
    name: 'BasUsmUserMgmt',
    mixins: [CommonMixin],
    props: {},
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
        BasUsmTUserRgst,
        BasUsmCurntPopup,
        BasUsmInfoUpdatePopup,
    },

    data() {
        return {
            // gridStyle: {
            //     height: '350px', //그리드 높이 조절
            // },
            active: false,
            gridObj: {},
            gridObj1: {},
            gridHeaderObj1: {},
            // gridObj2: {},
            gridHeaderObj2: {},
            gridData1: {},
            gridData2: {},
            localDialogShow: false,
            view: HEADER,
            view2: HEADER2,
            clickState: null,
            commUserGrpOriginList: [],
            commUserGrpList: [],
            toggleActive: false,
            checkBoxItems: [
                { id: 1, isChecked: true },
                { id: 2, isChecked: false },
                { id: 3, isChecked: false, label: '미체크 상태 박스' },
                { id: 4, isChecked: true, label: '체크 상태 박스' },
            ],
            ds_searchCon: [
                {
                    commCdVal: 'userGrp',
                    commCdValNm: '사용자그룹',
                },
                {
                    commCdVal: 'userNm',
                    commCdValNm: '성명',
                },
                {
                    commCdVal: 'userId',
                    commCdValNm: '사번',
                },
            ],
            // ds_userGrp: [],
            ds_effYn: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
                {
                    commCdVal: 'Z',
                    commCdValNm: '미매핑',
                },
            ],
            // ds_SearchCl: [
            //     {
            //         commCdVal: '1',
            //         commCdValNm: '관리조직',
            //     },
            //     {
            //         commCdVal: '2',
            //         commCdValNm: '원소속조직',
            //     },
            // ],
            attcCatList: [],
            ds_condition: {},
            div_search: {
                attcClCd: '',
                userGrp: '',
                cmbSchCon: 'userGrp',
                edt_UserNm: '',
                edt_UserCd: '',
                cmb_UserGrp: '',
                cmbEffUserYn: 'Y',
                edt_UserId: '',
                rdo_SearchCl: '1',
                cdiv_authOrg: '',
                cdiv_deal: '',
                edtPortalId: '',
                edit0: '',
                sktId: '', // 구 ukeyId
            },
            objAuth: {},
            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            // userGrpShow: true,
            userNmShow: true,
            // userCdShow: false,
            // paging처리 관련
            rowCnt: 15,
            dealcoDisabled: false,
            disabledUserGrp: false,
            layout: [
                'biMapping',
                'hrMapping',
                'userId',
                'sktId',
                'portalUserId',
                'userNm',
                'effUserYn',
                'rpsty_nm',
                'attcClCd',
                'userStCd',
                'userCd',
                'userGrpCd',
                'orgNm',
                'org_area',
                'org_area_nm',
                'entDt',
                'retirDt',
                'm_bu_nm',
                'bizChrgOrgCdNm',
                'm_sen_nm',
                'ptOrgCdNm',
                'out_org_nm',
                'repMblPhonNo',
                'wphonNo',
                'modDtm',
                'modUserId',
                'lastLogin',
                'mblPhonNo',
                'mblPhonNo2',
                'mblPhonNo3',
                'happy_sms1',
                'happy_sms2',
                'happy_sms3',
                'accSmsYn1',
                'accSmsYn2',
            ],
            //====================신규등록팝업관련====================
            showBasUsmTUserRgst: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchUsmUserRgstParam: {
                PV_USER_ID: '',
                sPortalId: '', // 통합 Login ID
                sInUserId: '', // 사용자 ID
                sInStatus: '', // 상태값(M:상세조회 및 비번수정, N:신규)
                sInModFlag: '', // 본인 여부(true: 본인은 비번 수정가능, false: 타인은 조회만 가능)
                sOrgID: '',
                sRelOrgID: '',
                sChannelCD: '',
                sUserGrp: '',
                sEffSta: '',
                sEffEnd: '',
                searchParam: this.ds_condition,
            },
            resultUsmUserRgstRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //================================================================
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchAuthOrgTreeParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                orgLvl: '',
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처(권한조직)====================
            showBasBcoDealcos: false,
            searchForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한조직)==================
            //====================//사용자 현행화 팝업 ==================
            showUsmCurnt: false,
            searchCurntParam: {},
            resultCurntRows: [],
            //====================//사용자 정보 업데이트 팝업 ==================
            showUsmInfoUpdate: false,
            searchInfoUpdateParam: {},
            resultInfoUpdateRows: [],
        }
    },

    created() {
        this.init()
        console.log('this.$route Detail: ', this.$route)
        // this.searchParam = this.$route.params.search
    },

    mounted() {
        this.gridHeaderObj1 = this.$refs.gridHeader1
        // this.gridHeaderObj2 = this.$refs.gridHeader2
        this.gridObj1 = this.$refs.grid1
        // this.gridObj2 = this.$refs.grid2
        console.log('gridObj1', this.gridObj1)

        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)
        this.initGrid()

        // 공통코드 API
        // this.getCommCodeList('ZBAS_C_00250')

        // 사용자 권한그룹 목록 조회
        this.getGetUserGrpLst()
        this.dropDownSetting()

        // 싱글클릭 시 통합sso 사용자정보 조회
        // this.gridObj1.gridView.onCellClicked = (grid, clickData) => {
        //     console.log('통합sso 사용자정보 조회', clickData)
        //     clearTimeout(this.clickState)
        //     this.clickState = setTimeout(() => {
        //         console.log('onCellClicked', clickData)
        //         const jsonData = this.gridObj1.dataProvider.getJsonRow(
        //             clickData.dataRow
        //         )
        //         this.getPortalUserInfo(jsonData)
        //     }, 200)
        // }
        // 더블클릭 시 등록팝업오픈
        this.gridObj1.gridView.onCellDblClicked = (grid, clickData) => {
            console.log('등록팝업오픈', clickData)
            clearTimeout(this.clickState)
            const jsonData = this.gridObj1.dataProvider.getJsonRow(
                clickData.dataRow
            )
            this.grd_list_OnCellDblClick(jsonData)
        }
        // "PS&Marketing" 이 아닐 시에 해당 컬럼 숨김
        if (this.orgInfo.orgCdLvl0 != 'O00000') {
            this.gridObj1.gridView.columnByName('biMapping').visible = false
            this.gridObj1.gridView.columnByName('hrMapping').visible = false
        }
        // 근무지코드 조회
        this.searchForm.dealcoCd = this.userInfo.dealcoCd
        this.searchForm.dealcoNm = this.userInfo.dealcoNm
        // 조직코드 조회
        this.searchAuthOrgTreeParam.orgCd = this.orgInfo.orgCd
        this.searchAuthOrgTreeParam.orgNm = this.orgInfo.orgNm
        this.searchAuthOrgTreeParam.orgLvl = this.orgInfo.orgLvl
    },
    methods: {
        async init() {
            CommonMsg.$_log('init 함수호출')
            this.gridData1 = this.gridSetData()
        },

        async initGrid() {
            // this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            // this.gridObj2.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

            this.gridObj1.setGridState(false, false, false, false)
            // this.gridObj2.setGridState()
            // this.gridObj1.gridView.setColumnLayout(this.layout)

            // this.gridObj1.setRows(this.rows)
            // this.gridObj2.setRows(this.rows)

            // this.getAuthOrgTreeList()
            // this.getDealcosList()
        },

        gridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt1(val) {
            this.rowCnt = val
        },
        /* 다음페이지 노출여부 */
        isShowNext(pageInfo) {
            this.showNext =
                pageInfo.totalDataCnt === pageInfo.pageSize ? true : false
        },

        // 그리드에 dropdown셋팅 공통코드 api
        async dropDownSetting() {
            console.log('dropDownSetting')

            // 소속유형
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00380',
                columnName: 'attcCat',
                option: '전체',
            })
        },

        async dropDownCmmonCodes({ key, columnName, option }) {
            console.log('key columnName option', key, columnName, option)
            let result = await API.dropDownCmmonCodes_(key)
            console.log('result', result)

            if (columnName == 'attcCat') {
                this.attcCatList = result
                console.log('resultAttcCat', result)
                // "PS&Marketing" 일시에 해당 대리점/판매점 콤보박스에서 숨김
                // if (this.orgInfo.orgCdLvl0 == 'O00000') {
                //     this.attcCatList = this.attcCatList
                //         .filter((p) => p.commCdVal != 'D')
                //         .filter((p) => p.commCdVal != 'P')
                // } else {
                this.attcCatList = this.attcCatList
                    .filter((p) => p.commCdVal != '1')
                    .filter((p) => p.commCdVal != '3')
                    .filter((p) => p.commCdVal != '4')
                    .filter((p) => p.commCdVal != '9')
                // .filter((p) => p.commCdVal == 'P')
                // }
            }
        },

        // 공통코드 API
        // getCommCodeList(codeId) {
        //     commonApi.getCommonCodeListById(codeId).then((res) => {
        //         if (res !== undefined) {
        //             this.commUserGrpOriginList = res
        //             // this.dCommItemList = res
        //         }
        //     })
        // },

        // 사용자 권한 목록조회
        getGetUserGrpLst() {
            API.getGetUserGrpLst().then((res) => {
                if (res !== undefined) {
                    this.commUserGrpOriginList = res
                    this.commUserGrpList = res
                    // this.dCommItemList = res
                }
            })
        },

        //===================== 등록팝업신규 methods ================================

        onUserRgstClick(jsonData) {
            this.resultUsmUserRgstRows = []
            this.searchUsmUserRgstParam = {
                orgParam: this.searchAuthOrgTreeParam,
                dealParam: this.searchForm,
                commUserGrpOriginList: this.commUserGrpOriginList,
                commUserGrpList: this.commUserGrpList,
                portalUserId: jsonData.portalUserId,
                selectedUserData: jsonData,
                sInStatus: 'N',
            }
            this.showBasUsmTUserRgst = true
        },

        //===================== //등록팝업수정 methods ================================
        onUserUpdateClick(jsonData) {
            this.resultUsmUserRgstRows = []
            this.searchUsmUserRgstParam = {
                orgParam: this.searchAuthOrgTreeParam,
                dealParam: this.searchForm,
                commUserGrpOriginList: this.commUserGrpOriginList,
                commUserGrpList: this.commUserGrpList,
                PV_USER_ID: jsonData.userId,
                sInUserId: jsonData.userId,
                selectedUserData: jsonData,
                sInStatus: 'M',
                sInModFlag: 'true',
            }
            this.showBasUsmTUserRgst = true
            // }
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchAuthOrgTreeParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    let cnt = 0

                    res.map((p) => {
                        if (p.orgLvl == '3') {
                            cnt++
                        }
                    })

                    if (cnt === 1) {
                        res.map((p) => {
                            this.searchAuthOrgTreeParam.orgCd = _.get(
                                p,
                                'orgCd'
                            )
                            this.searchAuthOrgTreeParam.orgNm = _.get(
                                p,
                                'orgNm'
                            )
                            this.searchAuthOrgTreeParam.orgLvl = _.get(
                                p,
                                'orgLvl'
                            )
                        })
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            // if (!_.isEmpty(this.searchAuthOrgTreeParam.orgNm)) {
            //     this.getAuthOrgTreeList()
            // } else {
            this.showBcoAuthOrgTrees = true
            // }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchAuthOrgTreeParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchAuthOrgTreeParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchAuthOrgTreeParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchAuthOrgTreeParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchAuthOrgTreeParam.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================

        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.searchForm.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.searchForm.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.searchForm.dealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchForm.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-전체조직명 입력해주세요.'
                return
            }
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.searchForm.dealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchForm.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.searchForm.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직)팝업관련 methods ================================

        btnChange: function () {
            console.log('테스트')
        },

        // 초기화
        onResetPage() {
            // CommonUtil.clearPage(this.$router)
            // CommonUtil.clearPage(this, 'div_search')
            // this.div_search = {
            //     attcClCd: '',
            //     userGrp: '',
            //     cmbSchCon: 'userGrp',
            //     edt_UserNm: '',
            //     edt_UserCd: '',
            //     cmb_UserGrp: '',
            //     cmbEffUserYn: 'Y',
            //     edt_UserId: '',
            //     rdo_SearchCl: '1',
            //     cdiv_authOrg: '',
            //     cdiv_deal: '',
            //     edtPortalId: '',
            //     edit0: '',
            //     sktId: '',
            // }
            CommonUtil.clearPage(this, 'div_search')
            // this.gridData1 = this.gridSetData()
            this.gridObj1.dataProvider.clearRows()

            this.init()
        },

        //조회 버튼
        onSearch() {
            //첫 조회시 표시할 행의 갯수
            // this.ds_condition.pageSize = this.rowCnt
            // this.ds_condition.pageNum = 1 //첫번째 페이지
            this.gridData1.totalPage = 0 // 이전페이지정보 초기화
            this.gridData2.totalPage = 0 // 이전페이지정보 초기화
            //API호출
            // this.setAxiosLoadingBar(true) //로딩바 작동
            this.getUserList(1)
        },

        //API 호출
        getUserList: function (pageNum) {
            console.log('orgLvlCd : ', this.searchAuthOrgTreeParam.orgLvl)
            console.log('serachGubnCd : ', this.div_search.cmbSchCon)
            this.gridObj1.setRows()
            // this.gridObj2.setRows()

            this.ds_condition = {
                orgCd:
                    this.div_search.cmb_attcCat != '1'
                        ? this.searchAuthOrgTreeParam.orgCd
                        : null,
                orgNm: this.searchAuthOrgTreeParam.orgNm,
                orgLvlCd: this.searchAuthOrgTreeParam.orgLvl
                    ? this.searchAuthOrgTreeParam.orgLvl
                    : 0,
                dealcoCd: this.searchForm.dealcoCd,
                serachGubnCd: this.div_search.rdo_SearchCl,
                // ? parseInt(this.div_search.rdo_SearchCl)
                // : 99,
                userNm: this.div_search.edt_UserNm,
                userCd: this.div_search.edt_UserCd,
                // userGrpCd: this.div_search.cmb_UserGrp,
                userGrpCd: this.div_search.userGrp,
                attcClCd: this.div_search.attcClCd,
                userId: this.div_search.edt_UserId,
                poratlUserId: this.div_search.edtPortalId,
                sktId: this.div_search.sktId,
                effUserYn: this.div_search.cmbEffUserYn,
                tel: this.div_search.edit0,
            }
            this.ds_condition.pageNum = pageNum
            this.ds_condition.pageSize = this.rowCnt

            console.log('this.ds_condition : ', this.ds_condition)
            API.getUserList(this.ds_condition).then((result) => {
                let list = result.gridList
                // result.gridList[idx].effUserYn
                list.map((p) => {
                    p.effUserYn === 'Z' ? (p.effUserYn = '미매핑') : p.effUserYn
                    // p.repMblPhonNo = p.repMblPhonNo
                    //     ? p.repMblPhonNo.substring(0, 3) +
                    //       '-' +
                    //       p.repMblPhonNo.substring(3, 7) +
                    //       '-' +
                    //       p.repMblPhonNo.substring(7, 11)
                    //     : ''
                    p.lastLogin
                        ? (p.lastLogin = CommonUtil.addDashDate(p.lastLogin))
                        : null
                    // p.effUserYn === 'Z' ? (p.effUserYn = '미매핑') : p.effUserYn,
                    this.commUserGrpOriginList.map((f) => {
                        if (f.commCdVal == p.userGrpCd) {
                            p.userGrpNm = f.commCdValNm
                        }
                    })
                })
                // result.gridList.map((p) => {
                //     p.userGrpCd = this.commUserGrpList.filter(
                //         (f) => f.commCdVal == p.userGrpCd
                //     )
                // })

                this.gridObj1.setRows(result.gridList)
                this.gridData1 = this.gridSetData() //초기화
                this.isShowNext(result.pagingDto)
                this.gridData1.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj1.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting

                // 통합sso 사용자정보 조회
                // if (result.gridList.length > 0) {
                //     this.getPortalUserInfo(result.gridList[0])
                // }
                console.log('조회완료')
            })
        },

        async onCell() {
            console.log('onCellonCellonCellonCell')
            this.gridObj1.gridView.onCellClicked = (grid, clickData) => {
                console.log('통합sso 사용자정보 조회', clickData)
                console.log('통합sso 사용자정보 조회grid', grid)
                clearTimeout(this.clickState)
                this.clickState = setTimeout(function () {
                    console.log('onCellClicked', clickData)
                }, 200)

                const jsonData = this.gridObj1.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.getPortalUserInfo(jsonData)
            }
            this.gridObj1.gridView.onCellDblClicked = (grid, clickData) => {
                console.log('통합sso 사용자정보 조회2', clickData)
                clearTimeout(this.clickState)

                const jsonData = this.gridObj1.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.grd_list_OnCellDblClick(jsonData)
            }
        },

        // ClearClickState() {
        //     clearTimeout(this.clickState)
        //     this.clickState = null
        // },

        // 목록 Grid에서 사용자를 선택한 경우 Portal SSO 정보 보여주기
        getPortalUserInfo(jsonData) {
            console.log('jsonData', jsonData)

            let params = {
                portalUserId: jsonData.portalUserId
                    ? jsonData.portalUserId
                    : '',
                userId: jsonData.userId ? jsonData.userId : '',
            }

            API.getPortalUserInfo(params).then((result) => {
                this.gridObj2.setRows(result)

                // // 페이징 관련
                // this.gridObj2.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                // this.gridData2 = this.gridSetData() //초기화
                // this.gridData2.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                // this.gridHeaderObj2.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting

                console.log('조회완료')
            })
        },

        // 더블클릭시 사용자등록 팝업 호출
        grd_list_OnCellDblClick(jsonData) {
            //사용자상세팝업:: 팝업에 전송할 파라메터 세팅
            // cf_setPopupParam(
            //     'PV_USER_ID',
            //     ds_output_1.getColumn(nRow, 'USER_ID')
            // ) //사용자ID
            // cf_setPopupParam(
            //     'sInUserId',
            //     ds_output_1.getColumn(nRow, 'USER_ID')
            // ) //사용자ID
            // cf_setPopupParam('sInStatus', 'M')
            // cf_setPopupParam('sInModFlag', 'true')
            // //사용자상세
            // cf_callPopup('BAS::BASUSM00400.xml')
            // this.searchUsmUserRgstParam = {
            //     orgParam: this.searchAuthOrgTreeParam,
            //     dealParam: this.searchForm,
            //     PV_USER_ID: jsonData.userId,
            //     sInUserId: jsonData.userId,
            //     sInStatus: 'M',
            //     sInModFlag: 'true',
            // }
            // this.searchUsmUserRgstParam.PV_USER_ID = jsonData.userId
            // this.searchUsmUserRgstParam.sInUserId = jsonData.userId
            // this.searchUsmUserRgstParam.sInStatus = 'M'
            // this.searchUsmUserRgstParam.sInModFlag = 'true'

            // 신규
            if (_.isEmpty(jsonData.userId)) {
                this.onUserRgstClick(jsonData)
            } else {
                // 수정
                this.onUserUpdateClick(jsonData)
            }
        },

        // 조회조건 변경 이벤트
        // cmb_SchCon_OnChanged(e) {
        //     console.log('cmbSchConcmbSchConcmbSchConcmbSchConcmbSchCon', e)
        //     if (e == 'userGrp') {
        //         console.log('userGrp')
        //         this.userGrpShow = true
        //         this.userNmShow = false
        //         this.userCdShow = false
        //         // div_search.lbl_UserGrp.Visible = true
        //         // div_search.cmb_UserGrp.Visible = true
        //         // div_search.lbl_UserNm.Visible = false
        //         // div_search.edt_UserNm.Visible = false
        //         // div_search.edt_UserNm.Text = ''
        //         // div_search.lbl_UserCd.Visible = false
        //         // div_search.edt_UserCd.Visible = false
        //         // div_search.edt_UserCd.Text = ''
        //         this.div_search.edt_UserNm = '' //.SetColumn(0, 'user_nm', '')
        //         this.div_search.edt_UserCd = '' //.SetColumn(0, 'user_id', '')
        //         this.div_search.cmbSchCon = 'userGrp'
        //     } else if (e == 'userNm') {
        //         console.log('userNm')
        //         this.userGrpShow = false
        //         this.userNmShow = true
        //         this.userCdShow = false
        //         // div_search.lbl_UserGrp.Visible = false
        //         // div_search.cmb_UserGrp.Visible = false
        //         // div_search.cmb_UserGrp.Value = ''
        //         // div_search.lbl_UserNm.Visible = true
        //         // div_search.edt_UserNm.Visible = true
        //         // div_search.lbl_UserCd.Visible = false
        //         // div_search.edt_UserCd.Visible = false
        //         // div_search.edt_UserCd.Text = ''
        //         // ds_condition.SetColumn(0, 'user_grp', '')
        //         this.div_search.cmbSchCon = 'userNm'
        //         // div_search.edt_UserNm.SetFocus()
        //     } else if (e == 'userId') {
        //         console.log('userId')
        //         this.userGrpShow = false
        //         this.userNmShow = false
        //         this.userCdShow = true
        //         // div_search.lbl_UserGrp.Visible = false
        //         // div_search.cmb_UserGrp.Visible = false
        //         // div_search.cmb_UserGrp.Value = ''
        //         // div_search.lbl_UserNm.Visible = false
        //         // div_search.edt_UserNm.Visible = false
        //         // div_search.edt_UserNm.Text = ''
        //         // div_search.lbl_UserCd.Visible = true
        //         // div_search.edt_UserCd.Visible = true
        //         // div_search.edt_UserCd.SetFocus()
        //         this.div_search.cmbSchCon = 'userId'
        //     }
        // },

        // 소속유형 이벤트
        cmb_attcCat_OnChanged(e) {
            // console.log(e)
            // this.dCommItemList = []
            // // 소속유형에 따른 권한그룹 combobox filter
            // this.dCommItemList = this.dCommItemOriginList.filter(
            //     (item) => item['addInfo1'] == e
            // )
            // if (e == '1') {
            //     this.disabledUserGrp = true
            // } else {
            //     this.disabledUserGrp = false
            // }

            this.commUserGrpList = []

            if (e == '') {
                this.div_search.userGrp = ''
                this.commUserGrpList = this.commUserGrpOriginList
                // this.disabledUserGrp = true
            } else {
                // 소속유형에 따른 권한그룹 combobox filter
                this.commUserGrpList = this.commUserGrpOriginList.filter(
                    (item) => item['attcClCd'] == e
                )
                this.div_search.userGrp = ''
            }
        },

        exportGridBtn: function () {
            this.gridData1 = this.gridHeaderObj.exportGrid('사용자관리.xls')
        },

        // excelDownBtn: function () {
        //     this.gridHeaderObj.exportGrid(
        //         `사용자관리-사용자목록_${moment(new Date()).format(
        //             'YYYYMMDDHHmmss'
        //         )}.xls`
        //     )
        // },

        // onBasUsmUserRgstReturnData(retrunData) {
        //     console.log('retrunData: ', retrunData)
        //     this.onSearch()
        // },

        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj1.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/usm/usmTUserMgmtExcelList',
                this.ds_condition
            )
        },

        onShowUsmCurnt() {
            this.showUsmCurnt = true
        },

        onUsmCurntReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.showUsmCurnt = false
        },

        onShowUsmInfoUpdate() {
            this.showUsmInfoUpdate = true
        },

        onUsmInfoUpdateReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.showUsmInfoUpdate = false
        },
    },
}
</script>
