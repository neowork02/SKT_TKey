<!-----------------------------------------------
 * 업무그룹명: Swing할부채권비교검증
 * 서브업무명: Swing할부채권비교검증
 * 설명: Swing할부채권비교검증 조회한다.
 * 작성자: P180190
 * 작성일: 2022.05.23 
------------------------------------------------>
<template>
    <div class="content">
        <h1>Swing할부채권비교검증</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="screenInit"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="search"
                    :disabled="disabledBtnSearch"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="기준월"
                        calType="M"
                        :eRequired="true"
                        v-model="reqParam.accYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :codeVal.sync="reqParam.agencyCd"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        v-model="reqParam.agencyNm"
                        @enterKey="onOrgAgencyEnterKey"
                        @appendIconClick="onOrgAgencyIconClick"
                        @input="onOrgAgencyInput"
                    />
                    <BasBcoOrgAgencysPopup
                        :parentParam="reqParam"
                        :rows="resultOrgAgencyRows"
                        :dialogShow.sync="showBcoOrgAgencys"
                        v-if="showBcoOrgAgencys"
                        @confirm="onOrgAgencyReturnData"
                    />
                </div>
                <!-- <div class="formitem div4">
                    <TCComComboBox
                        labelName="조회대상구분"
                        :itemList="searchCode"
                        :objAuth="objAuth"
                        v-model="reqParam.objClCd"
                    ></TCComComboBox>
                </div> -->
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="할부채권상세"
                :gridObj="gridObj"
                :isPageRows="true"
                :isNextPage="false"
                :isPageCnt="true"
            >
                <template #gridElementArea>
                    <button
                        type="button"
                        class="btn_noline btn_ty04"
                        @click="downloadExcelAll"
                    >
                        <span class="ico_exeldown">엑셀다운로드</span>
                    </button>
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="gridSet.fields"
                :columns="gridSet.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getAllotBondDtls"
                :gridObj="gridObj"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            />
            <!-- <TCComLoadingBar v-model="loadingStatus"></TCComLoadingBar> -->

            <!-- popup 영역 -->
            <AccPssAllotBondVrfDtl
                v-if="showPopupOrg === true"
                ref="popup"
                :dialogShow.sync="showPopupOrg"
                :popupParams.sync="popupParams"
            />
            <!-- @confirm="onReturnAllotBondVrfRgst" -->
            <!-- //popup 영역 -->
        </div>
    </div>
</template>
<script>
import { CommonGrid, CommonUtil } from '@/utils'
import pssApi from '@/api/biz/acc/pss/accPssAllotBondVrfMgmt'
import moment from 'moment'
import _ from 'lodash'
import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import AccPssAllotBondVrfDtl from '@/views/biz/acc/pss/AccPssAllotBondVrfDtl'
import { GRID_HEADER } from '@/const/grid/acc/pss/AccPssAllotBondVrfMgmtGrid'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
import CommonMixin from '@/mixins'
export default {
    name: 'AccPssAllotBondVrfMgmt',
    components: { BasBcoOrgAgencysPopup, AccPssAllotBondVrfDtl },
    mixins: [CommonMixin],
    props: {},
    data() {
        return {
            //Grid Class init
            gridSet: GRID_HEADER,

            //Grid
            objAuth: {},
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            showNext: false,
            gridDataRaw: {},
            /*그리드 스타일*/
            gridStyle: {
                height: '350px', //그리드 높이 조절
            },
            searchForms: {},
            resultData: '',
            rowCnt: 15,

            //요청 파라미터
            reqParam: {
                accYm_: moment(new Date()).format('YYYY-MM'),
                accYm: moment(new Date()).format('YYYY-MM'),
                agencyCd: '',
                aprvStatCd: '',
                objClCd: '1',
                pageSize: '',
                pageNum: 1,
                agencyNm: '',
            },
            searchCode: [
                {
                    commCdVal: '1',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'G',
                    commCdValNm: '차이건',
                },
            ],

            layout: [
                'agencyCd',
                'opSaleOrgNm',
                'svcDt',
                'accItmNm',
                'mdlNm',
                'serNo',
                'svcMgmtNum',
                {
                    name: '할부채권',
                    direction: 'horizontal',
                    items: ['bondPrchAmtSwing', 'bondPrchAmtTkey'],
                },
                'gapAmt',
                'rmks',
            ],

            //btn 바인딩
            disabledBtnSearch: false,

            /* popup영역 */
            showBcoOrgAgencys: false,
            popupParams: {},
            showPopupOrg: false,
            bondVrfs: [],
        }
    },
    mounted() {
        //GRID초기화
        this.setGrid()

        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, false, false)
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.setColumnLayout(this.layout)
        // 그리드 셀 클릭 팝업 이벤트
        this.$refs.grid.gridView.onCellDblClicked = this.onCellDblClicked

        //  일반대리점 접속시 대리점코드/명 Set
        if (this.orgInfo.orgCdLvl0 != 'O00000') {
            this.reqParam.agencyCd = this.userInfo.sktAgencyCd
            this.reqParam.agencyNm = this.userInfo.sktAgencyNm
        }
    },
    created() {
        this.gridData = this.gridSetData(this.rowCnt)
    },
    computed: {
        dateFormatted() {
            return ''
        },
    },
    methods: {
        // 초기화
        screenInit() {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.gridData.totalPage = 0 // 이전페이지정보 초기화

            //  일반대리점 접속시 대리점코드/명 Set
            if (this.orgInfo.orgCdLvl0 != 'O00000') {
                this.reqParam.agencyCd = this.userInfo.sktAgencyCd
                this.reqParam.agencyNm = this.userInfo.sktAgencyNm
            }
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.setGridState(false, false, false)
            this.gridObj.gridView.setRowIndicator({
                visible: true,
                headText: '번호',
            })
            this.$refs.grid.gridView.displayOptions.selectionStyle = 'rows'
        },

        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        // 조회대상구분으로 버튼 컨트롤
        onChange: function () {
            console.log(this.reqParam.objClCd)
            this.search()
        },

        //조회 - 최초
        search() {
            const accYm = this.reqParam.accYm_
            if (_.isEmpty(accYm)) {
                this.showTcComAlert('정산월을 선택해 주세요.')
            } else {
                this.gridData.totalPage = 0
                this.searchForms = { ...this.reqParam }
                this.searchForms.pageSize = this.rowCnt
                this.searchForms.pageNum = 1
                this.searchForms.accYm = CommonUtil.onlyNumber(
                    this.reqParam.accYm_
                )
                this.getAllotBondDtls(this.searchForms.pageNum)
            }
        },
        async getAllotBondDtls(page) {
            this.searchForms.pageNum = page
            // 연속클릭 방지
            this.disabledBtnSearch = false

            await pssApi.getAllotBondDtls(this.searchForms).then((res) => {
                console.log(res)
                if (res) {
                    // 연속클릭 방지
                    this.disabledBtnSearch = false
                    this.bondVrfs = res
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator(res.pagingDto)
                    this.gridData = this.gridSetData()
                    this.gridData.totalPage = res.pagingDto.totalPageCnt
                    this.gridHeaderObj.setPageCount(res.pagingDto)
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },
        /* 조직별 대리점팝업 */
        getOrgAgencyList() {
            basBcoOrgAgencysApi.getOrgAgencyList(this.reqParam).then((res) => {
                console.log('getOrgAgencyList then : ', res)
                if (res.length === 1) {
                    this.reqParam.agencyCd = _.get(res[0], 'agencyCd')
                    this.reqParam.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultOrgAgencyRows = res
                    this.showBcoOrgAgencys = true
                }
            })
        },
        /* 조직별 대리점팝업 - 돋보기 Icon 이벤트 */
        onOrgAgencyIconClick() {
            this.resultOrgAgencyRows = []
            if (!_.isEmpty(this.reqParam.agencyNm)) {
                this.getAllotBondDtls()
            } else {
                this.showBcoOrgAgencys = true
            }
        },
        /* 조직별 대리점팝업 - 엔터키 이벤트 */
        onOrgAgencyEnterKey() {
            this.resultOrgAgencyRows = []
            if (_.isEmpty(this.reqParam.agencyNm)) {
                this.showTcComAlert('대리점명을 입력해주세요.')
                return
            }
            this.getOrgAgencyList()
        },
        /* 조직별 대리점팝업 - Input 이벤트 */
        onOrgAgencyInput() {
            this.reqParam.agencyCd = ''
        },
        /* 조직별 대리점팝업 - 리턴 이벤트 */
        onOrgAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.reqParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.reqParam.agencyNm = _.get(retrunData, 'agencyNm')
        },

        //================================================
        // POPUP 열기
        //================================================
        onCellDblClicked(grid, clickData) {
            if (clickData?.dataRow >= 0) {
                const cellData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                {
                    this.popupParams = { ...cellData }
                    this.showPopupOrg = true
                }
            }
        },
        downloadExcelAll() {
            pssApi.downloadAllotBondVrfMgmtExcel(this.searchForms)
        },
    },
}
</script>
