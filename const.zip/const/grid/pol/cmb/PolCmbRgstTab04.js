import { ValueType } from 'realgrid'

export const GRID_INFO_WIRE_SVC = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'svcCd',
            fieldName: 'svcCd',
            type: 'data',
            header: {
                text: '코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'svcNm',
            fieldName: 'svcNm',
            type: 'data',
            header: {
                text: '코드명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_COMBO = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comboCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comboNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'comboCd',
            fieldName: 'comboCd',
            type: 'data',
            header: {
                text: '코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'comboNm',
            fieldName: 'comboNm',
            type: 'data',
            header: {
                text: '코드명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_AGREE = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agreeCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agreeNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'agreeCd',
            fieldName: 'agreeCd',
            type: 'data',
            header: {
                text: '코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'agreeNm',
            fieldName: 'agreeNm',
            type: 'data',
            header: {
                text: '코드명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_CUST = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'custCd',
            fieldName: 'custCd',
            type: 'data',
            header: {
                text: '코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            header: {
                text: '코드명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_WIRE_TECH = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'techCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'techNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'techCd',
            fieldName: 'techCd',
            type: 'data',
            header: {
                text: '코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'techNm',
            fieldName: 'techNm',
            type: 'data',
            header: {
                text: '코드명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}
