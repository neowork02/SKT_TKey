<template>
    <!-- //Search_div -->
    <div class="stitHead">
        <h4 v-if="gridTitle" class="subTit" v-html="gridTitle"></h4>
        <span
            class="stitTxtL"
            v-if="isPageRows && pageRows.replace(',', '') > 0"
            >(총 <span class="color-red" v-text="pageRows"></span>건)
        </span>
        <div class="multiForm">
            <slot name="gridElementLeftArea" />
        </div>
        <span class="stitBtnRef">
            <div class="multiForm">
                <slot name="gridElementArea" />
            </div>
            <slot name="gridBtnArea" />
            <!-- file inpit type 버튼 -->
            <div v-if="isFileInput" class="fileattach_wrap">
                <span class="fileattach">
                    <TCComFileInput
                        v-model="fileAdd"
                        ref="fileUpload"
                        :hideInput="true"
                        :multiple="true"
                        :truncateLength="15"
                        prependIcon="mdi-magnify"
                        @change="fileChange"
                    ></TCComFileInput>
                </span>
                <a class="txt btn_ty04" @click="onFileAdd">검색</a>
            </div>
            <!-- //file inpit type 버튼 -->
            <span v-if="isAddRow">
                <TCComButton
                    :Vuetify="false"
                    :disabled="disAddRow"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowadd"
                    :labelName="addRowLabel"
                    @click="addRowBtn"
                />
            </span>
            <span v-if="isDelRow">
                <TCComButton
                    :Vuetify="false"
                    :disabled="disDelRow"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowdel"
                    :labelName="delRowLabel"
                    @click="chkDelRowBtn"
                />
            </span>
            <span v-if="isExcelup">
                <TCComButton
                    :Vuetify="false"
                    :disabled="disExcelup"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_exelup"
                    labelName="업로드"
                    @click="excelUploadBtn"
                />
            </span>
            <span v-if="isExceldown">
                <TCComButton
                    :Vuetify="false"
                    :disabled="disExceldown"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_exeldown"
                    labelName="다운로드"
                    @click="excelDownBtn"
                />
            </span>
            <span v-if="isFileAdd">
                <TCComButton
                    :Vuetify="false"
                    :disabled="disFileAdd"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_fileadd"
                    labelName="파일첨부"
                    @click="fileBtnClick"
                />
            </span>
        </span>
    </div>
</template>
<script>
import JSZip from 'jszip'
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
export default {
    name: 'RealGridHeader',
    mixins: [CommonMixin],
    components: {},
    props: {
        id: {
            type: String,
            required: true,
        },
        gridObj: {
            type: Object,
            required: true,
        },
        gridTitle: {
            type: String,
            default: '',
        },
        styles: {
            type: Object,
        },
        options: {
            type: Object,
        },
        isPageRows: {
            type: Boolean,
            default: false,
        },
        isAddRow: {
            type: Boolean,
            default: false,
        },
        disAddRow: {
            type: Boolean,
            default: false,
        },
        isDelRow: {
            type: Boolean,
            default: false,
        },
        disDelRow: {
            type: Boolean,
            default: false,
        },
        isExcelup: {
            type: Boolean,
            default: false,
        },
        disExcelup: {
            type: Boolean,
            default: false,
        },
        isExceldown: {
            type: Boolean,
            default: false,
        },
        disExceldown: {
            type: Boolean,
            default: false,
        },
        isFileAdd: {
            type: Boolean,
            default: false,
        },
        disFileAdd: {
            type: Boolean,
            default: false,
        },
        isFileInput: {
            type: Boolean,
            default: false,
        },
        addData: {
            type: Array,
            default: () => [],
        },
        objAuth: {
            type: Object,
        },
        addRowLabel: {
            type: String,
            default: '추가',
        },
        delRowLabel: {
            type: String,
            default: '삭제',
        },
    },
    data() {
        return {
            pageRows: '',
            gridData: {},
            excelDownFile: '',
            fileAdd: null,
        }
    },

    mounted() {},

    computed: {},
    // 그리드 관련 메쏘드 프록시 처리하여 사용. [https://docs.realgrid.com/refs/local-data-provider]
    methods: {
        fileChange(value) {
            this.$refs.fileUpload.clearFileInputValue()
            this.$emit('fileChange', value)
        },
        fileBtnClick(ev) {
            this.$emit('fileBtnClick', ev)
        },
        addRowBtn: function () {
            this.$emit('addRowBtn', this.gridData)
        },
        chkDelRowBtn: function () {
            this.$emit('chkDelRowBtn', this.gridData)
        },
        excelUploadBtn() {
            this.$emit('excelUploadBtn')
        },
        excelDownBtn: function () {
            this.$emit('excelDownBtn', this.excelDownFile)
        },
        setPageCount: function (paging) {
            if (this.isPageRows === true && paging.totalDataCnt > 0)
                this.pageRows = CommonUtil.commaString(paging.totalDataCnt)
            else if (this.isPageRows === true && paging.totalDataCnt == 0) {
                this.pageRows = String(paging.totalDataCnt)
            }
        },
        /*************************************************
         * Page DATA ADD 함수
         * gridRows : Grid Row수(하나페이지에 표시할 행의 개수)
         * res      : 결과값
         *************************************************/
        setAddPage: function (gridRows, res) {
            if (res.pagingDto.pageNum) {
                gridRows = gridRows * res.pagingDto.pageNum
                this.gridObj.gridView.setPaging(true, gridRows)

                //페이지정보 셋팅
                this.setPageCount(res.pagingDto)
                let state = [] //insert된 행들 index 배열변수
                //forEach로 insertRow
                res.gridList.forEach((data) => {
                    state.push(this.gridObj.gridView.getItemCount())
                    this.gridObj.dataProvider.insertRow(
                        this.gridObj.gridView.getItemCount(),
                        data
                    )
                })

                //insertRow 된 index를 배열로 받아서 상태변경처리
                this.gridObj.dataProvider.setRowStates(state, 'none')
            }
            return gridRows
        },
        /*************************************************
         * Grid 행 추가
         * gridData  : Grid Data
         *************************************************/
        addRow: function (gridRows) {
            this.insertRowIndex()
            gridRows += 1
            this.gridObj.gridView.setPaging(true, gridRows)
            return gridRows
        },
        /*************************************************
         * Grid 행 추가(추가된 행의 위치 리턴)
         * gridData  : Grid Data
         *************************************************/
        addRowIndex: function () {
            this.insertRowIndex()
            return this.gridObj.gridView.getItemCount() - 1
        },
        /*************************************************
         * Grid 행 추가
         * data     : 추가되는 기본행 Data
         *************************************************/
        insertRow: function (data) {
            this.gridObj.dataProvider.insertRow(data)
        },
        /*************************************************
         * Grid 행 추가(추가되는 행에 위치 지정)
         *************************************************/
        insertRowIndex: function () {
            this.gridObj.dataProvider.insertRow(
                this.gridObj.gridView.getItemCount(),
                this.addData
            )
        },
        /*************************************************
         * Grid 체크된 행 삭제
         * gridData   : Grid Data Class
         *************************************************/
        chkDelRow: function (gridData) {
            //체크된 행 index 가져오기
            let chkRow = this.gridObj.gridView.getCheckedRows(true)
            if (chkRow == '') {
                this.showTcComAlert('삭제할 행을 선택하세요')
            } else {
                let delJsonRow = []
                //체크된 행 JsonData 저장
                for (let i = 0; i < chkRow.length; i++) {
                    let state = this.gridObj.dataProvider.getRowState(chkRow[i])

                    //신규행제외
                    if (state != 'created') {
                        let row = this.gridObj.dataProvider.getJsonRow(
                            chkRow[i],
                            true
                        )

                        //행에 상태값을 deleted로 변경 getRowState
                        row['__rowState'] = 'deleted'
                        delJsonRow.push(row)
                    } else {
                        //신규행인경우 그리드에 표시해야될 행의 갯수 조정
                        gridData.gridRows = gridData.gridRows - 1
                        this.gridObj.gridView.setPaging(true, gridData.gridRows)
                    }
                }

                this.gridObj.dataProvider.removeRows(chkRow)

                //삭제된값이 있으면 배열을 합치기
                if (gridData.delRows) {
                    gridData.delRows = delJsonRow.concat(gridData.delRows)
                } else {
                    gridData.delRows = delJsonRow
                }
            }

            this.setPageCount(gridData)
            return gridData
        },
        /*************************************************
         * Grid 선택된 행 바로 삭제(포커스 있는 행)
         *************************************************/
        selDelRow: function () {
            let current = this.gridObj.gridView.getCurrent()
            if (current.dataRow < 0) {
                this.showTcComAlert('삭제할 행을 선택하세요')
            } else {
                this.gridObj.dataProvider.removeRow(current.dataRow)
            }
        },

        /*************************************************
         * Grid 선택된 행 return 값 생성후 삭제(포커스 있는 행)
         * gridData   : Grid Data Class
         *************************************************/
        focusDelRow: function (gridData) {
            this.gridObj.gridView.commit()
            let current = this.gridObj.gridView.getCurrent()
            if (current.dataRow < 0) {
                this.showTcComAlert('삭제할 행을 선택하세요')
            } else {
                let state = this.gridObj.dataProvider.getRowState(
                    current.dataRow
                )
                let delJsonRow = []
                //신규행제외
                if (state != 'created') {
                    let row = this.gridObj.dataProvider.getJsonRow(
                        current.dataRow,
                        true
                    )

                    //행에 상태값을 deleted로 변경 getRowState
                    row['__rowState'] = 'deleted'
                    delJsonRow.push(row)
                } else {
                    //신규행인경우 그리드에 표시해야될 행의 갯수 조정
                    gridData.gridRows = gridData.gridRows - 1
                    this.gridObj.gridView.setPaging(true, gridData.gridRows)
                }
                this.gridObj.dataProvider.removeRow(current.dataRow)
                //삭제된값이 있으면 배열을 합치기
                if (gridData.delRows) {
                    gridData.delRows = delJsonRow.concat(gridData.delRows)
                } else {
                    gridData.delRows = delJsonRow
                }
            }
            return gridData
        },

        /*************************************************
         * Grid Excel Export
         * fileName   : 파일이름지정
         *************************************************/
        exportGrid: function (fileName) {
            this.showTcComAlert('엑셀 다운로드는 서버에서 처리하시길 바랍니다.')

            window.JSZip = window.JSZip || JSZip
            this.gridObj.gridView.exportGrid({
                type: 'excel',
                target: 'local',
                fileName: fileName,
                applyDynamicStyles: true,
                done: function () {
                    alert('Excel DownLoad!!')
                },
            })
        },

        /*************************************************
         * Sample Grid Excel Export
         * 그리드 양식을 다운받는경우(데이터 없이 헤더만 표기)
         * fileName : 파일명
         * hideColYn : 숨긴컬럼표시여부
         *************************************************/
        exportSampleGrid: function (fileName, hideColYn = false) {
            window.JSZip = window.JSZip || JSZip
            this.gridObj.gridView.exportGrid({
                type: 'excel',
                target: 'local',
                fileName: fileName,
                allColumns: hideColYn,
                //text 필드 출력 시 수행될 콜백
                textCallback: function () {
                    return '' //데이터부분 공백처리
                },
                //number 필드 출력 시 수행될 콜백
                numberCallback: function () {
                    return '' //데이터부분 공백처리
                },
                //datetime 필드 출력 시 수행될 콜백
                datetimeCallback: function () {
                    return '' //데이터부분 공백처리
                },
                //boolean 필드 출력 시 수행될 콜백
                booleanCallback: function () {
                    return '' //데이터부분 공백처리
                },
                //object 필드 출력 시 수행될 콜백
                objectCallback: function () {
                    return '' //데이터부분 공백처리
                },
            })
        },
        //파일검색
        onFileAdd() {
            this.$refs.fileUpload.fileInputClick()
        },
    },
}
</script>
<style>
.grid {
    width: 100%;
    height: 250px;
}
</style>
