<template>
    <!-- right_notice area -->

    <div class="notiArea">
        <div class="noticeTit">
            <h3>{{ this.notiTabSubject }}</h3>
            <a class="viewAll" @click="notiBtn()">전체보기</a>
        </div>
        <ul v-for="(item, idx) in notiList" v-bind:key="idx">
            <li>
                <a @click="notiBtn(item.bbsNo)">{{ item.textTitle }} </a>
                <span>{{ item.regDtm }}</span>
            </li>
        </ul>
        <DetailPopup
            v-if="showBasBbsDetailMgmt === true"
            ref="popup"
            :dialogShow.sync="showBasBbsDetailMgmt"
            :popupParams.sync="popupParams"
        />
    </div>

    <!-- //right_notice area -->
</template>

<script>
import CommonMixin from '@/mixins'
import mainNoticeApi from '@/api/common/mainNoticeApi'
//상세팝업
import DetailPopup from '@/views/biz/bas/bbs/BasBbsDetailMgmt'
export default {
    name: 'MainNoti',
    mixins: [CommonMixin],
    components: { DetailPopup },
    props: {
        notiTabSubject: {
            type: String,
            default: '',
        },
        notiBbsTypeCd: {
            type: String,
            default: '',
        },
    },
    data() {
        return {
            searchParam: {
                bbsTypeCd: this.notiBbsTypeCd,
                limit: 4,
            },
            notiList: [],
            popupParams: { bbsNo: '', mainYn: 'Y' },
            showBasBbsDetailMgmt: false,
        }
    },
    created() {
        this.axList()
    },
    mounted() {},
    computed: {},
    watch: {},
    methods: {
        axList() {
            let param = this.searchParam
            mainNoticeApi.getNotiApi(param).then((res) => {
                //console.log('getAgencyNotiApi then : ', res)

                // if (4 < res.length) {
                //     for (let i = 0; i < 4; i++) {
                //         this.agencyNotiList.push(res[i])
                //     }
                // } else {
                //     this.agencyNotiList = res
                // }

                for (let i = 0; i < 4; i++) {
                    if (undefined == res[i]) {
                        res[i] = {
                            textTitle: '\u00a0',
                        }
                        console.log(res[i])
                    }
                    this.notiList.push(res[i])
                }
            })
        },
        notiBtn(bbsNo) {
            //+버튼이동 (//N -> TAB0, D -> TAB1, S-> TAB2 )
            if (undefined == bbsNo) {
                let paramBbsTypeCd = ''

                if ('N' == this.notiBbsTypeCd) {
                    //대리점 공지사항
                    paramBbsTypeCd = 'N'
                } else if ('DS' == this.notiBbsTypeCd) {
                    paramBbsTypeCd = 'DS' //정책게시판
                } else if ('A' == this.notiBbsTypeCd) {
                    paramBbsTypeCd = 'A' //시스템공지사항
                } else if ('I' == this.notiBbsTypeCd) {
                    paramBbsTypeCd = 'I' //기능개선요청게시판
                }

                this.$router.push({
                    name: '/bas/bbs/BasBbsMgmt',
                    params: { bbsTypeCd: paramBbsTypeCd },
                })
            } else {
                //클릭시
                this.showBasBbsDetailMgmt = true
                this.popupParams.bbsNo = bbsNo
            }
        },
    },
}
</script>
