<!-----------------------------------------------
 * 업무그룹명: 기준정보>리포트
 * 서브업무명: SMS전송현황관리
 * 설명: SMS전송현황관리 조회/입력/수정/삭제 한다.
 * 작성자: P180392
 * 작성일: 2022.06.07
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="">
        <div class="content">
            <!-- Tit -->
            <h1>SMS전송현황관리</h1>
            <!-- // Tit -->
            <main-content ref="mainContent" />
        </div>
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/cmu/smsTrmsPrstMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/cmu/smsTrmsPrstMgmt'

export default {
    name: 'BasCmuSmsTrmsPrstMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (this.$store.hasModule('bas.cmu.smsTrmsPrstMgmtStore') != true) {
            this.$store.registerModule('bas.cmu.smsTrmsPrstMgmtStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.cmu.smsTrmsPrstMgmtStore') == true) {
            this.$store.unregisterModule('bas.cmu.smsTrmsPrstMgmtStore')
        }
    },

    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>

<style>
.content1 {
    display: flex;
    height: 800px;
    gap: 1em;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
}
</style>
