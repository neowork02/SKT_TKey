<template>
    <div class="content">
        <h1>판매수수료정산관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="saveOnDemandButton('JEONGSAN-BUTTON')"
                    >정산최종이력 > 엑셀</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="saveOnDemandButton('JEONGCHAK-BUTTON')"
                    >정책별 상세 > 엑셀</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="
                        exportExcelDownButton('GAGAM-BUTTON', '수수료가감엑셀')
                    "
                    >수수료가감 > 엑셀</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="
                        exportExcelDownButton('SANGGYE-BUTTON', '정산상계엑셀')
                    "
                    >정산상계 > 엑셀</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    :disabled="button.disabled.searchSpOp"
                    @click="onSearchSpOp"
                    >휴폐업조회</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    :disabled="button.disabled.resetAdjtAmt"
                    @click="onResetAdjtAmt"
                    >조정금액초기화</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave('Y')"
                    :objAuth="objAuth"
                    :disabled="button.disabled.confirm"
                    >확정</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onReset"
                    :objAuth="objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="objAuth"
                    >조회</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave('N')"
                    :objAuth="objAuth"
                    :disabled="button.disabled.save"
                    >저장</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onDelete"
                    :objAuth="objAuth"
                    :disabled="button.disabled.delete"
                    >삭제</TCComButton
                >
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        v-model="searchParams.searchAccYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchParams.searchOrgNm"
                        :codeVal.sync="searchParams.searchOrgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabled="false"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :eRequired="true"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="orgParams"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchParams.searchAccDealcoNm"
                        :codeVal.sync="searchParams.searchAccDealcoCd"
                        labelName="정산처"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :rows="resultDealcoRows"
                        :parentParam="searchAccDealcoParams"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComCheckBox
                        labelName=" "
                        v-model="searchParams.searchIsPreYm_"
                        :itemList="[
                            { commCdVal: 'Y', commCdValNm: '이전월포함' },
                        ]"
                        :objAuth="objAuth"
                    ></TCComCheckBox>
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="ERP전송"
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        :disabled="combo.disabled.erp"
                        :itemList="[
                            { commCdVal: '', commCdValNm: '전체' },
                            { commCdVal: 'Y', commCdValNm: '확정' },
                            { commCdVal: 'N', commCdValNm: '미확정' },
                        ]"
                        v-model="searchParams.searchErpFixYn"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="세금계산서상태"
                        codeId="TAX_BIL_ST_CD"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        :disabled="combo.disabled.tax"
                        v-model="searchParams.searchTaxBilStCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="정산상태"
                        codeId="ACC_FIX_ST_CD"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        :disabled="combo.disabled.accSt"
                        v-model="searchParams.searchAccFixStCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="휴폐업조회"
                        codeId="SP_OP_ST_CD"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        :disabled="combo.disabled.spOpSt"
                        v-model="searchParams.searchSpOpStCd"
                    ></TCComComboBox>
                </div>
            </div>
        </div>
        <!-- //Search_div -->

        <!-- gridWrap -->
        <div class="gridWrap">
            <TCComTab
                :tab.sync="tab.tabSync1"
                :items="tab.id"
                :itemName="tab.title"
                @click="onActiveTabClick"
            >
                <template #tab0>
                    <TCRealGridHeader
                        id="gridHeader0"
                        ref="gridHeader0"
                        :gridTitle="tab.title[0]"
                        :gridObj="tab.grid[0]"
                        :isExceldown="true"
                        :isPageRows="true"
                        :isFileAdd="true"
                        @fileBtnClick="onFileBtnClick"
                        @excelDownBtn="
                            exportExcelDownButton(
                                'JEONGSAN-TAB',
                                '판매수수료정산'
                            )
                        "
                    />
                    <TCRealGrid
                        id="grid0"
                        ref="grid0"
                        :fields="view.fields0"
                        :columns="view.columns0"
                        :styles="gridStyle"
                    />
                </template>
                <template #tab1>
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        :gridTitle="tab.title[1]"
                        :gridObj="tab.grid[1]"
                        :isExceldown="true"
                        :isExcelup="true"
                        :isPageRows="true"
                        @excelDownBtn="
                            exportExcelDownButton(
                                'JOJEONG-TAB',
                                '판매수수료조정'
                            )
                        "
                        @excelUploadBtn="onSelectExcelFile()"
                    />
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :fields="view.fields1"
                        :columns="view.columns1"
                        :styles="gridStyle"
                        @hook:mounted="tabGridMounted(1)"
                    />
                    <v-file-input
                        id="excelFile"
                        ref="excelFile"
                        label="엑셀업로드 파일선택(숨김)"
                        style="display: none"
                        @change="onChangeExcelFileTab3"
                    ></v-file-input>
                </template>
                <template #tab2>
                    <TCRealGridHeader
                        id="gridHeader2"
                        ref="gridHeader2"
                        :gridTitle="tab.title[2]"
                        :gridObj="tab.grid[2]"
                        :isExceldown="true"
                        :isExcelup="true"
                        :isPageRows="true"
                        @excelDownBtn="
                            exportExcelDownButton('GAGAM-TAB', '수수료가감')
                        "
                        @excelUploadBtn="openExcelUploadPopup(2)"
                    >
                        <template #gridBtnArea>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_rowadd"
                                labelName="추가"
                                :objAuth="objAuth"
                                @click="openPopup('gagam')"
                            />
                        </template>
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid2"
                        ref="grid2"
                        :fields="view.fields2"
                        :columns="view.columns2"
                        :styles="gridStyle"
                        @hook:mounted="tabGridMounted(2)"
                    />
                </template>
                <template #tab3>
                    <TCRealGridHeader
                        id="gridHeader3"
                        ref="gridHeader3"
                        :gridTitle="tab.title[3]"
                        :gridObj="tab.grid[3]"
                        :isExceldown="true"
                        :isExcelup="true"
                        :isPageRows="true"
                        @excelDownBtn="
                            exportExcelDownButton('SANGGYE-TAB', '정산상계')
                        "
                        @excelUploadBtn="openExcelUploadPopup(3)"
                    >
                        <template #gridBtnArea>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_rowadd"
                                labelName="추가"
                                :objAuth="objAuth"
                                @click="openPopup('sanggye')"
                            />
                        </template>
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid3"
                        ref="grid3"
                        :fields="view.fields3"
                        :columns="view.columns3"
                        :styles="gridStyle"
                        @hook:mounted="tabGridMounted(3)"
                    />
                </template>
            </TCComTab>
        </div>
        <!-- //gridWrap -->
        <!-- Dialog -->
        <TCComAlert
            v-model="showAlertBool"
            headerText="알림"
            :bodyText="alertBodyText"
        ></TCComAlert>
        <!-- //Dialog -->
        <!-- 판매수수료정산 팝업(세부내역) -->
        <AccSacWlessSaleCmmsAccMgmtJeongsanPopup
            v-if="popup.jeongsan.showBool === true"
            ref="jeongsanPopup"
            :dialogShow.sync="popup.jeongsan.showBool"
            :popupParams.sync="popup.jeongsan.params"
        />
        <!-- T에코환수 팝업 -->
        <AccSacWlessSaleCmmsAccMgmtTecoPopup
            v-if="popup.teco.showBool === true"
            ref="tecoPopup"
            :dialogShow.sync="popup.teco.showBool"
            :popupParams.sync="popup.teco.params"
        />
        <!-- 수수료가감 팝업 -->
        <AccSacWlessSaleCmmsAccMgmtGagamPopup
            v-if="popup.gagam.showBool === true"
            ref="gagamPopup"
            :dialogShow.sync="popup.gagam.showBool"
            :popupParams.sync="popup.gagam.params"
        />
        <!-- 수수료가감 엑셀업로드 팝업 -->
        <AccSacWlessSaleCmmsAccMgmtGagamExcelUploadPopup
            v-if="popup.gagamExcelUp.showBool === true"
            ref="gagamExcelUpPopup"
            :dialogShow.sync="popup.gagamExcelUp.showBool"
            :popupParams.sync="popup.gagamExcelUp.params"
        />
        <!-- 정산 상계 팝업 -->
        <AccSacWlessSaleCmmsAccMgmtSanggyePopup
            v-if="popup.sanggye.showBool === true"
            ref="sanggyePopup"
            :dialogShow.sync="popup.sanggye.showBool"
            :popupParams.sync="popup.sanggye.params"
        />
        <!-- 정산 상계 엑셀업로드 팝업 -->
        <AccSacWlessSaleCmmsAccMgmtSanggyeExcelUploadPopup
            v-if="popup.sanggyeExcelUp.showBool === true"
            ref="sanggyeExcelUpPopup"
            :dialogShow.sync="popup.sanggyeExcelUp.showBool"
            :popupParams.sync="popup.sanggyeExcelUp.params"
            @close="onSearch"
        />
        <!-- (도매매출)수납내역 팝업 -->
        <AccSacWlessSaleCmmsAccMgmtPayPopup
            v-if="popup.pay.showBool === true"
            ref="payPopup"
            :dialogShow.sync="popup.pay.showBool"
            :popupParams.sync="popup.pay.params"
        />
        <!-- 부가서비스해지환수 팝업 -->
        <AccSacWlessSaleCmmsAccMgmtSuplPopup
            v-if="popup.supl.showBool === true"
            ref="suplPopup"
            :dialogShow.sync="popup.supl.showBool"
            :popupParams.sync="popup.supl.params"
        />
        <!-- 중고단말기미반납 팝업 -->
        <AccSacWlessSaleCmmsAccMgmtOldPopup
            v-if="popup.old.showBool === true"
            ref="oldPopup"
            :dialogShow.sync="popup.old.showBool"
            :popupParams.sync="popup.old.params"
        />
        <!-- 파일첨부 팝업 -->
        <AttachedFileAddPopup
            v-if="file.showAddPopup"
            ref="fileAddPopup"
            :dialogShow.sync="file.showAddPopup"
            :fileList="file.list"
            @confirm="callbackReturnFiles"
        />
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import _ from 'lodash'
import moment from 'moment'
import sacApi from '@/api/biz/acc/sac'
import attachedFileApi from '@/api/common/attachedFile'
import { AccUtil } from '@/views/biz/acc'
import { CommonGrid, CommonUtil } from '@/utils'
import { AccExcelUpload } from '@/views/biz/acc'
import AttachedFileAddPopup from '@/components/common/AttachedFileAddPopup'
// import { AccPaging } from '@/views/biz/acc/AccPaging'
import { GRID_HEADER } from '@/const/grid/acc/sac/accSacWlessSaleCmmsAccMgmtGrid'
import AccSacWlessSaleCmmsAccMgmtJeongsanPopup from '@/views/biz/acc/sac/AccSacWlessSaleCmmsAccMgmtJeongsanPopup'
import AccSacWlessSaleCmmsAccMgmtGagamPopup from '@/views/biz/acc/sac/AccSacWlessSaleCmmsAccMgmtGagamPopup'
import AccSacWlessSaleCmmsAccMgmtGagamExcelUploadPopup from '@/views/biz/acc/sac/AccSacWlessSaleCmmsAccMgmtGagamExcelUploadPopup'
import AccSacWlessSaleCmmsAccMgmtSanggyePopup from '@/views/biz/acc/sac/AccSacWlessSaleCmmsAccMgmtSanggyePopup'
import AccSacWlessSaleCmmsAccMgmtSanggyeExcelUploadPopup from '@/views/biz/acc/sac/AccSacWlessSaleCmmsAccMgmtSanggyeExcelUploadPopup'
import AccSacWlessSaleCmmsAccMgmtTecoPopup from '@/views/biz/acc/sac/AccSacWlessSaleCmmsAccMgmtTecoPopup'
import AccSacWlessSaleCmmsAccMgmtPayPopup from '@/views/biz/acc/sac/AccSacWlessSaleCmmsAccMgmtPayPopup'
import AccSacWlessSaleCmmsAccMgmtSuplPopup from '@/views/biz/acc/sac/AccSacWlessSaleCmmsAccMgmtSuplPopup'
import AccSacWlessSaleCmmsAccMgmtOldPopup from '@/views/biz/acc/sac/AccSacWlessSaleCmmsAccMgmtOldPopup'

//  내부조직팝업(권한)
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//  내부조직팝업(권한)

//  내부거래처(권한조직)
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//  내부거래처(권한조직)

export default {
    name: 'AccSacWlessSaleCmmsAccMgmt',
    title: '판매수수료정산관리',
    mixins: [CommonMixin],
    components: {
        AccSacWlessSaleCmmsAccMgmtJeongsanPopup,
        AccSacWlessSaleCmmsAccMgmtGagamPopup,
        AccSacWlessSaleCmmsAccMgmtGagamExcelUploadPopup,
        AccSacWlessSaleCmmsAccMgmtSanggyePopup,
        AccSacWlessSaleCmmsAccMgmtSanggyeExcelUploadPopup,
        AccSacWlessSaleCmmsAccMgmtTecoPopup,
        AccSacWlessSaleCmmsAccMgmtPayPopup,
        AccSacWlessSaleCmmsAccMgmtSuplPopup,
        AccSacWlessSaleCmmsAccMgmtOldPopup,
        AttachedFileAddPopup,
        BasBcoAuthOrgTreesPopup, //  내부조직팝업(권한)
        BasBcoDealcosPopup, //  내부거래처(권한조직)
    },
    data() {
        return {
            screenId: 'AccSacWlessSaleCmmsAccMgmt',
            view: GRID_HEADER,
            objAuth: {},
            tabDefault: {},
            listAccDealco: [],
            accLastClsYm: '',
            gridStyle: {
                height: '360px',
            },
            tab: {
                nowIndex: 0,
                tabSync1: 0,
                id: ['tab0', 'tab1', 'tab2', 'tab3'],
                pageType: [
                    'JEONGSAN-TAB',
                    'JOJEONG-TAB',
                    'GAGAM-TAB',
                    'SANGGYE-TAB',
                ],
                title: [
                    '판매수수료 정산',
                    '판매수수료조정',
                    '수수료 가감',
                    '정산 상계',
                ],
                list: [[], [], [], []],
                grid: [{}, {}, {}, {}],
                gridHeader: [{}, {}, {}, {}],
                gridData0: {},
                gridData1: {},
                gridData2: {},
                gridData3: {},
                page: [
                    { pageSize: 15, pageNum: 1 },
                    { pageSize: 15, pageNum: 1 },
                    { pageSize: 15, pageNum: 1 },
                    { pageSize: 15, pageNum: 1 },
                ],
            },
            popup: {
                jeongsan: {
                    showBool: false,
                    params: {},
                },
                gagam: {
                    showBool: false,
                    params: {},
                },
                gagamExcelUp: {
                    showBool: false,
                    params: {},
                },
                sanggye: {
                    showBool: false,
                    params: {},
                },
                sanggyeExcelUp: {
                    showBool: false,
                    params: {},
                },
                teco: {
                    showBool: false,
                    params: {},
                },
                pay: {
                    showBool: false,
                    params: {},
                },
                supl: {
                    showBool: false,
                    params: {},
                },
                old: {
                    showBool: false,
                    params: {},
                },
            },
            // 버튼 제어
            button: {
                disabled: {
                    confirm: false,
                    save: false,
                    delete: false,
                    searchSpOp: false,
                    resetAdjtAmt: true,
                },
            },
            // 버튼 제어
            combo: {
                disabled: {
                    erp: true,
                    tax: true,
                    accSt: true,
                    spOpSt: true,
                },
            },
            // 엑셀업로드
            excelUp: {
                // Tab3[판매수수료 정산]
                tab3: {
                    // 컬럼명/컬럼변수 세팅
                    columns: [
                        { fieldName: 'accYm', header: { text: '정산월' } },
                        {
                            fieldName: 'gnrlSaleNo',
                            header: { text: '판매번호' },
                        },
                        {
                            fieldName: 'gnrlSaleChgSeq',
                            header: { text: '판매변경순번' },
                        },
                        { fieldName: 'accSeq', header: { text: '정산순번' } },
                        {
                            fieldName: 'saleClCd',
                            header: { text: '판매구분코드' },
                        },
                        {
                            fieldName: 'accDealcoCd',
                            header: { text: '정산처코드' },
                        },
                        {
                            fieldName: 'accDealcoNm',
                            header: { text: '정산처' },
                        },
                        {
                            fieldName: 'adjtAbleYn',
                            header: { text: '조정가능여부' },
                        },
                        {
                            fieldName: 'accClsYn',
                            header: { text: '마감여부' },
                        },
                        {
                            fieldName: 'adjtCmmsAmt',
                            header: { text: '*조정_수수료' },
                        },
                        {
                            fieldName: 'adjtCashSaleAmt',
                            header: { text: '*조정_현금매출' },
                        },
                        { fieldName: 'rmks', header: { text: '비고' } },
                    ],
                    // 필수체크 컬럼 세팅
                    required: {
                        accYm: '정산월',
                        gnrlSaleNo: '판매번호',
                        gnrlSaleChgSeq: '판매변경순번',
                        accSeq: '정산순번',
                        adjtCmmsAmt: '조정_수수료',
                        adjtCashSaleAmt: '조정_현금매출',
                    },
                },
            },
            fileDefault: {},
            file: {
                showAddPopup: false,
                isAttach: false,
                isAttachOnly: false,
                list: [],
                formData: new FormData(),
            },
            paramJson: {},
            searchParamsDefault: {},
            searchParams: {
                searchPageType: '',
                searchAccYm_: moment(new Date()).format('YYYY-MM') /*정산월*/,
                searchAccYm: moment(new Date()).format(
                    'YYYYMM'
                ) /*정산월(날짜format제거)*/,
                searchOrgCd: '' /*조직코드*/,
                searchOrgNm: '' /*조직명*/,
                searchOrgLvl: '' /*조직Level*/,
                searchOrgTree: '' /*조직트리Display*/,
                searchLvOrgCd: '' /*레벨0조직코드*/,
                searchAccDealcoCd: '' /*정산처코드*/,
                searchAccDealcoNm: '' /*정산처명*/,
                searchIsPreYm_: [] /*이전월포함*/,
                searchIsPreYm: '' /*이전월포함*/,
                searchErpFixYn: '' /*ERP전송*/,
                searchAccFixStCd: '' /*전산상태*/,
                searchTaxBilStCd: '' /*세금계산서상태*/,
                searchSpOpStCd: '' /*휴폐업조회*/,
                searchTabIndex: 0,
                searchQueryMode: '' /*목록(LIST)/목록수(COUNT) 조회여부*/,
                searchAccDealcoCdList: [],
                excelFileName: '',
                fileName: '',
                checkedRows: [],
                btnFixYn: 'N' /*확정버튼 클릭시 'Y'*/,
            },
            alertBodyText: '',

            //  마감여부
            accCloseYn: 'N',

            // 정산확정 갯수
            dealcoFixCount: 0,

            //  조회버튼 클릭시 정산월, 조직코드. 판매수수료조정 업로드시 사용
            SearchChangeCl: '',
            searchBakupAccYm: '',
            searchBackupOrgCd: '',

            //  내부조직팝업(권한)
            showAlertBool: false,
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            orgParams: {},
            //  내부조직팝업(권한)

            //  내부거래처(권한조직)
            basBcoDealcoShow: false,
            resultDealcoRows: [],
            searchAccDealcoParams: {
                basDay: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                dealcoCd: '',
                dealcoNm: '',
            },
            //  내부거래처(권한조직)
        }
    },
    watch: {
        'searchParams.searchAccYm_'(newVal) {
            var _newVal = newVal
            if (!_.isEmpty(newVal)) {
                _newVal = newVal.replace(/-/g, '')
            }

            this.orgParams.basMth = _newVal
            this.searchParams.searchAccYm = _newVal
            this.searchAccDealcoParams.basDay = moment(_newVal)
                .endOf('month')
                .format('YYYYMMDD')
        },
        'searchParams.searchIsPreYm_'(newVal) {
            if (_.isEmpty(newVal)) {
                this.searchParams.searchIsPreYm = ''
            } else {
                this.searchParams.searchIsPreYm = newVal[0]
            }
        },
        'searchParams.searchOrgCd'(newVal) {
            this.searchAccDealcoParams.orgCd = newVal
        },
        'searchParams.searchOrgNm'(newVal) {
            this.searchAccDealcoParams.orgNm = newVal
        },
        'searchParams.searchOrgLvl'(newVal) {
            this.searchAccDealcoParams.orgLvl = newVal
        },
        'searchParams.searchLvOrgCd'(newVal) {
            this.searchAccDealcoParams.lvOrgCd = newVal
        },
        'searchParams.searchAccDealcoCd'(newVal) {
            this.searchAccDealcoParams.dealcoCd = newVal
        },
        'searchParams.searchAccDealcoNm'(newVal) {
            this.searchAccDealcoParams.dealcoNm = newVal
        },
    },
    mounted() {
        //  회사구분조직코드
        this.searchParams.searchLvOrgCd = this.orgInfo.orgCdLvl0
        this.searchParams.searchOrgCd = this.orgInfo.orgCd
        this.searchParams.searchOrgNm = this.orgInfo.orgNm
        this.searchAccDealcoParams.orgLvl = this.orgInfo.orgLvl
        this.searchParams.searchOrgLvl = this.orgInfo.orgLvl

        //  Tab Index에 따른 버튼 Control
        this.onActiveTabClick('S')

        // searchPageType 세팅
        this.searchParams.searchPageType = this.tab.pageType[0]

        // 초기화를 위해 초기값 변수에 저장하기
        this.tabDefault = _.cloneDeep(this.tab)
        this.searchParamsDefault = _.cloneDeep(this.searchParams)
        this.fileDefault = _.cloneDeep(this.file)

        // 첫번째 그리드 세팅
        this.tab.gridData0 = this.gridSetData()
        this.tab.grid[0] = this.$refs.grid0
        this.tab.gridHeader[0] = this.$refs.gridHeader0
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.tab.grid[0].setGridState(false, false, true, true)
        this.tab.grid[0].gridView.setColumnLayout(this.view.layout0) //그리드 Header Layout 세팅하기

        // 일반 대리점 사용자 휴폐업조회 버튼 숨김
        if (this.orgInfo.orgCdLvl0 != 'O00000') {
            this.button.disabled.searchSpOp = true
        }

        // 일반 대리점 사용자 ERP전송 여부 컬름 숨김
        if (this.orgInfo.orgCdLvl0 != 'O00000') {
            this.tab.grid[0].gridView.columnByName('erpFixStNm').visible = false
            this.tab.grid[0].gridView.columnByName('spOpStNm').visible = false
            this.tab.grid[0].gridView.columnByName(
                'spClsBizClNm'
            ).visible = false
        }

        // 첫번째 그리드 더블클릭시
        this.tab.grid[0].gridView.onCellDblClicked = (grid, clickData) => {
            // [판매수수료 정산] 팝업 오픈하기
            this.popup.jeongsan.showBool = true
            this.popup.jeongsan.params = grid.getValues(clickData.itemIndex)
        }

        // 그리드 내 아이콘 클릭시 오픈될 팝업 세팅
        this.tab.grid[0].gridView.onCellButtonClicked = (grid, clickData) => {
            // 도매매출수납의 항목 아이콘 클릭시
            if (clickData.fieldName == 'payDiffSearch') {
                this.popup.pay.showBool = true
                this.popup.pay.params = grid.getValues(clickData.itemIndex)
            }
            // 부가서비스해지환수의 항목 아이콘 클릭시
            else if (clickData.fieldName == 'suplSvcRpaySearch') {
                this.popup.supl.showBool = true
                this.popup.supl.params = grid.getValues(clickData.itemIndex)
            }
            // 중고미반납환수의 항목 아이콘 클릭시
            else if (clickData.fieldName == 'unoldrtnRpaySearch') {
                this.popup.old.showBool = true
                this.popup.old.params = grid.getValues(clickData.itemIndex)
            }
            // 당월수수료가감의 항목 아이콘 클릭시
            else if (clickData.fieldName == 'cmmsAddSubSearch') {
                this.popup.gagam.showBool = true
                this.popup.gagam.params = {
                    ...grid.getValues(clickData.itemIndex),
                    isSearch: true,
                }
            }
            // 정산상계의 항목 아이콘 클릭시
            else if (clickData.fieldName == 'accMtchSearch') {
                this.popup.sanggye.showBool = true
                this.popup.sanggye.params = {
                    ...grid.getValues(clickData.itemIndex),
                    isSearch: true,
                }
            }
            // T에코환수의 항목 아이콘 클릭시
            else if (clickData.fieldName == 'tecoRpaySearch') {
                this.popup.teco.showBool = true
                this.popup.teco.params = grid.getValues(clickData.itemIndex)
            }
        }

        // 첨부파일명 클릭시 파일 다운로드
        this.tab.grid[0].gridView.onCellItemClicked = (
            grid,
            index,
            clickData
        ) => {
            if (clickData.type == 'link') {
                var downloadFileParam = {
                    screenId: grid.getValue(index.itemIndex, 'screenId'),
                    docId: grid.getValue(index.itemIndex, 'docId'),
                    filePathNm: grid.getValue(index.itemIndex, 'filePathNm'),
                    fileNm: grid.getValue(index.itemIndex, 'fileNm'),
                    fileType: grid.getValue(index.itemIndex, 'fileType'),
                }
                this.downloadFile(downloadFileParam)
                return false
            }
        }
    },
    methods: {
        tabGridMounted: function (tabIndex) {
            // 초기화를 위해 초기값 변수에 저장하기
            // this.tabDefault = _.cloneDeep(this.tab)
            // this.searchParamsDefault = _.cloneDeep(this.searchParams)

            // 그리드 Header Layout 세팅하기
            this.tab['gridData' + tabIndex] = this.gridSetData()
            this.tab.grid[tabIndex] = this.$refs['grid' + tabIndex]
            this.tab.gridHeader[tabIndex] = this.$refs['gridHeader' + tabIndex]
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            this.tab.grid[tabIndex].setGridState(false, false, false, true)
            this.tab.grid[tabIndex].gridView.setColumnLayout(
                this.view['layout' + tabIndex]
            )

            // 판매수수료조정(Tab1)일 경우
            if (tabIndex == 1) {
                //편집가능
                this.tab.grid[tabIndex].gridView.setEditOptions({
                    editable: true,
                    updatable: true,
                })
            }

            // 그리드 클릭시
            this.tab.grid[tabIndex].gridView.onCellClicked = (
                grid,
                clickData
            ) => {
                // [판매수수료조정] tab인 경우
                if (tabIndex == 1) {
                    // 조정_수수료/조정_현금매출 컬럼 클릭시 editable=false로 변경하기
                    var adjtAbleYn = grid.getValue(
                        clickData.itemIndex,
                        'adjtAbleYn'
                    )

                    if (adjtAbleYn == 'N') {
                        grid.setEditOptions({ editable: false })
                        grid.hideEditor() // 그리드 한번 클릭시 편집기 상태 닫기
                    } else {
                        grid.setEditOptions({ editable: true })
                        setTimeout(() => {
                            grid.showEditor() // 그리드 한번 클릭시 편집기 상태로 변경
                        }, 300)
                    }
                }
            }

            // 그리드 더블클릭시
            this.tab.grid[tabIndex].gridView.onCellDblClicked = (
                grid,
                clickData
            ) => {
                // [수수료 가감] 팝업 오픈하기
                if (tabIndex == 2) {
                    this.popup.gagam.showBool = true
                    this.popup.gagam.params = grid.getValues(
                        clickData.itemIndex
                    )
                    this.popup.gagam.params.isSearch = true
                    this.popup.gagam.params.isParentSearch = true
                }
                // [정산 상계] 팝업 오픈하기
                else if (tabIndex == 3) {
                    this.popup.sanggye.showBool = true
                    this.popup.sanggye.params = grid.getValues(
                        clickData.itemIndex
                    )
                    this.popup.sanggye.params.isSearch = true
                    this.popup.sanggye.params.isParentSearch = true
                }
            }
        },
        setParamJson: function (_method) {
            this.paramJson = _.cloneDeep(this.searchParams)

            // get방식으로 파라미터 넘길 때 오류로 인해 아래 제거함
            if (_method == 'GET') {
                delete this.paramJson['searchAccYm_']
                delete this.paramJson['searchOrgTree']
                delete this.paramJson['searchAccDealcoCdList']
                delete this.paramJson['checkedRows']
            }

            delete this.paramJson['searchIsPreYm_']
            return this.paramJson
        },
        /* DB에서 처리할 수 있게 row데이터를 가공해서 return */
        getChangeRowData: function (rowData) {
            // 정산일/정산확정일 날짜를 String으로 변경한다.
            rowData.accYm = AccUtil.dateToFormat(
                new Date(rowData.accYm),
                'YYYYMM'
            ).substring(0, 6)

            if (
                rowData.accFixYm != undefined &&
                !AccUtil.isEmpty(rowData.accFixYm)
            ) {
                rowData.accFixYm = AccUtil.dateToFormat(
                    new Date(rowData.accFixYm),
                    'YYYYMM'
                ).substring(0, 6)
            }

            // 판매일 날짜를 String으로 변경한다.
            if (
                rowData.saleDt != undefined &&
                !AccUtil.isEmpty(rowData.saleDt)
            ) {
                rowData.saleDt = AccUtil.dateToFormat(
                    new Date(rowData.saleDt),
                    'YYYYMMDD'
                )
            }

            return rowData
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(
                0,
                this.tab.page[this.tab.nowIndex].pageSize,
                '',
                ''
            )
        },
        setListGrid: function (list) {
            this.tab.list[this.tab.nowIndex] = list
            if (this.$refs['grid' + this.tab.nowIndex]) {
                this.$refs['grid' + this.tab.nowIndex].setRows(
                    this.tab.list[this.tab.nowIndex]
                )
            }
            // this.tab.grid[this.tab.nowIndex].setGridIndicator(
            //     resultData.pagingDto
            // ) //순번이 필요한경우 계산하는 함수
            // this.tab['gridData' + this.tab.nowIndex] = this.gridSetData()
            // this.tab['gridData' + this.tab.nowIndex].totalPage = totalPageCnt // 총페이지수
        },
        getAccDealcoCdList: function () {
            // 그리드의 정산처 목록을 변수에 저장한다.
            var searchAccDealcoCdList = []
            var list = this.tab.list[this.tab.nowIndex]
            if (list.length > 0) {
                list.map((json) => {
                    searchAccDealcoCdList.push(json.accDealcoCd)
                })
            }
            return searchAccDealcoCdList
        },
        onSearchSpOp: function () {
            this.tab.grid[0].gridView.commit()

            //  휴폐업조회기능은 판매수수료정산관리탭에서만 가능
            if (this.tab.nowIndex != 0) {
                return
            }

            // 그리드에서 휴폐업처리목록 추출
            this.searchParams.checkedRows = this.getCheckedItems('')
            if (this.searchParams.checkedRows.length == 0) {
                this.alertBodyText = '휴폐업조회 대상 정산처를 선택하십시오.'
                return
            }

            //  휴폐업조회가능여부 정산처 체크
            var rowData
            for (var i = 0; i < this.searchParams.checkedRows.length; i++) {
                rowData = this.searchParams.checkedRows[i]

                if (
                    rowData.spBrwsYn == 'N' ||
                    rowData.spOpStNm == '요청중' ||
                    rowData.accFixStCd == 'Y'
                ) {
                    this.showTcComAlert(
                        '[' +
                            rowData.accDealcoCd +
                            ', ' +
                            rowData.accDealcoNm +
                            ']은 휴폐업조회 불가능합니다.'
                    )
                    return
                }
            }

            sacApi.spOpWlessReqList(this.setParamJson('POST')).then((res) => {
                console.log(res)

                if (res.resultCode == 'SUCCESS') {
                    this.showTcComAlert('휴폐업조회 요청 되었습니다.')
                } else if (res.resultCode == 'FAIL') {
                    this.showTcComAlert(res.resultMessage)
                }

                this.onSearch()
            })
        },
        /* 판매수수료조정 Grid의 조정수수료 값을 초기화하는 함수 */
        onResetAdjtAmtTab1: function () {
            this.tab.grid[1].gridView.commit()
            var gridRowCount = this.tab.grid[1].dataProvider.getRowCount()
            for (var i = 0; i < gridRowCount; i++) {
                var rowData = this.tab.grid[1].gridView.getValues(i)
                if (
                    rowData.saleClCd == 'TSL' &&
                    (rowData.adjtCmmsAmt != 0 || rowData.adjtCashSaleAmt != 0)
                ) {
                    this.tab.grid[1].gridView.setValue(
                        i,
                        'adjtCmmsAmt',
                        rowData.adjtCmmsOldAmt
                    )
                    this.tab.grid[1].gridView.setValue(
                        i,
                        'adjtCashSaleAmt',
                        rowData.adjtCashSaleOldAmt
                    )
                }
            }
            // 그리드에서 저장할 목록을 변수에 담는다.
            this.searchParams.checkedRows = this.getCheckedItems('')
        },
        async onResetAdjtAmt() {
            // 조회조건 체크
            if (this.onSearchValidate() == false) {
                return
            }

            var gridRowCount =
                this.tab.grid[this.tab.nowIndex].dataProvider.getRowCount()
            if (gridRowCount == 0) {
                this.showTcComAlert('대상 목록이 없습니다.')
                return
            }

            // 판매수수료조정 Tab일 경우는 그리드의 조정수수료 값을 초기화한다.
            if (this.tab.nowIndex == 1) {
                this.onResetAdjtAmtTab1()

                if (this.searchParams.checkedRows.length == 0) {
                    this.showTcComAlert('대상 목록이 없습니다.')
                    return
                }
            }

            // 정산확정여부 체크
            if (this.dealcoFixCount > 0) {
                this.showTcComAlert('정산확정상태입니다.')
            } else {
                this.onResetAdjtAmtAfter()
            }
        },
        async onResetAdjtAmtAfter() {
            const confirmMsg = await this.showTcComConfirm(
                '조정금액초기화를 실행하시겠습니까?'
            )
            if (!confirmMsg) {
                return
            }

            // reset 처리
            this.tab.grid[this.tab.nowIndex].gridView.commit()
            await sacApi
                .resetAmtAccSacWlessSaleCmmsAccMgmt(this.setParamJson('POST'))
                .then((res) => {
                    console.log(res)
                    if (res.resultCode == 'SUCCESS') {
                        this.showTcComAlert('조정금액초기화가 되었습니다.')
                    } else if (res.resultCode == 'FAIL') {
                        this.showTcComAlert(res.resultMessage)
                    }
                    this.onSearch()
                })
        },
        openPopup: function (gubun, params) {
            if (AccUtil.isEmpty(this.searchParams.searchAccYm)) {
                this.showTcComAlert('먼저 정산월을 조회해 주세요.')
                return
            }
            if (AccUtil.isEmpty(this.searchParams.searchOrgCd)) {
                this.showTcComAlert('먼저 조직을 조회해 주세요.')
                return
            }
            if (AccUtil.isEmpty(params)) {
                params = {
                    isSearch: false,
                    orgCd: this.searchParams.searchOrgCd,
                    orgNm: this.searchParams.searchOrgNm,
                    orgLvl: this.searchParams.searchOrgLvl,
                    lvOrgCd: this.searchParams.searchLvOrgCd,
                    orgTree: this.searchParams.searchOrgTree,
                    accYm: this.searchParams.searchAccYm,
                    accDealcoCd: this.searchParams.searchAccDealcoCd,
                }
            }
            this.popup[gubun].showBool = true
            this.popup[gubun].params = params
            this.popup[gubun].params.isParentSearch = true
        },
        onReset: function () {
            // 파일첨부가 있는 경우 초기화
            this.file.list = []

            // 현재Tab번호를 변수에 저장한다.
            var tabNowIndex = _.cloneDeep(this.tab.nowIndex)

            // 변수 초기화
            this.searchParams = _.cloneDeep(this.searchParamsDefault)
            this.tab = _.cloneDeep(this.tabDefault)
            this.searchParams.searchTabIndex = this.tab.nowIndex

            //  회사구분조직코드
            this.searchParams.searchLvOrgCd = this.orgInfo.orgCdLvl0

            // Grid 초기화
            for (var i = 0; i < 4; i++) {
                this.tab.nowIndex = i
                this.setListGrid([])
            }

            // 원래 보였던 Tab으로 다시 이동시키기
            this.tab.nowIndex = tabNowIndex
            this.tab.tabSync1 = tabNowIndex
        },
        onSearchValidate: function () {
            var isResult = true
            if (_.isEmpty(this.searchParams.searchAccYm)) {
                this.showTcComAlert('정산월을 선택해 주세요.')
                isResult = false
            }
            if (_.isEmpty(this.searchParams.searchOrgCd)) {
                this.showTcComAlert('조직을 선택해 주세요.')
                isResult = false
            }
            if (_.isEmpty(this.searchParams.searchOrgNm)) {
                this.showTcComAlert('조직을 선택해 주세요.')
                isResult = false
            }

            return isResult
        },
        onSearch: function () {
            // 파일첨부가 있는 경우 초기화
            this.file.list = []

            if (this.tab.grid[this.tab.nowIndex].gridView) {
                this.tab.grid[this.tab.nowIndex].gridView.commit()
            }

            if (this.onSearchValidate() == false) {
                return
            }

            this.searchParams.searchTabIndex = this.tab.nowIndex
            this.onSearchPage()
        },
        onSearchPage: function () {
            var searchParams = Object.assign(
                this.setParamJson('GET'),
                this.tab.page[this.tab.nowIndex]
            )

            //  판매수수료조정 엑셀업로드시 정산월, 조직이 조회조건과
            //  변경되었는지 체크시에 사용(onSelectExcelFile 메소드)
            this.SearchChangeCl = ''
            this.searchBakupAccYm = searchParams.searchAccYm
            this.searchBackupOrgCd = searchParams.searchOrgCd
            console.log('KYJ search => ', searchParams)
            sacApi
                .getAccSacWlessSaleCmmsAccMgmtList(searchParams)
                .then((resultData) => {
                    console.log(resultData)
                    this.setListGrid(resultData.list)

                    // 정산처 확정 갯수
                    this.dealcoFixCount = resultData.dealcoFixCount

                    // 마감월 세팅
                    this.accLastClsYm = resultData.accLastClsYm

                    //  마감여부 Setting
                    this.accCloseYn = 'N'
                    if (resultData.list.length > 0) {
                        if (resultData.list[0].accCloseYnNm == '마감') {
                            this.accCloseYn = 'Y'
                        }
                        if (resultData.list[0].accCloseYnNm == '미마감') {
                            this.accCloseYn = 'N'
                            this.onActiveTabClick('S')
                        }
                    }

                    //  버튼 Control
                    this.buttonControl(0)
                })
        },
        buttonControl: function (nRow) {
            /*
                회계마감이 되었을 경우
                1) 정산상태 = "추정"
                    저장 가능, 삭제불가능, 확정불가능
                2) 정산상태 = "임시저장"
                    저장가능, 삭제가능, 확정불가능
                3) 정산상태 = "확정" && 세금계산서 = "미발행" && ERP전송 = "미확정"
                    저장불가능, 삭제불가능, 확정불가능
            */
            if (this.accCloseYn == 'Y') {
                this.button.disabled.confirm = true
                if (
                    this.tab.list[this.tab.nowIndex][nRow].accFixStNm == '추정'
                ) {
                    this.button.disabled.save = false
                    this.button.disabled.delete = true
                } else if (
                    this.tab.list[this.tab.nowIndex][nRow].accFixStNm ==
                    '임시저장'
                ) {
                    this.button.disabled.save = true
                    this.button.disabled.delete = false
                } else if (
                    this.tab.list[this.tab.nowIndex][nRow].accFixStNm == '확정'
                ) {
                    if (
                        this.tab.list[this.tab.nowIndex][nRow].erpFixStNm ==
                            '미확정' &&
                        this.tab.list[this.tab.nowIndex][nRow].taxBilStNm ==
                            '미발행'
                    ) {
                        this.button.disabled.save = true
                        this.button.disabled.delete = true
                    }
                }
            }
        },
        chgRowCnt: function (pageSize) {
            this.tab.page[this.tab.nowIndex].pageSize = pageSize
        },
        getCheckedItems: function (btnFixYn) {
            var checkedRows = []
            var rowData
            var i = 0

            // [Tab0]판매수수료정산 Tab일 경우
            if (this.tab.nowIndex == 0) {
                var checkedIndexRows =
                    this.tab.grid[this.tab.nowIndex].gridView.getCheckedItems(
                        true
                    )

                for (i = 0; i < checkedIndexRows.length; i++) {
                    rowData = this.tab.grid[
                        this.tab.nowIndex
                    ].gridView.getValues(checkedIndexRows[i])

                    //  확정(Y) / 저장(N)여부
                    rowData.fixYn = btnFixYn

                    checkedRows.push(this.getChangeRowData(rowData))
                }
            }
            // [Tab1]판매수수료조정 Tab일 경우
            else if (this.tab.nowIndex == 1) {
                var updateIndexRows =
                    this.tab.grid[this.tab.nowIndex].dataProvider.getStateRows(
                        'updated'
                    )

                if (updateIndexRows.length > 0) {
                    for (i = 0; i < updateIndexRows.length; i++) {
                        rowData = this.tab.grid[
                            this.tab.nowIndex
                        ].dataProvider.getJsonRow(updateIndexRows[i])

                        checkedRows.push(this.getChangeRowData(rowData))
                    }
                }
            }

            return checkedRows
        },
        onSaveValidate: function (mode) {
            if (this.orgInfo.orgCdLvl0 == 'O00000') {
                if (this.accLastClsYm < this.searchParams.searchAccYm) {
                    this.showTcComAlert(
                        '마감된 정산월이 아닙니다.\n최종마감월[' +
                            this.accLastClsYm +
                            ']'
                    )
                    return false
                }
            }
            if (
                this.tab.nowIndex == 0 &&
                mode == 'SAVE' &&
                this.file.list.length > 0
            ) {
                // 첨부파일이 존재하는지 여부 체크
                this.file.isAttach = true
            }

            if (this.tab.list[this.tab.nowIndex].length == 0) {
                this.showTcComAlert('조회된 데이터가 없습니다.')
                return false
            }

            if (this.searchParams.checkedRows.length == 0) {
                // 선택 or 변경사항이 없을 경우
                if (this.tab.nowIndex == 0) {
                    if (this.file.isAttach) {
                        // 목록체크없이 첨부파일만 저장하는지 여부 체크
                        this.file.isAttachOnly = true
                    } else {
                        this.showTcComAlert('선택된 목록이 없습니다.')
                        return false
                    }
                } else {
                    this.showTcComAlert('변경된 내용이 없습니다.')
                    return false
                }
            }

            // [Tab0] 판매수수료 정산일 경우 체크
            if (this.tab.nowIndex == 0) {
                var isNotPass = false
                var pJson = {}
                isNotPass = this.searchParams.checkedRows.some((json) => {
                    pJson = json
                    return (
                        json.accFixStCd == 'Y' ||
                        json.erpFixYn == 'Y' ||
                        json.taxFixYn == 'Y' ||
                        json.wireTaxStNm != '미발행' ||
                        json.spOpStNm == '요청중'
                    )
                })

                if (isNotPass) {
                    if (mode != 'DEL') {
                        if (pJson.accFixStCd == 'Y') {
                            this.showTcComAlert(
                                '정산확정 상태인 정산처가 있습니다.[' +
                                    pJson.accDealcoNm +
                                    ']'
                            )
                            return false
                        }
                    }
                    if (pJson.erpFixYn == 'Y') {
                        this.showTcComAlert(
                            'ERP 전송완료된 정산처가 있습니다.[' +
                                pJson.accDealcoNm +
                                ']'
                        )
                        return false
                    }
                    if (pJson.taxFixYn == 'Y') {
                        this.showTcComAlert(
                            '세금계산서 발행이 완료된 정산처가 있습니다.[' +
                                pJson.accDealcoNm +
                                ']'
                        )
                        return false
                    }
                    if (pJson.wireTaxStNm != '미발행') {
                        this.showTcComAlert(
                            '[정산처:' +
                                pJson.accDealcoNm +
                                ']의 유선 세금계산서 발행상태가 미발행상태가 아닙니다.'
                        )
                        return false
                    }
                    if (this.orgInfo.orgCdLvl0 == 'O00000') {
                        //  일반대리점 휴폐업체크 하지 않음
                        if (pJson.spOpStNm == '요청중') {
                            this.showTcComAlert(
                                '휴폐업조회요청중인 정산처가 있습니다.[' +
                                    pJson.accDealcoNm +
                                    ']'
                            )
                            return false
                        }
                    }
                }

                //  탭명
                this.searchParams.searchPageType =
                    this.tab.pageType[this.tab.nowIndex]
            } else if (this.tab.nowIndex == 1) {
                // 판매수수료조정 비고컬럼 단어체크
                var isChkWord = false
                this.searchParams.checkedRows.map((json) => {
                    if (!AccUtil.isEmpty(json.rmks)) {
                        if (!CommonUtil.chkRmks(json.rmks)) {
                            isChkWord = true
                            return false
                        }
                    }
                })

                if (isChkWord) {
                    return false
                }
            }

            return true
        },
        async onSave(btnFixYn) {
            if (this.tab.grid[this.tab.nowIndex].gridView) {
                this.tab.grid[this.tab.nowIndex].gridView.commit()
            }

            // 확정여부 변수에 담기
            this.searchParams.btnFixYn = btnFixYn

            // Tab0/Tab1이 아니면 저장 로직이 없으므로 return한다.
            if (this.tab.nowIndex != 0 && this.tab.nowIndex != 1) {
                return
            }

            // 그리드에서 저장할 목록을 변수에 담는다.
            this.searchParams.checkedRows = this.getCheckedItems(btnFixYn)

            // Validation 체크
            var mode = 'SAVE'
            if (btnFixYn == 'Y') {
                mode = 'CONFIRM'
            }
            if (this.onSaveValidate(mode) == false) {
                return
            }

            // 첨부파일만 저장하는 경우
            if (this.file.isAttachOnly) {
                this.doUploadFiles(btnFixYn)
                return
            }

            // 저장/확정 실행여부 확인
            var modeName = '저장'
            if (btnFixYn == 'Y') {
                modeName = '확정'
            }
            const confirmMsg = await this.showTcComConfirm(
                modeName + '하시겠습니까?'
            )
            if (!confirmMsg) {
                return
            }

            // 저장 처리
            this.tab.grid[this.tab.nowIndex].gridView.commit()
            sacApi
                .saveAccSacWlessSaleCmmsAccMgmtList(this.setParamJson('POST'))
                .then((res) => {
                    console.log(res)
                    if (AccUtil.isEmpty(res)) {
                        return
                    }

                    if (this.file.isAttach) {
                        // 첨부파일 저장함수 실행
                        this.doUploadFiles(btnFixYn)
                    } else {
                        if (res.resultCode == 'SUCCESS') {
                            this.showTcComAlert(modeName + '되었습니다.')
                        } else if (res.resultCode == 'FAIL') {
                            this.showTcComAlert(res.resultMessage)
                        }
                        this.onSearch()
                    }

                    // 확정여부 변수 'N'으로 변경
                    this.searchParams.btnFixYn = 'N'
                })
        },
        async doUploadFiles(btnFixYn) {
            if (this.file.isAttachOnly) {
                var rowData = this.tab.grid[0].dataProvider.getJsonRows()
                let list = this.file.list

                for (var j = 0; j < list.length; j++) {
                    let name = list[j].name.substring(
                        0,
                        list[j].name.indexOf('.')
                    )
                    for (var i = 0; i < rowData.length; i++) {
                        if (rowData[i].accDealcoCd.includes(name)) {
                            if (rowData[i].accFixStNm == '추정') {
                                this.showTcComAlert(
                                    '추정상태의 정산처 [' +
                                        rowData[i].accDealcoNm +
                                        ']는 파일첨부만 할 수 없습니다.'
                                )
                                return
                            }
                            break
                        }
                        if (i + 1 === rowData.length) {
                            this.showTcComAlert(
                                '조회된 내역에 [' +
                                    name +
                                    '] 첨부파일과 동일한  정산처가 없습니다.'
                            )
                            return
                        }
                    }
                }
                const confirmMsg = await this.showTcComConfirm(
                    '첨부파일을 저장하시겠습니까?'
                )
                if (!confirmMsg) {
                    return false
                }
            }

            sacApi
                .saveAccSacWlessSaleCmmsAccMgmtFileUpload(this.file.formData)
                .then((res) => {
                    console.log(res)
                    // 확정여부 변수 'N'으로 변경
                    this.searchParams.btnFixYn = 'N'

                    // 첨부파일 변수 초기화
                    this.file = _.cloneDeep(this.fileDefault)

                    if (res.resultCode == 'SUCCESS') {
                        if (btnFixYn == 'Y') {
                            this.showTcComAlert('확정되었습니다.')
                        } else {
                            this.showTcComAlert('저장되었습니다.')
                        }
                    } else if (res.resultCode == 'FAIL') {
                        this.showTcComAlert(res.resultMessage)
                    }

                    this.onSearch()
                })
        },
        async onDelete() {
            // Tab0/Tab1이 아니면 삭제 로직이 없으므로 return한다.
            if (this.tab.nowIndex != 0) {
                return
            }

            // 파일첨부가 있는 경우 초기화
            this.file.list = []

            // 그리드에서 저장할 목록을 변수에 담는다.
            this.searchParams.checkedRows = this.getCheckedItems('')

            // Validation 체크 (저장Validation체크를 삭제에서도 동일하게 사용한다.)
            if (this.onSaveValidate('DEL') == false) {
                return
            }

            // 삭제 실행여부 확인
            const confirmMsg = await this.showTcComConfirm('삭제하시겠습니까?')
            if (!confirmMsg) {
                return
            }

            // 삭제 처리
            this.tab.grid[this.tab.nowIndex].gridView.commit()
            sacApi
                .deleteAccSacWlessSaleCmmsAccMgmtList(
                    this.setParamJson('DELETE')
                )
                .then((res) => {
                    console.log(res)

                    if (res.resultCode == 'SUCCESS') {
                        this.showTcComAlert('삭제되었습니다.')
                    } else if (res.resultCode == 'FAIL') {
                        this.showTcComAlert(res.resultMessage)
                    }
                    this.onSearch()
                })
        },
        onActiveTabClick(tabIndex) {
            if (tabIndex == 'S') {
                //화면 오픈시 mounted()에서 호출
                this.tab.nowIndex = 0
                this.searchParams.searchPageType = this.tab.pageType[0]
            } else {
                this.tab.nowIndex = tabIndex
                this.searchParams.searchPageType = this.tab.pageType[tabIndex]
            }

            // 버튼 제어
            this.combo.disabled.erp = true
            this.combo.disabled.tax = true
            this.combo.disabled.accSt = true
            this.combo.disabled.spOpSt = true

            if (tabIndex == 0 || tabIndex == 'S') {
                this.button.disabled.confirm = false
                this.button.disabled.save = false
                this.button.disabled.delete = false
                this.button.disabled.resetAdjtAmt = true

                this.combo.disabled.erp = false
                this.combo.disabled.tax = false
                this.combo.disabled.accSt = false
                this.combo.disabled.spOpSt = false

                if (tabIndex == '0') {
                    this.onSearch()
                }
            } else if (tabIndex == 1) {
                this.button.disabled.confirm = true
                this.button.disabled.save = false
                this.button.disabled.delete = true
                this.button.disabled.resetAdjtAmt = false
            } else {
                this.button.disabled.confirm = true
                this.button.disabled.save = true
                this.button.disabled.delete = true
                this.button.disabled.resetAdjtAmt = false
            }
        },
        /* 화면 상단의 '정산최종이력>엑셀'', '정책별 상세>엑셀' 버튼 클릭시 onDemand 배치 등록 */
        saveOnDemandButton(searchPageType) {
            // 조회조건 Validation 체크
            if (this.onSearchValidate() == false) {
                return
            }
            // 버튼별 엑셀다운로드하기
            this.searchParams.searchPageType = searchPageType

            sacApi
                .saveAccSacWlessSaleCmmsAccMgmtOnDemand(
                    this.setParamJson('GET')
                )
                .then((res) => {
                    if (res.resultCode == 'SUCCESS') {
                        this.showTcComAlert(
                            '기준정보 > 대용량자료요청 화면에서 작업완료 확인후 데이터 다운로드 받으십시오'
                        )
                    } else {
                        this.showTcComAlert('실패했습니다.')
                    }
                })
        },
        /* 화면 상단의 엑셀다운로드 버튼 클릭시 실행 */
        exportExcelDownButton(searchPageType, excelFileName) {
            // 조회조건 Validation 체크
            if (this.onSearchValidate() == false) {
                return
            }
            // 버튼별 엑셀다운로드하기
            this.searchParams.searchPageType = searchPageType

            //  엑셀파일명(정산월 + 조직명)
            this.searchParams.excelFileName =
                '판매수수료정산관리_' +
                excelFileName +
                '_' +
                this.searchParams.searchAccYm +
                '_' +
                this.searchParams.searchOrgNm

            //  정산처가 있을 경우 엑셀파일명에 정산처명 추가
            if (!AccUtil.isEmpty(this.searchParams.searchAccDealcoNm)) {
                this.searchParams.excelFileName =
                    this.searchParams.excelFileName +
                    '_' +
                    this.searchParams.searchAccDealcoNm
            }

            sacApi
                .downloadAccSacWlessSaleCmmsAccMgmtExcelDown(
                    this.setParamJson('GET')
                )
                .then(() => {
                    this.showTcComAlert('엑셀파일이 다운로드되었습니다.')
                })
        },
        /* Tab별 엑셀업로드 버튼 클릭시 엑셀업로드 팝업이 열리게 실행 */
        openExcelUploadPopup: function (tabIndex) {
            if (this.onSearchValidate() == false) {
                return
            }
            if (this.orgInfo.orgCdLvl0 == 'O00000') {
                if (this.accLastClsYm < this.searchParams.searchAccYm) {
                    this.showTcComAlert(
                        '마감된 정산월이 아닙니다.\n최종마감월[' +
                            this.accLastClsYm +
                            ']'
                    )
                    return
                }
            }
            if (tabIndex == 1) {
                // 탐색기에서 파일을 선택하는 화면을 띄운다.
            } else if (tabIndex == 2) {
                // 수수료 가감 엑셀업로드 팝업 open
                this.popup.gagamExcelUp.showBool = true
                this.popup.gagamExcelUp.params = this.searchParams
            } else if (tabIndex == 3) {
                // 정산 상계 엑셀업로드 팝업 open
                this.popup.sanggyeExcelUp.showBool = true
                this.popup.sanggyeExcelUp.params = this.searchParams
            }
        },
        /* 판매수수료조정 Tab의 엑셀업로드 버튼 클릭시 실행 */
        onSelectExcelFile: function () {
            if (this.orgInfo.orgCdLvl0 == 'O00000') {
                if (this.accLastClsYm < this.searchParams.searchAccYm) {
                    this.showTcComAlert(
                        '마감된 정산월이 아닙니다.\n최종마감월[' +
                            this.accLastClsYm +
                            ']'
                    )
                    return
                }
            }
            if (AccUtil.isEmpty(this.searchParams.searchAccYm_)) {
                this.showTcComAlert('정산월을 입력하십시오.')
                return
            }
            if (AccUtil.isEmpty(this.searchParams.searchOrgCd)) {
                this.showTcComAlert('조직을 선택하십시오.')
                return
            }
            if (this.searchParams.searchOrgLvl != '3') {
                this.showTcComAlert('조직을 파트단위로 선택하십시오.')
                return
            }
            if (this.searchBakupAccYm != this.searchParams.searchAccYm) {
                this.SearchChangeCl = ' [정산월] '
            }
            if (this.searchBackupOrgCd != this.searchParams.searchOrgCd) {
                this.SearchChangeCl = ' [조직] '
            }
            if (!AccUtil.isEmpty(this.SearchChangeCl)) {
                this.showTcComAlert(
                    '조회 조건이 변경되었습니다' +
                        this.SearchChangeCl +
                        '\n조회후 처리하십시오.'
                )
                return
            }

            document.getElementById('excelFile').click()
        },
        /* 판매수수료조정 Tab의 엑셀업로드 파일 선택시 실행 */
        onChangeExcelFileTab3: function (f) {
            var tabNum = 1
            var pageType = 'wless'
            AccExcelUpload.onChange(
                pageType,
                tabNum,
                f,
                this.excelUp.tab3.columns,
                function () {},
                this.callbackExcelUpload
            )
        },
        /**
         * 엑셀업로드 파일을 선택한 이후에 실행되는 callback 함수
         * - 판매수수료조정 Tab에서 엑셀업로드 할 경우 적용
         */
        callbackExcelUpload: function (list) {
            if (list) {
                // 정산처/ERP확정여부 목록 조회
                this.listAccDealco = []
                this.searchParams.checkedRows = list
                sacApi
                    .getAccSacWlessSaleCmmsAccMgmtAccDealcoList(
                        this.searchParams
                    )
                    .then((resultData) => {
                        this.searchParams.checkedRows = []
                        this.listAccDealco = resultData
                        this.callbackExcelUploadValidate(list)
                    })
            }

            document.getElementById('excelFile').value = ''
        },
        /**
         * 엑셀업로드 파일을 선택한 이후에 실행되는 callback 함수
         * - 판매수수료조정 Tab에서 엑셀업로드 할 경우 적용
         */
        callbackExcelUploadValidate: function (list) {
            this.alertBodyText = ''
            this.searchParams.checkedRows = []

            for (var i = 0; i < list.length; i++) {
                // 필수항목 체크
                var checkRequired = AccExcelUpload.getCheckRequired(
                    list[i],
                    this.excelUp.tab3.required
                )
                if (checkRequired.isPass == false) {
                    this.alertBodyText = checkRequired.errMsg
                    break
                }

                // 정산처의 정산존재여부 체크
                var isAccYn = false
                var sAccDealcoCd = ''
                var sAccDealcoNm = ''
                if (this.listAccDealco) {
                    isAccYn = this.listAccDealco.some(function (json) {
                        sAccDealcoCd = list[i].accDealcoCd
                        sAccDealcoNm = list[i].accDealcoNm
                        return (
                            list[i].accDealcoCd == json.accDealcoCd &&
                            json.accExistsYn == 'Y' &&
                            json.saleClCd == 'TSL' &&
                            (json.adjtCmmsAmt != 0 || json.adjtCashSaleAmt != 0)
                        )
                    })

                    if (isAccYn) {
                        this.showTcComAlert(
                            '[' +
                                sAccDealcoCd +
                                ', ' +
                                sAccDealcoNm +
                                '] 정산확정 상태로 판매수수료조정 할 수 없습니다.'
                        )
                        return
                    }
                }

                // 판매수수료조정 대상건 Setting
                if (
                    (list[i].adjtCmmsAmt != 0 ||
                        list[i].adjtCashSaleAmt != 0) &&
                    list[i].saleClCd == 'TSL' &&
                    list[i].adjtAbleYn == 'Y'
                ) {
                    if (list[i].accClsYn == 'Y') {
                        this.alertBodyText = list[i].gnrlSaleNo + ';'
                    } else {
                        //  비고컬럼 단어체크
                        if (!AccUtil.isEmpty(list[i].rmks)) {
                            if (!CommonUtil.chkRmks(list[i].rmks)) {
                                this.searchParams.checkedRows = []
                                break
                            }
                        }
                        this.searchParams.checkedRows.push(list[i])
                    }
                }
            }

            if (this.searchParams.checkedRows.length == 0) {
                this.showTcComAlert('업로드할 데이터가 없습니다.')
                return
            }

            // 메시지가 있는 경우, 메시지 처리를 한다.
            if (this.alertBodyText) {
                this.showTcComAlert(
                    this.alertBodyText +
                        ' 정산종료 처리된 판매건은 처리되지 않습니다.'
                )
                return
            }

            // 엑셀업로드 데이터를 DB에 저장한다.
            sacApi
                .saveAccSacWlessSaleCmmsAccMgmtList(this.searchParams)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert('엑셀업로드가 완료되었습니다.')
                    this.onSearch()
                })
        },
        // 파일첨부 아이콘 클릭시 파일첨부 팝업 오픈
        onFileBtnClick() {
            this.file.showAddPopup = true
        },
        // 파일첨부 팝업에서 확인 클릭시 callback 함수
        callbackReturnFiles(returnData) {
            console.log('returnData: ', returnData)
            this.file.formData = new FormData()
            this.file.list = []
            this.file.formData.append(
                'searchAccYm',
                this.searchParams.searchAccYm
            )
            _.forEach(returnData.addFile, (item, index) => {
                this.file.formData.append('files', item.file)
                this.file.formData.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                this.file.formData.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                this.file.formData.append(
                    `admAppendFileList[${index}].screenId`,
                    this.screenId
                )
                this.file.formData.append(
                    `admAppendFileList[${index}].docId`,
                    ''
                )
                this.file.formData.append(
                    `admAppendFileList[${index}].__rowState`,
                    'created'
                )
                this.file.list.push(item.file)
            })
        },
        downloadFile(downloadFileParam) {
            attachedFileApi.downLoadFile(
                '/api/v1/backend/resource/common/file-download',
                downloadFileParam
            )
        },
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.orgParams.orgCd = this.searchParams.searchOrgCd
            this.orgParams.orgNm = this.searchParams.searchOrgNm
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.orgParams)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchParams.searchOrgCd = _.get(res[0], 'orgCd')
                        this.searchParams.searchOrgNm = _.get(res[0], 'orgNm')
                        this.searchParams.searchOrgLvl = _.get(res[0], 'vLevel')
                        this.searchParams.searchLvOrgCd = _.get(
                            res[0],
                            'orgCdLvl0'
                        )
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchParams.searchOrgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParams.searchOrgNm)) {
                this.showTcComAlert('조직명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchParams.searchOrgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchParams.searchOrgCd = _.get(returnData, 'orgCd')
            this.searchParams.searchOrgNm = _.get(returnData, 'orgNm')
            this.searchParams.searchOrgLvl = _.get(returnData, 'orgLvl')
            this.searchParams.searchLvOrgCd = _.get(returnData, 'orgCdLvl0')
            this.searchParams.searchOrgTree = _.get(returnData, 'orgNmLvl0')
            if (this.searchParams.searchOrgLvl > '0') {
                this.searchParams.searchOrgTree +=
                    ' > ' + _.get(returnData, 'orgNmLvl1')
            }
            if (this.searchParams.searchOrgLvl > '1') {
                this.searchParams.searchOrgTree +=
                    ' > ' + _.get(returnData, 'orgNmLvl2')
            }
            if (this.searchParams.searchOrgLvl > '2') {
                this.searchParams.searchOrgTree +=
                    ' > ' + _.get(returnData, 'orgNmLvl3')
            }
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        getDealcosList() {
            console.log(
                'this.searchAccDealcoParams',
                this.searchAccDealcoParams
            )
            basBcoDealcosApi
                .getDealcosList(this.searchAccDealcoParams)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.searchParams.searchAccDealcoCd = _.get(
                            res[0],
                            'dealcoCd'
                        )
                        this.searchParams.searchAccDealcoNm = _.get(
                            res[0],
                            'dealcoNm'
                        )
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        onDealcoIconClick() {
            this.resultDealcoRows = []
            if (_.isEmpty(this.searchParams.searchOrgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            this.searchAccDealcoParams.orgCd = this.searchParams.searchOrgCd
            this.searchAccDealcoParams.orgNm = this.searchParams.searchOrgNm
            this.searchAccDealcoParams.orgLvl = this.searchParams.searchOrgLvl
            this.searchAccDealcoParams.dealcoCd =
                this.searchParams.searchAccDealcoCd
            this.searchAccDealcoParams.dealcoNm =
                this.searchParams.searchAccDealcoNm
            this.searchAccDealcoParams.basDay = moment(
                this.searchParams.searchAccYm_
            ).format('YYYYMMDD')
            console.log(
                'BBBbbbb=>',
                this.searchAccDealcoParams,
                this.searchParams
            )
            // 내부거래처조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            this.resultDealcoRows = []
            if (_.isEmpty(this.searchParams.searchOrgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            if (_.isEmpty(this.searchParams.searchAccDealcoNm)) {
                this.showTcComAlert('정산처를 입력해주세요.')
                return
            }
            this.searchAccDealcoParams.orgCd = this.searchParams.searchOrgCd
            this.searchAccDealcoParams.orgNm = this.searchParams.searchOrgNm
            this.searchAccDealcoParams.orgLvl = this.searchParams.searchOrgLvl
            this.searchAccDealcoParams.dealcoCd =
                this.searchParams.searchAccDealcoCd
            this.searchAccDealcoParams.dealcoNm =
                this.searchParams.searchAccDealcoNm
            this.searchAccDealcoParams.basDay = moment(
                this.searchParams.searchAccYm_
            ).format('YYYYMMDD')
            console.log(
                'BBBbbbb=>',
                this.searchAccDealcoParams,
                this.searchParams
            )
            // 내부거래처조회
            this.getDealcosList()
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchParams.searchAccDealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchParams.searchAccDealcoCd = _.get(returnData, 'dealcoCd')
            this.searchParams.searchAccDealcoNm = _.get(returnData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================
    },
}
</script>
