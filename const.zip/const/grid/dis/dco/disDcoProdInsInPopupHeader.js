import { ValueType } from 'realgrid'
import _ from 'lodash'

export const DisDcoProdInsInGRID_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분명
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'badYnNm',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disStNm',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.TEXT, //수량
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'barCdType',
            dataType: ValueType.TEXT, //바코드타입
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT, //단말기구분
        },
        {
            fieldName: 'eqpClNm',
            dataType: ValueType.TEXT, //단말기구분명
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.TEXT, //단가
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '120',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            width: '150',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '150',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            button: 'action',
            buttonVisibility: 'always',
            header: {
                text: '모델',
                showTooltip: false,
            },
            styleCallback: function (grid, dataCell) {
                var serNum = grid.getValue(dataCell.index.itemIndex, 'serNum')
                var ret = {}
                if (!_.isEmpty(serNum)) {
                    ret.editable = false
                }
                return ret
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            button: 'action',
            buttonVisibility: 'always',
            editable: false,
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                textCase: 'upper',
            },
            header: {
                text: '* 일련번호',
                showTooltip: false,
            },
            editable: true,
            styleCallback: function (grid, dataCell) {
                var serNum = grid.getValue(dataCell.index.itemIndex, 'serNum')
                var ret = {}
                if (!_.isEmpty(serNum)) {
                    ret.editable = false
                }
                return ret
            },
        },
        {
            name: 'badYnNm',
            fieldName: 'badYnNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량여부',
                showTooltip: false,
            },
        },
        {
            name: 'disStNm',
            fieldName: 'disStNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고상태',
                showTooltip: false,
            },
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'mfactCd',
            fieldName: 'mfactCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'barCdType',
            fieldName: 'barCdType',
            visible: false,
            type: 'data',
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'eqpClNm',
            fieldName: 'eqpClNm',
            visible: false,
            type: 'data',
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'disStCd',
            fieldName: 'disStCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            visible: false,
            type: 'data',
        },
    ],
}
