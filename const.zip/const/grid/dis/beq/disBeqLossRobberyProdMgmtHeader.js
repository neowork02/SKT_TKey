import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.INT, //체크
        },
        {
            fieldName: 'riskId',
            dataType: ValueType.INT, //id
        },
        {
            fieldName: 'riskSeq',
            dataType: ValueType.INT, //번호
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT, //등록일자
        },
        {
            fieldName: 'oprUserId',
            dataType: ValueType.TEXT, //등록자ID
        },
        {
            fieldName: 'oprUserNm',
            dataType: ValueType.TEXT, //등록자명
        },
        {
            fieldName: 'oprNm',
            dataType: ValueType.TEXT, //등록자
        },
        {
            fieldName: 'modDt',
            dataType: ValueType.TEXT, //처리일자
        },
        {
            fieldName: 'bondTrmsDt',
            dataType: ValueType.TEXT, //상태변경일자
        },
        {
            fieldName: 'debtSetoffTrmsDt',
            dataType: ValueType.TEXT, //상태변경취소일자
        },
        {
            fieldName: 'riskDelYn',
            dataType: ValueType.TEXT, //삭제여부
        },
        {
            fieldName: 'clsDt',
            dataType: ValueType.TEXT, //완료일자
        },
        {
            fieldName: 'outOrgCd',
            dataType: ValueType.TEXT, //원보유처조직코드
        },
        {
            fieldName: 'outOrgNm',
            dataType: ValueType.TEXT, //원보유처조직
        },
        {
            fieldName: 'outDealcoCd',
            dataType: ValueType.TEXT, //원보유처코드
        },
        {
            fieldName: 'outDealcoNm',
            dataType: ValueType.TEXT, //원보유처명
        },
        {
            fieldName: 'outShopCd',
            dataType: ValueType.TEXT, //원보유처매장코드
        },
        {
            fieldName: 'outLvOrgCd',
            dataType: ValueType.TEXT, //원보유처레벨0조직코드
        },
        {
            fieldName: 'outLvOrgNm',
            dataType: ValueType.TEXT, //원보유처레벨0조직명
        },
        {
            fieldName: 'outLvOrgCd1',
            dataType: ValueType.TEXT, //원보유처레벨1조직코드
        },
        {
            fieldName: 'outLvOrgNm1',
            dataType: ValueType.TEXT, //원보유처레벨1조직명
        },
        {
            fieldName: 'outLvOrgCd2',
            dataType: ValueType.TEXT, //원보유처레벨2조직코드
        },
        {
            fieldName: 'outLvOrgNm2',
            dataType: ValueType.TEXT, //원보유처레벨2조직명
        },
        {
            fieldName: 'outLvOrgCd3',
            dataType: ValueType.TEXT, //원보유처레벨3조직코드
        },
        {
            fieldName: 'outLvOrgNm3',
            dataType: ValueType.TEXT, //원보유처레벨3조직명
        },
        {
            fieldName: 'inOrgCd',
            dataType: ValueType.TEXT, //현보유처조직코드
        },
        {
            fieldName: 'inOrgNm',
            dataType: ValueType.TEXT, //현보유처조직
        },
        {
            fieldName: 'inLvOrgCd',
            dataType: ValueType.TEXT, //현보유처레벨0조직코드
        },
        {
            fieldName: 'inLvOrgNm',
            dataType: ValueType.TEXT, //현보유처레벨0조직명
        },
        {
            fieldName: 'inLvOrgCd1',
            dataType: ValueType.TEXT, //현보유처레벨1조직코드
        },
        {
            fieldName: 'inLvOrgNm1',
            dataType: ValueType.TEXT, //현보유처레벨1조직명
        },
        {
            fieldName: 'inLvOrgCd2',
            dataType: ValueType.TEXT, //현보유처레벨2조직코드
        },
        {
            fieldName: 'inLvOrgNm2',
            dataType: ValueType.TEXT, //현보유처레벨2조직명
        },
        {
            fieldName: 'inLvOrgCd3',
            dataType: ValueType.TEXT, //현보유처레벨3조직코드
        },
        {
            fieldName: 'inLvOrgNm3',
            dataType: ValueType.TEXT, //현보유처레벨3조직명
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT, //현보유처코드
        },
        {
            fieldName: 'inDealcoNm',
            dataType: ValueType.TEXT, //현보유처명
        },
        {
            fieldName: 'inShopCd',
            dataType: ValueType.TEXT, //현보유처매장코드
        },
        {
            fieldName: 'inPlcNm',
            dataType: ValueType.TEXT, //현보유처
        },
        {
            fieldName: 'chrgrUserId',
            dataType: ValueType.TEXT, //영업담당자ID
        },
        {
            fieldName: 'chrgrUserNm',
            dataType: ValueType.TEXT, //영업담당
        },
        {
            fieldName: 'dealcoClCd',
            dataType: ValueType.TEXT, //거래처구분코드
        },
        {
            fieldName: 'dealCoClNm',
            dataType: ValueType.TEXT, //거래처구분
        },
        {
            fieldName: 'sktAgencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT, //서브코드
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT, //채널코드
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분명
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT, //제조사코드
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'riskLclCd',
            dataType: ValueType.TEXT, //RISK대분류코드
        },
        {
            fieldName: 'riskLclNm',
            dataType: ValueType.TEXT, //Risk 대분류
        },
        {
            fieldName: 'riskMclCd',
            dataType: ValueType.TEXT, //RISK중분류코드
        },
        {
            fieldName: 'riskMclNm',
            dataType: ValueType.TEXT, //RISK중분류명
        },
        {
            fieldName: 'riskStCd',
            dataType: ValueType.TEXT, //Risk 상태 코드
        },
        {
            fieldName: 'riskStNm',
            dataType: ValueType.TEXT, //Risk 상태
        },
        {
            fieldName: 'clsYn',
            dataType: ValueType.TEXT, //완료여부
        },
        {
            fieldName: 'fixCrdtAmt',
            dataType: ValueType.NUMBER, //여신매입가
        },
        {
            fieldName: 'realPrchsPrc',
            dataType: ValueType.NUMBER, //실제매입가
        },
        {
            fieldName: 'crdtPrchsPrc',
            dataType: ValueType.NUMBER, //Risk 금액
        },
        {
            fieldName: 'dpstAmt',
            dataType: ValueType.NUMBER, //입금(거래처)
        },
        {
            fieldName: 'etcDpstAmt',
            dataType: ValueType.NUMBER, //입금(타계좌)
        },
        {
            fieldName: 'costOpAmt',
            dataType: ValueType.NUMBER, //비용처리
        },
        {
            fieldName: 'debtSetoffAmt',
            dataType: ValueType.NUMBER, //채무상계
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'bondClctAmt',
            dataType: ValueType.TEXT, //채권회수금액
        },
        {
            fieldName: 'bondErpTrmsYn',
            dataType: ValueType.TEXT, //채권회수ERP전송여부
        },
        {
            fieldName: 'costErpTrmsYn',
            dataType: ValueType.TEXT, //비용ERP전송여부
        },
        {
            fieldName: 'dpstTrmsDt',
            dataType: ValueType.TEXT, //비용전송일자
        },
        {
            fieldName: 'debtSetoffErpTrmsYn',
            dataType: ValueType.TEXT, //채권상계ERP전송여부
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, //재고 UPD_CNT
        },
        {
            fieldName: 'erpTrmsYn',
            dataType: ValueType.TEXT, //ERP전송여부
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'badYnNm',
            dataType: ValueType.TEXT, //불량여부명
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT, //재고상태코드
        },
        {
            fieldName: 'disStNm',
            dataType: ValueType.TEXT, //재고상태명
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, //보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, //보유처명
        },
        {
            fieldName: 'hldShopCd',
            dataType: ValueType.TEXT, //보유처매장코드
        },
        {
            fieldName: 'lastInoutDt',
            dataType: ValueType.TEXT, //최종입출고일자
        },
        {
            fieldName: 'posDealcoCd',
            dataType: ValueType.TEXT, //소속거래처코드
        },
        {
            fieldName: 'posDealcoNm',
            dataType: ValueType.TEXT, //소속거래처명
        },
        {
            fieldName: 'posShopCd',
            dataType: ValueType.TEXT, //소속거래처매장코드
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //조직코드
        },
        {
            fieldName: 'orgLvl',
            dataType: ValueType.TEXT, //조직레벨
        },
        {
            fieldName: 'clsYnNm',
            dataType: ValueType.TEXT, //완료여부
        },
        {
            fieldName: 'erpTrmsDtm',
            dataType: ValueType.TEXT, //ERP전송일시
        },
        {
            fieldName: 'cnclTrmsDtm',
            dataType: ValueType.TEXT, //ERP취소전송일시
        },
    ],
    columns: [
        {
            name: 'riskId',
            fieldName: 'riskId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'id',
                showTooltip: false,
            },
            visible: false,
        },
        // {
        //     name: 'riskSeq',
        //     fieldName: 'riskSeq',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '번호',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'opDt',
            fieldName: 'opDt',
            header: {
                text: '등록일자',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'oprUserNm',
            fieldName: 'oprUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록자',
                showTooltip: false,
            },
        },
        {
            name: 'modDt',
            fieldName: 'modDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일자',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'bondTrmsDt',
            fieldName: 'bondTrmsDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상태변경일자',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'debtSetoffTrmsDt',
            fieldName: 'debtSetoffTrmsDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상태변경\n취소일자',
                styleName: 'multi-line-css',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'riskDelYn',
            fieldName: 'riskDelYn',
            type: 'data',
            header: {
                text: '삭제여부',
                showTooltip: false,
            },
        },
        {
            name: 'clsDt',
            fieldName: 'clsDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '완료일자',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'outOrgNm',
            fieldName: 'outOrgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '원보유처조직',
                showTooltip: false,
            },
        },
        {
            name: 'outDealcoCd',
            fieldName: 'outDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '원보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '원보유처',
                showTooltip: false,
            },
        },
        {
            name: 'inOrgCd',
            fieldName: 'inOrgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현보유처조직코드',
                showTooltip: false,
            },
        },
        {
            name: 'inOrgNm',
            fieldName: 'inOrgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현보유처조직',
                showTooltip: false,
            },
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현보유처코드',
                showTooltip: false,
            },
            visible: true,
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현보유처',
                showTooltip: false,
            },
            visible: true,
        },
        {
            name: 'chrgrUserNm',
            fieldName: 'chrgrUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업담당',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoClNm',
            fieldName: 'dealCoClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서브코드',
                showTooltip: false,
            },
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채널코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'riskLclNm',
            fieldName: 'riskLclNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Risk 대분류',
                showTooltip: false,
            },
        },
        {
            name: 'riskMclNm',
            fieldName: 'riskMclNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Risk 중분류',
                showTooltip: false,
            },
        },
        {
            name: 'riskStCd',
            fieldName: 'riskStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Risk 상태 코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'riskStNm',
            fieldName: 'riskStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Risk 상태',
                showTooltip: false,
            },
        },
        {
            name: 'erpTrmsDtm',
            fieldName: 'erpTrmsDtm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'ERP전송일시',
                showTooltip: false,
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'cnclTrmsDtm',
            fieldName: 'cnclTrmsDtm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'ERP취소전송일시',
                showTooltip: false,
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'clsYnNm',
            fieldName: 'clsYnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '완료여부',
                showTooltip: false,
            },
        },
        {
            name: 'clsYn',
            fieldName: 'clsYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '완료여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'fixCrdtAmt',
            fieldName: 'fixCrdtAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신매입가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'realPrchsPrc',
            fieldName: 'realPrchsPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '실제매입가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'crdtPrchsPrc',
            fieldName: 'crdtPrchsPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Risk 금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dpstAmt',
            fieldName: 'dpstAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입금(거래처)',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'etcDpstAmt',
            fieldName: 'etcDpstAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입금(타계좌)',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'costOpAmt',
            fieldName: 'costOpAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비용처리',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'debtSetoffAmt',
            fieldName: 'debtSetoffAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채무상계',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_COLOR_HEADER = {
    fields: [
        {
            fieldName: 'COLOR_CODE',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'COLOR_NM',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'COLOR_CODE',
            fieldName: 'COLOR_CODE',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'COLOR_NM',
            fieldName: 'COLOR_NM',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
    ],
}
