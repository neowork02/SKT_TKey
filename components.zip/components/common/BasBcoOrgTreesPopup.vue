<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="600px">
        <template #content>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">내부조직팝업(전체)</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <!-- SubTit -->
                    <div class="stitHead pop">
                        <h4 class="subTit">내부조직팝업(전체) 목록</h4>
                    </div>
                    <!-- // SubTit -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComDatePicker
                                    v-model="searchParam.basMth"
                                    labelName="기준년월"
                                    :objAuth="objAuth"
                                    calType="M"
                                ></TCComDatePicker>
                            </div>
                            <!-- item 2-4 -->
                            <div class="formitem div2">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- // Search_line 2 -->
                    </div>
                    <div class="contBoth">
                        <TCComInput
                            v-model="search"
                            :size="100"
                            :placeholder="'찾을 조직명을 입력해주세요.'"
                            labelName=""
                            :objAuth="objAuth"
                            ref="searchInput"
                        >
                        </TCComInput>
                        <!-- treeView -->
                        <TCComTreeview
                            v-if="items.length > 0"
                            v-model="selection"
                            :activatable="activatable"
                            :items="items"
                            :selectable="false"
                            :openAll="true"
                            selection-type="independent"
                            :returnObject="true"
                            :objAuth="objAuth"
                            :dense="true"
                            :shaped="true"
                            @input="onInput"
                            @active="onActive"
                            @open="onOpen"
                            :search="search"
                            :filter="filter"
                            :icOpenOnClick="true"
                            :open-on-click="openF"
                            @onOpenFolder="openFolder"
                            @dblclick="dblclick"
                        >
                        </TCComTreeview>
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
// eslint-disable-next-line no-unused-vars
import { CommonGrid, CommonUtil } from '@/utils'
import { M_HEADER } from '@/const/grid/bas/bco/basBcoOrgTreesHeader'
import basBcoOrgTreesApi from '@/api/biz/bas/bco/basBcoOrgTrees'
import commonApi from '@/api/common/commonCode'
import moment from 'moment'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'BasBcoAgencysPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: M_HEADER,
            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            searchParam: {
                //ordCd: '', // 내부조직팝업(전체)코드
                ordNm: '', // 내부조직팝업(전체)명
                basMth: '', // 기준년월
            },
            //commAgencyPtn: [],
            activatable: true,
            selection: [],
            selectedItem: '',
            items: '',
            // color: 'warning',
            // dense: false,
            // hoverable: true,
            // selectable: false,
            // disabled: '',
            search: null,
            caseSensitive: false,
            openF: false,
        }
    },
    computed: {
        activeOpen: {
            get() {
                //렌더링 된 이후에 포커스이동
                this.$nextTick(() => {
                    if (this.dialogShow === true) {
                        this.$refs.searchInput.inputFocus()
                    }
                })
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        filter() {
            return this.caseSensitive
                ? (item, search, textKey) => item[textKey].includes(search)
                : undefined
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('value :', value)
                this.searchParam.basMth =
                    value['basMth'] == undefined ? '' : value['basMth']
                if (
                    '' == this.parentParam.basMth ||
                    undefined == this.parentParam.basMth
                ) {
                    this.searchParam.basMth = moment().format('YYYY-MM')
                } else {
                    this.searchParam.basMth = this.parentParam.basMth
                }
                this.searchParam.orgCd =
                    value['orgCd'] == undefined ? '' : value['orgCd']
                this.searchParam.orgNm =
                    value['orgNm'] == undefined ? '' : value['orgNm']
                this.search = value['orgNm'] == undefined ? '' : value['orgNm']

                this.searchParam.vLevel =
                    value['vLevel'] == undefined ? '' : value['vLevel']
                this.searchParam.sLvlList =
                    value['sLvlList'] == undefined ? '' : value['sLvlList']
                this.searchParam.all =
                    value['all'] == undefined ? '' : value['all']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },
    async mounted() {
        await this.getOrgTreeList()
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)
    },
    methods: {
        async init() {},
        onInput(node) {
            console.log('input: ', node)
        },
        onActive(node) {
            console.log('active: ', node)
            if (node.length > 0) {
                this.selectedItem = _.clone(node[0])
            }
        },
        onOpen(node) {
            console.log('open: ', node)
        },
        openFolder(bl) {
            this.openF = bl
        },
        dblclick(node) {
            console.log(node)
            this.onConfirm()
        },
        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },
        async getOrgTreeList() {
            let param1 = { ...this.searchParam }
            param1.basMth = param1.basMth.replace(/-/g, '')
            console.log(
                '🚀 ~ file: BasBcoOrgTreesPopup.vue ~ line 255 ~ getOrgTreeList ~ param1',
                param1
            )
            basBcoOrgTreesApi.getOrgTreeList(param1).then((res) => {
                console.log('getOrgTreeList then : ', res)

                let body = res
                    //.filter((item) => item.type == 'I')
                    .map((object, index) => ({
                        ...object,
                        id: index,
                        name: object.orgNm,
                    }))
                this.items = CommonUtil.convertHierarchical(
                    body,
                    'supOrgCd',
                    'orgCd'
                )
            })
        },
        onConfirm() {
            console.log('getOrgTreeList confirm : ', this.selectedItem)
            if (this.selectedItem == '') {
                this.showAlertBool = true
                this.headerText = '내부조직팝업(전체) 선택'
                this.alertBodyText = '내부조직팝업(전체)을 선택해주세요.'
                return
            }
            let copy1 = this.clone(this.selectedItem)
            this.$emit('confirm', copy1)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        onSearch() {
            this.getOrgTreeList()
        },

        onEnterKey() {
            this.onSearch()
        },
        clone(obj) {
            if (null == obj || 'object' != typeof obj) return obj
            let copy = Object.create(null)
            for (let attr in obj) {
                if (obj.hasOwnProperty.call(obj, attr)) copy[attr] = obj[attr]
            }
            return copy
        },
    },
}
</script>
<style>
.box1 {
    height: 400px;
    overflow-y: scroll;
}
</style>
