export default {
    dualSimEqpYnList: [], //듀얼심단말여부
    svcTypCdComboList: [], // 개통유형
    opStCdComboList: [], // 처리상태
    acptPathCdComboList: [], //접수경로
    saleChnlComboList: [], //영업채널
    ageRngCdComboList: [], //연령대
    joinCardCdComboList: [], // 제휴카드사코드
    idmLmtCdComboList: [], // 유치기한
    saleTypCdComboList: [], // 판매유형
    giveMthdCdComboList: [], // 배송구분
    prodClComboList: [], // 상품구분
    agrmtClComboList: [], // 약정조건
    agrmtPrdCdComboList: [], // 약정기간코드
    scrbFeeClComboList: [], // 가입비
    mnpCmmsClComboList: [], // MNP
    frgGrtInsuClComboList: [], // 외국인보증보험료
    dealcoMgmtInfo: {},
    saleChrgrUserList: [],
    salesChrgrUserList: [],
    accDealcoList: [],
    ukeyInfo: {},
    ukeyInfoYn: {},
    suplIfList: [], //부가서비스전문
    eqpCashAmt: {}, //운영모델단가_확정여신가
    eqpInfo_: {}, //판매필요재고정보취득
    usimInfo_: {}, //usimInfo
    gearInfo_: {}, //gearInfo
    gear: [], //Gear
    generalSaleIfStatus: [],
    generalSaleIfInfo_: {}, //판매변경상세
    generalSaleInfo_: {}, //판매변경상세
    oldRtnEquipmentInfo_: {}, //판매변경상세
    allotSaleInfo_: [], //판매변경상세
    cashSaleInfo_: [], //판매변경상세
    bundleInfo_: [], //판매변경상세
    premiumRentInfo_: {}, //판매변경상세
    generalSaleDtlInfo: [], //판매변경상세
    equipmentSaleInfo: [], //판매변경상세
    suplServiceInfo: [], //판매변경상세
    sktPrprcInfo: [], //판매변경상세
    ocbMcardInfo: [], //판매변경상세
    saleCmmsInfo: {}, //판매변경상세
    promotionMoneyInfo: {}, //판매변경상세
    prodExchangeInfo: {}, //판매변경상세
    channelChgIfInfo: {}, //채널변경IF정보
    dsNetChgIfInfo: {}, //약정변경IF정보
    usimPayChgIfInfo: {}, //USIM후불취소
    disInfo: {}, //판매필요재고정보
}
