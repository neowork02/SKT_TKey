import { ValueType } from 'realgrid'

export const HEADER1 = {
    fields: [
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'staDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expirDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNo',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: {
                text: '근무지',
            },
        },
        {
            name: 'staDt',
            fieldName: 'staDt',
            header: {
                text: '시작일자',
                styleName: 'multi-line-css',
            },
            lookupDisplay: true,
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'expirDt',
            fieldName: 'expirDt',
            header: {
                text: '만료일자',
                styleName: 'multi-line-css',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
    ],
}

export const HEADER2 = {
    fields: [
        {
            fieldName: 'addOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'staDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expirDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNo',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'addOrgNm',
            fieldName: 'addOrgNm',
            header: {
                text: '내부조직',
            },
        },
        {
            name: 'staDt',
            fieldName: 'staDt',
            header: {
                text: '시작일자',
                styleName: 'multi-line-css',
            },
            lookupDisplay: true,
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'expirDt',
            fieldName: 'expirDt',
            header: {
                text: '만료일자',
                styleName: 'multi-line-css',
            },
            lookupDisplay: true,
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
    ],
}

export const HEADER3 = {
    fields: [
        {
            fieldName: 'addUserGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'staDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expirDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrp',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'addUserGrpCd',
            fieldName: 'addUserGrpCd',
            header: {
                text: '권한그룹',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            styleCallback(grid, dataCell) {
                console.log('grid, dataCell', grid, dataCell)
            },
        },
        {
            name: 'staDt',
            fieldName: 'staDt',
            header: {
                text: '시작일자',
                styleName: 'multi-line-css',
            },
            lookupDisplay: true,
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'expirDt',
            fieldName: 'expirDt',
            header: {
                text: '만료일자',
                styleName: 'multi-line-css',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
    ],
}

export const HEADER4 = {
    fields: [
        {
            fieldName: 'sktId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktIdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'sktId',
            fieldName: 'sktId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            button: 'action',
            buttonVisibility: 'always',

            header: {
                text: 'Swing ID',
                showTooltip: false,
            },
        },
        {
            name: 'sktIdNm',
            fieldName: 'sktIdNm',
            editable: false,
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing ID명',
            },
        },
        {
            name: 'sktUserId',
            fieldName: 'sktUserId',
            editable: false,
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing User ID',
            },
        },
        // {
        //     name: 'useYn',
        //     fieldName: 'useYn',
        //     editable: false,
        //     // type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '사용여부',
        //     },
        // },
        {
            name: 'useYn',
            fieldName: 'useYn',
            // editable: false,
            header: {
                text: '사용여부',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
        },
    ],
}

export const HEADER5 = {
    fields: [
        {
            fieldName: 'deptCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        /*
        {
            fieldName: 'bizDivOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizDivOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizChrgOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'teamOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ptOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ptOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orglDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orglDealcoNm',
            dataType: ValueType.TEXT,
        },
        */
    ],
    columns: [
        {
            name: 'deptCd',
            fieldName: 'deptCd',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'HR부서코드',
            },
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            width: 300,
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        /*
        {
            name: 'bizDivOrgCd',
            fieldName: 'bizDivOrgCd',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업부코드',
            },
        },
        {
            name: 'bizDivOrgNm',
            fieldName: 'bizDivOrgNm',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업부',
            },
        },
        {
            name: 'bizChrgOrgCd',
            fieldName: 'bizChrgOrgCd',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '담당코드',
            },
        },
        {
            name: 'bizChrgOrgNm',
            fieldName: 'bizChrgOrgNm',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당',
            },
        },
        {
            name: 'teamOrgCd',
            fieldName: 'teamOrgCd',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '센터코드',
            },
        },
        {
            name: 'teamOrgNm',
            fieldName: 'teamOrgNm',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '팀/센터',
            },
        },
        {
            name: 'ptOrgCd',
            fieldName: 'ptOrgCd',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'PT코드',
            },
        },
        {
            name: 'ptOrgNm',
            fieldName: 'ptOrgNm',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'PT',
            },
        },
        {
            name: 'orglDealcoCd',
            fieldName: 'orglDealcoCd',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'orglDealcoNm',
            fieldName: 'orglDealcoNm',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장명',
            },
        },
        */
    ],
}
