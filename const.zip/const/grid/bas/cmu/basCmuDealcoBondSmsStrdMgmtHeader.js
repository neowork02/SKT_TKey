import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'pagingSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ssupOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ssupOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'supOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'supOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'totCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },

        // {
        //     fieldName: 'orgCd',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpCdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'modDtm',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'modUserNm',
        //     dataType: ValueType.TEXT,
        // },

        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm3',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'treeOrgNm',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'userId',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'userNm',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'userGrpCd',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'userGrpCdNm',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'dealcoCd',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'dealcoCdNm',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'smsYn',
        //     dataType: ValueType.TEXT,
        // },
    ],
    columns: [
        // {
        //     name: 'sendYn',
        //     fieldName: 'sendYn',
        //     header: {
        //         text: '전송여부',
        //     },
        //     renderer: {
        //         type: 'check',
        //         shape: 'box',
        //         editable: true,
        //         startEditOnClick: true,
        //         trueValues: '1',
        //         falseValues: '0',
        //     },
        //     width: 50,
        // },
        {
            name: 'pagingSeq',
            fieldName: 'pagingSeq',
            header: {
                text: 'No.',
            },
            editable: false,
            width: 40,
        },
        {
            name: 'ssupOrgCd',
            fieldName: 'ssupOrgCd',
            header: {
                text: '사업담당코드',
            },
            visible: false,
        },
        {
            name: 'ssupOrgNm',
            fieldName: 'ssupOrgNm',
            header: {
                text: '사업담당명',
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'supOrgCd',
            fieldName: 'supOrgCd',
            header: {
                text: '사업팀코드',
            },
            visible: false,
        },
        {
            name: 'supOrgNm',
            fieldName: 'supOrgNm',
            header: {
                text: '사업팀명',
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            header: {
                text: '파트코드',
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: {
                text: '파트명',
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            header: {
                text: '계층파트명',
            },
            visible: false,
        },
        {
            name: 'totCnt',
            fieldName: 'totCnt',
            header: {
                text: '담당자소계',
            },
        },
        {
            name: 'useCnt',
            fieldName: 'useCnt',
            header: {
                text: 'SMS전송자계',
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '처리일시',
            },
        },

        // {
        //     name: 'orgCd',
        //     fieldName: 'orgCd',
        //     header: {
        //         text: '조직코드',
        //     },
        // },
        {
            name: 'userId',
            fieldName: 'userId',
            header: {
                text: '사용자ID',
            },
            editable: false,
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            header: {
                text: '성명',
            },
            editable: false,
        },
        {
            name: 'userGrpCd',
            fieldName: 'userGrpCd',
            header: {
                text: '사용자그룹CD',
            },
            visible: false,
        },
        {
            name: 'userGrpCdNm',
            fieldName: 'userGrpCdNm',
            header: {
                text: '사용자그룹',
            },
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            header: {
                text: '근무지코드',
            },
            editable: false,
        },
        {
            name: 'dealcoCdNm',
            fieldName: 'dealcoCdNm',
            header: {
                text: '근무지',
            },
            editable: false,
        },
        // {
        //     name: 'smsYn',
        //     fieldName: 'smsYn',
        //     header: {
        //         text: '채권SMS전송여부',
        //     },
        // },
        {
            name: 'smsYn',
            fieldName: 'smsYn',
            header: {
                text: '채권SMS전송여부',
            },
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: '0',
            },
            width: 50,
        },

        // {
        //     name: 'modDtm',
        //     fieldName: 'modDtm',
        //     header: {
        //         text: '처리일시',
        //     },
        // },
        // {
        //     name: 'modUserNm',
        //     fieldName: 'modUserNm',
        //     header: {
        //         text: '처리자',
        //     },
        // },

        {
            name: 'lvOrgCd1',
            fieldName: 'lvOrgCd1',
            header: {
                text: '조직레벨1',
            },
        },
        {
            name: 'lvOrgNm1',
            fieldName: 'lvOrgNm1',
            header: {
                text: '조직레벨명1',
            },
        },
        {
            name: 'lvOrgCd2',
            fieldName: 'lvOrgCd2',
            header: {
                text: '조직레벨2',
            },
        },
        {
            name: 'lvOrgNm2',
            fieldName: 'lvOrgNm2',
            header: {
                text: '조직레벨명2',
            },
        },
        {
            name: 'lvOrgCd3',
            fieldName: 'lvOrgCd3',
            header: {
                text: '조직레벨3',
            },
        },
        {
            name: 'lvOrgNm3',
            fieldName: 'lvOrgNm3',
            header: {
                text: '조직레벨명3',
            },
        },
        // {
        //     name: 'treeOrgNm',
        //     fieldName: 'treeOrgNm',
        //     header: {
        //         text: '계층파트명',
        //     },
        // },
        // {
        //     name: 'userId',
        //     fieldName: 'userId',
        //     header: {
        //         text: '사용자ID',
        //     },
        // },
        // {
        //     name: 'userNm',
        //     fieldName: 'userNm',
        //     header: {
        //         text: '성명',
        //     },
        // },
        // {
        //     name: 'userGrpCd',
        //     fieldName: 'userGrpCd',
        //     header: {
        //         text: '사용자그룹CD',
        //     },
        // },
        // {
        //     name: 'userGrpCdNm',
        //     fieldName: 'userGrpCdNm',
        //     header: {
        //         text: '사용자그룹명',
        //     },
        // },
        // {
        //     name: 'dealcoCd',
        //     fieldName: 'dealcoCd',
        //     header: {
        //         text: '근무지코드',
        //     },
        // },
        // {
        //     name: 'dealcoCdNm',
        //     fieldName: 'dealcoCdNm',
        //     header: {
        //         text: '근무지명',
        //     },
        // },
        // {
        //     name: 'smsYn',
        //     fieldName: 'smsYn',
        //     header: {
        //         text: 'SMS전송여부',
        //     },
        // },
    ],
}
