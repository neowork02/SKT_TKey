<template lang="">
    <div class="gridWrap">
        <TCRealGridHeader
            id="smsTrmsPrstMgmtGridHeader2"
            ref="smsTrmsPrstMgmtGridHeader2"
            gridTitle="목록"
            :gridObj="gridObj"
            :isPageRows="true"
            :isExceldown="true"
            :isNextPage="false"
            :isPageCnt="false"
            :editable="true"
            :isAddRow="false"
            :isDelRow="false"
            :addData="this.addData"
            @excelDownBtn="onClickDownload"
            @addRowBtn="this.gridAddRowBtn"
            @chkDelRowBtn="this.gridchkDelRowBtn"
        />
        <TCRealGrid
            id="smsTrmsPrstMgmtGrid2"
            ref="smsTrmsPrstMgmtGrid2"
            :fields="view.fields"
            :columns="view.columns"
        />
        <TCComPaging
            :totalPage="paging1.totalPageCnt"
            :apiFunc="pageMove"
            :rowCnt="paging1.pageSize"
            @input="pageSizeChange"
        />
        <BasBcoOrgTreesPopup
            v-if="showBcoOrgTrees"
            :parentParam="searchParam"
            :rows="resultOrgTreeRows"
            :dialogShow.sync="showBcoOrgTrees"
            @confirm="onOrgTreeReturnData"
        />
        <Detail1Popup
            v-if="showPopup1"
            :parentParam="searchPopup1"
            :rows="resultPopup1Rows"
            :dialogShow.sync="showPopup1"
            @confirm="onPopup1ReturnData"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/cmu/smsTrmsPrstMgmt/helpers'
import { M_HEADER } from '@/const/grid/bas/cmu/basCmuSmsTrmsPrstMgmtHeader'
import { CommonGrid } from '@/utils'
import CommonMsg from '@/utils/CommonMsg'
import { msgTxt } from '@/const/msg.Properties.js'
import attachedFileApi from '@/api/common/attachedFile'
//import { forEach } from 'lodash'
//====================내부조직팝업(전체)팝업====================
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
//====================//내부조직팝업(전체)팝업====================
//====================팝업1 팝업====================
import Detail1Popup from './Detail1Popup'
//====================//팝업1 팝업====================

export default {
    components: {
        BasBcoOrgTreesPopup,
        Detail1Popup,
    },
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: M_HEADER,
            layout: [
                'pagingSeq',
                'reservedDtm', //전송일시
                'usedCd', //구분
                'trmsSeq', //전송순번
                //'cmpMsgId', //전송번호 //hidden
                'lmsJobClCd', //업무구분
                'sendCl', //전송구분
                {
                    name: 'group01',
                    direction: 'horizontal',
                    items: ['sndOrg4', 'tranUserNm', 'tranUserId', 'rtnTelNo'],
                    header: {
                        text: '발신정보',
                    },
                },
                // 'sndOrg4', //발신소속PT
                // 'tranUserNm', //발신자명
                // 'tranUserId', //발신자ID
                // 'rtnTelNo', //발신번호
                {
                    name: 'group01',
                    direction: 'horizontal',
                    items: ['telNo', 'context', 'sndMsg', 'rsltValCd'],
                    header: {
                        text: '수신정보',
                    },
                },
                // 'telNo', //수신번호
                // 'context', //전체메시지
                // 'sndMsg', //분할메시지
                // 'rsltValCd', //전송결과
            ],
            addData: [],
            //행추가,수정시 필수 입력 컬럼
            requiredCols: [],
            popupRowIndex: '',
            //====================내부조직팝업(전체)팝업관련====================
            showBcoOrgTrees: false, // 내부조직팝업(전체) 팝업 오픈 여부
            searchParam: {
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultOrgTreeRows: [], // 내부조직팝업(전체) 팝업 오픈 여부
            //====================//내부조직팝업(전체)팝업관련==================
            //====================팝업1 팝업관련====================
            showPopup1: false, // 팝업1 팝업 오픈 여부
            searchPopup1: {},
            resultPopup1Rows: [], // 팝업1 팝업 오픈 여부
            //====================//팝업1 팝업관련==================
        }
    },
    async mounted() {
        //체크바
        // this.$refs.smsTrmsPrstMgmtGrid2.gridView.setCheckBar({
        //     visible: true,
        // })
        this.gridObj = this.$refs.smsTrmsPrstMgmtGrid2
        this.gridHeaderObj = this.$refs.smsTrmsPrstMgmtGridHeader2
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.setCopyOptions({
            singleMode: true,
            includeHeaderText: false,
        })

        /*
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         */
        //this.$refs.smsTrmsPrstMgmtGrid2.setGridState(true, true, true, false)
        //    this.gridObj.setGridState()
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, false, false, false)

        //체크바
        this.$refs.smsTrmsPrstMgmtGrid2.gridView.setCheckBar({
            visible: false,
        })
        //this.$refs.smsTrmsPrstMgmtGrid2.gridView.checkBar.fieldName = 'chk'

        //편집가능
        this.$refs.smsTrmsPrstMgmtGrid2.gridView.setEditOptions({
            editable: false,
            updatable: false,
        })
        //컬럼 고정
        // this.gridObj.gridView.setFixedOptions({
        //     colCount: 3,
        // })
        //dropdown combo
        //await this.dropDownSetting()

        //컬럼 크기 자동
        this.$refs.smsTrmsPrstMgmtGrid2.gridView.displayOptions.fitStyle =
            'even'

        this.$refs.smsTrmsPrstMgmtGrid2.gridView.onCellDblClicked = (
            grid,
            clickData
        ) => {
            console.log('onCellDblClicked', clickData.dataRow)
            this.gridPopup(clickData.dataRow, '')
        }

        // 셀 팝업버튼 누를때
        // this.$refs.smsTrmsPrstMgmtGrid2.gridView.onCellButtonClicked =
        //     (grid, index, column) => {
        //         this.gridPopup(
        //             index.itemIndex,
        //             column.fieldName
        //         )
        //     }

        //입력후 셀 포커스 변경될때 반응함.
        // this.$refs.smsTrmsPrstMgmtGrid2.gridView.onEditRowChanged = (
        //     grid,
        //     itemIndex,
        //     dataRow,
        //     field,
        //     oldValue,
        //     newValue
        // ) => {
        //     //let v = grid.getValue(itemIndex, field)
        //     console.log(
        //         'onEditRowChanged, ' +
        //             field +
        //             ': ' +
        //             oldValue +
        //             ' => ' +
        //             newValue,
        //         dataRow,
        //         grid._view.columnByField(field).fieldName
        //     )
        //     this.gridPopup(
        //         dataRow,
        //         grid._view.columnByField(field).fieldName,
        //         newValue
        //     )
        // }

        //keypress event와 비슷함
        // this.$refs.smsTrmsPrstMgmtGrid2.gridView.onEditChange = (
        //     grid,
        //     index,
        //     value
        // ) => {
        //     console.log(
        //         'grid.onEditChange driven, ' +
        //             index.column +
        //             ' at ' +
        //             index.dataRow +
        //             ' was replaced by value: ' +
        //             value
        //     )
        // }
    },
    computed: {
        ...serviceComputed,
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        saveAction1: {
            get() {
                return this.saveAction
            },
        },
        params: {
            get() {
                return this.searchParams
            },
        },
    },
    methods: {
        ...serviceMethods,
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 9999, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging',
                value: { ...this.paging, pageSize: pageSize },
            })
            if (this.paging1.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/cmu/smsTrmsPrstMgmt',
                this.params
            )
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            this.gridHeaderObj.setPageCount(this.paging)
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        gridAddRowBtn: function () {
            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            let focuscell = this.gridObj.gridView.getCurrent()
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
        },
        gridDelRowBtn: function () {
            // not used
            console.log('del current row')
            this.gridData.gridRows = this.gridHeaderObj.selDelRow()
        },
        gridchkDelRowBtn: function () {
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        async dropDownSetting() {
            //등록구분
            await this.dropDownCmmonCodes_({
                key: 'AGENCY_RGST_CL',
                columnName: 'agencyRgstClCd',
                option: '선택',
            })
            await this.changeDropDown('agencyRgstClCd')
            //대리점구분
            await this.dropDownCmmonCodes_({
                key: 'AGENCY_PTN',
                columnName: 'agencyClCd',
                option: '선택',
            })
            await this.changeDropDown('agencyClCd')
            //대리점유형
            await this.dropDownCmmonCodes_({
                key: 'AGENCY_TYP',
                columnName: 'agencyTypCd',
                option: '선택',
            })
            await this.changeDropDown('agencyTypCd')
            //자동배정
            await this.dropDownCmmonCodes_({
                key: 'USE_YN',
                columnName: 'disAsgnYn',
                option: '선택',
            })
            await this.changeDropDown('disAsgnYn')
            //유선이용여부
            await this.dropDownCmmonCodes_({
                key: 'USE_YN',
                columnName: 'wlClYn',
                option: '선택',
            })
            await this.changeDropDown('wlClYn')
        },
        async changeDropDown(key) {
            let col1 = this.gridObj.gridView.columnByName(key)
            col1.values = this.commDropDown[key].values
            col1.labels = this.commDropDown[key].labels
            this.gridObj.gridView.setColumn(col1)
        },
        errorCellFocus(chkCell, message) {
            this.toasting_({
                message: message,
            })
            //cell focus : { index: -1, fieldName: '' }
            this.gridObj.validationChkGrid(chkCell)
        },
        validationCheck() {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            var chk = { index: -1, fieldName: '' }
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.gridObj.dataProvider.getJsonRow(
                        index[i],
                        true
                    )

                    if (
                        row.__rowState == 'created' ||
                        row.__rowState == 'updated'
                    ) {
                        //필수 입력 체크
                        if (this.requiredCols.length) {
                            // created(추가) / updated(수정) 인경우 필수입력항목 체크
                            for (var j = 0; j < this.requiredCols.length; j++) {
                                //필수입력항목이 누락된경우
                                if (!row[this.requiredCols[j]]) {
                                    chk.index = index[i]
                                    chk.fieldName = this.requiredCols[j]

                                    this.errorCellFocus(
                                        chk,
                                        this.gridObj.gridView.columnByField(
                                            chk.fieldName
                                        ).header.text + ' 필수 입력 입니다.'
                                    )
                                    return false
                                }
                            }
                        }

                        // //적용일자 체크
                        // let fromDt = moment(row.aplyStaDt, 'YYYYMMDD').toDate()
                        // let toDt = moment(row.aplyEndDt, 'YYYYMMDD').toDate()
                        // if (fromDt > toDt) {
                        //     chk.index = index[i]
                        //     chk.fieldName = 'aplyStaDt'

                        //     this.errorCellFocus(
                        //         chk,
                        //         '적용시작일자가 적용마지막일자 보다 큽니다.'
                        //     )
                        //     return false
                        // }
                    }

                    //코드 중복 체크
                    // if (row.__rowState == 'created') {
                    //     let all1 = this.gridObj.dataProvider.getJsonRows(0, -1)
                    //     let dup1 = all1.filter(
                    //         (e) => e.sktChnlCd === row.sktChnlCd //'sktChnlCd', //UKEY채널코드
                    //     )
                    //     //UKEY채널코드 체크
                    //     if (dup1.length > 1) {
                    //         chk.index = index[i]
                    //         chk.fieldName = 'sktChnlCd'

                    //         this.errorCellFocus(chk, '중복 채널코드 입니다.')
                    //         return false
                    //     }
                    // }
                }
            } else {
                if (!this.gridData.delRows.length) {
                    this.toasting_({
                        message: msgTxt.MSG_01002,
                    })
                    return false
                }
            }

            return true
        },
        async saveData() {
            this.loading(true)
            let saveRows = []

            for (let i = 0; i < this.gridData.delRows.length; i++) {
                let e = this.gridData.delRows[i]
                saveRows.push({
                    ...e,
                    rowState: e.__rowState,
                })
            }

            var arr = []
            var cIndex = this.gridObj.dataProvider.getStateRows('created')
            var uIndex = this.gridObj.dataProvider.getStateRows('updated')
            arr.push(...cIndex)
            arr.push(...uIndex)
            for (var i = 0; i < arr.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(arr[i], true)
                saveRows.push({
                    ...row,
                    rowState: row.__rowState,
                })
            }

            //checkBar 를 사용할 경우 체크된 건만 저장처리
            if (
                this.$refs.smsTrmsPrstMgmtGrid2.gridView.checkBar.fieldName ==
                'chk'
            ) {
                saveRows = saveRows.filter((x) => {
                    return x['chk'] != null && x['chk'] == 'true'
                })
            }
            console.log('crud api call', saveRows)

            // let res1 = await this.saveSmsTrmsPrstMgmt_({ saveRows })
            // this.loading(false)
            // if (res1 == 1) {
            //     this.toasting_({
            //         message: '정상처리 되었습니다.',
            //     })
            //     //저장후 다시 조회 하는 경우
            //     this.$emit('Refresh', '')

            //     //저장후 그리드 초기화 하는 경우
            //     //this.gridObj.gridInit()
            // }
        },
        // eslint-disable-next-line no-unused-vars
        async gridPopup(row, col, val) {
            this.resultPopup1Rows = []
            this.showPopup1 = true
            this.popupRowIndex = row
            this.searchPopup1 = this.gridObj.dataProvider.getJsonRow(row)
            console.log('gridPopup', this.gridObj.dataProvider.getJsonRow(row))

            // //관리조직 공통 팝업 : 내부조직팝업(전체)(공통)
            // if (col == 'orgNm') {
            //     //TODO orgCd , orgNm 값을 팝업에서 받아와야 함
            //     this.resultOrgTreeRows = []
            //     this.showBcoOrgTrees = true
            //     this.popupRowIndex = row
            // }

            //부서명 api
            // if (col == 'orgeh') {
            //     let data = await this.getBasCmuSmsTrmsPrstMgmtCds_({
            //         param: { deptCd: val },
            //     })
            //     this.gridObj.gridView.commit()
            //     if (data.length > 0) {
            //         this.gridObj.dataProvider.setValue(
            //             row,
            //             'postDeptNm',
            //             data[0]['postDeptNm'] //
            //         )
            //     } else {
            //         this.gridObj.dataProvider.setValue(row, 'postDeptNm', '')
            //     }
            //     await this.callUserApi(row)
            // }
        },
        async callUserApi(row) {
            let val1 = this.gridObj.gridView.getValue(row, 'postDeptNm')
            let val2 = this.gridObj.gridView.getValue(row, 'dutyNm')
            let val3 = this.gridObj.gridView.getValue(row, 'rpstyNm')
            if (val1.length > 0 && val2.length > 0 && val3.length > 0) {
                let val11 = this.gridObj.gridView.getValue(row, 'orgeh')
                let val22 = this.gridObj.gridView.getValue(row, 'stell')
                let val33 = this.gridObj.gridView.getValue(row, 'jikchCd')
                let param1 = { deptCd: val11, dutyCd: val22, rpstyCd: val33 }
                let data = await this.getBasCmuSmsTrmsPrstMgmtUsers_({
                    param: param1,
                })
                if (data.length > 0) {
                    this.gridObj.dataProvider.setValue(
                        row,
                        'userCd',
                        data[0]['userCd']
                    )
                    this.gridObj.dataProvider.setValue(
                        row,
                        'userNm',
                        data[0]['userNm']
                    )
                    this.gridObj.dataProvider.setValue(
                        row,
                        'repMblPhonNo',
                        data[0]['repMblPhonNo']
                    )
                }
            } else {
                this.gridObj.dataProvider.setValue(row, 'userCd', '')
                this.gridObj.dataProvider.setValue(row, 'userNm', '')
                this.gridObj.dataProvider.setValue(row, 'repMblPhonNo', '')
            }
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onOrgTreeReturnData(retrunData) {
            this.gridObj.gridView.commit()
            console.log('retrunData: ', retrunData)
            this.gridObj.dataProvider.setValue(
                this.popupRowIndex,
                'orgCd',
                retrunData.orgCd
            )
            this.gridObj.dataProvider.setValue(
                this.popupRowIndex,
                'orgNm',
                retrunData.orgNm
            )
        },
        // 팝업1 팝업 리턴 이벤트 처리
        onPopup1ReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     retrunData.orgCd
            // )
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        resultList1(val, oldVal) {
            //console.log('resultList1 watched: ', val, oldVal, this.pageSize)
            //this.$refs.smsTrmsPrstMgmtGrid2.setRows(this.resultList)
            this.gridObj.gridView.commit()
            this.gridObj.setRows(this.resultList)

            //this.gridData = this.GridSetData() //초기화
        },
        // eslint-disable-next-line no-unused-vars
        paging1(val, oldVal) {
            //console.log('paging1 watched: ', val, oldVal)
            this.SetPaging()
        },
        // eslint-disable-next-line no-unused-vars
        async saveAction1(val, oldVal) {
            if (val == true) {
                //console.log('saveAction1: ', val, oldVal)
                this.gridObj.gridView.commit()

                console.log(
                    '변경 데이타',
                    this.gridObj.modifyGrid(), // 추가/수정 건 체크
                    this.gridData.delRows
                )
                //bug ?? saveRows 로는 추가/수정 건을 알수 없음.
                //console.log('변경 데이타 saverows ', this.gridData.saveRows)

                if (this.validationCheck()) {
                    await this.saveData()
                } else {
                    console.log('validation false')
                }

                //에러든 정상종료든 완료되면 flag처리
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: true,
                })

                //temp 임시로 두개의 saveAction 이 있다고 간주
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: true,
                })
            }
        },
    },
}
</script>
