<template>
    <div class="content">
        <!-- Tit -->
        <ul class="tit_area">
            <li class="left txtL">운영상품관리</li>
            <li class="right txtR">TDCS</li>
        </ul>
        <h3 class="tit2">검색</h3>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5">
                    <TCComComboBox
                        v-model="forms.prodclCd"
                        labelName="상품구분"
                        itemText="text"
                        itemValue="value"
                        :itemList="itemList"
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div6">
                    <TCComComboBox
                        v-model="forms.sktOpenYn"
                        labelName="SKT운영여부"
                        itemText="text"
                        itemValue="value"
                        :itemList="itemList1"
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div6">
                    <TCComComboBox
                        v-model="forms.prodChrticCd1"
                        labelName="상품특성1"
                        itemText="text"
                        itemValue="value"
                        :itemList="itemList2"
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div6">
                    <TCComComboBox
                        v-model="forms.prodChrticCd2"
                        labelName="상품특성2"
                        itemText="text"
                        itemValue="value"
                        :itemList="itemList3"
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div6">
                    <TCComComboBox
                        v-model="forms.prodChrticCd3"
                        labelName="상품특성3"
                        itemText="text"
                        itemValue="value"
                        :itemList="itemList4"
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>
            </div>
            <div class="fl_left wd43p">
                <div class="gridWrap">
                    <TCRealGridHeader
                        id="gridProdHeader"
                        ref="gridProdHeader"
                        gridTitle="전체상품"
                        :gridObj="gridObj"
                    />
                    <TCRealGrid
                        id="gridProd"
                        ref="gridProd"
                        :fields="view.fields"
                        :columns="view.columns"
                    />
                </div>
            </div>

            <div class="fl_left btn_ds1">
                <div class="div5_5 cont3">
                    <ul class="btnOrder">
                        <li>
                            <TCComButton
                                :Vuetify="false"
                                color=""
                                eClass="btnOrderright"
                                @click="onRight"
                            >
                            </TCComButton>
                        </li>
                        <li>
                            <TCComButton
                                :Vuetify="false"
                                color=""
                                eClass="btnOrderleft"
                                @click="onLeft"
                            >
                            </TCComButton>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="fl_left wd43p">
                <div class="gridWrap">
                    <TCRealGridHeader
                        id="gridProdListHeader"
                        ref="gridProdListHeader"
                        gridTitle="사용중상품"
                        :gridObj="gridObj1"
                    />
                    <TCRealGrid
                        id="gridProdList"
                        ref="gridProdList"
                        :fields="view.fields"
                        :columns="view.columns"
                    />
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import basProdApi from '@/api/biz/bas/prd/basProdMgmt'
import {
    BAS_PROD_HEADER,
    BAS_PROD_ACT_HEADER,
} from '@/const/grid/bas/prd/basProdMgmtHeader'
import CommonMixin from '@/mixins'
export default {
    name: 'BasProdMgmt',
    mixins: [CommonMixin],
    props: {},
    components: {},
    data() {
        return {
            gridObj: {},
            gridData: {},
            gridHeaderObj: {},
            gridObj1: {},
            gridData1: {},
            gridHeaderObj1: {},
            gridList: [],
            objAuth: {},
            forms: {
                prodCd: '',
                prodNm: '',
                prodclCd: '1',
            },
            from1: {},
            view: BAS_PROD_HEADER,
            view1: BAS_PROD_ACT_HEADER,
            rows: [],
            itemList: [
                {
                    value: '1',
                    text: '단말기',
                },
                {
                    value: '2',
                    text: 'USIM',
                },
                {
                    value: '3',
                    text: '스마트디바이스',
                },
                {
                    value: '4',
                    text: '일반상품',
                },
                {
                    value: '5',
                    text: '악세사리',
                },
                {
                    value: '6',
                    text: 'T.Gift',
                },
                {
                    value: '7',
                    text: '스마트홈_소품',
                },
                {
                    value: '8',
                    text: '스마트홈_단품',
                },
                {
                    value: '9',
                    text: '번들상품',
                },
            ],
            itemList1: [
                {
                    value: 'Y',
                    text: 'Y',
                },
                {
                    value: 'N',
                    text: 'N',
                },
            ],
            itemList2: [
                {
                    value: '2',
                    text: '2G',
                },
                {
                    value: '3',
                    text: '3G',
                },
                {
                    value: '6',
                    text: 'Wibro',
                },
                {
                    value: '12',
                    text: '테블릿',
                },
                {
                    value: '7',
                    text: 'KIT',
                },
                {
                    value: '9',
                    text: 'NEWBOOK',
                },
                {
                    value: '13',
                    text: '정품',
                },
                {
                    value: '14',
                    text: '일반',
                },
            ],
            itemList3: [
                {
                    value: '9',
                    text: 'Phone Acc',
                },
                {
                    value: '10',
                    text: '주변기기',
                },
                {
                    value: '11',
                    text: 'AV',
                },
                {
                    value: '12',
                    text: '스마트기기',
                },
                {
                    value: '13',
                    text: 'PC Acc',
                },
                {
                    value: '14',
                    text: '생활용품',
                },
            ],
            itemList4: [
                {
                    value: '15',
                    text: 'LTE',
                },
                {
                    value: '16',
                    text: 'LTE-A',
                },
                {
                    value: '17',
                    text: '광대역 LTE-A',
                },
                {
                    value: '11',
                    text: '스마트 폰',
                },
                {
                    value: '10',
                    text: '테블릿',
                },
                {
                    value: '12',
                    text: '피처 폰',
                },
                {
                    value: '14',
                    text: 'PPS',
                },
                {
                    value: '13',
                    text: 'KIT',
                },
                {
                    value: '18',
                    text: '케이스',
                },
                {
                    value: '19',
                    text: '케이블',
                },
                {
                    value: '20',
                    text: '충전기',
                },
                {
                    value: '21',
                    text: '배터리',
                },
                {
                    value: '22',
                    text: '펜',
                },
                {
                    value: '23',
                    text: '거치대',
                },
                {
                    value: '24',
                    text: '키보드',
                },
                {
                    value: '25',
                    text: '어댑터',
                },
                {
                    value: '26',
                    text: '기타',
                },
                {
                    value: '27',
                    text: '이어폰',
                },
                {
                    value: '28',
                    text: '헤드폰',
                },
                {
                    value: '29',
                    text: '스피커',
                },
                {
                    value: '30',
                    text: '필름',
                },
                {
                    value: '27',
                    text: '터치펜',
                },
                {
                    value: '28',
                    text: '암배드',
                },
                {
                    value: '29',
                    text: '도크링',
                },
                {
                    value: '30',
                    text: '필름',
                },
            ],
        }
    },
    mounted() {
        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.gridProdList
        this.gridHeaderObj = this.$refs.gridProdListHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, false, true, false)

        this.gridObj1 = this.$refs.gridProd
        this.gridHeaderObj1 = this.$refs.gridProdHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj1.setGridState(false, false, true, false)

        this.initGrid()

        this.basProdList()
        this.basProdActList()
    },
    methods: {
        initGrid() {
            // 그리드 이벤트 처리
            if (!this.rows.length) {
                this.onLeft()
            } else {
                this.onRight()
            }
        },
        basProdList() {
            basProdApi.basProdList(this.forms).then((resultData) => {
                this.gridList = resultData
                this.gridObj1.setRows(this.gridList)
                let pageInfo = {}
                pageInfo.type = 'noPaging' //페이징이 없는경우
                pageInfo.totalDataCnt = this.gridObj1.dataProvider.getRowCount()
                this.gridObj1.setGridIndicator(pageInfo)
            })
        },
        basProdActList() {
            basProdApi.basProdActList(this.forms).then((resultData) => {
                this.gridList = resultData
                this.gridObj.setRows(this.gridList)
                let pageInfo = {}
                pageInfo.type = 'noPaging' //페이징이 없는경우
                pageInfo.totalDataCnt = this.gridObj.dataProvider.getRowCount()
                this.gridObj.setGridIndicator(pageInfo)
            })
        },
        onLeft() {
            //체크된
            let chkRow = this.gridObj.gridView.getCheckedRows(true)
            //체크된 행 이동
            for (var i = 0; i < chkRow.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(chkRow[i])
                //그리드에 표시
                this.gridObj1.dataProvider.insertRow(0, row)
            }
            this.gridObj.dataProvider.removeRows(chkRow)
        },
        onRight() {
            let chkRow = this.gridObj1.gridView.getCheckedRows(true)
            //체크된 행 이동
            for (var i = 0; i < chkRow.length; i++) {
                let row = this.gridObj1.dataProvider.getJsonRow(chkRow[i])
                //그리드에 표시
                this.gridObj.dataProvider.addRow(row)
            }
            this.gridObj1.dataProvider.removeRows(chkRow)
        },
    },
}
</script>

<style scoped>
.fl_left {
    display: block;
    float: left;
}
.wd40p {
    width: 40%;
}
.wd43p {
    width: 43%;
}
.btn_ds1 {
    width: 13%;
    height: 60px;
    position: relative;
    margin-top: 21%;
    padding-left: 66px;
}
.left {
    float: left;
}

.right {
    float: right;
}
#gridProdList,
#gridProd {
    height: 700px !important;
}
</style>
