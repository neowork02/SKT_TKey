<!-----------------------------------------------
 * 업무그룹명: T에코 정산관리
 * 서브업무명: T에코 정산관리
 * 설명: T에코 정산관리 조회,삭제,확정,취소 한다.
 * 작성자: P180190
 * 작성일: 2022.05.30
------------------------------------------------>
<template>
    <div class="content">
        <h1>T에코 정산관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="fixBtn"
                    >확정</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="fixCancelBtn"
                    >취소</TCComButton
                >
                <!-- <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="fixBtn"
                    >확정</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="fixCancelBtn"
                    >취소</TCComButton
                > -->
            </li>
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="initBtn()"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="searchBtn"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="deletBtn"
                    >삭제</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        v-model="searchFormData.accYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchFormData.srchOrgNm"
                        :codeVal.sync="searchFormData.srchOrgCd"
                        :eRequired="true"
                        labelName="조직"
                        placeholder="선택해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="공제유형"
                        :eRequired="true"
                        :itemList="srchDedtTypNmItems"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-model="searchFormData.srchDedtTypNm"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="처리구분"
                        :itemList="srchConfirmYnItems"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-model="searchFormData.srchConfirmYn"
                    ></TCComComboBox>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="UPLOAD 리스트"
                :isPageRows="true"
                :isNextPage="false"
                :isPageCnt="true"
                :isExcelup="true"
                :isExceldown="true"
                :gridObj="this.gridObj"
                @excelDownBtn="this.downloadExcel"
                @excelUploadBtn="openExcelUploadPopup()"
            >
                <template #gridElementArea>
                    <TCComDatePicker
                        labelName="확정일"
                        calType="D"
                        class="btn_noline btn_ty04"
                        v-model="confirmDate_"
                    />
                </template>
                <template #gridBtnArea>
                    <TCComButton
                        :Vuetify="false"
                        eClass="btn_noline btn_ty04"
                        eAttr="ico_alldown"
                        labelName="전체 다운로드"
                        @click="downloadExcelAll"
                    ></TCComButton>
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getTEcoAccList"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            />

            <!-- Excell upload popup 영역 -->
            <AccPssTecoAccXls
                v-if="popup.adjustExcelUp.showBool === true"
                ref="adjustExcelUpPopup"
                :dialogShow.sync="popup.adjustExcelUp.showBool"
                :paramAccYm.sync="searchFormData"
                @confirm="onReturnTecoAccXls"
            />
            <!-- //popup 영역 -->
            <AccPssTecoAccDtl
                v-if="popup.adjustDtl.showBool === true"
                ref="popup"
                :dialogShow.sync="popup.adjustDtl.showBool"
                :popupParams.sync="popupParams"
            />
        </div>
    </div>
</template>
<script>
import { CommonGrid, CommonUtil } from '@/utils'
import tecoApi from '@/api/biz/acc/pss/accPssTecoAccMgmt'
import moment from 'moment'
import _ from 'lodash'
// 내부조직팝업
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
// 내부조직팝업
import AccPssTecoAccXls from '@/views/biz/acc/pss/AccPssTecoAccXls'
import AccPssTecoAccDtl from '@/views/biz/acc/pss/AccPssTecoAccDtl'
import { GRID_HEADER } from '@/const/grid/acc/pss/AccPssTecoAccMgmtGrid'
import CommonMixin from '@/mixins'
export default {
    name: 'AccPssTecoAccMgmt',
    components: { BasBcoAuthOrgTreesPopup, AccPssTecoAccXls, AccPssTecoAccDtl },
    mixins: [CommonMixin],
    props: {},
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,

            //Grid
            objAuth: {},
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            gridDataRaw: {},
            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
            searchForms: {},
            rowData: '',
            rowCnt: 15,
            confirmDate_: '',
            tecoAccList: [],

            //요청 파라미터
            searchFormData: {
                accYm_: moment(new Date()).format('YYYY-MM'),
                srchCoClOrgCd: '',
                srchOrgCd: '',
                srchOrgNm: '',
                srchOrgLvl: '',
                pageSize: '',
                pageNum: 1,
                srchDedtTypNm: '',
                srchConfirmYn: '',
                srchAccYm: '',
                accYm: '',
                accWrtDt: '',
            },
            // 공제유형
            srchDedtTypNmItems: [
                {
                    commCdVal: '선할인',
                    commCdValNm: '선할인',
                },
                {
                    commCdVal: '선납',
                    commCdValNm: '선납',
                },
                {
                    commCdVal: '계좌',
                    commCdValNm: '계좌',
                },
            ],
            //처리구분
            srchConfirmYnItems: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
            /* popup영역 */
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                // orgCd: '', // 내부조직팝업(권한)코드
                // orgNm: '', // 내부조직팝업(권한)명
                // srchCoClOrgCd: '',
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부

            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            //====================//내부조직팝업(권한)팝업관련==================

            popupParams: {},
            dtlParam: {},
            popup: {
                adjustExcelUp: {
                    showBool: false,
                },
                adjustDtl: {
                    showBool: false,
                },
            },
        }
    },
    mounted() {
        //PARMA초기화
        //GRID초기화
        this.setGrid()
    },
    computed: {},
    watch: {},
    created() {
        this.gridData = this.gridSetData(this.rowCnt)
    },
    methods: {
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.searchFormData.srchOrgCd
            this.searchParam.orgNm = this.searchFormData.srchOrgNm

            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchFormData.srchOrgCd = _.get(res[0], 'orgCd')
                        this.searchFormData.srchOrgNm = _.get(res[0], 'orgNm')
                        this.searchFormData.srchOrgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.searchParam.basMth = CommonUtil.onlyNumber(
                this.searchFormData.accYm_
            )
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchFormData.srchOrgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchFormData.srchOrgNm)) {
                this.showTcComAlert('조직명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchFormData.srchOrgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchFormData.srchOrgCd = _.get(retrunData, 'orgCd')
            this.searchFormData.srchOrgNm = _.get(retrunData, 'orgNm')
            this.searchFormData.srchOrgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================

        // 초기화
        initBtn: function () {
            CommonUtil.clearPage(this, 'searchFormData', this.gridObj)
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader

            this.gridObj.gridView.setRowIndicator({
                visible: true,
                headText: '번호',
            })
            this.gridObj.setGridState(true, false, true, false)
            this.gridObj.gridView.setColumnLayout(this.view.layout)
            this.$refs.grid.gridView.displayOptions.selectionStyle = 'rows'
            this.$refs.grid.gridView.onCellDblClicked = this.onCellDblClicked
        },

        gridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        //================================================
        // 전체 조회 :::: getTEcoAccList
        //================================================
        searchBtn: function () {
            //  회사구분조직코드
            this.searchFormData.srchCoClOrgCd = this.orgInfo.orgCdLvl0

            //  조직을 선택하지 않았을 경우 전체
            if (_.isEmpty(this.searchFormData.srchOrgCd)) {
                this.searchFormData.srchOrgCd = 'O00000'
                this.searchFormData.srchOrgLvl = '0'
            }

            const srchAccYm = this.searchFormData.accYm_
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
            } else {
                this.searchForms = { ...this.searchFormData }
                this.searchForms.pageSize = this.rowCnt
                this.searchForms.pageNum = 1
                this.searchForms.srchAccYm = CommonUtil.onlyNumber(
                    this.searchFormData.accYm_
                )

                this.getTEcoAccList(this.searchForms.pageNum)
            }
        },
        async getTEcoAccList(page) {
            this.searchForms.pageNum = page

            await tecoApi.getTEcoAccList(this.searchForms).then((res) => {
                if (res) {
                    this.tecoAccListDtl = res
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator(res.pagingDto)
                    this.gridData = this.gridSetData()
                    this.gridData.totalPage = res.pagingDto.totalPageCnt
                    this.gridHeaderObj.setPageCount(res.pagingDto)
                    console.log('전체리스트조회 ::::::: 끝')

                    //  확정일
                    this.confirmDate_ = moment(this.searchFormData.accYm_)
                        .endOf('month')
                        .format('YYYY-MM-DD')
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },
        //================================================
        // 선택한 row 확정 :::: fixTEcoAcc
        //================================================
        fixBtn: function () {
            var tecoAccList = this.$refs.grid.gridView.getCheckedItems(true)
            if (tecoAccList == null || tecoAccList.length == 0) {
                this.showTcComAlert('변경된 데이터가 존재하지 않습니다.')
                console.log('tecoAccList:::' + tecoAccList)
                return
            } else {
                for (var i = 0; i < tecoAccList.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(tecoAccList[i])
                    // 정산처가 매핑되지 않은 건 :: accDealcoCd
                    if (
                        row['accDealcoCd'] == '' ||
                        row['accDealcoCd'] == null
                    ) {
                        console.log(row['accDealcoCd'])
                        this.showTcComAlert(
                            '정산처가 없는 자료는 확정처리 할실수 없습니다.'
                        )
                        return
                    }
                    // 이미 정산처리가 되어 있는 건 :: confirmYn
                    if (row['confirmYn'] == 'Y') {
                        console.log(row['confirmYn'])
                        this.showTcComAlert(
                            '이미 정산된 자료는 확정처리 하실수 없습니다.'
                        )
                        return
                    }
                }
                this.showTcComConfirm(
                    this.searchFormData.accYm_ +
                        '월 자료를 확정처리 하시겠습니까?'
                ).then((confirm) => {
                    console.log('showTcComConfirm confirm: ', confirm)
                    if (confirm) {
                        // 선택한 row로 API 호출
                        // list 초기화
                        this.searchForms.tecoAccList = []
                        for (i = 0; i < tecoAccList.length; i++) {
                            var rowData = this.$refs.grid.gridView.getValues(
                                tecoAccList[i]
                            )
                            this.searchForms.tecoAccList.push({
                                accYm: CommonUtil.onlyNumber(
                                    this.searchFormData.accYm_
                                ),
                                accDealcoCd: rowData.accDealcoCd,
                                lvOrgCd2: rowData.teamOrgCd,
                                totAccAmt: rowData.totAccAmt,
                                accWrtDt: CommonUtil.onlyNumber(
                                    this.confirmDate_
                                ),
                            })
                        }
                        tecoApi
                            .fixTEcoAcc(this.searchForms)
                            .then((resultData) => {
                                if (resultData) {
                                    this.showTcComAlert('확정처리되었습니다.')
                                    this.searchBtn()
                                }
                            })
                    }
                })
            }
        },
        //================================================
        // 선택한 row 확정 취소
        //================================================
        async fixCancelBtn() {
            var tecoAccList = this.$refs.grid.gridView.getCheckedItems(true)

            if (tecoAccList == null || tecoAccList.length == 0) {
                this.showTcComAlert('선택된 데이터가 존재하지 않습니다.')
                return
            } else {
                for (var i = 0; i < tecoAccList.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(tecoAccList[i])
                    // 정산처가 매핑되지 않은 건 :: accDealcoCd
                    if (
                        row['accDealcoCd'] == '' ||
                        row['accDealcoCd'] == null
                    ) {
                        console.log(row['accDealcoCd'])
                        this.showTcComAlert(
                            '정산처가 없는 자료는 확정처리 할실수 없습니다.'
                        )
                        return
                    }
                    // 정산되지 않거나 삭제되어 있는건 :: confirmYn
                    if (row['confirmYn'] == 'N') {
                        console.log(row['confirmYn'])
                        this.showTcComAlert(
                            '확정되지 않은 자료는 취소 하실수 없습니다.'
                        )
                        return
                    }
                    // 취소가능 여부 :: canPsblYn
                    if (row['canPsblYn'] == 'N') {
                        console.log(row['canPsblYn'])
                        this.showTcComAlert(
                            'ERP전송중이거나 완료되어 취소할 수 없습니다.'
                        )
                        return
                    }
                }

                this.showTcComConfirm(
                    this.searchFormData.accYm_ +
                        '월 자료를 취소처리 하시겠습니까?'
                ).then((confirm) => {
                    if (confirm) {
                        // 선택한 row로 API 호출
                        // list 초기화
                        this.searchForms.tecoAccList = []
                        for (i = 0; i < tecoAccList.length; i++) {
                            var rowData = this.$refs.grid.gridView.getValues(
                                tecoAccList[i]
                            )
                            this.searchForms.tecoAccList.push({
                                accYm: CommonUtil.onlyNumber(
                                    this.searchFormData.accYm_
                                ),
                                accDealcoCd: rowData.accDealcoCd,
                                lvOrgCd2: rowData.teamOrgCd,
                                accWrtDt: CommonUtil.onlyNumber(
                                    this.confirmDate_
                                ),
                            })
                        }
                        console.log('searchForms ====> ', this.searchForms)
                        tecoApi
                            .cancelFixTEcoAcc(this.searchForms)
                            .then((resultData) => {
                                if (resultData) {
                                    this.showTcComAlert('취소처리되었습니다.')

                                    this.searchBtn()
                                }
                            })
                    }
                })
            }
        },
        //================================================
        // 선택한 row 삭제
        //================================================
        async deletBtn() {
            var tecoAccList = this.$refs.grid.gridView.getCheckedItems(true)
            if (tecoAccList == null || tecoAccList.length == 0) {
                this.showTcComAlert('삭제 대상을 선택하십시오.')
                return
            } else {
                for (var i = 0; i < tecoAccList.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(tecoAccList[i])
                    // 정산되지 않거나 삭제되어 있는건 :: confirmYn
                    if (row['confirmYn'] == 'Y') {
                        console.log(row['confirmYn'])
                        this.showTcComAlert(
                            tecoAccList[i] +
                                1 +
                                '번째 거래처 ' +
                                row['accDealcoNm'] +
                                '은(는) 확정이 완료되었습니다\n 취소후 삭제처리하십시오.'
                        )
                        return
                    }
                }
                this.showTcComConfirm(
                    this.searchFormData.accYm_ +
                        '월 자료를 삭제처리 하시겠습니까?'
                ).then((confirm) => {
                    console.log('showTcComConfirm confirm: ', confirm)
                    if (confirm) {
                        // 선택한 row로 API 호출
                        // list 초기화
                        this.searchForms.tecoAccList = []
                        this.searchFormData.accYm = CommonUtil.onlyNumber(
                            this.searchFormData.accYm_
                        )
                        this.searchFormData.confirmDate = CommonUtil.onlyNumber(
                            this.confirmDate_
                        )
                        for (i = 0; i < tecoAccList.length; i++) {
                            var rowData = this.$refs.grid.gridView.getValues(
                                tecoAccList[i]
                            )
                            this.searchForms.tecoAccList.push({
                                accYm: CommonUtil.onlyNumber(
                                    this.searchFormData.accYm_
                                ),
                                accDealcoCd: rowData.accDealcoCd,
                            })
                        }
                        tecoApi
                            .deleteTEcoAccList(this.searchForms)
                            .then((resultData) => {
                                if (resultData) {
                                    this.showTcComAlert('삭제처리되었습니다.')
                                    this.searchBtn()
                                }
                            })
                    }
                })
            }
        },
        //================================================
        // 상세 페이지 POPUP
        //================================================
        onCellDblClicked() {
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                this.popup.adjustDtl.showBool = true
                var rowData = grid.getValues(clickData.itemIndex)
                this.popup.adjustDtl.params = rowData
                this.popupParams.accYm_ = this.searchForms.srchAccYm
                this.popupParams.srchDedtTypNm = rowData.dedtTypNm
                this.popupParams.accDealcoCd = rowData.accDealcoCd
                this.popupParams.accDealcoNm = rowData.accDealcoNm
            }
        },

        // 팝업 닫으면 부모페이지 재조회
        onReturnTecoAccXls(retVal) {
            if (retVal) {
                console.log('retrunData: ', retVal)
                this.searchFormData.accYm_ = retVal
                this.searchBtn()
            }
        },

        //================================================
        // EXCEL UPLOAD POPUP 열기
        //================================================
        openExcelUploadPopup: function () {
            this.popup.adjustExcelUp.showBool = true
        },
        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcel: function () {
            tecoApi.downloadTEcoAccListExcel(this.searchForms)
        },
        downloadExcelAll: function () {
            this.searchForms.srchDedtTypNm = this.searchFormData.srchDedtTypNm
            this.searchForms.srchOrgCd = this.searchFormData.srchOrgCd
            tecoApi.downloadAllTEcoAccListExcel(this.searchForms)
        },
    },
}
</script>
