<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">일반모델단가표 상품 변경관리</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <!-- 등록구분 -->
                            <div class="formitem div2">
                                <TCComComboBox
                                    v-model="div_search.changeInfo"
                                    labelName="등록구분"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :itemList="changeList"
                                    @change="change"
                                ></TCComComboBox>
                            </div>
                            <!-- //등록구분 -->
                            <div class="formitem div2">
                                <TCComDatePicker
                                    v-if="v_aplyDtm.visible"
                                    labelName="변경적용시작일"
                                    v-model="div_search.aplyDtm"
                                    elementClass="iteminput"
                                    calType="DHM"
                                    :hourVal.sync="div_search.aplyStaHour"
                                    :minuVal.sync="div_search.aplyStaMin"
                                    :endHourVal.sync="div_search.aplyEndHour"
                                    :endMinuVal.sync="div_search.aplyEndMin"
                                    :disabled="!v_aplyDtm.enable"
                                    @change="onAplyDtmChange"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader"
                            ref="gridHeader"
                            :gridObj="gridObj"
                            :isPageRows="true"
                            :isPageCnt="true"
                        />
                        <TCRealGrid
                            id="grid"
                            ref="grid"
                            :editable="true"
                            :movable="false"
                            :columnMovable="false"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                        <!-- <TCComPaging
                            :totalPage="gridData.totalPage"
                            :apiFunc="getGnrlProdMgmtList"
                            :rowCnt="rowCnt"
                            :gridObj="gridObj"
                            @input="chgRowCnt"
                        /> -->
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onConfirm"
                            :objAuth="objAuth"
                        >
                            확인
                        </TCComButton>
                        <!-- 230109 기능변경으로 주석처리
                      <TCComButton
                          :eLarge="true"
                          eClass="btn_ty02"
                          @click="onCancel"
                          :objAuth="objAuth"
                      >
                          취소
                      </TCComButton>
                      -->
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import API from '@/api/biz/bas/pdm/basPdmUprcTbltnMgmt'
import { CHG_POPUP_HEADER } from '@/const/grid/bas/pdm/basPdmUprcTbltnChgMgmtPopupHeader'
import { convertDate, getTodayDate } from '@/utils/accUtil'
import _ from 'lodash'
import CommonUtil from '@/utils/CommonUtil'
import { msgTxt } from '@/const/msg.Properties'
/**************************************************************************************************************
 * 공통 LIB import 영역
 **************************************************************************************************************/
// import { NewLib } from '@/views/newlib'

export default {
    name: 'BasPdmPrcTbltnPolChgPopup',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            showAlertBool: false,
            headerText: '',
            alertBodyText: '',
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: CHG_POPUP_HEADER,
            div_search: {
                cal_polYm: '',
                aplyDtm: '',
                aplyStaHour: '',
                aplyStaMin: '',
                changeInfo: '',
            },
            ds_condition: {}, // 선택한 단가표 정보 담아둠
            changeList: [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
                {
                    commCdVal: 'CRD',
                    commCdValNm: '신규',
                },
                {
                    commCdVal: 'UPT',
                    commCdValNm: '수정',
                },
            ], // 변경여부
            v_aplyDtm: { visible: true, enable: true },
            rowCnt: 15, // 표시할 행의 갯수
            parentData: [],
            ds_prod_mgmt: [], // 변경대상 상품 리스트
        }
    },
    beforeCreated() {
        console.log('------일반모델단가표 상품 변경관리 beforeCreated------')
    },

    mounted() {
        console.log('------일반모델단가표 상품 변경관리 mounted------')
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)
        /****************** Grid **********************/
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.initGrid()
        this.initPopup(this.ds_condition)

        // 특정 필드 가리기
        this.gridObj.gridView.columnByName('prodCd').visible = false
        this.gridObj.gridView.columnByName('modRsn').visible = false
        this.gridObj.gridView.columnByName('prodClCd').visible = false
        this.gridObj.gridView.columnByName('dstrbEqpClCd').visible = false

        console.log('mounted ds_condition : ', this.ds_condition)

        /* 230109 기능변경으로 주석처리
        const aplyStaDtm = this.ds_condition.aplyStaDtm
        const ymd = aplyStaDtm.substr(0, 8)
        const hour = aplyStaDtm.substr(-4, 2)
        const min = aplyStaDtm.substr(-2, 2)
        */

        // 변경적용시작일은 현재일시로 저장한다.
        const aplyStaDtm = getTodayDate('YYYYMMDDHHmmss')
        const ymd = this.getDateTime('date', aplyStaDtm)
        // const hour = this.getDateTime('hour', aplyStaDtm)
        // const min = this.getDateTime('min', aplyStaDtm)
        const hour = '00'
        const min = '00'

        // 변경시작일시 표기
        this.div_search = {
            cal_polYm: this.ds_condition.polYm,
            aplyDtm: ymd,
            aplyStaHour: hour,
            aplyStaMin: min,
            changeInfo: 'UPT',
        }
        // 초기화
        this.v_aplyDtm = {
            visible: true,
            enable: false,
        }

        console.log('mouted this.div_search : ', this.div_search)

        // 20230109 주석처리 적용기간 diabled 처리
        // this.v_aplyDtm.enable = false
        this.onSearch()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentData', value)
                this.ds_condition = value
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, true)
            this.gridObj.setRows(this.parentData)
        },

        initPopup(condition) {
            // 오늘날짜 -> 적용시작일시, 적용종료일시와 형식 맞춰주기
            const today = new Date()
            const y = today.getFullYear()
            const m = today.getMonth() + 1
            const d =
                today.getDate().toString().length == 1
                    ? '0'.concat(today.getDate())
                    : today.getDate()
            const todayFormat = ''.concat(
                y.toString(),
                m.toString(),
                d.toString()
            )
            const aplyStaDtm = condition.aplyStaDtm.substr(0, 8)
            const aplyEndDtm = condition.aplyEndDtm.substr(0, 6)
            console.log('todayFormat : ', todayFormat)
            console.log('aplyStaDtm : ', aplyStaDtm)
            console.log('aplyEndDtm : ', aplyEndDtm)

            // crudFlag에 따른 변경적용시작일 제어
            this.checkCrudFlag(condition)
        },

        /** init 시 사용. crudFlag에 따라 적용시작일시 제어 */
        checkCrudFlag(condition) {
            console.log('crudFlag check : ', condition.crudFlag)
            if (condition.crudFlag == 'Y') {
                // 해당 정책연월의 단가표 중 단가표 적용종료일시가 마지막일 경우
                this.v_aplyDtm.enable = true
            } else if (condition.crudFlag == 'N') {
                this.v_aplyDtm.enable = false
            }
        },

        change(changeType) {
            let enable = false
            if (_.isEqual(changeType, 'CRD')) {
                enable = true
            } else if (_.isEqual(changeType, 'UPT')) {
                enable = false
            }
            this.v_aplyDtm = {
                visible: true,
                enable: enable,
            }
        },

        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        // 적용기간 변경 이벤트
        onAplyDtmChange(val) {
            console.log('onAplyDtmChange::::', val)
            this.div_search.aplyStaDtm = val[0]
            this.div_search.aplyEndDtm = val[1]
        },

        getDateTime(type, dtm) {
            if (_.isEqual(type, 'date')) {
                return convertDate(dtm.substr(0, 8), 'YYYY-MM-DD')
            } else if (_.isEqual(type, 'hour')) {
                return dtm.substr(8, 2)
            } else if (_.isEqual(type, 'min')) {
                return dtm.substr(10, 2)
            } else if (_.isEqual(type, 'sec')) {
                return dtm.substr(12, 2)
            } else {
                return dtm
            }
        },

        onSearch() {
            this.getGnrlProdMgmtList()
        },

        getGnrlProdMgmtList() {
            let paramObj = {
                uplstId: this.ds_condition.uplstId,
                polYm: this.ds_condition.polYm,
                polTs: this.ds_condition.polTs,
                aplyEndDtm: this.ds_condition.aplyEndDtm,
            }

            // 조회
            API.getGnrlProdMgmtList(paramObj).then((result) => {
                if (result != undefined) {
                    console.log('chg onSearch : ', result)
                    this.gridObj.setRows(result)
                }
            })
        },

        onConfirm() {
            // 1. 변경적용일시 점검
            //   1) 변경일시 시간 입력 예외처리
            let hour = this.div_search.aplyStaHour
            if (hour.length == 1) {
                hour = '0'.concat(hour)
                console.log('hour : ', hour)
            }
            if (parseInt(hour) > 23) {
                this.showAlertBool = true
                this.alertBodyText =
                    '변경적용시작일의 시는 23시를 넘을 수 없습니다.'
                return
            }

            //   2) 변경일시 분 입력 예외처리
            let min = this.div_search.aplyStaMin
            if (min.length == 1) {
                min = '0'.concat(min)
                console.log('min : ', min)
            }
            if (parseInt(min) > 59) {
                this.showAlertBool = true
                this.alertBodyText =
                    '변경적용시작일의 분은 59분을 넘을 수 없습니다.'
                return
            }
            //   3) 최종변경일자 - 적용시작일시와 적용종료일시 사이에 있을 때만 가능
            let check = false
            let currentAplyStaDtm =
                this.div_search.aplyDtm.replaceAll('-', '') +
                this.div_search.aplyStaHour +
                this.div_search.aplyStaMin
            console.log(
                'this.ds_condition.aplyStaDtm : ',
                this.ds_condition.aplyStaDtm
            )
            console.log(
                'this.ds_condition.aplyEndDtm : ',
                this.ds_condition.aplyEndDtm
            )
            if (this.ds_condition.aplyStaDtm > currentAplyStaDtm) {
                this.showAlertBool = true
                this.alertBodyText =
                    '변경적용일은 적용시작일자부터 적용종료일자 사이로 입력하십시오.'
                return
            } else {
                this.ds_condition.aplyStaDtm = currentAplyStaDtm
                check = true
            }

            console.log('currentAplyStaDtm : ', currentAplyStaDtm)

            const changeInfo = this.div_search.changeInfo // 변경여부

            if (_.isEmpty(changeInfo)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '변경여부를')
                )
                return
            }

            this.ds_condition.changeInfo = changeInfo

            if (check) {
                this.ds_condition.popFlag = 'N'
            } else {
                this.ds_condition.popFlag = 'Y'
            }
            // 2.confirm 시, 선택(체크)한 변경 리스트 상세로 넘김
            const checkedIndex = this.gridObj.gridView.getCheckedRows(true)
            const checkedProdList = []
            checkedIndex.forEach((chk) => {
                const data = this.gridObj.dataProvider.getJsonRow(chk)
                checkedProdList.push(data)
            })
            console.log('checkedProdList : ', checkedProdList)

            // 3. 체크한 리스트와 ds_condition 갖고 상세로 넘어가기
            this.ds_condition.hstFlag = 'Y'
            let reqParam = {
                ...this.ds_condition,
                ds_prod_mgmt: checkedProdList,
                ds_prod_mgmt_cnt: checkedProdList.length,
            }
            console.log('onConfirm reqParam : ', reqParam)
            // 일반모델단가표 상세로 이동
            this.$router.push({
                name: '/bas/pdm/BasPdmGnrlMdlUprcTbltnDtl',
                params: { search: reqParam },
            })
            this.onClose()
        },

        onCancel() {
            // 취소 시에는 아무런 상품을 추가하지 않음
            this.ds_condition.hstFlag = 'Y'
            let reqParam = {
                ...this.ds_condition,
            }
            console.log('onCancel reqParam : ', reqParam)
            // 일반모델단가표 상세로 이동
            this.$router.push({
                name: '/bas/pdm/BasPdmGnrlMdlUprcTbltnDtl',
                params: { search: reqParam },
            })
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },
    },
}
</script>
