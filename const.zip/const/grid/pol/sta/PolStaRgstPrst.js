import { ValueType } from 'realgrid'

export const GRID_INFO_TAB01 = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'ictBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFile',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            width: '100',
            header: {
                text: '정책등록일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            editable: false,
            footer: {
                text: '합계',
            },
        },
        {
            name: 'ictBase',
            fieldName: 'ictBase',
            type: 'data',
            header: {
                text: '기본단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFee',
            fieldName: 'ictFee',
            type: 'data',
            header: {
                text: '요금제정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictVas',
            fieldName: 'ictVas',
            type: 'data',
            header: {
                text: '부가서비스정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictServ',
            fieldName: 'ictServ',
            type: 'data',
            header: {
                text: '서비스별단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFile',
            fieldName: 'ictFile',
            type: 'data',
            header: {
                text: '파일업로드정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsBase',
            fieldName: 'cmsBase',
            type: 'data',
            header: {
                text: '기본단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFee',
            fieldName: 'cmsFee',
            type: 'data',
            header: {
                text: '요금제정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsVas',
            fieldName: 'cmsVas',
            type: 'data',
            header: {
                text: '부가서비스정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsServ',
            fieldName: 'cmsServ',
            type: 'data',
            header: {
                text: '서비스별단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFile',
            fieldName: 'cmsFile',
            type: 'data',
            header: {
                text: '파일업로드정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
    ],
}

export const GRID_INFO_TAB02 = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ictBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFile',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            width: '100',
            header: {
                text: '정책작성자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            footer: {
                text: '합계',
            },
        },
        {
            name: 'ictBase',
            fieldName: 'ictBase',
            type: 'data',
            header: {
                text: '기본단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFee',
            fieldName: 'ictFee',
            type: 'data',
            header: {
                text: '요금제정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictVas',
            fieldName: 'ictVas',
            type: 'data',
            header: {
                text: '부가서비스정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictServ',
            fieldName: 'ictServ',
            type: 'data',
            header: {
                text: '서비스별단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFile',
            fieldName: 'ictFile',
            type: 'data',
            header: {
                text: '파일업로드정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsBase',
            fieldName: 'cmsBase',
            type: 'data',
            header: {
                text: '기본단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFee',
            fieldName: 'cmsFee',
            type: 'data',
            header: {
                text: '요금제정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsVas',
            fieldName: 'cmsVas',
            type: 'data',
            header: {
                text: '부가서비스정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsServ',
            fieldName: 'cmsServ',
            type: 'data',
            header: {
                text: '서비스별단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFile',
            fieldName: 'cmsFile',
            type: 'data',
            header: {
                text: '파일업로드정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
    ],
}

export const GRID_INFO_TAB03 = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'polOperNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ictBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFile',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polOperNm',
            fieldName: 'polOperNm',
            type: 'data',
            width: '100',
            header: {
                text: '정책운영사',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            footer: {
                text: '합계',
            },
        },
        {
            name: 'ictBase',
            fieldName: 'ictBase',
            type: 'data',
            header: {
                text: '기본단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFee',
            fieldName: 'ictFee',
            type: 'data',
            header: {
                text: '요금제정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictVas',
            fieldName: 'ictVas',
            type: 'data',
            header: {
                text: '부가서비스정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictServ',
            fieldName: 'ictServ',
            type: 'data',
            header: {
                text: '서비스별단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFile',
            fieldName: 'ictFile',
            type: 'data',
            header: {
                text: '파일업로드정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsBase',
            fieldName: 'cmsBase',
            type: 'data',
            header: {
                text: '기본단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFee',
            fieldName: 'cmsFee',
            type: 'data',
            header: {
                text: '요금제정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsVas',
            fieldName: 'cmsVas',
            type: 'data',
            header: {
                text: '부가서비스정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsServ',
            fieldName: 'cmsServ',
            type: 'data',
            header: {
                text: '서비스별단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFile',
            fieldName: 'cmsFile',
            type: 'data',
            header: {
                text: '파일업로드정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
    ],

    layout: [
        'rowNum',
        'polOperNm',
        {
            name: '인센티브',
            direction: 'horizontal',
            items: ['ictBase', 'ictServ', 'ictFee', 'ictVas', 'ictFile'],
        },
        {
            name: '수수료',
            direction: 'horizontal',
            items: ['cmsBase', 'cmsServ', 'cmsFee', 'cmsVas', 'cmsFile'],
        },
    ],
}
export const GRID_INFO_TAB03_01 = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'polOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ictBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFile',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polOrgNm',
            fieldName: 'polOrgNm',
            type: 'data',
            width: '100',
            header: {
                text: '정책조직',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            footer: {
                text: '합계',
            },
        },
        {
            name: 'ictBase',
            fieldName: 'ictBase',
            type: 'data',
            header: {
                text: '기본단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFee',
            fieldName: 'ictFee',
            type: 'data',
            header: {
                text: '요금제정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictVas',
            fieldName: 'ictVas',
            type: 'data',
            header: {
                text: '부가서비스정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictServ',
            fieldName: 'ictServ',
            type: 'data',
            header: {
                text: '서비스별단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFile',
            fieldName: 'ictFile',
            type: 'data',
            header: {
                text: '파일업로드정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsBase',
            fieldName: 'cmsBase',
            type: 'data',
            header: {
                text: '기본단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFee',
            fieldName: 'cmsFee',
            type: 'data',
            header: {
                text: '요금제정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsVas',
            fieldName: 'cmsVas',
            type: 'data',
            header: {
                text: '부가서비스정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsServ',
            fieldName: 'cmsServ',
            type: 'data',
            header: {
                text: '서비스별단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFile',
            fieldName: 'cmsFile',
            type: 'data',
            header: {
                text: '파일업로드정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
    ],

    layout: [
        'rowNum',
        'polOrgNm',
        {
            name: '인센티브',
            direction: 'horizontal',
            items: ['ictBase', 'ictServ', 'ictFee', 'ictVas', 'ictFile'],
        },
        {
            name: '수수료',
            direction: 'horizontal',
            items: ['cmsBase', 'cmsServ', 'cmsFee', 'cmsVas', 'cmsFile'],
        },
    ],
}

export const GRID_INFO_TAB03_02 = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'polGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ictBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFile',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polGrpNm',
            fieldName: 'polGrpNm',
            type: 'data',
            width: '100',
            header: {
                text: '정책그룹',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            footer: {
                text: '합계',
            },
        },
        {
            name: 'ictBase',
            fieldName: 'ictBase',
            type: 'data',
            header: {
                text: '기본단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFee',
            fieldName: 'ictFee',
            type: 'data',
            header: {
                text: '요금제정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictVas',
            fieldName: 'ictVas',
            type: 'data',
            header: {
                text: '부가서비스정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictServ',
            fieldName: 'ictServ',
            type: 'data',
            header: {
                text: '서비스별단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFile',
            fieldName: 'ictFile',
            type: 'data',
            header: {
                text: '파일업로드정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsBase',
            fieldName: 'cmsBase',
            type: 'data',
            header: {
                text: '기본단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFee',
            fieldName: 'cmsFee',
            type: 'data',
            header: {
                text: '요금제정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsVas',
            fieldName: 'cmsVas',
            type: 'data',
            header: {
                text: '부가서비스정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsServ',
            fieldName: 'cmsServ',
            type: 'data',
            header: {
                text: '서비스별단가정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFile',
            fieldName: 'cmsFile',
            type: 'data',
            header: {
                text: '파일업로드정책',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
    ],

    layout: [
        'rowNum',
        'polGrpNm',
        {
            name: '인센티브',
            direction: 'horizontal',
            items: ['ictBase', 'ictServ', 'ictFee', 'ictVas', 'ictFile'],
        },
        {
            name: '수수료',
            direction: 'horizontal',
            items: ['cmsBase', 'cmsServ', 'cmsFee', 'cmsVas', 'cmsFile'],
        },
    ],
}
