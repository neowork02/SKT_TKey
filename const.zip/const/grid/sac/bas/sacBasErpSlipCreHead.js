import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'lvOrgNm1', // 영업본부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd1', // 영업본부 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 영업팀
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 영업팀 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'clCd', // 구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyCd', // D코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyNm', // D코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ukeyAgencyNm', // D코드명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq', // seq
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', // SUB코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tcodeCd', // T코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effStaDt', // 유효개시일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effEndDt', // 유효종료일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dChk', //
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // 수정횟수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errDesc', // 오류
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            header: '조직',
            //header: '영업팀',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            header: '조직명',
            //header: '영업팀 조직코드',
        },
        {
            name: 'clCd',
            fieldName: 'clCd',
            type: 'data',
            header: '구분코드',
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            header: 'SKT대리점코드',
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            width: '200',
            header: 'SKT대리점',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            header: 'SUB코드',
        },
        {
            name: 'tcodeCd',
            fieldName: 'tcodeCd',
            type: 'data',
            header: 'T코드',
        },
        {
            name: 'effStaDt',
            fieldName: 'effStaDt',
            type: 'data',
            header: '유효개시일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'effEndDt',
            fieldName: 'effEndDt',
            type: 'data',
            header: '유효종료일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}
export const G_HEADER2 = {
    fields: [
        {
            fieldName: 'orgNm', // 영업팀
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 영업팀 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1', // 영업본부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd1', // 영업본부 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2', // 영업팁
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd2', // 영업팀 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd3', // POST조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm3', // POST조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpNm', // 거래처그룹
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm1', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt', // 거래개시일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndDt', // 거래종료일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoShopCd', // 거래처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyCd', // D코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyNm', // D코드명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', // SUB코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tcodeCd', // T코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effStaDt', // 유효개시일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effEndDt', // 유효종료일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // 수정횟수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errDesc', // 오류
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            header: '조직명',
        },
        {
            name: 'dealcoGrpNm',
            fieldName: 'dealcoGrpNm',
            type: 'data',
            header: '거래처그룹',
        },
        {
            name: 'dealcoClNm1',
            fieldName: 'dealcoClNm1',
            type: 'data',
            header: '거래처구분',
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            type: 'data',
            header: '거래개시일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            type: 'data',
            header: '거래종료일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'dealcoShopCd',
            fieldName: 'dealcoShopCd',
            type: 'data',
            header: '거래처매장코드',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: '거래처코드',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: '거래처명',
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            header: 'SKT대리점코드',
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            header: 'SKT대리점',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            header: 'SUB코드',
        },
        {
            name: 'tcodeCd',
            fieldName: 'tcodeCd',
            type: 'data',
            header: 'T코드',
        },
        {
            name: 'effStaDt',
            fieldName: 'effStaDt',
            type: 'data',
            header: '유효개시일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'effEndDt',
            fieldName: 'effEndDt',
            type: 'data',
            header: '유효종료일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}

export const G_HEADER_REGISTER = {
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            header: '조직',
            //header: '영업팀',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            header: '조직명',
            //header: '영업팀 조직코드',
        },
        {
            name: 'clCd',
            fieldName: 'clCd',
            type: 'data',
            header: '구분코드',
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            header: 'SKT대리점코드',
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            width: '200',
            header: 'SKT대리점',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            header: 'SUB코드',
        },
        {
            name: 'tcodeCd',
            fieldName: 'tcodeCd',
            type: 'data',
            header: 'T코드',
        },
        {
            name: 'effStaDt',
            fieldName: 'effStaDt',
            type: 'data',
            header: '유효개시일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'effEndDt',
            fieldName: 'effEndDt',
            type: 'data',
            header: '유효종료일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '400',
            header: {
                text: '오류사항',
                showTooltip: false,
            },
        },
    ],
}

export const G_HEADER2_REGISTER = {
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            header: '조직명',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: '거래처코드',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: '거래처명',
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            header: 'SKT대리점코드',
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            header: 'SKT대리점',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            header: 'SUB코드',
        },
        {
            name: 'tcodeCd',
            fieldName: 'tcodeCd',
            type: 'data',
            header: 'T코드',
        },
        {
            name: 'effStaDt',
            fieldName: 'effStaDt',
            type: 'data',
            header: '유효개시일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'effEndDt',
            fieldName: 'effEndDt',
            type: 'data',
            header: '유효종료일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '400',
            header: {
                text: '오류사항',
                showTooltip: false,
            },
        },
    ],
}
