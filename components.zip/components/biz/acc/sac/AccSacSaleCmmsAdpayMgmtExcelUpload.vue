<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccSacSaleCmmsAdpayMgmtExcelUpload.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="statusShow" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">판매수수료선지급업로드</p>
                <div class="layerCont">
                    <!-- <ul class="btn_area top">
                        <li class="right">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_exeldown"
                                labelName="양식다운로드"
                                @click="excelDownload"
                            />
                        </li>
                    </ul> -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComFileInput
                                    id="excelUpload"
                                    ref="excelUpload"
                                    labelName="파일선택"
                                    v-model="fileValue"
                                    @change="loadExcel"
                                />
                            </div>
                            <div
                                class="formitem div2"
                                style="margin-top: -14px"
                            >
                                <button
                                    type="button"
                                    class="btn_s btn_ty03"
                                    @click="clickValidate"
                                >
                                    오류검증
                                </button>
                                <button
                                    type="button"
                                    class="btn_s btn_ty03"
                                    :disabled="!isValid"
                                    @click="submit"
                                >
                                    엑셀반영
                                </button>
                            </div>
                        </div>
                    </div>

                    <AccGridTable
                        ref="accGridTable"
                        title="판매수수료선지급 엑셀업로드"
                        isColumnNo
                        noPaging
                        :offset="[]"
                        :gridMeta="GRID_HEADER"
                        :data="data"
                    >
                        <template #gridBtnArea>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_exeldown"
                                labelName="양식다운로드"
                                @click="excelDownload"
                            />
                        </template>
                    </AccGridTable>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom"></div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <button
                        type="button"
                        class="layerClose b-close"
                        @click="closePopup"
                    >
                        닫기
                    </button>
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'
import _ from 'lodash'

import {
    // gridMetaUtil,
    getTodayDate,
} from '@/utils/accUtil'

import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import { GRID_HEADER } from '@/const/grid/acc/sac/accSacSaleCmmsAdpayMgmtExcelUploadGrid'

import sacApi from '@/api/biz/acc/sac'
import attachApi from '@/api/common/attachedFile'

export default {
    name: 'AccSacSaleCmmsAdpayMgmtExcelUpload',
    mixins: [CommonMixin, accMixin],
    components: { AccGridTable },
    props: {
        status: {
            default: false,
        },

        query: {
            default: () => ({}),
        },
    },

    data() {
        return {
            GRID_HEADER,
            data: [],
            file: null,
            isValid: false,
            fileValue: null,
        }
    },

    computed: {
        statusShow: {
            get() {
                return this.status
            },
            set(value) {
                this.$emit('update:status', value)
            },
        },
    },

    watch: {},

    created() {},
    mounted() {},
    methods: {
        closePopup() {
            this.data = []
            this.fileValue = null
            this.isValid = false
            this.statusShow = false

            this.$emit('close')
        },

        //  엑셀업로드
        loadExcel(files) {
            if (!_.isUndefined(files) && !_.isNull(files)) {
                const formData = new FormData()
                formData.append('files', files)
                sacApi.getParseExcelAdpayTcip(formData).then((res) => {
                    console.log('res', res)
                    res.forEach((row) => {
                        row.errDesc = ''
                    })
                    this.file = res
                    this.data = res
                })
            }
        },

        //  오류검증
        clickValidate() {
            if (!this.file) {
                return this.showTcComAlert(
                    (this.data = `업로드 문서에 처리 할 데이터가 없습니다.\n업로드 문서를 확인하시기 바랍니다.`)
                )
            }

            return sacApi
                .postAccSacAccsExcelCheck({
                    excelCheckVoList: this.accGridTable.getAllRow(),
                })
                .then((res) => {
                    console.log(res)
                    this.data = res
                    this.isValid = true
                })
        },

        excelDownload() {
            attachApi.downloadSampleFile('405')
        },

        //  엑셀반영
        async submit() {
            if (
                await this.showTcComConfirm(
                    '오류사항이 발생된 행은 업로드 시 자동 제외 합니다. \n계속 하시겠습니까?'
                )
            ) {
                const rows = []
                this.data.forEach((arr) => {
                    if (arr.errDesc == '') {
                        rows.push(
                            Object.assign(arr, {
                                payReqDt: getTodayDate('YYYYMMDD'),
                                accMth: this.query.accMth,
                            })
                        )
                    }
                })

                return sacApi
                    .postAccSacAccsExcelUpload({ excelInputVoList: rows })
                    .then((res) => {
                        console.log(res)
                        this.showTcComAlert(`정상적으로 처리되었습니다.`)
                        this.closePopup()
                    })
            }
        },
    },
}
</script>
