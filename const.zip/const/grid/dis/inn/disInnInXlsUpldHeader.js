import { ValueType } from 'realgrid'

export const DisInnInMgmtXlsUpldGRID_HEADER = {
    fields: [
        {
            fieldName: 'inSchdDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'amt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAmt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'barCdType',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'excelClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchTypCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'inSchdDt',
            fieldName: 'inSchdDt',
            type: 'data',
            datetimeFormat: 'yyyy-MM-dd',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '일자',
            },
        },
        {
            name: 'prchsDealcoCd',
            fieldName: 'prchsDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매입처 코드',
                showTooltip: false,
            },
        },
        {
            name: 'prchsDealcoNm',
            fieldName: 'prchsDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매입처명',
                showTooltip: false,
            },
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처 코드',
                showTooltip: false,
            },
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처명',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
            width: '180',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'amt',
            fieldName: 'amt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '금액',
                showTooltip: false,
            },
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매단가',
                showTooltip: false,
            },
        },
        {
            name: 'barCdType',
            fieldName: 'barCdType',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            styles: {
                textAlignment: 'near',
            },
            header: {
                text: '오류사항',
                showTooltip: true,
            },
            width: '300',
        },
        {
            name: 'excelClCd',
            fieldName: 'excelClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'inClCd',
            fieldName: 'inClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'prchTypCd',
            fieldName: 'prchTypCd',
            visible: false,
            type: 'data',
        },
    ],
}
