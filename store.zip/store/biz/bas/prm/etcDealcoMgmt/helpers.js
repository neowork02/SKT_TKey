import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('bas.prm.etcDealcoMgmtStore', Object.keys(state)),
    ...mapGetters('bas.prm.etcDealcoMgmtStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('bas.prm.etcDealcoMgmtStore', Object.keys(actions)),
    ...mapMutations('bas.prm.etcDealcoMgmtStore', Object.keys(mutations)),
}
