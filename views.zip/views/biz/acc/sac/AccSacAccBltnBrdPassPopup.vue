<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="400px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">비밀번호 입력</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap small">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="비밀번호 입력"
                                    v-model="inputPassword"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 1-1 -->
                        </div>
                        <!-- Search_line 1 -->
                    </div>
                    <!-- //Search_div -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="onConfirm"
                            >확인</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >취소</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
export default {
    name: 'AccSacAccBltnBrdPassPopup',
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            inputPassword: '',
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {},
    methods: {
        //  확인
        onConfirm: function () {
            this.$emit('confirm', this.inputPassword)
            this.activeOpen = false
        },
        //팝업닫기
        closeBtn: function () {
            this.activeOpen = false
        },
    },
}
</script>
