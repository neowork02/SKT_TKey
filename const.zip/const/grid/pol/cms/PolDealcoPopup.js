import { ValueType } from 'realgrid'

export let GRID_INFO = {
    fields: [
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            type: 'data',
            width: '400',
            header: {
                text: '조직',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: {
                text: '매장명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}
