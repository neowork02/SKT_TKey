import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('bas.cmu.smsTrmsTypHappyMgmtStore', Object.keys(state)),
    ...mapGetters('bas.cmu.smsTrmsTypHappyMgmtStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('bas.cmu.smsTrmsTypHappyMgmtStore', Object.keys(actions)),
    ...mapMutations('bas.cmu.smsTrmsTypHappyMgmtStore', Object.keys(mutations)),
}
