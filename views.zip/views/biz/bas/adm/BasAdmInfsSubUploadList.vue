<template>
    <div class="content">
        <h1>정산파일업로드조회</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearchClick"
                >
                    조회
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5_1">
                    <TCComComboBox
                        v-model="searchParam.gubun"
                        labelName="구분"
                        :itemList="downupList"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div3">
                    <TCComDatePicker
                        v-model="calYearMonth"
                        calType="M"
                        labelName="정산년월"
                        :eRequired="true"
                    ></TCComDatePicker>
                </div>
                <div class="formitem div3">
                    <TCComInput
                        v-model="searchParam.titleNm"
                        labelName="제목"
                        @enterKey="onSearchClick"
                    >
                    </TCComInput>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="subUploadGridHeader"
                ref="subUploadGridHeader"
                gridTitle="목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="false"
            />
            <TCRealGrid
                id="subUploadGrid"
                ref="subUploadGrid"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getSubUploadList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="onChgRowCnt"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import { SUB_UPLOAD_HEADER } from '@/const/grid/bas/adm/basAdmInfsSubUploadHeader'
import basAdmInfsSubUploadApi from '@/api/biz/bas/adm/basAdmInfsSubUploadApi'
import CommonMixin from '@/mixins'
// import _ from 'lodash'

export default {
    name: 'BasAdmInfsSubUploadList',
    components: {},
    mixins: [CommonMixin],

    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            view: SUB_UPLOAD_HEADER,
            rowCnt: 15,
            downupList: [
                { commCdVal: 'U', commCdValNm: '업로드' },
                { commCdVal: 'D', commCdValNm: '다운로드' },
            ],
            //각각 엘리먼트 컴포넌트 v-model
            searchParam: {
                gubun: '',
                calYearMonth: '',
                titleNm: '',
                pageNum: 1,
                pageSize: 15,
            },
            calYearMonth: '',
            selectedJsonData: {},
            selectedRow: '',
        }
    },

    created() {
        this.init()
    },

    mounted() {
        // console.log('menuInfo', this.menuInfo) //메뉴정보
        // console.log('orgInfo', this.orgInfo) //조직정보
        // console.log('userInfo', this.userInfo) //사용자정보
        // console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        this.gridObj = this.$refs.subUploadGrid
        this.gridHeaderObj = this.$refs.subUploadGridHeader
        this.gridObj.setGridState(true, false, false, false)
        this.setGridEvent()
    },

    methods: {
        init() {
            this.gridData = this.gridSetData()
            // 정산년월
            this.calYearMonth = CommonUtil.getCurrentMonth('YYYY-MM')
        },

        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        setGridEvent() {},

        // 조회 버튼 이벤트
        onSearchClick() {
            this.gridData.totalPage = 0
            this.getSubUploadList()
        },

        // 페이지 표시 행의 수 변경처리
        onChgRowCnt(val) {
            this.rowCnt = val
        },

        getSubUploadList(pageNum) {
            this.searchParam.calYearMonth = CommonUtil.replaceDash(
                this.calYearMonth
            )
            this.searchParam.pageNum = pageNum ?? 1
            this.searchParam.pageSize = this.rowCnt

            // 페이징 조회
            basAdmInfsSubUploadApi
                .getSubUploadList(this.searchParam)
                .then((result) => {
                    this.gridObj.dataProvider.setRows(result.gridList)
                    // 페이징 관련
                    // 순번(역순)이 필요한경우 계산하는 함수
                    this.gridObj.setGridIndicator(result.pagingDto)
                    // 초기화
                    this.gridData = this.gridSetData()
                    // 총페이지수
                    this.gridData.totalPage = result.pagingDto.totalPageCnt
                    // Grid Row 가져올때 페이지정보 Setting
                    this.gridHeaderObj.setPageCount(result.pagingDto)
                })
        },
    },
}
</script>
