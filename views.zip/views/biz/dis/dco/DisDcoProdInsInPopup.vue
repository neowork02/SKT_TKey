<!-----------------------------------------------
 * 업무그룹명: 상품입력(입고)
 * 서브업무명: 입고상세(등록)[DISDCO00100]
 * 설명: 입고 상품을 입력한다
 * 작성자: P179229
 * 작성일: 2022.04.26
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">상품입력(입고)</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <ul class="btn_area top pop">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="addBarCodePop"
                                >2차원바코드입력</TCComButton
                            >
                        </li>
                    </ul>
                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="popupGridHeader"
                            ref="popupGridHeader"
                            gridTitle="상품내역"
                            :gridObj="gridObj"
                            :isAddRow="true"
                            :isDelRow="true"
                            @addRowBtn="gridAddRowBtn"
                            @chkDelRowBtn="gridchkDelRowBtn"
                        />
                        <div class="gridWrap">
                            <TCRealGrid
                                id="popupGrid"
                                ref="popupGrid"
                                :fields="view.fields"
                                :columns="view.columns"
                                :editable="true"
                            />
                        </div>
                    </div>
                    <!-- //gridWrap -->
                    <!-- btn -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="addBtn"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="closeBtn"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--// btn -->
                </div>
                <!-- //Popup_Cont -->
                <!-- popup -->
                <DisDcoProdSrchPopup
                    v-if="showProdSrchPop === true"
                    ref="popup"
                    :dialogShow.sync="showProdSrchPop"
                    :parentParam="srchProdPopParam"
                    @confirm="modelPopReturnData"
                />
                <DisDcoProdColorSrchPopup
                    v-if="showProdColorSrchPop === true"
                    ref="popup"
                    :dialogShow.sync="showProdColorSrchPop"
                    :parentParam="srchProdColorParam"
                    @confirm="colorPopReturnData"
                />
                <DisDcoProdInsBarCdPopup
                    v-if="showProdInsBarCdPop === true"
                    ref="popup"
                    :dialogShow.sync="showProdInsBarCdPop"
                    :parentParam="srchBarCodePopParam"
                    @confirm="barCodePopReturnData"
                />
                <!-- // popup -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { DisDcoProdInsInGRID_HEADER } from '@/const/grid/dis/dco/disDcoProdInsInPopupHeader'
import disDcoProdInsInApi from '@/api/biz/dis/dco/disDcoProdInsIn'
import DisDcoProdSrchPopup from './DisDcoProdSrchPopup'
import DisDcoProdColorSrchPopup from './DisDcoProdColorSrchPopup'
import DisDcoProdInsBarCdPopup from './DisDcoProdInsBarCdPopup'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'DisDcoProdInsInPopup',
    mixins: [CommonMixin],
    components: {
        DisDcoProdSrchPopup,
        DisDcoProdInsBarCdPopup,
        DisDcoProdColorSrchPopup,
    },
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        parentParam: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            //Paging Class init
            gridData: this.gridSetData(),
            objAuth: {},
            view: DisDcoProdInsInGRID_HEADER,
            gridObj: {},
            gridHeaderObj: {},
            showProdSrchPop: false,
            srchProdPopParam: {},
            showProdColorSrchPop: false,
            srchProdColorParam: {},
            srchSerNumParam: {},
            srchBarCodePopParam: {},
            showProdInsBarCdPop: false,
            srchProdIndex: '',
            dtlClList: [
                '206',
                '201',
                '205',
                '213',
                '505',
                '511',
                '512',
                '513',
                '514',
            ],
            barCdTypCd: [],
            barCdRtn: false,
        }
    },
    created() {},
    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.popupGridHeader
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.dataProvider.onRowInserted = this.onRowInserted
        this.gridObj.gridView.onCellButtonClicked = this.onCellButtonClicked
        this.gridObj.gridView.onCellEdited = this.onCellEdited
        this.gridObj.gridView.columnByName('prodNm').buttonVisibleCallback =
            this.buttonVisibleCallback
        this.gridObj.gridView.columnByName('colorNm').buttonVisibleCallback =
            this.buttonVisibleCallback
        //바코드타입 조회
        this.getDisDcoBarCdTypCd()
    },
    watch: {},
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        //GridSetData
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(-1, 10, '', '')
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        // Add Row Event
        gridAddRowBtn: function () {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            var chk = true
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    if (!this.isValidChk(i)) {
                        chk = false
                        return false
                    }
                }
            }

            if (chk) {
                this.gridData.gridRows = this.gridHeaderObj.addRow(
                    this.gridData.gridRows
                )
                if (this.gridObj.dataProvider.getRowCount() > 1) {
                    this.editSerNum()
                }
                this.gridObj.gridView.commit()
            }
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            this.gridObj.gridView.commit()
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
            this.deleleGridData = this.gridData.delRows
        },
        //상품검색팝업
        addProdModelPop(itemIndex, prodNm) {
            this.gridObj.gridView.commit()
            this.srchProdIndex = itemIndex
            this.srchProdPopParam.prodNm = prodNm
            this.srchProdPopParam.applyDt = this.parentParam.inSchdDt
            this.showProdSrchPop = true
        },
        // 모델 팝업 리턴 이벤트 처리
        modelPopReturnData(returnData) {
            // 상품, 색상조회 callback
            this.gridObj.dataProvider.updateRow(this.srchProdIndex, returnData)
            this.gridObj.gridView.setValue(this.srchProdIndex, 'colorCd', '')
            this.gridObj.gridView.setValue(this.srchProdIndex, 'colorNm', '')
        },
        //색상검색팝업
        addProdColorPop(itemIndex, prodCd) {
            this.gridObj.gridView.commit()
            this.srchProdIndex = itemIndex
            this.srchProdColorParam.prodCd = prodCd
            this.showProdColorSrchPop = true
        },
        // 색상 팝업 리턴 이벤트 처리
        colorPopReturnData(returnData) {
            // 상품, 색상조회 callback
            this.gridObj.dataProvider.updateRow(this.srchProdIndex, returnData)
            this.editSerNum(this.srchProdIndex)
        },
        //2차원바코드입력팝업
        addBarCodePop() {
            this.gridObj.gridView.commit()
            this.srchBarCodePopParam.aplyDt = this.parentParam.inSchdDt
            this.srchBarCodePopParam.inOutClCd = this.parentParam.inClCd
            this.srchBarCodePopParam.prchTyp = this.parentParam.prchTypCd
            this.showProdInsBarCdPop = true
            this.barCdRtn = true
        },
        //2차원바코드입력팝업 리턴 이벤트 처리
        barCodePopReturnData(returnData) {
            // 2차원바코드입력 callback
            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            rowData.forEach((data, i) => {
                if (_.isEmpty(data.serNum)) {
                    this.gridObj.dataProvider.removeRow(i)
                }
            })
            let chk = false
            if (returnData.length > 0) {
                returnData.forEach((barCodeData) => {
                    if (
                        this.checkSerNum(
                            _.get(barCodeData, 'serNum'),
                            _.get(barCodeData, 'prodCd')
                        )
                    ) {
                        // 상품정보 append
                        this.gridObj.dataProvider.insertRow(
                            this.gridObj.gridView.getItemCount(),
                            barCodeData
                        )
                    } else {
                        chk = true
                    }
                })
            }
            if (chk) {
                this.showTcComAlert(
                    '중복된 일련번호를 제외하고 추가하였습니다.'
                )
            }
            this.barCdRtn = false
        },
        //확인
        addBtn() {
            this.gridObj.gridView.commit()
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            const chkProdList = []
            var chk = true
            for (var i = 0; i < index.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(i)
                if (
                    !_.isEmpty(_.get(row, 'serNum')) &&
                    !_.isEmpty(_.get(row, 'badYnNm'))
                ) {
                    chkProdList.push(row)
                }
            }
            if (chk) {
                this.$emit('addProdList', chkProdList)
                this.activeOpen = false
            }
        },
        //기본 값 유효성 체크
        isValidChk(itemIndex) {
            var row = this.gridObj.dataProvider.getJsonRow(itemIndex)

            if (_.isEmpty(_.get(row, 'prodCd'))) {
                this.showTcComAlert('상품을 선택하세요')
                return false
            }
            if (_.isEmpty(_.get(row, 'serNum'))) {
                this.showTcComAlert('일련번호를 입력하세요')
                return false
            }
            if (
                (this.parentParam.inClCd === '101' ||
                    this.parentParam.inClCd === '102') &&
                _.isEmpty(_.get(row, 'colorCd')) &&
                _.get(row, 'prodClCd') !== '2'
            ) {
                this.showTcComAlert('색상을 선택하세요')
                return false
            }
            return true
        },
        //일련번호 중복체크
        checkSerNum(serNum, prodCd, itemIndex) {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.gridObj.dataProvider.getJsonRow(i)
                    if (
                        itemIndex !== i &&
                        serNum + prodCd ===
                            _.get(row, 'serNum') + _.get(row, 'prodCd')
                    ) {
                        return false
                    }
                }
            }
            return true
        },
        //일련번호 유효성 체크
        isSerNumValidChk(serNumData, itemIndex) {
            var lastInoutDtlClCd = _.get(serNumData, 'lastInoutDtlClCd')
            if (this.srchSerNumParam.chkType === 'prod') {
                if (_.isEmpty(serNumData)) {
                    this.showTcComAlert('등록되지 않은 상품입니다.')
                    return false
                } else {
                    if (!_.isEmpty(lastInoutDtlClCd)) {
                        if (this.dtlClList.indexOf(lastInoutDtlClCd) < 0) {
                            this.showTcComAlert('등록된 일련번호입니다.')
                            return false
                        }
                    }
                }
                this.gridObj.gridView.setValue(itemIndex, 'badYnNm', '정상')
                this.gridObj.gridView.setValue(itemIndex, 'disStNm', '가용')
                this.gridObj.gridView.setValue(itemIndex, 'badYn', '01')
                this.gridObj.gridView.setValue(itemIndex, 'disStCd', '01')
            } else {
                if (_.isEmpty(serNumData)) {
                    this.showTcComAlert('해당하는 상품이 존재 하지 않습니다.')
                    return false
                } else {
                    if (_.isEmpty(_.get(serNumData, 'serNum'))) {
                        this.showTcComAlert(
                            '바코드 정보에 일련번호가 존재하지 않습니다. 직접 KEY IN 바랍니다.'
                        )
                        return false
                    }
                    if (_.isEmpty(_.get(serNumData, 'rawColorCd'))) {
                        this.showTcComAlert(
                            '바코드 정보에 색상이 존재하지 않습니다. 직접 KEY IN 바랍니다.'
                        )
                        return false
                    }
                    if (_.isEmpty(_.get(serNumData, 'colorCd'))) {
                        this.showTcComAlert(
                            '상품에 등록되지 않은 색상코드[' +
                                _.get(serNumData, 'rawColorCd') +
                                ']입니다.'
                        )
                        return false
                    }
                    // as 입고, 교품 반환입고
                    if (
                        this.parentParam.inClCd === '103' ||
                        this.parentParam.inClCd === '109'
                    ) {
                        if (_.get(serNumData, 'badYn') !== '02') {
                            this.showTcComAlert(
                                '상품의 불량구분이 불량이어야 합니다.'
                            )
                            return false
                        }
                        if (_.get(serNumData, 'disStCd') !== '02') {
                            this.showTcComAlert(
                                '상품의 재고상태가 비가용이어야 합니다.'
                            )
                            return false
                        }
                        if (_.get(serNumData, 'lastInoutClCd') !== '200') {
                            this.showTcComAlert(
                                '상품의 입출고구분이 출고이어야 합니다.'
                            )
                            return false
                        }
                        if (
                            this.parentParam.inClCd === '103' &&
                            lastInoutDtlClCd !== '203'
                        ) {
                            this.showTcComAlert(
                                '상품의 입출고상세구분이 AS출고이어야 합니다.'
                            )
                            return false
                        }
                        if (
                            this.parentParam.inClCd === '109' &&
                            lastInoutDtlClCd !== '202'
                        ) {
                            this.showTcComAlert(
                                '상품의 입출고상세구분이 교품출고이어야 합니다.'
                            )
                            return false
                        }
                        this.gridObj.gridView.setValue(
                            itemIndex,
                            'badYnNm',
                            _.get(serNumData, 'badYnNm')
                        )
                        this.gridObj.gridView.setValue(
                            itemIndex,
                            'disStNm',
                            _.get(serNumData, 'disStNm')
                        )
                        this.gridObj.gridView.setValue(
                            itemIndex,
                            'badYn',
                            _.get(serNumData, 'badYn')
                        )
                        this.gridObj.gridView.setValue(
                            itemIndex,
                            'disStCd',
                            _.get(serNumData, 'disStCd')
                        )
                    } else {
                        if (
                            this.parentParam.inClCd === '101' ||
                            this.parentParam.inClCd === '102'
                        ) {
                            if (!_.isEmpty(lastInoutDtlClCd)) {
                                if (
                                    this.dtlClList.indexOf(lastInoutDtlClCd) < 0
                                ) {
                                    this.showTcComAlert(
                                        '등록된 일련번호입니다.'
                                    )
                                    return false
                                }
                            }
                            this.gridObj.gridView.setValue(
                                itemIndex,
                                'badYnNm',
                                '정상'
                            )
                            this.gridObj.gridView.setValue(
                                itemIndex,
                                'disStNm',
                                '가용'
                            )
                            this.gridObj.gridView.setValue(
                                itemIndex,
                                'badYn',
                                '01'
                            )
                            this.gridObj.gridView.setValue(
                                itemIndex,
                                'disStCd',
                                '01'
                            )
                        } else {
                            if (_.isEmpty(_.get(serNumData, 'lastInoutClCd'))) {
                                this.showTcComAlert('등록된 일련번호입니다.')
                                return false
                            }
                        }
                    }
                    if (_.get(serNumData, 'prodClCd') !== '02') {
                        this.gridObj.gridView.setValue(
                            itemIndex,
                            'colorCd',
                            _.get(serNumData, 'colorCd')
                        )
                    }
                }
            }
            return true
        },
        //행추가시 일련번호 제외한 마지막 row 1건 추가
        onRowInserted(provider, row) {
            if (!this.barCdRtn && row > 0) {
                var lastRow = this.gridObj.dataProvider.getJsonRow(row - 1)
                delete lastRow.serNum
                delete lastRow.badYnNm
                delete lastRow.disStNm
                this.gridObj.dataProvider.updateRow(row, lastRow)
            }
        },
        //모델, 색상 조회
        onCellButtonClicked(grid, itemIndex, column) {
            this.gridObj.gridView.commit()
            if (column.fieldName === 'prodNm') {
                this.addProdModelPop(
                    itemIndex.itemIndex,
                    grid.getValue(itemIndex.itemIndex, 'prodNm')
                )
            } else if (column.fieldName === 'colorNm') {
                var prodCd = grid.getValue(itemIndex.itemIndex, 'prodCd')
                if (_.isEmpty(prodCd)) {
                    this.showTcComAlert('선택된 상품이 없습니다.')
                } else {
                    this.addProdColorPop(
                        itemIndex.itemIndex,
                        grid.getValue(itemIndex.itemIndex, 'prodCd')
                    )
                }
            }
        },
        //일련번호체크
        onCellEdited(grid, itemIndex, dataRow, field) {
            //일련번호 수정
            this.gridObj.gridView.commit()
            if (field === 5) {
                var row = this.gridObj.dataProvider.getJsonRow(itemIndex)
                var prodClCd = _.get(row, 'prodClCd')
                var prodCd = _.get(row, 'prodCd')

                // var sSerNum = _.get(row, 'serNum').replace('%', ' ')
                // _.set(row, 'serNum', sSerNum)

                var serNum = grid.getValue(itemIndex, field).replace('%', '')

                if (!this.isValidChk(itemIndex)) {
                    this.editSerNum(itemIndex)
                    return
                }
                //일련번호 중복체크
                if (!this.checkSerNum(serNum, prodCd, itemIndex)) {
                    this.showTcComAlert('중복된 일련번호가 있습니다.')
                    this.editSerNum(itemIndex)
                    return
                }
                if (
                    serNum.length < 12 ||
                    (serNum.length === 12 &&
                        this.barCdTypCd.indexOf(_.get(row, 'barCdType')) > -1)
                ) {
                    //단말기 일련번호 체크
                    if (prodClCd === '1' && serNum.length !== 7) {
                        if (serNum.length !== 10) {
                            if (serNum.length !== 11) {
                                if (serNum.length !== 12) {
                                    this.showTcComAlert(
                                        '일련번호가 바르게 입력되지 않았습니다. [단말기:7자리,10자리,11자리,12자리]'
                                    )
                                    this.editSerNum(itemIndex)
                                    return
                                }
                            }
                        }
                    }
                    //USIM 일련번호 체크
                    if (prodClCd === '2' && serNum.length !== 8) {
                        this.showTcComAlert(
                            '일련번호가 바르게 입력되지 않았습니다. [USIM:8자리]'
                        )
                        this.editSerNum(itemIndex)
                        return
                    }
                    if (
                        this.parentParam.inClCd === '101' ||
                        this.parentParam.inClCd === '102'
                    ) {
                        //구매입고, 교품입고
                        this.srchSerNumParam.chkType = 'prod'
                    } else {
                        //AS입고
                        this.srchSerNumParam.chkType = 'serNum'
                    }
                } else {
                    //바코드
                    this.srchSerNumParam.chkType = 'barCode'
                }
                this.srchSerNumParam.prodCd = prodCd
                this.srchSerNumParam.serNum = serNum
                this.srchSerNumParam.prchType = this.parentParam.prchTypCd
                //등록된 일련번호 체크
                disDcoProdInsInApi
                    .getDisDcoSerNum(this.srchSerNumParam)
                    .then((res) => {
                        var returnData = {}
                        res.disDcoSerNumVo.forEach((data) => {
                            returnData = data
                            return false
                        })
                        if (!this.isSerNumValidChk(returnData, itemIndex)) {
                            this.editSerNum(itemIndex)
                        } else {
                            if (this.srchSerNumParam.chkType === 'barCode') {
                                //일련번호 중복체크
                                if (
                                    !this.checkSerNum(
                                        _.get(returnData, 'serNum'),
                                        prodCd,
                                        itemIndex
                                    )
                                ) {
                                    this.showTcComAlert(
                                        '중복된 일련번호가 있습니다.'
                                    )
                                    this.editSerNum(itemIndex)
                                    return
                                }
                                grid.setValue(
                                    itemIndex,
                                    'serNum',
                                    _.get(returnData, 'serNum')
                                )
                                grid.setValue(
                                    itemIndex,
                                    'colorCd',
                                    _.get(returnData, 'colorCd')
                                )
                                grid.setValue(
                                    itemIndex,
                                    'colorNm',
                                    _.get(returnData, 'colorNm')
                                )
                            }
                            //행추가
                            this.gridAddRowBtn()
                        }
                    })
            }
        },
        //버튼제어
        buttonVisibleCallback(grid, index) {
            if (!_.isEmpty(grid.getValue(index.itemIndex, 'serNum'))) {
                return false
            } else {
                return true
            }
        },
        //바코드타입조회
        getDisDcoBarCdTypCd: function () {
            disDcoProdInsInApi.getDisDcoBarCdTypCd().then((res) => {
                res.disDcoBarCdTypeCdVo.forEach((data) => {
                    this.barCdTypCd.push(_.get(data, 'barCdType'))
                })
                //행추가
                this.gridAddRowBtn()
            })
        },
        //일련번호 KeyIN
        editSerNum(index) {
            this.gridObj.gridView.setValue(index, 'serNum', '')
            this.gridObj.gridView.setCurrent({
                itemIndex: this.gridObj.dataProvider.getRowCount(),
                fieldName: 'serNum',
            })
            //focus간 셀 편집
            setTimeout(() => {
                this.gridObj.gridView.showEditor()
            }, 100)
        },
    },
}
</script>
