<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">게시판 수정</p>
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3_3">
                                <div class="arrayType">
                                    <div class="formitem div2">
                                        <TCComInput
                                            v-model="regPopUp.bbsTypeNm"
                                            labelName="게시판구분"
                                            :objAuth="objAuth"
                                            :disabled="true"
                                        ></TCComInput>
                                    </div>
                                    <div class="col0">
                                        <TCComCheckBox
                                            :objAuth="objAuth"
                                            v-model="formParam.noticeYn"
                                            :itemList="[
                                                {
                                                    commCdVal: 'Y',
                                                    commCdValNm: '',
                                                },
                                            ]"
                                        />
                                    </div>
                                    <div class="col0">
                                        <span class="basicTxt mgl-5">
                                            <span class="color-red"
                                                >공지글</span
                                            >
                                            (체크하면 리스트 최상단에 나오게
                                            됩니다.)</span
                                        >
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="regPopUp.textTitle"
                                    labelName="제목"
                                    :disabled="disableEl"
                                />
                                <!-- <div class="arrayType">
                                    <div class="col75"></div>
                                </div> -->
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="regPopUp.bbsDtl"
                                    labelName="내용"
                                    class="boxtype"
                                    :rows="18"
                                    :disabled="disableEl"
                                />
                            </div>
                        </div>
                    </div>
                    <!-- 파일첨부 그리드 -->
                    <AttachedBoardFileAdd
                        gridId="modifyFileGrid"
                        ref="attachedFile"
                        :fileList="fileSearchList1"
                        @file-change="onFileAddChange1"
                        gridHeight="50px"
                    ></AttachedBoardFileAdd>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <div class="right">
                            <TCComButton
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onClick"
                                v-show="showUpdateBtn"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="dtlClick"
                                v-show="showDeleteBtn"
                                >삭제</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onClose"
                                >닫기</TCComButton
                            >
                        </div>
                    </div>

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

// 화면 하단 버튼 정렬
<style lang="scss" scoped>
// .btn_area_bottom::v-deep {
//     display: block;
//     float: none;
//     overflow: hidden;

//     .left {
//         float: left;
//     }

//     .right {
//         float: right;
//     }
// }
</style>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import _ from 'lodash'
import AttachedBoardFileAdd from '@/components/common/AttachedBoardFileAdd'
import BasBbsModifyApi from '@/api/biz/bas/bbs/basBbsMgmt'
//import StorePopup from '@/views/biz/bas/bbs/BasBbsStorePopMgmt'

//import _ from 'lodash'

export default {
    name: 'BasBbsModify',
    mixins: [CommonMixin],
    components: { AttachedBoardFileAdd },
    props: {
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            checkbox: true,
            objAuth: {},
            showUpdateBtn: true,
            showDeleteBtn: true,
            disableEl: false,
            admAppendFileList: [],
            formData1: new FormData(),
            fileSearchList1: [],
            inputValue2: '20',
            regPopUp: {
                noticeYn: 'N',
                bbsTypeCd: '',
                bbsTypeNm: '',
                textTitle: '',
                bbsDtl: '',
                insUserId: '',
                dealcoNm: '', // 매장명
                dealcoCd: '', // 매장코드
                userNm: '', // 사용자명
                userId: '', // 사용자아이디
                screenId: 'BASBBS00001',
                docId: '',
                bbsNo: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                delYn: '',
            },
            formParam: {
                noticeYn: [],
                dealcoCd: [],
                dealcoNm: [],
                userId: [],
                userNm: [],
            },
        }
    },
    mounted() {
        if (this.$parent.guideTab == 0) {
            this.regPopUp.bbsTypeNm = '대리점공지사항'
            this.regPopUp.bbsTypeCd = 'N'
        }
        if (this.$parent.guideTab == 1) {
            this.regPopUp.bbsTypeNm = '정책게시판'
        }
        if (this.$parent.guideTab == 2) {
            this.regPopUp.bbsTypeNm = '시스템공지사항'
            this.regPopUp.bbsTypeCd = 'A'
        }
        if (this.$parent.guideTab == 3) {
            this.regPopUp.bbsTypeNm = '기능개선요청게시판'
            this.regPopUp.bbsTypeCd = 'I'
        }
        this.searchBoard()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        popupParams: {
            handler: function (value) {
                this.popupParams = value
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        onClose: function () {
            this.activeOpen = false
        },
        async onClick() {
            this.regPopUp.noticeYn =
                String(this.formParam.noticeYn) == undefined
                    ? ''
                    : String(this.formParam.noticeYn)
            this.regPopUp.noticeYn =
                this.regPopUp.noticeYn == 'undefined'
                    ? ''
                    : this.regPopUp.noticeYn
            this.regPopUp.dealcoNm =
                String(this.formParam.dealcoNm) == undefined
                    ? ''
                    : String(this.formParam.dealcoNm)
            this.regPopUp.dealcoCd =
                String(this.formParam.dealcoCd) == undefined
                    ? ''
                    : String(this.formParam.dealcoCd)
            this.regPopUp.userId =
                String(this.formParam.userId) == undefined
                    ? ''
                    : String(this.formParam.userId)
            this.regPopUp.userNm =
                String(this.formParam.userNm) == undefined
                    ? ''
                    : String(this.formParam.userNm)
            /*
            if (this.regPopUp.bbsTypeCd == '시스템공지사항') {
                this.regPopUp.bbsTypeCd = 'A'
            } else if (this.regPopUp.bbsTypeCd == '기능개선요청게시판') {
                this.regPopUp.bbsTypeCd = 'I'
            } else if (this.regPopUp.bbsTypeCd == '대리점공지사항') {
                this.regPopUp.bbsTypeCd = 'N'
            }
            */
            this.formParam = this.regPopUp
            this.formParam = this.formParam.__rowState = 'updated'
            this.regPopUp.bbsNo = this.popupParams.bbsNo
            await this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    //  첨부파일 저장
                    BasBbsModifyApi.saveAttachFile(this.formData1).then(
                        (resultData) => {
                            console.log(resultData)

                            if (resultData != null) {
                                this.regPopUp.docId = resultData[0].docId
                            }
                            /*
                            if (this.regPopUp.bbsTypeCd == '대리점공지사항') {
                                // this.$parent.$parent.getBasBbsMgmtList()
                            }
                            if (this.regPopUp.bbsTypeCd == '시스템공지사항') {
                                // this.$parent.$parent.getBasBbsMgmtList()
                            }
                            if (
                                this.regPopUp.bbsTypeCd == '기능개선요청게시판'
                            ) {
                                // this.$parent.$parent.getBasBbsMgmtList2()
                            }
                            */

                            //  문의상세내용 저장
                            BasBbsModifyApi.getBasBbsUpdateMgmt(
                                this.regPopUp
                            ).then((resultData) => {
                                console.log(resultData)
                                this.showTcComAlert('수정되었습니다.')
                                this.$emit('confirm', true)
                                this.onClose()
                            })
                        }
                    )
                }
            })
        },
        async dtlClick() {
            this.regPopUp.noticeYn = String(this.formParam.noticeYn)
            this.regPopUp.dealcoNm = String(this.formParam.dealcoNm)
            this.regPopUp.dealcoCd = String(this.formParam.dealcoCd)
            this.regPopUp.userId = String(this.formParam.userId)
            this.regPopUp.userNm = String(this.formParam.userNm)
            this.formParam = this.regPopUp
            this.formParam.__rowState = 'deleted'
            this.formParam.delYn = 'Y'
            this.formParam.bbsNo = this.popupParams.bbsNo
            await this.showTcComConfirm('삭제하시겠습니까?').then((confirm) => {
                if (confirm) {
                    BasBbsModifyApi.getBasBbsDeleteMgmt(this.formParam).then(
                        (resultData) => {
                            if (resultData != null) {
                                console.log('this', this)
                            }
                            this.showTcComAlert('삭제되었습니다.')
                            this.$emit('confirm', true)
                            this.onClose()
                        }
                    )
                }
            })
        },
        async searchBoard() {
            await BasBbsModifyApi.getBasBbsDetailMgmt(this.popupParams).then(
                (resultData) => {
                    this.regPopUp.bbsTypeCd = resultData[0].bbsTypeCd
                    this.regPopUp.textTitle = resultData[0].textTitle
                    this.regPopUp.bbsDtl = resultData[0].bbsDtl
                    this.regPopUp.insUserId = resultData[0].insUserId
                    this.formParam.dealcoNm = resultData[0].dealcoNm
                    this.formParam.dealcoCd = resultData[0].dealcoCd
                    this.formParam.userNm = resultData[0].userNm
                    this.formParam.userId = resultData[0].userId
                    this.regPopUp.docId = resultData[0].docId
                    if (resultData[0].noticeYn === 'Y') {
                        this.formParam.noticeYn = [resultData[0].noticeYn]
                    }
                    if (this.regPopUp.bbsTypeCd == 'N') {
                        this.showUserbtn = false
                        this.showUser = false
                        this.showAllUserbtn = false
                    }
                    if (this.userInfo.userId != this.regPopUp.insUserId) {
                        this.showUpdateBtn = false
                        this.showDeleteBtn = false
                        this.disableEl = true
                        this.showStorebtn = false
                        this.showUserbtn = false
                        this.showAllUserbtn = false
                    }
                    /*
                    if (this.regPopUp.bbsTypeCd == 'A') {
                        this.regPopUp.bbsTypeCd = '시스템공지사항'
                    } else if (this.regPopUp.bbsTypeCd == 'I') {
                        this.regPopUp.bbsTypeCd = '기능개선요청게시판'
                    } else if (this.regPopUp.bbsTypeCd == 'N') {
                        this.regPopUp.bbsTypeCd = '대리점공지사항'
                    }
                    */

                    this.$parent.onClose

                    BasBbsModifyApi.getAttachFile(this.regPopUp).then((res) => {
                        this.fileSearchList1 = []
                        res.forEach((item) => {
                            this.fileSearchList1.push({
                                screenId: item.screenId,
                                docId: item.docId,
                                name: item.fileNm,
                                size: item.fileSize,
                                filePathNm: item.filePathNm,
                                fileType: item.fileType,
                            })
                        })
                        this.$refs.attachedFile.init()
                    })
                }
            )
        },
        onFileAddChange1(files) {
            this.formData1 = new FormData()
            const addFileLength = files.addFile.length

            _.forEach(files.addFile, (item, index) => {
                this.formData1.append('files', item.file)
                this.formData1.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                this.formData1.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                this.formData1.append(
                    `admAppendFileList[${index}].screenId`,
                    'BASBBS00001'
                )
                this.formData1.append(
                    `admAppendFileList[${index}].docId`,
                    this.regPopUp.docId === undefined ? '' : this.regPopUp.docId
                )
                this.formData1.append(
                    `admAppendFileList[${index}].__rowState`,
                    'created'
                )
            })
            _.forEach(files.delFile, (item, index) => {
                this.formData1.append(
                    `admAppendFileList[${index + addFileLength}].filePathNm`,
                    item.filePathNm
                )
                this.formData1.append(
                    `admAppendFileList[${index + addFileLength}].fileType`,
                    item.fileType
                )
                this.formData1.append(
                    `admAppendFileList[${index + addFileLength}].screenId`,
                    item.screenId
                )
                this.formData1.append(
                    `admAppendFileList[${index + addFileLength}].docId`,
                    item.docId
                )
                this.formData1.append(
                    `admAppendFileList[${index + addFileLength}].__rowState`,
                    'deleted'
                )
            })
        },
        chkData() {
            this.regPopUp = this.list
        },
    },
}
</script>
