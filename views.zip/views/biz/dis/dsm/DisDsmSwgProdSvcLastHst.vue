<!-----------------------------------------------
 * 업무그룹명: Swing상품개통최종이력
 * 서브업무명: Swing상품개통최종이력
 * 설명: Swing상품개통최종이력 관리한다.
 * 작성자: P179234
 * 작성일: 2022.04.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- <h1>Swing상품개통최종이력</h1> -->
        <h1>개통이력조회</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    @click="init()"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="개통일자"
                        calType="DP"
                        v-model="setDate"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.orgNm"
                        :codeVal.sync="reqParam.orgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :eRequired="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchOrgForm"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.hldDealcoNm"
                        :codeVal.sync="reqParam.hldDealcoCd"
                        labelName="보유처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :eRequired="false"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchDealcosForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="개통여부"
                        codeId="ZDIS_C_00040"
                        :objAuth="this.objAuth"
                        v-model="reqParam.svcHstYn"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="상품구분"
                        codeId="ZBAS_C_00010"
                        :objAuth="this.objAuth"
                        v-model="reqParam.prodClCd"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="모델"
                        @enterKey="onProdsEnterKey"
                        @appendIconClick="onProdsIconClick"
                        @input="reqParam.prodCd = ''"
                        :objAuth="this.objAuth"
                        v-model="reqParam.prodNm"
                        :codeVal="reqParam.prodCd"
                        :disabledAfter="true"
                    >
                    </TCComInputSearchText>
                    <BasBcoProdsPopup
                        v-if="basBcoProdsShow === true"
                        :dialogShow.sync="basBcoProdsShow"
                        :parentParam="reqParam"
                        :rows="resultProdsRows"
                        @confirm="onProdsReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="모델명"
                        :appendIconShow="false"
                        :appendIconClass="''"
                        :objAuth="this.objAuth"
                        v-model="reqParam.prodNm"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="일련번호"
                        :appendIconShow="false"
                        :appendIconClass="''"
                        :objAuth="this.objAuth"
                        v-model="reqParam.serNum"
                    />
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeaderSPLHst"
                ref="gridHeaderSPLHst"
                gridTitle="Swing상품개통최종이력"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="gridSPLHst"
                ref="gridSPLHst"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisDsmSwgProdSvcLastHsts"
                :gridObj="gridObj"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 콜백 서비스 아이디
 * 4 대리점명 버튼 클릭, 키다운 이벤트
 * 5 엑셀다운
------------------------------------------------>
<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { GRID_HEADER } from '@/const/grid/dis/dsm/disDsmSwgProdSvcLastHstHeader.js'
import SwgProdSvcLastHstApi from '@/api/biz/dis/dsm/disDsmSwgProdSvcLastHst.js'
import attachedFileApi from '@/api/common/attachedFile'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-전체조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-전체조직==================
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================

import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'disDsmSwgProdSvcLastHstMgmt',
    mixins: [CommonMixin],
    components: { BasBcoAuthOrgTreesPopup, BasBcoDealcosPop, BasBcoProdsPopup },
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            codeIDView: true,
            codeIDViewVal: '',
            objAuth: {},
            active: false,
            view: GRID_HEADER,
            //====================내부조직팝업(권한)팝업관련====================
            orgDisabled: false,
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchOrgForm: {
                orgCd: '', // 조직id
                orgNm: '', // 조직명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처-전체조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchDealcosForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                basDay: '', // 거래처 팝업 - 기준년월
            },
            resultDealcoRows: [],
            //====================//내부거래처-전체조직==================
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            //====================//상품팝업관련==================
            reqParam: {
                orgCdLvl0: '', // 회사구분
                fromDt: '', // 조회시작일
                toDt: '', // 조회종료일
                orgCd: '', // 조직코드
                orgNm: '', //조직명
                orgLvl: '0', // 조직레벨
                hldDealcoCd: '', //보유처코드
                hldDealcoNm: '', //보유처명
                prodClCd: '', //상품구분
                prodNm: '', // 상품명
                prodCd: '', // 상품코드
                serNum: '', // 일련번호
                svcHstYn: '', // 개통여부
                basMth: '', // 조직 팝업 - 기준년월
            },
            searchForm: {},
            rowCnt: 15,
            indicatorOpt: { sort: 'DESC' }, // Grid정렬순서 기본 desc
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.fromDt, this.reqParam.toDt]
            },
            set(val) {
                this.reqParam.fromDt = val[0]
                this.reqParam.toDt = val[1]
                this.searchDealcosForm.basDay = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMMDD'
                )
                this.searchOrgForm.basMth = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMM'
                )
                return val
            },
        },
    },
    created() {
        this.gridData = this.gridSetData(this.rowCnt)
    },
    mounted() {
        /* 그리드 설정 */
        this.gridObj = this.$refs.gridSPLHst
        this.gridHeaderObj = this.$refs.gridHeaderSPLHst
        this.gridObj.setGridState(true, false, false)
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.init()
    },
    methods: {
        /* 초기화 */
        init() {
            //검색영역
            this.reqParam.fromDt = moment(new Date()).format('YYYY-MM-01') // 입고일 from
            this.reqParam.toDt = moment(new Date()).format('YYYY-MM-DD') // 입고일 to

            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLvl'] = this.orgInfo['orgLvl']
                this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.reqParam['hldDealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['hldDealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam')
            this.init()
        },
        //Grid Init
        gridSetData(rowCnt) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(0, rowCnt, '', '')
        },
        // 페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //리스트 조회
        searchBtn: function () {
            // 유효성체크
            if (!this.isValidChk()) {
                return false
            }
            /* Swing상품개통최종이력 조회 - 최초 */
            this.searchForm = { ...this.reqParam }
            this.searchForm.fromDt = CommonUtil.replaceDash(
                this.searchForm.fromDt
            )
            this.searchForm.toDt = CommonUtil.replaceDash(this.searchForm.toDt)

            //첫 조회시 표시할 행의 갯수
            this.searchForm.pageSize = this.rowCnt
            this.searchForm.pageNum = 1 // 첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getDisDsmSwgProdSvcLastHsts(this.searchForm.pageNum)
        },
        /* Swing상품개통최종이력 조회 - 페이징호출 */
        getDisDsmSwgProdSvcLastHsts(pageNum) {
            this.searchForm.pageNum = pageNum
            SwgProdSvcLastHstApi.getSwgProdSvcLastHst(this.searchForm).then(
                (res) => {
                    console.log(res)
                    if (res) {
                        this.gridObj.setRows(res.gridList)
                        // this.gridObj.setGridIndicator(res.pagingDto) // 순번이 필요한경우 계산하는 함수
                        this.indicatorOpt.sort = 'ASC' // 오름차순 정렬
                        this.gridObj.setGridIndicator(
                            res.pagingDto,
                            this.indicatorOpt
                        ) // Grid정렬순서 설정
                        this.gridData = this.gridSetData(this.rowCnt) // 초기화
                        this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                        this.gridHeaderObj.setPageCount(res.pagingDto) // Grid Row 가져올때 페이지정보 Setting
                    }
                }
            )
        },
        // 유효성체크
        isValidChk() {
            let validFromDt = CommonUtil.replaceDash(this.reqParam.fromDt)
            let validToDt = CommonUtil.replaceDash(this.reqParam.toDt)
            if (_.isEmpty(validFromDt)) {
                this.showTcComAlert('개통일자의 시작일(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(validToDt)) {
                this.showTcComAlert('개통일자의 종료일(을)를 입력해 주십시오.')
                return false
            }
            if (validFromDt.substr(0, 6) !== validToDt.substr(0, 6)) {
                this.showTcComAlert(
                    '시작일자와 종료일자를 동일한 월로 지정하세요.'
                )
                return false
            }
            if (validFromDt > validToDt) {
                this.showTcComAlert('개통일자의 시작일이 종료일보다 큽니다.')
                return false
            }
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 입력해 주십시오.')
                return false
            }
            return true
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-max/resource/dis/dsm/swgProdSvcLastHstExcelList',
                this.searchForm
            )
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchOrgForm.orgCd = this.reqParam.orgCd
            this.searchOrgForm.orgNm = this.reqParam.orgNm
            this.searchOrgForm.orgLvl = this.reqParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchOrgForm)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                        this.reqParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgNm)) {
                this.onAuthOrgTreeIconClick()
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
            this.reqParam.orgCdLvl0 = ''
            this.reqParam.hldDealcoCd = ''
            this.reqParam.hldDealcoNm = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            this.reqParam.orgCd = _.get(retrunData, 'orgCd')
            this.reqParam.orgNm = _.get(retrunData, 'orgNm')
            this.reqParam.orgLvl = _.get(retrunData, 'orgLvl')
            this.reqParam.orgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
            this.reqParam.hldDealcoCd = ''
            this.reqParam.hldDealcoNm = ''
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcosForm)
                .then((res) => {
                    // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.hldDealcoCd = _.get(res[0], 'dealcoCd')
                        this.reqParam.hldDealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultDealcoRows = res
                        this.showBasBcoDealcos = true
                    }
                })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.hldDealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            this.searchDealcosForm.orgCd = this.reqParam.orgCd
            this.searchDealcosForm.orgNm = this.reqParam.orgNm
            this.searchDealcosForm.orgLvl = this.reqParam.orgLvl
            this.searchDealcosForm.dealcoCd = this.reqParam.hldDealcoCd
            this.searchDealcosForm.dealcoNm = this.reqParam.hldDealcoNm
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.reqParam.hldDealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            this.reqParam.hldDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.hldDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-전체조직팝업관련 methods ================================
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.reqParam).then((res) => {
                if (res.length === 1) {
                    this.reqParam.prodCd = _.get(res[0], 'prodCd')
                    this.reqParam.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.reqParam.prodCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.prodCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },

        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            this.reqParam.prodCd = _.get(retrunData, 'prodCd')
            this.reqParam.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
