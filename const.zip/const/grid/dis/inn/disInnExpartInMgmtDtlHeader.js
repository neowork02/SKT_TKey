import { ValueType } from 'realgrid'

export const DisInnExpartInMgmtDtlGRID_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outColorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outSerNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'barCdType',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outColorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outUpdCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outBadYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDisStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disAmt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
            width: '140',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
            width: '180',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고색상',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'outDealcoCd',
            fieldName: 'outDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            visible: false,
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
            width: '130',
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            visible: false,
            header: {
                text: '출고처',
                showTooltip: false,
            },
            width: '130',
        },
        {
            name: 'outColorNm',
            fieldName: 'outColorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            visible: false,
            header: {
                text: '출고색상',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고일련번호',
                showTooltip: false,
            },
            width: '130',
        },
        {
            name: 'outSerNum',
            fieldName: 'outSerNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            visible: false,
            button: 'action',
            buttonVisibility: 'always',
            editable: false,
            header: {
                text: '출고일련번호',
                showTooltip: false,
            },
            width: '130',
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'mfactCd',
            fieldName: 'mfactCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'disStCd',
            fieldName: 'disStCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            visible: false,
            type: 'data',
        },
        {
            name: 'barCdType',
            fieldName: 'barCdType',
            visible: false,
            type: 'data',
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'inSeq',
            fieldName: 'inSeq',
            visible: false,
            type: 'data',
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            visible: false,
            type: 'data',
        },
        {
            name: 'outColorCd',
            fieldName: 'outColorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'outUpdCnt',
            fieldName: 'outUpdCnt',
            visible: false,
            type: 'data',
        },
        {
            name: 'outBadYn',
            fieldName: 'outBadYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'outDisStCd',
            fieldName: 'outDisStCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'disAmt',
            fieldName: 'disAmt',
            visible: false,
            type: 'data',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            visible: false,
            type: 'data',
        },
        {
            name: 'inFixYn',
            fieldName: 'inFixYn',
            visible: false,
            type: 'data',
        },
    ],
}
