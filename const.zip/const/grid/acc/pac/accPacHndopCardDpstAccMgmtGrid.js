import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = {
    columns0: [
        {
            fieldName: 'orgTree',
            header: { text: '조직' },
            width: '300',
        },
        {
            fieldName: 'orgCd',
            header: { text: '조직코드(숨김)' },
            width: '150',
            visible: false,
        },
        {
            fieldName: 'orgLvl',
            header: { text: '조직Level(숨김)' },
            width: '150',
            visible: false,
        },
        {
            fieldName: 'lvOrgCd',
            header: { text: '조직0Level코드(숨김)' },
            width: '150',
            visible: false,
        },
        {
            fieldName: 'accDealcoCd',
            header: { text: '정산처' },
            width: '80',
        },
        {
            fieldName: 'accDealcoNm',
            header: { text: '정산처명' },
            width: '150',
        },
        {
            fieldName: 'dealcoCd',
            header: { text: '수납처' },
            width: '80',
        },
        {
            fieldName: 'dealcoNm',
            header: { text: '수납처명' },
            width: '150',
        },
        {
            fieldName: 'dealcoClNm1',
            header: { text: '거래처구분' },
            width: '150',
        },
        {
            fieldName: 'totPayAmt',
            header: { text: '정산대상금액' },
            width: '120',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'toAccAmt',
            header: { text: '정산금액' },
            width: '120',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'dpstAccAmt',
            header: { text: '입금금액' },
            width: '120',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'dpstAccCmms',
            header: { text: '결제수수료' },
            width: '120',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'notAccAmt',
            header: { text: '미정산금액' },
            width: '120',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
    ],
    columns1: [
        {
            fieldName: 'fixYn',
            header: { text: '확정여부(숨김)' },
            width: '0',
            visible: false,
        },
        {
            fieldName: 'fixNm',
            header: { text: '확정여부' },
            width: '100',
            editable: false,
        },
        {
            fieldName: 'erpFixYn',
            header: { text: 'ERP전송여부(숨김)' },
            width: '0',
            visible: false,
        },
        {
            fieldName: 'erpFixNm',
            header: { text: 'ERP전송여부' },
            width: '100',
            editable: false,
        },
        {
            fieldName: 'fixDt',
            header: { text: '정산일' },
            width: '150',
            dataType: ValueType.DATETIME,
            fieldDatetimeFormat: 'yyyyMMdd',
            columnDatetimeFormat: 'yyyy-MM-dd',
            editable: false,
        },
        {
            fieldName: 'payDtm',
            header: { text: '수납일' },
            width: '150',
            dataType: ValueType.DATETIME,
            fieldDatetimeFormat: 'yyyyMMdd',
            columnDatetimeFormat: 'yyyy-MM-dd',
            editable: false,
        },
        {
            fieldName: 'orgTree',
            header: { text: '조직' },
            width: '300',
            editable: false,
        },
        {
            fieldName: 'dealcoCd',
            header: { text: '수납처' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'dealcoNm',
            header: { text: '수납처명' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'dealcoClNm1',
            header: { text: '거래처구분' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'accDealcoCd',
            header: { text: '정산처' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'accDealcoNm',
            header: { text: '정산처명' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'saleMgmtNo',
            header: { text: '수납관리번호' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'saleMgmtSeq',
            header: { text: '변경순번' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'saleClNm',
            header: { text: '수납구분' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'opStNm',
            header: { text: '수납상태' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'payMgmtNo',
            header: { text: '수납번호' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'cardCoCd',
            header: { text: '카드사코드(숨김)' },
            width: '150',
            visible: false,
        },
        {
            fieldName: 'cardCoNm',
            header: { text: '카드사' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'cardAprvNo',
            header: { text: '승인번호' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'payAmt',
            header: { text: '수납금액' },
            width: '150',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
            editable: false,
        },
        {
            fieldName: 'dpstAccAmt',
            header: { text: '입금금액' },
            width: '150',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
            editable: true,
        },
        {
            fieldName: 'dpstAccCmmsAmt',
            header: { text: '수수료' },
            width: '150',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
            editable: true,
        },
        {
            fieldName: 'svcMgmtNos',
            header: { text: 'T서비스관리번호' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'cntrctMgmtNos',
            header: { text: '계약관리번호' },
            width: '150',
            editable: false,
        },
        {
            fieldName: 'freeProdSaleNos',
            header: { text: '일반상품판매번호' },
            width: '180',
            editable: false,
        },
        {
            fieldName: 'clsDt',
            header: { text: '최종마감일(숨김)' },
            visible: false,
        },
        {
            fieldName: 'cmmsRt',
            header: { text: '수수료율(숨김)' },
            visible: false,
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'calcDpstAccAmt',
            header: { text: '수수료율적용 입금금액(숨김)' },
            visible: false,
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'calcDpstAccCmms',
            header: { text: '수수료율적용 수수료(숨김)' },
            visible: false,
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
    ],
}

const GRID_HEADER = {}

/* [Tab0] 수기카드입금정산관리 세팅 */
GRID_HEADER.columns0 = gridMetaUtil.adjustColumns(GRID_META.columns0)
GRID_HEADER.fields0 = gridMetaUtil.adjustFields(GRID_META.columns0)

/* [Tab1] 수작업카드입금정산 세팅 */
GRID_HEADER.columns1 = gridMetaUtil.adjustColumns(GRID_META.columns1)
GRID_HEADER.fields1 = gridMetaUtil.adjustFields(GRID_META.columns1)

export { GRID_HEADER }
