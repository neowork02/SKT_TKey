/*****************************************
 * 업무 그룹명 : T상품판매
 * 서브업무명: T판매기준정보
 * 설명: T상품판매-T판매기준정보-카드승인요청내역(SALSCO02900)
 * 작성자: P179234
 * 작성일: 2022.08.24
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'editable',
            dataType: ValueType.TEXT, // 수정가능
        },
        {
            fieldName: 'trmsDtm',
            dataType: ValueType.TEXT, //거래일시
        },
        {
            fieldName: 'cardEqpNo',
            dataType: ValueType.TEXT, //CAT ID
        },
        {
            fieldName: 'dealSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvDt',
            dataType: ValueType.TEXT, //승인일자
        },
        {
            fieldName: 'aprvNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'joinbrNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealClCd',
            dataType: ValueType.TEXT, //거래구분
        },
        {
            fieldName: 'dealAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmms',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tax',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'istmtPrd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'isueCoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'isuecoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchCoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchCoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cardRpsCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpsCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpsMsgDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cnclDtm',
            dataType: ValueType.TEXT, //취소일자
        },
        {
            fieldName: 'payOpDt',
            dataType: ValueType.TEXT, //수납일자
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, //변경일시
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //내부거래처[거래처명]
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, //서비스관리번호
        },
        {
            fieldName: 'prodSaleNo',
            dataType: ValueType.TEXT, //판매관리번호
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cntrctMgmtNum',
            dataType: ValueType.TEXT, //계약관리번호
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cardOpStCd',
            dataType: ValueType.TEXT, //처리상태
        },
    ],
    columns: [
        {
            name: 'editable',
            fieldName: 'editable',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수정가능',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
            editable: false,
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',

            styles: {
                textAlignment: 'center',
            },
            header: '매장코드',
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '내부거래처',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'cardEqpNo',
            fieldName: 'cardEqpNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'CAT ID',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'trmsDtm',
            fieldName: 'trmsDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래일시',
                showTooltip: false,
            },
            editable: false,
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'dealClCd',
            fieldName: 'dealClCd',
            type: 'data',
            lookupDisplay: true,
            values: ['', 'CA', 'CC', 'CP', 'CL'],
            labels: ['전체', '승인', '취소', '전화승인', '전화취소'],
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래구분',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'cardOpStCd',
            fieldName: 'cardOpStCd',
            type: 'data',
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리상태',
                showTooltip: false,
            },
            styleCallback: function (grid, dataCell) {
                let editable = grid.getValue(
                    dataCell.index.itemIndex,
                    'editable'
                )
                let ret = {}
                if (editable === '0') {
                    ret = {
                        editable: false,
                    }
                }
                return ret
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '변경일자',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'aprvDt',
            fieldName: 'aprvDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '승인일자',
                showTooltip: false,
            },
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'cnclDtm',
            fieldName: 'cnclDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '취소일자',
                showTooltip: false,
            },
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'payOpDt',
            fieldName: 'payOpDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납일자',
                showTooltip: false,
            },
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'prodSaleNo',
            fieldName: 'prodSaleNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매관리번호',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'cntrctMgmtNum',
            fieldName: 'cntrctMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '계약관리번호',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'isuecoNm',
            fieldName: 'isuecoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '카드사명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'refNo',
            fieldName: 'refNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '레퍼런스번호',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'aprvNo',
            fieldName: 'aprvNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '승인번호',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealAmt',
            fieldName: 'dealAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '승인금액',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'istmtPrd',
            fieldName: 'istmtPrd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '할부개월',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'rpsMsg',
            fieldName: 'rpsMsg',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '응답메세지',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
            editable: false,
        },
    ],
}

export const GRID_COLOR_HEADER = {
    fields: [
        {
            fieldName: 'COLOR_CODE',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'COLOR_NM',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'COLOR_CODE',
            fieldName: 'COLOR_CODE',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'COLOR_NM',
            fieldName: 'COLOR_NM',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
    ],
}
