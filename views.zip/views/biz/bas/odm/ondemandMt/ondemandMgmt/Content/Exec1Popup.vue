<template>
    <TCComDialog :dialogShow.sync="activeOpenExec" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">OnDemand 작업수행</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    v-model="parentParam1.opTypCd"
                                    codeId="ZBAS_ONDMND_OP_TYP_CD"
                                    labelName="업무유형"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :disabled="true"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div4">
                                <TCComDatePicker
                                    v-model="parentParam1.rgstDt"
                                    labelName="등록일자"
                                    :objAuth="objAuth"
                                    :disabled="true"
                                ></TCComDatePicker>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="parentParam1.batId"
                                    labelName="BATCH ID"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="50"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="parentParam1.progId"
                                    labelName="프로그램ID"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="50"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                        </div>
                        <!-- Search_line 2 -->
                        <div v-if="includeOrgCond" class="searchform">
                            <!-- input -->
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    labelName="조직"
                                    :appendIconClass="''"
                                    @appendIconClick="searchCommon('org')"
                                    :objAuth="objAuth"
                                    v-model="formSearchParams.orgNm"
                                    :codeVal.sync="formSearchParams.orgCd"
                                    :disabledAfter="true"
                                    @input="onAuthOrgTreeInput"
                                />
                            </div>
                            <div class="formitem div3"></div>
                            <div class="formitem div3"></div>
                        </div>
                    </div>
                    <div class="contBoth">
                        <table-container />
                    </div>
                    <div id="detail2" class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="execCondDesc"
                                    labelName="조회조건"
                                    class="boxtype"
                                    :rows="3"
                                    :maxlength="1000"
                                    :readonly="true"
                                ></TCComTextArea>
                            </div>
                            <!--
                                    v-model="selectedRow1.execCondDesc"
                                    class="boxtype"
                                            @click="removeChild(item)"

                                    -->
                        </div>
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
                <BasBcoAuthOrgTreesPopup
                    v-if="showBcoAuthOrgTrees"
                    :parentParam="popupParam"
                    :rows="resultAuthOrgTreeRows"
                    :dialogShow.sync="showBcoAuthOrgTrees"
                    @confirm="onAuthOrgTreeReturnData"
                />
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/odm/ondemandMt/ondemandMgmt/helpers'
// eslint-disable-next-line no-unused-vars
import { CommonGrid, CommonUtil } from '@/utils'
//import { SKT_AGENCYS_HEADER } from '@/const/grid/bas/odm/basOdmOndemandMgmtHeader'
//import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
// eslint-disable-next-line no-unused-vars
import commonApi from '@/api/common/commonCode'
import moment from 'moment'
import _ from 'lodash'
import CommonMixin from '@/mixins'
import TableContainer from './Exec1Popup/TableContainer.vue'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
//====================//내부조직팝업(권한)팝업====================

export default {
    mixins: [CommonMixin],
    components: {
        TableContainer,
        BasBcoAuthOrgTreesPopup,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            searchParam: {
                searchDateModel: '', // 조회기준일(v-model)
                searchDate: '', // 조회기준일
            },
            formSearchParams: {
                orgCd: '', // 조직코드
                orgId: '', // 조직코드
                orgLvl: '', // 조직코드
                orgNm: '', // 대리점명
            },
            parentParam1: {},
            condArr: [],
            execCondDesc: '',
            includeOrgCond: false,
            includeOrg: {},
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            popupParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
        }
    },
    computed: {
        ...serviceComputed,
        activeOpenExec: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        resultList1: {
            get() {
                return this.resultExecList
            },
        },
    },
    created() {
        this.init()
    },
    async mounted() {
        let data = await this.basOdmOndemandMgmtConds_({
            param: {},
        })
        let inConds = []
        let inx = 1
        data.forEach((r) => {
            if (this.condArr.indexOf(r.condId) >= 0) {
                if (r.condTypCd == '00') {
                    this.includeOrg = r
                    this.includeOrgCond = true
                } else inConds.push({ ...r, pagingSeq: inx++, condVal: '' })
            }
        })
        await this.defaultAssign_({
            key: 'resultExecList',
            value: inConds,
        })

        this.$nextTick(() => {
            this.execCondDesc = inConds
                .map((r) => {
                    return `${r.condNm}:`
                })
                .join('\n')
            if (this.includeOrgCond)
                this.execCondDesc = `${this.includeOrg.condNm}:\n${this.execCondDesc}`
        })
    },
    methods: {
        ...serviceMethods,
        init() {
            //this.searchParam.searchDateModel = moment().format('YYYY-MM-DD')
        },
        // // 공통코드 API
        // async getCommCodeList(codeId) {
        //     const res = await commonApi.getCommonCodeListById(codeId)
        //     //console.log('getCommCodeList res: ', res)
        //     return res
        // },

        // async getAgencyList() {
        //     this.searchParam.searchDate = CommonUtil.replaceDash(
        //         this.searchParam.searchDateTemp
        //     )
        //     await this.getBasPrmAgencyMgmtAgencys_({
        //         param: this.searchParam,
        //     }).then((res) => {
        //         //console.log('getAgencyList then : ', res)
        //         this.gridObj.setRows(res)
        //     })
        // },
        async onConfirm() {
            // const current = this.gridObj.gridView.getCurrent()
            // if (current.dataRow === -1) {
            //     return
            // }
            // const jsonData = this.gridObj.dataProvider.getJsonRow(
            //     current.dataRow
            // )
            //this.$emit('confirm', jsonData)

            if (this.parentParam1.opTypCd === '') {
                this.showTcComAlert('업무유형을 선택하세요.')
                return
            }
            if (this.parentParam1.batId.trim() === '') {
                this.showTcComAlert('BATCH ID를 입력하세요.')
                return
            }
            if (this.parentParam1.progId.trim() === '') {
                this.showTcComAlert('프로그램ID를 입력하세요.')
                return
            }
            if (this.resultExecList.length == 0) {
                this.showTcComAlert('선택된 조회 조건이 없습니다.')
                return
            }
            if (
                this.includeOrgCond == true &&
                this.formSearchParams.orgCd == ''
            ) {
                this.showTcComAlert('조직을 선택하세요.')
                return
            }

            for (let i = 1; i < 10; i++) {
                this.parentParam1['condId' + i] = null
                this.parentParam1['condVal' + i] = null
            }

            let tmpList = []
            if (this.includeOrgCond) {
                tmpList.push({
                    ...this.includeOrg,
                    condVal: this.formSearchParams.orgCd,
                })
            }
            this.resultExecList.forEach((r) => {
                tmpList.push(r)
            })
            this.checkGrid = true
            tmpList.forEach((r, index) => {
                this.parentParam1['condId' + (index + 1)] = r.condId
                this.parentParam1['condVal' + (index + 1)] = r.condVal
                if (
                    r.condVal.trim().length == 0 ||
                    r.condVal.trim().length > parseInt(r.condLen) //조직길이가 맞지않아 큰건만 체크함.
                ) {
                    this.showTcComAlert(
                        '조회값이 없거나 입력값 길이가 맞지 않습니다.'
                    )
                    this.checkGrid = false
                    return
                }
            })
            if (this.checkGrid == false) {
                return
            }
            this.parentParam1['condCnt'] = tmpList.length

            this.parentParam1['rgstDt'] = this.parentParam1.rgstDt.replace(
                /-/g,
                ''
            )
            this.parentParam1['execCondDesc'] = this.execCondDesc

            console.log(
                'save exec popup param',
                JSON.stringify(this.parentParam1)
            )
            let saveRows = []
            saveRows.push({ ...this.parentParam1, rowState: 'created' })
            let res1 = await this.saveOndemandMgmtHist_({ saveRows })
            if (res1 == 1) {
                this.toasting_({
                    message: '정상처리 되었습니다.',
                })
            }

            this.$emit('confirm', {})
            this.onClose()
        },

        onClose() {
            this.parentParam1 = {}
            this.activeOpenExec = false
        },

        // onSearch() {
        //     this.getAgencyList()
        // },

        onEnterKey() {
            //this.onSearch()
        },
        async setExecCondDesc() {
            await this.defaultAssign_({
                key: 'execListSave',
                value: 'run',
            })

            //let arr1 = this.resultExecList
            console.log('resultExecList')
            this.execCondDesc = this.resultExecList
                .map((r) => {
                    return `${r.condNm}:${r.condVal}`
                })
                .join('\n')
            if (this.includeOrgCond)
                this.execCondDesc = `${this.includeOrg.condNm}:${this.formSearchParams.orgCd}\n${this.execCondDesc}`
        },
        //====================내부조직팝업(권한)팝업관련====================
        searchCommon(flag) {
            // TODO 공통팝업 호출
            if (flag === 'mfact') {
                alert('제조사')
            } else if (flag === 'org') {
                //alert('조직')
                if (this.formSearchParams.orgNm == '') {
                    this.formSearchParams.orgId = ''
                }
                this.resultAuthOrgTreeRows = []
                this.showBcoAuthOrgTrees = true
            } else if (flag === 'prod') {
                alert('모델')
            } else if (flag === 'outPlc') {
                alert('보유처')
            }
        },
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.formSearchParams.orgCd = ''
            this.formSearchParams.orgId = ''
            this.formSearchParams.orgLvl = ''
            this.inputEvent()
        },
        onAuthOrgTreeReturnData(retrunData) {
            console.log('popup retrunData: ', retrunData)
            this.formSearchParams.orgNm = retrunData.orgNm
            this.formSearchParams.orgCd = retrunData.orgCd
            this.formSearchParams.orgId = retrunData.orgCd
            this.formSearchParams.orgLvl = retrunData.orgLvl

            this.setExecCondDesc()
        },
        //====================내부조직팝업(권한)팝업관련====================
    },
    watch: {
        parentParam: {
            handler: function (value) {
                //this.searchParam.orgNm = value['orgNm']
                if (value == null) {
                    console.log('new detail')
                    this.parentParam1['rowState'] = 'created'
                    this.parentParam1['opTypCd'] = ''
                    this.parentParam1['batId'] = ''
                    this.parentParam1['progId'] = ''
                    this.parentParam1['rgstDt'] = moment(new Date()).format(
                        'YYYY-MM-DD'
                    )
                    this.parentParam1['execCondDesc'] = ''
                } else {
                    console.log('exist detail')
                    this.parentParam1 = _.clone(value)
                    this.parentParam1['rowState'] = 'updated'
                    // this.parentParam1.rgstDt = moment(
                    //     value.rgstDt,
                    //     'YYYYMMDDHHmmss'
                    // ).format('YYYY-MM-DD HH:mm:ss')
                    this.parentParam1.rgstDt = moment(
                        value.rgstDt,
                        'YYYYMMDD'
                    ).format('YYYY-MM-DD')

                    for (let i = 1; i < 10; i++) {
                        if (this.parentParam1['condId' + i] == null) break
                        this.condArr.push(this.parentParam1['condId' + i])
                    }
                    this.parentParam1['execCondDesc'] = ''
                }
                console.log(
                    'receive popup param',
                    JSON.stringify(this.parentParam1)
                )
            },
            deep: false, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        resultList1: {
            // eslint-disable-next-line no-unused-vars
            handler: function (value) {
                this.setExecCondDesc()
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style>
#detail1,
#detail2 {
    background-color: #ffffff !important;
}
#detail1_1 {
    width: 45% !important;
}
#detail1_c {
    width: 10% !important;
    text-align: center !important;
}
#detail1_2 {
    width: 45% !important;
}
</style>
