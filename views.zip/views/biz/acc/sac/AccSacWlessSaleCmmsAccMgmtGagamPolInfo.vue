<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">정책정보 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridPolPopupHeader1"
                                ref="gridPolPopupHeader1"
                                gridTitle=""
                                :gridObj="gridObj"
                                :isExceldown="true"
                                class="notit"
                                @excelDownBtn="exportExcelDown"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="gridPolPopup1"
                                ref="gridPolPopup1"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
import CommonMixin from '@/mixins'
import sacApi from '@/api/biz/acc/sac'
import { GRID_HEADER } from '@/const/grid/acc/sac/AccSacWlessSaleCmmsAccMgmtGagamPolInfoGrid'

export default {
    name: 'AccSacWlessSaleCmmsAccMgmtGagamPolInfo',
    title: '정책정보 팝업',
    mixins: [CommonMixin],
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list: [],
            gridObj: {},
            gridHeaderObj: {},
            searchParams: {
                searchPageType: 'GAGAM-POL-POPUP',
                searchAccYm: this.popupParams.accYm,
                searchLvOrgCd: this.popupParams.lvOrgCd,
            },
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        this.gridObj = this.$refs.gridPolPopup1
        this.gridHeaderObj = this.$refs.gridPolPopupHeader1
        this.gridObj.setGridState(false, false, false, false)

        // 그리드 더블클릭시
        this.gridObj.gridView.onCellDblClicked = () => {
            this.onConfirm()
        }

        // 목록 조회
        this.onSearch()
    },
    methods: {
        onSearch: function () {
            console.log('search')
            sacApi
                .getAccSacWlessSaleCmmsAccMgmtList(this.searchParams)
                .then((res) => {
                    this.list = res
                    this.gridObj.setRows(this.list)
                })
        },
        onConfirm: function () {
            if (this.gridObj.gridView.getItemCount() == 0) {
                this.showTcComAlert('데이터가 없습니다.')
                return
            }
            var selectedRow = this.gridObj.gridView.getSelectedRows()
            if (_.isEmpty(selectedRow) || selectedRow.length == 0) {
                this.showTcComAlert('선택된 행이 없습니다.')
                return
            }

            this.$emit(
                'confirm',
                this.gridObj.gridView.getValues(selectedRow[0])
            )
            this.onClose()
        },
        onClose: function () {
            // 부모 함수 실행
            if (this.popupParams.isParentSearch) {
                this.$parent.onSearch()
            }

            // 팝업 닫기 실행
            this.activeOpenAgency = false
        },
        exportExcelDown: function () {
            if (this.list.length == 0) {
                this.showTcComAlert('출력할 데이터가 없습니다.')
                return
            }

            sacApi
                .downloadAccSacWlessSaleCmmsAccMgmtExcelDown(this.searchParams)
                .then(() => {
                    this.showTcComAlert('엑셀파일이 다운로드되었습니다.')
                })
        },
    },
}
</script>
