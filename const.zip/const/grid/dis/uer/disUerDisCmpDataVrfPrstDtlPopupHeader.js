import { ValueType } from 'realgrid'

// 재고보상 대상 List(T-key+) 그리드
export const DisUerDisCmpDataVrfPrstDtlPopup_GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'cfmYm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMM', // 정책월
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, // 재고보상대상금액
        },
        {
            fieldName: 'lastInoutDtlClVal',
            dataType: ValueType.TEXT, // 최종상품이력
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'cfmYm',
            fieldName: 'cfmYm',
            header: {
                text: '정책월',
            },
            datetimeFormat: 'yyyy-MM',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'occrAmt',
            fieldName: 'occrAmt',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고보상대상금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'lastInoutDtlClVal',
            fieldName: 'lastInoutDtlClVal',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최종상품이력',
                showTooltip: false,
            },
        },
    ],
}

// 재고보상 List(매입처) 그리드
export const DisUerDisCmpDataVrfPrstDtlPopup_GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'cfmYm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMM', // 정책월
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, // 재고보상대상금액
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'cfmYm',
            fieldName: 'cfmYm',
            header: {
                text: '정책월',
            },
            datetimeFormat: 'yyyy-MM',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'occrAmt',
            fieldName: 'occrAmt',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고보상대상금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
    ],
}

// 위탁창고 보상 대상 List(T-key+) 그리드
export const DisUerDisCmpDataVrfPrstDtlPopup_GRID_HEADER3 = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'occrQty',
            dataType: ValueType.NUMBER, // 수량
        },
        {
            fieldName: 'cfmYm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMM', // 정책월
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, // 재고보상대상금액
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'occrQty',
            fieldName: 'occrQty',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'cfmYm',
            fieldName: 'cfmYm',
            header: {
                text: '정책월',
            },
            datetimeFormat: 'yyyy-MM',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'occrAmt',
            fieldName: 'occrAmt',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고보상대상금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
    ],
}

// 위탁창고 보유재고 SKN 보상 List 그리드
export const DisUerDisCmpDataVrfPrstDtlPopup_GRID_HEADER4 = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'occrQty',
            dataType: ValueType.NUMBER, // 수량
        },
        {
            fieldName: 'cfmYm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMM', // 정책월
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, // 재고보상대상금액
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'occrQty',
            fieldName: 'occrQty',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'cfmYm',
            fieldName: 'cfmYm',
            header: {
                text: '정책월',
            },
            datetimeFormat: 'yyyy-MM',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'occrAmt',
            fieldName: 'occrAmt',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고보상대상금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
    ],
}

// T-key+ 누락 List 그리드
export const DisUerDisCmpDataVrfPrstDtlPopup_GRID_HEADER5 = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'cfmYm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMM', // 정책월
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, // 재고보상대상금액
        },
        {
            fieldName: 'lastInoutDtlClVal',
            dataType: ValueType.TEXT, // 최종상품이력
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'cfmYm',
            fieldName: 'cfmYm',
            header: {
                text: '정책월',
            },
            datetimeFormat: 'yyyy-MM',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'occrAmt',
            fieldName: 'occrAmt',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고보상대상금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'lastInoutDtlClVal',
            fieldName: 'lastInoutDtlClVal',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최종상품이력',
                showTooltip: false,
            },
        },
    ],
}

// SKN누락 List 그리드
export const DisUerDisCmpDataVrfPrstDtlPopup_GRID_HEADER6 = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'cfmYm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMM', // 정책월
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, // 재고보상대상금액
        },
        {
            fieldName: 'lastInoutDtlClVal',
            dataType: ValueType.TEXT, // 최종상품이력
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'cfmYm',
            fieldName: 'cfmYm',
            header: {
                text: '정책월',
            },
            datetimeFormat: 'yyyy-MM',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'occrAmt',
            fieldName: 'occrAmt',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고보상대상금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'lastInoutDtlClVal',
            fieldName: 'lastInoutDtlClVal',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최종상품이력',
                showTooltip: false,
            },
        },
    ],
}

// 위탁재고 검증 누락 List 그리드
export const DisUerDisCmpDataVrfPrstDtlPopup_GRID_HEADER7 = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'tkeyWare',
            dataType: ValueType.NUMBER, // T-key+수량
        },
        {
            fieldName: 'sknWare',
            dataType: ValueType.NUMBER, // SKN수량
        },
        {
            fieldName: 'gapWare',
            dataType: ValueType.NUMBER, // Gap
        },
        {
            fieldName: 'gapAmt',
            dataType: ValueType.NUMBER, // Gap금액
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'tkeyWare',
            fieldName: 'tkeyWare',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'sknWare',
            fieldName: 'sknWare',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'gapWare',
            fieldName: 'gapWare',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Gap',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'gapAmt',
            fieldName: 'gapAmt',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Gap금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
    ],
}
