import { ValueType } from 'realgrid'

export const DisDtrDisMovPrstGRID_HEADER = {
    fields: [
        {
            fieldName: 'outSchdDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'outOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outFixQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'inFixQty',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'outSchdDt',
            fieldName: 'outSchdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
            width: '100',
        },
        {
            name: 'outOrgNm',
            fieldName: 'outOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고조직',
                showTooltip: false,
            },
            width: '400',
        },
        {
            name: 'outDealSktCd',
            fieldName: 'outDealSktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고매장코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outDealcoCd',
            fieldName: 'outDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'inOrgNm',
            fieldName: 'inOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고조직',
                showTooltip: false,
            },
            width: '400',
        },
        {
            name: 'inDealSktCd',
            fieldName: 'inDealSktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고매장코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처',
                showTooltip: false,
            },
            footer: {
                text: '합계',
            },
            width: '150',
        },
        {
            name: 'outFixQty',
            fieldName: 'outFixQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동출고',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
            width: '100',
        },
        {
            name: 'inFixQty',
            fieldName: 'inFixQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동입고',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
            width: '100',
        },
    ],
}
