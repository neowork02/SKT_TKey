'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: '__rowState',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'dpstPlc',
        visible: false,
        header: { text: '입금처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'dpstPlcNm',
        editable: false,
        editor: { type: 'line' },
        header: { text: '입금처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'dpstDt',
        editable: false,
        editor: { type: 'date' },
        header: { text: '입금일자' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'dpstTm',
        editable: false,
        editor: { type: 'time' },
        header: { text: '입금시간' },
        type: 'data',
        fieldDatetimeFormat: 'hhmmss',
        columnDatetimeFormat: 'hh:mm:ss',
    },
    {
        fieldName: 'imagAccNo',
        editable: false,
        editor: { type: 'line' },
        header: { text: '가상계좌' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'dpstAccClNm',
        editable: false,
        editor: { type: 'line' },
        header: { text: '계좌구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'dpstAmt',
        editable: false,
        editor: { type: 'line' },
        header: { text: '입금액' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'procStClNm',
        editable: false,
        editor: { type: 'line' },
        header: { text: '처리상태' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'rfndYn',
        editable: false,
        editor: { type: 'line' },
        header: { text: '환불대상' },
        renderer: {
            type: 'check',
            falseValues: '0',
            trueValues: '1',
        },
        // styleCallback: (grid, dataCell) => {
        //     var ret = {}
        //     var rfndPossAmt = grid.getValue(
        //         dataCell.index.itemIndex,
        //         'rfndPossAmt'
        //     )

        //     if (rfndPossAmt == 0) {
        //         // ret.renderer = { type: 'text' }
        //         // ret.renderer = { type: 'check', editable: false }
        //         ret.renderer = { type: 'check' }
        //     }

        //     return ret
        // },
        // displayCallback: function () {
        //     return ''
        // },
        type: 'data',
    },
    {
        fieldName: 'rfndAmt',
        editable: false,
        editor: { type: 'line' },
        header: { text: '환불금액' },
        dataType: ValueType.NUMBER,
        styleName: 'right-column',
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'rfndPossAmt',
        editable: false,
        editor: { type: 'line' },
        header: { text: '환불가능금액' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 300px`

const MOCK_DATA = {
    rsDpstProcList: [
        {
            dpstPlcNm: '11',
            dpstDt: '20190202',
            dpstTm: '110101',
            imagAccNo: '11',
            dpstAccClNm: '11',
            dpstAmt: '1122313123',
            procStClNm: '11',
            rfndYn: '11',
            rfndAmt: '1213121',
            rfndPossAmt: '1213121',
        },
        {
            dpstPlcNm: '11',
            dpstDt: '20190202',
            dpstTm: '110101',
            imagAccNo: '11',
            dpstAccClNm: '11',
            dpstAmt: '1122313123',
            procStClNm: '11',
            rfndYn: '11',
            rfndAmt: '1213121',
            rfndPossAmt: '1213121',
        },
    ],
    rsRfndProcList: [
        {
            dealCoNm: 'ddsfsdf',
            ymd: '21201221',
            imagAccNo: '123123',
            accountCl: '123123213',
            bfBondAmt: '11020312',
            toFeesAmt: '1230123',
            toCashAmt: '1230013',
            toEtcmAmt: '1230031',
            toDpstAmt: '10320132',
            toRfndAmt: '13201230',
            toPpayAmt: '12303120',
            toRcvbAmt: '12300',
            toBondAmt: '1230210',
        },
        {
            dealCoNm: 'ddsfsdf',
            ymd: '21201221',
            imagAccNo: '123123',
            accountCl: '123123213',
            bfBondAmt: '11020312',
            toFeesAmt: '1230123',
            toCashAmt: '1230013',
            toEtcmAmt: '1230031',
            toDpstAmt: '10320132',
            toRfndAmt: '13201230',
            toPpayAmt: '12303120',
            toRcvbAmt: '12300',
            toBondAmt: '1230210',
        },
        {
            dealCoNm: 'ddsfsdf',
            ymd: '21201221',
            imagAccNo: '123123',
            accountCl: '123123213',
            bfBondAmt: '11020312',
            toFeesAmt: '1230123',
            toCashAmt: '1230013',
            toEtcmAmt: '1230031',
            toDpstAmt: '10320132',
            toRfndAmt: '13201230',
            toPpayAmt: '12303120',
            toRcvbAmt: '12300',
            toBondAmt: '1230210',
        },
        {
            dealCoNm: 'ddsfsdf',
            ymd: '21201221',
            imagAccNo: '123123',
            accountCl: '123123213',
            bfBondAmt: '11020312',
            toFeesAmt: '1230123',
            toCashAmt: '1230013',
            toEtcmAmt: '1230031',
            toDpstAmt: '10320132',
            toRfndAmt: '13201230',
            toPpayAmt: '12303120',
            toRcvbAmt: '12300',
            toBondAmt: '1230210',
        },
    ],
    rsRfndDealAccList: [
        {
            rfndDealCoCd: 'RFND_DEAL_CO_CD',
            rfndDealCoNm: 'RFND_DEAL_CO_NM',
            rfndAccNo: 'RFND_ACC_NO',
            rfndBankCd: 'RFND_BANK_CD',
            rfndDepo: 'RFND_DEPO',
            rfndDealCoCl: 'RFND_DEAL_CO_CL',
            equalYn: 'N',
            insUserId: 'string',
            modUserId: 'string',
        },
    ],
}

export { GRID_HEADER, MOCK_DATA }
