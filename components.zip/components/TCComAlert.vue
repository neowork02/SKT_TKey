<!-----------------------------------------------
 * 업무그룹명: Alert 컴포넌트
 * 서브업무명: Alert 공통함수
 * 설명: Alert 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.04.08
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <v-dialog
        persistent
        :max-width="cSize"
        v-if="dValue"
        v-model="dValue"
        @input="emitInput"
    >
        <template v-slot:default>
            <div class="layerPop">
                <!-- Popup_tit -->
                <p class="popTitle noDraggable">{{ headerText }}</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont alert">
                    <!-- textbox -->
                    <div class="text-box">
                        <p style="white-space: pre-line">{{ alertMessage }}</p>
                    </div>
                    <!-- //textbox -->
                    <!-- Close BTN-->
                    <a
                        v-show="btnOkShow"
                        href="#none"
                        class="layerClose b-close"
                        @click="emitClose"
                    >
                        <!-- 닫기 -->
                    </a>
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
                <!-- Popup_BTN :하단 버튼 1개 -->
                <div class="popBtn">
                    <!-- <TCComButton
                        v-show="btnCloseShow"
                        :Vuetify="false"
                        :labelName="confirmLabel"
                        class="btn_bottom full"
                        @click="emitOk"
                    >
                    </TCComButton> -->
                    <button
                        v-show="btnCloseShow"
                        ref="alertBtn"
                        type="button"
                        class="btn_bottom full"
                        @click="emitOk"
                    >
                        <span>{{ confirmLabel }}</span>
                    </button>
                </div>
                <!-- //Popup_BTN  :하단 버튼 1개-->
            </div>
        </template>
    </v-dialog>
</template>

<script>
export default {
    inheritAttrs: false,
    name: 'TCComAlert',
    components: {},
    props: {
        // 팝업오픈여부 양방향 바인딩
        value: { type: Boolean, default: false, required: false },
        // 하단 '확인' 버튼 노출 제어
        btnOkShow: { type: Boolean, default: true, required: false },
        // 상단 'X' 버튼 노출 제어
        btnCloseShow: { type: Boolean, default: true, required: false },
        // 하단 '확인' 버튼명
        confirmLabel: { type: String, default: '확인', required: false },
        //헤더 내용
        headerText: { type: String, default: '필수입력', required: false },
        //바디 내용
        bodyText: {
            type: String,
            default: '필수입력 입니다.',
            required: false,
        },
        //팝업 넓이
        size: { type: Number, default: null, required: false },
        // auth
        objAuth: { type: Object, default: () => {}, required: false },
    },

    data() {
        return {
            dValue: this.value,
        }
    },
    computed: {
        cSize() {
            let res = '360'
            if (this.size != null) {
                res = this.size + 'px'
            }
            return res
        },
        alertMessage() {
            const alertMessage = this.bodyText
            return alertMessage
        },
    },
    // props 동적 제어
    watch: {
        value: function () {
            this.$nextTick(() => {
                if (this.value === true) {
                    this.$refs.alertBtn.focus()
                }
            })
            this.dValue = this.value
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.dValue = this.value
        },
        emitInput(value) {
            this.$emit('input', value)
        },
        emitClose() {
            this.dValue = false
            this.emitInput(this.dValue)
            this.$emit('close-click')
        },
        emitOk() {
            this.dValue = false
            this.emitInput(this.dValue)
            this.$emit('ok-click')
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
