import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        { fieldName: 'dealcoGrpNm', dataType: ValueType.TEXT }, // 거래처그룹
        { fieldName: 'dealCoCl1Nm', dataType: ValueType.TEXT }, // 거래처구분
        { fieldName: 'dealCoCl2Nm', dataType: ValueType.TEXT }, // 거래처유형
        { fieldName: 'sknDelvPlcCd', dataType: ValueType.TEXT }, // 배송지코드
        { fieldName: 'sknDelvPlcNm', dataType: ValueType.TEXT }, // 배송지명
        { fieldName: 'dam', dataType: ValueType.TEXT }, // 사업담당명
        { fieldName: 'team', dataType: ValueType.TEXT }, // 사업팀명
        { fieldName: 'pt', dataType: ValueType.TEXT }, // 영업PT명
        { fieldName: 'treeOrgNm', dataType: ValueType.TEXT }, // 트리조직
        { fieldName: 'dealcoNm', dataType: ValueType.TEXT }, // 거래처명
        { fieldName: 'dealcoCd', dataType: ValueType.TEXT }, // 거래처코드
        { fieldName: 'sktChnlCd', dataType: ValueType.TEXT }, // P코드(skt대리점코드)
        { fieldName: 'dealStatus', dataType: ValueType.TEXT }, // 거래상태
        { fieldName: 'normalYn', dataType: ValueType.TEXT }, // 정상여부
        { fieldName: 'dealEndYn', dataType: ValueType.TEXT }, // 거래종료여부
        { fieldName: 'payStopYn', dataType: ValueType.TEXT }, // 수납정지여부
        { fieldName: 'outStopYn', dataType: ValueType.TEXT }, // 출고정지여부
        { fieldName: 'saleStopYn', dataType: ValueType.TEXT }, // 판매정지여부
        { fieldName: 'drwStopYn', dataType: ValueType.TEXT }, // 출금정지여부
        { fieldName: 'dealStaDt', dataType: ValueType.TEXT }, // 거래 개시일
        { fieldName: 'dealEndDt', dataType: ValueType.TEXT }, // 거래 종료일
        { fieldName: 'agencyCd', dataType: ValueType.TEXT }, // 배송대리점코드
        { fieldName: 'newAgencyNm', dataType: ValueType.TEXT }, // 배송대리점명
        { fieldName: 'newSubCd', dataType: ValueType.TEXT }, // 배송처SUB코드
        { fieldName: 'sktAgencyCd', dataType: ValueType.TEXT }, // SKT대리점코드
        { fieldName: 'sktAgencyNm', dataType: ValueType.TEXT }, // SKT대리점명
        { fieldName: 'sktSubCd', dataType: ValueType.TEXT }, // SKT_SUB코드
        { fieldName: 'postSubCd', dataType: ValueType.TEXT }, // POST코드
        { fieldName: 'useYn', dataType: ValueType.TEXT }, // 사용여부
        { fieldName: 'applyYn', dataType: ValueType.TEXT }, // 적용여부
        { fieldName: 'zipCd', dataType: ValueType.TEXT }, // 새우편번호
        { fieldName: 'sidoNm', dataType: ValueType.TEXT }, // 시도
        { fieldName: 'sigunguNm', dataType: ValueType.TEXT }, // 시군구
        { fieldName: 'eupmyundongNm', dataType: ValueType.TEXT }, // 읍면동
        { fieldName: 'streetNm', dataType: ValueType.TEXT }, // 도로명
        { fieldName: 'sigunguBldnNm', dataType: ValueType.TEXT }, // 법정동명
        { fieldName: 'ldongNm', dataType: ValueType.TEXT }, // 도로주소
        { fieldName: 'newDtlAddr', dataType: ValueType.TEXT }, // 도로주소상세
        { fieldName: 'sknDelvChrgrUserId', dataType: ValueType.TEXT }, // 수취담당자맨
        { fieldName: 'sknDelvMblPhonNo', dataType: ValueType.TEXT }, // 수취담당자연락처
        { fieldName: 'hstSeq', dataType: ValueType.TEXT }, // 이력순번
        { fieldName: 'rcvSknDelvPlcCd', dataType: ValueType.TEXT }, // SKN회신배송처코드
        { fieldName: 'sknZipCd', dataType: ValueType.TEXT }, // 직배송우편번호
        { fieldName: 'sknDelvAddr', dataType: ValueType.TEXT }, // 직배송주소
        { fieldName: 'sknDelvDtlAddr', dataType: ValueType.TEXT }, // 직배송상세주소
        { fieldName: 'sktDealCd', dataType: ValueType.TEXT }, // 매장코드

        { fieldName: 'ifYn', dataType: ValueType.TEXT },
        { fieldName: 'qckSvcCoNm', dataType: ValueType.TEXT },
        { fieldName: 'qckSvcTelNo', dataType: ValueType.TEXT },
        { fieldName: 'wgs84XCodnVal', dataType: ValueType.TEXT },
        { fieldName: 'wgs84YCodnVal', dataType: ValueType.TEXT },
        { fieldName: 'salePlcCd', dataType: ValueType.TEXT },
    ],
    columns: [
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            header: { text: '배송처사용여부' },
            editable: false,
        },
        {
            name: 'applyYn',
            fieldName: 'applyYn',
            type: 'data',
            header: { text: '배송처적용여부' },
            editable: false,
        },
        {
            name: 'dealcoGrpNm',
            fieldName: 'dealcoGrpNm',
            type: 'data',
            header: { text: '거래처그룹' },
            editable: false,
        },
        {
            name: 'dealCoCl1Nm',
            fieldName: 'dealCoCl1Nm',
            type: 'data',
            header: { text: '거래처구분' },
            editable: false,
        },
        {
            name: 'dealCoCl2Nm',
            fieldName: 'dealCoCl2Nm',
            type: 'data',
            header: { text: '거래처유형' },
            editable: false,
        },
        {
            name: 'sknDelvPlcCd',
            fieldName: 'sknDelvPlcCd',
            type: 'data',
            header: { text: '배송지코드' },
            editable: false,
        },
        {
            name: 'rcvSknDelvPlcCd',
            fieldName: 'rcvSknDelvPlcCd',
            type: 'data',
            header: { text: 'SKN배송지코드' },
            editable: false,
        },
        {
            name: 'sknDelvPlcNm',
            fieldName: 'sknDelvPlcNm',
            type: 'data',
            header: { text: '배송지명' },
            editable: false,
        },
        {
            name: 'dam',
            fieldName: 'dam',
            type: 'data',
            header: { text: '사업담당명' },
            editable: false,
        },
        {
            name: 'team',
            fieldName: 'team',
            type: 'data',
            header: { text: '사업팀명' },
            editable: false,
        },
        {
            name: 'pt',
            fieldName: 'pt',
            type: 'data',
            header: { text: '영업PT명' },
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: { text: '거래처명' },
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: { text: '거래처코드' },
            editable: false,
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            header: { text: 'P코드(skt대리점코드)' },
            editable: false,
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            type: 'data',
            header: { text: '거래상태' },
            editable: false,
        },
        {
            name: '정상여부',
            fieldName: 'normalYn',
            type: 'data',
            header: { text: '정상여부' },
            editable: false,
        },
        {
            name: '거래종료여부',
            fieldName: 'dealEndYn',
            type: 'data',
            header: { text: '거래종료여부' },
            editable: false,
        },
        {
            name: '수납정지여부',
            fieldName: 'payStopYn',
            type: 'data',
            header: { text: '수납정지여부' },
            editable: false,
        },
        {
            name: '출고정지여부',
            fieldName: 'outStopYn',
            type: 'data',
            header: { text: '출고정지여부' },
            editable: false,
        },
        {
            name: '판매정지여부',
            fieldName: 'saleStopYn',
            type: 'data',
            header: { text: '판매정지여부' },
            editable: false,
        },
        {
            name: '출금정지여부',
            fieldName: 'drwStopYn',
            type: 'data',
            header: { text: '출금정지여부' },
            editable: false,
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            type: 'data',
            header: { text: '거래개시일' },
            editable: false,
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            type: 'data',
            header: { text: '거래종료일' },
            editable: false,
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '배송대리점코드' },
            editable: false,
        },
        {
            name: 'newAgencyNm',
            fieldName: 'newAgencyNm',
            type: 'data',
            header: { text: '배송대리점명' },
            editable: false,
        },
        {
            name: 'newSubCd',
            fieldName: 'newSubCd',
            type: 'data',
            header: { text: '배송처SUB코드' },
            editable: false,
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            header: { text: 'SKT대리점코드' },
            editable: false,
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            header: { text: 'SKT대리점명' },
            editable: false,
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            header: { text: 'SKT_SUB코드' },
            editable: false,
        },
        {
            name: 'postSubCd',
            fieldName: 'postSubCd',
            type: 'data',
            header: { text: 'POST코드' },
            editable: false,
        },
        {
            name: 'zipCd',
            fieldName: 'zipCd',
            type: 'data',
            header: { text: '새우편번호' },
            editable: false,
        },
        {
            name: 'sidoNm',
            fieldName: 'sidoNm',
            type: 'data',
            header: { text: '시도' },
            editable: false,
        },
        {
            name: 'sigunguNm',
            fieldName: 'sigunguNm',
            type: 'data',
            header: { text: '시군구' },
            editable: false,
        },
        {
            name: 'eupmyundongNm',
            fieldName: 'eupmyundongNm',
            type: 'data',
            header: { text: '읍면동' },
            editable: false,
        },
        {
            name: 'streetNm',
            fieldName: 'streetNm',
            type: 'data',
            header: { text: '도로명' },
            editable: false,
        },
        {
            name: 'sigunguBldnNm',
            fieldName: 'sigunguBldnNm',
            type: 'data',
            header: { text: '법정동명' },
            editable: false,
        },
        {
            name: 'ldongNm',
            fieldName: 'ldongNm',
            type: 'data',
            header: { text: '도로주소' },
            editable: false,
        },
        {
            name: 'newDtlAddr',
            fieldName: 'newDtlAddr',
            type: 'data',
            header: { text: '도로주소상세' },
            editable: false,
        },
        {
            name: 'sknDelvChrgrUserId',
            fieldName: 'sknDelvChrgrUserId',
            type: 'data',
            header: { text: '수취담당자' },
            editable: false,
        },
        {
            name: 'sknDelvMblPhonNo',
            fieldName: 'sknDelvMblPhonNo',
            type: 'data',
            header: { text: '수취담당자연락처' },
            editable: false,
        },
        {
            name: '이력순번',
            fieldName: 'hstSeq',
            type: 'data',
            header: { text: '이력순번' },
            editable: false,
        },
        {
            name: 'sknZipCd',
            fieldName: 'sknZipCd',
            type: 'data',
            header: { text: '직배송우편번호' },
            editable: false,
        },
        {
            name: 'sknDelvAddr',
            fieldName: 'sknDelvAddr',
            type: 'data',
            header: { text: '직배송주소' },
            editable: false,
        },
        {
            name: 'sknDelvDtlAddr',
            fieldName: 'sknDelvDtlAddr',
            type: 'data',
            header: { text: '직배송상세주소' },
            editable: false,
        },
        {
            name: 'sktDealCd',
            fieldName: 'sktDealCd',
            type: 'data',
            header: { text: '매장코드' },
            editable: false,
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: 350,
            header: {
                text: '조직',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
    layout: [
        'useYn',
        'applyYn',
        'dealcoGrpNm',
        'dealCoCl1Nm',
        {
            name: '거래처',
            direction: 'horizontal',
            items: [
                'treeOrgNm',
                'sktDealCd',
                'dealcoCd',
                'dealcoNm',
                'dealStatus',
            ],
        },
        'dealCoCl2Nm',
        'sknDelvPlcCd',
        'rcvSknDelvPlcCd',
        'sknDelvPlcNm',
        'dam',
        'team',
        'pt',
        // 'dealcoNm',
        // 'dealcoCd',
        'sktChnlCd',
        // 'dealStatus',
        'dealStaDt',
        'dealEndDt',
        {
            name: '배송대리점',
            direction: 'horizontal',
            items: ['agencyCd', 'newAgencyNm', 'newSubCd'],
        },
        {
            name: 'Swing대리점',
            direction: 'horizontal',
            items: ['sktAgencyCd', 'sktAgencyNm', 'sktSubCd'],
        },
        'postSubCd',
        {
            name: '직배송(도로명)',
            direction: 'horizontal',
            items: [
                'zipCd',
                'sidoNm',
                'sigunguNm',
                'eupmyundongNm',
                'streetNm',
                'sigunguBldnNm',
                'ldongNm',
                'newDtlAddr',
            ],
        },
        {
            name: '직배송(지번)',
            direction: 'horizontal',
            items: ['sknZipCd', 'sknDelvAddr', 'sknDelvDtlAddr'],
        },
        'sknDelvChrgrUserId',
        'sknDelvMblPhonNo',
    ],
}
