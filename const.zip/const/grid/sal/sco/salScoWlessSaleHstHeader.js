import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'chk', //선택
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleNo', //판매번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleChgSeq', //판매변경순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgHstClNm', //이력구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTmNm', //팀
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgPtNm', //파트
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtm', //판매일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgDtm', //매출일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoCl1Nm', //거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoCl3Nm', //거래처분류
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'salePlcNm', //판매처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgUkeyChannelCd', //채널코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlClNm', //판매채널구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stlPlcNm', //정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prepadeClNm', //선후불구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prepadeTypNm', //선후불유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlCdNm', //영업채널
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cntrctMgmtNum', //계약관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', //서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNm', //고객정보_고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custBizNum', //고객정보_주민번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNum', //고객정보_개통번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dsNetCdNm', //개통정보_유통망
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agrmtPrdCdNm', //개통정보_약정기간
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtlTypNm', //개통정보_판매유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpSettlCondNm', //단말기정보_결제조건
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpMdlNm', //단말기정보_모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpSerNum', //단말기정보_일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpDisClCdNm', //단말기정보_구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimSettlCondNm', //USIM정보_결제조건
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimMdlNm', //USIM정보_모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimSerNum', //USIM정보_일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimDisClCdNm', //USIM정보_구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gearMdlNm', //스마트디바이스_모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gearSerNum', //스마트디바이스_일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gearDisClCdNm', //스마트디바이스_구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agrmtAstamt', //공시지원금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tgiftDcAmt', //T사은권할인금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'addDcAmt', //추가할인금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'kindPhoneDcAmt', //착한폰기변할인금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'kindPhoneDcLightAmt', //착한폰기변LIGHT할인금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cardDcAmt', //세이브카드
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'suplNms', //부가상품유치내역
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgrNm', //영업담당자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', //비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'paymentGubn', //(현금 건)매출상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm', //처리자정보_최초처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId', //처리자정보_최초처리자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', //처리자정보_변경처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', //처리자정보_변경처리자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm', //_조직트리
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNumOrg', //_개통번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpMdlCd', //_단말기CD
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpMdlAllotSalePrc', //_단말기할부금
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpMdlCashSalePrc', //_단말기현금가
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimMdlAllotSalePrc', //_USIM할부금
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimMdlCashSalePrc', //_USIM현금가
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactDcSuprtAmt', //_공시지원금
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'scrbFee', //_가입비
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mnpCmms', //_MNP수수료
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'frgGrtInsuFee', //_보증보험료
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sumPrprc', //_예수금소계
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opDt', //_IF일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opTm', //_IF시간
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq', //_IF순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcTypCd', //_개통유형코드
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            header: {
                text: '선택',
                excelName: '선택',
            },
            editable: true,
            visible: true,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1', //true
                falseValues: '0', //false
            },
            width: 30,
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            header: {
                text: '판매번호',
                excelName: '판매번호',
            },
            editable: false,
            visible: true,
            width: '150',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'gnrlSaleChgSeq',
            fieldName: 'gnrlSaleChgSeq',
            type: 'data',
            header: {
                text: '판매변경순번',
                excelName: '판매변경순번',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'saleChgHstClNm',
            fieldName: 'saleChgHstClNm',
            type: 'data',
            header: {
                text: '이력구분',
                excelName: '이력구분',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'orgTmNm',
            fieldName: 'orgTmNm',
            type: 'data',
            header: {
                text: '팀',
                excelName: '팀',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'orgPtNm',
            fieldName: 'orgPtNm',
            type: 'data',
            header: {
                text: '파트',
                excelName: '파트',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            header: {
                text: '판매일시',
                excelName: '판매일시',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            header: {
                text: '매출일시',
                excelName: '매출일시',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'dealCoCl1Nm',
            fieldName: 'dealCoCl1Nm',
            type: 'data',
            header: {
                text: '거래처구분',
                excelName: '거래처구분',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'dealCoCl3Nm',
            fieldName: 'dealCoCl3Nm',
            type: 'data',
            header: {
                text: '거래처분류',
                excelName: '거래처분류',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'salePlcNm',
            fieldName: 'salePlcNm',
            type: 'data',
            header: {
                text: '판매처',
                excelName: '판매처',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'orgUkeyChannelCd',
            fieldName: 'orgUkeyChannelCd',
            type: 'data',
            header: {
                text: '채널코드',
                excelName: '채널코드',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'saleChnlClNm',
            fieldName: 'saleChnlClNm',
            type: 'data',
            header: {
                text: '판매채널구분명',
                excelName: '판매채널구분명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'stlPlcNm',
            fieldName: 'stlPlcNm',
            type: 'data',
            header: {
                text: '정산처',
                excelName: '정산처',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'prepadeClNm',
            fieldName: 'prepadeClNm',
            type: 'data',
            header: {
                text: '선후불구분',
                excelName: '선후불구분',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'prepadeTypNm',
            fieldName: 'prepadeTypNm',
            type: 'data',
            header: {
                text: '선후불유형',
                excelName: '선후불유형',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'saleChnlCdNm',
            fieldName: 'saleChnlCdNm',
            type: 'data',
            header: {
                text: '영업채널',
                excelName: '영업채널',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'cntrctMgmtNum',
            fieldName: 'cntrctMgmtNum',
            type: 'data',
            header: {
                text: '계약관리번호',
                excelName: '계약관리번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            header: {
                text: '서비스관리번호',
                excelName: '서비스관리번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            header: {
                text: '고객명', //'고객정보_고객명',
                excelName: '고객정보_고객명',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'custBizNum',
            fieldName: 'custBizNum',
            type: 'data',
            header: {
                text: '주민번호', //'고객정보_주민번호',
                excelName: '고객정보_주민번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            header: {
                text: '개통번호', //'고객정보_개통번호',
                excelName: '고객정보_개통번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'dsNetCdNm',
            fieldName: 'dsNetCdNm',
            type: 'data',
            header: {
                text: '유통망', //'개통정보_유통망',
                excelName: '개통정보_유통망',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'agrmtPrdCdNm',
            fieldName: 'agrmtPrdCdNm',
            type: 'data',
            header: {
                text: '약정기간', //'개통정보_약정기간',
                excelName: '개통정보_약정기간',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'saleDtlTypNm',
            fieldName: 'saleDtlTypNm',
            type: 'data',
            header: {
                text: '판매유형', //'개통정보_판매유형',
                excelName: '개통정보_판매유형',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'eqpSettlCondNm',
            fieldName: 'eqpSettlCondNm',
            type: 'data',
            header: {
                text: '결제조건', //'단말기정보_결제조건',
                excelName: '단말기정보_결제조건',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'eqpMdlNm',
            fieldName: 'eqpMdlNm',
            type: 'data',
            header: {
                text: '모델', //'단말기정보_모델',
                excelName: '단말기정보_모델',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'eqpSerNum',
            fieldName: 'eqpSerNum',
            type: 'data',
            header: {
                text: '일련번호', //'단말기정보_일련번호',
                excelName: '단말기정보_일련번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'eqpDisClCdNm',
            fieldName: 'eqpDisClCdNm',
            type: 'data',
            header: {
                text: '구분', //'단말기정보_구분',
                excelName: '단말기정보_구분',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'usimSettlCondNm',
            fieldName: 'usimSettlCondNm',
            type: 'data',
            header: {
                text: '결제조건', //'USIM정보_결제조건',
                excelName: 'USIM정보_결제조건',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'usimMdlNm',
            fieldName: 'usimMdlNm',
            type: 'data',
            header: {
                text: '모델', //'USIM정보_모델',
                excelName: 'USIM정보_모델',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'usimSerNum',
            fieldName: 'usimSerNum',
            type: 'data',
            header: {
                text: '일련번호', //'USIM정보_일련번호',
                excelName: 'USIM정보_일련번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'usimDisClCdNm',
            fieldName: 'usimDisClCdNm',
            type: 'data',
            header: {
                text: '구분', //'USIM정보_구분',
                excelName: 'USIM정보_구분',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'gearMdlNm',
            fieldName: 'gearMdlNm',
            type: 'data',
            header: {
                text: '모델', //'스마트디바이스_모델',
                excelName: '스마트디바이스_모델',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'gearSerNum',
            fieldName: 'gearSerNum',
            type: 'data',
            header: {
                text: '일련번호', //'스마트디바이스_일련번호',
                excelName: '스마트디바이스_일련번호',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'gearDisClCdNm',
            fieldName: 'gearDisClCdNm',
            type: 'data',
            header: {
                text: '구분', //'스마트디바이스_구분',
                excelName: '스마트디바이스_구분',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'agrmtAstamt',
            fieldName: 'agrmtAstamt',
            type: 'data',
            header: {
                text: '공시지원금',
                excelName: '공시지원금',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'tgiftDcAmt',
            fieldName: 'tgiftDcAmt',
            type: 'data',
            header: {
                text: 'T사은권할인금액',
                excelName: 'T사은권할인금액',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'addDcAmt',
            fieldName: 'addDcAmt',
            type: 'data',
            header: {
                text: '추가할인금액',
                excelName: '추가할인금액',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'kindPhoneDcAmt',
            fieldName: 'kindPhoneDcAmt',
            type: 'data',
            header: {
                text: '착한폰기변할인금액',
                excelName: '착한폰기변할인금액',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'kindPhoneDcLightAmt',
            fieldName: 'kindPhoneDcLightAmt',
            type: 'data',
            header: {
                text: '착한폰기변LIGHT할인금액',
                excelName: '착한폰기변LIGHT할인금액',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'cardDcAmt',
            fieldName: 'cardDcAmt',
            type: 'data',
            header: {
                text: '세이브카드',
                excelName: '세이브카드',
            },
            editable: false,
            visible: true,
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'suplNms',
            fieldName: 'suplNms',
            type: 'data',
            header: {
                text: '부가상품유치내역',
                excelName: '부가상품유치내역',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'saleChrgrNm',
            fieldName: 'saleChrgrNm',
            type: 'data',
            header: {
                text: '영업담당자',
                excelName: '영업담당자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            header: {
                text: '비고',
                excelName: '비고',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'paymentGubn',
            fieldName: 'paymentGubn',
            type: 'data',
            header: {
                text: '(현금 건)매출상태 ',
                excelName: '(현금 건)매출상태 ',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            header: {
                text: '최초처리일시', //'처리자정보_최초처리일시',
                excelName: '처리자정보_최초처리일시',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            type: 'data',
            header: {
                text: '최초처리자', //'처리자정보_최초처리자',
                excelName: '처리자정보_최초처리자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            header: {
                text: '변경처리일시', //'처리자정보_변경처리일시',
                excelName: '처리자정보_변경처리일시',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            header: {
                text: '변경처리자', //'처리자정보_변경처리자',
                excelName: '처리자정보_변경처리자',
            },
            editable: false,
            visible: true,
            width: '150',
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            header: {
                text: '조직트리',
                excelName: '조직트리',
            },
            editable: false,
            visible: true,
            width: '350',
        },
        {
            name: 'svcNumOrg',
            fieldName: 'svcNumOrg',
            type: 'data',
            header: {
                text: '_개통번호',
                excelName: '_개통번호',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'eqpMdlCd',
            fieldName: 'eqpMdlCd',
            type: 'data',
            header: {
                text: '_단말기CD',
                excelName: '_단말기CD',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'eqpMdlAllotSalePrc',
            fieldName: 'eqpMdlAllotSalePrc',
            type: 'data',
            header: {
                text: '_단말기할부금',
                excelName: '_단말기할부금',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'eqpMdlCashSalePrc',
            fieldName: 'eqpMdlCashSalePrc',
            type: 'data',
            header: {
                text: '_단말기현금가',
                excelName: '_단말기현금가',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'usimMdlAllotSalePrc',
            fieldName: 'usimMdlAllotSalePrc',
            type: 'data',
            header: {
                text: '_USIM할부금',
                excelName: '_USIM할부금',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'usimMdlCashSalePrc',
            fieldName: 'usimMdlCashSalePrc',
            type: 'data',
            header: {
                text: '_USIM현금가',
                excelName: '_USIM현금가',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'mfactDcSuprtAmt',
            fieldName: 'mfactDcSuprtAmt',
            type: 'data',
            header: {
                text: '_공시지원금',
                excelName: '_공시지원금',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'scrbFee',
            fieldName: 'scrbFee',
            type: 'data',
            header: {
                text: '_가입비',
                excelName: '_가입비',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'mnpCmms',
            fieldName: 'mnpCmms',
            type: 'data',
            header: {
                text: '_MNP수수료',
                excelName: '_MNP수수료',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'frgGrtInsuFee',
            fieldName: 'frgGrtInsuFee',
            type: 'data',
            header: {
                text: '_보증보험료',
                excelName: '_보증보험료',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'sumPrprc',
            fieldName: 'sumPrprc',
            type: 'data',
            header: {
                text: '_예수금소계',
                excelName: '_예수금소계',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            header: {
                text: '_IF일자',
                excelName: '_IF일자',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'opTm',
            fieldName: 'opTm',
            type: 'data',
            header: {
                text: '_IF시간',
                excelName: '_IF시간',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            header: {
                text: '_IF순번',
                excelName: '_IF순번',
            },
            editable: false,
            visible: false,
            width: '150',
        },
        {
            name: 'svcTypCd',
            fieldName: 'svcTypCd',
            type: 'data',
            header: {
                text: '_개통유형코드',
                excelName: '_개통유형코드',
            },
            editable: false,
            visible: false,
            width: '150',
        },
    ],
}
