<template>
    <div v-if="this.isGridDlvDealcoInfo1">
        <!--<div>-->

        <!-- SubTit  -->
        <div class="stitHead">
            <h4 class="subTit">배송지정보</h4>
        </div>
        <!-- //SubTit -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div3">
                    <!--
                      <TCComInput
                          v-model="dlvDealcoInfo.sknDlvDealcoCd"
                          labelName="배송지코드"
                          :disabled="true"
                          :disabled="isDlvDealco"
                          @input="setData"
                      />
                      -->
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDlvDealcoCd"
                        labelName="배송지코드"
                        :disabled="isDlvDealco"
                        :readonly="true"
                        @input="setData"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div3">
                    <TCComInput
                        v-model="dlvDealcoInfo.rcvSknDlvDealcoCd"
                        labelName="SKN배송지코드"
                        :disabled="true"
                        @input="setData"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div3">
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDelvDealcdNm"
                        labelName="배송지명"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                        @input="setData"
                    />
                </div>
                <!-- //item 1-3 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="dlvDealcoInfo.agencyNm"
                        :codeVal.sync="dlvDealcoInfo.sknDlvSktAgencyCd"
                        :eRequired="true"
                        labelName="배송대리점"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAgencyEnterKey"
                        @appendIconClick="onAgencyIconClick"
                        @input="onAgencyInput"
                        :disabled="isDlvDealco"
                    />
                    <BasBcoAgencysPopup
                        v-if="showBcoAgencys"
                        :parentParam="agencySearchParam"
                        :rows="resultAgencyRows"
                        :dialogShow.sync="showBcoAgencys"
                        @confirm="onAgencyReturnData"
                    />
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div3">
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDlvSktSubCd"
                        labelName="배송대리점 서브코드"
                        labelClass="line2"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                        @input="setData"
                    />
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div3">
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDlvPwdNo"
                        labelName="직배송 인증번호"
                        labelClass="line2"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                        @input="setData"
                    />
                </div>
                <!-- //item 2-3 -->
            </div>
            <div class="searchform">
                <div class="formitem div3">
                    <TCComComboBox
                        v-model="dlvDealcoInfo.sknDlvClCd"
                        labelName="SKN창고코드"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="objAuth"
                        :itemList="sknWhouseCdList"
                        :disabled="isDlvDealco"
                        @input="setData"
                    ></TCComComboBox>
                </div>
                <div class="formitem div3"></div>
                <div class="formitem div3"></div>
            </div>
            <!-- //Search_line 2 -->
            <!-- Search_line 4 -->
            <div class="searchform">
                <!-- item 4-1 -->
                <div class="formitem div1">
                    <!-- label + 멀티폼_주소 -->
                    <div class="multiFormAddressType2">
                        <div class="col1">
                            <TCComInputSearch
                                labelName="배송지주소"
                                @appendIconClick="onNewZipSrchClick"
                                v-model="dlvDealcoInfo.sknDelvZipCd"
                                :disabled="isDlvDealco"
                                @input="setData"
                            />
                            <BasBcoNewZipSrchPopup1
                                v-if="showBcoNewZipSrch"
                                :rows="resultNewZipSrchRows"
                                :dialogShow.sync="showBcoNewZipSrch"
                                :parentParam="searchNewZipSrchParam"
                                @confirm="onNewZipSrchSReturnData"
                            />
                        </div>
                        <div class="col2">
                            <TCComNoLabelInput
                                class="inBlock"
                                v-model="dlvDealcoInfo.sknDelvAddr"
                                :disabled="true"
                                @input="setData"
                            />
                        </div>
                        <div class="col3">
                            <TCComNoLabelInput
                                class="inBlock"
                                v-model="dlvDealcoInfo.sknDelvDtlAddr"
                                :disabled="isDlvDealco"
                                @input="setData"
                            />
                        </div>
                        <div class="colbtn">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="복사"
                                @click="clickCopy"
                                :disabled="isDlvDealco"
                            />
                        </div>
                    </div>
                    <!-- // label + 멀티폼_주소 -->
                </div>
                <!-- //Search_line 4 -->
            </div>
            <!-- Search_line 6 -->
            <div class="searchform">
                <!-- item 6-1 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDlvChrgrUserId"
                        labelName="수취담당명"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                        @input="setData"
                    />
                </div>
                <!-- //item 6-1 -->
                <!-- item 6-2 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDlvMblPhonNo"
                        labelName="수취담당 연락처"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                        @input="setData"
                    />
                </div>
                <!-- //item 6-2 -->
                <!-- item 6-3 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        v-model="dlvDealcoInfo.aplyStaDt"
                        labelName="적용시작일"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                        @input="setData"
                    />
                </div>
                <!-- //item 6-3 -->
                <!-- item 6-4 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="dlvDealcoInfo.useYn"
                        labelName="사용여부"
                        :addBlankItem="true"
                        :itemList="comYn"
                        blankItemText="선택"
                        blankItemValue=""
                        :eRequired="true"
                        :disabled="isDlvDealco"
                        @input="setData"
                    ></TCComComboBox>
                </div>
                <!-- //item 6-4 -->
            </div>
            <!-- //Search_line 6 -->
            <!-- Search_line 7 -->
            <div class="searchform">
                <!-- item 7-1 -->
                <div class="formitem div1">
                    <TCComTextArea
                        v-model="dlvDealcoInfo.sknDlvRmks"
                        labelName="비고"
                        :disabled="isDlvDealco"
                        @input="setData"
                    />
                </div>
                <!-- //item 7-1 -->
            </div>
            <!-- //Search_line 7 -->
            <!-- Search_line 7 -->
            <!--
            <div class="searchform">
          
                <div class="formitem div1">
                    <div class="rightArea">
                        <span class="inner">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="임시저장"
                                :objAuth="objAuth"
                                @click="tempSave"
                            />
                        </span>
                    </div>
                </div>
                
            </div>
            -->
            <!-- //Search_line 7 -->
        </div>
        <!-- //Search_div -->

        <!-- SubTit  -->
        <div class="stitHead">
            <span class="stitBtnRef notit mb10">
                <!--                <TCComButton-->
                <!--                    :Vuetify="false"-->
                <!--                    eClass="btn_noline btn_ty04"-->
                <!--                    eAttr="ico_basic"-->
                <!--                    labelName="배송지 정보수정"-->
                <!--                    @click="updateInfo"-->
                <!--                />-->
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_basic"
                    labelName="전송"
                    :objAuth="objAuth"
                    @click="submit"
                />
                <SendPopup
                    v-if="showSendDtPopup"
                    :parentParam="searchSendDtParam"
                    :rows="resultSendDtRows"
                    :dialogShow.sync="showSendDtPopup"
                />
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_filesave"
                    labelName="입력저장"
                    :objAuth="objAuth"
                    @click="tempSave"
                />
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowadd"
                    labelName="행추가"
                    @click="gridAddRowBtn"
                />
                <TCComButton
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowdel"
                    labelName="행삭제"
                    @click="gridChkDelRowBtn"
                />
            </span>
        </div>
        <!-- //SubTit -->
        <TCRealGrid
            id="gridDlvDealcoInfo"
            ref="gridDlvDealcoInfo"
            :editable="false"
            :updatable="false"
            :movable="false"
            :columnMovable="false"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
        <p class="infoTxt">
            <span class="color-red">
                수정/등록 후 입력저장 버튼을 눌러야 반영이 됩니다.
            </span>
        </p>
    </div>
</template>

<script>
import { CommonGrid } from '@/utils'
import { GRID_DLV_HEADER } from '@/const/grid/bas/prm/basPrmDealcoMgmtHeader'

import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dealcoMgmt/helpers'

import _ from 'lodash'
import CommonMixin from '@/mixins'
//====================대리점팝업====================
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
//====================//대리점팝업====================
//====================우편번호팝업====================
import BasBcoNewZipSrchPopup1 from '@/views/biz/bas/bco/BasBcoNewZipSrchPopup'
import basBcoNewZipSrchApi from '@/api/biz/bas/bco/basBcoNewZipSrch'
//====================//우편번호팝업====================
import SendPopup from './SendPopupContainer'
import CommonUtil from '@/utils/CommonUtil'
import { msgTxt } from '@/const/msg.Properties'
export default {
    name: 'DlvDealcoInfoContainer',
    props: {},
    components: {
        BasBcoAgencysPopup,
        BasBcoNewZipSrchPopup1,
        SendPopup,
    },
    mixins: [CommonMixin],
    computed: {
        ...serviceComputed,
        //==================== 상세데이터 ==================
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
        basPrmDealcoDtlDlvList1: {
            get() {
                return this.basPrmDealcoDtlDlvList
            },
        },
        dlvDealcoInfoData1: {
            get() {
                return this.dlvDealcoInfoData
            },
        },
        //==================== //상세데이터 ==================
        comYn: {
            get() {
                return this.COM_YN
            },
        },
        sknWhouseCdList1: {
            get() {
                return this.SKN_WHOUSE_CD
            },
        },
        isGridDlvDealcoInfo1: {
            get() {
                return this.isGridDlvDealcoInfo
            },
        },
        getSknDlvDealcoCd1: {
            get() {
                return this.getSknDlvDealcoCd
            },
        },
    },
    created() {},
    data() {
        return {
            objCnt: 0,
            view: GRID_DLV_HEADER,
            isDtlAdd: false,
            isDlvDealco: true,
            gridData: this.gridSetData(),
            storeKey: 'dlvDealcoInfoData',
            objAuth: {},
            gridObj: {},
            dlvDealcoInfo: {
                sknDlvDealcoCd: '',
                rcvSknDlvDealcoCd: '',
                sknDelvDealcdNm: '',
                agencyNm: '',
                sknDlvSktAgencyCd: '',
                sknDlvSktSubCd: '',
                sknDlvPwdNo: '',
                sknDlvClCd: '',
                sknDelvZipCd: '',
                sknDelvAddr: '',
                sknDelvDtlAddr: '',
                sknDlvChrgrUserId: '',
                sknDlvMblPhonNo: '',
                aplyStaDt: '',
                useYn: '',
                sknDlvRmks: '',
                sknDlvAplyStaDt: '',
                sknDlvUseYn: '',
                __rowState: '',
            },
            oldDlvDealcoInfo: {
                index: 0,
                sknDlvDealcoCd: '',
                rcvSknDlvDealcoCd: '',
                sknDelvDealcdNm: '',
                agencyNm: '',
                sknDlvSktAgencyCd: '',
                sknDlvSktSubCd: '',
                sknDlvPwdNo: '',
                sknDlvClCd: '',
                sknDelvZipCd: '',
                sknDelvAddr: '',
                sknDelvDtlAddr: '',
                sknDlvChrgrUserId: '',
                sknDlvMblPhonNo: '',
                aplyStaDt: '',
                useYn: '',
                sknDlvRmks: '',
                sknDlvAplyStaDt: '',
                sknDlvUseYn: '',
                __rowState: '',
            },
            gridStyle: {
                height: '130px', //그리드 높이 조절
            },
            layout3: [
                'sknDlvDealcoCd',
                'sknDelvDealcdNm',
                'sknDlvSktAgencyCd',
                'agencyNm',
                'sknDlvSktSubCd',
                'useYn',
                'applyYn',
            ],
            sknWhouseCdList: [{ commCdVal: '', commCdValNm: '선택' }], // SKN창고코드
            //====================대리점팝업관련====================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            agencySearchParam: {
                sknDlvSktAgencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
            //====================우편번호팝업관련===================
            showBcoNewZipSrch: false, // 팝업 오픈 여부
            searchNewZipSrchParam: {
                sknDelvAddr: '',
                sknDelvDtlAddr: '',
            },
            resultNewZipSrchRows: [], // 팝업 오픈 여부
            //====================//우편번호팝업관련=================
            clickStatus: null,
            //====================거래상태변경====================
            showSendDtPopup: false,
            searchSendDtParam: {
                sendDtCd: '', // 전송
            },
            resultSendDtRows: [],
            //====================//거래상태변경==================
            isUptDlvDealcoInfo: false,
            clickIndex: 0,
        }
    },
    mounted() {
        this.initData()
        if (this.pIsNew) {
            this.initDlvDealcoInfo()
        }
    },
    methods: {
        ...serviceMethods,
        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        setData() {
            let params = { ...this.dlvDealcoInfo }

            if (!_.isEmpty(this.dlvDealcoInfoData)) {
                let checkKeys = [
                    'sknDlvDealcoCd',
                    'rcvSknDlvDealcoCd',
                    'sknDelvDealcdNm',
                    'agencyNm',
                    'sknDlvSktAgencyCd',
                    'sknDlvSktSubCd',
                    'sknDlvPwdNo',
                    'sknDlvClCd',
                    'sknDelvZipCd',
                    'sknDlvChrgrUserId',
                    'sknDlvMblPhonNo',
                    'sknDlvAplyStaDt',
                    'sknDlvUseYn',
                    'sknDlvRmks',
                ]

                checkKeys.some((key) => {
                    if (
                        !_.isEmpty(this.dlvDealcoInfoDataOld) &&
                        !_.isEqual(
                            this.dlvDealcoInfoDataOld[key],
                            this.dlvDealcoInfoData[key]
                        )
                    ) {
                        this.isUptDlvDealcoInfo = true
                        return true
                    } else {
                        if (_.isEmpty(this.dlvDealcoInfoDataOld)) {
                            this.storeSet('dlvDealcoInfoDataOld', params)
                        }

                        this.isUptDlvDealcoInfo = false
                    }
                })
            }

            this.storeSet('isDlvDealcoInfo', this.isUptDlvDealcoInfo)

            this.storeSet(this.storeKey, params)
        },
        initData() {
            this.dlvDealcoInfo = {
                sknDlvDealcoCd: '',
                rcvSknDlvDealcoCd: '',
                sknDelvDealcdNm: '',
                agencyNm: '',
                sknDlvSktAgencyCd: '',
                sknDlvSktSubCd: '',
                sknDlvPwdNo: '',
                sknDlvClCd: '',
                sknDelvZipCd: '',
                sknDelvAddr: '',
                sknDelvDtlAddr: '',
                sknDlvChrgrUserId: '',
                sknDlvMblPhonNo: '',
                aplyStaDt: '',
                useYn: '',
                sknDlvRmks: '',
                sknDlvAplyStaDt: '',
                sknDlvUseYn: '',
                __rowState: '',
            }
            this.sknWhouseCdList = this.sknWhouseCdList1
            this.isUptDlvDealcoInfo = false
        },
        initDlvDealcoInfo() {
            if (this.$refs.gridDlvDealcoInfo !== undefined) {
                this.gridObj = this.$refs.gridDlvDealcoInfo
                this.gridObj.gridView.setColumnLayout(this.layout3)
                this.gridObj.gridView.commit()
                this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
                this.gridObj.gridView.setDisplayOptions.focusVisible = false //포커스 표시 여부
                this.gridObj.setGridState(true, true, true, false)

                if (!this.isDtlAdd) {
                    if (!_.isEmpty(this.basPrmDealcoDtlDlvList1)) {
                        this.gridObj.setRows(this.basPrmDealcoDtlDlvList1)
                        this.gridObj.gridView.onCellClicked = (
                            grid,
                            clickData
                        ) => {
                            this.clickIndex = clickData.itemIndex
                            if (typeof clickData.itemIndex !== 'undefined') {
                                this.isDlvDealco = false
                                _.forEach(GRID_DLV_HEADER.fields, (item) => {
                                    const key = item.fieldName
                                    this.dlvDealcoInfo[key] = grid.getValue(
                                        clickData.itemIndex,
                                        key
                                    )
                                    this.oldDlvDealcoInfo.index =
                                        clickData.itemIndex
                                    this.oldDlvDealcoInfo[key] = grid.getValue(
                                        clickData.itemIndex,
                                        key
                                    )
                                })
                            }
                        }
                    }
                    this.isDtlAdd = true
                }
            }
        },
        gridSetData() {
            return new CommonGrid(0, 10, '', '')
        },
        _getSknDlvDealcoCd() {
            let dealcoRgstClCd = this.strdInfoData.dealcoRgstClCd // 매장개별 DS
            let dealcoGrpCd = this.strdInfoData.dealcoGrpCd // 물류창고, 기타 ZZ, XZ

            let sktAgencyCd = this.etcAddInfoData.sktAgencyCd
            let sktChnlCd = this.etcAddInfoData.sktChnlCd
            let sktSubCd = this.etcAddInfoData.sktSubCd
            let agencyNm = this.dlvDealcoInfo.agencyNm

            let sknDlvDealcoCd = this.dlvDealcoInfo.sknDlvDealcoCd
            //let sknDlvSktAgencyCd = this.dlvDealcoInfo.sknDlvSktAgencyCd
            let newKey = ''

            if (
                _.isEqual(dealcoRgstClCd, 'DS') && // 매장개별(DS)
                (_.isEqual(dealcoGrpCd, 'ZZ') || _.isEqual(dealcoGrpCd, 'XZ')) // 물류창고(ZZ), 기타(XZ)
            ) {
                if (_.isEmpty(sknDlvDealcoCd)) {
                    newKey = this.getSknDlvDealcoCd1
                    if (_.isEqual(agencyNm, 'TWSN')) {
                        newKey = newKey + 'N'
                    } else if (_.isEqual(agencyNm, 'TWSP')) {
                        newKey = newKey + 'P'
                    } else {
                        newKey = newKey + '0'
                    }
                    this.dlvDealcoInfo.sknDlvDealcoCd = newKey
                }
            } else {
                //
                // 배송지코드 가공 (총 12자리)
                // 채널코드값이 있는 경우
                // Swing코드 : D09998(6) + 채널코드 : P12345(6)
                // 기본 D09998(6) + 0035(4) + 00(2자리)
                // TWSN : D09998(6) + 0035(4) + N0(2자리)
                // TWSP : D09998(6) + 0035(4) + P0(2자리)
                //
                if (_.isEmpty(sknDlvDealcoCd)) {
                    if (!_.isEmpty(sktChnlCd)) {
                        // 채널코드가 있는 경우
                        newKey = sktAgencyCd + sktChnlCd
                    } else {
                        if (_.isEqual(agencyNm, 'TWSN')) {
                            newKey = sktAgencyCd + sktSubCd + 'N0'
                        } else if (_.isEqual(agencyNm, 'TWSP')) {
                            newKey = sktAgencyCd + sktSubCd + 'P0'
                        } else {
                            newKey = sktAgencyCd + sktSubCd + '00'
                        }
                    }
                }
            }
            return newKey
        },
        dlvDealcoInfoValidation() {
            const sknDlvDealcoCd = this.dlvDealcoInfo.sknDlvDealcoCd
            const sknDelvDealcdNm = this.dlvDealcoInfo.sknDelvDealcdNm
            const sknDlvSktAgencyCd = this.dlvDealcoInfo.sknDlvSktAgencyCd
            const sknDlvSktSubCd = this.dlvDealcoInfo.sknDlvSktSubCd
            const sknDlvPwdNo = this.dlvDealcoInfo.sknDlvPwdNo
            const sknDlvChrgrUserId = this.dlvDealcoInfo.sknDlvChrgrUserId
            const sknDlvMblPhonNo = this.dlvDealcoInfo.sknDlvMblPhonNo
            const sknDlvAplyStaDt = this.dlvDealcoInfo.aplyStaDt
            const sknDlvUseYn = this.dlvDealcoInfo.useYn
            const sktAgencyCd = this.etcAddInfoData.sktAgencyCd
            console.log(' ======================================== ')
            console.log('sknDlvDealcoCd ->', sknDlvDealcoCd)
            console.log('sknDelvDealcdNm ->', sknDelvDealcdNm)
            console.log('sknDlvSktAgencyCd ->', sknDlvSktAgencyCd)
            console.log('sknDlvSktSubCd ->', sknDlvSktSubCd)
            console.log('sknDlvPwdNo ->', sknDlvPwdNo)
            console.log('sknDlvChrgrUserId ->', sknDlvChrgrUserId)
            console.log('sknDlvMblPhonNo ->', sknDlvMblPhonNo)
            console.log('sknDlvAplyStaDt ->', sknDlvAplyStaDt)
            console.log('sknDlvUseYn ->', sknDlvUseYn)
            console.log('sktAgencyCd ->', sktAgencyCd)

            if (_.isEmpty(sktAgencyCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, 'Swing대리점')
                )
                return false
            } else if (_.isEmpty(sknDelvDealcdNm)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '배송지명')
                )
                return false
            } else if (_.isEmpty(sknDlvSktAgencyCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '배송대리점을')
                )
                return false
            } else if (_.isEmpty(sknDlvSktSubCd)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(
                        msgTxt.MSG_00083,
                        '배송대리점서브코드'
                    )
                )
                return false
            } else if (_.isEmpty(sknDlvPwdNo)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '직배송인증번호')
                )
                return false
            } else if (_.isEmpty(sknDlvChrgrUserId)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '수취담당명')
                )
                return false
            } else if (_.isEmpty(sknDlvMblPhonNo)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '수취담담연락처')
                )
                return false
            } else if (_.isEmpty(sknDlvAplyStaDt)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00083, '적용시작일')
                )
                return false
            } else if (_.isEmpty(sknDlvUseYn)) {
                this.showTcComAlert(
                    CommonUtil.replaceMsg(msgTxt.MSG_00047, '사용여부를')
                )
                return false
            } else {
                if (_.isEmpty(sknDlvDealcoCd)) {
                    this.getSknDlvSkyAgencyCd()
                }
                return true
            }
        },
        getJsonData(save, type) {
            let rows =
                this.$refs.gridDlvDealcoInfo.dataProvider.getStateRows(type)

            for (let idx = 0; idx < rows.length; idx++) {
                let data = this.$refs.gridDlvDealcoInfo.dataProvider.getJsonRow(
                    rows[idx]
                )

                let sknDlvDealcoCd = this.dlvDealcoInfo.sknDlvDealcoCd
                let rcvSknDlvDealcoCd = _.isEmpty(data.rcvSknDlvDealcoCd)
                    ? ''
                    : data.rcvSknDlvDealcoCd
                let sknDelvDealcdNm = _.isEmpty(data.sknDelvDealcdNm)
                    ? ''
                    : data.sknDelvDealcdNm
                let agencyNm = _.isEmpty(data.agencyNm) ? '' : data.agencyNm
                let sknDlvSktAgencyCd = _.isEmpty(data.sknDlvSktAgencyCd)
                    ? ''
                    : data.sknDlvSktAgencyCd
                let sknDlvSktSubCd = _.isEmpty(data.sknDlvSktSubCd)
                    ? ''
                    : data.sknDlvSktSubCd
                let sknDlvPwdNo = _.isEmpty(data.sknDlvPwdNo)
                    ? ''
                    : data.sknDlvPwdNo
                let sknDlvClCd = _.isEmpty(data.sknDlvClCd)
                    ? ''
                    : data.sknDlvClCd
                let sknDelvZipCd = _.isEmpty(data.sknDelvZipCd)
                    ? ''
                    : data.sknDelvZipCd
                let sknDelvAddr = _.isEmpty(data.sknDelvAddr)
                    ? ''
                    : data.sknDelvAddr
                let sknDelvDtlAddr = _.isEmpty(data.sknDelvDtlAddr)
                    ? ''
                    : data.sknDelvDtlAddr
                let sknDlvChrgrUserId = _.isEmpty(data.sknDlvChrgrUserId)
                    ? ''
                    : data.sknDlvChrgrUserId
                let sknDlvMblPhonNo = _.isEmpty(data.sknDlvMblPhonNo)
                    ? ''
                    : data.sknDlvMblPhonNo
                let useYn = _.isEmpty(data.useYn) ? '' : data.useYn
                let sknDlvUseYn = _.isEmpty(data.sknDlvUseYn)
                    ? ''
                    : data.sknDlvUseYn
                let sknDlvRmks = _.isEmpty(data.sknDlvRmks)
                    ? ''
                    : data.sknDlvRmks
                let aplyStaDt = _.isEmpty(data.aplyStaDt) ? '' : data.aplyStaDt
                let sknDlvAplyStaDt = _.isEmpty(data.sknDlvAplyStaDt)
                    ? ''
                    : data.sknDlvAplyStaDt
                let __rowState = type

                data.sknDlvDealcoCd = sknDlvDealcoCd
                data.rcvSknDlvDealcoCd = rcvSknDlvDealcoCd
                data.sknDelvDealcdNm = sknDelvDealcdNm
                data.agencyNm = agencyNm
                data.sknDlvSktAgencyCd = sknDlvSktAgencyCd
                data.sknDlvSktSubCd = sknDlvSktSubCd
                data.sknDlvPwdNo = sknDlvPwdNo
                data.sknDlvClCd = sknDlvClCd
                data.sknDelvZipCd = sknDelvZipCd
                data.sknDelvAddr = sknDelvAddr
                data.sknDelvDtlAddr = sknDelvDtlAddr
                data.sknDlvChrgrUserId = sknDlvChrgrUserId
                data.sknDlvMblPhonNo = sknDlvMblPhonNo
                data.useYn = useYn
                data.sknDlvUseYn = sknDlvUseYn
                data.sknDlvRmks = sknDlvRmks
                data.aplyStaDt = aplyStaDt
                data.sknDlvAplyStaDt = sknDlvAplyStaDt
                data.sknDlvUseYn = useYn
                data.__rowState = __rowState
                save.push(data)
            }
        },
        isNewData(values) {
            if (this.clickIndex === this.oldDlvDealcoInfo.index) {
                if (!_.isEmpty(this.oldDlvDealcoInfo.sknDlvDealcoCd)) {
                    const checkKeys = [
                        'sknDlvDealcoCd',
                        'rcvSknDlvDealcoCd',
                        'sknDelvDealcdNm',
                        'agencyNm',
                        'sknDlvSktAgencyCd',
                        'sknDlvSktSubCd',
                        'sknDlvPwdNo',
                        'sknDlvClCd',
                        'sknDelvZipCd',
                        'sknDelvAddr',
                        'sknDelvDtlAddr',
                        'sknDlvChrgrUserId',
                        'sknDlvMblPhonNo',
                        'aplyStaDt',
                        'useYn',
                        'sknDlvRmks',
                        'sknDlvAplyStaDt',
                        'sknDlvUseYn',
                    ]
                    let isUpt = true
                    checkKeys.some((key) => {
                        if (
                            !_.isEqual(values[key], this.oldDlvDealcoInfo[key])
                        ) {
                            values['__rowState'] = 'updated'
                            isUpt = true
                            return true
                        } else {
                            isUpt = false
                        }
                    })
                    return isUpt
                } else {
                    return true
                }
            }
            return true
        },
        tempSave() {
            if (this.isDlvDealco) return false

            if (!this.dlvDealcoInfoValidation()) {
                return false
            }
            this.showTcComConfirm('입력저장 하시겠습니까?').then((confirm) => {
                if (!confirm) return false

                let sknDlvDealcoCd_ = _.isEmpty(this.getSknDlvDealcoCd)
                    ? this.dlvDealcoInfo.sknDlvDealcoCd
                    : this.getSknDlvDealcoCd

                const values = {
                    //sknDlvDealcoCd: this._getSknDlvDealcoCd(), // 배송지코드 생성
                    sknDlvDealcoCd: sknDlvDealcoCd_,
                    rcvSknDlvDealcoCd: this.dlvDealcoInfo.rcvSknDlvDealcoCd,
                    sknDelvDealcdNm: this.dlvDealcoInfo.sknDelvDealcdNm,
                    agencyNm: this.dlvDealcoInfo.agencyNm,
                    sknDlvSktAgencyCd: this.dlvDealcoInfo.sknDlvSktAgencyCd,
                    sknDlvSktSubCd: this.dlvDealcoInfo.sknDlvSktSubCd,
                    sknDlvPwdNo: this.dlvDealcoInfo.sknDlvPwdNo,
                    sknDlvClCd: this.dlvDealcoInfo.sknDlvClCd,
                    sknDelvZipCd: this.dlvDealcoInfo.sknDelvZipCd,
                    sknDelvAddr: this.dlvDealcoInfo.sknDelvAddr,
                    sknDelvDtlAddr: this.dlvDealcoInfo.sknDelvDtlAddr,
                    sknDlvChrgrUserId: this.dlvDealcoInfo.sknDlvChrgrUserId,
                    sknDlvMblPhonNo: this.dlvDealcoInfo.sknDlvMblPhonNo,
                    useYn: this.dlvDealcoInfo.useYn,
                    sknDlvUseYn: this.dlvDealcoInfo.useYn,
                    sknDlvRmks: this.dlvDealcoInfo.sknDlvRmks,
                    aplyStaDt: this.dlvDealcoInfo.aplyStaDt,
                    sknDlvAplyStaDt: this.dlvDealcoInfo.aplyStaDt,
                    __rowState: 'created',
                }

                if (!this.isNewData(values)) {
                    this.showTcComAlert('변경된 데이터가 없습니다')
                    return false
                }

                this.$refs.gridDlvDealcoInfo.dataProvider.updateRow(
                    this.clickIndex,
                    values
                )

                this.$refs.gridDlvDealcoInfo.gridView.commit()
                let rows =
                    this.$refs.gridDlvDealcoInfo.dataProvider.getJsonRows()
                this.storeSet('basPrmDealcoDtlDlvList', rows)
            })
        },
        getSknDlvSkyAgencyCd() {
            const dealcoGrpCd = this.strdInfoData.dealcoGrpCd // 거래처그룹코드
            const dealcoRgstClCd = this.strdInfoData.dealcoRgstClCd // 거래처등록구분코드
            const sknDlvSktAgencyCd = this.dlvDealcoInfoData.sknDlvSktAgencyCd // 배송지대리점코드
            const sktAgencyCd = this.etcAddInfoData.sktAgencyCd // SKT대리점코드
            const sktChnlCd = this.etcAddInfoData.sktChnlCd // SKT서브점코드
            const sktSubCd = this.etcAddInfoData.sktSubCd // SKT채널코드

            // if (
            //     _.isEqual(dealcoRgstClCd, 'DS') && // 매장개별(DS)
            //     (_.isEqual(dealcoGrpCd, 'ZZ') || _.isEqual(dealcoGrpCd, 'XZ')) // 물류창고(ZZ), 기타(XZ)
            // ) { // 221206 배송지정보에서 코드발급 받는걸로 로직변경
            let param = {}
            param['dealcoGrpCd'] = dealcoGrpCd
            param['dealcoRgstClCd'] = dealcoRgstClCd
            param['sknDlvSktAgencyCd'] = sknDlvSktAgencyCd
            param['sktAgencyCd'] = sktAgencyCd
            param['sktChnlCd'] = sktChnlCd
            param['sktSubCd'] = sktSubCd
            let list = [param]
            let params = {}
            params['basPrmDealcoDtlNewDlvDealcoCdDto'] = list
            this.storeSet('paramAgencyCd', params)

            this.getSknDlvDealcoCd_()
                .then((data) => {
                    console.log('data ->', data)
                    this.storeSet('getSknDlvDealcoCd', data[0].sknDlvDealcoCd)
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('배송지코드발급종료')
                })
            // }
        },
        updateInfo() {
            if (this.isDlvDealco) {
                this.isDlvDealco = false
                if (_.isEmpty(this.dlvDealcoInfo.sknDlvDealcoCd)) {
                    let sktAgencyCd = this.etcAddInfoData.sktAgencyCd
                    let sktChnlCd = this.etcAddInfoData.sktChnlCd
                    let sktSubCd = this.etcAddInfoData.sktSubCd
                    let agencyNm = this.dlvDealcoInfo.agencyNm
                    let newKey
                    /**
                     * 배송지코드 가공 (총 12자리)
                     * 채널코드값이 있는 경우
                     * Swing코드 : D09998(6) + 채널코드 : P12345(6)
                     * 기본 D09998(6) + 0035(4) + 00(2자리)
                     * TWSN : D09998(6) + 0035(4) + N0(2자리)
                     * TWSP : D09998(6) + 0035(4) + P0(2자리)
                     */
                    if (!_.isEmpty(sktChnlCd)) {
                        // 채널코드가 있는 경우
                        newKey = sktAgencyCd + sktChnlCd
                    } else {
                        if (_.isEqual(agencyNm, 'TWSN')) {
                            newKey = sktAgencyCd + sktSubCd + 'N0'
                        } else if (_.isEqual(agencyNm, 'TWSP')) {
                            newKey = sktAgencyCd + sktSubCd + 'P0'
                        } else {
                            newKey = sktAgencyCd + sktSubCd + '00'
                        }
                    }
                    this.dlvDealcoInfo.sknDlvDealcoCd = newKey
                }
            } else {
                this.isDlvDealco = true
                //this.dlvDealcoInfo.sknDlvDealcoCd = ''
            }
        },
        submit() {
            this.showSendDtPopup = true
        },
        gridAddRowBtn: function () {
            this.isDlvDealco = false
            this.dlvDealcoInfo.sknDlvDealcoCd = ''
            this.dlvDealcoInfo.rcvSknDlvDealcoCd = ''
            this.dlvDealcoInfo.sknDelvDealcdNm = ''
            this.dlvDealcoInfo.agencyNm = ''
            this.dlvDealcoInfo.sknDlvSktAgencyCd = ''
            this.dlvDealcoInfo.sknDlvSktSubCd = ''
            this.dlvDealcoInfo.sknDlvPwdNo = ''
            this.dlvDealcoInfo.sknDlvClCd = ''
            this.dlvDealcoInfo.sknDelvZipCd = ''
            this.dlvDealcoInfo.sknDelvAddr = ''
            this.dlvDealcoInfo.sknDelvDtlAddr = ''
            this.dlvDealcoInfo.sknDlvChrgrUserId = ''
            this.dlvDealcoInfo.sknDlvMblPhonNo = ''
            this.dlvDealcoInfo.aplyStaDt = ''
            this.dlvDealcoInfo.useYn = ''
            this.dlvDealcoInfo.sknDlvRmks = ''
            this.dlvDealcoInfo.sknDlvAplyStaDt = ''
            this.dlvDealcoInfo.sknDlvUseYn = ''
            this.$refs.gridDlvDealcoInfo.dataProvider.addRow([])

            let focuscell = this.$refs.gridDlvDealcoInfo.gridView.getCurrent()
            focuscell.dataRow =
                this.$refs.gridDlvDealcoInfo.dataProvider.getRows(0, -1)
                    .length - 1
            this.clickIndex = focuscell.dataRow
            this.$refs.gridDlvDealcoInfo.gridView.setCurrent(focuscell)
        },

        gridChkDelRowBtn: function () {
            this.$refs.gridDlvDealcoInfo.gridView.commit()
            let newRows = []
            let checkRows =
                this.$refs.gridDlvDealcoInfo.gridView.getCheckedRows(true)
            let rows = this.$refs.gridDlvDealcoInfo.dataProvider.getJsonRows()

            if (checkRows.length >= 1) {
                checkRows.forEach((n) => {
                    rows.forEach((v, i) => {
                        if (n === i) {
                            v.__rowState = 'deleted'
                            newRows.push(v)
                        }
                    })
                })

                //this.storeSet('basPrmDealcoDtlDlvListDel', newRows) // 삭제된 항목
                this.$refs.gridDlvDealcoInfo.dataProvider.beginUpdate()
                this.$refs.gridDlvDealcoInfo.dataProvider.removeRows(checkRows)
                this.$refs.gridDlvDealcoInfo.dataProvider.endUpdate()
                this.objCnt -= checkRows.length
            } else {
                this.showTcComAlert('삭제할 대상을 선택해 주세요.')
                return false
            }

            if (this.objCnt < 0) {
                this.isDlvDealco = true
                this.initData()
            }
        },

        //===================== 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getAgencyList() {
            let searchParam = {}
            searchParam['agencyCd'] = this.dlvDealcoInfo.sknDlvSktAgencyCd
            searchParam['agencyNm'] = this.dlvDealcoInfo.agencyNm
            searchParam['agencyTypCd'] = '1'
            basBcoAgencysApi.getAgencyList(searchParam).then((res) => {
                // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (!_.isEmpty(res)) {
                    this.dlvDealcoInfo.sknDlvSktAgencyCd = _.get(
                        res[0],
                        'agencyCd'
                    )
                    this.dlvDealcoInfo.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultAgencyRows = res
                    this.agencySearchParam.sknDlvSktAgencyCd =
                        this.dlvDealcoInfo.sknDlvSktAgencyCd
                    this.agencySearchParam.agencyNm =
                        this.dlvDealcoInfo.agencyNm
                    this.agencySearchParam.agencyTypCd = '1'
                    this.showBcoAgencys = true
                }
            })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.dlvDealcoInfo.agencyNm)) {
                this.getAgencyList()
            } else {
                this.agencySearchParam.sknDlvSktAgencyCd =
                    this.dlvDealcoInfo.sknDlvSktAgencyCd
                this.agencySearchParam.agencyNm = this.dlvDealcoInfo.agencyNm
                this.agencySearchParam.agencyTypCd = '1'
                this.showBcoAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dlvDealcoInfo.agencyNm)) {
                this.showTcComAlert('대리점명을 입력해주세요.')
                return false
            }
            // 대리점 정보 조회
            this.getAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.dlvDealcoInfo.sknDlvSktAgencyCd = ''
            let params = { ...this.dlvDealcoInfo }
            this.storeSet(this.storeKey, params)
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.dlvDealcoInfo.sknDlvSktAgencyCd = _.get(returnData, 'agencyCd')
            this.dlvDealcoInfo.agencyNm = _.get(returnData, 'agencyNm')

            //this.getSknDlvDealcoCd()

            let params = { ...this.dlvDealcoInfo }
            this.storeSet(this.storeKey, params)
        },
        //===================== //대리점팝업관련 methods ================================
        //===================== 우편번호팝업관련 methods ================================
        clickCopy() {
            this.dlvDealcoInfo.sknDelvZipCd = this.strdInfoData.signZipCd
            this.dlvDealcoInfo.sknDelvAddr = this.strdInfoData.signAddr
            this.dlvDealcoInfo.sknDelvDtlAddr = this.strdInfoData.signDtlAddr
            let param = { ...this.dlvDealcoInfo }
            this.storeSet(this.storeKey, param)
        },
        getZipList() {
            let searchParam = {}
            searchParam['streetNm'] = this.dlvDealcoInfo.sknDelvAddr
            basBcoNewZipSrchApi.getNewZipCode(searchParam).then((res) => {
                if (!_.isEmpty(res)) {
                    this.dlvDealcoInfo.sknDelvAddr = _.get(res[0], 'streetNm')
                    this.dlvDealcoInfo.sknDelvDtlAddr = _.get(
                        res[0],
                        'siGunGuBldnNm'
                    )
                } else {
                    this.resultAgencyRows = res
                    this.searchNewZipSrchParam.sknDelvAddr =
                        this.dlvDealcoInfo.sknDelvAddr
                    this.searchNewZipSrchParam.sknDelvDtlAddr =
                        this.dlvDealcoInfo.sknDelvDtlAddr
                    this.showBcoNewZipSrch = true
                }
            })
        },
        // 사용자 TextField 돋보기 Icon 이벤트 처리
        onNewZipSrchClick() {
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultNewZipSrchRows = []
            if (!_.isEmpty(this.dlvDealcoInfo.sknDelvAddr)) {
                // API 호출
                this.getZipList()
            } else {
                this.searchNewZipSrchParam.sknDelvAddr =
                    this.dlvDealcoInfo.sknDelvAddr
                this.searchNewZipSrchParam.sknDelvDtlAddr =
                    this.dlvDealcoInfo.sknDelvDtlAddr

                this.showBcoNewZipSrch = true
            }
        },
        // 주소 TextField 엔터키 이벤트 처리
        onNewZipSrchEnterKey() {
            // 주소 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 주소 빈값이면 알림창 오픈
            if (_.isEmpty(this.dlvDealcoInfo.sknDelvAddr)) {
                this.showTcComAlert('배송지를 입력해주세요.')
                return false
            }
            // 주소 정보 조회
            this.getZipList()
        },
        replaceStreetNm(returnData, path) {
            let street
            if (!_.isEmpty(path)) {
                street = _.get(returnData, path) + ' '
            }
            return street
        },
        // 사용자 팝업 리턴 이벤트 처리
        onNewZipSrchSReturnData(returnData) {
            this.dlvDealcoInfo.sknDelvZipCd = _.get(returnData, 'zipNum')
            this.dlvDealcoInfo.sknDelvAddr = _.get(returnData, 'rdAddr1')
            this.dlvDealcoInfo.sknDelvDtlAddr = _.get(returnData, 'rdAddr2')
            let param = { ...this.dlvDealcoInfo }
            this.storeSet(this.storeKey, param)
        },
        //===================== //사용자영업담당자팝업관련 methods ================================
    },
    watch: {
        basPrmDealcoDtlDlvList1: {
            handler: function (values) {
                if (!_.isEmpty(values) && this.isGridDlvDealcoInfo1) {
                    clearTimeout(this.clickStatus)
                    this.clickStatus = setTimeout(() => {
                        this.initDlvDealcoInfo()
                    }, 200)
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        basPrmDealcoDtlDlvVo: {
            handler: function (values) {
                let detailData = this.dlvDealcoInfo // 데이터 Set

                _.forEach(Object.keys(detailData), (key) => {
                    if (!_.isEmpty(key)) {
                        // 기본정보셋팅
                        let value = values[key]
                        //let isValue = false
                        //let currentDate = moment(new Date()).format('YYYY-MM-DD')
                        if (
                            _.isEqual(value, undefined) ||
                            _.isEqual(value, null) ||
                            _.isEqual(value, '')
                        ) {
                            if (typeof detailData[key] === 'object') {
                                value = []
                            } else {
                                value = ''
                            }
                        } else {
                            //isValue = true
                        }
                        // 필터정보셋팅
                        detailData[key] = value
                    }
                })

                let param = { ...detailData }
                this.storeSet('dlvDealcoInfoDataOld', param)
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
