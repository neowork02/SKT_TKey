<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">서비스대상 일괄변경</p>
                <div class="layerCont">
                    <div class="contBoth">
                        <div class="searchLayer_wrap">
                            <div class="searchform">
                                <div class="formitem div3">
                                    <TCComComboBox
                                        v-model="commCdVal"
                                        labelName="서비스대상"
                                        :itemList="combDataset"
                                        blankItemText="전체"
                                        blankItemValue=""
                                        :objAuth="objAuth"
                                    ></TCComComboBox>
                                </div>
                            </div>
                        </div>
                    </div>
                    <ul class="btn_area pop">
                        <li class="center">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="onConfirm"
                                :objAuth="objAuth"
                            >
                                적용
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="onClose"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton>
                        </li>
                    </ul>
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
export default {
    name: 'BasPrmDirArrvlMgmtPop',
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                console.log('set', value)
                this.$emit('update:dialogShow', value)
            },
        },
    },
    data() {
        return {
            objAuth: {},
            commCdVal: '',
            combDataset: [
                {
                    commCdValNm: '로지스팟',
                    commCdVal: 'L',
                },
                {
                    commCdValNm: '원더스',
                    commCdVal: 'W',
                },
            ],
        }
    },
    created() {},
    mounted() {},
    methods: {
        onConfirm() {
            let copy1 = this.commCdVal
            console.log('onConfirm', copy1)
            this.$emit('confirm', copy1)
            this.onClose()
        },
        /* 팝업 창닫기 */
        onClose() {
            this.activeOpen = false
        },
    },
}
</script>
