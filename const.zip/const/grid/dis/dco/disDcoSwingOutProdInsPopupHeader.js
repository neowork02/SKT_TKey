import { ValueType } from 'realgrid'

export const DisDcoSwingOutProdInsPopup_GRID_HEADER = {
    fields: [
        {
            fieldName: 'inoutSchdDt',
            dataType: ValueType.TEXT, // 출고예정일
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, // 오류내용
        },
        {
            fieldName: 'reflYn',
            dataType: ValueType.TEXT, // 반영여부
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT, // 처리일자
        },
        {
            fieldName: 'opTm',
            dataType: ValueType.TEXT, // if처리일자
        },
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, // 번호
        },
        {
            fieldName: 'rgstSeq',
            dataType: ValueType.TEXT, // 등록순번
        },
        {
            fieldName: 'inoutPlcId',
            dataType: ValueType.TEXT, // 입출고처코드
        },
        {
            fieldName: 'inoutPlcNm',
            dataType: ValueType.TEXT, // 입출고처명
        },
        {
            fieldName: 'inoutCl',
            dataType: ValueType.TEXT, // 입출고구분코드
        },
        {
            fieldName: 'inoutClNm',
            dataType: ValueType.TEXT, // 입출고구분명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, // 제조사명
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, // 상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'toSerNum',
            dataType: ValueType.TEXT, // 종료일련번호
        },
        {
            fieldName: 'ukeyOrgCd',
            dataType: ValueType.TEXT, // SKT조직코드
        },
        {
            fieldName: 'ukeySubOrgCd',
            dataType: ValueType.TEXT, // SKT서브조직코드
        },
        {
            fieldName: 'sknRnpTypCd',
            dataType: ValueType.TEXT, // SKN수불유형코드
        },
        {
            fieldName: 'sknOpClCd',
            dataType: ValueType.TEXT, // SKN처리구분코드
        },
        {
            fieldName: 'errorCl',
            dataType: ValueType.TEXT, // 오류코드
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.NUMBER, // 입고수량
        },
        {
            fieldName: 'outQty',
            dataType: ValueType.NUMBER, // 출고수량
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER, // 단가
        },
        {
            fieldName: 'amt',
            dataType: ValueType.NUMBER, // 금액
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.NUMBER, // 수정횟수
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, // 불량여부
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT, // 재고상태
        },
        {
            fieldName: 'mdlClCd',
            dataType: ValueType.TEXT, // 단말기구분
        },
    ],
    columns: [
        {
            name: 'inoutSchdDt',
            fieldName: 'inoutSchdDt',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고예정일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '250',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류내용',
                showTooltip: false,
            },
        },
        {
            name: 'reflYn',
            fieldName: 'reflYn',
            type: 'data',
            width: '60',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반영여부',
                showTooltip: false,
            },
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            visible: false,
        },
        {
            name: 'opTm',
            fieldName: 'opTm',
            type: 'data',
            visible: false,
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            visible: false,
        },
        {
            name: 'rgstSeq',
            fieldName: 'rgstSeq',
            type: 'data',
            visible: false,
        },
        {
            name: 'inoutPlcId',
            fieldName: 'inoutPlcId',
            type: 'data',
            visible: false,
        },
        {
            name: 'inoutPlcNm',
            fieldName: 'inoutPlcNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'inoutCl',
            fieldName: 'inoutCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'inoutClNm',
            fieldName: 'inoutClNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'toSerNum',
            fieldName: 'toSerNum',
            type: 'data',
            visible: false,
        },
        {
            name: 'ukeyOrgCd',
            fieldName: 'ukeyOrgCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'ukeySubOrgCd',
            fieldName: 'ukeySubOrgCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'sknRnpTypCd',
            fieldName: 'sknRnpTypCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'sknOpClCd',
            fieldName: 'sknOpClCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'errorCl',
            fieldName: 'errorCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            type: 'data',
            visible: false,
        },
        {
            name: 'outQty',
            fieldName: 'outQty',
            type: 'data',
            visible: false,
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            visible: false,
        },
        {
            name: 'amt',
            fieldName: 'amt',
            type: 'data',
            visible: false,
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            type: 'data',
            visible: false,
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            type: 'data',
            visible: false,
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            type: 'data',
            visible: false,
        },
        {
            name: 'mdlClCd',
            fieldName: 'mdlClCd',
            type: 'data',
            visible: false,
        },
    ],
}
