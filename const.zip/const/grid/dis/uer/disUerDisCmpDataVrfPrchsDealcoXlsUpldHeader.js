import { ValueType } from 'realgrid'

// 재고보상 대상 List(T-key+) 그리드
export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'polYm',
            dataType: ValueType.TEXT, // 정산월
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, // 재고보상대상금액
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, // 오류사항
        },
        {
            fieldName: 'flag',
            dataType: ValueType.TEXT, // 구분자
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'polYm',
            fieldName: 'polYm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산월',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'occrAmt',
            fieldName: 'occrAmt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            header: {
                text: '재고보상대상금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '300',
            styleName: 'left-column',
            header: {
                text: '오류사항',
                showTooltip: true,
            },
            renderer: {
                type: 'text',
                showTooltip: true,
            },
        },
        {
            name: 'flag',
            fieldName: 'flag',
            type: 'data',
            visible: false,
        },
    ],
}
