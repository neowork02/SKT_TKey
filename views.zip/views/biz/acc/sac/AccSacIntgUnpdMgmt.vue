<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 통합미수금 관리
 * 설명: 조회, 저장, 삭제, 상세
 * 작성자: P180190
 * 작성일: 2022.11.17
------------------------------------------------>
<template>
    <div class="content">
        <h1>통합미수금 관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onReceipt"
                    >수납대상집계</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onDpst"
                    >입금처리</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="init()"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComDatePicker
                        labelName="입금일자"
                        calType="DP"
                        :eRequired="true"
                        v-model="dpstDt_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        labelName="조직"
                        placeholder="입력해주세요"
                        :eRequired="true"
                        :disabled="false"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :codeVal.sync="reqParam.orgCd"
                        v-model="reqParam.orgNm"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="reqParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="reqParam.dealcoNm"
                        :codeVal.sync="reqParam.dealcoCd"
                        labelName="거래처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="reqParam"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <template>
                <TCRealGridHeader
                    id="gridHeader"
                    ref="gridHeader"
                    gridTitle="입금내역"
                    :gridObj="gridObj"
                    :isExceldown="true"
                    @excelDownBtn="downloadIntgUnpdListExcel"
                >
                </TCRealGridHeader>
                <TCRealGrid
                    id="grid"
                    ref="grid"
                    :editable="true"
                    :fields="view.fields"
                    :columns="view.columns"
                    :styles="gridStyle"
                />
            </template>
        </div>
        <AccSacIntgUnpdMgmtPayTot
            v-if="showIntgUnpdMgmtPayTot"
            :parentParam="popupParams"
            :dialogShow.sync="showIntgUnpdMgmtPayTot"
            @confirm="onAccSacIntgUnpdMgmtPayTotData"
        />
        <AccSacIntgUnpdMgmtDpstProc
            v-if="showIntgUnpdMgmtDpstProc"
            :parentParam="popupParams"
            :dialogShow.sync="showIntgUnpdMgmtDpstProc"
            @confirm="onAccSacIntgUnpdMgmtDpstProcData"
        />
        <AccSacIntgUnpdMgmtDtl
            v-if="showIntgUnpdMgmtDtl"
            :parentParam="popupParams"
            :dialogShow.sync="showIntgUnpdMgmtDtl"
            @confirm="onAccSacIntgUnpdMgmtDtlData"
        />
    </div>
</template>
<script>
import _ from 'lodash'
import { CommonGrid, CommonUtil } from '@/utils'
import intgUnpdMgmtApi from '@/api/biz/acc/sac/AccSacIntgUnpdMgmt'
import { GRID_HEADER } from '@/const/grid/acc/sac/AccSacIntgUnpdMgmtGrid'
import CommonMixin from '@/mixins'
import moment from 'moment'
import AccSacIntgUnpdMgmtPayTot from '@/views/biz/acc/sac/AccSacIntgUnpdMgmtPayTot' //수납 팝업
import AccSacIntgUnpdMgmtDpstProc from '@/views/biz/acc/sac/AccSacIntgUnpdMgmtDpstProc' //입금 팝업
import AccSacIntgUnpdMgmtDtl from '@/views/biz/acc/sac/AccSacIntgUnpdMgmtDtl' //상세 팝업
//====================내부조직팝업(권한)==============================================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================조직별대리점팝업================================================
//====================거래처팝업======================================================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================거래처팝업======================================================
export default {
    name: 'AccSacIntgUnpdMgmt',
    title: '정산 종합 기준관리',
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
        AccSacIntgUnpdMgmtPayTot,
        AccSacIntgUnpdMgmtDpstProc,
        AccSacIntgUnpdMgmtDtl,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,

            //Grid
            objAuth: {},
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},

            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            // 조회 조건 파라미터
            searchFormData: {
                srchStartDpstDt: '',
                srchEndDpstDt: '',
                srchOrgCd: '',
                srchDealcoCd: '',
                srchCoClOrgCd: '',
                srchOrgLvl: '',
            },
            //팝업 파라미터
            popupParams: {
                dpstDt: [],
                baseDt: [],
                orgCd: '',
                orgNm: '',
                dealcoCd: '',
                dealcoNm: '',
                matchKey: '',
                srchOrgCd: '',
            },
            // 조직팝업 요청 파라미터
            reqParam: {
                orgCd: '', // 조직코드
                orgNm: '', //
                orgLvl: '',
                dealcoCd: '',
                dealcoNm: '',
                basDay: '',
                basMth: '',
            },

            // 입금일자
            dpstDt_: [
                moment(new Date()).startOf('month').format('YYYY-MM-DD'),
                moment(new Date()).format('YYYY-MM-DD'),
            ],

            //  내부조직팝업(권한)
            showBcoAuthOrgTrees: false,
            resultAuthOrgTreeRows: [],
            //  내부조직팝업(권한)

            //  내부거래처(권한조직)
            basBcoDealcoShow: false,
            resultDealcoRows: [],
            //  내부거래처(권한조직)

            // 팝업
            showIntgUnpdMgmtPayTot: false, // 수납
            showIntgUnpdMgmtDpstProc: false, // 입금
            showIntgUnpdMgmtDtl: false, // 상세

            //row cnt
            rowCnt: 15,
            nowGridIndex: 0,
        }
    },
    mounted() {
        // 그리드 세팅
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState(false, false, false, true)
        this.gridObj.gridView.setRowIndicator({
            zeroBase: false,
            visible: true,
            displayValue: 'index',
        })

        // 조직 초기화
        if (!_.isEmpty(this.orgInfo['orgCd'])) {
            this.reqParam.orgCd = this.orgInfo.orgCd
            this.reqParam.orgNm = this.orgInfo.orgNm
            this.reqParam.orgLvl = this.orgInfo.orgLvl
            this.searchFormData.srchOrgLvl = this.orgInfo.orgLvl
            this.searchFormData.srchCoClOrgCd = this.orgInfo.orgCdLvl0
        }

        // 그리드 더블클릭
        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            const cIndex = this.gridObj.dataProvider.getRowState(
                clickData.itemIndex
            )
            if (clickData.dataRow != undefined && cIndex == 'none') {
                const rowData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                if (!_.isEmpty(rowData)) {
                    this.popupParams = rowData
                    this.popupParams.srchOrgCd = this.searchFormData.srchOrgCd
                    this.showIntgUnpdMgmtDtl = true
                }
            }
        }
    },
    computed: {},
    watch: {
        // 입금일자 변경 감지
        dpstDt_: {
            handler: function (newArr) {
                if (!_.isEmpty(newArr[0])) {
                    this.searchFormData.srchStartDpstDt = newArr[0].replace(
                        /-/g,
                        ''
                    )
                }
                if (!_.isEmpty(newArr[1])) {
                    this.searchFormData.srchEndDpstDt = newArr[1].replace(
                        /-/g,
                        ''
                    )
                }
                this.reqParam.basDay = moment(
                    this.searchFormData.srchStartDpstDt
                )
                    .endOf('month')
                    .format('YYYYMMDD')
                this.reqParam.basMth = moment(
                    this.searchFormData.srchStartDpstDt
                ).format('YYYYMM')
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },

        // 조직 변경 감지
        'reqParam.orgCd': {
            handler: function (orgCd) {
                if (!_.isEmpty(this.reqParam.orgCd)) {
                    this.searchFormData.srchOrgCd = orgCd
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },

        // 거래처 변경 감지
        'reqParam.dealcoCd': {
            handler: function (dealcoCd) {
                if (!_.isEmpty(this.reqParam.dealcoCd)) {
                    this.searchFormData.srchDealcoCd = dealcoCd
                } else {
                    this.searchFormData.srchDealcoCd = ''
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.gridData = this.gridSetData(this.rowCnt)
    },
    methods: {
        // 초기화
        init() {
            this.gridObj.gridView.commit()

            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.gridObj.gridView.orderBy([]) // 정렬 초기화

            this.gridData.totalPage = 0 // 이전페이지정보 초기화

            // param 초기화
            this.param = {}

            // 조직 초기화
            if (!_.isEmpty(this.orgInfo['orgCd'])) {
                this.reqParam.orgCd = this.orgInfo.orgCd
                this.reqParam.orgNm = this.orgInfo.orgNm
                this.reqParam.orgLvl = this.orgInfo.orgLvl
            }
        },

        gridSetData(rowCnt) {
            return new CommonGrid(0, rowCnt, '', '')
        },

        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        // 수납대상집계 팝업
        onReceipt() {
            console.log('수납집계 팝업 오픈')
            if (_.isEmpty(this.dpstDt_)) {
                this.showTcComAlert('입금일자를 입력해 주세요.')
            }
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 입력해 주세요.')
            }
            this.popupParams = { ...this.reqParam }
            this.popupParams.baseDt = this.dpstDt_
            this.showIntgUnpdMgmtPayTot = true
        },
        onAccSacIntgUnpdMgmtPayTotData(reVal) {
            if (reVal) {
                console.log(reVal)
                this.onSearch()
            }
        },

        // 입금처리 팝업
        onDpst() {
            console.log('입금처리 팝업 오픈')
            var current = this.gridObj.gridView.getCurrent()
            if (current.itemIndex < 0) {
                this.showTcComAlert('데이터를 선택해 주세요.')
                return
            }
            const rowData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.popupParams = rowData
            this.showIntgUnpdMgmtDpstProc = true
        },
        onAccSacIntgUnpdMgmtDpstProcData(reVal) {
            if (reVal) {
                console.log(reVal)
                this.onSearch()
            }
        },

        //================================================
        //조회 ::::::::통합미수금 관리
        //================================================
        onSearch: function () {
            // 입금일자 입력 확인
            if (_.isEmpty(this.dpstDt_)) {
                this.showTcComAlert('입금일자를 입력하십시오.')
                return
            }
            //조회 조직 입력 확인
            if (_.isEmpty(this.searchFormData.srchOrgCd)) {
                this.showTcComAlert('조직을 입력하십시오.')
                return
            }

            intgUnpdMgmtApi.getIntgUnpdMgmt(this.searchFormData).then((res) => {
                if (res) {
                    this.gridObj.setRows(res.gridList)

                    // 조회된 데이터의 length
                    res.gridList.length
                    console.log(
                        ':::::::총 건수' + res.gridList.length + '건:::::::'
                    )
                    // 고정
                    this.gridIndex = this.gridObj.dataProvider.getRowCount()

                    // 동적으로 변경될 rowcnt
                    this.nowGridIndex = this.gridObj.dataProvider.getRowCount()
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },
        //================================================
        // EXCEL DOWNLOAD:::::::::입금내역
        //================================================
        downloadIntgUnpdListExcel: function () {
            intgUnpdMgmtApi.getIntgUnpdListExcel(this.searchFormData)
            console.log('엑셀다운로드 :::::::')
        },

        onAccSacIntgUnpdMgmtDtlData(reVal) {
            if (reVal) {
                console.log(reVal)
                this.onSearch()
            }
        },

        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            console.log('this.reqParam::::', this.reqParam)
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.reqParam)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res) {
                        if (res.length === 1) {
                            this.reqParam.orgCd = _.get(res[0], 'orgCd')
                            this.reqParam.orgNm = _.get(res[0], 'orgNm')
                            this.reqParam.srchOrgLvl = _.get(res[0], 'vLevel')
                            this.reqParam.srchCoClOrgCd = _.get(
                                res[0],
                                'orgCdLvl0'
                            )
                            this.reqParam.orgTree = _.get(res[0], 'orgTree')
                        } else {
                            this.resultAuthOrgTreeRows = res
                            this.showBcoAuthOrgTrees = true
                        }
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            }
            this.showBcoAuthOrgTrees = true
        },

        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgNm)) {
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.orgCd = ''
            this.reqParam.srchOrgLvl = ''
            this.reqParam.srchCoClOrgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.srchOrgLvl = _.get(returnData, 'orgLvl')
            this.reqParam.srchCoClOrgCd = _.get(returnData, 'orgCdLvl0')
        },

        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.reqParam).then((res) => {
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.basBcoDealcoShow = true
                }
            })
        },
        //  내부거래처(권한조직))
        onDealcoIconClick() {
            this.resultDealcoRows = []
            if (!_.isEmpty(this.reqParam.dealcoNm)) {
                this.getDealcosList()
            } else {
                this.basBcoDealcoShow = true
            }
        },

        onDealcoEnterKey() {
            this.resultDealcoRows = []
            if (!_.isEmpty(this.reqParam.dealcoNm)) {
                this.getDealcosList()
            } else {
                // 팝업오픈
                this.basBcoDealcoShow = true
            }
        },

        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.reqParam.dealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            this.reqParam.dealcoCd = _.get(returnData, 'dealcoCd')
            this.reqParam.dealcoNm = _.get(returnData, 'dealcoNm')
        },
    },
}
</script>
