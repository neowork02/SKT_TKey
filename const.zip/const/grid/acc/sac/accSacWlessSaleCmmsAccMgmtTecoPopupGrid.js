import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = [
    {
        fieldName: 'accDealcoNm',
        header: { text: '정산상태' },
        width: '150',
    },
    {
        fieldName: 'fixYnNm',
        header: { text: '확정상태' },
        width: '150',
    },
    {
        fieldName: 'accFixYm',
        header: { text: '확정정산월' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMM',
        columnDatetimeFormat: 'yyyy-MM',
    },
    {
        fieldName: 'aplyDt',
        header: { text: '반영일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'cnslDt',
        header: { text: '상담일자' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'cnslId',
        header: { text: '상담ID' },
        width: '150',
    },
    {
        fieldName: 'fieldJudgeYn',
        header: { text: '현장감정' },
        width: '150',
    },
    {
        fieldName: 'dedtTypNm',
        header: { text: '공제유형' },
        width: '150',
    },
    {
        fieldName: 'svcMgmtNum',
        header: { text: '서비스관리번호' },
        width: '150',
    },
    {
        fieldName: 'cntrctMgmtNo',
        header: { text: '계약관리번호' },
        width: '150',
    },
    {
        fieldName: 'custNmMask',
        header: { text: '고객명' },
        width: '150',
    },
    {
        fieldName: 'prodCd',
        header: { text: '모델코드' },
        width: '150',
        group: 'eqp',
    },
    {
        fieldName: 'prodNm',
        header: { text: '모델' },
        width: '150',
        group: 'eqp',
    },
    {
        fieldName: 'serNum',
        header: { text: '일련번호' },
        width: '150',
        group: 'eqp',
    },
    {
        fieldName: 'tecoStGrade',
        header: { text: '등급' },
        width: '150',
    },
    {
        fieldName: 'ecoDcAmt',
        header: { text: 'ECO할인' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'reJudgeGrd',
        header: { text: '재감정등급' },
        width: '150',
    },
    {
        fieldName: 'reJudgeAmt',
        header: { text: '재감정금액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'reJudgeComment',
        header: { text: '감정내역' },
        width: '150',
    },
    {
        fieldName: 'reJudgeDtl',
        header: { text: '감정상세' },
        width: '150',
    },
    {
        fieldName: 'ppayReproYn',
        header: { text: '귀책' },
        width: '150',
    },
    {
        fieldName: 'ppayAssetAmt',
        header: { text: '자산가액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
        group: 'preAsset',
    },
    {
        fieldName: 'ppayAgencyFalutAmt',
        header: { text: '대리점오류' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
        group: 'preAsset',
    },
    {
        fieldName: 'ppayRpayAmt',
        header: { text: '환수' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
        group: 'preAsset',
    },
    {
        fieldName: 'ppayCostOpAmt',
        header: { text: '비용처리' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
        group: 'preAsset',
    },
    {
        fieldName: 'assetAmt',
        header: { text: '자산가액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
        group: 'preSale',
    },
    {
        fieldName: 'agnErrAmt',
        header: { text: '대리점오류' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
        group: 'preSale',
    },
    {
        fieldName: 'costPrsvAmt',
        header: { text: '비용보전' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
        group: 'preSale',
    },
    {
        fieldName: 'ddctAmt',
        header: { text: '환수' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
        group: 'preSale',
    },
    {
        fieldName: 'totAccAmt',
        header: { text: '총정산액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'fixAdjtAmt',
        header: { text: '확정금액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'fixDtm',
        header: { text: '확정일자' },
        width: '150',
        datetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'fixOpUserId',
        type: 'data',
        header: { text: '확정처리자' },
        width: '150',
    },
    {
        fieldName: 'fieldJudeDt',
        header: { text: '현장감정일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'rgstUserId',
        header: { text: '등록자ID' },
        width: '150',
    },
    {
        fieldName: 'rgstNm',
        header: { text: '등록자' },
        width: '150',
    },
    {
        fieldName: 'chgDt',
        header: { text: '변경일자' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'svcChgTypNm',
        header: { text: '서비스변경' },
        width: '150',
    },
    {
        fieldName: 'svcChgRsn',
        header: { text: '서비스변경사유' },
        width: '150',
    },
    {
        fieldName: 'mktNm',
        header: { text: '본부조직' },
        width: '150',
    },
    {
        fieldName: 'cntrNm',
        header: { text: '센터조직' },
        width: '150',
    },
    {
        fieldName: 'agencyCd',
        header: { text: 'D코드' },
        width: '150',
    },
    {
        fieldName: 'sktSubCd',
        header: { text: 'SUB코드' },
        width: '150',
    },
    {
        fieldName: 'agencyNm',
        header: { text: '대리점명' },
        width: '150',
    },
    {
        fieldName: 'agencyCd2',
        header: { text: '대리점코드' },
        width: '150',
    },
    {
        fieldName: 'agencyNm2',
        header: { text: 'Swing대리점명' },
        width: '150',
    },
    {
        fieldName: 'bizNo',
        header: { text: '사업자번호' },
        width: '150',
    },
    {
        fieldName: 'bizNm',
        header: { text: '법인명' },
        width: '150',
    },
]

const GRID_META_GROUP = {
    eqp: {
        direction: 'horizontal',
        header: { text: '단말기' },
        items: [],
    },
    preAsset: {
        direction: 'horizontal',
        header: { text: '선납/계좌' },
        items: [],
    },
    preSale: {
        direction: 'horizontal',
        header: { text: '선할인' },
        items: [],
    },
}

const GRID_HEADER = {}
GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = gridMetaUtil.adjustLayout(GRID_META, GRID_META_GROUP)

export { GRID_HEADER }
