<template>
    <div class="header">
        <!-- header -->
        <div class="inner_header">
            <div class="logoWrap">
                <h1 class="logo">
                    <a
                        href="#"
                        @click.prevent="$router.push('/main').catch(() => {})"
                        >{{ this.CONSTANTS.SYSTEM_NM }}
                    </a>
                    <span class="color-red2"> {{ this.nodeEnv }} </span>
                </h1>
            </div>

            <div class="search">
                <!-- <input
                    type="text"
                    class="searchType"
                    title=""
                    value="통합검색"
                />
                <span class="icon">
                    <a href="#" class="btn_search"
                        ><i class="el-icon2-search"></i
                    ></a>
                </span> -->
                <!-- selectBox area -->
                <div class="hserachWrap">
                    <div class="selectBox">
                        <v-select
                            v-model="quickVal"
                            :items="items2"
                            item-text="commCdValNm"
                            item-value="commCdVal"
                            outlined
                            dense
                            color="basiccont"
                            class="headerInput"
                            append-icon="mdi-chevron-down"
                            @change="mQuickChange"
                        >
                            <!-- <template v-slot:append>
                               <v-icon class="headerInput">
                                    mdi-chevron-down
                                </v-icon> -->
                            <!-- <v-hover v-slot="{ hover }">
                                    <v-icon :color="hover ? 'gray' : 'primary'"
                                        >mdi-chevron-up</v-icon
                                    >
                                </v-hover>
                            </template> -->
                        </v-select>
                    </div>
                    <!-- //selectBox area -->
                    <!-- input + button area -->
                    <div class="schBox">
                        <v-text-field
                            outlined
                            dense
                            class="headerSelectbox"
                            placeholder="검색어를 입력해주세요"
                            v-model="searchQuickParam.menuNm"
                            @keydown.enter="mQuickClick"
                        ></v-text-field>
                        <button type="button" class="" @click="mQuickClick">
                            <span>검색</span>
                        </button>
                    </div>
                    <!-- 쿽메뉴검색팝업 -->
                    <BasAdmQuickSearchMenuPopup
                        v-if="showQuickSearchMenu"
                        :parentParam="searchQuickParam"
                        :dialogShow.sync="showQuickSearchMenu"
                        @confirm="onCommCdSrchReturnData"
                    />
                    <!-- //input + button area -->
                </div>
            </div>

            <div class="help">
                <div class="tooltip_area">
                    <span class="funcTip" title="도움말"
                        ><a @click.prevent="onHelpClick">도움말</a></span
                    >
                    <HelpPopup v-if="showHelp" :dialogShow.sync="showHelp" />
                </div>
            </div>

            <div class="gnb">
                <ul>
                    <li v-for="item in menus" v-bind:key="item.menuNm">
                        <a
                            @click.prevent="
                                topMenuClicked(item.menuGrpCd, item.menuUrl)
                            "
                            >{{ item.menuNm }}</a
                        >
                    </li>

                    <!-- <li>
                        <a
                            href="#"
                            @click.prevent="
                                $router
                                    .push('/pages/basic/dashboardSal')
                                    .catch(() => {})
                            "
                            >판매</a
                        >
                    </li>
                    <li>
                        <a
                            href="#"
                            @click.prevent="
                                $router
                                    .push('/pages/basic/dashboardDis')
                                    .catch(() => {})
                            "
                            >재고</a
                        >
                    </li>
                    <li>
                        <a
                            href="#"
                            @click.prevent="
                                $router
                                    .push('/pages/basic/dashboardRm')
                                    .catch(() => {})
                            "
                            >RM
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            @click.prevent="
                                $router
                                    .push('/pages/basic/dashboardPol')
                                    .catch(() => {})
                            "
                            >정책</a
                        >
                    </li>
                    <li>
                        <a
                            href="#"
                            @click.prevent="
                                $router
                                    .push('/pages/basic/dashboardSac')
                                    .catch(() => {})
                            "
                            >판매회계</a
                        >
                    </li>
                    <li>
                        <a
                            href="#"
                            @click.prevent="
                                $router
                                    .push('/pages/basic/dashboardBas')
                                    .catch(() => {})
                            "
                        >
                            기준정보
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            @click.prevent="
                                $router
                                    .push('/pages/basic/dashboardAcc')
                                    .catch(() => {})
                            "
                        >
                            정산
                        </a>
                    </li>
                    <li>
                        <a
                            href="#"
                            @click.prevent="
                                $router
                                    .push('/pages/basic/dashboardStore')
                                    .catch(() => {})
                            "
                            >판매점관리
                        </a>
                    </li> -->
                </ul>
            </div>
        </div>
        <!--div class="sitemap">
            <div class="sitemap_header">
                <button
                type="button"
                class="sitemap_close"
                @click.prevent="$router.push('/').catch(() => {})"
                >
                <span class="offscreen">Header1</span>
                </button>
                <button
                type="button"
                class="sitemap_close"
                @click.prevent="$router.push('/home2').catch(() => {})"
                >
                <span class="offscreen">Home2</span>
                </button>
                <button
                type="button"
                class="sitemap_close"
                @click.prevent="fnSitemap(false)"
                >
                <span class="offscreen">Header3</span>
                </button>
            </div>
        </div-->
        <!-- header // -->
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import _ from 'lodash'
//====================퀵서치메뉴검색====================
import BasAdmQuickSearchMenuPopup from '@/components/common/BasAdmQuickSearchMenuPopup'
import commonApi from '@/api/common/commonCode'
//====================//퀵서치메뉴검색=============
import HelpPopup from '@/components/common/HelpPopup'
export default {
    name: 'Header',
    mixins: [CommonMixin],
    components: { BasAdmQuickSearchMenuPopup, HelpPopup },
    data() {
        return {
            nodeEnv: '',
            icon: true,
            menusAll: [],
            menus: [],
            quickVal: '100003000', //메뉴검색고정
            items: ['일련번호', 'Option1', 'Option2', 'Option3'],
            items2: [],
            //퀵서치
            searchQuickParam: {
                type: Object,
                default: () => {},
                required: false,
            },
            //====================퀵서치 메뉴 검색 관련====================
            showQuickSearchMenu: false, // 팝업 오픈 여부
            //====================//퀵서치 메뉴 검색 ==================
            pageSh: '#',
            showHelp: false,
        }
    },
    computed: {},
    created() {
        //Dev / STG / PRD 구분
        switch (process.env.NODE_ENV) {
            case 'development':
                this.nodeEnv = 'Local'
                break
            case 'local':
                this.nodeEnv = 'Local'
                break
            case 'dev':
                this.nodeEnv = 'Dev'
                break
            case 'stg':
                this.nodeEnv = 'Stg'
                break
            default:
                break
        }
        this.init()
    },
    mounted() {
        _.forEach(this.menuInfo, (item) => {
            // 100 재고관리
            // 200 정책관리
            // 300 판매관리
            // 400 정산관리
            // 500 기준정보
            // 600 Admin
            // 700 RM관리
            // 800 판매점관리
            // 900 판매회계
            if (item.topMenuYn == 'Y') {
                this.menus.push(item)
            }
        })
    },

    methods: {
        init() {
            //퀵서치 SELECTBOX
            this.getCommonQuickList('QUICK_MENU_NEW')
        },
        //상단메뉴 클릭이벤트
        topMenuClicked(menuGrpCd, url) {
            //상단메뉴 클릭시 페이징 이동및 Left메뉴 셋팅필요
            this.$router
                .push({
                    name: url,
                    params: { menuGrpCd: menuGrpCd },
                })
                .catch(() => {})
        },

        // 퀵서치 공통코드 API
        getCommCodeList(codeId) {
            commonApi.getCommonCodeListById(codeId).then((res) => {
                //console.log(' === res', res[0].commCdValNm)

                for (let i = 0; i < res.length; i++) {
                    this.items2.push(res[i])
                }
            })
        },
        // 퀵서치 공통코드 API
        getCommonQuickList(codeId) {
            commonApi.getCommonQuickList(codeId).then((res) => {
                //console.log(' === res', res[0].commCdValNm)

                for (let i = 0; i < res.length; i++) {
                    this.items2.push(res[i])
                }
            })
        },

        mQuickChange() {
            this.pageSh = '#'
        },
        //퀵서치
        mQuickClick() {
            //alert(this.$router.currentRoute.fullPath)
            console.log(this.quickVal)
            //console.log('#####===>', this.pageSh)
            if (this.pageSh.length == 20) {
                this.pageSh = '#'
            } else {
                this.pageSh = this.pageSh + '#'
            }
            if ('100000192' == this.quickVal) {
                //일련번호검색 주석.(일련번호팝업검색)
                //this.showMainQuickSerialSend = true

                if (_.isEmpty(this.searchQuickParam.menuNm)) {
                    this.showTcComAlert('일련번호를 입력하세요.')
                    return
                }

                this.$router.push({
                    name: '/dis/dsm/DisDsmProdHstBrws',
                    hash: this.pageSh,
                    params: { search: this.searchQuickParam.menuNm },
                })
            } else if ('100003000' == this.quickVal) {
                //퀵서치 메뉴검색
                if (_.isEmpty(this.searchQuickParam.menuNm)) {
                    this.showTcComAlert('메뉴명을 입력하세요.')
                    return
                }

                this.showQuickSearchMenu = true // 팝업 오픈 여부
            } else if ('100000216' == this.quickVal) {
                //개통이력조회

                if (_.isEmpty(this.searchQuickParam.menuNm)) {
                    this.showTcComAlert('개통이력 검색어를 입력하세요.')
                    return
                }

                this.$router.push({
                    name: '/sal/sco/wlessSaleHst/SalScoWlessSaleHstMt',
                    hash: this.pageSh,
                    params: { svcMgmtNum: this.searchQuickParam.menuNm },
                })
            } else if ('100003743' == this.quickVal) {
                //유선개통이력

                if (_.isEmpty(this.searchQuickParam.menuNm)) {
                    this.showTcComAlert('유선개통이력 검색어를 입력하세요.')
                    return
                }

                this.$router.push({
                    name: '/tkp/sal/TkpSalWireSaleMgmtBrws',
                    hash: this.pageSh,
                    params: { svcMgmtNum: this.searchQuickParam.menuNm },
                })
            }
        },
        //Quick메뉴검색리턴
        onCommCdSrchReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            //let maxMenu = _.get(retrunData, 'maxMenu')
            //let menuNm = _.get(retrunData, 'menuNm')
            //let menuNo = _.get(retrunData, 'menuNo')
            let menuUrl = _.get(retrunData, 'menuUrl')

            this.$router.push({
                name: menuUrl,
                // params: { search: this.searchQuickParam.menuNm },
            })
        },

        // 도움말
        onHelpClick() {
            this.showHelp = true
        },
    },
}
</script>

<style></style>
