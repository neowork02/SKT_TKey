import { ValueType } from 'realgrid'

export let GRID_PROPERTYINFO = {
    fields: [
        {
            fieldName: 'no', // 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'swgMgmtNo', // 관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'swgPolCd', // T정책코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'swgPolPagerNm', // 정책서명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'swgPolNm', // 정책명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'swgPolTyp', // 정책유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'swgPolIdxTyp', // 정책지표유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effStaDt', // 유효시작일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effEndDt', // 유효종료일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn', // 사용여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'no',
            fieldName: 'no',
            type: 'data',
            width: '40',
            header: {
                text: '순번',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'swgMgmtNo',
            fieldName: 'swgMgmtNo',
            type: 'data',
            width: '70',
            header: {
                text: '관리번호',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'swgPolCd',
            fieldName: 'swgPolCd',
            type: 'data',
            width: '120',
            header: {
                text: 'T정책코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'swgPolPagerNm',
            fieldName: 'swgPolPagerNm',
            type: 'data',
            width: '160',
            header: {
                text: '정책서명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'swgPolNm',
            fieldName: 'swgPolNm',
            type: 'data',
            width: '140',
            header: {
                text: '정책명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'swgPolIdxTyp',
            fieldName: 'swgPolIdxTyp',
            type: 'data',
            width: '90',
            header: {
                text: '정책지표유형',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'swgPolTyp',
            fieldName: 'swgPolTyp',
            type: 'data',
            width: '140',
            header: {
                text: '정책유형',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
            editable: false,
        },
        {
            name: 'effStaDt',
            fieldName: 'effStaDt',
            type: 'data',
            width: '80',
            header: {
                text: '유효시작일',
                showTooltip: false,
            },
            styleName: 'left-column',
            datetimeFormat: 'yyyy-MM-dd',
            editable: false,
        },
        {
            name: 'effEndDt',
            fieldName: 'effEndDt',
            type: 'data',
            width: '80',
            header: {
                text: '유효종료일',
                showTooltip: false,
            },
            styleName: 'left-column',
            datetimeFormat: 'yyyy-MM-dd',
            editable: false,
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            width: '60',
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '90',
            header: {
                text: '처리일',
                showTooltip: false,
            },
            editable: false,
            styleName: 'left-column',
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            width: '80',
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
            editable: false,
            styleName: 'left-column',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '110',
            header: {
                text: '처리자',
                showTooltip: false,
            },
            editable: false,
            styleName: 'left-column',
        },
    ],

    layout: [
        'no', // 순번
        'swgMgmtNo', // 관리번호
        'swgPolCd', // T정책코드
        'swgPolPagerNm', // 정책서명
        'swgPolNm', // 정책명
        'swgPolIdxTyp', // 정책지표유형
        'swgPolTyp', // 정책유형
        'effStaDt', // 유효시작일
        'effEndDt', // 유효종료일
        'useYn', // 사용여부
        'useYn', // 사용여부
        'modDtm',
        'modUserId',
        'modUserNm',
    ],

    // grouping: ['saleWght'],
}
