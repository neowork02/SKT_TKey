'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: 'ukeyProcDt',
        editable: false,
        header: { text: '처리일자' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'ukeyAgencyCd',
        editable: false,
        header: { text: '대리점코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeyAgencyNm',
        editable: false,
        header: { text: '대리점명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeySubCd',
        editable: false,
        header: { text: '서브점코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeySubNm',
        editable: false,
        header: { text: '서브점명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeyChannelCd',
        editable: false,
        header: { text: '판매점코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'svcMgmtNum',
        editable: false,
        header: { text: '서비스관리번호' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeyPayClNm',
        editable: false,
        header: { text: '수납구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeySettlWayNm',
        editable: false,
        header: { text: '결제수단' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeyPayObjAmt',
        editable: false,
        header: { text: '수납대상금액' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'ifOpStNm',
        editable: false,
        header: { text: 'IF처리상태' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 300px`

const MOCK_DATA = {
    resultGridDto: {
        gridList: [],
        pagingDto: {
            pageSize: 10,
            pageNum: 1,
            totalPageCnt: 31,
            totalDataCnt: 310,
        },
    },
}

export { GRID_HEADER, MOCK_DATA }
