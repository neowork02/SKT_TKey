/*****************************************
 * 업무그룹명: 판매관리
 * 서브업무명: 소매매출수납현황
 * 설명: 판매관리-소매매출수납현황-소매매출수납현황관리 그리드 헤더
 * 작성자: P179234
 * 작성일: 2022.07.04
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, //조직트리
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, //영업팀코드
        },
        {
            fieldName: 'lvOrgNm2',
            dataType: ValueType.TEXT, //영업팀
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT, //영업센터코드
        },
        {
            fieldName: 'lvOrgNm3',
            dataType: ValueType.TEXT, //영업센터
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, //정산처코드
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT, //정산처
        },
        {
            fieldName: 'saleDealcoCd',
            dataType: ValueType.TEXT, //판매처
        },
        {
            fieldName: 'saleDealcoNm',
            dataType: ValueType.TEXT, //판매처명
        },
        {
            fieldName: 'dealCoClNm',
            dataType: ValueType.TEXT, //거래처구분
        },
        {
            fieldName: 'payCashAmt',
            dataType: ValueType.NUMBER, //현금
        },
        {
            fieldName: 'payPosAmt',
            dataType: ValueType.NUMBER, //POS
        },
        {
            fieldName: 'payPgAmt',
            dataType: ValueType.NUMBER, //PG사
        },
        {
            fieldName: 'payCrdtAmt',
            dataType: ValueType.NUMBER, //카드
        },
        {
            fieldName: 'payBondAmt',
            dataType: ValueType.NUMBER, //상품권
        },
        {
            fieldName: 'payRpayAmt',
            dataType: ValueType.NUMBER, //기타수납
        },
        {
            fieldName: 'paySumAmt',
            dataType: ValueType.NUMBER, //소계
        },
        {
            fieldName: 'notCnt',
            dataType: ValueType.TEXT, //미처리 건수
        },
        {
            fieldName: 'tnotPayAmt',
            dataType: ValueType.NUMBER, //T판매
        },
        {
            fieldName: 'nnotPayAmt',
            dataType: ValueType.NUMBER, //일반상품판매
        },
        {
            fieldName: 'notPayAmt',
            dataType: ValueType.NUMBER, //소계
        },
    ],
    columns: [
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',

            styleName: 'center-column',
            header: '매장코드',
        },
        {
            name: 'lvOrgCd2',
            fieldName: 'lvOrgCd2',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '영업팀코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'lvOrgNm2',
            fieldName: 'lvOrgNm2',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '영업팀',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'lvOrgCd3',
            fieldName: 'lvOrgCd3',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '영업센터코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'lvOrgNm3',
            fieldName: 'lvOrgNm3',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '영업센터',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '정산처',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '판매처',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '판매처명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealCoClNm',
            fieldName: 'dealCoClNm',
            type: 'data',
            styleName: 'center-column',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payCashAmt',
            fieldName: 'payCashAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '현금',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
        },
        {
            name: 'payPosAmt',
            fieldName: 'payPosAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'POS',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payPgAmt',
            fieldName: 'payPgAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'PG사',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payCrdtAmt',
            fieldName: 'payCrdtAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '카드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payBondAmt',
            fieldName: 'payBondAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '상품권',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payRpayAmt',
            fieldName: 'payRpayAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '기타수납',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'paySumAmt',
            fieldName: 'paySumAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '소계',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'notCnt',
            fieldName: 'notCnt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '미처리 건수',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
        },
        {
            name: 'tnotPayAmt',
            fieldName: 'tnotPayAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: 'T판매',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'nnotPayAmt',
            fieldName: 'nnotPayAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '일반상품판매',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'notPayAmt',
            fieldName: 'notPayAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '소계',
                showTooltip: false,
            },
            editable: false,
        },
    ],
    layout: [
        'treeOrgNm',
        'sktCd',
        'accDealcoCd',
        'accDealcoNm',
        'saleDealcoCd',
        'saleDealcoNm',
        'dealCoClNm',
        {
            name: 'culumn1',
            direction: 'horizontal',
            items: [
                'payCashAmt',
                'payPosAmt',
                'payPgAmt',
                'payCrdtAmt',
                'payBondAmt',
                'payRpayAmt',
                'paySumAmt',
            ],
            header: { text: '수납금액' },
        },
        {
            name: 'culumn2',
            direction: 'horizontal',
            items: ['notCnt', 'tnotPayAmt', 'nnotPayAmt', 'notPayAmt'],
            header: { text: '미수납현황' },
        },
    ],
}
