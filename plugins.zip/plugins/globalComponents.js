import Vue from 'vue'
import TCComAlert from '@/components/TCComAlert.vue'
import TCComBaseAlert from '@/components/TCComBaseAlert.vue'
import TCComConfirm from '@/components/TCComConfirm.vue'
import TCComButton from '@/components/TCComButton.vue'
import TCComCheckBox from '@/components/TCComCheckBox.vue'
import TCComNoLabelCheckBox from '@/components/TCComNoLabelCheckBox.vue'
import TCComInputCheckBox from '@/components/TCComInputCheckBox.vue'
import TCComComboBox from '@/components/TCComComboBox.vue'
import TCComNoLabelComboBox from '@/components/TCComNoLabelComboBox.vue'
import TCComMultiComboBox from '@/components/TCComMultiComboBox.vue'
import TCComNoLabelMultiComboBox from '@/components/TCComNoLabelMultiComboBox.vue'
import TCComDatePicker from '@/components/TCComDatePicker.vue'
import TCComDialog from '@/components/TCComDialog.vue'
import TCComInput from '@/components/TCComInput.vue'
import TCComNoLabelInput from '@/components/TCComNoLabelInput.vue'
import TCComInputSearch from '@/components/TCComInputSearch.vue'
import TCComInputSearchText from '@/components/TCComInputSearchText.vue'
import TCComLoadingBar from '@/components/TCComLoadingBar.vue'
import TCComRadioBox from '@/components/TCComRadioBox.vue'
import TCComNoLabelRadioBox from '@/components/TCComNoLabelRadioBox.vue'
import TCComLabel from '@/components/TCComLabel.vue'
import TCComSwitch from '@/components/TCComSwitch.vue'
import TCComTab from '@/components/TCComTab.vue'
import TCComTextArea from '@/components/TCComTextArea.vue'
import TCComNoLabelTextArea from '@/components/TCComNoLabelTextArea.vue'
import TCComTextField from '@/components/TCComTextField.vue'
import TCComTreeview from '@/components/TCComTreeview.vue'
import TCRealGrid from '@/components/TCRealGrid.vue'
import TCRealGridHeader from '@/components/TCRealGridHeader.vue'
import TCComPaging from '@/components/TCComPaging.vue'
import TCComExceptionDialog from '@/components/TCComExceptionDialog.vue'
import TCComFileInput from '@/components/TCComFileInput.vue'
import TCHighcharts from '@/components/TCHighcharts.vue'
import TCComSnackbar from '@/components/TCComSnackbar.vue'

Vue.component('TCComAlert', TCComAlert)
Vue.component('TCComBaseAlert', TCComBaseAlert)
Vue.component('TCComConfirm', TCComConfirm)
Vue.component('TCComButton', TCComButton)
Vue.component('TCComCheckBox', TCComCheckBox)
Vue.component('TCComNoLabelCheckBox', TCComNoLabelCheckBox)
Vue.component('TCComInputCheckBox', TCComInputCheckBox)
Vue.component('TCComComboBox', TCComComboBox)
Vue.component('TCComNoLabelComboBox', TCComNoLabelComboBox)
Vue.component('TCComMultiComboBox', TCComMultiComboBox)
Vue.component('TCComNoLabelMultiComboBox', TCComNoLabelMultiComboBox)
Vue.component('TCComDatePicker', TCComDatePicker)
Vue.component('TCComDialog', TCComDialog)
Vue.component('TCComInput', TCComInput)
Vue.component('TCComNoLabelInput', TCComNoLabelInput)
Vue.component('TCComInputSearch', TCComInputSearch)
Vue.component('TCComInputSearchText', TCComInputSearchText)
Vue.component('TCComLabel', TCComLabel)
Vue.component('TCComLoadingBar', TCComLoadingBar)
Vue.component('TCComRadioBox', TCComRadioBox)
Vue.component('TCComNoLabelRadioBox', TCComNoLabelRadioBox)
Vue.component('TCComSwitch', TCComSwitch)
Vue.component('TCComTab', TCComTab)
Vue.component('TCComTextArea', TCComTextArea)
Vue.component('TCComNoLabelTextArea', TCComNoLabelTextArea)
Vue.component('TCComTextField', TCComTextField)
Vue.component('TCComTreeview', TCComTreeview)
Vue.component('TCRealGrid', TCRealGrid)
Vue.component('TCRealGridHeader', TCRealGridHeader)
Vue.component('TCComPaging', TCComPaging)
Vue.component('TCComExceptionDialog', TCComExceptionDialog)
Vue.component('TCComFileInput', TCComFileInput)
Vue.component('TCHighcharts', TCHighcharts)
Vue.component('TCComSnackbar', TCComSnackbar)
