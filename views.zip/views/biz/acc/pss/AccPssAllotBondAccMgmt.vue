<template>
    <div class="content">
        <h1>할부채권정산관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="ApproveAccPss"
                    >승인요청</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="fInit"
                    :objAuth="objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="loadData"
                    :objAuth="objAuth"
                    >조회</TCComButton
                >
                <!-- <v-btn
                    color="btn2"
                    class="btn_ty01"
                    @click="fInit"
                    :objAuth="objAuth"
                    >초기화</v-btn
                >
                <v-btn
                    color="btn2"
                    class="btn_ty01"
                    @click="loadData"
                    :objAuth="objAuth"
                    >조회</v-btn
                > -->
            </li>
        </ul>
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        v-model="searchFormData.accYm"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchFormData.sktAgencyNm"
                        :codeVal.sync="searchFormData.sktAgencyCd"
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAgencyEnterKey"
                        @appendIconClick="onAgencyIconClick"
                        @input="onAgencyInput"
                    />
                    <BasBcoAgencysPopup
                        v-if="showBcoAgencys"
                        :parentParam="searchAgency"
                        :rows="resultAgencyRows"
                        :dialogShow.sync="showBcoAgencys"
                        @confirm="onAgencyReturnData"
                    />
                </div>
                <div class="formitem div4"></div>
                <div class="formitem div4"></div>
            </div>
        </div>
        <!-- //Search_div -->

        <!-- SubTit -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="할부채권 정산목록"
                :isExceldown="true"
                :gridObj="gridObj"
                @excelDownBtn="excelDown"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
        </div>

        <!-- //popup 영역 -->
        <AccPssAllotBondAccRgst
            v-if="showPopupOrg === true"
            ref="popup"
            :dialogShow.sync="showPopupOrg"
            :popupParams.sync="popupParams"
            @close="loadData"
        />
        <!-- //popup 영역 -->
    </div>
</template>
<style scoped>
/* .grid {
    height: ;
} */
</style>

<script>
import pssApi from '@/api/biz/acc/pss'
import moment from 'moment'
import _ from 'lodash'
import AccPssAllotBondAccRgst from '@/views/biz/acc/pss/AccPssAllotBondAccRgst'
import { CommonUtil } from '@/utils'
import { GRID_HEADER } from '@/const/grid/acc/pss/AccPssAllotBondAccMgmtGrid'

//  세션정보
import CommonMixin from '@/mixins'

//  대리점팝업
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
//  대리점팝업

export default {
    name: 'AccPssAllotBondAccMgmt',
    mixins: [CommonMixin],
    components: {
        AccPssAllotBondAccRgst,
        BasBcoAgencysPopup,
    },
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,
            /* gridData: this.GridSetData(), */
            gridHeaderObj: {},
            list: [],

            //승인요청
            objAuth: {},
            gridObj: {},

            //요청 파라미터
            searchFormData: {
                accYm: moment(new Date()).format('YYYY-MM'),
                sktAgencyCd: '',
                sktAgencyNm: '',
                accDealcoCd: '',
                loginUserCd: '',
                checkedRows: [],
                erpFixYn: '',
                fixYn: '',
                aprvStatCd: '',
            },
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
            /* popup영역 */
            searchForms: {},
            popupParams: {},
            showPopupOrg: false,

            //  대리점팝업
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            searchAgency: {},
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //  대리점팝업
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, true, true)
        // 그리드 셀 클릭 팝업 이벤트
        this.$refs.grid1.gridView.onCellDblClicked = (grid, clickData) => {
            this.grdListOnCellDblClick(clickData.dataRow)
        }

        this.searchFormData.loginUserCd = this.userInfo.userCd
    },
    methods: {
        // 초기화
        fInit: function () {
            CommonUtil.clearPage(this, 'searchFormData', this.gridObj)
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
        },
        //  엑셀다운로드
        excelDown: function () {
            pssApi.downloadAllogBondExcel(this.searchFormData)
        },
        //조회 버튼 클릭시 실행 method
        loadData: function () {
            if (_.isEmpty(this.searchFormData.accYm)) {
                this.showTcComAlert('정산월을 입력하십시오.')
                return
            }

            delete this.searchFormData.checkedRows
            pssApi
                .accPssAllotBondAccMgmts(this.searchFormData)
                .then((resultData) => {
                    console.log(resultData)
                    this.list = resultData
                    this.$refs.grid1.setRows(this.list)
                })
        },
        // 승인요청 대리점 체크여부
        ApproveAccPss: function () {
            var checkedRows = this.$refs.grid1.gridView.getCheckedItems(false)
            if (checkedRows == null || checkedRows.length == 0) {
                this.showTcComAlert(
                    '승인요청 대상 대리점을 선택 후 재처리하십시오.'
                )
                return
            } else
                for (var i = 0; i < checkedRows.length; i++) {
                    var row = this.$refs.grid1.gridView.getValues(
                        checkedRows[i]
                    )
                    if (row['fixYn'] == 'N') {
                        this.showTcComAlert(
                            '미확정인 대리점이 있습니다.\n[' +
                                row['sktAgencyCd'] +
                                '(' +
                                row['sktAgencyNm'] +
                                ')]\n승인요청은 확정후에 가능합니다.'
                        )
                        return
                    }
                    if (
                        row['aprvStatCd'] == '01' || // 요청중
                        row['aprvStatCd'] == 'C' || // 승인완료
                        row['aprvStatCd'] == 'P' || // 진행중
                        row['aprvStatCd'] == 'RD' // 준비중
                    ) {
                        this.showTcComAlert(
                            '승인이 진행중이거나 완료된 대리점이 있습니다.\n[' +
                                row['sktAgencyCd'] +
                                '(' +
                                row['sktAgencyNm'] +
                                ')]'
                        )
                        return
                    }
                }

            this.searchFormData.checkedRows = []
            var rowData = {}
            for (i = 0; i < checkedRows.length; i++) {
                rowData = this.$refs.grid1.gridView.getValues(checkedRows[i])
                this.searchFormData.checkedRows.push(rowData)
            }
            // 승인요청 처리로직 실행하기
            pssApi
                .accPssAllotBondAccMgmtEarvAprvReqs(this.searchFormData)
                .then((resultData) => {
                    if (resultData) {
                        this.showTcComAlert('승인요청이 완료되었습니다.')
                        this.loadData()
                    }
                })
        },
        // 검색 결과 체크하는 로직
        // 조회시 prama 정산월 입력 여부
        grdListOnCellDblClick: function (pRow) {
            if (pRow == undefined) return

            const rowData = this.list[pRow]

            this.cfCallPopup(rowData)
        },
        //================================================
        // POPUP 열기
        //================================================
        cfCallPopup: function (params) {
            this.popupParams.seq = params.seq
            this.popupParams.sktAgencyCd = params.sktAgencyCd
            this.popupParams.sktAgencyNm = params.sktAgencyNm
            this.popupParams.accDealcoCd = params.accDealcoCd
            this.popupParams.accYm = params.accYm
            this.popupParams.erpFixYn = params.erpFixYn
            this.popupParams.fixYn = params.fixYn
            this.popupParams.aprvStatCd = params.aprvStatCd

            this.showPopupOrg = true
        },
        //  대리점팝업
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getAgencyList() {
            this.searchAgency.agencyNm = this.searchFormData.sktAgencyNm
            basBcoAgencysApi.getAgencyList(this.searchAgency).then((res) => {
                console.log('getAgencyList then : ', res)
                // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (res.length === 1) {
                    this.searchFormData.sktAgencyCd = _.get(res[0], 'agencyCd')
                    this.searchFormData.sktAgencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultAgencyRows = res
                    this.showBcoAgencys = true
                }
            })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.searchFormData.sktAgencyNm)) {
                this.getAgencyList()
            } else {
                this.showBcoAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchFormData.sktAgencyNm)) {
                this.showTcComAlert('대리점명을 입력해주세요.')
                return
            }
            // 대리점 정보 조회
            this.getAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.searchFormData.sktAgencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchFormData.sktAgencyCd = _.get(retrunData, 'agencyCd')
            this.searchFormData.sktAgencyNm = _.get(retrunData, 'agencyNm')
        },
        //  대리점팝업
    },
}
</script>
