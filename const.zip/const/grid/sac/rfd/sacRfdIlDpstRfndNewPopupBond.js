'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: 'dealCoNm',
        editable: false,
        header: { text: '입금처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ymd',
        editable: false,
        header: { text: '일자' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'imagAccNo',
        editable: false,
        header: { text: '가상계좌' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accountCl',
        editable: false,
        header: { text: '계좌구분' },
        type: 'data',
        dataType: ValueType.TEXT,
        footer: {
            text: '합계',
        },
    },
    {
        fieldName: 'bfBondAmt',
        editable: false,
        header: { text: '전일채권잔액' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'toFeesAmt',
        editable: false,
        header: { text: 'SKT수납' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'toCashAmt',
        editable: false,
        header: { text: '현금매출' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'toEtcmAmt',
        editable: false,
        header: { text: '기타수납' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'toDpstAmt',
        editable: false,
        header: { text: '본사송금' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'toRfndAmt',
        editable: false,
        header: { text: '오입금환불' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'toPpayAmt',
        editable: false,
        header: { text: '선급금' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'toRcvbAmt',
        editable: false,
        header: { text: '기타미수금' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'toArrsAmt',
        editable: false,
        header: { text: '발생' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'toExpsAmt',
        editable: false,
        header: { text: '지출' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'toBondAmt',
        editable: false,
        header: { text: '당일채권잔액' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = [
    'dealCoNm',
    'ymd',
    'imagAccNo',
    'accountCl',
    'bfBondAmt',
    {
        name: 'bondIncrease',
        header: { text: '당일채권증가' },
        direction: 'horizontal',
        items: ['toFeesAmt', 'toCashAmt', 'toEtcmAmt'],
    },
    'toDpstAmt',
    'toRfndAmt',
    'toPpayAmt',
    'toRcvbAmt',
    {
        name: 'payable',
        header: { text: '미지급금' },
        direction: 'horizontal',
        items: ['toArrsAmt', 'toExpsAmt'],
    },
    'toBondAmt',
]
GRID_HEADER.contextStyle = `height: 300px`

const MOCK_DATA = {
    adpayMgmtVoList: [],
}

export { GRID_HEADER, MOCK_DATA }
