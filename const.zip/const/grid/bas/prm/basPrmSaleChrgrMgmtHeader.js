import { ValueType } from 'realgrid'

export const GRID_D_HEADER = {
    fields: [
        {
            fieldName: 'idx', // 사용자 ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId', // 사용자 ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm', // 사용자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effUserYn', // 유효사용자여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sendYn', // 발신여부
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'bizChrgOrgCd', // 사업담당조직
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'teamOrgCd', // 팀조직
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'ptOrgCd', // PT조직
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd', // P코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktDealCd', // 거래처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStatus', // 거래처거래상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt', // 적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt', // 적용종료일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 처리자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm', // 등록일시
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'userId',
            fieldName: 'userId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용자ID',
                showTooltip: false,
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            button: 'action',
            buttonVisibility: 'always',

            header: {
                text: '사용자명',
                showTooltip: false,
            },
        },
        {
            name: 'effUserYn',
            fieldName: 'effUserYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '유효사용자여부',
                showTooltip: false,
            },
        },
        {
            name: 'sendYn',
            fieldName: 'sendYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SMS전송',
                showTooltip: false,
            },
        },
        // {
        //     name: 'bizChrgOrgCd',
        //     fieldName: 'bizChrgOrgCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '사업담당',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: 'teamOrgCd',
        //     fieldName: 'teamOrgCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '영업팀',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: 'ptOrgCd',
        //     fieldName: 'ptOrgCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '영업파트',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            width: '400',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직코드',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        // {
        //     name: 'sktChnlCd',
        //     fieldName: 'sktChnlCd',
        //     type: 'data',
        //     editable: false,
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: 'P코드',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'sktDealCd',
            fieldName: 'sktDealCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처거래상태',
                showTooltip: false,
            },
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            header: {
                text: '적용시작일자',
                styleName: 'multi-line-css',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            header: {
                text: '적용종료일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyy-MM-dd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            editable: false,
            header: {
                text: '처리일시',
            },
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99 23:59:59',
                    includedFormat: true,
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}

export const GRID_SMS_HEADER = {
    fields: [
        {
            fieldName: 'userCd', // 사번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId', // 사용자 ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm', // 사용자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktDealCd', // 거래처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt', // 사용자그룹
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt', // 사업담당조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm', // 처리자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId', // 처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm', // 등록일시
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'userCd',
            fieldName: 'userCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사번',
                showTooltip: false,
            },
        },
        {
            name: 'userId',
            fieldName: 'userId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용자아이디',
                showTooltip: false,
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            button: 'action',
            buttonVisibility: 'always',

            header: {
                text: '사용자명',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
        },
        {
            name: 'sktDealCd',
            fieldName: 'sktDealCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            header: {
                text: '적용시작일자',
                styleName: 'multi-line-css',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            header: {
                text: '적용종료일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyy-MM-dd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            editable: false,
            header: {
                text: '처리일시',
            },
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99 23:59:59',
                    includedFormat: true,
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}
