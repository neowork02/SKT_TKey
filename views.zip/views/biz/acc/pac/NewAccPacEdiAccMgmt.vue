<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccPacEdiAccMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>EDI 매출/입금 정산 관리</h1>

        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    @click="onReset"
                    :objAuth="objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="objAuth"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    @click="onSave"
                    :objAuth="objAuth"
                    >저장</TCComButton
                >
            </li>
        </ul>

        <!-- [Tab0][EDI 매출정산] Search_div -->
        <NewAccPacEdiAccMgmtSearchBoxEdi
            ref="NewAccPacEdiAccMgmtSearchBoxEdi"
            :tabIndex="0"
            :nowTabIndex="tab.nowIndex"
            :objAuth="objAuth"
            :parentParams="tab.searchParams[0]"
            @setSearchParams="setSearchParams"
        />
        <!-- // [Tab0][EDI 매출정산] Search_div -->

        <!-- [Tab1][EDI 입금정산] Search_div -->
        <NewAccPacEdiAccMgmtSearchBoxEdi
            ref="NewAccPacEdiAccMgmtSearchBoxEdi"
            :tabIndex="1"
            :nowTabIndex="tab.nowIndex"
            :objAuth="objAuth"
            :parentParams="tab.searchParams[1]"
            @setSearchParams="setSearchParams"
        />
        <!-- // [Tab1][EDI 입금정산] Search_div -->

        <!-- [Tab2][카드입금정산 내역] Search_div -->
        <NewAccPacEdiAccMgmtSearchBoxEtc
            ref="NewAccPacEdiAccMgmtSearchBoxEtc"
            :tabIndex="2"
            :nowTabIndex="tab.nowIndex"
            :objAuth="objAuth"
            :parentParams="tab.searchParams[2]"
            @setSearchParams="setSearchParams"
        />
        <!-- // [Tab2][카드입금정산 내역] Search_div -->

        <!-- [Tab3][카드입금정산 상세] Search_div -->
        <NewAccPacEdiAccMgmtSearchBoxEtc
            ref="NewAccPacEdiAccMgmtSearchBoxEtc"
            :tabIndex="3"
            :nowTabIndex="tab.nowIndex"
            :objAuth="objAuth"
            :parentParams="tab.searchParams[3]"
            @setSearchParams="setSearchParams"
        />
        <!-- // [Tab3][카드입금정산 상세] Search_div -->

        <!-- [Tab4][수기입금정산] Search_div -->
        <NewAccPacEdiAccMgmtSearchBoxEtc
            ref="NewAccPacEdiAccMgmtSearchBoxEtc"
            :tabIndex="4"
            :nowTabIndex="tab.nowIndex"
            :objAuth="objAuth"
            :parentParams="tab.searchParams[4]"
            @setSearchParams="setSearchParams"
        />
        <!-- // [Tab4][수기입금정산] Search_div -->

        <TCComTab
            :tab.sync="tab.tabSync"
            :items="tab.id"
            :itemName="tab.name"
            :centered="false"
            :grow="false"
            :hideSlider="false"
            :vertical="false"
            :objAuth="objAuth"
            sliderSize="8"
            @change="onActiveTabClick"
        >
            <template #AccPacEdiSales>
                <TCRealGridHeader
                    id="gridHeader0"
                    ref="gridHeader0"
                    gridTitle=""
                    class="notit"
                    :gridObj="tab.grid[0]"
                    :isExceldown="true"
                    :isPageRows="true"
                    @excelDownBtn="exportExcelDownButton(0)"
                />
                <TCRealGrid
                    id="grid0"
                    ref="grid0"
                    :fields="tab.view[0].fields"
                    :columns="tab.view[0].columns"
                    :styles="gridStyle"
                />
                <TCComPaging
                    :gridObj="tab.grid[0]"
                    :totalPage="tab.gridData0.totalPage"
                    :apiFunc="onSearchPage"
                    :rowCnt="tab.page[0].pageSize"
                    @input="chgRowCnt"
                />
            </template>
            <template #AccPacEdiDeposit>
                <TCRealGridHeader
                    id="gridHeader1"
                    ref="gridHeader1"
                    gridTitle=""
                    class="notit"
                    :gridObj="tab.grid[1]"
                    :isExceldown="true"
                    :isPageRows="true"
                    @excelDownBtn="exportExcelDownButton(1)"
                />
                <TCRealGrid
                    id="grid1"
                    ref="grid1"
                    :fields="tab.view[1].fields"
                    :columns="tab.view[1].columns"
                    :styles="gridStyle"
                    @hook:mounted="tabGridMounted(1)"
                />
                <TCComPaging
                    :gridObj="tab.grid[1]"
                    :totalPage="tab.gridData1.totalPage"
                    :apiFunc="onSearchPage"
                    :rowCnt="tab.page[1].pageSize"
                    @input="chgRowCnt"
                />
            </template>
            <template #AccPacEdiDepositReport>
                <TCRealGridHeader
                    id="gridHeader2"
                    ref="gridHeader2"
                    gridTitle=""
                    class="notit"
                    :gridObj="tab.grid[2]"
                    :isExceldown="true"
                    :isPageRows="true"
                    @excelDownBtn="exportExcelDownButton(2)"
                />
                <TCRealGrid
                    id="grid2"
                    ref="grid2"
                    :fields="tab.view[2].fields"
                    :columns="tab.view[2].columns"
                    :styles="gridStyle"
                    @hook:mounted="tabGridMounted(2)"
                />
                <TCComPaging
                    :gridObj="tab.grid[2]"
                    :totalPage="tab.gridData2.totalPage"
                    :apiFunc="onSearchPage"
                    :rowCnt="tab.page[2].pageSize"
                    @input="chgRowCnt"
                />
            </template>
            <template #AccPacEdiDepositDetail>
                <TCRealGridHeader
                    id="gridHeader3"
                    ref="gridHeader3"
                    gridTitle=""
                    class="notit"
                    :gridObj="tab.grid[3]"
                    :isExceldown="true"
                    :isPageRows="true"
                    @excelDownBtn="exportExcelDownButton(3)"
                />
                <TCRealGrid
                    id="grid3"
                    ref="grid3"
                    :fields="tab.view[3].fields"
                    :columns="tab.view[3].columns"
                    :styles="gridStyle"
                    @hook:mounted="tabGridMounted(3)"
                />
                <TCComPaging
                    :gridObj="tab.grid[3]"
                    :totalPage="tab.gridData3.totalPage"
                    :apiFunc="onSearchPage"
                    :rowCnt="tab.page[3].pageSize"
                    @input="chgRowCnt"
                />
            </template>
            <template #AccPacEdiHardWrite>
                <TCRealGridHeader
                    id="gridHeader4"
                    ref="gridHeader4"
                    gridTitle=""
                    class="notit"
                    :gridObj="tab.grid[4]"
                    :isAddRow="true"
                    :isDelRow="true"
                    :isExceldown="true"
                    :isExcelup="true"
                    :isPageRows="true"
                    @addRowBtn="gridAddRowBtn"
                    @chkDelRowBtn="gridChkDelRowBtn"
                    @excelDownBtn="exportExcelDownButton(4)"
                    @excelUploadBtn="onSelectExcelFile()"
                />
                <TCRealGrid
                    id="grid4"
                    ref="grid4"
                    :fields="tab.view[4].fields"
                    :columns="tab.view[4].columns"
                    :styles="gridStyle"
                    @hook:mounted="tabGridMounted(4)"
                />
                <TCComPaging
                    :totalPage="tab.gridData4.totalPage"
                    :apiFunc="onSearchPage"
                    :rowCnt="tab.page[4].pageSize"
                    @input="chgRowCnt"
                />
                <v-file-input
                    id="excelFile"
                    ref="excelFile"
                    label="엑셀업로드 파일선택(숨김)"
                    style="display: none"
                    @change="onChangeExcelFileTab4"
                ></v-file-input>
            </template>
        </TCComTab>
    </div>
</template>
<script>
import _ from 'lodash'
import CommonMixin from '@/mixins'
import { CommonGrid } from '@/utils'
import { errorHandle } from '@/utils/accUtil'
import accMixin from '@/mixins/accMixin'
import pacApi from '@/api/biz/acc/pac'

import { GRID_HEADER as GRID_HEADER0 } from '@/const/grid/acc/pac/accPacEdiSalesGrid'
import { GRID_HEADER as GRID_HEADER1 } from '@/const/grid/acc/pac/accPacEdiDepositGrid'
import { GRID_HEADER as GRID_HEADER2 } from '@/const/grid/acc/pac/accPacEdiDepositReportGrid'
import { GRID_HEADER as GRID_HEADER3 } from '@/const/grid/acc/pac/accPacEdiDepositDetailGrid'
import { GRID_HEADER as GRID_HEADER4 } from '@/const/grid/acc/pac/accPacEdiHardWriteGrid'

import NewAccPacEdiAccMgmtSearchBoxEdi from '@/views/biz/acc/pac/NewAccPacEdiAccMgmtSearchBoxEdi' // 조회조건(EDI매출정산/EDI입금정산)
import NewAccPacEdiAccMgmtSearchBoxEtc from '@/views/biz/acc/pac/NewAccPacEdiAccMgmtSearchBoxEtc' // 조회조건(카드입금정산내역/카드입금정산상세/수기입금정산)

export default {
    name: 'AccPacEdiAccMgmt',
    mixins: [CommonMixin, accMixin],
    components: {
        NewAccPacEdiAccMgmtSearchBoxEdi, // 조회조건(EDI매출정산/EDI입금정산)
        NewAccPacEdiAccMgmtSearchBoxEtc, // 조회조건(카드입금정산내역/카드입금정산상세/수기입금정산)
    },
    data() {
        return {
            objAuth: {},
            activeTabIdx: 0,
            tabInfo: {
                id: [
                    'AccPacEdiSales',
                    'AccPacEdiDeposit',
                    'AccPacEdiDepositReport',
                    'AccPacEdiDepositDetail',
                    'AccPacEdiHardWrite',
                ],
                label: [
                    'EDI 매출정산',
                    'EDI 입금정산',
                    '카드입금정산 내역',
                    '카드입금정산 상세',
                    '수기입금정산',
                ],
            },

            formAccPacEdiSales: {
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                data: [],
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formAccPacEdiDeposit: {
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                data: [],
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formAccPacEdiDepositReport: {
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                data: [],
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formAccPacEdiDepositDetail: {
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                data: [],
                dtlInfo: {},
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formAccPacEdiHardWrite: {
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                data: [],
                pagingInfo: {
                    pageSize: 15,
                },
            },

            gridStyle: {
                height: '360px',
            },
            tabDefault: {},
            tab: {
                nowIndex: 0,
                tabSync: 0,
                id: [
                    'AccPacEdiSales',
                    'AccPacEdiDeposit',
                    'AccPacEdiDepositReport',
                    'AccPacEdiDepositDetail',
                    'AccPacEdiHardWrite',
                ],
                name: [
                    'EDI 매출정산',
                    'EDI 입금정산',
                    '카드입금정산 내역',
                    '카드입금정산 상세',
                    '수기입금정산',
                ],
                view: [
                    GRID_HEADER0,
                    GRID_HEADER1,
                    GRID_HEADER2,
                    GRID_HEADER3,
                    GRID_HEADER4,
                ],
                list: [[], [], [], [], []],
                grid: [{}, {}, {}, {}, {}],
                gridData0: {},
                gridData1: {},
                gridData2: {},
                gridData3: {},
                gridData4: {},
                page: [
                    { pageSize: 15, pageNum: 1 },
                    { pageSize: 15, pageNum: 1 },
                    { pageSize: 15, pageNum: 1 },
                    { pageSize: 15, pageNum: 1 },
                    { pageSize: 15, pageNum: 1 },
                ],
                searchParamsDefault: [],
                searchParams: [{}, {}, {}, {}, {}],
            },
            searchParams: {},

            showAlertBool: false,
        }
    },
    computed: {
        curSearchField() {
            return `${this.tab.id[this.tab.nowIndex]}Search`
        },

        curForm() {
            return this[`form${this.tab.id[this.tab.nowIndex]}`]
        },

        curGrid() {
            return this.$refs[this.tab.id[this.tab.nowIndex]].$refs.accGridTable
        },

        curPostApi() {
            let targetAPI

            switch (this.tab.nowIndex) {
                case 0:
                case 1:
                    targetAPI = pacApi.postEdiSalesList
                    break
                case 4:
                    targetAPI = pacApi.postCardHndsList
                    break
            }

            return targetAPI
        },
    },
    watch: {
        searchParams: {
            handler: function (newJson) {
                this.tab.searchParams[this.tab.nowIndex] = newJson
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        'tab.searchParams'(newArr) {
            this.tab.searchParams = newArr
        },
    },
    mounted() {
        console.log('mounted')
        // 초기화를 위해 초기값 저장하기
        this.tabDefault = _.cloneDeep(this.tab)
        this.tab.searchParamsDefault = _.cloneDeep(this.tab.searchParams)

        // 첫번째 그리드 세팅
        this.tab['gridData' + this.tab.nowIndex] = this.gridSetData()
        this.tab.grid[0] = this.$refs.grid0
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.tab.grid[0].setGridState(false, false, true, false)
    },
    methods: {
        tabGridMounted: function (tabIndex) {
            // 그리드 세팅하기
            this.tab['gridData' + tabIndex] = this.gridSetData()
            this.tab.grid[tabIndex] = this.$refs['grid' + tabIndex]
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            this.tab.grid[tabIndex].setGridState(false, false, false, false)
        },
        onActiveTabClick(tabIndex) {
            this.tab.nowIndex = tabIndex

            // 현재 tab의 조회조건을 this.searchParams 변수에 세팅한다.
            this.searchParams = _.cloneDeep(
                this.tab.searchParams[this.tab.nowIndex]
            )
        },
        setSearchParams(searchParams) {
            this.tab.searchParams[this.tab.nowIndex] = searchParams
        },
        setParamJson(_method) {
            // 현재 tab의 조회조건을 this.searchParams 변수에 세팅한다.
            let _searchParams = _.cloneDeep(
                this.tab.searchParams[this.tab.nowIndex]
            )

            // get방식으로 파라미터 넘길 때 오류로 인해 아래 제거함
            if (_method == 'GET') {
                Object.assign(_searchParams, this.tab.page[this.tab.nowIndex])
                delete _searchParams['payDt']
                delete _searchParams['baseMth_']
            }

            return _searchParams
        },
        setListGrid(res) {
            const api = this.getTabInfo()

            // list를 변수에 세팅
            this.tab.list[this.tab.nowIndex] = res[api.listName].gridList
            this.tab.page[this.tab.nowIndex] = res[api.listName].pagingDto
            this.tab['gridData' + this.tab.nowIndex].totalPage =
                res[api.listName].pagingDto.totalPageCnt // 총페이지수

            // list를 그리드에 출력
            if (this.$refs['grid' + this.tab.nowIndex]) {
                this.$refs['grid' + this.tab.nowIndex].setRows(
                    this.tab.list[this.tab.nowIndex]
                )
            }
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(
                0,
                this.tab.page[this.tab.nowIndex].pageSize,
                '',
                ''
            )
        },
        onReset() {
            var tabNowIndex = _.cloneDeep(this.tab.nowIndex) // 현재Tab번호를 변수에 저장한다.

            // 변수 초기화
            this.searchParams = _.cloneDeep(
                this.tab.searchParamsDefault[this.tab.nowIndex]
            )
            this.tab = _.cloneDeep(this.tabDefault)

            // Grid 초기화
            for (var i = 0; i < 4; i++) {
                this.tab.nowIndex = i
                this.setListGrid([])
            }

            // 원래 보였던 Tab으로 다시 이동시키기
            this.tab.nowIndex = tabNowIndex
            this.tab.tabSync1 = tabNowIndex
        },
        getTabInfo() {
            let api = {}
            if (this.tab.nowIndex == 0) {
                api.listFunc = pacApi.getEdiSalesList
                api.listName = 'ediSaleAccVoPagingList'
            } else if (this.tab.nowIndex == 1) {
                api.listFunc = pacApi.getEdiDpstsList
                api.listName = 'ediDpstAccVoPagingList'
            } else if (this.tab.nowIndex == 2) {
                api.listFunc = pacApi.getCardDpstsList
                api.listName = 'ediCardDpstAccVoPagingList'
            } else if (this.tab.nowIndex == 3) {
                api.listFunc = pacApi.getCardDpstsDtlList
                api.listName = 'ediCardDpstAccVoDtlVoPagingList'
            } else if (this.tab.nowIndex == 4) {
                api.listFunc = pacApi.getCardHndsList
                api.listName = 'hndwrtDpstAccVoPagingList'
            }

            return api
        },
        onSearchValidate: function () {
            let isResult = true
            const _searchParams = this.setParamJson('GET')

            if (this.tab.nowIndex == 4) {
                return
            }

            if (this.tab.nowIndex <= 1) {
                if (_.isEmpty(_searchParams.baseMth)) {
                    this.showTcComAlert('조회월을 선택해 주세요.')
                    isResult = false
                }
            } else {
                if (
                    _.isEmpty(_searchParams.payStaDtm) ||
                    _.isEmpty(_searchParams.payEndDtm)
                ) {
                    this.showTcComAlert('조회일자를 선택해 주세요.')
                    isResult = false
                }
            }

            if (_.isEmpty(_searchParams.orgId)) {
                this.showTcComAlert('조직을 선택해 주세요.')
                isResult = false
            }

            return isResult
        },
        onSearch() {
            // validate 체크
            if (this.onSearchValidate() == false) {
                return
            }

            this.tab['gridData' + this.tab.nowIndex] = this.gridSetData()
            this.onSearchPage(1)
        },
        onSearchPage(pageNum) {
            this.tab.page[this.tab.nowIndex].pageNum = pageNum
            var _searchParams = Object.assign(
                this.setParamJson('GET'),
                this.tab.page[this.tab.nowIndex]
            )

            _searchParams.searchCoClOrgCd = 'O00000'

            // 목록 호출
            const api = this.getTabInfo()
            return api
                .listFunc(_searchParams)
                .then((res) => {
                    console.log(res)
                    this.setListGrid(res)
                })
                .catch(errorHandle)
        },
        onSave() {
            const form = this.curForm
            const postList = this.curPostApi
            const voListName = this.curVoListName
            const grid = this.curGrid
            console.log(grid)

            const rows = grid.getChangedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`수정된 항목이 없습니다.`)
            } else {
                form.query[voListName] = rows
                return postList(form.query)
                    .then((res) => {
                        console.log(res)
                        this.showTcComAlert(`정상적으로 처리되었습니다.`)
                        delete form.query[voListName]
                        this.viewForm(form.query)
                    })
                    .catch(errorHandle)
            }
        },
        chgRowCnt: function (pageSize) {
            this.tab.page[this.tab.nowIndex].pageSize = pageSize
        },
        /* 화면 상단의 엑셀다운로드 버튼 클릭시 실행 */
        exportExcelDownButton(tabIndex) {
            // 조회조건 Validation 체크
            if (this.onSearchValidate() == false) {
                return
            }

            var _searchParams = this.setParamJson('GET')
            _searchParams.tabIndex = tabIndex
            _searchParams.dataClCd = String(tabIndex + 1)

            pacApi.excelDownload(_searchParams).then(() => {
                this.showTcComAlert('엑셀파일이 다운로드되었습니다.')
            })
        },

        dblClickCellAccPacEdiDepositReport(row) {
            const form = this.formAccPacEdiDepositDetail
            const getList = pacApi.getCardDpstsDtlList

            form.query = row
            form.query.guBun2 = 'DTL'
            form.query.pageNum = 1
            form.query.pageSize = 15

            // form.data = MOCK_DATA.gridList
            // form.dtlInfo = Object.assign({}, form.query)
            // this.changeTabMenu(3)
            // console.log(getList)

            return getList(form.query).then((res) => {
                form.data = [...res.gridList]
                Object.assign(form.dtlInfo, form.query)
                this.changeTabMenu(3)
            })
        },

        movePage(query) {
            const form = this.curForm
            Object.assign(form.query, query)

            this.viewForm(form.query)
        },

        changePageSize(query) {
            this.curSearchField.setQuery(query)
        },

        //Add Row Event
        gridAddRowBtn: function () {
            this.gridObj.gridView.commit()
        },
        //Check Row Delete Event
        gridChkDelRowBtn: function () {
            this.gridObj.gridView.commit()
        },
        /* 수기입금정산 Tab의 엑셀업로드 버튼 클릭시 실행 */
        onSelectExcelFile: function () {
            document.getElementById('excelFile').click()
        },
        /* 수기입금정산 Tab의 엑셀업로드 파일 선택시 실행 */
        onChangeExcelFileTab4: function (f) {
            // AccExcelUpload.onChange(
            //     f,
            //     this.excelUp.tab3.columns,
            //     function () {},
            //     this.callbackExcelUpload
            // )
            console.log(f)
        },
    },
}
</script>
