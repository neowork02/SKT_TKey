import { ValueType } from 'realgrid'

export const GRID_LAYOUT1 = [
    'NO',
    'orgNm',
    'dealSktCd',
    'hldDealcoCd',
    'hldDealcoNm',
    'pmthDisQty',
    'pmthSaleQty',
    'currDisCnt',
    {
        name: '입고유형',
        direction: 'horizontal',
        items: [
            {
                name: '입고',
                direction: 'horizontal',
                items: [
                    'mthInQty',
                    'chgInCnt',
                    'saleRtnCnt',
                    'saleOutCnclCnt',
                    'prOutCnclCnt',
                    'przOutCnclCnt',
                    'eqpOutCnclCnt',
                    'giftOutCnclCnt',
                    'othItOutCnclCnt',
                ],
            },
            {
                name: '재고이동입고',
                direction: 'horizontal',
                items: ['movInSchdCnt', 'movInCnt', 'disAdjInQty'],
            },
        ],
    },
    {
        name: '출고유형',
        direction: 'horizontal',
        items: [
            {
                name: '출고',
                direction: 'horizontal',
                items: [
                    'rtnOutCnt',
                    'chgOutCnt',
                    'chgRtnOutCnt',
                    'saleOutCnt',
                    'mthOutQty',
                    'prOutCnt',
                    'przOutCnt',
                    'eqpOutCnt',
                    'giftOutCnt',
                    'othItOutCnt',
                ],
            },
            {
                name: '재고이동출고',
                direction: 'horizontal',
                items: ['movOutCnt', 'disAdjOutQty', 'riskProdRgstCnt'],
            },
        ],
    },
]

export const GRID_LAYOUT2 = [
    'NO',
    'orgNm',
    'dealSktCd',
    'hldDealcoCd',
    'hldDealcoNm',
    'mfactNm',
    'prodClNm',
    'prodCd',
    'prodNm',
    'colorCd',
    'colorNm',
    'mktgDt',
    'fixCashPrc',
    'fixCrdtPrc',
    'realPrchsPrc',
    'pmthDisQty',
    'pmthSaleQty',
    'currDisCnt',
    {
        name: '입고유형',
        direction: 'horizontal',
        items: [
            {
                name: '입고',
                direction: 'horizontal',
                items: [
                    'mthInQty',
                    'chgInCnt',
                    'saleRtnCnt',
                    'saleOutCnclCnt',
                    'prOutCnclCnt',
                    'przOutCnclCnt',
                    'eqpOutCnclCnt',
                    'giftOutCnclCnt',
                    'othItOutCnclCnt',
                ],
            },
            {
                name: '재고이동입고',
                direction: 'horizontal',
                items: ['movInSchdCnt', 'movInCnt', 'disAdjInQty'],
            },
        ],
    },
    {
        name: '출고유형',
        direction: 'horizontal',
        items: [
            {
                name: '출고',
                direction: 'horizontal',
                items: [
                    'rtnOutCnt',
                    'chgOutCnt',
                    'chgRtnOutCnt',
                    'saleOutCnt',
                    'mthOutQty',
                    'prOutCnt',
                    'przOutCnt',
                    'eqpOutCnt',
                    'giftOutCnt',
                    'othItOutCnt',
                ],
            },
            {
                name: '재고이동출고',
                direction: 'horizontal',
                items: ['movOutCnt', 'disAdjOutQty', 'riskProdRgstCnt'],
            },
        ],
    },
]

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, // 보유처명
        },
        {
            fieldName: 'pmthDisQty',
            dataType: ValueType.NUMBER, // 전월재고수량
        },
        {
            fieldName: 'pmthSaleQty',
            dataType: ValueType.NUMBER, // 전월판매수량
        },
        {
            fieldName: 'currDisCnt',
            dataType: ValueType.NUMBER, // 현재고건수
        },
        {
            fieldName: 'mthInQty',
            dataType: ValueType.NUMBER, // 월입고수량
        },
        {
            fieldName: 'chgInCnt',
            dataType: ValueType.NUMBER, // 교품입고건수
        },
        {
            fieldName: 'saleRtnCnt',
            dataType: ValueType.NUMBER, // 매출반품건수
        },
        {
            fieldName: 'saleOutCnclCnt',
            dataType: ValueType.NUMBER, // 판매출고취소건수
        },
        {
            fieldName: 'prOutCnclCnt',
            dataType: ValueType.NUMBER, // 판촉출고취소건수
        },
        {
            fieldName: 'przOutCnclCnt',
            dataType: ValueType.NUMBER, // 포상비출고취소건수
        },
        {
            fieldName: 'eqpOutCnclCnt',
            dataType: ValueType.NUMBER, // 비품출고취소건수
        },
        {
            fieldName: 'giftOutCnclCnt',
            dataType: ValueType.NUMBER, // TGift출고취소건수
        },
        {
            fieldName: 'othItOutCnclCnt',
            dataType: ValueType.NUMBER, // 타전산출고취소건수
        },
        {
            fieldName: 'movInSchdCnt',
            dataType: ValueType.NUMBER, // 이동입고예정건수
        },
        {
            fieldName: 'movInCnt',
            dataType: ValueType.NUMBER, // 이동입고건수
        },
        {
            fieldName: 'disAdjInQty',
            dataType: ValueType.NUMBER, // 재고조정입고수량
        },
        {
            fieldName: 'rtnOutCnt',
            dataType: ValueType.NUMBER, // 반품출고건수
        },
        {
            fieldName: 'chgOutCnt',
            dataType: ValueType.NUMBER, // 교품출고건수
        },
        {
            fieldName: 'chgRtnOutCnt',
            dataType: ValueType.NUMBER, // 교품반품출고건수
        },
        {
            fieldName: 'saleOutCnt',
            dataType: ValueType.NUMBER, // 매출출고건수
        },
        {
            fieldName: 'mthOutQty',
            dataType: ValueType.NUMBER, // 월출고수량
        },
        {
            fieldName: 'prOutCnt',
            dataType: ValueType.NUMBER, // 판촉출고건수
        },
        {
            fieldName: 'przOutCnt',
            dataType: ValueType.NUMBER, // 포상비출고건수
        },
        {
            fieldName: 'eqpOutCnt',
            dataType: ValueType.NUMBER, // 비품출고건수
        },
        {
            fieldName: 'giftOutCnt',
            dataType: ValueType.NUMBER, // Tgift출고건수
        },
        {
            fieldName: 'othItOutCnt',
            dataType: ValueType.NUMBER, // 타전산출고건수
        },
        {
            fieldName: 'movOutCnt',
            dataType: ValueType.NUMBER, // 이동출고건수
        },
        {
            fieldName: 'disAdjOutQty',
            dataType: ValueType.NUMBER, // 재고조정출고수량
        },
        {
            fieldName: 'riskProdRgstCnt',
            dataType: ValueType.NUMBER, // 사고단말기등록건수
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '조직',
            },
            footer: {
                text: '합계',
                styleName: 'left-column',
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '보유처매장코드',
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '보유처코드',
            },
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '보유처',
            },
        },
        {
            name: 'pmthDisQty',
            fieldName: 'pmthDisQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '전월재고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'pmthSaleQty',
            fieldName: 'pmthSaleQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '전월매출',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'currDisCnt',
            fieldName: 'currDisCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '현재고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'mthInQty',
            fieldName: 'mthInQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '구매입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'chgInCnt',
            fieldName: 'chgInCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '교품입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'saleRtnCnt',
            fieldName: 'saleRtnCnt',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '매출반품입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'saleOutCnclCnt',
            fieldName: 'saleOutCnclCnt',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'prOutCnclCnt',
            fieldName: 'prOutCnclCnt',
            type: 'data',
            width: '110',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판촉출고취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'przOutCnclCnt',
            fieldName: 'przOutCnclCnt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '포상비출고취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'eqpOutCnclCnt',
            fieldName: 'eqpOutCnclCnt',
            type: 'data',
            width: '110',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '비품출고취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'giftOutCnclCnt',
            fieldName: 'giftOutCnclCnt',
            type: 'data',
            width: '110',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'T.Gift출고취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'othItOutCnclCnt',
            fieldName: 'othItOutCnclCnt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '타전산출고취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'movInSchdCnt',
            fieldName: 'movInSchdCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '이동입고미확정',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'movInCnt',
            fieldName: 'movInCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '이동입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'disAdjInQty',
            fieldName: 'disAdjInQty',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '재고조정입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'rtnOutCnt',
            fieldName: 'rtnOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '반품출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'chgOutCnt',
            fieldName: 'chgOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '교품출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'chgRtnOutCnt',
            fieldName: 'chgRtnOutCnt',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '교품반품출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'saleOutCnt',
            fieldName: 'saleOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '매출출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'mthOutQty',
            fieldName: 'mthOutQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'prOutCnt',
            fieldName: 'prOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판촉출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'przOutCnt',
            fieldName: 'przOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '포상비출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'eqpOutCnt',
            fieldName: 'eqpOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '비품출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'giftOutCnt',
            fieldName: 'giftOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'T.Gift출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'othItOutCnt',
            fieldName: 'othItOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '타전산출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'movOutCnt',
            fieldName: 'movOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '이동출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'disAdjOutQty',
            fieldName: 'disAdjOutQty',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '재고조정출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'riskProdRgstCnt',
            fieldName: 'riskProdRgstCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '사고단말기등록',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],
}

export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, // 보유처명
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, // 제조사명
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'eqpClNm',
            dataType: ValueType.TEXT, // 단말기구분명
        },
        {
            fieldName: 'comMthdNm',
            dataType: ValueType.TEXT, // 통신방식명
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 출시일자
        },
        {
            fieldName: 'fixCashPrc',
            dataType: ValueType.NUMBER, // 확정현금가격
        },
        {
            fieldName: 'fixCrdtPrc',
            dataType: ValueType.NUMBER, // 확정여신가격
        },
        {
            fieldName: 'realPrchsPrc',
            dataType: ValueType.NUMBER, // 실매입가격
        },
        {
            fieldName: 'pmthDisQty',
            dataType: ValueType.NUMBER, // 전월재고수량
        },
        {
            fieldName: 'pmthSaleQty',
            dataType: ValueType.NUMBER, // 전월판매수량
        },
        {
            fieldName: 'currDisCnt',
            dataType: ValueType.NUMBER, // 현재고건수
        },
        {
            fieldName: 'mthInQty',
            dataType: ValueType.NUMBER, // 월입고수량
        },
        {
            fieldName: 'chgInCnt',
            dataType: ValueType.NUMBER, // 교품입고건수
        },
        {
            fieldName: 'saleRtnCnt',
            dataType: ValueType.NUMBER, // 매출반품건수
        },
        {
            fieldName: 'saleOutCnclCnt',
            dataType: ValueType.NUMBER, // 판매출고취소건수
        },
        {
            fieldName: 'prOutCnclCnt',
            dataType: ValueType.NUMBER, // 판촉출고취소건수
        },
        {
            fieldName: 'przOutCnclCnt',
            dataType: ValueType.NUMBER, // 포상비출고취소건수
        },
        {
            fieldName: 'eqpOutCnclCnt',
            dataType: ValueType.NUMBER, // 비품출고취소건수
        },
        {
            fieldName: 'giftOutCnclCnt',
            dataType: ValueType.NUMBER, // TGift출고취소건수
        },
        {
            fieldName: 'othItOutCnclCnt',
            dataType: ValueType.NUMBER, // 타전산출고취소건수
        },
        {
            fieldName: 'movInSchdCnt',
            dataType: ValueType.NUMBER, // 이동입고예정건수
        },
        {
            fieldName: 'movInCnt',
            dataType: ValueType.NUMBER, // 이동입고건수
        },
        {
            fieldName: 'disAdjInQty',
            dataType: ValueType.NUMBER, // 재고조정입고수량
        },
        {
            fieldName: 'rtnOutCnt',
            dataType: ValueType.NUMBER, // 반품출고건수
        },
        {
            fieldName: 'chgOutCnt',
            dataType: ValueType.NUMBER, // 교품출고건수
        },
        {
            fieldName: 'chgRtnOutCnt',
            dataType: ValueType.NUMBER, // 교품반품출고건수
        },
        {
            fieldName: 'saleOutCnt',
            dataType: ValueType.NUMBER, // 매출출고건수
        },
        {
            fieldName: 'mthOutQty',
            dataType: ValueType.NUMBER, // 월출고수량
        },
        {
            fieldName: 'prOutCnt',
            dataType: ValueType.NUMBER, // 판촉출고건수
        },
        {
            fieldName: 'przOutCnt',
            dataType: ValueType.NUMBER, // 포상비출고건수
        },
        {
            fieldName: 'eqpOutCnt',
            dataType: ValueType.NUMBER, // 비품출고건수
        },
        {
            fieldName: 'giftOutCnt',
            dataType: ValueType.NUMBER, // Tgift출고건수
        },
        {
            fieldName: 'othItOutCnt',
            dataType: ValueType.NUMBER, // 타전산출고건수
        },
        {
            fieldName: 'movOutCnt',
            dataType: ValueType.NUMBER, // 이동출고건수
        },
        {
            fieldName: 'disAdjOutQty',
            dataType: ValueType.NUMBER, // 재고조정출고수량
        },
        {
            fieldName: 'riskProdRgstCnt',
            dataType: ValueType.NUMBER, // 사고단말기등록건수
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '조직',
            },
            footer: {
                text: '합계',
                styleName: 'left-column',
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '보유처매장코드',
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '보유처코드',
            },
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '보유처',
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '제조사',
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '모델코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '모델명',
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상코드',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상명',
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '출시일',
            },
        },
        {
            name: 'fixCashPrc',
            fieldName: 'fixCashPrc',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '확정현금가',
            },
        },
        {
            name: 'fixCrdtPrc',
            fieldName: 'fixCrdtPrc',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '확정여신가',
            },
        },
        {
            name: 'realPrchsPrc',
            fieldName: 'realPrchsPrc',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '실제매입가',
            },
        },
        {
            name: 'pmthDisQty',
            fieldName: 'pmthDisQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '전월재고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'pmthSaleQty',
            fieldName: 'pmthSaleQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '전월매출',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'currDisCnt',
            fieldName: 'currDisCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '현재고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'mthInQty',
            fieldName: 'mthInQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '구매입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'chgInCnt',
            fieldName: 'chgInCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '교품입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'saleRtnCnt',
            fieldName: 'saleRtnCnt',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '매출반품입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'saleOutCnclCnt',
            fieldName: 'saleOutCnclCnt',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'prOutCnclCnt',
            fieldName: 'prOutCnclCnt',
            type: 'data',
            width: '110',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판촉출고취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'przOutCnclCnt',
            fieldName: 'przOutCnclCnt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '포상비출고취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'eqpOutCnclCnt',
            fieldName: 'eqpOutCnclCnt',
            type: 'data',
            width: '110',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '비품출고취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'giftOutCnclCnt',
            fieldName: 'giftOutCnclCnt',
            type: 'data',
            width: '110',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'T.Gift출고취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'othItOutCnclCnt',
            fieldName: 'othItOutCnclCnt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '타전산출고취소입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'movInSchdCnt',
            fieldName: 'movInSchdCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '이동입고미확정',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'movInCnt',
            fieldName: 'movInCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '이동입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'disAdjInQty',
            fieldName: 'disAdjInQty',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '재고조정입고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'rtnOutCnt',
            fieldName: 'rtnOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '반품출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'chgOutCnt',
            fieldName: 'chgOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '교품출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'chgRtnOutCnt',
            fieldName: 'chgRtnOutCnt',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '교품반품출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'saleOutCnt',
            fieldName: 'saleOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '매출출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'mthOutQty',
            fieldName: 'mthOutQty',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판매출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'prOutCnt',
            fieldName: 'prOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '판촉출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'przOutCnt',
            fieldName: 'przOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '포상비출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'eqpOutCnt',
            fieldName: 'eqpOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '비품출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'giftOutCnt',
            fieldName: 'giftOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'T.Gift출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'othItOutCnt',
            fieldName: 'othItOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '타전산출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'movOutCnt',
            fieldName: 'movOutCnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '이동출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'disAdjOutQty',
            fieldName: 'disAdjOutQty',
            type: 'data',
            width: '90',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '재고조정출고',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'riskProdRgstCnt',
            fieldName: 'riskProdRgstCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '사고단말기등록',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],
}

export const DETAIL_GRID_HEADER = {
    fields: [
        {
            fieldName: 'NO',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'inoutDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 입출고일자
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, // 보유처명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm ',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'inoutDtlClCd',
            dataType: ValueType.TEXT, // 입출고상세구분코드
        },
        {
            fieldName: 'inoutDtlClNm',
            dataType: ValueType.TEXT, // 입출고상세구분명
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'NO',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            numberFormat: '##0',
            header: {
                text: 'No',
            },
            editor: {
                textReadOnly: false,
            },
        },
        {
            name: 'inoutDt',
            fieldName: 'inoutDt',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '입출고일자',
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '보유처매장코드',
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '보유처코드',
            },
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '보유처',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '모델코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '모델명',
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상코드',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '80',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상명',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'inoutDtlClNm',
            fieldName: 'inoutDtlClNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '수불유형명',
            },
        },
    ],
}
