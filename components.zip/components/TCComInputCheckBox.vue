<!-----------------------------------------------
 * 업무그룹명: CheckBox 컴포넌트
 * 서브업무명: CheckBox 공통함수
 * 설명: CheckBox 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.04.08
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <label class="wrapperck flex items-center">
        {{ labelName }}
        <input
            class="checkbox"
            type="checkbox"
            :value="dValue"
            :readonly="readonly"
            :disabled="disabled"
        />
        <span class="checkmenu"></span>
    </label>
</template>
<script>
export default {
    inheritAttrs: false,
    name: 'TCComInputCheckBox',
    components: {},
    props: {
        // 체크 값
        value: {
            type: [String, Array],
            required: false,
        },
        //텍스트박스 명
        labelName: { type: String, default: '', required: false },
        // disabled
        disabled: { type: Boolean, default: false, required: false },
        // readonly
        readonly: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            dValue: [],
        }
    },
    computed: {},
    // props 동적 제어
    watch: {
        value: {
            handler: function () {
                this.dValue = this.value
            },
            deep: true,
            immediate: true,
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.dValue = this.value
        },
    },
}
</script>

<style lang="scss" scoped>
.wrapperck {
    display: block;
    position: relative;
    padding-left: 14px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    font-size: 12px;
}
.wrapperck input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
    height: 0;
    width: 0;
}
.checkmenu {
    position: absolute;
    top: 0;
    left: 0;
    height: 13px;
    width: 13px;
    border-radius: 2px;
    background-color: #fff;
    border: 1px solid #666;
}
.wrapperck:hover input ~ .checkmenu {
    background-color: #fff;
    border: 1px solid #666;
}
.wrapperck input:checked ~ .checkmenu {
    background: #777;
    border: 1px solid #777;
}
.checkmenu:after {
    content: '';
    position: absolute;
    display: none;
}
.wrapperck input:checked ~ .checkmenu:after {
    display: block;
}
.wrapperck .checkmenu:after {
    left: 3px;
    top: 0px;
    width: 5px;
    height: 8px;
    border: solid #fff;
    border-width: 0 2px 2px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
}
</style>
