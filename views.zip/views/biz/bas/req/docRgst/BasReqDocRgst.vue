<!-----------------------------------------------
 * 업무그룹명: 기본정보
 * 서브업무명: 기타
 * 설명: 기본정보-기타-요건서등록
 * 작성자: P180392
 * 작성일: 2022.10.20
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">{{ title }}</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <search-container ref="searchContainer" />
                    <!-- <table-container
                        @PopupOpen="PopupOpen"
                        @Refresh="Refresh"
                    /> -->
                    <data-container @PopupOpen="PopupOpen" />
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            v-if="!readOnly"
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            :objAuth="objAuth"
                            @click="saveBtn"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            :objAuth="objAuth"
                            @click="onClose"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/docRgst/helpers'
import store from '@/store/biz/bas/req/docRgst'
import _ from 'lodash'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
import CommonMixin from '@/mixins'
import SearchContainer from './Content/SearchContainer.vue'
//import TableContainer from './Content/TableContainer.vue'
import DataContainer from './Content/DataContainer.vue'

export default {
    name: 'BasReqDocRgstPopup',
    mixins: [CommonMixin],
    components: {
        SearchContainer,
        //TableContainer,
        DataContainer,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    created() {
        console.log('created:' + this.$options.name)
        if (this.$store.hasModule('bas.req.docRgstStore') != true) {
            this.$store.registerModule('bas.req.docRgstStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.req.docRgstStore') == true) {
            this.$store.unregisterModule('bas.req.docRgstStore')
        }
    },
    data() {
        return {
            objAuth: {},
            title: '',
            readOnly: false,
        }
    },
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        popupClose1: {
            get() {
                return this.popupClose
            },
        },
        popupConfirm1: {
            get() {
                return this.popupConfirm
            },
        },
    },
    methods: {
        ...serviceMethods,
        PopupOpen(param) {
            this.$refs.popupContainer.open(param)
        },
        Refresh() {
            console.log('emit refresh')
            //this.$refs.searchContainer.searchData()
        },
        async onClose() {
            console.log('main close btn')
            await this.defaultAssign_({
                key: 'popupInit',
                value: true,
            })
            await this.defaultAssign_({
                key: 'popupInit',
                value: false,
            })

            this.activeOpen = false
        },
        async saveBtn() {
            await this.defaultAssign_({
                key: 'saveAction',
                value: true,
            })
        },
        maskingName(strName) {
            if (_.isEmpty(strName)) return strName
            if (strName.length > 2) {
                let originName = strName.split('')
                originName.forEach(function (name, i) {
                    if (i === 0 || i === originName.length - 1) return
                    originName[i] = '*'
                })
                let joinName = originName.join()
                return joinName.replace(/,/g, '')
            } else {
                let pattern = /.$/ // 정규식
                return strName.replace(pattern, '*')
            }
        },
        async initState() {
            //init State
            await this.defaultAssign_({
                key: 'saveAction',
                value: false,
            })
            await this.defaultAssign_({
                key: 'saveDoneA',
                value: false,
            })
            await this.defaultAssign_({
                key: 'saveDoneB',
                value: false,
            })
            await this.defaultAssign_({
                key: 'resultList',
                value: '',
            })

            //컴포넌트 조각에서 각각 초기화
            await this.defaultAssign_({
                key: 'popupInit',
                value: true,
            })
            await this.defaultAssign_({
                key: 'popupInit',
                value: false,
            })
        },
    },
    watch: {
        parentParam: {
            handler: async function (value) {
                if (this.$store.hasModule('bas.req.docRgstStore') != true) {
                    this.$store.registerModule('bas.req.docRgstStore', store)
                }
                console.log('call popup main parentParam', value)
                await this.initState()

                const param1 = _.clone(value)

                //this.searchParam.orgNm = value['orgNm']
                if (_.isEmpty(param1.uuid)) {
                    this.title = '요건서등록'
                    this.readOnly = false
                    let basicData = {
                        reqOrgCd: this.orgInfo.orgCd,
                        reqOrgNm: this.orgInfo.orgNm,
                        reqOrgNmView: `${this.orgInfo.orgNm}(${this.orgInfo.orgCd})`,
                        reqUserId: this.userInfo.userId,
                        reqUserNm: this.userInfo.userNm,
                        reqUserNmView: `${this.maskingName(
                            this.userInfo.userNm
                        )}(${this.userInfo.userId})`,
                        readOnly: false,
                        mode: 'new',
                    }
                    await this.defaultAssign_({
                        key: 'popupParams',
                        value: basicData,
                    })
                    console.log('popup new detail', basicData)
                } else {
                    if (param1.readOnly == true) {
                        this.title = '요건서조회'
                        this.readOnly = true
                    } else {
                        this.title = '요건서수정'
                        this.readOnly = false
                        if (param1.mode == 'dev')
                            this.title = '요건서수정(개발정보)'
                    }

                    console.log('popup param popup exist detail', param1)
                    await this.defaultAssign_({
                        key: 'popupParams',
                        value: param1,
                    })
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        popupConfirm1: {
            // eslint-disable-next-line no-unused-vars
            handler: async function (value) {
                if (value == true) {
                    await this.defaultAssign_({
                        key: 'popupConfirm',
                        value: false,
                    })
                    //this.$emit('confirm', this.popupRtData)
                    this.$emit('confirm', true)
                    this.onClose()
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        popupClose1: {
            // eslint-disable-next-line no-unused-vars
            handler: async function (value) {
                if (value == true) {
                    await this.defaultAssign_({
                        key: 'popupClose',
                        value: false,
                    })
                    //this.$emit('confirm', { test1: '111' }) //단순 닫기에도 호출창에서 refresh를 하려면 emit 호출
                    this.onClose()
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        // resultList1: {
        //     // eslint-disable-next-line no-unused-vars
        //     handler: function (value) {},
        //     deep: true, // 속성 내부까지 감시
        //     immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        // },
    },
}
</script>
