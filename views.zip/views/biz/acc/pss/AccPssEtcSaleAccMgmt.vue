<template>
    <div class="content">
        <h1>기타매출정산관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    :disabled="disabledBtnApp"
                    @click="ApproveAccPss"
                    >승인요청</TCComButton
                >
                <span class="infoTxt color-red"
                    >승인상태가 기안취소, 반려, 오류일 경우만
                    재요청됩니다.</span
                >
            </li>
            <li class="right">
                <v-btn
                    color="btn2"
                    class="btn_ty01"
                    @click="screenInit"
                    :objAuth="objAuth"
                    >초기화</v-btn
                >
                <v-btn
                    color="btn2"
                    class="btn_ty01"
                    @click="loadData()"
                    :objAuth="objAuth"
                    :disabled="disabledBtnSearch"
                    >조회</v-btn
                >
                <v-btn
                    color="btn2"
                    class="btn_ty01"
                    :disabled="disabledBtnSave"
                    @click="saveData"
                    :objAuth="objAuth"
                    >저장</v-btn
                >
            </li>
        </ul>
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        v-model="searchFormData.accYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="AR_CL_CD"
                        labelName="상품구분"
                        v-model="searchFormData.arClCd"
                        :objAuth="objAuth"
                        @change="onChange()"
                        :eRequired="true"
                        :filterFunc="inClCdFilter"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchFormData.agencyNm"
                        :codeVal.sync="searchFormData.agencyCd"
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAgencyEnterKey"
                        @appendIconClick="onAgencyIconClick"
                        @input="onAgencyInput"
                    />
                    <BasBcoAgencysPopup
                        v-if="showBcoAgencys"
                        :parentParam="searchFormData"
                        :rows="resultAgencyRows"
                        :dialogShow.sync="showBcoAgencys"
                        @confirm="onAgencyReturnData"
                    />
                </div>
            </div>
        </div>
        <!-- //Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="정산내역"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :gridObj="gridObj"
                @excelDownBtn="listExcelDownload"
            >
                <template #gridElementArea>
                    <TCComDatePicker
                        labelName="확정일"
                        calType="D"
                        class="btn_noline btn_ty04"
                        v-model="searchFormData.wrtDt_"
                    />
                    <button
                        type="button"
                        class="btn_noline btn_ty04"
                        @click="dtlExcelDownload"
                    >
                        <span class="ico_exeldown">상세</span>
                    </button>
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :gridObj="gridObj"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getAccPssEtcSaleAccMgmts"
                :gridObj="gridObj"
            />
            <TCRealGridHeader
                id="gridSubHeader"
                ref="gridSubHeader"
                :gridObj="gridSubObj"
            />
            <TCRealGrid
                v-show="false"
                id="gridSub"
                ref="gridSub"
                :fields="subView.fields"
                :columns="subView.columns"
                :styles="excelGridStyle"
            />
        </div>
        <!-- popup 영역 -->
        <AccPssEtcSaleAccRgst
            v-if="popup.adjustDtl.showPopupOrg === true"
            ref="popup"
            :dialogShow.sync="popup.adjustDtl.showPopupOrg"
            :popupParams.sync="popupParams"
            @close="loadData"
        />
        <!-- //popup 영역 -->
    </div>
</template>
<script>
import pssApi from '@/api/biz/acc/pss/accPssEtcSaleAccMgmt'
import moment from 'moment'
import { CommonGrid, CommonUtil } from '@/utils'
import _ from 'lodash'
import AccPssEtcSaleAccRgst from '@/views/biz/acc/pss/AccPssEtcSaleAccRgst'
import {
    GRID_HEADER,
    GRID_DETIAL_HEADER,
} from '@/const/grid/acc/pss/AccPssEtcSaleAccMgmtGrid'

//  세션정보
import CommonMixin from '@/mixins'

//  대리점팝업
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
//  대리점팝업

export default {
    name: 'AccPssEtcSaleAccMgmt',
    mixins: [CommonMixin],
    components: {
        AccPssEtcSaleAccRgst,
        BasBcoAgencysPopup,
    },
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,
            subView: GRID_DETIAL_HEADER,

            //Grid
            gridObj: {},
            gridSubObj: {},

            resultData: '',
            closed: false,
            gridData: this.gridSetData(),
            searchForms: {},
            rowCnt: 15,

            layout: [
                'aprvStat',
                'confirmYn',
                'agencyCd',
                'agencyNm',
                'accYm',

                {
                    name: '마감금액',
                    direction: 'horizontal',
                    items: ['splyPrc', 'vatAmt', 'saleAmt'],
                },
                {
                    name: 'SWING금액',
                    direction: 'horizontal',
                    items: ['ukeyPay', 'ukeyRfnd', 'ukeyClose'],
                },
                {
                    name: '확정금액',
                    direction: 'horizontal',
                    items: ['fixAmt', 'fixVatAmt', 'totFixAmt'],
                },
                'insUserNm',
                'insDtm',
            ],

            //list
            etcSaleMgmts: [],
            prodAccDetails: [],
            paramJson: {},

            //btn 바인딩
            disabledBtnSearch: false,
            disabledBtnApp: true,
            disabledBtnSave: true,

            //alert창
            showAlertBool: false,
            alertBodyText: '',

            //승인요청
            objAuth: {},

            //요청 파라미터
            searchFormData: {
                accYm_: moment(new Date()).format('YYYY-MM'),
                accYm: moment(new Date()).format('YYYYMM'), // 정산월
                wrtDt_: moment(this.accYm_)
                    .endOf('months')
                    .format('YYYY-MM-DD'), // 확정일자
                wrtDt: moment(this.accYm).endOf('months').format('YYYYMMDD'), // 확정일
                agencyCd: '', //
                agencyNm: '',
                checkedRows: [],
                insUserId: '',
                aprvStatCd: '',
                arClCd: 'SAVE',
                keyCode: '',
                loginUserCd: '',
            },
            /* popup영역 */
            popupParams: {},
            popup: {
                adjustDtl: {
                    showPopupOrg: false,
                },
            },

            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
            excelGridStyle: {
                height: '0px', //그리드 높이 조절
            },

            //  대리점팝업
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //  대리점팝업
        }
    },
    created() {},
    mounted() {
        //정산내역 상세 그리드(excel 다운로드용)
        this.gridSubObj = this.$refs.gridSub
        this.gridSubHeaderObj = this.$refs.gridSubHeader
        this.gridSubObj.setGridState(false, false, false, false)

        //정산내역 조회 그리드
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, true, false)
        this.gridObj.gridView.setColumnLayout(this.layout)
        // 그리드 셀 클릭 팝업 이벤트
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked

        this.searchFormData.loginUserCd = this.userInfo.userCd
    },
    watch: {
        'searchFormData.accYm_'(newVal) {
            this.searchFormData.accYm = newVal
            if (!_.isEmpty(newVal)) {
                this.searchFormData.accYm = newVal.replace(/-/g, '')
                // 확정일 : 선택된 정산월의 마지막일 자동 세팅
                this.searchFormData.wrtDt_ = moment(this.searchFormData.accYm_)
                    .endOf('month')
                    .format('YYYY-MM-DD')
                this.searchFormData.wrtDt = moment(this.searchFormData.accYm)
                    .endOf('month')
                    .format('YYYYMMDD')
            }
        },
    },
    methods: {
        // 초기화
        screenInit: function () {
            CommonUtil.clearPage(this.$router)
        },
        // 상품구분으로 승인요청/저장 버튼 컨트롤
        onChange: function () {
            console.log(this.searchFormData.arClCd)
            if (this.searchFormData.arClCd == 'SAVE') {
                this.disabledBtnApp = true
                this.disabledBtnSave = true
            } else {
                this.disabledBtnApp = false
                this.disabledBtnSave = false
            }
            this.loadData()
        },
        //공통코드 상품구분 Filter
        inClCdFilter(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] === 'SAVE' || item['commCdVal'] === 'SAF1'
            )
        },
        //================================================
        // get방식 파라미터 '-' 오류 해결
        //================================================
        setGetParamJson: function () {
            this.paramJson = _.cloneDeep(this.searchFormData)

            // get방식으로 파라미터 넘길 때 오류로 인해 아래 제거함
            delete this.paramJson['accYm_']
            delete this.paramJson['wrtDt_']
            delete this.paramJson['checkedRows']

            return this.paramJson
        },
        gridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        listExcelDownload: function () {
            pssApi.accPssEtcSaleAccListExcel(this.setGetParamJson())
        },

        dtlExcelDownload: function () {
            pssApi.accPssEtcSaleAccDtlExcel(this.setGetParamJson())
        },
        //조회 버튼 클릭시 실행 method
        loadData() {
            this.gridData.totalPage = 0
            this.searchForms = { ...this.setGetParamJson() }
            this.searchForms.pageSize = this.rowCnt
            this.searchForms.pageNum = 1

            this.getAccPssEtcSaleAccMgmts(this.setGetParamJson().pageNum)
        },
        async getAccPssEtcSaleAccMgmts(page) {
            if (_.isEmpty(this.searchFormData.accYm)) {
                this.searchForms.pageNum = page
                this.showTcComAlert('정산월을 입력하십시오.')
                return false
            }
            await pssApi
                .getAccPssEtcSaleAccMgmts(this.searchForms)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        this.etcSaleMgmts = res
                        this.$refs.grid.setRows(res.gridList)
                        this.$refs.grid.setGridIndicator(res.pagingDto)
                        this.gridData = this.gridSetData()
                        this.gridData.totalPage = res.pagingDto.totalPageCnt
                        this.gridHeaderObj.setPageCount(res.pagingDto)
                        console.log(res)
                    }
                })
        },
        saveData: function () {
            var checkedRows = this.$refs.grid.gridView.getCheckedItems(false)
            if (checkedRows == null || checkedRows.length == 0) {
                this.showTcComAlert(
                    '저장할 대상 대리점을 선택 후 재처리하십시오.'
                )
                return
            } else
                for (var i = 0; i < checkedRows.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(checkedRows[i])

                    if (row['saveYn'] == 'Y') {
                        this.showTcComAlert(
                            '이미 정산된 자료는 저장처리 하실수 없습니다. \n 삭제처리후 저장하십시오.'
                        )
                        return
                    }
                }
            this.searchFormData.checkedRows = []
            for (i = 0; i < checkedRows.length; i++) {
                var rowData = this.$refs.grid.gridView.getValues(checkedRows[i])
                this.searchFormData.checkedRows.push(rowData)
            }
            this.disabledBtnSave = true
            pssApi.setEtcProdAcc(this.searchFormData).then((resultData) => {
                if (resultData) {
                    this.disabledBtnSave = false
                    this.showTcComAlert(checkedRows.length + '건 저장 완료')

                    // 목록 재조회
                    this.loadData()
                }
            })
        },

        // 승인요청 대리점 체크여부
        ApproveAccPss: function () {
            var checkedRows = this.$refs.grid.gridView.getCheckedItems(false)
            if (checkedRows == null || checkedRows.length == 0) {
                this.showTcComAlert(
                    '승인요청 대상 대리점을 선택 후 재처리하십시오.'
                )
                return
            } else
                for (var i = 0; i < checkedRows.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(checkedRows[i])
                    if (row['fixYn'] == 'N') {
                        this.showTcComAlert(
                            '미확정인 대리점이 있습니다.\n[' +
                                row['agencyCd'] +
                                '(' +
                                row['agencyNm'] +
                                ')' +
                                ']\n승인요청은 확정후에 가능합니다.'
                        )
                        return
                    }
                    if (
                        row['aprvStatCd'] == '01' || // 요청중
                        row['aprvStatCd'] == 'C' || // 승인완료
                        row['aprvStatCd'] == 'P' || // 진행중
                        row['aprvStatCd'] == 'RD' // 준비중
                    ) {
                        this.showTcComAlert(
                            '승인이 진행중이거나 완료되어 승인요청 가능한 대리점이 없습니다.'
                        )
                        return
                    }
                }
            this.searchFormData.checkedRows = []
            for (i = 0; i < checkedRows.length; i++) {
                var rowData = this.$refs.grid.gridView.getValues(checkedRows[i])
                this.searchFormData.checkedRows.push(rowData)
            }
            this.disabledBtnApp = true
            // 승인요청 처리로직 실행하기
            pssApi
                .accPssEtcSaleAccEarvAprvReqs(this.searchFormData)
                .then((resultData) => {
                    if (resultData) {
                        this.disabledBtnApp = false
                        this.showTcComAlert(
                            checkedRows.length + '건 승인요청 완료'
                        )

                        // 목록 재조회
                        this.loadData()
                    }
                })
        },
        //================================================
        // POPUP 열기
        //================================================

        // 검색 결과 체크하는 로직
        // 조회시 prama 정산월 입력 여부
        onCellDblClicked() {
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                this.popup.adjustDtl.showPopupOrg = true
                var rowData = grid.getValues(clickData.itemIndex)
                this.popup.adjustDtl.popupParams = rowData
                this.popupParams.agencyCd = rowData.agencyCd
                this.popupParams.agencyNm = rowData.agencyNm
                this.popupParams.arClCd = rowData.arClCd
                this.popupParams.accYm = moment(rowData.accYm).format('YYYYMM')
                this.popupParams.accYm_ = moment(rowData.accYm).format(
                    'YYYY-MM'
                )
                this.popupParams.saveYn = rowData.saveYn
            }
        },

        onReturnSaleAccRgst: function (retVal) {
            if (retVal) {
                this.showAlertBool = true
                this.alertBodyText = '삭제되었습니다.'
                this.loadData()
            }
        },
        //  대리점팝업
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getAgencyList() {
            basBcoAgencysApi.getAgencyList(this.searchFormData).then((res) => {
                console.log('getAgencyList then : ', res)
                // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (res.length === 1) {
                    this.searchFormData.agencyCd = _.get(res[0], 'agencyCd')
                    this.searchFormData.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultAgencyRows = res
                    this.showBcoAgencys = true
                }
            })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.searchFormData.agencyNm)) {
                this.getAgencyList()
            } else {
                this.showBcoAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchFormData.agencyNm)) {
                this.showTcComAlert('대리점명을 입력해주세요.')
                return
            }
            // 대리점 정보 조회
            this.getAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.searchFormData.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchFormData.agencyCd = _.get(retrunData, 'agencyCd')
            this.searchFormData.agencyNm = _.get(retrunData, 'agencyNm')
        },
        //  대리점팝업
    },
}
</script>
