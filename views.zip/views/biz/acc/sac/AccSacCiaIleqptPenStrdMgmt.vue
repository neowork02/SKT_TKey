<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccSacCiaIleqptPenStrdMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <AccHeadline title="CIA미비 패널티 기준관리" />

        <AccSearchField
            ref="accSearchField"
            :offset="[
                'btn-right-reset',
                'btn-right-view',
                'btn-right-save',
                'btn-right-delete',
                { slotSearch: 'search-pntyClNm' },
                { slotSearch: 'search-useYn' },
            ]"
            :initValue="initValue"
            @reset="resetForm"
            @view="viewForm"
            @save="saveForm"
            @delete="deleteForm"
        >
            <template slot="search-pntyClNm" slot-scope="slotProps">
                <div
                    class="formitem"
                    :class="`div${slotProps.divideCellCount}`"
                >
                    <TCComInput
                        v-model="formGetPenaltySvcs.query.pntyClNm"
                        labelName="제목"
                    >
                    </TCComInput>
                </div>
            </template>
            <template slot="search-useYn" slot-scope="slotProps">
                <div
                    class="formitem"
                    :class="`div${slotProps.divideCellCount}`"
                >
                    <TCComComboBox
                        itemText="label"
                        itemValue="value"
                        :itemList="[
                            {
                                label: '전체',
                                value: '',
                            },
                            {
                                label: 'Y',
                                value: 'Y',
                            },
                            {
                                label: 'N',
                                value: 'N',
                            },
                        ]"
                        labelName="조회구분"
                        v-model="formGetPenaltySvcs.query.useYn"
                    ></TCComComboBox>
                </div>
            </template>
        </AccSearchField>

        <AccGridTable
            ref="accGridTable"
            class="accGridTable"
            isEditable
            isCheckbox
            :offset="['btn-addRow', 'btn-deleteRow', 'btn-excelDownload']"
            :gridMeta="GRID_HEADER"
            :data="formGetPenaltySvcs.data"
            :pagingInfo="formGetPenaltySvcs.pagingInfo"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/sac/penalty-svcs-excel-download`,
                query: formGetPenaltySvcs.query,
            }"
            @movePage="movePage"
            @changePageSize="changePageSize"
        />
    </div>
</template>
<style lang="scss" scoped></style>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import { errorHandle, distanceDate } from '@/utils/accUtil'

import AccHeadline from '@/components/biz/common/acc/AccHeadline'
import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import sacApi from '@/api/biz/acc/sac'

import {
    GRID_HEADER,
    MOCK_DATA,
} from '@/const/grid/acc/sac/AccSacCiaIleqptPenStrdMgmtGrid'

export default {
    name: 'AccSacCiaIleqptPenStrdMgmt',
    mixins: [CommonMixin, accMixin],
    components: {
        AccHeadline,
        AccSearchField,
        AccGridTable,
    },
    data() {
        return {
            GRID_HEADER,

            initValue: {
                pageSize: 15,
                pageNum: 1,
            },

            formGetPenaltySvcs: {
                data: [],
                query: {
                    useYn: '',
                },
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formPostPenaltySvcs: {
                data: [],
                query: {},
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formDeletePenaltySvcs: {
                query: {},
            },
        }
    },

    computed: {
        accGridTable() {
            return this.$refs.accGridTable
        },

        gridView() {
            return this.$refs.accGridTable.gridView
        },

        dataProvider() {
            return this.$refs.accGridTable.dataProvider
        },
    },

    created() {
        this.initPage()
        console.log(sacApi, MOCK_DATA)
    },
    methods: {
        initPage() {},

        resetForm() {
            this.formGetPenaltySvcs.query.pntyClNm = ''
            this.formGetPenaltySvcs.query.useYn = ''
            this.formGetPenaltySvcs.data = []
        },

        viewForm(query) {
            Object.assign(this.formGetPenaltySvcs.query, query)
            return this.getPenaltySvcs()
        },

        saveForm() {
            this.gridView.commit()

            const rows = this.accGridTable.getChangedRow()
            const rowIdx = this.accGridTable.getChangedRowIdx()

            if (rows.length == 0) {
                return this.showTcComAlert(`수정된 항목이 없습니다.`)
            } else {
                const invalidList = []
                rows.forEach((row, idx) => {
                    if (
                        distanceDate(row.pntyAplyStaDt, row.pntyAplyEndDt) > 0
                    ) {
                        invalidList.push(rowIdx[idx])
                    }
                })

                if (invalidList.length) {
                    return this.showTcComAlert(
                        `[${invalidList}]번째 데이터의 적용시작/종료일자를 확인하십시오`
                    )
                } else {
                    this.formPostPenaltySvcs.query.accSacCiaIleqptPenStrdMgmtSVCVoList =
                        rows

                    this.postPenaltySvcs().then(this.getPenaltySvcs)
                }
            }
        },

        async deleteForm() {
            this.gridView.commit()

            const rows = this.accGridTable.getCheckedRow()
            const rowIdx = this.accGridTable.getCheckedRowIdx()
            const rowStatus = this.accGridTable.getRowStateInIdx(rowIdx)

            if (rows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                const invalidList = []
                rowStatus.forEach((status, idx) => {
                    if (status == 'created') invalidList.push(rowIdx[idx])
                })

                if (invalidList.length) {
                    return this.showTcComAlert(
                        `[${invalidList}]번째 Row는 추가된 Row입니다. -버튼으로 삭제하십시오`
                    )
                } else {
                    this.formDeletePenaltySvcs.query.accSacCiaIleqptPenStrdMgmtSVCVoList =
                        rows

                    const confirm = await this.showTcComConfirm(
                        '선택한 데이터를 삭제하시겠습니까?'
                    )

                    if (confirm) {
                        this.deletePenaltySvcs().catch(errorHandle)
                    } else {
                        this.showTcComAlert('삭제가 취소되었습니다.')
                    }
                }
            }
        },

        movePage(query) {
            Object.assign(this.formGetPenaltySvcs.query, query)
            this.getPenaltySvcs()
        },

        changePageSize(query) {
            this.accSearchField.setQuery(query)
            // Object.assign(this.formGetPenaltySvcs.query, query)
        },

        getPenaltySvcs() {
            // this.formGetPenaltySvcs.data = [
            //     ...MOCK_DATA.accPacPrseBondAdjMgmtGrid.gridList,
            // ]

            // this.formGetPenaltySvcs.pagingInfo =
            //     MOCK_DATA.accPacPrseBondAdjMgmtGrid.pagingDto

            // return Promise.resolve()

            return sacApi
                .getPenaltySvcs(this.formGetPenaltySvcs.query)
                .then((res) => {
                    this.formGetPenaltySvcs.data = [
                        ...res.accSacCiaIleqptPenStrdMgmtGridList.gridList,
                    ]
                    this.formGetPenaltySvcs.pagingInfo =
                        res.accSacCiaIleqptPenStrdMgmtGridList.pagingDto
                })
                .catch(errorHandle)
        },

        postPenaltySvcs() {
            return sacApi
                .postPenaltySvcs(this.formPostPenaltySvcs.query)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
                .catch(errorHandle)
        },

        deletePenaltySvcs() {
            return sacApi
                .deletePenaltySvcs(this.formDeletePenaltySvcs.query)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                    return this.getPenaltySvcs()
                })
                .catch(errorHandle)
        },
    },
}
</script>
