<template>
    <TCComDialog :dialogShow.sync="activeOpenSpecialSale" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">내부거래처-특판처</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComComboBox
                                    v-model="ckParam.dealcoClCd1"
                                    :itemList="dealcoGubunList"
                                    labelName="거래처구분"
                                    :disabled="true"
                                ></TCComComboBox>
                            </div>

                            <div class="formitem div4">
                                <TCComDatePicker
                                    v-model="searchParam.basDayTemp"
                                    labelName="기준년월"
                                    calType="M"
                                ></TCComDatePicker>
                            </div>
                            <div class="formitem div4">
                                <TCComCheckBox
                                    v-model="ckParam.dealEndYn"
                                    labelName="거래종료포함"
                                    :itemList="chkData"
                                    itemValue="dealEndYn"
                                ></TCComCheckBox>
                            </div>
                            <div class="formitem div4"></div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <div class="rightArea btn">
                                    <span class="inner"> </span>
                                </div>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParam.dealcoCd"
                                    labelName="거래처코드"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParam.dealcoNm"
                                    labelName="거래처명"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4"></div>
                            <div class="formitem div4">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="searchform"></div>
                    </div>
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">내부거래처 목록</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="specialSaleGrid"
                                ref="specialSaleGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonGrid, CommonUtil } from '@/utils'
import { SALE_HEADER } from '@/const/grid/bas/bco/basBcoSpecialSaleHeader'
import basBcoSpecialSaleApi from '@/api/biz/bas/bco/basBcoSpecialSale'
import commonApi from '@/api/common/commonCode'
import moment from 'moment'
import { SacCommon } from '@/views/biz/sac/js'

export default {
    name: 'BasBcoSpecialSalePopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            header: SALE_HEADER,
            dealcoGubunList: [], // 거래처구분
            searchParam: {
                basDay: '', //기준년월
                basDayTemp: '',
                orgLvl: '', //세션레벨
                dealcoClCd1: '', // 내부거래처구분
                dealcoCd: '', //거래처코드
                dealcoNm: '', // 내부거래처명
                dealEndYn: '', //거래종료
            },
            ckParam: {
                //onlyAccDeaCoCd: '',
                dealEndYn: ['Y'], //거래종료
                dealcoClCd1: '',
            },
            commSpecialSalePtn: [],
            chkData: [
                {
                    dealEndYn: 'Y',
                    commCdValNm: '',
                },
            ],
        }
    },
    computed: {
        activeOpenSpecialSale: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                //거래처코드

                if (
                    (value['dealEndYn'] !== '') == undefined
                        ? ''
                        : value['dealEndYn']
                ) {
                    this.ckParam.dealEndYn = [
                        value['dealEndYn'] == undefined
                            ? ''
                            : value['dealEndYn'],
                    ] //거래종료
                }
                this.searchParam.orgLvl =
                    value['orgLvl'] == undefined ? '' : value['orgLvl'] //조직레벨

                let dealcoClCd1 =
                    value['dealcoClCd1'] == undefined
                        ? ''
                        : value['dealcoClCd1'] //거래처구분코드

                if (dealcoClCd1 === '') {
                    this.ckParam.dealcoClCd1 = '81'
                } else {
                    this.ckParam.dealcoClCd1 = dealcoClCd1
                }

                this.searchParam.dealcoNm =
                    value['dealcoNm'] == undefined ? '' : value['dealcoNm'] //거래처명
                this.searchParam.dealcoCd =
                    value['dealcoCd'] == undefined ? '' : value['dealcoCd'] //거래처코드
                this.searchParam.onlyDisUse =
                    value['onlyDisUse'] == undefined ? '' : value['onlyDisUse'] //재고전용여부

                let basDay = value['basDay'] == undefined ? '' : value['basDay']
                basDay = CommonUtil.replaceDash(basDay)
                if (basDay.length < 6) {
                    basDay = CommonUtil.replaceDash(SacCommon.getToday())
                    basDay = basDay.substring(0, 6)
                    this.searchParam.basDayTemp = basDay
                } else if (basDay.length == 6) {
                    this.searchParam.basDayTemp = basDay
                } else {
                    basDay = basDay.substring(0, 6)
                    this.searchParam.basDayTemp = basDay
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },
    async mounted() {
        this.gridObj = this.$refs.specialSaleGrid // Grid Object 설정
        await this.setBaseData()
        this.initGrid()

        // console.log('menuInfo', this.menuInfo) //메뉴정보
        // console.log('orgInfo', this.orgInfo) //조직정보
        // console.log('userInfo', this.userInfo) //사용자정보
        // console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        //this.searchParam.orgLvl = this.orgInfo.orgLvl //세션레벨
    },
    methods: {
        init() {
            this.gridData = this.gridSetData()
            this.searchParam.searchDateModel = moment().format('YYYY-MM-DD')
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async setBaseData() {
            this.dealcoGubunList = await this.getCommCodeList('ZBAS_C_00240')
        },
        async initGrid() {
            // const commDealCoClCd1Nm = await this.getCommCodeList('ZBAS_C_00240')
            this.gridObj.gridView.columnByName('dealcoClCd1').values =
                CommonUtil.convListToGridLovValues(
                    this.dealcoGubunList,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('dealcoClCd1').labels =
                CommonUtil.convListToGridLovLabels(
                    this.dealcoGubunList,
                    'commCdValNm'
                )

            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, true, true)
            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                this.selectDataRow = clickData.dataRow
                //빈곳클릭시작업없음
                if (undefined == this.selectDataRow) {
                    return
                }

                let jsonData = []
                jsonData.push(
                    this.gridObj.dataProvider.getJsonRow(clickData.dataRow)
                )

                /*
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                */

                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        getSpecialSaleList() {
            //##백앤드String으로 받게 되어있음
            //거래처구분
            this.searchParam.dealcoClCd1 = String(this.ckParam.dealcoClCd1)

            //체크박스거래종료
            this.searchParam.dealEndYn = String(this.ckParam.dealEndYn)
            //##백앤드String으로 받게 되어있음

            let basDayTemp = CommonUtil.replaceDash(this.searchParam.basDayTemp)

            if ('' == basDayTemp) {
                let today = SacCommon.getToday()
                this.searchParam.basDay = CommonUtil.replaceDash(today)
            } else {
                if (basDayTemp.length == 6) {
                    let lastDay = SacCommon.uf_monthLastDay(basDayTemp)
                    this.searchParam.basDay = basDayTemp + lastDay
                } else if (this.searchParam.basDayTemp.length > 6) {
                    let today = SacCommon.getToday()
                    this.searchParam.basDay = CommonUtil.replaceDash(today)
                }
            }

            basBcoSpecialSaleApi
                .getSpecialSaleList(this.searchParam)
                .then((res) => {
                    console.log('getSpecialSaleList then : ', res)
                    this.gridObj.setRows(res)
                })
        },

        onConfirm() {
            /*
            const current = this.gridObj.gridView.getCurrent()


            if (current.dataRow === -1) {
                this.showAlertBool = true
                this.headerText = '거래처 선택'
                this.alertBodyText = '거래처를 선택해주세요.'
                return
            }
            */

            let jsonData = []
            let checkedRows = this.gridObj.gridView.getCheckedRows()

            if (!checkedRows.length) {
                this.showTcComAlert('거래처를 선택해주세요.')
                return
            }

            for (var r in checkedRows) {
                jsonData.push(
                    this.gridObj.dataProvider.getJsonRow(checkedRows[r])
                )
            }

            /*
            const jsonData = this.gridObj.dataProvider.getJsonRow()
            */
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenSpecialSale = false
        },

        onSearch() {
            this.getSpecialSaleList()
        },

        onEnterKey() {
            this.onSearch()
        },
    },
}
</script>
