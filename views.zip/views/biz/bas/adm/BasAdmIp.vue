<template>
    <div class="content">
        <!-- Tit -->
        <h1>IPLOG리스트</h1>
        <!-- // Tit -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton eClass="btn_ty01" @click="resetBtn"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                    >조회
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="DP"
                        v-model="arrDate"
                        labelName="조회일자"
                        :eRequired="true"
                        :objAuth="this.objAuth"
                    ></TCComDatePicker>
                </div>
                <div class="formitem div5">
                    <TCComInput
                        v-model="reqParam.dealCoCd"
                        labelName="근무지코드"
                        :objAuth="objAuth"
                    ></TCComInput>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="IPLog리스트"
                :gridObj="gridObj"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="gridIpLogList"
                ref="gridIpLogList"
                :editable="true"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getIpLogList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonGrid } from '@/utils'
import moment from 'moment'
import API from '@/api/biz/bas/adm/basAdmIp'
import { BAS_IP_LOG_HEADER } from '@/const/grid/bas/adm/basAdmIpHeader'
export default {
    name: 'BasAdmIp',
    mixins: [CommonMixin],
    props: {},
    components: {},
    data() {
        return {
            gridObj: {},
            gridData: this.GridSetData(),
            gridHeaderObj: {},
            objAuth: {},
            forms: {},
            arrDate: [],
            resultList: [],
            view: BAS_IP_LOG_HEADER,
            //rows: [],
            gridStyle: {
                height: '600px',
            },
            reqParam: {},
            rowCnt: 15,
            activePage: 1, // 현재페이지
            paging: {
                pageNum: 1,
                pageSize: 15,
                totalPageCnt: 0,
                totalDataCnt: 0,
            },
        }
    },
    computed: {},
    watch: {},
    created() {},
    mounted() {
        this.initParam()

        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.gridIpLogList
        this.gridHeaderObj = this.$refs.gridHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, false, false, false)
    },
    methods: {
        initParam() {
            this.resultList = []
            this.arrDate = [
                moment(new Date()).format('YYYY-MM-DD'),
                moment(new Date()).format('YYYY-MM-DD'),
            ]
            this.paging = {
                pageNum: 1,
                pageSize: 10,
                totalPageCnt: 0,
                totalDataCnt: 0,
            }
        },
        init() {
            this.gridData = this.GridSetData()
        },
        chgRowCnt(pageSize) {
            this.rowCnt = pageSize
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수),
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            var date = new Date()
            var year = date.getFullYear()
            var month = ('0' + (1 + date.getMonth())).slice(-2)
            var day = ('0' + date.getDate()).slice(-2)

            return year + '-' + month + '-' + day
        },
        searchBtn: function () {
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getIpLogList(1)
        },
        resetBtn: function () {
            this.initParam()
            this.gridSet()
        },
        getIpLogList(pageNum) {
            this.reqParam.fromDt = this.removeHyphen(this.arrDate[0])
            this.reqParam.toDt = this.removeHyphen(this.arrDate[1])
            let paramObj = { ...this.reqParam }

            paramObj.pageSize = this.rowCnt
            paramObj.pageNum = pageNum

            console.log('paramObj : ', paramObj)
            this.excelParam = paramObj

            let data

            API.getIpLogList(paramObj)
                .then((result) => {
                    console.log('result -> ', result)
                    data = result
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    if (data.gridList.length > 0) {
                        this.resultList = data.gridList
                        this.paging = data.pagingDto
                    } else {
                        this.showTcComAlert('데이터가 없습니다.')
                        this.resultList = []
                        this.paging = {
                            pageNum: 1,
                            pageSize: 15,
                            totalPageCnt: 0,
                            totalDataCnt: 0,
                        }
                    }
                    this.gridSet()
                })
        },
        // 문자열 하이픈 제거
        removeHyphen: function (val) {
            try {
                return val.replace(/[^0-9]/g, '')
            } catch (e) {
                return val
            }
        },
        gridSet() {
            // dataSet
            this.gridObj.setRows(this.resultList)
            this.gridObj.setGridIndicator(this.paging) //순번이 필요한경우 계산하는 함수

            // paging
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
        },
    },
}
</script>

<style></style>
