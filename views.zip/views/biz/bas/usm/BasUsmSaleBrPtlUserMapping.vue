<!-----------------------------------------------
 * 업무그룹명: 기준정보>판매점포탈 사용자매핑 
 * 서브업무명: 판매점포탈 사용자매핑 
 * 설명: 판매점포탈 사용자매핑 Popup 컴포넌트
 * 작성자: 서영우
 * 작성일: 2022.05.10
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">판매점포탈 사용자매핑</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <ul class="btn_area top">
                    <li class="right">
                        <TCComButton
                            color="btn2"
                            eClass="btn_ty01"
                            @click="onResetPage"
                            :objAuth="objAuth"
                        >
                            초기화
                        </TCComButton>
                        <TCComButton
                            color="btn2"
                            eClass="btn_ty01"
                            @click="onSearch"
                            :objAuth="objAuth"
                        >
                            조회
                        </TCComButton>
                        <TCComButton
                            color="btn2"
                            eClass="btn_ty01"
                            @click="onSave"
                            :objAuth="objAuth"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            color="btn2"
                            eClass="btn_ty01"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </li>
                </ul>
                <div class="searchLayer_wrap">
                    <div class="searchform">
                        <div class="formitem div4">
                            <TCComInput
                                v-model="reqParam.edt_UserNm"
                                :eRequired="true"
                                labelName="사용자명"
                                :objAuth="objAuth"
                            >
                            </TCComInput>
                        </div>
                        <div class="formitem div4">
                            <TCComInput
                                v-model="reqParam.edt_LoginID"
                                :eRequired="true"
                                labelName="통합ID"
                                :objAuth="objAuth"
                            >
                            </TCComInput>
                        </div>
                    </div>
                </div>

                <div class="gridWrap">
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :editable="true"
                        :fields="view.fields"
                        :columns="view.columns"
                    />
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
import { HEADER } from '@/const/grid/bas/usm/basUsmSaleBrPtlUserMappingHeader'
import API from '@/api/biz/bas/usm/basUsmSaleBrPtlUserMapping'
import _ from 'lodash'

export default {
    name: 'BasUsmSaleBrPtlUserMapping',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },

    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            objAuth: {},
            view: HEADER,
            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            selectedItem: '',
            // 조회조건
            reqParam: {
                // userNm: '', //사용자명
                // portalID: '', //
                // opDt: '', //
                // opTm: '', //
                // seq: '', //
                // d14Yn: '', //
            },
            // 매핑저장조건
            ds_output_1: {},

            FV_FORTAL_ID: '',
            FV_OP_DT: '',
            FV_OP_TM: '',
            FV_SEQ: '',
            FV_D14_YN: '',

            ds_cust_info: {},
        }
    },

    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },

    watch: {
        parentParam: {
            handler: function (value) {
                ////?????/?
                this.reqParam.edt_UserNm = value['edt_UserNm']
                this.reqParam.edt_PortalId = value['edt_PortalId']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },

    created() {
        this.init()
    },

    async mounted() {
        this.gridObj = this.$refs.grid1
        this.initGrid()
    },

    methods: {
        async init() {
            this.gridData = this.GridSetData()
            this.reqParam.portalID = this.props.parentParam.portalID
            // 모화면 데이터 셋팅 + 사용자명 셋팅
            this.reqParam = this.props.parentParam
            this.reqParam.userNm = ''
            this.FV_FORTAL_ID = this.props.parentParam.portalId
            this.FV_OP_DT = this.props.parentParam.opDt
            this.FV_OP_TM = this.props.parentParam.opTm
            this.FV_SEQ = this.props.parentParam.seq
            this.FV_D14_YN = this.props.parentParam.d14Yn
        },

        async initGrid() {
            this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj.setGridState()

            CommonMsg.$_log('init 함수호출')

            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },

        onInput(node) {
            console.log('input: ', node)
        },
        onActive(node) {
            console.log('active: ', node)
            if (node.length > 0) {
                this.selectedItem = _.clone(node[0])
            }
        },
        onOpen(node) {
            console.log('open: ', node)
        },
        //GridSet Init
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수),
            return new CommonGrid(-1, -1, 10, 0, '')
        },

        onChange(value) {
            console.log('onChange: ', value)
        },

        //조회 이벤트
        getList: function () {
            console.log('this.reqParam : ', this.reqParam)
            API.getMappingUserList(this.reqParam).then((resultData) => {
                this.ds_output_1 = resultData
                console.log('resultData : ', resultData.length)
                // INDEX 셋팅
                if (resultData.length > 0) {
                    for (let index = 0; index < resultData.length; index++) {
                        resultData[index].NO = index + 1
                    }
                } else if (resultData.length === 0) {
                    alert('데이터가 없습니다')
                }
                // Get Row Data
                this.gridObj.setRows(resultData)

                console.log('조회완료')
            })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showAlertBool = true
                this.headerText = '거래처 선택'
                this.alertBodyText = '거래처을 선택해주세요.'
                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()

            // let copy1 = this.clone(this.selectedItem)
            // this.$emit('confirm', copy1)
            // this.onClose()
        },

        clone(obj) {
            if (null == obj || 'object' != typeof obj) return obj
            let copy = Object.create(null)
            for (let attr in obj) {
                if (obj.hasOwnProperty.call(obj, attr)) copy[attr] = obj[attr]
            }
            return copy
        },

        onClose() {
            this.activeOpen = false
        },

        onSearch() {
            this.getList()
        },

        // 초기화
        onResetPage() {
            CommonUtil.clearPage(this.$router)
        },

        // mapping정보 저장
        onSave() {
            console.log('onSave')
            this.saveMapping_OnClick()
            this.onClose()
        },

        // mapping정보 저장
        saveMapping_OnClick() {
            for (let i = 0; i < this.ds_output_1.length; i++) {
                if (this.ds_output_1.check === '1') {
                    this.ds_output_1 = {
                        effStaDt: this.getToday(),
                        effEndDt: '20301231',
                        auditUserId: '', // ukeyId
                        auditDtm: '',
                        transDtm: '',
                    }
                }
            }

            let saveParam = {
                d14Yn: this.FV_D14_YN,
                portalId: this.FV_PORTAL_ID,
            }

            // 고객정보사용관리 데이터셋팅
            this.cust_info_set()

            console.log('saveParam : ', saveParam)
            API.saveMappingUser(saveParam).then((resultData) => {
                console.log('resultData : ', resultData.length)
                // INDEX 셋팅
                alert('저장완료')
            })
        },

        // 고객정보사용관리 데이터셋팅
        cust_info_set() {
            // 고객정보항목
            // let sCustInfoItem = '' //고객정보컬럼
            // let sCustInfoKey = '' // 필수조회조건

            this.ds_cust_info = {
                userId: '', // 세션정보
                tranDtm: '',
                connIp: '', // 세션정보
                dataCl: '',
                actionCl: '',
                custInfo: '',
                queryCl: '',
                queryCond: '',
                screenId: '', //BASUSM01710
                rmks: '',
            }
        },

        onEnterKey() {
            this.onSearch()
        },

        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            var date = new Date()
            var year = date.getFullYear()
            var month = ('0' + (1 + date.getMonth())).slice(-2)
            var day = ('0' + date.getDate()).slice(-2)

            return year + '-' + month + '-' + day
        },
    },
}
</script>
