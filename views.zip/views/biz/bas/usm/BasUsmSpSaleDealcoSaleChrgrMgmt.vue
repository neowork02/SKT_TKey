<template>
    <div class="content">
        <h1>특판처영업담당자관리</h1>
    </div>
</template>

<script>
export default {
    name: 'SpSaleDealcoSaleChrgrMgmt',
}
</script>

<style scoped></style>
