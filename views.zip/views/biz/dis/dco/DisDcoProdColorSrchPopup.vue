<!-----------------------------------------------
 * 업무그룹명: 상품색상조회팝업
 * 서브업무명: 상품색상조회팝업
 * 설명: 상품색상조회한다.
 * 작성자: P179229
 * 작성일: 2022.05.04
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="300px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">상품색상조회</p>
                <div class="layerCont">
                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="colorPopupGridHeader"
                            ref="colorPopupGridHeader"
                            gridTitle="상품색상"
                            :gridObj="gridObj"
                        />
                        <div class="gridWrap">
                            <TCRealGrid
                                id="colorPopupGrid"
                                ref="colorPopupGrid"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                    </div>
                    <!-- //gridWrap -->
                    <!-- btn -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="addBtn"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!-- // btn -->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { DisDcoProdColorSrchGRID_HEADER } from '@/const/grid/dis/dco/disDcoProdColorSrchPopupHeader'
import disDcoProdInsInApi from '@/api/biz/dis/dco/disDcoProdInsIn'
import CommonMixin from '@/mixins'

export default {
    name: 'DisDcoProdColorSrchPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        parentParam: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            gridData: this.gridSetData(),
            objAuth: {},
            view: DisDcoProdColorSrchGRID_HEADER,
            gridObj: {},
            gridHeaderObj: {},
            alertBool: false,
            alertBodyTxt: '',
            alertHeaderTxt: '',
            reqParam: {
                prodCd: '',
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log(value)
                this.reqParam.prodCd =
                    value['prodCd'] !== undefined ? value['prodCd'] : ''
                this.searchDisDcoProdColor()
            },
            deep: true,
            immediate: true,
        },
    },
    created() {},
    mounted() {
        this.gridObj = this.$refs.colorPopupGrid
        this.gridHeaderObj = this.$refs.colorPopupGridHeader
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setCheckBar({
            exclusive: true,
        })
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked
    },
    methods: {
        /* 그리드 설정 */
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(-1, 10, '', '')
        },
        /* 상품검색 조회 - 최초 */
        searchDisDcoProdColor() {
            disDcoProdInsInApi.getDisDcoProdColor(this.reqParam).then((res) => {
                this.gridObj.setRows(res.disDcoProdColorVo)
            })
        },
        /* 확인 */
        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('색상을 선택해주세요.')
                return
            }

            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )

            this.$emit('confirm', jsonData)
            this.onClose()
        },
        addBtn() {
            var chkRow = this.gridObj.gridView.getCheckedRows(true)
            if (chkRow.length == 0) {
                this.showTcComAlert('색상을 선택해주세요.')
                return
            }

            for (var i = 0; i < chkRow.length; i++) {
                const jsonData = this.gridObj.dataProvider.getJsonRow(chkRow[i])
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        /* 그리드 설정 -셀 더블클릭 시 부모로 값 이동 */
        onCellDblClicked() {
            this.onConfirm()
        },
        onClose: function () {
            this.activeOpen = false
        },
    },
}
</script>
