<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : RmtAccAccRptPolDtlPopup.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="statusShow" size="1400px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">정산 Report 정책상세</p>

                <!-- Popup_Cont -->
                <div class="layerCont">
                    <AccGridTable
                        ref="accGridTable"
                        noPaging
                        :offset="['btn-excelDownload']"
                        :title="`정산처코드 : ${param.accPlc} 정산처명 : ${param.accPlcNm}`"
                        :gridMeta="GRID_HEADER"
                        :data="data"
                        :exportInfo="{
                            uri: `/api/v1/backend-max/resource/rmt/acc/polish-reports-excel-down-load`,
                            query: query,
                        }"
                    />

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">&nbsp;</div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <button
                        type="button"
                        class="layerClose b-close"
                        @click="closePopup"
                    >
                        닫기
                    </button>
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>
<style lang="scss" scoped></style>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'
// import { getCalcDays, filter } from '@/utils/accUtil'

import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import rmtApi from '@/api/biz/rmt/acc'

import { GRID_HEADER } from '@/const/grid/rmt/acc/rmtAccAccRptPolDtlPopupGrid'

export default {
    name: 'RmtAccAccRptPolDtlPopup',
    mixins: [CommonMixin, accMixin],
    components: { AccGridTable },
    props: {
        status: {
            default: false,
        },

        param: {
            default: () => ({
                accPlc: '',
                accPlcNm: '',
            }),
        },
    },
    data() {
        return {
            GRID_HEADER,
            query: {},
            data: [],
        }
    },

    computed: {
        statusShow: {
            get() {
                return this.status
            },
            set(value) {
                this.$emit('update:status', value)
            },
        },
    },

    watch: {},

    created() {},
    mounted() {
        this.initPage()
    },
    methods: {
        initPage() {
            Object.keys(this.param).forEach((arr) => {
                if (this.param[arr]) this.query[arr] = this.param[arr]
            })

            this.getRmtAccPolishReports()
        },

        closePopup() {
            this.statusShow = false
        },

        getRmtAccPolishReports() {
            return rmtApi.getRmtAccPolishReports(this.query).then((res) => {
                this.data = res.polishRptVoList
            })
        },
    },
}
</script>
