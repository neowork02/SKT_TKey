import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orglvl', // 조직레벨
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'adjStCd', // 상태 (조정상태코드)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtm', // 판매일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wrtDt', // 전기일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arClCd', // 코드명(매출항목)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleShopCd', // 판매처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd', // 판매처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoNm', // 판매처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품 (단말기 모델)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleQty', // 수량
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleAmt', // 판매가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'splyPrc', // 공급가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rmks', // 조정사유
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId', // 요청자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDtm', // 요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleClCd', // 코드명(판매구분)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlCd', // 코드명(영업채널)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 정산처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxClCd', // 세금구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', // 서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBilId', // 발행ID (세금계산서)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBilSeq', // 발행순번(세금계산서)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refId', // 참고ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refSeq', // 참고순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgRefId', // 원참고ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgRefSeq', // 원참고순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cfmUserId', // 승인자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvDtm', // 승인일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arClNm', // 코드명(매출항목)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleClNm', // 코드명(판매구분)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlNm', // 코드명(영업채널)
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        // {
        //     name: 'adjStCd',
        //     fieldName: 'adjStCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '상태',
        // },
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'wrtDt',
            fieldName: 'wrtDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전기일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'arClNm',
            fieldName: 'arClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매출항목',
        },
        {
            name: 'saleShopCd',
            fieldName: 'saleShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처매장코드',
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처',
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처명',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'saleQty',
            fieldName: 'saleQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '수량',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매가',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공급가',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '부가세',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '조정사유',
        },
        {
            name: 'reqUserId',
            fieldName: 'reqUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청자',
        },
        {
            name: 'reqDtm',
            fieldName: 'reqDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청일시',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'saleClNm',
            fieldName: 'saleClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매구분',
        },
        {
            name: 'saleChnlNm',
            fieldName: 'saleChnlNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '영업채널',
        },
        {
            name: 'accShopCd',
            fieldName: 'accShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처매장코드',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처명',
        },
        {
            name: 'taxClCd',
            fieldName: 'taxClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '세금구분',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '서비스관리번호',
        },
        {
            name: 'taxBilId',
            fieldName: 'taxBilId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발행ID',
        },
        {
            name: 'taxBilSeq',
            fieldName: 'taxBilSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발행순번',
        },
        {
            name: 'refId',
            fieldName: 'refId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '참고ID',
        },
        {
            name: 'refSeq',
            fieldName: 'refSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '참고순번',
        },
        {
            name: 'orgRefId',
            fieldName: 'orgRefId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '원참고ID',
        },
        {
            name: 'orgRefSeq',
            fieldName: 'orgRefSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '원참고순번',
        },
        // {
        //     name: 'cfmUserId',
        //     fieldName: 'cfmUserId',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '승인자',
        // },
        // {
        //     name: 'aprvDtm',
        //     fieldName: 'aprvDtm',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '승인일시',
        //     textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        // },
    ],
    layout: [
        // 'adjStCd',
        'saleDtm',
        'wrtDt',
        'arClNm',
        'saleDealcoCd',
        'saleDealcoNm',
        'prodNm',
        'saleQty',
        'saleAmt',
        'splyPrc',
        'vatAmt',
        'rmks',
        'reqUserId',
        'reqDtm',
        'saleClNm',
        'saleChnlNm',
        'accDealcoCd',
        'accDealcoNm',
        'taxClCd',
        'svcMgmtNum',
        {
            name: '세금계산서',
            direction: 'horizontal',
            items: ['taxBilId', 'taxBilSeq'],
        },
        'refId',
        'refSeq',
        'orgRefId',
        'orgRefSeq',
        // 'cfmUserId',
        // 'aprvDtm',
    ],
}
