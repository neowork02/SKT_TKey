import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, // 보유처명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'errCtt',
            dataType: ValueType.TEXT, // 오류내용
        },
    ],
    columns: [
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '보유처코드',
            },
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '보유처명',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '모델코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '모델명',
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상코드',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상명',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'errCtt',
            fieldName: 'errCtt',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '오류사항',
            },
        },
    ],
}
