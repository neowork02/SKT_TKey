<template>
    <div>
        <!-- SubTit  -->
        <div class="stitHead pop">
            <h4 class="subTit">기본정보</h4>
        </div>
        <!-- //SubTit -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="strdInfo.dealcoCd"
                        labelName="거래처코드"
                        :disabled="true"
                        @input="setData"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="strdInfo.dealcoRgstClCd"
                        :readonly="true"
                        labelName="등록구분"
                        :eRequired="true"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :objAuth="objAuth"
                        :itemList="dealcoRgstClCdList"
                        :filterFunc="filterRgstClCd"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="strdInfo.dealcoGrpCd"
                        :readonly="true"
                        labelName="거래처그룹"
                        :eRequired="true"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :objAuth="objAuth"
                        :itemList="dealcoGrpCdList"
                        @change="changeDealcoCl"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="strdInfo.dealcoClCd1"
                        :readonly="true"
                        labelName="거래처구분"
                        :eRequired="true"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :objAuth="objAuth"
                        :itemList="dealcoClList"
                        @change="changeDealcoCl2"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-3 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 1-4 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="strdInfo.dealcoNm"
                        :readonly="true"
                        labelName="거래처명"
                        :eRequired="true"
                        @input="setData"
                    />
                </div>
                <!-- //item 1-4 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        v-model="strdInfo.dealStaDt"
                        :disabled="isDealEndDt"
                        labelName="시작일"
                        :eRequired="true"
                        @input="setData"
                    />
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        v-model="strdInfo.dealEndDt"
                        :disabled="isDealEndDt"
                        labelName="종료일"
                        :eRequired="true"
                        @input="setData"
                    />
                </div>
                <!-- //item 2-3 -->
                <!-- item 2-3 -->
                <!--                <div class="formitem div4">-->
                <!--                    <TCComInput-->
                <!--                        v-model="strdInfo.wgs84XCodnVal"-->
                <!--                        labelName="매장좌표X"-->
                <!--                        :readonly="true"-->
                <!--                        @input="setData"-->
                <!--                    />-->
                <!--                </div>-->
                <!-- //item 2-3 -->
                <div class="formitem div4"></div>
            </div>
            <!-- //Search_line 2 -->
            <div class="searchform">
                <!--                <div class="formitem div4">-->
                <!--                    <TCComInput-->
                <!--                        v-model="strdInfo.wgs84YCodnVal"-->
                <!--                        labelName="매장좌표Y"-->
                <!--                        :readonly="true"-->
                <!--                        @input="setData"-->
                <!--                    />-->
                <!--                </div>-->
            </div>
            <!-- //Search_line 2 -->

            <div class="searchform">
                <!-- item 10-1 -->
                <div class="formitem div1">
                    <!-- label + 멀티폼_주소 -->
                    <div class="multiFormAddress">
                        <div class="col1">
                            <TCComInputSearch
                                labelName="주소"
                                :readonly="true"
                                :eRequired="true"
                                v-model="strdInfo.signZipCd"
                                @input="setData"
                                :objAuth="objAuth"
                            />
                            <!--                            <BasBcoNewZipSrchPopup1-->
                            <!--                                v-if="showBcoNewZipSrch1"-->
                            <!--                                :rows="resultNewZipSrchRows1"-->
                            <!--                                :dialogShow.sync="showBcoNewZipSrch1"-->
                            <!--                                :parentParam="searchNewZipSrchParam1"-->
                            <!--                                @confirm="onNewZipSrchSReturnData1"-->
                            <!--                                :objAuth="objAuth"-->
                            <!--                            />-->
                        </div>
                        <div class="col2">
                            <TCComTextField
                                class="inBlock w100"
                                v-model="strdInfo.signAddr"
                                :readonly="true"
                                @input="setData"
                                :objAuth="objAuth"
                            />
                        </div>
                        <div class="col3">
                            <TCComTextField
                                class="inBlock w100"
                                :eRequired="true"
                                :readonly="true"
                                v-model="strdInfo.signDtlAddr"
                                @input="setData"
                                :objAuth="objAuth"
                            />
                        </div>
                    </div>
                    <!-- // label + 멀티폼_주소 -->
                </div>
                <!-- //item 10-1 -->
            </div>
            <!-- Search_line 3 -->
            <div class="searchform">
                <!-- item 3-1 -->
                <div class="formitem div4">
                    <TCComCheckBox
                        labelName="거래상태"
                        :readonly="true"
                        :eRequired="true"
                        id="comCheck1"
                        ref="comCheck1"
                        v-model="strdInfo.dealStatus"
                        :itemList="zbasC00120"
                        @change="changeRsnCd"
                        @click="clickRsnCd"
                        :filterFunc="filterRsnCd"
                    />
                </div>
                <!-- //item 3-1 -->
            </div>
            <!-- //Search_line 3 -->
        </div>
        <!-- //Search_div -->
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dirDlvMgmt/helpers'
import _ from 'lodash'

import moment from 'moment'

//====================우편번호팝업====================

import basBcoNewZipSrchApi1 from '@/api/biz/bas/bco/basBcoNewZipSrch'
//====================//우편번호팝업====================

export default {
    name: 'StrdInfoContainer',
    components: {},
    props: {},
    data() {
        return {
            objAuth: {},
            rsnList: [],
            storeKey: 'strdInfoData',
            isChk: true,
            isDealEndDt: true,
            dealcoGrpCdList: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처그룹
            dealcoClList: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처구분
            isAy: true, // 거래처그룹이 직영매장인 경우 false
            strdInfo: {
                dealcoCd: '',
                dealcoRgstClCd: '',
                dealcoGrpCd: '',
                dealcoClCd1: '',
                dealcoNm: '',

                dealStatus: [],
                dealStaDt: '',
                dealEndDt: '',

                normalYn: '',
                payStopYn: '',
                outStopYn: '',
                saleStopYn: '',
                sttlEndYn: '',
                drwStopYn: '',
                dealEndYn: '',

                wgs84XCodnVal: '',
                wgs84YCodnVal: '',

                signZipCd: '',
                signAddr: '',
                signDtlAddr: '',
            },
            dealcoCl2CodeId: '', // 거래처유형코드
            //====================우편번호팝업관련====================
            showBcoNewZipSrch1: false, // 팝업 오픈 여부
            searchNewZipSrchParam1: {
                signAddr: '',
                signDtlAddr: '',
            },
            resultNewZipSrchRows1: [], //

            //====================//우편번호팝업관련==================
        }
    },
    computed: {
        ...serviceComputed,
        reqParam: {
            get() {
                return this.reqParams
            },
        },
        isDisabledDataUKey1: {
            get() {
                return this.isDisabledDataUKey
            },
        },
        initParam: {
            get() {
                return this.initParams
            },
        },
        dealcoClList1: {
            get() {
                return this.dealcoClList_1
            },
        },
        initList1: {
            get() {
                return this.initList
            },
        },

        //==================== 상세데이터 ==================
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
        //==================== //상세데이터 ==================
        ////////////////// 공통코드 조회
        dealcoRgstClCdList: {
            get() {
                return this.DEALCO_RGST_CL_CD // 거래처등록구분
            },
        },
        dealcoGrpList1: {
            get() {
                return this.DEAL_CO_GRP // 거래처그룹
            },
        },
        zbasC00240: {
            get() {
                return this.ZBAS_C_00240 // 거래처구분
            },
        },
        zbasC00510: {
            get() {
                return this.ZBAS_C_00510 // 거래처유형 (판매점구분)
            },
        },
        zbasC00570: {
            get() {
                return this.ZBAS_C_00570 // 거래처유형 (직영점구분)
            },
        },
        zbasC00530: {
            get() {
                return this.ZBAS_C_00530 // 거래처분류
            },
        },
        zbasC00590: {
            get() {
                return this.ZBAS_C_00590 // 거래처분류 (직영점2차점 거래처분류)
            },
        },
        zbasC00110: {
            get() {
                return this.ZBAS_C_00110 // 전자결재 진행여부
            },
        },
        zbasC00130: {
            get() {
                return this.ZBAS_C_00130 // 전자결재 진행여부
            },
        },
        zbasC00120: {
            get() {
                return this.ZBAS_C_00120 // 전자결재 진행여부
            },
        },
        zbasC00400: {
            get() {
                return this.ZBAS_C_00400 //
            },
        },
        zbasC00710: {
            get() {
                return this.ZBAS_C_00710 //
            },
        },
        zbasC00230: {
            get() {
                return this.ZBAS_C_00230 //
            },
        },
        spClsBizClCd: {
            get() {
                return this.SP_CLS_BIZ_CL_CD // 전자결재 진행여부
            },
        },
        comYn: {
            get() {
                return this.COM_YN // 전자결재 진행여부
            },
        },
        ////////////////// 공통코드 조회
        isGridBizRgstInfo1: {
            get() {
                return this.isGridBizRgstInfo
            },
        },
    },
    mounted() {
        this.initData()
    },
    methods: {
        ...serviceMethods,
        initData() {
            this.strdInfo = {
                dealcoCd: '',
                dealcoRgstClCd: '',
                dealcoGrpCd: '',
                dealcoClCd1: '',
                dealcoNm: '',

                dealStatus: [],
                dealStaDt: '',
                dealEndDt: '',

                normalYn: '',
                payStopYn: '',
                outStopYn: '',
                saleStopYn: '',
                sttlEndYn: '',
                drwStopYn: '',
                dealEndYn: '',

                wgs84XCodnVal: '',
                wgs84YCodnVal: '',

                signZipCd: '',
                signAddr: '',
                signDtlAddr: '',
            }
            if (!this.initParam.pIsNew) {
                this.strdInfo.dealStatus = ['1']
            }
            this.isAy = true
        },
        setData() {
            let params = { ...this.strdInfo }
            this.storeSet(this.storeKey, params)
        },
        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        isDisabled(key, isDisabled) {
            this.defaultAssign_({
                key: key,
                value: isDisabled,
            })
        },

        changeRsnCd(items) {
            _.forEach(items, (data) => {
                if (_.isEqual(data, '1')) {
                    this.isChk = true
                    this.isDealEndDt = true
                    this.strdInfo.dealStatus = []
                    this.strdInfo.dealStatus[0] = '1'
                    this.strdInfo.dealEndDt = ''
                } else if (_.isEqual(data, '5')) {
                    this.strdInfo.dealStatus = []
                    this.strdInfo.dealStatus[0] = '5'
                    this.isDealEndDt = false
                    this.strdInfo.dealEndDt = moment(new Date()).format(
                        'YYYY-MM-DD'
                    )
                } else if (!_.isEqual(data, '1')) {
                    if (this.isChk) {
                        this.isChk = false
                        this.isDealEndDt = true
                        this.strdInfo.dealStatus = []
                        this.strdInfo.dealStatus[0] = data
                        this.strdInfo.dealEndDt = ''
                    }
                } else {
                    this.isChk = false
                    this.isDealEndDt = true

                    this.strdInfo.dealEndDt = ''
                }
                let param = { ...this.strdInfo }
                this.storeSet(this.storeKey, param)
            })
        },
        clickRsnCd() {
            if (
                this.initParam.pIsNew && // 상세
                !_.isEqual(this.strdInfo.dealStatus[0], '5') // 거래종료
            ) {
                this.strdInfo.dealEndDt = '9999-12-31'
            }
            let param = { ...this.strdInfo }
            this.storeSet(this.storeKey, param)
        },
        getFilterCode(codeList, codes) {
            let rtnCode = []

            codes.forEach((code) => {
                _.forEach(codeList, (data) => {
                    if (_.isEqual(data.commCdVal, code)) {
                        // 매장공통이면서 직영매장일 경우 거래처구분은 readonly false
                        if (
                            !this.initParam.pIsNew ||
                            (_.isEqual(this.strdInfo.dealcoRgstClCd, 'DC') &&
                                _.isEqual(code, 'AY'))
                        ) {
                            this.isAy = false
                        } else if (_.isEqual(this.reqParam.ifYn, 'N')) {
                            this.isAy = false
                        }
                        rtnCode.push(data)
                    }
                })
            })
            return rtnCode
        },
        /**
         * 거래처그룹코드 셋팅
         * DC : 매장공통
         * DS : 매장개별
         * EC : 기타공통
         * ES : 기타개별
         * @param dealcoRgstClCd : 거래처등록구분코드
         */
        setDealcoGrpCd(dealcoRgstClCd) {
            let dealcoGrpCds = [{ commCdVal: '', commCdValNm: '전체' }]
            let paramDealcoRgstClCd = this.strdInfo.dealcoRgstClCd
            if (!_.isEmpty(paramDealcoRgstClCd)) {
                dealcoRgstClCd = paramDealcoRgstClCd
            }

            let codes = []
            if (_.isEqual(dealcoRgstClCd, 'DC')) {
                // 매장공통
                codes = ['AY', 'YY', '8X'] // 직영(AY), 하부망(YY), 대형유통(8X)
            } else if (_.isEqual(dealcoRgstClCd, 'DS')) {
                // 매장개별
                codes = ['XZ', 'ZZ'] // 기타(1)(XZ), 물류창고(ZZ)
            } else if (_.isEqual(dealcoRgstClCd, 'EC')) {
                // 기타공통
                codes = ['2X', '7X'] // 제조사(2X), 금융사(7X)
            } else if (_.isEqual(dealcoRgstClCd, 'ES')) {
                // 기타개별
                codes = ['XX'] // 기타(XX)
            }
            if (codes.length > 0) {
                dealcoGrpCds = this.getFilterCode(this.DEAL_CO_GRP, codes)
            }
            this.dealcoGrpCdList = dealcoGrpCds
        },
        filterRgstClCd(items) {
            if (!this.initParam.pIsNew) {
                return items.filter(
                    (item) => _.isEqual(item['commCdVal'], 'DS') // 매장개별
                )
            } else if (this.initParam.pIsNew) {
                if (_.isEqual(this.reqParam.ifYn, 'Y')) {
                    return items.filter(
                        (item) => _.isEqual(item['commCdVal'], 'DC') // 매장공통
                    )
                } else {
                    return items.filter(
                        (item) =>
                            _.isEqual(item['commCdVal'], 'DS') ||
                            _.isEqual(item['commCdVal'], 'DC') // 매장개별
                    )
                }
            } else {
                return items.filter(
                    (item) => !_.isEqual(item['addInfo1'], 'ETC')
                )
            }
        },
        filterRsnCd(items) {
            return items.filter(
                (item) =>
                    _.isEqual(item['commCdVal'], '1') ||
                    _.isEqual(item['commCdVal'], '5')
            )
            // if (!this.initParam.pIsNew) {
            /*
            return items.filter(
                // (item) => !_.isEqual(item['commCdVal'], '5')
                (item) =>
                    _.isEqual(item['commCdVal'], '1') ||
                    _.isEqual(item['commCdVal'], '5')
            )
        } else if (this.initParam.pIsNew) {
            let data1 = items.filter(
                (item) => !_.isEqual(item['commCdVal'], '5')
            )

            let data2 = Object.assign(
                {},
                items.filter((item) => _.isEqual(item['commCdVal'], '5'))
            )
            data1.push(data2[0])

            return data1
        } else {
            return items
        } */
        },

        //////////////////// 거래처그룹 이벤트 함수 ////////////////////////
        // 거래처그룹 Change 이벤트
        changeDealcoCl() {
            // 거래처그룹
            this.getDealcoClList() // 거래처 유형 조회
        },
        // 거래처구분 Change 이벤트
        changeDealcoCl2(dealcoCl) {
            // 거래처유형 코드 구하기
            this.getDealcoCl2CodeId(dealcoCl)
            this.getDealcoCl2List() // 거래처 유형 조회

            // 거래처분류 조회
            this.getDealcoCl3List() // 거래처 분류 조회
        },

        // 거래처 유형 코드조회
        getDealcoCl2CodeId(dealcoCl) {
            let dealcoGrpCd = ''
            let addInfoYn = ''

            _.forEach(this.dealcoClList1, (data) => {
                if (_.isEqual(dealcoCl, data.commCdVal)) {
                    dealcoGrpCd = data.addInfo1
                    addInfoYn = data.addInfo4
                }
            })
            /**
             * dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */
            if (_.isEqual(dealcoGrpCd, 'AY')) {
                if (_.isEqual(addInfoYn, 'Y')) {
                    this.dealcoCl2CodeId = this.zbasC00110
                } else if (_.isEqual(addInfoYn, 'N')) {
                    this.dealcoCl2CodeId = this.zbasC00570
                }

                this.isDisabled('isDisabledDataDealcoCl2_1', false)
                this.strdInfo.dealcoCl2 = ''

                if (
                    _.isEqual(dealcoCl, 'A2') ||
                    _.isEqual(dealcoCl, 'B1') ||
                    _.isEqual(dealcoCl, 'AD') ||
                    _.isEqual(dealcoCl, 'AE')
                ) {
                    this.isDisabled('isDisabledDataSisYn_1', true)
                } else {
                    this.isDisabled('isDisabledDataSisYn_1', false)
                }
            } else if (_.isEqual(dealcoGrpCd, 'YY')) {
                this.dealcoCl2CodeId = this.zbasC00110
                this.isDisabled('isDisabledDataDealcoCl2_1', false)
                this.strdInfo.dealcoCl2 = ''

                if (_.isEqual(dealcoCl, 'M1') || _.isEqual(dealcoCl, 'M2')) {
                    // MA || B&C MA
                    this.isDisabled('isDisabledDataMaDirectYn_1', false)
                } else {
                    this.isDisabled('isDisabledDataMaDirectYn_1', true)

                    this.strdInfo.maDirectYn = '' // 초기화
                }
            } else if (_.isEqual(dealcoGrpCd, 'ZZ')) {
                this.dealcoCl2CodeId = this.zbasC00110

                this.isDisabled('isDisabledDataDealcoCl2_1', false)

                this.strdInfo.dealcoCl2 = ''
            }
            let param = { ...this.strdInfo }
            this.storeSet(this.storeKey, param)
        },
        // 거래처구분 조회
        getDealcoClList() {
            this.show() // ON/OFF

            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]

            /**
             * addInfo1
             * 3X : 매입처
             * 2X : 제조사
             */
            _.forEach(this.zbasC00240, (data) => {
                if (_.isEqual(data.addInfo1, this.strdInfo.dealcoGrpCd)) {
                    defaultData.push(data)
                }
            })

            this.dealcoClList = defaultData
            let params = { ...this.strdInfo }
            this.storeSet(this.storeKey, params)
            this.storeSet('dealcoClList_1', defaultData)
            this.isDisabled('isDisabledDataDealcoCl2_1', true)
            this.isDisabled('isDisabledDataDealcoCl3_1', true)
            this.storeSet('dealcoCl2List_1', this.initList1) // 초기화
        },
        // 거래처유형 조회
        getDealcoCl2List() {
            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]

            /**
             * strdInfo.dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */
            _.forEach(this.dealcoCl2CodeId, (data) => {
                if (_.isEqual(this.strdInfo.dealcoGrpCd, 'AY')) {
                    if (
                        _.isEqual(
                            data.addInfo1,
                            'Y' || _.isEmpty(data.addInfo1)
                        ) &&
                        _.isEqual(data.commCdId, 'ZBAS_C_00110')
                    ) {
                        defaultData.push(data)
                    } else if (_.isEqual(data.commCdId, 'ZBAS_C_00570')) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.strdInfo.dealcoGrpCd, 'YY')) {
                    if (
                        _.isEqual(
                            data.addInfo2,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.strdInfo.dealcoGrpCd, 'ZZ')) {
                    if (
                        _.isEqual(
                            data.addInfo3,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                }
            })
            let params = { ...this.strdInfo }
            this.storeSet(this.storeKey, params)
            this.storeSet('dealcoCl2List_1', defaultData)
            this.isDisabled('isDisabledDataBankCdYn', true) // 출금계좌 off
        },
        // 거래처분류 조회
        getDealcoCl3List() {
            const defaultData = [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
            ]
            /**
             * strdInfo.dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             */
            _.forEach(this.zbasC00530, (data) => {
                if (_.isEqual(this.strdInfo.dealcoGrpCd, 'AY')) {
                    if (
                        _.isEqual(
                            data.addInfo1,
                            'Y' || _.isEmpty(data.addInfo1)
                        ) &&
                        _.isEqual(data.commCdId, 'ZBAS_C_00110')
                    ) {
                        defaultData.push(data)
                    } else if (_.isEqual(data.commCdId, 'ZBAS_C_00570')) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.strdInfo.dealcoGrpCd, 'YY')) {
                    if (
                        _.isEqual(
                            data.addInfo2,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                } else if (_.isEqual(this.strdInfo.dealcoGrpCd, 'ZZ')) {
                    if (
                        _.isEqual(
                            data.addInfo3,
                            'Y' || _.isEmpty(data.addInfo1)
                        )
                    ) {
                        defaultData.push(data)
                    }
                }
            })

            let params = { ...this.strdInfo }
            this.storeSet(this.storeKey, params)
            if (defaultData.length > 1 && _.isEmpty(defaultData[1].commCdVal)) {
                this.isDisabled('isDisabledDataDealcoCl3_1', true) // 거래처구분 off
                this.isDisabled('isDisabledDataBankCdYn', true) // 출금계좌 off
            }
            this.storeSet('dealcoCl3List_1', defaultData)
        },

        async show() {
            /**
             * dealcoGrpCd
             * AY : 직영매장
             * YY : 하부망
             * ZZ : 물류창고
             * AX : 대리점
             */
            let isDataSknDelvYn = true // skn 직배송여부 OFF
            let isDataExcYn = true // skn 전속점여부 OFF
            if (
                _.isEqual(this.strdInfo.dealcoGrpCd, 'ZZ') ||
                _.isEqual(this.strdInfo.dealcoGrpCd, 'AY') ||
                _.isEqual(this.strdInfo.dealcoGrpCd, 'YY')
            ) {
                if (_.isEqual(this.strdInfo.dealcoGrpCd, 'ZZ')) {
                    isDataSknDelvYn = false // skn 직배송여부 ON
                    isDataExcYn = true // skn 직배송여부 OFF
                } else if (_.isEqual(this.strdInfo.dealcoGrpCd, 'YY')) {
                    isDataSknDelvYn = true // skn 직배송여부 OFF
                    isDataExcYn = false // skn 직배송여부 OFF
                }
            }

            this.isDisabled('isDisabledDataSknDelvYn', isDataSknDelvYn) // skn 직배송여부
            this.isDisabled('isDisabledDataExcYn', isDataExcYn) //  skn 전속점여부
        },
        //////////////////// 거래처그룹 이벤트 함수 ////////////////////////
        //===================== 우편번호팝업관련 methods ================================
        sameAddress(type) {
            if (_.isEqual(type[0], 'Y')) {
                // 매장주소
                this.strdInfo.signZipCd = this.bizRgstInfoData.zipCd
                this.strdInfo.signAddr = this.bizRgstInfoData.addr
                this.strdInfo.signDtlAddr = this.bizRgstInfoData.dtlAddr
            } else {
                // 매장주소
                this.strdInfo.signZipCd = ''
                this.strdInfo.signAddr = ''
                this.strdInfo.signDtlAddr = ''
            }
            let param = { ...this.strdInfo }
            this.storeSet(this.storeKey, param)
        },
        replaceStreetNm(returnData, path) {
            let street
            if (!_.isEmpty(path)) {
                street = _.get(returnData, path) + ' '
            }
            return street
        },
        getZipList1() {
            let searchParam = {}
            searchParam['streetNm'] = this.strdInfo.signAddr
            basBcoNewZipSrchApi1.getNewZipCode(searchParam).then((res) => {
                if (!_.isEmpty(res)) {
                    this.strdInfo.signAddr = _.get(res[0], 'streetNm')
                    this.strdInfo.signDtlAddr = _.get(res[0], 'siGunGuBldnNm')
                } else {
                    this.resultNewZipSrchRows1 = res
                    this.searchNewZipSrchParam1.signAddr =
                        this.strdInfo.signAddr
                    this.searchNewZipSrchParam1.signDtlAddr =
                        this.strdInfo.signDtlAddr
                    this.showBcoAgencys1 = true
                }
            })
        },
        // 사용자 TextField 돋보기 Icon 이벤트 처리
        onNewZipSrchClick1() {
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultNewZipSrchRows1 = []
            if (!_.isEmpty(this.strdInfo.signAddr)) {
                // API 호출
                //this.getZipList()
            } else {
                this.searchNewZipSrchParam1.signAddr = this.strdInfo.signAddr
                this.searchNewZipSrchParam1.signDtlAddr =
                    this.strdInfo.signDtlAddr

                this.showBcoNewZipSrch1 = true
            }
        },
        // 주소 TextField 엔터키 이벤트 처리
        onNewZipSrchEnterKey1() {
            // 주소 팝업 Row 설정 Prop 변수 초기화
            this.resultNewZipSrchRows1 = []
            // 검색조건 주소 빈값이면 알림창 오픈
            if (_.isEmpty(this.strdInfo.signAddr)) {
                this.showTcComAlert('도로명을 입력해주세요.')
                return false
            }
            // 주소 정보 조회
            this.getZipList1()
        },
        onNewZipSrchSReturnData1(returnData) {
            let streetNm =
                this.replaceStreetNm(returnData, 'siDoNm') +
                this.replaceStreetNm(returnData, 'siGunGuNm') +
                this.replaceStreetNm(returnData, 'streetNm')

            this.strdInfo.signZipCd = _.get(returnData, 'zipCd')
            this.strdInfo.signAddr = streetNm.trim()
            this.strdInfo.signDtlAddr = _.get(returnData, 'siGunGuBldnNm')
            let param = { ...this.strdInfo }
            this.storeSet(this.storeKey, param)
        },
        //===================== 우편번호팝업관련 methods ================================
    },
    watch: {
        basPrmDealcoDtlVo: {
            handler: function (values) {
                if (_.isEmpty(values)) {
                    if (
                        !this.initParam.pIsNew || // 상세가 아니거나
                        _.isEqual(this.reqParam.ifYn, 'Y') // 인터페이스인 경우
                    ) {
                        this.strdInfo.dealStatus = ['1']
                    }
                }

                let detailData = this.strdInfo // 데이터 Set
                _.forEach(Object.keys(detailData), (key) => {
                    if (!_.isEmpty(key)) {
                        // 기본정보셋팅
                        let value = values[key]
                        let isValue = false

                        let currentDate = moment(new Date()).format(
                            'YYYY-MM-DD'
                        )

                        if (
                            _.isEqual(value, undefined) ||
                            _.isEqual(value, null) ||
                            _.isEqual(value, '')
                        ) {
                            if (typeof detailData[key] === 'object') {
                                value = []
                            } else {
                                value = ''
                            }
                        } else {
                            isValue = true
                        }

                        // 필터정보셋팅
                        if (_.isEqual(key, 'dealStaDt')) {
                            detailData[key] = isValue
                                ? moment(value).format('YYYY-MM-DD')
                                : currentDate
                        } else if (_.isEqual(key, 'dealEndDt')) {
                            detailData[key] = isValue
                                ? moment(value).format('YYYY-MM-DD')
                                : '9999-12-31'
                            /*
                        } else if (_.isEqual(key, 'normalYn')) {
                            if (isValue && _.isEqual(value, 'Y')) {
                                detailData['dealStatus'].push('1')
                            }
                        } else if (_.isEqual(key, 'payStopYn')) {
                            if (isValue && _.isEqual(value, 'Y')) {
                                detailData['dealStatus'].push('2')
                            }
                        } else if (_.isEqual(key, 'outStopYn')) {
                            if (isValue && _.isEqual(value, 'Y')) {
                                detailData['dealStatus'].push('3')
                            }
                        } else if (_.isEqual(key, 'saleStopYn')) {
                            if (isValue && _.isEqual(value, 'Y')) {
                                detailData['dealStatus'].push('4')
                            }
                        } else if (_.isEqual(key, 'dealEndYn')) {
                            if (isValue && _.isEqual(value, 'Y')) {
                                detailData['dealStatus'].push('5')
                            }
                        } else if (_.isEqual(key, 'sttlEndYn')) {
                            if (isValue && _.isEqual(value, 'Y')) {
                                detailData['dealStatus'].push('6')
                            }
                        } else if (_.isEqual(key, 'drwStopYn')) {
                            if (isValue && _.isEqual(value, 'Y')) {
                                detailData['dealStatus'].push('7')
                            }

                         */
                        } else if (!_.isEqual(key, 'dealStatus')) {
                            detailData[key] = value
                        }

                        if (_.isEqual(key, 'dealcoRgstClCd')) {
                            this.setDealcoGrpCd() // 거래처 그룹조회
                        }

                        if (_.isEqual(key, 'dealcoClCd1')) {
                            this.changeDealcoCl() // 거래처 유형 조회
                            this.changeDealcoCl2()
                        }
                    }
                })

                const normalYn = _.isEqual(values['normalYn'], 'N') ? '' : '1'
                const payStopYn = _.isEqual(values['payStopYn'], 'N') ? '' : '2'
                const outStopYn = _.isEqual(values['outStopYn'], 'N') ? '' : '3'
                const saleStopYn = _.isEqual(values['saleStopYn'], 'N')
                    ? ''
                    : '4'
                const dealEndYn = _.isEqual(values['dealEndYn'], 'N') ? '' : '5'
                const sttlEndYn = _.isEqual(values['sttlEndYn'], 'N') ? '' : '6'
                const drwStopYn = _.isEqual(values['drwStopYn'], 'N') ? '' : '7'

                let arr = [
                    normalYn,
                    payStopYn,
                    outStopYn,
                    saleStopYn,
                    dealEndYn,
                    sttlEndYn,
                    drwStopYn,
                ]
                let dealStatus = arr.filter((element) => element != '')
                detailData['dealStatus'] = dealStatus

                let param = { ...detailData }
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
