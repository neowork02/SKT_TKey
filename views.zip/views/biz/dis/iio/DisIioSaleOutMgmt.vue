<!-----------------------------------------------
 * 업무그룹명: 매출출고
 * 서브업무명: 매출출고관리
 * 설명: 매출출고를 조회한다.
 * 작성자: P179890
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>매출출고관리</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="excelUpload"
                    :objAuth="this.objAuth"
                    >엑셀업로드</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="newBtn"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00430"
                        labelName="주문유형"
                        :eRequired="true"
                        :objAuth="this.objAuth"
                        v-model="reqParam.asgnCl"
                        :addBlankItem="false"
                        :filterFunc="filterAsgnFunc"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="납기요청일"
                        :eRequired="true"
                        :calType="calType"
                        v-model="setDate"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="출고조직"
                        @enterKey="onAuthOrgTreeIconClick('OUT')"
                        @appendIconClick="onAuthOrgTreeIconClick('OUT')"
                        @input="onAuthOrgTreeInput('OUT')"
                        :eRequired="true"
                        :objAuth="this.objAuth"
                        v-model="reqParam.outOrgNm"
                        :codeVal="reqParam.outOrgId"
                        :disabledAfter="true"
                        :disabled="searchDisable"
                        @focus="outOrgFocus"
                    >
                    </TCComInputSearchText>
                    <!-- 내부조직팝업(권한) -->
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="orgParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4-->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="출고처"
                        @appendIconClick="onDealcoIconClick('OUT')"
                        @enterKey="onDealcoIconClick('OUT')"
                        @input="onDealcoInput('OUT')"
                        :objAuth="this.objAuth"
                        v-model="reqParam.outPlcNm"
                        :codeVal="reqParam.outPlcId"
                        :disabledAfter="true"
                        :disabled="searchDisable"
                        @focus="outPlcFocus"
                    >
                    </TCComInputSearchText>
                    <!-- 내부거래처팝업(권한조직) -->
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchDealcoParam"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 1-4 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00450"
                        labelName="처리상태"
                        :objAuth="this.objAuth"
                        v-model="reqParam.outFixYn"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="조직구분"
                        :itemList="orgClComboItems"
                        :objAuth="this.objAuth"
                        v-model="reqParam.inCl"
                        :addBlankItem="false"
                        @change="inClChange"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="입고조직"
                        @enterKey="onAuthOrgTreeIconClick('IN')"
                        @appendIconClick="onAuthOrgTreeIconClick('IN')"
                        @input="onAuthOrgTreeInput('IN')"
                        :objAuth="this.objAuth"
                        v-model="reqParam.inOrgNm"
                        :codeVal="reqParam.inOrgId"
                        :disabledAfter="true"
                        v-show="showInOrg"
                        @focus="inOrgFocus"
                    >
                    </TCComInputSearchText>
                </div>
                <!-- //item 2-3 -->
                <!-- item 2-4 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="입고처"
                        @appendIconClick="onDealcoIconClick('IN')"
                        @enterKey="onDealcoIconClick('IN')"
                        @input="onDealcoInput('IN')"
                        :objAuth="this.objAuth"
                        v-model="reqParam.inPlcNm"
                        :codeVal="reqParam.inPlcId"
                        :disabled="inPlcDisable"
                        :disabledAfter="true"
                        @focus="inPlcFocus"
                    >
                    </TCComInputSearchText>
                    <!-- 외부거래처팝업 -->
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 2-4 -->
            </div>
            <!-- //Search_line 2 -->
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{
                            ' btn_ty_exp_active ': active,
                        }"
                        @click="active = !active"
                    >
                    </v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="active">
                    <!-- Search_line 3 -->
                    <div class="searchform">
                        <!-- item 3-1 -->
                        <div class="formitem div4">
                            <TCComInput
                                labelName="출고관리번호"
                                v-model="reqParam.outMgmtNo"
                                @enterKey="searchBtn"
                            />
                        </div>
                        <!-- //item 3-1 -->
                        <div class="formitem div4_6"></div>
                    </div>
                    <!-- //Search_line 3 -->
                </div>
            </v-expand-transition>
        </div>
        <!-- //Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="매출출고관리 내역"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.exportGridBtn"
            >
                <template #gridBtnArea>
                    <TCComButton
                        :Vuetify="false"
                        eClass="btn_noline btn_ty04"
                        eAttr="ico_exeldown"
                        labelName="상세다운로드"
                        :objAuth="objAuth"
                        @click="exportGridDtlBtn"
                    />
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
        </div>
        <!-- //gridWrap -->
    </div>
</template>

<!--style scoped>
</style-->
<script>
import { DisIioSaleOutMgmt_GRID_HEADER } from '@/const/grid/dis/iio/disIioSaleOutMgmtHeader.js'
import iioApi from '@/api/biz/dis/iio/disIioSaleOutMgmt.js'
import attachedFileApi from '@/api/common/attachedFile'
import { CommonUtil, CommonMsg } from '@/utils'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처(권한조직)====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처(권한조직)==================
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================

export default {
    name: 'DisIioSaleOutMgmt',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
        BasBcoOutDealsPopup,
    },
    data() {
        return {
            //====================내부조직팝업(권한)팝업관련====================
            authOrgParam: {},
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            curInOutOrgFocus: '', // 현재 포커스된 검색조직(출고:OUT/입고:IN) 영역
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처(권한 조직))====================
            basBcoDealcoShow: false,
            searchDealcoParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY',
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC',
            },
            resultDealcoRows: [],
            curInOutPlcFocus: '', // 현재 포커스된 거래처(출고:OUT/입고:IN) 영역
            //====================//내부거래처(권한 조직)==================
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '3X,2X,8X', // 거래처그룹
                dealcoClCd1: '', // 거래처구분
            },
            // ---- AS-IS ------
            // aDealCoGrp[0] = "3X";	// 제조사
            // aDealCoGrp[1] = "2X";	// 매입처
            // aDealCoGrp[2] = "8X";	// 특판처
            // ---- //AS-IS ------
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            active: false,
            searchDisable: false,
            alertBodyTxt: '',
            alertHeadTxt: '매출출고관리',
            showInOrg: false,
            inPlcDisable: false,
            calType: 'DP',
            view: DisIioSaleOutMgmt_GRID_HEADER,
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            searchForms: {},
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
            orgParam: {
                orgNm: '',
                vLevel: '',
            },
            reqParam: {
                // 요청파라미터
                fromOutSchdDt: '', // 납기요청시작일
                toOutSchdDt: '', // 납기요청종료일
                outMgmtNo: '', // 출고처관리번호
                outOrgId: '', // 출고조직코드
                outOrgNm: '', // 출고조직명
                outOrgLevel: '', // 출고조직레벨
                outOrgCdLvl0: '', // 출고레벨0조직코드
                inOrgId: '', // 입고조직코드
                inOrgNm: '', // 입고조직명
                inOrgLevel: '', // 입고조직레벨
                inOrgCdLvl0: '', // 입고레벨0조직코드
                outPlcId: '', // 출고처코드
                outPlcNm: '', // 출고처명
                inPlcId: '', // 입고처코드
                inPlcNm: '', // 입고처명
                asgnCl: '', // 주문유형
                inCl: '', // 조직구분
                outFixYn: '', // 처리상태
            },
            orgClComboItems: [
                { commCdValNm: '내부', commCdVal: '1' },
                { commCdValNm: '외부', commCdVal: '2' },
            ],
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.fromOutSchdDt, this.reqParam.toOutSchdDt]
            },
            set(val) {
                this.reqParam.fromOutSchdDt = val[0]
                this.reqParam.toOutSchdDt = val[1]
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.orgParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchDealcoParam.basDay = CommonUtil.onlyNumber(
                    val[1]
                ).substr(0, 8)
                return val
            },
        },
    },
    watch: {},
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked

        if (CommonUtil.isNotEmptyObject(this.$route.params.search)) {
            // 타계정출고등록 화면에서 목록으로 이동 시 검색영역 set
            this.reqParam = this.$route.params.search
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.searchDisable = true
            } else {
                this.searchDisable = false
            }
            if (this.reqParam.inCl == '2') {
                this.showInOrg = false
            } else {
                this.showInOrg = true
            }
            this.searchBtn()
        } else {
            this.init()
        }
    },
    methods: {
        init() {
            // 검색영역
            // 납기요청시작일
            this.reqParam.fromOutSchdDt = moment(new Date()).format(
                'YYYY-MM-01'
            )
            // 납기요청종료일
            this.reqParam.toOutSchdDt = moment(new Date()).format('YYYY-MM-DD')
            // 세션정보 set
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                // 출고처
                this.reqParam['outPlcId'] = this.userInfo['dealcoCd']
                this.reqParam['outPlcNm'] = this.userInfo['dealcoNm']
                // 조직
                this.reqParam['outOrgId'] = this.orgInfo['orgCd']
                this.reqParam['outOrgNm'] = this.orgInfo['orgNm']
                this.reqParam['outOrgLevel'] = this.orgInfo['orgLvl']
                this.reqParam['outOrgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.searchDisable = true
            } else {
                this.searchDisable = false
            }
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
            this.reqParam.asgnCl = '02'
            this.reqParam.inCl = '1'
            this.showInOrg = true
        },
        // 엑셀업로드 버튼 클릭이벤트
        excelUpload() {
            this.$router.push({
                name: '/dis/iio/DisIioSaleOutXlsUpld',
                params: { search: this.reqParam },
            })
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/iio/disIioSaleOutMgmtExcels',
                this.searchForms
            )
        },
        //상세 ExcelDown
        exportGridDtlBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/iio/disIioSaleOutMgmtAllExcels',
                this.searchForms
            )
        },
        //조회 버튼 이벤트
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            //첫 조회시 표시할 행의 갯수
            this.searchForms = { ...this.reqParam }
            this.searchForms.fromOutSchdDt = CommonUtil.onlyNumber(
                this.searchForms.fromOutSchdDt
            )
            this.searchForms.toOutSchdDt = CommonUtil.onlyNumber(
                this.searchForms.toOutSchdDt
            )
            this.getSaleOutMgmtList()
        },
        getSaleOutMgmtList() {
            iioApi.getSaleOutMgmtList(this.searchForms).then((res) => {
                this.gridObj.setRows(res.gridList)
                this.gridHeaderObj.setPageCount({
                    totalDataCnt: res.gridList.length,
                })
            })
        },
        clearPage() {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.init()
        },
        isValidChk() {
            if (_.isEmpty(this.reqParam.fromOutSchdDt)) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00083', '납기요청시작일')
                )
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.fromOutSchdDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            if (_.isEmpty(this.reqParam.toOutSchdDt)) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00083', '납기요청종료일')
                )
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.toOutSchdDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            if (
                this.reqParam.fromOutSchdDt.substr(0, 7) !==
                this.reqParam.toOutSchdDt.substr(0, 7)
            ) {
                // MSG_00086
                this.openAlert('시작일자와 종료일자을 동일한 월로 지정하세요.')
                return false
            }
            if (
                this.reqParam.fromOutSchdDt.replaceAll('-', '') >
                this.reqParam.toOutSchdDt.replaceAll('-', '')
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_01026'))
                return false
            }
            if (_.isEmpty(this.reqParam.outOrgId)) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00121', '출고조직;조회')
                )
                return false
            }
            return true
        },
        onCellDblClicked(grid, clickData) {
            if (clickData?.dataRow >= 0) {
                const rowData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )

                // 매출출고관리상세 화면 호출
                this.$router.push({
                    name: '/dis/iio/DisIioSaleOutMgmtDtl',
                    params: { ...rowData, search: this.reqParam },
                })
            }
        },
        // 매출출고등록 화면 이동
        newBtn() {
            this.$router.push({
                name: '/dis/iio/DisIioSaleOutMgmtDtl',
                params: { search: this.reqParam },
            })
        },
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        // 출고구분comboBox filter
        filterAsgnFunc(items) {
            return items.filter((item) => item['commCdVal'] === '02')
        },
        // 조직구분 ComboBox 변경이벤트
        inClChange(val) {
            if (val == '1') {
                // 내부
                // 입고조직 검색영역 visible true
                this.showInOrg = true
                // 입고처 disabled true
                // this.inPlcDisable = true
            } else {
                // 외부
                // 입고조직 검색영역 visible false
                this.showInOrg = false
                // 입고처 disabled false
                // this.inPlcDisable = false
            }
            // 입고조직 입고처 초기화
            this.reqParam['inOrgId'] = ''
            this.reqParam['inOrgNm'] = ''
            this.reqParam['inOrgLevel'] = ''
            this.reqParam['inOrgCdLvl0'] = ''
            this.reqParam['inPlcId'] = ''
            this.reqParam['inPlcNm'] = ''
        },
        // 출고조직 Focus이벤트
        outOrgFocus() {
            // 현재 Focus 조직 flag
            this.curInOutOrgFocus = 'OUT'
        },
        // 입고조직 Focus이벤트
        inOrgFocus() {
            // 현재 Focus 조직 flag
            this.curInOutOrgFocus = 'IN'
        },
        // 출고처 Focus이벤트
        outPlcFocus() {
            // 현재 Focus 거래처 flag
            this.curInOutPlcFocus = 'OUT'
        },
        // 입고처 Focus이벤트
        inPlcFocus() {
            // 현재 Focus 거래처 flag
            this.curInOutPlcFocus = 'IN'
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList(flag) {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.authOrgParam)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        if (flag == 'OUT') {
                            this.reqParam.outOrgId = _.get(res[0], 'orgCd')
                            this.reqParam.outOrgNm = _.get(res[0], 'orgNm')
                            this.reqParam.outOrgLevel = _.get(res[0], 'orgLvl')
                            this.reqParam.outOrgCdLvl0 = _.get(
                                res[0],
                                'orgCdLvl0'
                            )
                        } else {
                            this.reqParam.inOrgId = _.get(res[0], 'orgCd')
                            this.reqParam.inOrgNm = _.get(res[0], 'orgNm')
                            this.reqParam.inOrgLevel = _.get(res[0], 'orgLvl')
                            this.reqParam.inOrgCdLvl0 = _.get(
                                res[0],
                                'orgCdLvl0'
                            )
                        }
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick(flag) {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []

            const inOutOrgNm =
                flag == 'OUT' ? this.reqParam.outOrgNm : this.reqParam.outInNm

            // 내부조직팝업 파라미터
            if (flag == 'OUT') {
                // 출고조직명
                this.orgParam['orgNm'] = this.reqParam['outOrgNm']
            } else {
                // 입고조직명
                this.orgParam['orgNm'] = this.reqParam['inOrgNm']
            }

            if (flag == 'OUT') {
                this.authOrgParam['orgNm'] = this.reqParam['outOrgNm']
                this.authOrgParam['orgCd'] = this.reqParam['outOrgId']
                this.authOrgParam['orgLvl'] = this.reqParam['outOrgLevel']
            } else {
                this.authOrgParam['orgNm'] = this.reqParam['inOrgNm']
                this.authOrgParam['orgCd'] = this.reqParam['inOrgId']
                this.authOrgParam['orgLvl'] = this.reqParam['inOrgLevel']
            }

            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(inOutOrgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            if (this.curInOutOrgFocus == 'OUT') {
                if (
                    !_.isEmpty(this.reqParam.outOrgId) &&
                    this.reqParam.outOrgId != returnData.orgCd
                ) {
                    this.reqParam.outPlcId = ''
                    this.reqParam.outPlcNm = ''
                }
                this.reqParam.outOrgId = _.get(returnData, 'orgCd')
                this.reqParam.outOrgNm = _.get(returnData, 'orgNm')
                this.reqParam.outOrgLevel = _.get(returnData, 'orgLvl')
                this.reqParam.outOrgCdLvl0 = _.get(returnData, 'orgCdLvl0')
            } else {
                if (
                    !_.isEmpty(this.reqParam.inOrgId) &&
                    this.reqParam.inOrgId != returnData.orgCd
                ) {
                    this.reqParam.inPlcId = ''
                    this.reqParam.inPlcNm = ''
                }
                this.reqParam.inOrgId = _.get(returnData, 'orgCd')
                this.reqParam.inOrgNm = _.get(returnData, 'orgNm')
                this.reqParam.inOrgLevel = _.get(returnData, 'orgLvl')
                this.reqParam.inOrgCdLvl0 = _.get(returnData, 'orgCdLvl0')
            }
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput(flag) {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            if (flag == 'OUT') {
                // 출고조직 검색영역 초기화
                this.reqParam.outOrgId = ''
                this.reqParam.outOrgLevel = ''
                this.reqParam.outOrgCdLvl0 = ''
                // 출고처 검색영역 초기화
                this.reqParam.outPlcId = ''
                this.reqParam.outPlcNm = ''
            } else {
                // 입고조직 검색영역 초기화
                this.reqParam.inOrgId = ''
                this.reqParam.inOrgLevel = ''
                this.reqParam.inOrgCdLvl0 = ''
                // 입고처 검색영역 초기화
                this.reqParam.inPlcId = ''
                this.reqParam.inPlcNm = ''
            }
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList(flag) {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcoParam)
                .then((res) => {
                    console.log('res::', res)
                    // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                    if (res.length === 1) {
                        if (flag == 'OUT') {
                            this.reqParam.outPlcId = _.get(res[0], 'dealcoCd')
                            this.reqParam.outPlcNm = _.get(res[0], 'dealcoNm')
                        } else {
                            this.reqParam.inPlcId = _.get(res[0], 'dealcoCd')
                            this.reqParam.inPlcNm = _.get(res[0], 'dealcoNm')
                        }
                    } else {
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        onDealcoIconClick(flag) {
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.resultOutDealRows = []
            if (flag == 'OUT') {
                // 출고처
                if (_.isEmpty(this.reqParam.outOrgId)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00083', '출고조직')
                    )
                    return
                }
                this.searchDealcoParam['orgCd'] = this.reqParam['outOrgId']
                this.searchDealcoParam['orgNm'] = this.reqParam['outOrgNm']
                this.searchDealcoParam['orgLvl'] = this.reqParam['outOrgLevel']
                this.searchDealcoParam['dealcoCd'] = this.reqParam['outPlcId']
                this.searchDealcoParam['dealcoNm'] = this.reqParam['outPlcNm']
                this.searchDealcoParam['dealcoClCd1'] =
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC'
                if (!_.isEmpty(this.reqParam.outPlcNm)) {
                    // 내부거래처조회
                    this.getDealcosList(flag)
                } else {
                    // 팝업오픈
                    this.basBcoDealcoShow = true
                }
            } else {
                // 입고처
                if (this.reqParam.inCl == '1') {
                    // 내부
                    if (_.isEmpty(this.reqParam.inOrgId)) {
                        this.openAlert(
                            CommonMsg.getMessage('MSG_00083', '입고조직')
                        )
                        return
                    }
                    this.searchDealcoParam['orgCd'] = this.reqParam['inOrgId']
                    this.searchDealcoParam['orgNm'] = this.reqParam['inOrgNm']
                    this.searchDealcoParam['orgLvl'] =
                        this.reqParam['inOrgLevel']
                    this.searchDealcoParam['dealcoCd'] =
                        this.reqParam['inPlcId']
                    this.searchDealcoParam['dealcoNm'] =
                        this.reqParam['inPlcNm']
                    this.searchDealcoParam['dealcoClCd1'] =
                        'A6,A7,AF,B2,M1,A3,D1,C1,E1,AC'
                    if (!_.isEmpty(this.reqParam.inPlcNm)) {
                        // 내부거래처조회
                        this.getDealcosList(flag)
                    } else {
                        // 팝업오픈
                        this.basBcoDealcoShow = true
                    }
                } else {
                    // 외부
                    // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
                    // 그 이외는 외부거래처 팝업 오픈
                    this.resultOutDealRows = []
                    this.searchOutDealParam['dealcoCd'] = this.reqParam.inPlcId
                    this.searchOutDealParam['dealcoNm'] = this.reqParam.inPlcNm
                    // 외부거래처팝업오픈
                    if (!_.isEmpty(this.reqParam.inPlcNm)) {
                        this.getOutDealList()
                    } else {
                        this.showBcoOutDeals = true
                    }
                }
            }
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput(flag) {
            // 입력되는 값이 있으면 코드 초기화
            if (flag == 'OUT') {
                this.reqParam.outPlcId = ''
            } else {
                this.reqParam.inPlcId = ''
            }
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            if (this.curInOutPlcFocus == 'OUT') {
                this.reqParam.outPlcId = _.get(returnData, 'dealcoCd')
                this.reqParam.outPlcNm = _.get(returnData, 'dealcoNm')
            } else {
                this.reqParam.inPlcId = _.get(returnData, 'dealcoCd')
                this.reqParam.inPlcNm = _.get(returnData, 'dealcoNm')
            }
        },
        //===================== //내부거래처(권한조직) methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.inPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.inPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
    },
}
</script>
