import { ValueType } from 'realgrid'

export const GRID_INFO_A = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'priceMnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'priceChg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prodCheck',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'feeCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '100',
            header: {
                text: '단말기모델ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            header: {
                text: '단말기모델명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'priceCd',
            fieldName: 'priceCd',
            type: 'data',
            width: '100',
            header: {
                text: '요금제그룹ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'priceNm',
            fieldName: 'priceNm',
            type: 'data',
            width: '100',
            header: {
                text: '요금제그룹명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'priceNum',
            fieldName: 'priceNum',
            type: 'number',
            width: '100',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'priceMnp',
            fieldName: 'priceMnp',
            type: 'number',
            width: '100',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'priceChg',
            fieldName: 'priceChg',
            type: 'number',
            width: '100',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
    ],
    layout: [
        'prodCd',
        'prodNm',
        'priceCd',
        'priceNm',
        'priceNum',
        'priceMnp',
        'priceChg',
    ],
}

export const GRID_INFO_B = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price1Cd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price1Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price1Num',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price1Mnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price1Chg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price2Cd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price2Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price2Num',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price2Mnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price2Chg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price3Cd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price3Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price3Num',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price3Mnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price3Chg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price4Cd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price4Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price4Num',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price4Mnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price4Chg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price5Cd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price5Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price5Num',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price5Mnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price5Chg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price6Cd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price6Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'price6Num',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price6Mnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price6Chg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price7Num',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price7Mnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'price7Chg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prodCheck',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'feeCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '100',
            header: {
                text: '단말기모델ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            header: {
                text: '단말기모델명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'price1Num',
            fieldName: 'price1Num',
            type: 'number',
            width: '50',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price1Mnp',
            fieldName: 'price1Mnp',
            type: 'number',
            width: '50',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price1Chg',
            fieldName: 'price1Chg',
            type: 'number',
            width: '50',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },

        {
            name: 'price2Num',
            fieldName: 'price2Num',
            type: 'number',
            width: '50',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price2Mnp',
            fieldName: 'price2Mnp',
            type: 'number',
            width: '50',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price2Chg',
            fieldName: 'price2Chg',
            type: 'number',
            width: '50',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },

        {
            name: 'price3Num',
            fieldName: 'price3Num',
            type: 'number',
            width: '50',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price3Mnp',
            fieldName: 'price3Mnp',
            type: 'number',
            width: '50',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price3Chg',
            fieldName: 'price3Chg',
            type: 'number',
            width: '50',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },

        {
            name: 'price4Num',
            fieldName: 'price4Num',
            type: 'number',
            width: '50',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price4Mnp',
            fieldName: 'price4Mnp',
            type: 'number',
            width: '50',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price4Chg',
            fieldName: 'price4Chg',
            type: 'number',
            width: '50',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },

        {
            name: 'price5Num',
            fieldName: 'price5Num',
            type: 'number',
            width: '50',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price5Mnp',
            fieldName: 'price5Mnp',
            type: 'number',
            width: '50',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price5Chg',
            fieldName: 'price5Chg',
            type: 'number',
            width: '50',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },

        {
            name: 'price6Num',
            fieldName: 'price6Num',
            type: 'number',
            width: '50',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price6Mnp',
            fieldName: 'price6Mnp',
            type: 'number',
            width: '50',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price6Chg',
            fieldName: 'price6Chg',
            type: 'number',
            width: '50',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price7Num',
            fieldName: 'price7Num',
            type: 'number',
            width: '50',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price7Mnp',
            fieldName: 'price7Mnp',
            type: 'number',
            width: '50',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'price7Chg',
            fieldName: 'price7Chg',
            type: 'number',
            width: '50',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            numberFormat: '#,##0',
        },
    ],

    layout: [
        'prodCd',
        'prodNm',
        {
            name: '기본구간',
            direction: 'horizontal',
            items: ['price7Num', 'price7Mnp', 'price7Chg'],
        },
        {
            name: '세이브(S_33)',
            direction: 'horizontal',
            items: ['price6Num', 'price6Mnp', 'price6Chg'],
        },
        {
            name: '안심 2.5G(R_43)',
            direction: 'horizontal',
            items: ['price5Num', 'price5Mnp', 'price5Chg'],
        },
        {
            name: '안심 4G(M_50)',
            direction: 'horizontal',
            items: ['price4Num', 'price4Mnp', 'price4Chg'],
        },
        {
            name: '에센스(L_69)',
            direction: 'horizontal',
            items: ['price3Num', 'price3Mnp', 'price3Chg'],
        },
        {
            name: '스페셜(F_79)',
            direction: 'horizontal',
            items: ['price2Num', 'price2Mnp', 'price2Chg'],
        },
        {
            name: '맥스(I_100)',
            direction: 'horizontal',
            items: ['price1Num', 'price1Mnp', 'price1Chg'],
        },
    ],
}
