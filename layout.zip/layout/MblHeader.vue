<!-----------------------------------------------
 * 업무그룹명: 레이아웃 Header 컴포넌트
 * 서브업무명: 레이아웃 Header 컴포넌트 
 * 설명: 레이아웃 Header 처리
 * 작성자: 양현모
 * 작성일: 2022.11.21
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="header">
        <a
            href=""
            class="btnMenu"
            role="button"
            @click.prevent="onPageClick('/mobile/home/MblMenu', $event)"
            ><span>Menu</span></a
        >
        <!-- <a href="#none" class="btnBack" role="button"
            ><span>Back</span></a
        > -->
        <h1>{{ currentMenuInfo.menuNm }}</h1>
        <a
            href=""
            class="btnSearch"
            role="button"
            @click.prevent="onQuickSearchPopupClick"
            ><span>Search</span></a
        >
        <a
            href=""
            class="btnGoHome"
            role="button"
            @click.prevent="onPageClick('/mobile/home/MblMain', $event)"
            ><span>Home</span></a
        >
        <MblQuickSearchPopup
            v-if="showMblQuickSearchPopup"
            ref="mblQuickSearchPopup"
            :dialogShow.sync="showMblQuickSearchPopup"
        />
    </div>
</template>

<script>
export default {
    components: {
        MblQuickSearchPopup: () =>
            import('@/views/mobile/home/MblQuickSearchPopup'),
    },
    data() {
        return {
            showMblQuickSearchPopup: false,
        }
    },
    created() {},
    computed: {
        currentMenuInfo() {
            return this.$store.getters['menu/currentMenuInfo']
        },
    },
    methods: {
        // 퀵 서치 팝업
        onQuickSearchPopupClick() {
            this.showMblQuickSearchPopup = true
        },

        onPageClick(url, ev) {
            this.$router
                .push({
                    name: url,
                })
                .catch(() => {})

            ev.stopPropagation()
            // @click.prevent 사용시 중복 된 기능이라 주석처리
            // ev.preventDefault()
        },
    },
}
</script>
<style></style>
