import { ValueType } from 'realgrid'

export const GRID_INFO = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cmmsId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cmmsTs',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cmmsTsNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcStaDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcEndDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'applyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'applyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polOperCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polOperNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polSubjCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polSubjNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polKndCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polKndNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstSchdYm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'vatCd',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'cmmsId',
            fieldName: 'cmmsId',
            type: 'data',
            width: '100',
            header: {
                text: '수수료정책ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'cmmsTsNm',
            fieldName: 'cmmsTsNm',
            type: 'data',
            width: '80',
            header: {
                text: '차수',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        // {
        //     name: 'polOperNm',
        //     fieldName: 'polOperNm',
        //     type: 'data',
        //     width: '250',
        //     header: {
        //         text: '정책운영사',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     editable: false,
        // },
        {
            name: 'polSubjNm',
            fieldName: 'polSubjNm',
            type: 'data',
            width: '100',
            header: {
                text: '정책주관',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polTypNm',
            fieldName: 'polTypNm',
            type: 'data',
            width: '150',
            header: {
                text: '정책구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polNm',
            fieldName: 'polNm',
            type: 'data',
            width: '400',
            header: {
                text: '정책명칭',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'polStNm',
            fieldName: 'polStNm',
            type: 'data',
            width: '80',
            header: {
                text: '상태',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'applyNm',
            fieldName: 'applyNm',
            type: 'data',
            width: '80',
            header: {
                text: '적용유형',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'svcStaDtm',
            fieldName: 'svcStaDtm',
            type: 'data',
            width: '150',
            header: {
                text: '개통시작일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'svcEndDtm',
            fieldName: 'svcEndDtm',
            type: 'data',
            width: '150',
            header: {
                text: '개통종료일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dpstSchdYm',
            fieldName: 'dpstSchdYm',
            type: 'data',
            width: '100',
            header: {
                text: '입금예정월',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            width: '80',
            header: {
                text: '작성자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '80',
            header: {
                text: '처리자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            width: '150',
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}
