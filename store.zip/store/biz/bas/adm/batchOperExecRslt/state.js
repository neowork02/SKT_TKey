export default {
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 15,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 15, //전체 조회:9999
        totalPageCnt: 0,
        totalDataCnt: 0,
    },

    resultList: [],

    searchParams: {},
    popupParams: {},
    popupOpenNew: false,

    commDropDown: {},
}
