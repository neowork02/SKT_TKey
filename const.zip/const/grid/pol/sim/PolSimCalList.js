import { ValueType } from 'realgrid'

export const GRID_CAL_INFO = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polTs',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'calAmt',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'lvOrgNm',
            fieldName: 'lvOrgNm',
            type: 'data',
            width: '100',
            header: {
                text: '매장/거래처',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polTypNm',
            fieldName: 'polTypNm',
            type: 'data',
            width: '100',
            header: {
                text: '정책유형',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polId',
            fieldName: 'polId',
            type: 'data',
            width: '100',
            header: {
                text: '정책ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polTs',
            fieldName: 'polTs',
            type: 'data',
            width: '100',
            header: {
                text: '정책차수',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'polNm',
            fieldName: 'polNm',
            type: 'data',
            width: '150',
            header: {
                text: '정책명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}
