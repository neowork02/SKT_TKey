import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'trmsDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cashRcpIdntInfo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cashRcpTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpsMsgDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'trmsDtm',
            fieldName: 'trmsDtm',
            type: 'data',
            header: { text: '거래일시' },
            width: '150',
        },
        {
            name: 'dealClCd',
            fieldName: 'dealClCd',
            type: 'data',
            header: { text: '거래구분' },
            width: '150',
        },
        {
            name: 'aprvDt',
            fieldName: 'aprvDt',
            type: 'data',
            header: { text: '승인일자' },
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'cashRcpIdntInfo',
            fieldName: 'cashRcpIdntInfo',
            type: 'data',
            header: { text: '현금영수증식별번호' },
            width: '150',
            styleName: 'right-column',
        },
        {
            name: 'aprvNo',
            fieldName: 'aprvNo',
            type: 'data',
            header: {
                text: '승인번호',
            },
            width: '150',
        },
        {
            name: 'dealAmt',
            fieldName: 'dealAmt',
            type: 'data',
            header: { text: '승인금액' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'cashRcpTypCd',
            fieldName: 'cashRcpTypCd',
            type: 'data',
            header: { text: '결제유형' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
        },
        {
            name: 'rpsMsgDesc',
            fieldName: 'rpsMsgDesc',
            type: 'data',
            header: { text: '응답메시지' },
            width: '150',
        },
        {
            name: 'rmk',
            fieldName: 'rmk',
            type: 'data',
            header: { text: '비고' },
            width: '150',
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            header: { text: '처리자' },
            width: '150',
        },
    ],
}
