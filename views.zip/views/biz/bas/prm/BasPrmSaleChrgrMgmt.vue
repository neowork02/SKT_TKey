<template>
    <div class="content">
        <h1>거래처영업담당자관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="btn_select_Onclick(1)"
                >
                    일괄변경 - 사용자선택
                </TCComButton>
                <BasBcoUserSaleChrgrsPopup
                    v-if="showBcoSaleChrgr"
                    :parentParam="searchParam"
                    :rows="resultSaleChrgrRows"
                    :dialogShow.sync="showBcoSaleChrgr"
                    @confirm="anconSaleChrgrReturnData"
                />

                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="btn_setAplyDt_OnClick"
                >
                    일괄변경 - 적용일자 변경
                </TCComButton>
                <BasPrmAplyDtBatChgPopup
                    v-if="showPrmAplyDtBatChg"
                    ref="popup"
                    :dialogShow.sync="showPrmAplyDtBatChg"
                    @confirm="onAplyDtBatChgReturnData"
                />
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clear"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch(type)"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave()"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>
        <!-- searchLayer_wrap -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4" v-if="this.type === 0">
                    <TCComAlert
                        v-model="showAlertBool"
                        :headerText="headerText"
                        :bodyText="alertBodyText"
                    ></TCComAlert>
                    <TCComInputSearchText
                        v-model="searchParam.orgNm"
                        :codeVal.sync="searchParam.orgCd"
                        :eRequired="true"
                        labelName="소속조직"
                        placeholder="선택해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div5_2" v-if="this.type === 0">
                    <TCComInput
                        labelName="거래처명"
                        :objAuth="this.objAuth"
                        :disabled="false"
                        v-model="reqParam.dealcoNm"
                        @enterKey="onSearch(type)"
                    />
                </div>
                <div class="formitem div5_2" v-if="this.type === 0">
                    <TCComInput
                        labelName="거래처코드"
                        :objAuth="this.objAuth"
                        :disabled="false"
                        v-model="reqParam.dealcoCd"
                        @enterKey="onSearch(type)"
                    />
                </div>
                <div class="formitem div5_2" v-if="this.type === 1">
                    <TCComInput
                        labelName="특판처코드"
                        :objAuth="this.objAuth"
                        :disabled="false"
                        v-model="reqParam.dealcoCd"
                        @enterKey="onSearch(type)"
                    />
                </div>
                <div class="formitem div5_2" v-if="this.type === 1">
                    <TCComInput
                        labelName="특판처명"
                        :objAuth="this.objAuth"
                        :disabled="false"
                        v-model="reqParam.dealcoNm"
                        @enterKey="onSearch(type)"
                    />
                </div>
                <div class="formitem div5_2">
                    <TCComInput
                        labelName="사용자"
                        :objAuth="this.objAuth"
                        v-model="reqParam.userNm"
                        @enterKey="onSearch(type)"
                    />
                </div>
                <div class="formitem div5_2">
                    <TCComCheckBox
                        v-model="formParam.effUserYn"
                        itemText="text"
                        itemValue="value"
                        :objAuth="objAuth"
                        :itemList="effUserYns"
                        @change="funcEffUserYn"
                        v-if="this.type === 0"
                    ></TCComCheckBox>
                </div>
            </div>
        </div>

        <!-- //searchLayer_wrap -->
        <div class="gridWrap">
            <TCComTab
                :tab.sync="guideTab2"
                :items="items"
                :itemName="itemName"
                :tabColor="tabColor"
                :textColor="textColor"
                :centered="centered"
                :grow="grow"
                :height="height"
                :hideSlider="hideSlider"
                :sliderColor="sliderColor"
                :vertical="vertical"
                :objAuth="objAuth"
                sliderSize="8"
                @change="onActiveTabChange"
                @click="onActiveTabClick"
                :cKey="0"
            >
                <template #Template1>
                    <!-- Grid Default Sample -->
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="거래처영업담당자관리"
                        :gridObj="gridObj1"
                        :isPageRows="true"
                        :isAddRow="true"
                        :isDelRow="true"
                        :isExceldown="true"
                        :isNextPage="showNext === true ? true : false"
                        :isPageCnt="true"
                        @excelDownBtn="excelDown"
                        @addRowBtn="gridAddRow"
                        @chkDelRowBtn="gridChkDelRow"
                        @addPageBtn="gridAddPageBtn"
                    />
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :editable="true"
                        :movable="true"
                        :columnMovable="false"
                        :fields="view.fields"
                        :columns="view.columns"
                        :isGridReSize="true"
                    />
                    <p class="infoTxt">
                        <span class="color-red">
                            1. 거래처 별 영업 담당자 이력의 적용시작(종료)일자가
                            겹칠시 거래처 영업당자관리 화면이 아닌 다른
                            화면(배치)에서 문제가 발생할 수 있습니다.
                        </span>
                    </p>
                    <p class="infoTxt">
                        <span class="color-red">
                            2. 적용종료일자 9999-12-31인 영업담당자 변경시 대한
                            이력이 생깁니다.
                        </span>
                    </p>
                    <TCComPaging
                        :totalPage="gridData1.totalPage"
                        :apiFunc="getSaleChrgrList"
                        :rowCnt="rowCnt"
                        :gridObj="gridObj1"
                        @input="chgRowCnt1"
                    />

                    <BasBcoChrgrDealcosPop
                        v-if="showBasBcoChrgrDealcos"
                        :parentParam="searchParam"
                        :rows="resultChrgrDealcoRows"
                        :dialogShow.sync="showBasBcoChrgrDealcos"
                        @confirm="onChrgrDealcosReturnData"
                    />
                </template>
                <template #Template2>
                    <TCRealGridHeader
                        id="gridHeader2"
                        ref="gridHeader2"
                        gridTitle="특판처 영업담당자목록"
                        :gridObj="gridObj2"
                        :isPageRows="true"
                        :isAddRow="true"
                        :isDelRow="true"
                        :isExceldown="true"
                        :isNextPage="showNext === true ? true : false"
                        :isPageCnt="true"
                        @excelDownBtn="excelDown2"
                        @addRowBtn="gridAddRow2"
                        @chkDelRowBtn="gridChkDelRow2"
                        @addPageBtn="gridAddPageBtn"
                    />
                    <TCRealGrid
                        id="grid2"
                        ref="grid2"
                        :editable="true"
                        :movable="true"
                        :columnMovable="false"
                        :fields="view2.fields"
                        :columns="view2.columns"
                        @hook:mounted="tabGridMounted"
                        :isGridReSize="true"
                    />
                    <p class="infoTxt">
                        <span class="color-red">
                            1. 거래처 별 영업 담당자 이력의 적용시작(종료)일자가
                            겹칠시 거래처 영업당자관리 화면이 아닌 다른
                            화면(배치)에서 문제가 발생할 수 있습니다.
                        </span>
                    </p>
                    <p class="infoTxt">
                        <span class="color-red">
                            2. 적용종료일자 9999-12-31인 영업담당자 변경시 대한
                            이력이 생깁니다.
                        </span>
                    </p>
                    <TCComPaging
                        :totalPage="gridData2.totalPage"
                        :apiFunc="getSaleChrgr81List"
                        :rowCnt="rowCnt"
                        :gridObj="gridObj2"
                        @input="chgRowCnt2"
                    />
                </template>

                <br />
            </TCComTab>
            <SaleChrgrMgmtPopup
                ref="popup"
                v-if="showBool === true"
                :dialogShow.sync="showBool"
                @confirm="onReturnData"
            />
        </div>
        <!-- //gridWrap -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
//====================사용자팝업====================
import BasBcoUserSaleChrgrsPopup from '@/components/common/BasBcoUserSaleChrgrsPopup'
// import basBcoUserApi from '@/api/biz/bas/bco/basBcoUserPop'
//====================//사용자팝업====================
import BasPrmAplyDtBatChgPopup from '@/views/biz/bas/prm/BasPrmAplyDtBatChgPopup'
import {
    GRID_D_HEADER,
    GRID_SMS_HEADER,
} from '@/const/grid/bas/prm/basPrmSaleChrgrMgmtHeader'

import API from '@/api/biz/bas/prm/basPrmSaleChrgrMgmt'
import moment from 'moment'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
import _ from 'lodash'
import CommonMixin from '@/mixins'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-영업담당자====================
import BasBcoChrgrDealcosPop from '@/components/common/BasBcoChrgrDealcosPopup'
import basBcoChrgrDealcosApi from '@/api/biz/bas/bco/basBcoChrgrDealcos'
import attachedFileApi from '@/api/common/attachedFile'
//====================//내부거래처-영업담당자==================
export default {
    name: 'BasUsmSaleChrgrMgmt',
    mixins: [CommonMixin],
    props: {},
    components: {
        BasBcoUserSaleChrgrsPopup,
        BasPrmAplyDtBatChgPopup,
        BasBcoAuthOrgTreesPopup,
        BasBcoChrgrDealcosPop,
    },

    data() {
        return {
            // gridStyle: {
            //     height: '500px', //그리드 높이 조절
            // },
            guideTab: 0,
            guideTab2: 0,
            items: ['Template1', 'Template2'],
            itemName: ['영업담당자', '특판처담당자'],
            //====================사용자팝업(영업담당자)관련======================
            showBcoSaleChrgr: false,
            searchSaleChrgrParam: {},
            resultSaleChrgrRows: [],
            //================================================================
            //====================적용일자 일괄변경팝업관련======================
            showPrmAplyDtBatChg: false,
            resultPrmAplyDtBatChgRows: [],
            //================================================================
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                orgLvl: '',
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            //=================================================================
            //====================내부거래처-영업담당자==========================
            showBasBcoChrgrDealcos: false,
            searchForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
            },
            resultChrgrDealcoRows: [],
            //=================================================================
            type: 0,
            tabColor: '',
            textColor: '',
            height: '',
            sliderColor: '',
            centered: false,
            grow: false,
            hideSlider: false,
            vertical: false,
            gridData1: this.gridSetData(),
            gridData2: this.gridSetData(),
            objAuth: {},
            showBool: false,
            view: GRID_D_HEADER,
            view2: GRID_SMS_HEADER,
            gridObj1: {},
            gridHeaderObj1: {},
            gridObj2: {},
            gridHeaderObj2: {},
            layout1: [
                'NO',
                'userId',
                'userNm',
                'effUserYn',
                'sendYn',
                {
                    name: '거래처',
                    direction: 'horizontal',
                    items: [
                        // 'bizChrgOrgCd',
                        // 'teamOrgCd',
                        // 'ptOrgCd',
                        'orgNm',
                        // 'sktChnlCd',
                        'sktDealCd',
                        'dealcoCd',
                        'dealcoNm',
                        'dealStatus',
                    ],
                },
                'aplyStaDt',
                'aplyEndDt',
                'modUserId',
                'modDtm',
            ],
            effUserYns: [
                {
                    value: 'Y',
                    text: '적용 유효여부',
                },
            ],
            formParam: {
                effUserYn: ['Y'],
            },
            reqParam: {
                orgCd: '', // 조직코드
                userId: '', // 사용자아이디
                userNm: '', // 사용자명
                effUserYn: '', // 유효사용자여부
                orgLvl: '', // 조직레벨
                dealcoNm: '', // 거래처명
                dealcoCd: '', // 거래처코드
            },
            resPostOrgData: {
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
            },
            pageNum: '',
            pageSize: '',
            showNext: false,
            showNext2: false,
            isSms: false,
            // paging
            rowCnt: 15, // 표시할 행의 갯수
            // paging
            rowCnt2: 15, // 표시할 행의 갯수
            delIdxs: [],
            oldResultData: [],
        }
    },
    mounted() {
        console.log('------mounted------')
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        this.gridObj1 = this.$refs.grid1
        this.gridHeaderObj1 = this.$refs.gridHeader1
        // this.gridObj1.gridView.setRowIndicator({ visible: true })

        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj1.setGridState(true, false, true, false)

        this.gridObj1.gridView.setColumnLayout(this.layout1)
        this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

        // 전송여부 가리기
        this.gridObj1.gridView.columnByName('sendYn').visible = false

        //페이지 정보
        let pageInfo = {}
        // pageInfo.type = 'noPaging' //페이징이 없는경우
        pageInfo.totalDataCnt = this.gridObj1.dataProvider.getRowCount() // 총건수
        this.gridObj1.setGridIndicator(pageInfo) //순번 셋팅

        const arr = []
        arr.push('POST_ORG')
        this.gridObj1.groupBy(arr)
        let paramObj = {}
        paramObj.orgCd = '' // 조직코드
        paramObj.orgClCd = '' // 조직구분코드
        paramObj.orgBizClCd = '' // 조직업무구분코드
        paramObj.deptCd = '' // 부서코드
        paramObj.orgLvl = '' // 조직레벨
        paramObj.pageNum = ''
        paramObj.pageSize = this.gridData1.totalPage
        // SRCH_API.getPostOrgList(paramObj).then((res) => {
        //     if (res.gridList !== null) {
        //         this.resPostOrgData.orgCd = res.gridList[0].orgCd // 조직코드
        //         this.resPostOrgData.orgNm = res.gridList[0].orgNm // 조직명
        //         this.reqParam.orgLvl = res.gridList[0].orgLvl // 조직레벨
        //         this.reqParam.orgCd = res.gridList[0].orgCd // 조직코드
        //     }
        // })

        this.searchParam.orgCd = this.orgInfo.orgCd // 조직코드
        this.searchParam.orgNm = this.orgInfo.orgNm // 조직코드
        this.searchParam.orgLvl = this.orgInfo.orgLvl // 조직코드
        console.log('searchParam', this.searchParam) // 권한정보(속성권한)
        this.gridObj1.gridView.onCellEdited = (
            grid,
            itemIndex,
            dataRow,
            field
        ) => {
            // var column = grid.columnByField('accDealcoNm')
            this.gridObj1.gridView.commit()
            const getData = grid.getValue(itemIndex, field)
            console.log('getData', getData)

            this.selectedJsonData =
                this.gridObj1.dataProvider.getJsonRow(dataRow)
            console.log('selectedJsonData', this.selectedJsonData)
            console.log('getdataRow.fieldNameData')
        }

        // 싱글클릭 시 저장데이터 SET
        this.gridObj1.gridView.onCellClicked = (grid, clickData) => {
            // if (clickData.dataRow >= 0) {
            //     console.log('grid set1', '11111111111111111111', grid)
            //     console.log('clickData set2', '22222222222222222222', clickData)

            //     this.selectedJsonData = this.gridObj1.dataProvider.getJsonRow(
            //         clickData.dataRow
            //     )
            //     console.log('saveparam set3', this.selectedJsonData)
            //     console.log('clickData.dataRow', clickData.dataRow)
            //     console.log('saveparam set4', this.selectedJsonData.aplyEndDt)

            //     if (clickData.fieldName === 'aplyStaDt') {
            //         if (this.selectedJsonData.aplyEndDt != '99991231') {
            //             this.showTcComAlert(
            //                 '거래처 적용 종료일자가9999-12-31 인\n거래처만 적용시작일자 변경 가능합니다 '
            //             )
            //         }
            //     }
            // }
            // 그리드내의 부여조직 돋보기 클릭시 이벤트처리
            this.gridObj1.gridView.onCellButtonClicked = (
                grid,
                itemIndex,
                column
            ) => {
                console.log('22222222222222')
                console.log(grid, itemIndex, column)
                // checkbox에 체크하기
                this.gridObj1.gridView.checkItem(itemIndex.dataRow, true)

                this.gridObj1.gridView.commit()
                if (column.fieldName === 'userNm') {
                    this.btn_select_Onclick(0)
                }
            }
            // if (this.delIdxs.length == 0) {
            //     this.delIdxs.push(clickData.dataRow)
            //     console.log('delIdxs1', this.delIdxs)
            //     return
            // }
            // this.delIdxs.map((Idx) => {
            //     console.log('Idx', Idx)
            //     if (this.delIdxs[Idx] == clickData.dataRow) {
            //         console.log('if (Idx == clickData.dataRow)', Idx)
            //         this.delIdxs.splice(clickData.dataRow, 1)
            //         console.log('if (Idx == clickData.dataRow)2', this.delIdxs)
            //         return
            //     }
            // })

            this.delIdxs.push(clickData.dataRow)
            // console.log('delIdxs5', this.delIdxs)
        }
    },
    methods: {
        // 페이지 표시 행의 수 변경처리
        chgRowCnt1(val) {
            this.rowCnt = val
            // eslint-disable-next-line no-undef
            this.onSearch(this.type)
        },
        chgRowCnt2(val) {
            this.rowCnt = val
            this.onSearch(this.type)
        },
        /* 초기화 */
        init() {
            this.initParam()
            this.gridObj.setRows({})
            this.isSms = false
        },

        // async tabGrid() {
        //     this.gridObj2 = this.$refs.grid2
        //     this.gridHeaderObj2 = this.$refs.gridHeader2
        //     this.gridObj2.setGridState(true, false, true)
        //     this.gridObj2.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        // },

        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                orgCd: '', // 조직코드
                userId: '', // 사용자ID
                userNm: '', // 사용자명
                effUserYn: '', // 유효사용자여부
                orgLvl: '', // 조직레벨
                dealcoNm: '', // 거래처명
                dealcoCd: '', // 거래처코드
                pageSize: '',
                pageNum: '',
            }
            // this.$router.go()
        },
        popup(openType) {
            if (openType === 'postOrg') {
                this.showBool = true
            }
        },
        clear() {
            this.initParam()
            if (this.type == 0) {
                this.gridData1 = this.gridSetData()
                this.gridObj1.dataProvider.clearRows()
            } else {
                this.gridData2 = this.gridSetData()
                this.gridObj2.dataProvider.clearRows()
            }
        },
        onSearch(type) {
            console.log('onSearch조회', type)
            this.delIdxs = []
            if (type === 0) {
                this.gridData1.totalPage = 0

                this.getSaleChrgrList(1)
                // 0 : 거래처영업담당자 목록조회
            } else if (type === 1) {
                this.gridData2.totalPage = 0

                this.getSaleChrgr81List(1)
                // 1 : 특판처담당자
            }
        },

        getSaleChrgrList(pageNum) {
            let paramObj = { ...this.reqParam }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt
            paramObj.orgCd = this.searchParam.orgCd
            paramObj.orgLvl = this.searchParam.orgLvl
            // if (this.reqParam.effUserYn[0] !== undefined) {
            //     paramObj.effUserYn = 'Y'
            // }
            if (!_.isEmpty(this.formParam.effUserYn)) {
                paramObj.effUserYn = 'Y'
            }
            this.gridObj1.gridView.commit()

            console.log('onSearch조회 파라미터 ', paramObj)
            // 페이징 조회
            API.getSaleChrgrList(paramObj).then((resultData) => {
                if (_.isEmpty(resultData.gridList)) {
                    this.showTcComAlert('조회된 데이터가 없습니다')

                    this.gridData1 = this.gridSetData()
                    this.gridObj1.dataProvider.clearRows()

                    return
                }
                console.log(resultData)
                this.oldResultData = []
                this.oldResultData = resultData.gridList
                this.gridObj1.setRows(resultData.gridList) // 임시주석
                // 페이징 관련
                this.gridObj1.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData1 = this.gridSetData() //초기화
                this.gridData1.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj1.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                console.log('old', this.oldResultData)
            })
        },
        getSaleChrgr81List(pageNum) {
            let paramObj = { ...this.reqParam }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt
            // if (this.reqParam.effUserYn[0] !== undefined) {
            //     paramObj.effUserYn = 'Y'
            // }
            // 페이징 조회
            this.gridObj2.gridView.commit()
            API.getSaleChrgr81List(paramObj).then((resultData) => {
                if (_.isEmpty(resultData.gridList)) {
                    this.showTcComAlert('조회된 데이터가 없습니다')
                    this.gridData2 = this.gridSetData()
                    this.gridObj2.dataProvider.clearRows()
                }

                this.oldResultData = []
                this.oldResultData = resultData.gridList
                this.gridObj2.setRows(resultData.gridList) // 임시주석
                // 페이징 관련
                this.gridObj2.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData2 = this.gridSetData() //초기화
                this.gridData2.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj2.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },

        // onSmsSearch(type) {
        //     let paramObj = { ...this.reqParam }
        //     paramObj.pageNum = 1
        //     paramObj.pageSize = 10
        //     if (this.reqParam.effUserYn[0] !== undefined) {
        //         paramObj.effUserYn = 'Y'
        //     }
        //     console.log('onSmsSearch조회', type)
        //     API.getSaleChrgrUserList(paramObj).then((res) => {
        //         if (res !== undefined) {
        //             if (type === 'sms') {
        //                 this.gridObj2.setRows(res.gridList)
        //                 this.gridData2 = this.gridSetData() //초기화
        //                 this.isShowNext2(res.pagingDto)
        //                 this.gridData2.totalPage = res.pagingDto.totalPageCnt
        //                 this.gridHeaderObj2.setPageCount(res.pagingDto)
        //             }
        //         }
        //     })
        // },

        isShowNext(pageInfo) {
            this.showNext =
                pageInfo.totalDataCnt === pageInfo.pageSize ? true : false
        },
        isShowNext2(pageInfo) {
            this.showNext2 =
                pageInfo.totalDataCnt === pageInfo.pageSize ? true : false
        },

        gridAddPageBtn() {
            let paramObj = { ...this.reqParam }
            paramObj.pageNum += 1
            API.getSaleChrgrUserList(paramObj).then((res) => {
                this.isShowNext(res.pagingDto)
                this.gridData1.gridRows = this.gridHeaderObj1.setAddPage(
                    this.gridData1.gridRows,
                    res.gridList
                )
            })
        },
        gridAddPageBtn2() {
            let paramObj = { ...this.reqParam }
            paramObj.pageNum += 1
            API.getSaleChrgrUserList(paramObj).then((res) => {
                this.isShowNext2(res.pagingDto)
                this.gridData2.gridRows = this.gridHeaderObj2.setAddPage(
                    this.gridData2.gridRows,
                    res.gridList
                )
            })
        },

        async onSave() {
            let saveParam = []
            // let saveParam = {}
            let gridCreatedIndexArr = []

            let gridUpdatedIndexArr = []

            // 영업담당자
            if (this.type == 0) {
                this.gridObj1.gridView.commit()
                gridCreatedIndexArr =
                    this.gridObj1.dataProvider.getStateRows('created')
                gridUpdatedIndexArr =
                    this.gridObj1.dataProvider.getStateRows('updated')
                // insert data set

                for (let idx = 0; idx < gridCreatedIndexArr.length; idx++) {
                    let getJson = this.gridObj1.dataProvider.getJsonRow(
                        gridCreatedIndexArr[idx]
                    )

                    if (this.validation(getJson)) {
                        if (this.validation(getJson)) {
                            saveParam.push(this.setParam(getJson, 'created'))
                        }
                    }
                }
                // update data set
                for (let idx = 0; idx < gridUpdatedIndexArr.length; idx++) {
                    let getJson = this.gridObj1.dataProvider.getJsonRow(
                        gridUpdatedIndexArr[idx]
                    )

                    if (this.validation(getJson)) {
                        if (this.validation(getJson)) {
                            saveParam.push(this.setParam(getJson, 'updated'))
                        }
                    }
                }

                if (!_.isEmpty(saveParam)) {
                    await API.saveSaleChrgr(saveParam).then((result) => {
                        if (result != null) {
                            this.showTcComAlert('정상적으로 처리되었습니다.')
                            // 매핑정보 재조회
                            this.onSearch(this.type)
                        }
                    })
                } else {
                    this.showTcComAlert('변경된 거래처 영업담당자가 없습니다.')
                }

                // 특판처담당자
            } else {
                this.gridObj2.gridView.commit()
                gridCreatedIndexArr =
                    this.gridObj2.dataProvider.getStateRows('created')
                gridUpdatedIndexArr =
                    this.gridObj2.dataProvider.getStateRows('updated')

                // insert data set
                for (let idx = 0; idx < gridCreatedIndexArr.length; idx++) {
                    let getJson = this.gridObj2.dataProvider.getJsonRow(
                        gridCreatedIndexArr[idx]
                    )
                    if (this.validation(getJson)) {
                        if (this.validation(getJson)) {
                            saveParam.push(this.setParam(getJson, 'created'))
                        }
                    }
                }

                // update data set
                for (let idx = 0; idx < gridUpdatedIndexArr.length; idx++) {
                    let getJson = this.gridObj2.dataProvider.getJsonRow(
                        gridUpdatedIndexArr[idx]
                    )
                    if (this.validation(getJson)) {
                        if (this.validation(getJson)) {
                            saveParam.push(this.setParam(getJson, 'updated'))
                        }
                    }
                }
                if (!_.isEmpty(saveParam)) {
                    await API.saveSaleChrgr81(saveParam).then((result) => {
                        if (result != null) {
                            this.showTcComAlert('정상적으로 처리되었습니다.')
                            // 매핑정보 재조회
                            this.onSearch(this.type)
                        }
                    })
                } else {
                    this.showTcComAlert('변경된 특판처 담당자가 없습니다.')
                }
            }
        },

        async onDelete() {
            let saveParam = []
            let checkedRows = []

            // 영업담당자
            if (this.type == 0) {
                this.gridObj1.gridView.commit()
                checkedRows = this.gridObj1.gridView.getCheckedRows(true)
                console.log('delRow', checkedRows)
                for (let idx = 0; idx < checkedRows.length; idx++) {
                    let getJson = this.gridObj1.dataProvider.getJsonRow(
                        checkedRows[idx]
                    )

                    if (this.validation(getJson)) {
                        if (this.validation(getJson)) {
                            saveParam.push(this.setParam(getJson, 'deleted'))
                        }
                    }
                }
                if (!_.isEmpty(saveParam)) {
                    await API.deleteSaleChrgrNew(saveParam).then((result) => {
                        if (result != null) {
                            this.showTcComAlert('정상적으로 처리되었습니다.')
                            // 매핑정보 재조회
                            this.onSearch(this.type)
                        } else {
                            this.showTcComAlert('다시 시도하여 주십시오')
                        }
                    })
                } else {
                    this.showTcComAlert(
                        '삭제할 거래처 영업담당자를 선택해 주세요 '
                    )
                }

                // 특판처담당자
            } else {
                this.gridObj2.gridView.commit()
                checkedRows = this.gridObj2.gridView.getCheckedRows(true)

                for (let idx = 0; idx < checkedRows.length; idx++) {
                    let getJson = this.gridObj2.dataProvider.getJsonRow(
                        checkedRows[idx]
                    )
                    if (this.validation(getJson)) {
                        if (this.validation(getJson)) {
                            saveParam.push(this.setParam(getJson, 'deleted'))
                        }
                    }
                }
                if (!_.isEmpty(saveParam)) {
                    await API.deleteSaleChrgr81(saveParam).then((result) => {
                        if (result != null) {
                            this.showTcComAlert('정상적으로 처리되었습니다.')
                            // 매핑정보 재조회
                            this.onSearch(this.type)
                        } else {
                            this.showTcComAlert('다시 시도하여 주십시오')
                        }
                    })
                } else {
                    this.showTcComAlert(
                        '삭제할 특판처 영업담당자를 선택해 주세요 '
                    )
                }
            }
        },

        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        // gridSetData2() {
        //     return new CommonGrid(0, this.rowCnt2, '', '')
        // },
        onClick() {
            this.showBool = true
        },
        onReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
        },
        onReturnData2(retrunData) {
            console.log('retrunData: ', retrunData)
        },
        excelDown() {
            //this.gridHeaderObj1.exportGrid('saleChrgrMgmt.xls')
            let paramObj = { ...this.reqParam }
            console.log('this.searchParam -> ', this.searchParam)
            paramObj.orgCd = this.searchParam.orgCd
            paramObj.orgLvl = this.searchParam.orgLvl
            //
            // paramObj.orgCd = this.searchParam.orgCd
            // paramObj.orgLvl = this.searchParam.orgLvl

            if (!_.isEmpty(this.formParam.effUserYn)) {
                paramObj.effUserYn = 'Y'
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/usm/saleChrgrExcelList',
                paramObj
            )
        },
        excelDown2() {
            let paramObj = { ...this.reqParam }
            console.log('this.searchParam -> ', this.reqParam)
            //
            // paramObj.orgCd = this.searchParam.orgCd
            // paramObj.orgLvl = this.searchParam.orgLvl

            if (!_.isEmpty(this.formParam.effUserYn)) {
                paramObj.effUserYn = 'Y'
            }
            if (_.isEmpty(this.reqParam.dealcoCd)) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다')
            } else {
                attachedFileApi.downLoadFile(
                    '/api/v1/backend-long/resource/bas/usm/saleChrgr81ExcelList',
                    paramObj
                )
            }
            //this.gridHeaderObj2.exportGrid('smsSaleChrgrMgmt.xls')
        },
        gridAddRow() {
            this.onChrgrDealcosIconClick()
            // this.gridData1.gridRows = this.gridHeaderObj1.insertRowIndex(
            //     this.gridData1.gridRows
            // )
            // this.popup('postOrg')
            // 내부거래처-영업담당자 팝업오픈
        },
        gridAddRow2() {
            this.onChrgrDealcosIconClick()
            // this.gridData1.gridRows = this.gridHeaderObj1.insertRowIndex(
            //     this.gridData1.gridRows
            // )
            // this.popup('postOrg')
            // 내부거래처-영업담당자 팝업오픈
        },
        gridChkDelRow() {
            // let gridCreatedIndexArr =
            //     this.gridObj1.dataProvider.getStateRows('created')
            // console.log('created', gridCreatedIndexArr)
            // if (gridCreatedIndexArr.length > 0) {
            //     // this.gridData1.gridRows = this.gridHeaderObj1.chkDelRow(
            //     //     this.gridData1.gridRows
            //     // )
            //     gridCreatedIndexArr.forEach((index) => {
            //         this.gridObj1.dataProvider.removeRow(index)
            //     })
            // } else {
            //     this.onDelete()
            // }
            this.onDelete()
        },

        gridChkDelRow2() {
            // let gridCreatedIndexArr =
            //     this.gridObj1.dataProvider.getStateRows('created')
            // console.log('created', gridCreatedIndexArr)
            // if (gridCreatedIndexArr.length > 0) {
            //     this.gridData1.gridRows = this.gridHeaderObj1.chkDelRow(
            //         this.gridData1.gridRows
            //     )
            // } else {
            //     this.onDelete()
            // }
            this.onDelete()
        },

        onActiveTabChange(tabIdx) {
            console.log('onActiveTabChange: ', tabIdx)
            this.type = tabIdx
            this.isSms = false
            if (tabIdx === 1) {
                // this.tabGrid()
                this.isSms = true
                this.showBool = false
                // this.onSmsSearch()
                if (!_.isEmpty(this.gridObj2)) {
                    this.clear()
                }
            } else {
                this.isSms = true
                this.showBool = false
                // this.onSearch(tabIdx)
                if (!_.isEmpty(this.gridObj1)) {
                    this.clear()
                }
            }
            // this.onSearch(tabIdx)
        },
        onActiveTabClick() {},
        tabGridMounted() {
            this.gridObj2 = this.$refs.grid2
            this.gridHeaderObj2 = this.$refs.gridHeader2
            this.gridObj2.setGridState(true, false, true)
            // this.gridObj2.gridView.setRowIndicator({ visible: true })
            this.gridObj2.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

            // 싱글클릭 시 저장데이터 SET
            this.gridObj2.gridView.onCellClicked = (grid, clickData) => {
                // 그리드내의 부여조직 돋보기 클릭시 이벤트처리
                this.gridObj2.gridView.onCellButtonClicked = (
                    grid,
                    itemIndex,
                    column
                ) => {
                    console.log('22222222222222')
                    console.log(grid, itemIndex, column)
                    // checkbox에 체크하기
                    this.gridObj2.gridView.checkItem(itemIndex.dataRow, true)

                    this.gridObj2.gridView.commit()
                    if (column.fieldName === 'userNm') {
                        this.btn_select_Onclick(0)
                    }
                }

                this.delIdxs.push(clickData.dataRow)
                // console.log('delIdxs5', this.delIdxs)
            }
        },
        //=====================적용일자 일괄변경팝업 관련 =========================================
        async btn_setAplyDt_OnClick() {
            // let userList = []
            var checkRows1 = []
            var data1 = []
            if (this.type == 0) {
                checkRows1 = this.gridObj1.gridView.getCheckedRows(true)
            } else {
                checkRows1 = this.gridObj2.gridView.getCheckedRows(true)
            }
            if (checkRows1.length > 0) {
                checkRows1.forEach((row) => {
                    if (this.type == 0) {
                        data1 = this.gridObj1.dataProvider.getJsonRow(row)
                    } else {
                        data1 = this.gridObj2.dataProvider.getJsonRow(row)
                    }
                    console.log('BASPRMSALECHRGRMGMT  1106', data1.aplyEndDt)
                    this.resultSaleChrgrRows = []
                    this.resultPrmAplyDtBatChgRows = []
                    this.showPrmAplyDtBatChg = true
                })
            } else {
                this.showTcComAlert('거래처 영업 담당자를 선택해주세요.')
                return false
            }
        },
        // 적용일자 팝업 리턴 이벤트 처리
        onAplyDtBatChgReturnData(retrunData) {
            console.log('onAplyDtBatChgReturnData retrunData: ', retrunData)
            CommonUtil.replaceDash(
                (this.searchSaleChrgrParam.newAplyEndDt = _.get(
                    retrunData,
                    'newAplyEndDt'
                ).replaceAll('/', ''))
            )
            CommonUtil.replaceDash(
                (this.searchSaleChrgrParam.newAplyStaDt = _.get(
                    retrunData,
                    'newAplyStaDt'
                ).replaceAll('/', ''))
            )
            CommonUtil.replaceDash(
                (this.searchSaleChrgrParam.oldAplyEndDt = _.get(
                    retrunData,
                    'oldAplyEndDt'
                ).replaceAll('/', ''))
            )
            CommonUtil.replaceDash(
                (this.searchSaleChrgrParam.oldAplyStaDt = _.get(
                    retrunData,
                    'oldAplyStaDt'
                ).replaceAll('/', ''))
            )
            console.log(
                'onAplyDtBatChgReturnData searchSaleChrgrParam: ',
                this.searchSaleChrgrParam
            )
            if (this.type == 0) {
                this.setRows(this.gridObj1, 'dt')
            } else {
                this.setRows(this.gridObj2, 'dt')
            }
        },
        //=======================================================================================
        //===================== 사용자팝업(영업담당자)관련 methods ================================
        // 사용자 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 사용자 팝업 오픈
        getSaleChrgrPopList() {
            let chkRow = ''
            if (this.type == 0) {
                chkRow = this.gridObj1.gridView.getCheckedRows(true)
            } else {
                chkRow = this.gridObj2.gridView.getCheckedRows(true)
            }
            if (chkRow == '') {
                this.showTcComAlert('거래처 영업담당자 행을 선택하세요')
            } else {
                console.log(
                    'Line 1088 BAS PRMSALE CHRGR MGMT this.searchParam: ',
                    this.searchParam
                )
                // this.resultSaleChrgrRows = res
                this.showBcoSaleChrgr = true
            }
        },
        // 사용자 TextField 돋보기 Icon 이벤트 처리
        async btn_select_Onclick(cilckType) {
            //영업담당자가 이미 지정되어있으면 팝업X
            if (this.type == 0) {
                this.getRows(this.gridObj1, cilckType)
            } else {
                this.getRows(this.gridObj2, cilckType)
            }
        },
        getRows(grid, cilckType) {
            grid.gridView.commit()
            let jsonData = []

            const checkRows = grid.gridView.getCheckedRows(true)

            console.log(
                'BASPRMSALECHRGRMGMT 1104 checkRows.length',
                checkRows.length
            )
            console.log('BASPRMSALECHRGRMGMT 1104 cilckType', cilckType)
            if (checkRows.length > 0) {
                if (cilckType == 0 && checkRows.length > 1) {
                    this.showTcComAlert(
                        '영업담당자 그리드 사용자 선택시 단일건만 처리 가능합니다.\n좌측 상단의 일괄변경 - 사용자선택 버튼을 이용해주세요 '
                    )
                    return false
                }
                for (var i = 0; i < checkRows.length; i++) {
                    const data = grid.dataProvider.getJsonRow(checkRows[i])
                    console.log('------------------------data----------')
                    console.log(data)
                    if (data.aplyEndDt !== '99991231') {
                        this.showTcComAlert(
                            '거래처 적용 종료일자가9999-12-31 인\n거래처만 사용자 변경 가능합니다 '
                            // '그리드에 추가된 거래처만\n사용자 선택이 가능합니다 .'
                        )

                        return false
                    } else {
                        jsonData.push(data)
                    }
                }
            } else {
                this.showTcComAlert('거래처 영업 담당자를 선택해주세요.')
                return false
            }
            if (jsonData.length != 0) {
                this.getSaleChrgrPopList()
            }
        },
        // 사용자 TextField 엔터키 이벤트 처리
        onSaleChrgrEnterKey() {
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultSaleChrgrRows = []
            // 검색조건 사용자명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchSaleChrgrParam.UserNm)) {
                this.showTcComAlert('사용자명을 입력해주세요.')
                return
            }
            // 사용자 정보 조회
            this.getSaleChrgrList()
        },
        // 사용자 TextField Input 이벤트 처리
        onSaleChrgrInput() {
            // 입력되는 값이 있으면 사용자 코드 초기화
            this.searchSaleChrgrParam.userCd = ''
        },
        // 사용자 팝업 리턴 이벤트 처리
        async anconSaleChrgrReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchSaleChrgrParam.userId = _.get(retrunData, 'userId')
            this.searchSaleChrgrParam.userNm = _.get(retrunData, 'userNm')
            this.searchSaleChrgrParam.orgNm = _.get(retrunData, 'orgNmTree')
            if (this.type == 0) {
                this.setRows(this.gridObj1, 'user')
            } else {
                this.setRows(this.gridObj2, 'user')
            }
        },

        setRows(setGrid, setGridClCd) {
            setGrid.gridView.commit()

            const setCheckRows = setGrid.gridView.getCheckedRows(true)
            setCheckRows.forEach((row) => {
                if (setGridClCd == 'user') {
                    setGrid.gridView.setValue(
                        row,
                        'userId',
                        this.searchSaleChrgrParam.userId
                    )
                    setGrid.gridView.setValue(
                        row,
                        'userNm',
                        this.searchSaleChrgrParam.userNm
                    )
                    setGrid.gridView.setValue(row, 'effUserYn', 'Y')
                    setGrid.gridView.setValue(
                        row,
                        'orgNm',
                        this.searchSaleChrgrParam.orgNm
                    )
                }
                if (setGridClCd == 'dt') {
                    if (
                        this.searchSaleChrgrParam.newAplyStaDt !=
                        this.searchSaleChrgrParam.oldAplyStaDt
                    ) {
                        setGrid.gridView.setValue(
                            row,
                            'aplyStaDt',
                            this.searchSaleChrgrParam.newAplyStaDt
                        )
                    }
                    if (
                        this.searchSaleChrgrParam.newAplyEndDt !=
                        this.searchSaleChrgrParam.oldAplyEndDt
                    ) {
                        setGrid.gridView.setValue(
                            row,
                            'aplyEndDt',
                            this.searchSaleChrgrParam.newAplyEndDt
                        )
                    }
                }
            })
        },
        //===================== //사용자팝업(영업담당자)관련 methods ================================
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchParam.orgNm = _.get(res[0], 'orgNm')
                        this.searchParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchParam.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-영업담당자팝업관련 methods ================================
        // 내부거래처-영업담당자 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-영업담당자 팝업 오픈
        getChrgrDealcosList() {
            basBcoChrgrDealcosApi
                .getChrgrDealcosList(this.searchForm)
                .then((res) => {
                    console.log('getDealcosList then : ', res)
                    // 검색된 내부거래처-영업담당자 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-영업담당자 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-영업담당자 팝업 오픈
                    if (res.length === 1) {
                        this.searchForm.dealcoCd = _.get(res[0], 'dealcoCd')
                        this.searchForm.dealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultChrgrDealcoRows = res
                        this.showBasBcoChrgrDealcos = true
                    }
                })
        },
        // 내부거래처-영업담당자 TextField 돋보기 Icon 이벤트 처리
        onChrgrDealcosIconClick() {
            // 내부거래처-영업담당자 팝업 Row 설정 Prop 변수 초기화
            this.resultChrgrDealcoRows = []
            // 검색조건 내부거래처-영업담당자명이 빈값이 아니면 내부거래처-영업담당자 정보 조회
            // 그 이외는 내부거래처-영업담당자 팝업 오픈
            if (!_.isEmpty(this.searchForm.dealcoNm)) {
                this.getChrgrDealcosList()
            } else {
                this.showBasBcoChrgrDealcos = true
            }
        },
        // 내부거래처-영업담당자 TextField 엔터키 이벤트 처리
        onChrgrDealcosEnterKey() {
            // 내부거래처-영업담당자 팝업 Row 설정 Prop 변수 초기화
            this.resultChrgrDealcoRows = []
            // 검색조건 내부거래처-영업담당자명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchForm.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-영업담당자명 입력해주세요.'
                return
            }
            // 내부거래처-영업담당자 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-영업담당자 TextField Input 이벤트 처리
        onChrgrDealcosInput() {
            // 입력되는 값이 있으면 내부거래처-영업담당자 코드 초기화
            this.searchForm.dealcoCd = ''
        },
        // 내부거래처-영업담당자 팝업 리턴 이벤트 처리
        onChrgrDealcosReturnData(returnData) {
            console.log('retrunData: ', returnData)

            let rowCount = 0
            let cntNo = 1
            returnData.forEach((item) => {
                console.log('item!!!!', item)

                if (this.type == 0) {
                    cntNo = this.gridObj1.dataProvider.getRowCount() + 1
                } else {
                    cntNo = this.gridObj2.dataProvider.getRowCount() + 1
                }
                let insertData = {
                    ...item,
                    NO: cntNo,
                    sktDealCd: item.sktCd,
                    sktChnlCd: item.ukeyChannelCd, // SKT채널코드 AS-IS: UKEY_CHANNEL_CD
                    // dealStatus: '',
                    aplyStaDt: this.getToday(),
                    aplyEndDt: '99991231',
                }

                if (this.type == 0) {
                    // rowCount = this.gridObj1.dataProvider.getRowCount()
                    this.gridObj1.dataProvider.insertRow(rowCount, insertData)
                    this.gridObj1.gridView.checkRow(rowCount)
                    this.gridObj1.gridView.commit()
                } else {
                    // rowCount = this.gridObj2.dataProvider.getRowCount()
                    this.gridObj2.dataProvider.insertRow(rowCount, insertData)
                    this.gridObj2.gridView.checkRow(rowCount)
                    this.gridObj2.gridView.commit()
                }
            })
        },
        //===================== //내부거래처-영업담당자팝업관련 methods ================================
        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
        funcEffUserYn(e) {
            console.log('funcEffUserYn', e)
        },

        validation(jsonFile) {
            console.log(jsonFile)
            if (_.isEmpty(jsonFile.userId)) {
                this.showTcComAlert('사용자ID를 선택해주세요.')
                return false
            } else if (_.isEmpty(jsonFile.dealcoCd)) {
                this.showTcComAlert('거래처 입력해주세요.')
                return false
            } else if (_.isEmpty(jsonFile.aplyStaDt)) {
                this.showTcComAlert('적용시작일자를 입력해주세요')
                return false
            } else if (_.isEmpty(jsonFile.aplyEndDt)) {
                this.showTcComAlert('적용종료일자를 입력해주세요')
                return false
            } else {
                return true
            }
        },
        setParam(jsonFile, crudFlag) {
            let obj = {}

            obj.userId = jsonFile.userId
            obj.dealcoCd = jsonFile.dealcoCd

            obj.aplyStaDt = CommonUtil.replaceDash(
                jsonFile.aplyStaDt.replaceAll('/', '')
            )

            obj.aplyEndDt = CommonUtil.replaceDash(
                jsonFile.aplyEndDt.replaceAll('/', '')
            )
            obj.insDtm = jsonFile.insDtm ? jsonFile.insDtm : ''
            obj.orgCd = jsonFile.orgCd ? jsonFile.orgCd : ''
            obj.__rowState = crudFlag
            let hisYn = 'Y'

            for (let idx = 0; idx < this.oldResultData.length; idx++) {
                let hisgetJson = this.oldResultData[idx]
                if (
                    hisgetJson.dealcoCd == jsonFile.dealcoCd &&
                    hisgetJson.insDtm == jsonFile.insDtm &&
                    hisgetJson.userId == jsonFile.userId
                ) {
                    if (hisgetJson.aplyStaDt != jsonFile.aplyStaDt) {
                        hisYn = 'N'
                    }
                }
            }
            obj.hisYn = hisYn
            return obj
        },
    },

    // watch: {
    //     gridData1: function (newVal, oldVal) {
    //         console.log('watch gridObj1', newVal, oldVal)
    //     },
    // },
}
</script>

<style scoped></style>
