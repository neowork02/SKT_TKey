<template>
    <TCComDialog :dialogShow="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">게시판 상세</p>
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3_3">
                                <div class="arrayType">
                                    <div class="formitem div2">
                                        <TCComInput
                                            v-model="ckParam.bbsTypeNm"
                                            labelName="게시판구분"
                                            :objAuth="objAuth"
                                            :disabled="true"
                                        ></TCComInput>
                                    </div>
                                    <div class="col0">
                                        <TCComCheckBox
                                            :objAuth="objAuth"
                                            v-model="formParam.noticeYn"
                                            :disabled="true"
                                            :itemList="[
                                                {
                                                    commCdVal: 'Y',
                                                    commCdValNm: '',
                                                },
                                            ]"
                                        />
                                    </div>
                                    <div class="col0">
                                        <span class="basicTxt mgl-5">
                                            <span class="color-red"
                                                >공지글</span
                                            >
                                            (체크하면 리스트 최상단에 나오게
                                            됩니다.)</span
                                        >
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="ckParam.textTitle"
                                    labelName="제목"
                                    :disabled="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="ckParam.bbsDtl"
                                    labelName="내용"
                                    class="boxtype"
                                    :rows="rowsCnt"
                                    :disabled="true"
                                />
                            </div>
                        </div>
                    </div>
                    <!-- 파일첨부 그리드 -->
                    <AttachedFileAdd
                        ref="attachedFileAdd"
                        :fileList="fileSearchList"
                        @file-change="onFileAddChange"
                        :isDelRow="false"
                        :isFileInput="false"
                        gridHeight="50px"
                    ></AttachedFileAdd>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <div class="right">
                            <TCComButton
                                eClass="btn_ty02_point"
                                :eLarge="true"
                                :objAuth="objAuth"
                                @click="onAllDown"
                                v-show="showAllDownBtn"
                                >전체다운로드</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02_point"
                                :eLarge="true"
                                :objAuth="objAuth"
                                @click="onUser"
                                v-show="showUserBtn"
                                >조회이력</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02_point"
                                :eLarge="true"
                                :objAuth="objAuth"
                                @click="onClick"
                                v-show="showUpdateBtn"
                                >수정</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :eLarge="true"
                                :objAuth="objAuth"
                                @click="onClose"
                                >닫기</TCComButton
                            >
                            <!-- <BbsModifyPop
                                v-if="showBbsModify === true"
                                ref="popup"
                                :dialogShow.sync="showBbsModify"
                                :popupParams.sync="popupParams"
                            /> -->
                            <AdmBbsModifyPop
                                v-if="showAdmBbsModify === true"
                                ref="popup"
                                :dialogShow.sync="showAdmBbsModify"
                                :popupParams.sync="popupParams"
                            />
                            <SearchUserPop
                                v-if="SearchUserPop === true"
                                ref="popup"
                                :dialogShow.sync="SearchUserPop"
                                :popupParams.sync="popupParams"
                            />
                        </div>
                    </div>

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

// 화면 하단 버튼 정렬
<style lang="scss" scoped>
// .btn_area_bottom::v-deep {
//     display: block;
//     float: none;
//     overflow: hidden;

//     .left {
//         float: left;
//     }

//     .right {
//         float: right;
//     }
// }
</style>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import _ from 'lodash'
import AttachedFileAdd from '@/components/common/AttachedFileAdd'
import BasBbsDetailMgmtApi from '@/api/biz/bas/bbs/basBbsMgmt'
// import BbsModifyPop from '@/views/biz/bas/bbs/BasBbsModify'
import AdmBbsModifyPop from '@/views/biz/bas/bbs/AdmBbsModify'
import SearchUserPop from '@/views/biz/bas/bbs/BasSearchUser'
import attachedFileApi from '@/api/common/attachedFile'
//import _ from 'lodash'

export default {
    name: 'BasBbsDetailMgmt',
    mixins: [CommonMixin],
    components: {
        AdmBbsModifyPop,
        AttachedFileAdd,
        SearchUserPop,
    },
    props: {
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            checkbox: true,
            showUpdateBtn: true,
            showBbsModify: false,
            showAdmBbsModify: false,
            SearchUserPop: false,
            showUserBtn: true,
            showAllDownBtn: false,
            objAuth: {},
            admAppendFileList: [],
            formData: new FormData(),
            fileSearchList: [],
            itemListAdmin: [
                {
                    value: 'D',
                    text: '도매',
                },
                {
                    value: 'S',
                    text: '소매',
                },
                {
                    value: 'B',
                    text: '대형',
                },
            ],
            inputValue2: '20',
            ckParam: {
                noticeYn: '',
                bbsTypeCd: '',
                bbsTypeNm: '',
                textTitle: '',
                bbsDtl: '',
                insUserId: '',
                dealcoNm: '', // 매장명
                dealcoCd: '', // 매장코드
                userNm: '', // 사용자명
                userId: '', // 사용자아이디
                screenId: 'BASBBS00001',
                docId: '',
                bbsNo: '',
            },
            formParam: {
                noticeYn: [],
                dealcoCd: [],
                dealcoNm: [],
                userId: [],
                userNm: [],
            },
            downloadFileParam: {},
            rowsCnt: 18,
        }
    },
    mounted() {
        this.searchBoard()
        if ('Y' == this.popupParams.mainYn) {
            this.showUserBtn = false
            this.showUpdateBtn = false
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        onClose() {
            this.activeOpen = false
        },
        allCheck() {
            this.ckParam.userNm = '전체'
        },
        onClick() {
            if (this.ckParam.bbsTypeCd == 'N') {
                this.onClose()
                this.$parent.showAdmBbsModify = true
            }
            if (this.ckParam.bbsTypeCd == 'D') {
                this.onClose()
                this.$parent.showBbsModify = true
            }
            if (this.ckParam.bbsTypeCd == 'S') {
                this.onClose()
                this.$parent.showBbsModify = true
            }
            if (this.ckParam.bbsTypeCd == 'B') {
                this.onClose()
                this.$parent.showBbsModify = true
            }
            if (this.ckParam.bbsTypeCd == 'A') {
                this.onClose()
                this.$parent.showAdmBbsModify = true
            }
            if (this.ckParam.bbsTypeCd == 'I') {
                this.onClose()
                this.$parent.showAdmBbsModify = true
            }
        },
        async onUser() {
            this.SearchUserPop = true
        },
        async searchBoard() {
            await BasBbsDetailMgmtApi.getBasBbsDetailMgmt(
                this.popupParams
            ).then((resultData) => {
                this.ckParam.bbsTypeCd = resultData[0].bbsTypeCd
                this.ckParam.bbsNo = resultData[0].bbsNo
                this.ckParam.textTitle = resultData[0].textTitle
                this.ckParam.bbsDtl = resultData[0].bbsDtl

                let conText = resultData[0].bbsDtl.replace(
                    /(?:\r\n|\r|\n)/g,
                    '@#!'
                )

                var conCnt = conText.split('@#!').length - 1
                conCnt = conCnt + 3
                this.rowsCnt = conCnt

                this.ckParam.insUserId = resultData[0].insUserId
                this.formParam.dealcoNm = resultData[0].dealcoNm
                this.formParam.dealcoCd = resultData[0].dealcoCd
                this.formParam.userNm = resultData[0].userNm
                this.formParam.userId = resultData[0].userId
                this.formParam.userGrpNm = resultData[0].userGrpNm
                this.formParam.userGrpCd = resultData[0].userGrpCd
                this.formParam.grpNm = resultData[0].grpNm
                this.formParam.grpNo = resultData[0].grpNo
                this.formParam.orgNm = resultData[0].orgNm
                this.formParam.orgCd = resultData[0].orgCd
                this.ckParam.docId = resultData[0].docId
                this.formParam.docId = resultData[0].docId
                if (resultData[0].noticeYn === 'Y') {
                    this.formParam.noticeYn = [resultData[0].noticeYn]
                }
                if (this.ckParam.bbsTypeCd == 'N') {
                    this.ckParam.bbsTypeNm = '대리점공지사항'
                } else if (this.ckParam.bbsTypeCd == 'D') {
                    this.ckParam.bbsTypeNm = '도매'
                } else if (this.ckParam.bbsTypeCd == 'S') {
                    this.ckParam.bbsTypeNm = '소매'
                } else if (this.ckParam.bbsTypeCd == 'B') {
                    this.ckParam.bbsTypeNm = '대형'
                } else if (this.ckParam.bbsTypeCd == 'A') {
                    this.ckParam.bbsTypeNm = '시스템공지사항'
                } else if (this.ckParam.bbsTypeCd == 'I') {
                    this.ckParam.bbsTypeNm = '기능개선요청게시판'
                }
                if (this.userInfo.userId != this.ckParam.insUserId) {
                    this.showUpdateBtn = false
                    this.showUserBtn = false
                }
                if (this.ckParam.bbsTypeCd == 'A') {
                    this.showUserBtn = false
                } else if (this.ckParam.bbsTypeCd == 'I') {
                    this.showUserBtn = false
                } else if (this.ckParam.bbsTypeCd == 'N') {
                    this.showUserBtn = false
                }
                BasBbsDetailMgmtApi.getAttachFile(this.ckParam).then((res) => {
                    this.fileSearchList = []
                    res.forEach((item) => {
                        this.fileSearchList.push({
                            screenId: item.screenId,
                            docId: item.docId,
                            name: item.fileNm,
                            size: item.fileSize,
                            filePathNm: item.filePathNm,
                            fileType: item.fileType,
                        })
                    })
                    this.$refs.attachedFileAdd.init()
                    //alert(this.fileSearchList.length)
                    if (1 < this.fileSearchList.length) {
                        this.showAllDownBtn = true
                    }
                })
            })
        },
        onFileAddChange(files) {
            this.formData = new FormData()
            const addFileLength = files.addFile.length

            _.forEach(files.addFile, (item, index) => {
                this.formData.append('files', item.file)
                this.formData.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].screenId`,
                    'BASBBS00001'
                )
                this.formData.append(
                    `admAppendFileList[${index}].docId`,
                    this.ckParam.docId === undefined ? '' : this.ckParam.docId
                )
                this.formData.append(
                    `admAppendFileList[${index}].__rowState`,
                    'created'
                )
            })
            _.forEach(files.delFile, (item, index) => {
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].filePathNm`,
                    item.filePathNm
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].fileType`,
                    item.fileType
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].screenId`,
                    item.screenId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].docId`,
                    item.docId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].__rowState`,
                    'deleted'
                )
            })
        },
        chkData() {
            this.ckParam = this.list
        },
        onAllDown() {
            this.fileSearchList.forEach((item) => {
                let downloadFileParam = {}

                downloadFileParam.screenId = item.screenId
                downloadFileParam.docId = item.docId
                downloadFileParam.filePathNm = item.filePathNm
                downloadFileParam.fileNm = item.name
                downloadFileParam.fileType = item.fileType
                attachedFileApi.downLoadFile(
                    '/api/v1/backend/resource/common/file-download',
                    downloadFileParam
                )
            })
        },
    },
}
</script>
