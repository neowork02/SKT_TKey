import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('sal.sco.shomeSvcHstBrwsStore', Object.keys(state)),
    ...mapGetters('sal.sco.shomeSvcHstBrwsStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('sal.sco.shomeSvcHstBrwsStore', Object.keys(actions)),
    ...mapMutations('sal.sco.shomeSvcHstBrwsStore', Object.keys(mutations)),
}
