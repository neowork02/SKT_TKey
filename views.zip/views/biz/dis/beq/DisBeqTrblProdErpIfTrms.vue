<!-----------------------------------------------
 * 업무그룹명: 사고기기관리>사고기기 ERP I/F 전송
 * 서브업무명: 사고기기 ERP I/F 전송
 * 설명: 사고기기 ERP I/F 전송
 * 작성자: P179237
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>사고기기 ERP I/F 전송</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="btnSaveOnclick"
                    >ERP전송</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="cfSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="상태변경일"
                        :eRequired="true"
                        calType="DP"
                        v-model="setDate"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZSAC_C_00100"
                        labelName="확정여부"
                        v-model="dsCondition.trmsYn"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZSAC_C_00063"
                        labelName="전송구분"
                        v-model="dsCondition.trmsItemCd"
                        :filterFunc="trmsItemCdFilter"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="dsCondition.orgNm"
                        :codeVal.sync="dsCondition.orgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        @enterKey="onOrgTreeEnterKey"
                        @appendIconClick="onOrgTreeIconClick"
                        @input="onOrgTreeInput"
                    />
                    <BasBcoOrgTreesPopup
                        v-if="showBcoOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultOrgTreeRows"
                        :dialogShow.sync="showBcoOrgTrees"
                        @confirm="onOrgTreeReturnData"
                    />
                </div>
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <!--:disabled="true" -->
                    <TCComInputSearchText
                        v-model="dsCondition.dealcoNm"
                        :codeVal.sync="dsCondition.dealcoCd"
                        labelName="거래처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 2-1 -->
                <div class="formitem div4_6"></div>
            </div>
            <!-- //Search_line 2 -->
        </div>
        <!-- //Search_div -->

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="사고기기 ERP I/F 전송"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getPagingData"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil, CommonGrid, CommonMsg } from '@/utils'
import _ from 'lodash'
import { SacCommon } from '@/views/biz/sac/js'

import { G_HEADER } from '@/const/grid/dis/beq/disBeqTrblProdErpIfTrmsHead'

import api from '@/api/biz/dis/beq/disBeqTrblProdErpIfTrms'

import attachedFileApi from '@/api/common/attachedFile'

//====================내부조직팝업(전체)팝업====================
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
import basBcoOrgTreesApi from '@/api/biz/bas/bco/basBcoOrgTrees'
//====================//내부조직팝업(전체)팝업====================
//====================내부거래처-권한조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================

export default {
    name: 'DisDsmInOutDtl',
    mixins: [CommonMixin],
    components: {
        BasBcoOrgTreesPopup,
        BasBcoDealcosPop,
    },
    data() {
        return {
            indicatorOpt: { sort: 'ASC' },
            dsCondition: {
                // 내부조직 전체
                orgCd: '',
                orgNm: '',
                basMth: SacCommon.getTodayMonth(),
                // 내부거래처 권한조직 - 입출고처 << 조직넘겨줘야함 ***
                dealcoCd: '',
                dealcoNm: '',
                onlyAccDeaCoCd: 'Y',
                basDay: SacCommon.getTodayMonth(),
                // deafault data
                trmsYn: '',
                trmsItemCd: '',
                searchFromDt: '',
                searchToDt: '',
            },

            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},
            view: G_HEADER,
            dsResult: [],
            gridStyle: {
                height: '400px',
            },

            objAuth: {}, // ?????

            deleteRows: [], // 삭제대상 rows

            //popup
            popupParams: {},
            showPopup: false,
            //====================내부조직팝업(전체)팝업관련====================
            orgDisabled: false,
            showBcoOrgTrees: false, // 내부조직팝업(전체) 팝업 오픈 여부
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultOrgTreeRows: [], // 내부조직팝업(전체) 팝업 오픈 여부
            //====================//내부조직팝업(전체)팝업관련==================
            //====================내부거래처-권한조직====================
            // 거래처그룹 - 물류창고, 직영매장, 하부망 선택해줘야함
            // 거래처구분 - 직영점 ~ Acc.채널까지 범위에서 '오입금환불', 'B&C MA' 제외하고 선택
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================

            // paging
            rowCnt: 15, // 표시할 행의 갯수
            //조회 파라미터
            reqParams: {},
        }
    },
    created() {
        this.gridData = this.GridSetData()
    },
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 초기값 세팅
        this.fInit()
    },
    computed: {
        setDate: {
            get() {
                return [
                    this.dsCondition.searchFromDt,
                    this.dsCondition.searchToDt,
                ]
            },
            set(val) {
                this.dsCondition.searchFromDt = val[0]
                this.dsCondition.searchToDt = val[1]
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val[1])
                return val
            },
        },
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            this.gridObj.setGridState(true, false, true)
            this.gridData = this.GridSetData()

            this.gridObj.gridView.setColumnLayout(this.view.layout)
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 폼 초기화
        fInit: function () {
            this.dsCondition.searchFromDt = SacCommon.getFirstday()
            this.dsCondition.searchToDt = SacCommon.getToday()

            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.dsCondition['orgCd'] = this.orgInfo['orgCd']
                this.dsCondition['orgNm'] = this.orgInfo['orgNm']
                this.dsCondition['orgLvl'] = this.orgInfo['orgLvl']
                // this.dsCondition['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.dsCondition['dealcoCd'] = this.userInfo['dealcoCd']
                this.dsCondition['dealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true
            }

            // this.dsCondition.calOrdDtm = [
            //     SacCommon.getFirstday(),
            //     SacCommon.getToday(),
            // ]
        },

        //ERP전송
        async btnSaveOnclick() {
            let reqRowDatas = []
            let rows = 0
            rows = this.gridObj.gridView.getCheckedRows(true)
            for (let i in rows) {
                const idx = rows[i]
                this.dsResult[idx].chk = '1' // 백엔드 체크용
                reqRowDatas.push(this.dsResult[idx])
            }
            console.log('선택 데이터 목록 ==========', reqRowDatas)

            if (0 == rows.length) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00134', '전송건'))
                return false
            }

            const confirm = await this.showTcComConfirm(
                '전송요청 하시겠습니까?'
            )
            if (confirm) {
                const params = {
                    dsCondition: {
                        rowDatas: reqRowDatas,
                    },
                }

                await api.reqTrblProdErpTrmss(params).then((resultData) => {
                    console.log(resultData)
                    // this.showTcComAlert('정상 처리되었습니다.')
                    this.cfSearch()
                })
            }
        },
        cfSearch: function () {
            this.dsResult = []
            this.gridObj.setRows([])

            this.dsCondition.pageSize = this.rowCnt
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getPagingData(1)
        },
        getPagingData: function (pageNum) {
            this.dsCondition.pageNum = pageNum
            const formData = this.getDsCondition()

            // 페이징 조회
            api.getTrblProdErpTrmss(formData).then((resultData) => {
                if (resultData) {
                    this.dsResult = resultData.gridList
                    this.gridObj.setRows(this.dsResult)
                    // 페이징 관련
                    this.gridObj.setGridIndicator(
                        resultData.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.GridSetData() //초기화
                    this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
            })
        },

        // 조회조건 가져오기
        getDsCondition: function () {
            // testdata
            // this.dsCondition.searchFromDt = '20200101'
            // this.dsCondition.searchToDt = '20221231'
            //testdata
            // this.dsCondition.searchFromDt = this.dsCondition.calOrdDtm[0]
            // this.dsCondition.searchToDt = this.dsCondition.calOrdDtm[1]

            this.dsCondition.rgnCd = _.toString(this.dsCondition.rgnCdList)

            const reqData = SacCommon.objectRemovedArray(this.dsCondition)

            // 엑셀다운로드
            this.reqParams = reqData

            const formData = {
                dsCondition: {
                    ...reqData,
                },
            }
            return formData
        },
        trmsItemCdFilter: function (item) {
            return item.filter(
                (item) =>
                    item['commCdVal'] !== 'R13' &&
                    item['commCdVal'] !== 'F23' &&
                    item['commCdVal'] !== 'F03'
            )
        },

        // 초기화
        clearPage() {
            CommonUtil.clearPage(this, 'dsCondition')
            this.fInit()
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //Grid ExcelDown
        onClickDownload: function () {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/beq/trblProdErpTrmssExcelDown',
                this.reqParams
            )
        },

        //===================== 내부조직팝업(전체)팝업관련 methods ================================
        // 내부조직팝업(전체) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(전체) 팝업 오픈
        getOrgTreeList() {
            this.searchParam.orgCd = this.dsCondition.orgCd
            this.searchParam.orgNm = this.dsCondition.orgNm
            this.searchParam.orgLvl = this.dsCondition.orgLvl
            basBcoOrgTreesApi.getOrgTreeList(this.searchParam).then((res) => {
                console.log('getOrgTreeList then : ', res)
                // 검색된 내부조직팝업(전체) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(전체) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(전체) 팝업 오픈
                if (res.length === 1) {
                    this.dsCondition.orgCd = _.get(res[0], 'orgCd')
                    this.dsCondition.orgNm = _.get(res[0], 'orgNm')
                    this.dsCondition.orgLvl = _.get(res[0], 'orgLvl')
                } else {
                    this.resultOrgTreeRows = res
                    this.showBcoOrgTrees = true
                }
            })
        },
        // 내부조직팝업(전체) TextField 돋보기 Icon 이벤트 처리
        onOrgTreeIconClick() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이 아니면 내부조직팝업(전체) 정보 조회
            // 그 이외는 내부조직팝업(전체) 팝업 오픈
            if (!_.isEmpty(this.dsCondition.orgNm)) {
                this.getOrgTreeList()
            } else {
                this.showBcoOrgTrees = true
            }
        },
        // 내부조직팝업(전체) TextField 엔터키 이벤트 처리
        onOrgTreeEnterKey() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이면 알림창 오픈
            // if (_.isEmpty(this.dsCondition.orgNm)) {
            //     this.showAlertBool = true
            //     this.headerText = '검색조건 필수'
            //     this.alertBodyText = '내부조직팝업(전체)명을 입력해주세요.'
            //     return
            // }
            // 내부조직팝업(전체) 정보 조회
            this.getOrgTreeList()
        },
        // 내부조직팝업(전체) TextField Input 이벤트 처리
        onOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(전체) 코드 초기화
            this.dsCondition.orgCd = ''
            this.dsCondition.orgLvl = ''
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.orgCd = _.get(retrunData, 'orgCd')
            this.dsCondition.orgNm = _.get(retrunData, 'orgNm')
            this.dsCondition.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(전체)팝업관련 methods ================================
        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            this.searchForm.orgCd = this.dsCondition.orgCd
            this.searchForm.orgNm = this.dsCondition.orgNm
            this.searchForm.orgLvl = this.dsCondition.orgLvl
            this.searchForm.dealcoCd = this.dsCondition.dealcoCd
            this.searchForm.dealcoNm = this.dsCondition.dealcoNm
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.dsCondition.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.dsCondition.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // if (_.isEmpty(this.dsCondition.orgCd)) {
            //     this.showTcComAlert(CommonMsg.getMessage('MSG_00083', '조직'))
            //     return false
            // }

            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.dsCondition.dealcoNm)) {
                // this.getDealcosList()
                this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsCondition.orgCd)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return false
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.dsCondition.dealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.dsCondition.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================
    },
}
</script>
