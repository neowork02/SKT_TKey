/*****************************************
 * 업무그룹명: 판매공통업무
 * 서브업무명: 공통 Utils
 * 설명: 공통 Utils 기능
 * 작성자: P180181
 * 작성일: 2022.06.7
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
 *****************************************/
import store from '@/store'
import { CommonUtil } from '@/utils'
import moment from 'moment'
import _ from 'lodash'

import basBcoSysClsInfoApi from '@/api/biz/bas/bco/basBcoSysClsInfo'
import salCommonApi from '@/api/biz/sal/common/salCommonApi.js' //판매공통api

export default {
    // 현재일자 확인(yyyy-mm-dd)
    getToday() {
        let today = moment().format('YYYY-MM-DD') ?? ''
        if (!this.isEmpty(today)) {
            today = today.replaceAll('-', '')
        }

        return today
    },
    // 현재시각가져오기
    getTime() {
        let now = moment().format('YYYYMMDDHHmmss') ?? ''
        if (!this.isEmpty(now)) {
            now = now.replaceAll('-', '')
        }

        return now
    },
    isEmpty(val) {
        if (
            val === '' ||
            val === null ||
            val === undefined ||
            (val !== null &&
                typeof val === 'object' &&
                !Object.keys(val).length)
        ) {
            return true
        } else {
            return false
        }
    },
    toNumber(val) {
        val = String(val).replace(/,/gi, '')
        let retVal = 0
        if (
            val === '' ||
            val === null ||
            val === undefined ||
            (val !== null &&
                typeof val === 'object' &&
                !Object.keys(val).length)
        ) {
            retVal = 0
        } else {
            retVal = _.toNumber(val)
        }
        return retVal
    },
    toString(val) {
        //  console.log('SalUtil.toString', val)
        let retVal = ''
        if (
            val === '' ||
            val === null ||
            val === undefined ||
            (val !== null &&
                typeof val === 'object' &&
                !Object.keys(val).length)
        ) {
            retVal = ''
        } else {
            retVal = _.toString(val)
        }
        return retVal
    },
    getJsonCompare(a, b) {
        let newObj = Object.entries(a).sort()
        let oldObj = Object.entries(b).sort()

        console.log('newObj==', JSON.stringify(newObj))
        console.log('oldObj==', JSON.stringify(oldObj))
        let isEqual = JSON.stringify(newObj) !== JSON.stringify(oldObj)

        return isEqual
    },
    isEqual(a, b) {
        console.log(a)
        console.log(b)
        console.log('SalUtil.isEqual==', _.isEqual(a, b))
        return _.isEqual(a, b)
    },
    /*******************************************************************************
     * @description    :  두 값을 비교하여 
                         좌측 값과 우측 값이 동일 할 경우 0
                        좌측 값이 클 경우 -1 
                        우측 값이 클 경우 1
    *******************************************************************************/
    compareData(sData1, sData2) {
        var nRetValue = 1
        if (sData1 === sData2) {
            nRetValue = 0
        } else if (sData1 > sData2) {
            nRetValue = -1
        }
        return nRetValue
    },
    /*******************************************************************************
     * @description    :  조회기간 날짜 유효성검사
     *******************************************************************************/
    isValidDateFromToYear(fromDt, toDt, nInterValDay, bSameYear) {
        if (this.isEmpty(fromDt)) {
            let msg = '조회기간을 입력해주십시오.'
            store.dispatch('showTcComAlert', {
                message: msg,
                options: {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                },
            })
            return false
        }

        if (this.isEmpty(toDt)) {
            let msg = '조회기간을 입력해주십시오.'
            store.dispatch('showTcComAlert', {
                message: msg,
                options: {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                },
            })
            return false
        }

        var nCompared = this.compareData(fromDt, toDt)
        if (nCompared == -1) {
            let msg = ' 종료일자는 시작일자 이후 날짜만 입력이 가능합니다.'
            store.dispatch('showTcComAlert', {
                message: msg,
                options: {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                },
            })
            return false
        }

        if (!this.isEmpty(bSameYear) && bSameYear) {
            let fromYear = fromDt.substring(0, 4)
            let toYear = toDt.substring(0, 4)
            if (fromYear != toYear) {
                store.dispatch('showTcComAlert', {
                    message: '동일한 년에 대해서만 조회가 가능합니다.',
                    options: {
                        header: '',
                        size: '500',
                        confirmLabel: 'OK',
                    },
                })
                return false
            }
        }

        var nInterValDayTarget = CommonUtil.getDiffDate(toDt, fromDt)

        if (!this.isEmpty(nInterValDay) && nInterValDay != 0) {
            // 날짜 차 설정하지 않았을 경우
            if (nInterValDayTarget > nInterValDay) {
                let msg = nInterValDay + '일을 초과 설정하실수 없습니다. '
                store.dispatch('showTcComAlert', {
                    message: msg,
                    options: {
                        header: '',
                        size: '500',
                        confirmLabel: 'OK',
                    },
                })
                return false
            }
        }

        return true
    },
    // 최종마감일자 조회
    async getCloseBisDayMth(saleChgDtm) {
        let lastClsDtm = ''
        if (!this.isEmpty(saleChgDtm)) {
            let searchData = {}
            searchData.gubun = 'D'
            searchData.strdDt = saleChgDtm
            searchData.orgCd = '*'
            searchData.workClCd = 'SLS'
            await basBcoSysClsInfoApi
                .getCloseBisDayMth(searchData)
                .then((resultData) => {
                    console.log(resultData)
                    if (resultData.clsStCd === 'SLS') {
                        lastClsDtm = resultData.lastClsDtm
                    }
                })
        }
        return lastClsDtm
    },
    //공통코드 코드의 코드명 찾아서 리턴 Lib_sal.sf_findCmbDsCdNm
    findComboListCdNm(comboList, findCdVal) {
        console.log('findComboListCdNm', comboList, findCdVal)
        let returnVal = ''

        comboList.some((data) => {
            if (data.commCdVal === findCdVal) {
                returnVal = data.commCdValNm
                console.log(returnVal)
                return returnVal
            }
        })
        return returnVal
    },
    //오브젝트 null값 ''로 변환
    convertJsonNullData(convertObj) {
        let json = convertObj
        for (var key in json) {
            if (null == json[key]) {
                convertObj[key] = ''
            }
        }
        return convertObj
    },
    //배열 null값 ''로 변환
    convertArrayNullData(fromArray) {
        let toArray = []
        if (!this.isEmpty(fromArray) && fromArray.length > 0) {
            fromArray.forEach((data) => {
                toArray.push(this.convertJsonNullData(data))
            })
        }
        return toArray
    },
    //오브젝트 deep copy
    copyDeepJson(fromObj) {
        //object의 null값 ''로 변환
        let toObj = _.cloneDeep(fromObj)
        let convertObj = this.convertJsonNullData(toObj)
        //     console.log('copyDeepJson', convertObj)
        return convertObj
    },
    //배열 deep copy
    copyDeepArray(fromArray) {
        //object의 null값 ''로 변환
        let toArray = _.cloneDeep(fromArray)
        let convertArray = this.convertArrayNullData(toArray)
        //    console.log('copyDeepArray', convertArray)
        return convertArray
    },
    //거래처코드로 거래처명 조회
    async getDealCoMgmtNm(dealcoCd, effDt) {
        console.log('판매공통util :: getDealCoMgmtNm==', dealcoCd, effDt)
        if (this.isEmpty(effDt)) {
            effDt = this.getToday()
        }
        let dealcoNm = ''
        let ds_input = {
            dealcoCd: dealcoCd,
            effDt: effDt,
        }

        await salCommonApi.getDealCoMgmtNm(ds_input).then((res) => {
            if (!this.isEmpty(res.dealCoMgmtNm)) {
                dealcoNm = res.dealCoMgmtNm.dealcoNm
                return dealcoNm
            }
        })
        return dealcoNm
    },
    //이름 마스킹
    maskingName(strName) {
        if (this.isEmpty(strName)) return strName
        if (strName.length > 2) {
            let originName = strName.split('')
            originName.forEach(function (name, i) {
                if (i === 0 || i === originName.length - 1) return
                originName[i] = '**'
            })
            let joinName = originName.join()
            return joinName.replace(/,/g, '')
        } else {
            let pattern = /.$/ // 정규식
            return strName.replace(pattern, '**')
        }
    },
}
