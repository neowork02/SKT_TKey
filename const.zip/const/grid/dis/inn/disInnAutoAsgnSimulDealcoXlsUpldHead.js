import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT, //조직
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'crdtBalAmt',
            dataType: ValueType.TEXT, //여신잔액
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //오류사항
        },
    ],
    columns: [
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
        },
        {
            name: 'crdtBalAmt',
            fieldName: 'crdtBalAmt',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신잔액',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '250',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류사항',
                showTooltip: false,
            },
        },
    ],
}
