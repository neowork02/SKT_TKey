import { ValueType } from 'realgrid'

export const DisActProdListGRID_HEADER = {
    fields: [
        {
            fieldName: 'no',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, // 재고보유처
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mdlClCd',
            dataType: ValueType.TEXT, // 단말기구분
        },
        {
            fieldName: 'mdlClNm',
            dataType: ValueType.TEXT, // 단말기구분명
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사명
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'qty',
            dataType: ValueType.NUMBER, //수량
        },
        {
            fieldName: 'barYn',
            dataType: ValueType.TEXT, //스캔여부
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'barCdTyp',
            dataType: ValueType.TEXT, //바코드타입
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직명
        },
    ],
    columns: [
        {
            name: 'no',
            fieldName: 'no',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '번호',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '100',
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'mdlClCd',
            fieldName: 'mdlClCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'mdlClNm',
            fieldName: 'mdlClNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            type: 'data',
            visible: false,
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            type: 'data',
            visible: false,
        },
        {
            name: 'qty',
            fieldName: 'qty',
            type: 'data',
            visible: false,
        },
        {
            name: 'barYn',
            fieldName: 'barYn',
            type: 'data',
            visible: false,
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            type: 'data',
            visible: false,
        },
        {
            name: 'barCdTyp',
            fieldName: 'barCdTyp',
            type: 'data',
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            visible: false,
        },
    ],
}
