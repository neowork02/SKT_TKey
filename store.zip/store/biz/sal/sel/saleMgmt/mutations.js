export default {
    setDisInfo(state, payload) {
        state.disInfo = payload
    },
    //USIM후불취소IF
    setUsimPayChgIfInfo(state, payload) {
        state.usimPayChgIfInfo = payload
    },
    //약정변경IF
    setDsNetChgIfInfo(state, payload) {
        state.dsNetChgIfInfo = payload
    },
    //채널변경IF
    setChannelChgIfInfo(state, payload) {
        state.channelChgIfInfo = payload
    },
    //판매상세정보
    setGeneralSaleDtlInfo(state, payload) {
        state.generalSaleDtlInfo = payload
    },
    //판매상세상품정보조회
    setEquipmentSaleInfo(state, payload) {
        state.equipmentSaleInfo = payload
    },
    //부가서비스
    setSuplServiceInfo(state, payload) {
        state.suplServiceInfo = payload
    },
    //SKT예수금정보
    setSktPrprcInfo(state, payload) {
        state.sktPrprcInfo = payload
    },
    //OCB/M카드 정보
    setOcbMcardInfo(state, payload) {
        state.ocbMcardInfo = payload
    },
    //판매수수료정보
    setSaleCmmsInfo(state, payload) {
        state.saleCmmsInfo = payload
    },
    //기기교환이력정보
    setProdExchangeInfo(state, payload) {
        state.prodExchangeInfo = payload
    },
    //장려금정보
    setPromotionMoneyInfo(state, payload) {
        state.promotionMoneyInfo = payload
    },
    //프리미엄임대폰
    setPremiumRentInfo(state, payload) {
        state.premiumRentInfo_ = payload
    },
    //중고반납기기정보
    setOldRtnEquipmentInfo(state, payload) {
        state.oldRtnEquipmentInfo_ = payload
    },
    //할부매출정보
    setAllotSaleInfo(state, payload) {
        state.allotSaleInfo_ = payload
    },
    //현금매출정보
    setCashSaleInfo(state, payload) {
        state.cashSaleInfo_ = payload
    },
    //번들상품
    setBundleInfo(state, payload) {
        state.bundleInfo_ = payload
    },
    //판매Master정보
    setGeneralSaleInfo(state, payload) {
        state.generalSaleInfo_ = payload
    },
    SET_GENERAL_SALE_INFO(state, payload) {
        state.generalSaleInfo_ = payload
    },
    //판매변경IF정보
    setGeneralSaleIfInfo(state, payload) {
        state.generalSaleIfInfo_ = payload
    },
    setUkeyInfoYn(state, payload) {
        state.ukeyInfoYn = payload
    },
    setUkeyInfo(state, payload) {
        console.log('setUkeyInfo============')
        state.ukeyInfo = payload
    },
    setSuplIfList(state, payload) {
        console.log('setSuplIfList============')
        state.suplIfList = payload
    },
    setGear(state, payload) {
        console.log('setGearList============')
        state.gear = payload
    },
    setEqpCashAmt(state, payload) {
        console.log('setEqpCashAmt============')
        state.eqpCashAmt = payload
    },
    setEqpInfo(state, payload) {
        console.log('setEqpInfo============')
        state.eqpInfo_ = payload
    },
    setUsimInfo(state, payload) {
        console.log('setUsimInfo============')
        state.usimInfo_ = payload
    },
    setGearInfo(state, payload) {
        console.log('setGearInfo============')
        state.gearInfo_ = payload
    },
    setComCombo(state, payload) {
        console.log('setComCombo===' + payload)
        state.svcTypCdComboList = payload.svcTypCdComboList
        state.opStCdComboList = payload.opStCdComboList
        state.saleChnlComboList = payload.saleChnlComboList
        state.acptPathCdComboList = payload.acptPathCdComboList
        state.ageRngCdComboList = payload.ageRngCdComboList
        state.joinCardCdComboList = payload.joinCardCdComboList
        state.idmLmtCdComboList = payload.idmLmtCdComboList
        state.saleTypCdComboList = payload.saleTypCdComboList
        state.giveMthdCdComboList = payload.giveMthdCdComboList
        state.prodClComboList = payload.prodClComboList
        state.agrmtClComboList = payload.agrmtClComboList
        state.agrmtPrdCdComboList = payload.agrmtPrdCdComboList
        state.scrbFeeClComboList = payload.scrbFeeClComboList
        state.mnpCmmsClComboList = payload.mnpCmmsClComboList
        state.frgGrtInsuClComboList = payload.frgGrtInsuClComboList
        state.dualSimEqpYnList = payload.dualSimEqpYnList
    },
    setSalCommonComboList(state, payload) {
        state.saleChrgrUserList = payload.saleChrgrUserList // 판매담당자목록
        state.salesChrgrUserList = payload.salesChrgrUserList //판매처정보(영업담당자ID)
        state.accDealcoList = payload.accDealcoList // 정산처목록
        state.dealcoMgmtInfo = payload.dealcoMgmtInfo // 거래처정보
    },
}
