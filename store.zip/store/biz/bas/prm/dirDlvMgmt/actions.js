import types from './mutation-types'
import api from '@/api/biz/bas/prm/basPrmDirDlvMgmt'
import api2 from '@/api/biz/bas/prm/basPrmDealcoMgmt'
import _ from 'lodash'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    showAlert_({ commit }, { title, message }) {
        commit(types.DEFAULT_ASSIGN, {
            key: 'alertHeaderText',
            value: title,
        })
        commit(types.DEFAULT_ASSIGN, {
            key: 'alertBodyText',
            value: message,
        })
        commit(types.DEFAULT_ASSIGN, {
            key: 'alertShow',
            value: true,
        })
    },
    toasting_({ commit }, { message }) {
        commit(types.DEFAULT_ASSIGN, {
            key: 'snackbar',
            value: true,
        })
        commit(types.DEFAULT_ASSIGN, {
            key: 'snackbarText',
            value: message,
        })
    },

    async getDealCoDlvPlcList_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum
        console.log(
            '🚀 ~ file: actions.js ~ line 87 ~ searchParams',
            searchParams
        )
        await api
            .getDealCoDlvPlcList_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ line 97 ~ .then ~ data',
                    data
                )
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: data.pagingDto,
                    })
                    let body = data.gridList
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: body,
                    })
                } else {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: state.initPaging,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: [],
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },

    async getBasPrmDealcoDtlNewList_({ state, commit }) {
        let detailData
        let reqParams = state.reqParams

        await api2
            .getBasPrmDealcoDtlNewList_({ reqParams })
            .then((data) => {
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlList',
                        value: data.basPrmDealcoDtlListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlCmList',
                        value: data.basPrmDealcoDtlCmListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlCardList',
                        value: data.basPrmDealcoDtlCardListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlCrdList',
                        value: data.basPrmDealcoDtlCrdListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlDlvList',
                        value: data.basPrmDealcoDtlDlvListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlChrgrList',
                        value: data.basPrmDealcoDtlChrgrListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoDtlEarvCntList',
                        value: data.basPrmDealcoDtlEarvCntListVo,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'basPrmDealcoImagAccList',
                        value: data.basPrmDealcoImagAccListVo,
                    })
                    _.forEach(data.basPrmDealcoDtlListVo, (item) => {
                        // 거래처상세
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlCmListVo, (item) => {
                        // 사업자등록정보
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlCmListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlCardListVo, (item) => {
                        // 카드단말기
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlCardListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlCrdListVo, (item) => {
                        // 담보
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlCrdListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlDlvListVo, (item) => {
                        // 배송지
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlDlvListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlChrgrListVo, (item) => {
                        // 영업담당자
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlChrgrListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoDtlEarvCntListVo, (item) => {
                        // 전자결재 진행여부
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoDtlEarvCntListVo',
                            value: item,
                        })
                    })
                    _.forEach(data.basPrmDealcoImagAccListVo, (item) => {
                        // 매장별가상계좌
                        commit(types.DEFAULT_ASSIGN, {
                            key: 'basPrmDealcoImagAccListVo',
                            value: item,
                        })
                    })
                }
                detailData = data
            })
            .catch((error) => {
                throw error
            })

        return detailData
    },
    async dealcoMgmtUpdate_({ state }) {
        let result = 0
        let params = state.params
        await api2
            .dealcoMgmtUpdate_({ params })
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
}
