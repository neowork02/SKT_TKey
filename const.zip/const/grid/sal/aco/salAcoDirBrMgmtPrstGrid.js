import { ValueType } from 'realgrid'
// 판매마감처리현황 그리드
export const SALEADMINGRIDHEADER = {
    fields: [
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT, // 사업담당코드
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT, // 영업팀코드
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 영업파트코드
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, // 거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, // 거래처명
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT, // 거래처구분코드
        },
        {
            fieldName: 'opCl',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'opClDtl',
            dataType: ValueType.TEXT, // 항목
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, // 대리점코드
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT, // 서브점코드
        },
        {
            fieldName: 'dayTotCnt',
            dataType: ValueType.NUMBER, // 당일전송
        },
        {
            fieldName: 'dayOpCnt',
            dataType: ValueType.NUMBER, // 당일처리
        },
        {
            fieldName: 'dayYetCnt',
            dataType: ValueType.NUMBER, // 당일미처리
        },
        {
            fieldName: 'dayExcCnt',
            dataType: ValueType.NUMBER, // 당일제외
        },
        {
            fieldName: 'mthTotCnt',
            dataType: ValueType.NUMBER, // 당월전송
        },
        {
            fieldName: 'mthOpCnt',
            dataType: ValueType.NUMBER, // 당월처리
        },
        {
            fieldName: 'mthYetCnt',
            dataType: ValueType.NUMBER, // 당월미처리
        },
        {
            fieldName: 'mthExcCnt',
            dataType: ValueType.NUMBER, // 당월제외
        },
    ],
    columns: [
        {
            name: 'opCl',
            fieldName: 'opCl',
            type: 'data',
            width: '300',
            header: {
                text: '구분',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
            footer: {
                text: '합계',
            },
        },
        {
            name: 'opClDtl',
            fieldName: 'opClDtl',
            type: 'data',
            width: '300',
            styleName: 'left-column',
            header: {
                text: '항목',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'dayTotCnt',
            fieldName: 'dayTotCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '전송',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayOpCnt',
            fieldName: 'dayOpCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '처리',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayYetCnt',
            fieldName: 'dayYetCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '미처리',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayExcCnt',
            fieldName: 'dayExcCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '제외',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthTotCnt',
            fieldName: 'mthTotCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '전송',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthOpCnt',
            fieldName: 'mthOpCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '처리',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthYetCnt',
            fieldName: 'mthYetCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '미처리',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthExcCnt',
            fieldName: 'mthExcCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '제외',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
    ],
}

// 재고마감처리현황 그리드
export const STOCKADMINGRIDHEADER = {
    fields: [
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT, // 사업담당코드
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT, // 영업팀코드
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 영업파트코드
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, // 거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, // 거래처명
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT, // 거래처구분코드
        },
        {
            fieldName: 'opCl',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'opClDtl',
            dataType: ValueType.TEXT, // 항목
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, // 대리점코드
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT, // 서브점코드
        },
        {
            fieldName: 'dayTotCnt',
            dataType: ValueType.NUMBER, // 당일예정
        },
        {
            fieldName: 'dayOpCnt',
            dataType: ValueType.NUMBER, // 당일확정
        },
        {
            fieldName: 'dayYetCnt',
            dataType: ValueType.NUMBER, // 당일미확정
        },
        {
            fieldName: 'mthTotCnt',
            dataType: ValueType.NUMBER, // 당월예정
        },
        {
            fieldName: 'mthOpCnt',
            dataType: ValueType.NUMBER, // 당월확정
        },
        {
            fieldName: 'mthYetCnt',
            dataType: ValueType.NUMBER, // 당월미확정
        },
    ],
    columns: [
        {
            name: 'opCl',
            fieldName: 'opCl',
            type: 'data',
            width: '300',
            header: {
                text: '구분',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
            footer: {
                text: '합계',
            },
        },
        {
            name: 'opClDtl',
            fieldName: 'opClDtl',
            type: 'data',
            width: '300',
            styleName: 'left-column',
            header: {
                text: '항목',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'dayTotCnt',
            fieldName: 'dayTotCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '예정',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayOpCnt',
            fieldName: 'dayOpCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '확정',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayYetCnt',
            fieldName: 'dayYetCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '미확정',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthTotCnt',
            fieldName: 'mthTotCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '예정',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthOpCnt',
            fieldName: 'mthOpCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '확정',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthYetCnt',
            fieldName: 'mthYetCnt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '미확정',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
        },
    ],
}
// 시재현황 그리드
export const DECRAMTGRIDHEADER = {
    fields: [
        {
            fieldName: 'clsDt',
            dataType: ValueType.TEXT, // 마감일자
        },
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT, // 사업담당코드
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT, // 영업팀코드
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 영업파트코드
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, // 정산처코드
        },
        {
            fieldName: 'bfBondAmt',
            dataType: ValueType.NUMBER, // 전일현금잔액
        },
        {
            fieldName: 'tdayFeesAmt',
            dataType: ValueType.NUMBER, // 당일현금증가_SKT수납
        },
        {
            fieldName: 'tdayCashAmt',
            dataType: ValueType.NUMBER, // 당일현금증가_현금매출
        },
        {
            fieldName: 'toEtcmAmt',
            dataType: ValueType.NUMBER, // 당일현금증가_기타수납
        },
        {
            fieldName: 'tdayDpstAmt',
            dataType: ValueType.NUMBER, // 본사송금
        },
        {
            fieldName: 'tdayRfndAmt',
            dataType: ValueType.NUMBER, // 오입금환불
        },
        {
            fieldName: 'tdayBondAmt',
            dataType: ValueType.NUMBER, // 당일현금잔액
        },
    ],
    columns: [
        {
            name: 'bfBondAmt',
            fieldName: 'bfBondAmt',
            type: 'data',
            width: '200',
            styleName: 'right-column',
            header: {
                text: '전일 현금잔액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayFeesAmt',
            fieldName: 'tdayFeesAmt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: 'SKT수납',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayCashAmt',
            fieldName: 'tdayCashAmt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '현금매출',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'toEtcmAmt',
            fieldName: 'toEtcmAmt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '기타수납',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayDpstAmt',
            fieldName: 'tdayDpstAmt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '본사송금',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayRfndAmt',
            fieldName: 'tdayRfndAmt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '오입금환불',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'tdayBondAmt',
            fieldName: 'tdayBondAmt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '당일 현금잔액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
    ],
}
// 재고현황 그리드
export const PSPPGRIDHEADER = {
    fields: [
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, // 거래처코드
        },
        {
            fieldName: 'totInvQty',
            dataType: ValueType.NUMBER, // 상품내역_합계
        },
        {
            fieldName: 'eqpInvQty',
            dataType: ValueType.NUMBER, // 상품내역_단말기
        },
        {
            fieldName: 'etcInvQty',
            dataType: ValueType.NUMBER, // 상품내역_일반상품
        },
        {
            fieldName: 'usimInvQty',
            dataType: ValueType.NUMBER, // 상품내역_USIM
        },
        {
            fieldName: 'totInvAmt',
            dataType: ValueType.NUMBER, // 금액_합계
        },
        {
            fieldName: 'eqpInvAmt',
            dataType: ValueType.NUMBER, // 금액_단말기
        },
        {
            fieldName: 'etcInvAmt',
            dataType: ValueType.NUMBER, // 금액_일반상품
        },
        {
            fieldName: 'usimInvAmt',
            dataType: ValueType.NUMBER, // 금액_USIM
        },
    ],
    columns: [
        {
            name: 'totInvQty',
            fieldName: 'totInvQty',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '합계',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'eqpInvQty',
            fieldName: 'eqpInvQty',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '단말기',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'etcInvQty',
            fieldName: 'etcInvQty',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '일반상품',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'usimInvQty',
            fieldName: 'usimInvQty',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: 'USIM',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'totInvAmt',
            fieldName: 'totInvAmt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '합계',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'eqpInvAmt',
            fieldName: 'eqpInvAmt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '단말기',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'etcInvAmt',
            fieldName: 'etcInvAmt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '일반상품',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'usimInvAmt',
            fieldName: 'usimInvAmt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: 'USIM',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
    ],
}
// 재고현황(상세내역) 그리드
export const INVENGRIDHEADER = {
    fields: [
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, // 정산처코드
        },
        {
            fieldName: 'prodClCdNm',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'disClNm',
            dataType: ValueType.TEXT, // 항목
        },
        {
            fieldName: 'disQty',
            dataType: ValueType.NUMBER, // 보유현황_현재고
        },
        {
            fieldName: 'disAmt',
            dataType: ValueType.NUMBER, // 보유현황_평가금액
        },
        {
            fieldName: 'dayDisInQty',
            dataType: ValueType.NUMBER, // 당일_입고
        },
        {
            fieldName: 'dayDisOutQty',
            dataType: ValueType.NUMBER, // 당일_출고
        },
        {
            fieldName: 'daySaleQty',
            dataType: ValueType.NUMBER, // 당일_판매
        },
        {
            fieldName: 'dayBadQty',
            dataType: ValueType.NUMBER, // 당일_불량
        },
        {
            fieldName: 'dayRiskQty',
            dataType: ValueType.NUMBER, // 당일_사고
        },
        {
            fieldName: 'dayInNonFixQty',
            dataType: ValueType.NUMBER, // 당일_입고미확정
        },
        {
            fieldName: 'bfMthQty',
            dataType: ValueType.NUMBER, // 당월_이월
        },
        {
            fieldName: 'mthDisInQty',
            dataType: ValueType.NUMBER, // 당월_입고
        },
        {
            fieldName: 'mthDisOutQty',
            dataType: ValueType.NUMBER, // 당월_출고
        },
        {
            fieldName: 'mthSaleQty',
            dataType: ValueType.NUMBER, // 당월_판매
        },
        {
            fieldName: 'mthBadQty',
            dataType: ValueType.NUMBER, // 당월_불량
        },
        {
            fieldName: 'mthRiskQty',
            dataType: ValueType.NUMBER, // 당월_사고
        },
        {
            fieldName: 'mthInNonFixQty',
            dataType: ValueType.NUMBER, // 당월_입고미확정
        },
        {
            fieldName: 'disRt',
            dataType: ValueType.TEXT, // 재고보유율
        },
    ],
    columns: [
        {
            name: 'prodClCdNm',
            fieldName: 'prodClCdNm',
            type: 'data',
            width: '120',
            header: {
                text: '구분',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'disClNm',
            fieldName: 'disClNm',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            header: {
                text: '항목',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'disQty',
            fieldName: 'disQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '현재고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'disAmt',
            fieldName: 'disAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '평가금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayDisInQty',
            fieldName: 'dayDisInQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '입고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayDisOutQty',
            fieldName: 'dayDisOutQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '출고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'daySaleQty',
            fieldName: 'daySaleQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '판매',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayBadQty',
            fieldName: 'dayBadQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '불량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayRiskQty',
            fieldName: 'dayRiskQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '사고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayInNonFixQty',
            fieldName: 'dayInNonFixQty',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '입고미확정',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'bfMthQty',
            fieldName: 'bfMthQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '이월',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthDisInQty',
            fieldName: 'mthDisInQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '입고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthDisOutQty',
            fieldName: 'mthDisOutQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '출고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthSaleQty',
            fieldName: 'mthSaleQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '판매',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthBadQty',
            fieldName: 'mthBadQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '불량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthRiskQty',
            fieldName: 'mthRiskQty',
            type: 'data',
            width: '70',
            styleName: 'right-column',
            header: {
                text: '사고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthInNonFixQty',
            fieldName: 'mthInNonFixQty',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '입고미확정',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'disRt',
            fieldName: 'disRt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '재고보유율',
                showTooltip: false,
            },
        },
    ],
}
// 실적현황 그리드
export const RECORDGRIDHEADER = {
    fields: [
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, // 정산처코드
        },
        {
            fieldName: 'saleRsltItm',
            dataType: ValueType.TEXT, // 항목
        },
        {
            fieldName: 'saleRsltItmDtl',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'trgtQty',
            dataType: ValueType.NUMBER, // 목표실적
        },
        {
            fieldName: 'daySaleQty',
            dataType: ValueType.NUMBER, // 당일실적
        },
        {
            fieldName: 'mthSaleQty',
            dataType: ValueType.NUMBER, // 당월실적
        },
        {
            fieldName: 'trgtAchvRt',
            dataType: ValueType.TEXT, // 달성율
        },
        {
            fieldName: 'trgtGapQty',
            dataType: ValueType.NUMBER, // 목표GAP
        },
        {
            fieldName: 'asmptSaleQty',
            dataType: ValueType.NUMBER, // 예상마감
        },
        {
            fieldName: 'asmptAchvRt',
            dataType: ValueType.TEXT, // 예상달성율
        },
        {
            fieldName: 'bizChrgRank',
            dataType: ValueType.TEXT, // 사업담당순위
        },
        {
            fieldName: 'hqRank',
            dataType: ValueType.TEXT, // 전사순위
        },
    ],
    columns: [
        {
            name: 'saleRsltItm',
            fieldName: 'saleRsltItm',
            type: 'data',
            width: '120',
            header: {
                text: '항목',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'saleRsltItmDtl',
            fieldName: 'saleRsltItmDtl',
            type: 'data',
            width: '120',
            header: {
                text: '구분',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'trgtQty',
            fieldName: 'trgtQty',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '목표실적',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'daySaleQty',
            fieldName: 'daySaleQty',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '당일실적',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthSaleQty',
            fieldName: 'mthSaleQty',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '당월실적',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'trgtAchvRt',
            fieldName: 'trgtAchvRt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '달성율',
                showTooltip: false,
            },
        },
        {
            name: 'trgtGapQty',
            fieldName: 'trgtGapQty',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '목표GAP',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'asmptSaleQty',
            fieldName: 'asmptSaleQty',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '예상마감',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'asmptAchvRt',
            fieldName: 'asmptAchvRt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '예상달성율',
                showTooltip: false,
            },
        },
        {
            name: 'bizChrgRank',
            fieldName: 'bizChrgRank',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '사업담당순위',
                showTooltip: false,
            },
        },
        {
            name: 'hqRank',
            fieldName: 'hqRank',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '전사순위',
                showTooltip: false,
            },
        },
    ],
}
// 세금계산서발행현황 그리드
export const TAXINVOICEGRIDHEADER = {
    fields: [
        {
            fieldName: 'gubun',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'dayRowCnt',
            dataType: ValueType.NUMBER, // 당일_발행건수
        },
        {
            fieldName: 'daySplyPrc',
            dataType: ValueType.NUMBER, // 당일_발행공급가
        },
        {
            fieldName: 'dayVatAmt',
            dataType: ValueType.NUMBER, // 당일_발행세액
        },
        {
            fieldName: 'daySumAmt',
            dataType: ValueType.NUMBER, // 당일_발행합계
        },
        {
            fieldName: 'mthRowCnt',
            dataType: ValueType.NUMBER, // 당월_발행건수
        },
        {
            fieldName: 'mthSplyPrc',
            dataType: ValueType.NUMBER, // 당월_발행공급가
        },
        {
            fieldName: 'mthVatAmt',
            dataType: ValueType.NUMBER, // 당월_발행세액
        },
        {
            fieldName: 'mthSumAmt',
            dataType: ValueType.NUMBER, // 당월_발행합계
        },
    ],
    columns: [
        {
            name: 'gubun',
            fieldName: 'gubun',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            header: {
                text: '구분',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'dayRowCnt',
            fieldName: 'dayRowCnt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            header: {
                text: '발행건수',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'daySplyPrc',
            fieldName: 'daySplyPrc',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            header: {
                text: '발행공급가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'dayVatAmt',
            fieldName: 'dayVatAmt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            header: {
                text: '발행세액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'daySumAmt',
            fieldName: 'daySumAmt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            header: {
                text: '발행합계',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthRowCnt',
            fieldName: 'mthRowCnt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            header: {
                text: '발행건수',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthSplyPrc',
            fieldName: 'mthSplyPrc',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            header: {
                text: '발행공급가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthVatAmt',
            fieldName: 'mthVatAmt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            header: {
                text: '발행세액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthSumAmt',
            fieldName: 'mthSumAmt',
            type: 'data',
            width: '120',
            styleName: 'right-column',
            header: {
                text: '발행합계',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
    ],
}
// 손익현황 그리드
export const PROFITLOSSGRIDHEADER = {
    fields: [
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, // 순번
        },
        {
            fieldName: 'rsltItm',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'rsltSubItm',
            dataType: ValueType.TEXT, // 항목
        },
        {
            fieldName: 'dayRslt',
            dataType: ValueType.NUMBER, // 당일실적
        },
        {
            fieldName: 'mthRslt',
            dataType: ValueType.NUMBER, // 당월실적
        },
        {
            fieldName: 'asmptRslt',
            dataType: ValueType.NUMBER, // 예상마감
        },
    ],
    columns: [
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            width: '70',
            header: {
                text: '순번',
                showTooltip: false,
            },
        },
        {
            name: 'rsltItm',
            fieldName: 'rsltItm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '구분',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'rsltSubItm',
            fieldName: 'rsltSubItm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '항목',
                showTooltip: false,
            },
            mergeRule: {
                criteria: 'value',
            },
        },
        {
            name: 'dayRslt',
            fieldName: 'dayRslt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '당일실적',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mthRslt',
            fieldName: 'mthRslt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '당월실적',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'asmptRslt',
            fieldName: 'asmptRslt',
            type: 'data',
            width: '150',
            styleName: 'right-column',
            header: {
                text: '예상마감',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
    ],
}
