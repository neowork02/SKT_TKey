import _ from 'lodash'
// import * as XLSX from 'xlsx'
// import { FileUtil } from '@/utils'
import { AccUtil } from '@/views/biz/acc'
import sacApi from '@/api/biz/acc/sac'
import pacApi from '@/api/biz/acc/pac'
import sssApi from '@/api/biz/acc/sss/AccSssSkbCmmsIncenAccMgmt'
export default {
    onChange: function (pageType, tabNum, files, columns, fnReset, callback) {
        fnReset()
        if (!_.isUndefined(files) && !_.isNull(files)) {
            let formData = new FormData()
            let key = tabNum
            formData.append('files', files)
            formData.append('key', key)

            if (pageType == 'wless') {
                this.getParseExcelWlessTcip(formData, columns, callback)
            }
            if (pageType == 'wire') {
                this.getParseExcelWireTcip(formData, columns, callback)
            }
            if (pageType == 'card') {
                this.getParseExcelCardTcip(formData, columns, callback)
            }
            if (pageType == 'skb') {
                this.getParseExcelSkbTcip(formData, columns, callback)
            }
        }
    },
    getParseExcelWlessTcip(data, columns, callback) {
        sacApi.getParseExcelWlessTcip(data).then((res) => {
            console.log('res', res)
            this.processWorkbook(res, columns, callback)
        })
    },
    getParseExcelWireTcip(data, columns, callback) {
        sacApi.getParseExcelWireTcip(data).then((res) => {
            console.log('res', res)
            this.processWorkbook(res, columns, callback)
        })
    },

    getParseExcelCardTcip(data, columns, callback) {
        pacApi.getParseExcelCardTcip(data).then((res) => {
            console.log('res', res)
            this.processWorkbook(res, columns, callback)
        })
    },

    getParseExcelSkbTcip(data, columns, callback) {
        sssApi.getParseExcelSkbTcip(data).then((res) => {
            console.log('res', res)
            this.processWorkbook(res, columns, callback)
        })
    },

    processWorkbook(res, columns, callback) {
        // uploadList
        var uploadList = res.map((item) => {
            var jsonData = {}
            columns.map((column) => {
                var excelName = column.fieldName
                if (_.isEmpty(excelName)) {
                    excelName = column.header.text
                }

                // 영업월일 경우, saleMthClCd로 값 추가
                if (excelName == '영업월') {
                    jsonData['saleMthClNm'] = _.trim(this.getSaleMthClCd(item))
                    return true // (=continue)
                }

                // 금액일 경우, amt로 값 추가
                if (_.isEmpty(item[excelName]) && excelName == '금액') {
                    jsonData['amt'] = item[excelName]
                    return true // (=continue)
                }

                // 숫자일 경우, 콤마 제거
                if (column.dataType == 'number') {
                    if (!_.isEmpty(item[excelName])) {
                        item[excelName] = item[excelName].replace(/,/g, '')
                    }
                }

                if (column.name == 'splyPrc') {
                    if (!_.isEmpty(item[excelName])) {
                        item[excelName] = item[excelName].replace(/,/g, '')
                    }
                }

                jsonData[column.fieldName] = _.trim(item[excelName])
            })

            console.log('jsonData', jsonData)
            return jsonData
        })

        callback(uploadList)
        // }
        // }
    },
    /**
     * 영업월일 경우, 추출이 잘 안되는 문제로 인해 강제 추출한다.
     * - 엑셀업로드 양식에 이름이 아래처럼 돼 있기 때문에 에러로 인해 강제 추출한다.
     *  => 영업월(당월:2, 이전월:1 => 숫자입력)
     */
    getSaleMthClCd: function (json) {
        var val = ''
        var keys = Object.keys(json)
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i]
            if (key.indexOf('영업월') == 0) {
                val = json[key]
                break
            }
        }

        return val
    },
    /**
     * 필수항목 체크
     * - 빈값이면 true, 값이 있으면 false를 반환한다.
     */
    getCheckRequired: function (data, requiredExcelGrid) {
        console.log('AccExcelUpload')
        var resultJson = {
            isPass: true,
            key: '',
            errMsg: '',
        }
        var keys = Object.keys(requiredExcelGrid)
        keys.map((key) => {
            if (resultJson.isPass && AccUtil.isEmpty(data[key])) {
                resultJson = {
                    isPass: false,
                    key: key,
                    errMsg: requiredExcelGrid[key] + '은(는) 필수항목입니다.',
                }
                return false
            }
        })

        return resultJson
    },
    /* 해당 정산처코드가 정산처 목록에 존재하는지 체크한다. */
    isExistsAccDealcoCd: function (accDealcoCd, list) {
        var isExists = false
        if (list) {
            isExists = list.some(function (json) {
                return accDealcoCd == json.accDealcoCd
            })
        }

        return isExists
    },
    /* 해당 정산처코드가 직영점인지 체크한다. */
    isDirectDealco: function (accDealcoCd, list) {
        var isDirect = false
        if (list) {
            isDirect = list.some(function (json) {
                return accDealcoCd == json.accDealcoCd && json.directYn == 'Y'
            })
        }

        return isDirect
    },
    /* 해당 정산처코드가 ERP데이터에 존재하는지 여부를 체크한다. */
    isErpExists: function (accDealcoCd, list) {
        var isErpExists = false
        if (list) {
            isErpExists = list.some(function (json) {
                return (
                    accDealcoCd == json.accDealcoCd && json.erpExistsYn == 'Y'
                )
            })
        }

        return isErpExists
    },
    /* 해당 정산처코드가 정산완료됐는지 여부를 체크한다. */
    isErpFix: function (accDealcoCd, list) {
        var isErpFix = false
        if (list) {
            isErpFix = list.some(function (json) {
                // AS-IS에서는 erpFixYn=='Y'를 체크하는데 fixYn=='Y'인 것을 체크하는 것으로 수정함(고용진 차장님 의견 반영)
                return json.accExistsYn == 'Y' && json.fixYn == 'Y'
            })
        }

        return isErpFix
    },
    /* 해당 코드가 존재하는지 여부 체크한다. */
    checkExistsCode: function (code, list) {
        var isExists = false
        if (list) {
            isExists = list.some(function (json) {
                return code == json.commCdVal
            })
        }

        return isExists
    },
    /* 오류데이터 Grid에 출력할 내용 return */
    getErrGridJson: function (data, errMsg) {
        return {
            accDealcoCd: data.accDealcoCd,
            accDealcoNm: data.accDealcoNm,
            amt: data.amt,
            errMsg: errMsg,
        }
    },
    /* 오류데이터 Grid에 출력할 내용 return */
    getGagamErrGridJson: function (data, errMsg) {
        return {
            accDealcoCd: data.accDealcoCd,
            accDealcoNm: data.accDealcoNm,
            svcMgmtNum: data.svcMgmtNum,
            addSubItmNm: data.addSubItmNm,
            amt: data.amt,
            errMsg: errMsg,
        }
    },
    /*
     SKB수수료/인센티브 정산관리 엑셀업로드
     오류데이터 Grid에 출력할 내용 return 
     */
    getAccPssSkbErrGridJson: function (data, errMsg) {
        return {
            wireAccClCd: data.wireAccClCd,
            prodClCd: data.prodClCd,
            agencyCd: data.agencyCd,
            agencyNm: data.agencyNm,
            splyPrc: data.splyPrc,
            rmks: data.rmks,
            errMsg: errMsg,
        }
    },
}
