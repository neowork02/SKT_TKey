<!-----------------------------------------------
 * 업무그룹명: RadioBox 컴포넌트 (No Label)
 * 서브업무명: RadioBox 공통함수 (No Label)
 * 설명: Tab 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.04.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <span :class="spanClass">
        <v-radio-group
            row
            :value="value"
            :readonly="readonly"
            :disabled="disabled"
            :rules="getRules"
            color="point"
            @change="emitChange"
        >
            <v-radio
                v-for="item in cItemList"
                v-bind:key="item[itemValue]"
                :label="item[itemText]"
                :value="item[itemValue]"
                color="point"
            ></v-radio>
        </v-radio-group>
    </span>
</template>

<script>
import commonApi from '@/api/common/prototype'
import _ from 'lodash'
export default {
    inheritAttrs: false,
    name: 'TCComNoLabelRadioBox',
    components: {},
    props: {
        value: { type: String, default: '', required: false },
        codeId: { type: String, default: '', required: false },
        //텍스트박스 명
        labelName: { type: String, default: '', required: false },
        //필수입력여부
        eRequired: { type: Boolean, default: false, required: false },
        // disabled
        disabled: { type: Boolean, default: false, required: false },
        // readonly
        readonly: { type: Boolean, default: false, required: false },
        // auth
        objAuth: { type: Object, default: () => {}, required: false },
        // ITEM TEXT
        itemText: { type: String, default: 'commCdValNm', required: false },
        // ITEM VALUE
        itemValue: { type: String, default: 'commCdVal', required: false },
        // 목록 정보(codeID가 없을때만 적용)
        itemList: {
            type: Array,
            default: () => [],
            required: false,
        },
        // Blank Item 추가 여부
        addBlankItem: { type: Boolean, default: false, required: false },
        // Blank Item Text
        blankItemText: { type: String, default: '전체', required: false },
        // Sort By
        sortBy: { type: [String, Array], required: false },
        // Sort Order
        sortOrder: { type: String, default: 'asc', required: false },
        // 함수, 부울 및 문자열의 혼합 배열을 사용할 수 있습니다.
        // 함수는 입력값을 인수로 전달하며 true/false 또는 오류 메시지를 포함하는 문자열을 반환해야 합니다.
        // 함수가 false를 반환하거나(또는 배열의 모든 값에 포함됨) 문자열인 경우 입력 필드가 오류 상태가 됩니다.
        rules: { required: false },
        // 사용자 정의 필터 함수 설정
        filterFunc: { type: Function, required: false },
        // span class
        spanClass: {
            type: String,
            default: 'iteminput-type2',
            required: false,
        },
    },

    data() {
        return {
            dCommItemList: [],
        }
    },
    computed: {
        cItemList() {
            let items = []
            if (!_.isEmpty(this.codeId)) {
                items = this.dCommItemList.slice()
            } else {
                items = this.itemList.slice()
            }
            if (!_.isEmpty(items)) {
                if (typeof this.filterFunc === 'function') {
                    items = this.filterFunc(items)
                }

                if (this.sortBy) {
                    items = _.sortBy(items, this.sortBy)
                    if (this.sortOrder !== 'asc') {
                        items.reverse()
                    }
                }

                if (this.addBlankItem) {
                    items.unshift({
                        [this.itemValue]: '',
                        [this.itemText]: this.blankItemText,
                    })
                }
            }
            return items
        },
        getRules() {
            let rules = []
            if (this.rules) {
                rules = this.rules
            }
            return rules
        },
        getValueText() {
            let items = []
            if (!_.isEmpty(this.codeId)) {
                items = this.dCommItemList
            } else {
                items = this.itemList
            }
            return _.find(items, {
                [this.itemValue]: this.value,
            })?.[this.itemText]
        },
    },
    // props 동적 제어
    watch: {
        value: function () {
            this.emitInput(this.value)
        },
        codeId: function () {
            if (!_.isEmpty(this.codeId)) {
                this.getCommCodeList()
            }
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            // 코드 ID 존재시 공통코드 호출
            if (!_.isEmpty(this.codeId)) {
                this.getCommCodeList()
            }
        },
        emitInput(value) {
            this.$emit('input', value)
        },
        emitChange(value) {
            this.emitInput(value)
            this.$emit('change', value)
        },
        // 공통코드 API
        getCommCodeList() {
            commonApi.getCommonCodeList(this.codeId).then((res) => {
                this.dCommItemList = res
            })
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
