import { ValueType } from 'realgrid'

export const DisDsmSknOderInOmsnPrst_GRID_HEADER = {
    fields: [
        {
            fieldName: 'sknOutDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //SKN 매출일
        },
        {
            fieldName: 'inoutDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //입고일자
        },
        {
            fieldName: 'opTm',
            dataType: ValueType.TEXT, //전송시각
        },
        {
            fieldName: 'opClCd',
            dataType: ValueType.TEXT, //처리구분
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //관리조직
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'dealCoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealCoNm',
            dataType: ValueType.TEXT, //거래처
        },
        {
            fieldName: 'sknDlvcoCd',
            dataType: ValueType.TEXT, //배송지코드
        },
        {
            fieldName: 'sknDelvPlcNm',
            dataType: ValueType.TEXT, //배송지명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'sknTypNm',
            dataType: ValueType.TEXT, //입고수불유형
        },
        {
            fieldName: 'errorClNm',
            dataType: ValueType.TEXT, //오류내용
        },
    ],
    columns: [
        {
            name: 'sknOutDt',
            fieldName: 'sknOutDt',
            header: {
                text: 'SKN 매출일',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'col4',
            fieldName: 'inoutDt',
            header: {
                text: '입고일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'opTm',
            fieldName: 'opTm',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전송시각',
                showTooltip: false,
            },
            textFormat: '([0-9]{2})([0-9]{2})([0-9]{2})$;$1:$2:$3',
        },
        {
            name: 'opClCd',
            fieldName: 'opClCd',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리구분',
                showTooltip: false,
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '관리조직',
                showTooltip: false,
            },
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            width: '90',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            width: '140',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '대리점명',
                showTooltip: false,
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            width: '90',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoCd',
            fieldName: 'dealCoCd',
            type: 'data',
            width: '90',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoNm',
            fieldName: 'dealCoNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처',
                showTooltip: false,
            },
        },
        {
            name: 'sknDlvcoCd',
            fieldName: 'sknDlvcoCd',
            type: 'data',
            width: '90',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배송지코드',
                showTooltip: false,
            },
        },
        {
            name: 'sknDelvPlcNm',
            fieldName: 'sknDelvPlcNm',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '배송지명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '70',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '70',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '70',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'sknTypNm',
            fieldName: 'sknTypNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '입고수불유형',
                showTooltip: false,
            },
        },
        {
            name: 'errorClNm',
            fieldName: 'errorClNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '오류내용',
                showTooltip: false,
            },
        },
    ],
}
