<template>
    <div class="content">
        <!-- Tit -->
        <h1>BI연동매핑관리</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        v-model="div_search.biId"
                        :eRequired="true"
                        labelName="아이디"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="div_search.deptCd"
                        :eRequired="true"
                        labelName="부서코드"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="div_search.deptNm"
                        :eRequired="true"
                        labelName="부서명"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComRadioBox
                        v-model="div_search.aplyYn"
                        :itemList="ds_radio"
                        labelName="반영여부"
                        :objAuth="this.objAuth"
                    ></TCComRadioBox>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="매핑정보"
                :gridObj="gridObj"
                :isAddRow="true"
                :isDelRow="false"
                :isExceldown="true"
                @addRowBtn="btn_add_OnClick"
                @chkDelRowBtn="btn_del_OnClick"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getBiUserList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMsg from '@/utils/CommonMsg'
import _ from 'lodash'
import { HEADER } from '@/const/grid/bas/usm/basUsmBiLnkgMappMgmtHeader'
import API from '@/api/biz/bas/usm/basUsmBiLnkgMappMgmt'
import CommonMixin from '@/mixins'

export default {
    name: 'BasUsmBiLnkgMappMgmt',
    components: {},
    mixins: [CommonMixin],
    data() {
        return {
            // gridStyle: {
            //     height: '500px', //그리드 높이 조절
            // },
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            ds_radio: [
                {
                    commCdVal: '0',
                    commCdValNm: '미반영',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '반영',
                },
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
            ],
            objAuth: {},
            div_search: {
                biId: '',
                deptCd: '',
                deptNm: '',
                aplyYn: '0',
            },
            rowCnt: 15,
            biIdList: [],
            deptCdList: [],
            dutyCdList: [],
            rpstyCdList: [],
            userGrpList: [],
            selectedJsonData: {},
            getData: '',
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

        this.init()
        this.dropDownSetting()
        // this.dutyCdList.map((dutyCd) => {
        //     if (dutyCd.commCdVal == getData) {
        //         grid.setValue(itemIndex, 'dutyNm', dutyCd.commCdValNm)
        //         return
        //     }
        // })

        this.gridObj.gridView.onCellEdited = (
            grid,
            itemIndex,
            dataRow,
            field
        ) => {
            // var column = grid.columnByField('accDealcoNm')
            this.gridObj.gridView.commit()
            this.getData = grid.getValue(itemIndex, field)
            console.log('getData', this.getData)
            console.log('rpstyCdList', this.rpstyCdList)
            console.log('field', field)
            if (field == 1) {
                this.biIdList.map((duty) => {
                    if (duty.commCdVal == this.getData) {
                        grid.setValue(itemIndex, 'biIdNm', duty.commCdValNm)
                        return
                    }
                })
            } else if (field == 4) {
                grid.setValue(itemIndex, 'userGrpCd', this.getData)
            } else if (field == 7) {
                this.dutyCdList.map((duty) => {
                    if (duty.commCdVal == this.getData) {
                        grid.setValue(itemIndex, 'dutyNm', duty.commCdValNm)
                        return
                    }
                })
            } else if (field == 9) {
                this.rpstyCdList.map((rpsty) => {
                    if (rpsty.commCdVal == this.getData) {
                        grid.setValue(itemIndex, 'rpstyNm', rpsty.commCdValNm)
                        return
                    }
                })
            }
            this.selectedJsonData =
                this.gridObj.dataProvider.getJsonRow(dataRow)
            console.log('selectedJsonData', this.selectedJsonData)
        }

        // 그리드내의 부여조직 돋보기 클릭시 이벤트처리
        this.gridObj.gridView.onCellButtonClicked = (
            grid,
            itemIndex,
            column
        ) => {
            this.gridObj.gridView.commit()
            if (
                column.fieldName === 'orgNm' ||
                column.fieldName === 'bizChrgOrgNm'
            ) {
                this.onOrgTreeIconClick()
            } else if (column.fieldName === 'dealcoNm') {
                this.onDealcoIconClick()
            }
        }
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.gridSetData()
            this.gridObj.setGridState()
            this.gridObj.gridView.setRowIndicator({ visible: true })
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        //조회 버튼 이벤트
        onSearch: function () {
            // console.log('reqParam : ', reqParam)
            // API.getBiUserList(reqParam).then((resultData) => {
            //     console.log('resultData : ', resultData)
            //     this.ds_list = resultData
            //     this.gridObj.setRows(resultData)
            //     console.log('조회완료')
            // })
            this.gridData.totalPage = 0
            this.getBiUserList(1)
        },

        getBiUserList(pageNum) {
            let reqParam = {
                biId: this.div_search.biId,
                deptCd: this.div_search.deptCd,
                deptNm: this.div_search.deptNm,
                aplyYn: this.div_search.aplyYn,
            }
            reqParam.pageNum = pageNum
            reqParam.pageSize = this.rowCnt
            console.log('reqParam : ', reqParam)
            // 페이징 조회
            API.getBiUserList(reqParam).then((result) => {
                if (result.gridList) {
                    this.ds_list = result.gridList
                    this.gridObj.setRows(result.gridList)
                    // 페이징 관련
                    this.gridObj.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting

                    this.getNm()
                    // 업데이트상태인 인덱스를 기본상태로 초기화
                    let gridUpdatedIndexArr =
                        this.gridObj.dataProvider.getStateRows('updated')
                    this.gridObj.dataProvider.setRowStates(
                        gridUpdatedIndexArr,
                        'none'
                    )
                }
            })
        },

        getNm() {
            this.ds_list.map((row, itemIndex) => {
                this.biIdList.map((biId) => {
                    // let getData = this.gridObj.gridView.getValue(idx, 'biId')
                    if (row.biId == biId.commCdVal) {
                        this.gridObj.gridView.setValue(
                            itemIndex,
                            'biIdNm',
                            biId.commCdValNm
                        )
                        // this.gridObj.gridView.setColumn(col1)
                        return
                    }
                })
            })
            this.ds_list.map((row, itemIndex) => {
                this.dutyCdList.map((duty) => {
                    // let getData = this.gridObj.gridView.getValue(idx, 'biId')
                    if (row.dutyCd == duty.commCdVal) {
                        this.gridObj.gridView.setValue(
                            itemIndex,
                            'dutyNm',
                            duty.commCdValNm
                        )
                        // this.gridObj.gridView.setColumn(col1)
                        return
                    }
                })
            })
            this.ds_list.map((row, itemIndex) => {
                this.rpstyCdList.map((rpsty) => {
                    // let getData = this.gridObj.gridView.getValue(idx, 'biId')
                    if (row.rpstyCd == rpsty.commCdVal) {
                        this.gridObj.gridView.setValue(
                            itemIndex,
                            'rpstyNm',
                            rpsty.commCdValNm
                        )
                        // this.gridObj.gridView.setColumn(col1)
                        return
                    }
                })
            })
            // this.dataProvider.setRowStates(state, 'none')
            // if (field == 1) {
            //     this.biIdList.map((duty) => {
            //         if (duty.commCdVal == this.getData) {
            //             grid.setValue(itemIndex, 'biIdNm', duty.commCdValNm)
            //             return
            //         }
            //     })
            // } else if (field == 4) {
            //     grid.setValue(itemIndex, 'userGrpCd', this.getData)
            // } else if (field == 7) {
            //     this.dutyCdList.map((duty) => {
            //         if (duty.commCdVal == this.getData) {
            //             grid.setValue(itemIndex, 'dutyNm', duty.commCdValNm)
            //             return
            //         }
            //     })
            // } else if (field == 9) {
            //     this.rpstyCdList.map((rpsty) => {
            //         if (rpsty.commCdVal == this.getData) {
            //             grid.setValue(itemIndex, 'rpstyNm', rpsty.commCdValNm)
            //             return
            //         }
            //     })
            // }
        },

        //저장 버튼 이벤트
        onSave: function () {
            this.gridObj.gridView.commit()
            let basUsmBiLnkgMappMgmtVo = []
            let saveParam = {}
            let gridCreatedIndexArr =
                this.gridObj.dataProvider.getStateRows('created')
            let gridUpdatedIndexArr =
                this.gridObj.dataProvider.getStateRows('updated')

            console.log('gridCreatedIndexArr', gridCreatedIndexArr)
            console.log('gridUpdatedIndexArr', gridUpdatedIndexArr)

            for (let idx = 0; idx < gridCreatedIndexArr.length; idx++) {
                let getJson = this.gridObj.dataProvider.getJsonRow(
                    gridCreatedIndexArr[idx]
                )
                console.log('getJson', getJson)
                getJson.seq = getJson.seq ? getJson.seq : ''
                getJson.biId = getJson.biId ? getJson.biId : ''
                getJson.oldBiId = getJson.oldBiId ? getJson.oldBiId : ''
                getJson.deptCd = getJson.deptCd ? getJson.deptCd : ''
                getJson.oldDeptCd = getJson.oldDeptCd ? getJson.oldDeptCd : ''
                getJson.deptNm = getJson.deptNm ? getJson.deptNm : ''
                getJson.dutyCd = getJson.dutyCd ? getJson.dutyCd : ''
                getJson.oldDutyCd = getJson.oldDutyCd ? getJson.oldDutyCd : ''
                getJson.rpstyCd = getJson.rpstyCd ? getJson.rpstyCd : ''
                getJson.oldRpstyCd = getJson.oldRpstyCd
                    ? getJson.oldRpstyCd
                    : ''
                getJson.userGrpCd = getJson.userGrpCd ? getJson.userGrpCd : ''
                getJson.insUserId = getJson.insUserId ? getJson.insUserId : ''
                getJson.insDtm = getJson.insDtm ? getJson.insDtm : ''
                getJson.modUserId = getJson.modUserId ? getJson.modUserId : ''
                getJson.modDtm = getJson.modDtm ? getJson.modDtm : ''
                getJson.__rowState = 'created'
                basUsmBiLnkgMappMgmtVo.push(getJson)
            }

            for (let idx = 0; idx < gridUpdatedIndexArr.length; idx++) {
                let getJson = this.gridObj.dataProvider.getJsonRow(
                    gridUpdatedIndexArr[idx]
                )
                getJson.seq = getJson.seq ? getJson.seq : ''
                getJson.biId = getJson.biId ? getJson.biId : ''
                getJson.oldBiId = this.ds_list[gridUpdatedIndexArr[idx]].oldBiId
                    ? this.ds_list[gridUpdatedIndexArr[idx]].oldBiId
                    : ''
                getJson.deptCd = getJson.deptCd ? getJson.deptCd : ''
                getJson.oldDeptCd = this.ds_list[gridUpdatedIndexArr[idx]]
                    .oldDeptCd
                    ? this.ds_list[gridUpdatedIndexArr[idx]].oldDeptCd
                    : ''
                getJson.deptNm = getJson.deptNm ? getJson.deptNm : ''
                getJson.dutyCd = getJson.dutyCd ? getJson.dutyCd : ''
                getJson.oldDutyCd = this.ds_list[gridUpdatedIndexArr[idx]]
                    .oldDutyCd
                    ? this.ds_list[gridUpdatedIndexArr[idx]].oldDutyCd
                    : ''
                getJson.rpstyCd = getJson.rpstyCd ? getJson.rpstyCd : ''
                getJson.oldRpstyCd = this.ds_list[gridUpdatedIndexArr[idx]]
                    .oldRpstyCd
                    ? this.ds_list[gridUpdatedIndexArr[idx]].oldRpstyCd
                    : ''
                getJson.userGrpCd = getJson.userGrpCd ? getJson.userGrpCd : ''
                getJson.insUserId = getJson.insUserId ? getJson.insUserId : ''
                getJson.insDtm = getJson.insDtm ? getJson.insDtm : ''
                getJson.modUserId = getJson.modUserId ? getJson.modUserId : ''
                getJson.modDtm = getJson.modDtm ? getJson.modDtm : ''
                console.log('getJson', getJson)
                // getJson.addOrgCd = getJson.orgCd
                if (this.selectedJsonData.check == true) {
                    getJson.__rowState = 'deleted'
                } else {
                    getJson.__rowState = 'updated'
                }
                basUsmBiLnkgMappMgmtVo.push(getJson)
            }

            saveParam = {
                basUsmBiLnkgMappMgmtVo,
            }

            //	입력컬럼 체크
            for (let i = 0; i < basUsmBiLnkgMappMgmtVo.length; i++) {
                if (
                    basUsmBiLnkgMappMgmtVo[i].__rowState == 'created' ||
                    basUsmBiLnkgMappMgmtVo[i].__rowState == 'updated'
                ) {
                    if (
                        _.isEmpty(basUsmBiLnkgMappMgmtVo[i].biId) ||
                        _.isEmpty(basUsmBiLnkgMappMgmtVo[i].deptCd) ||
                        _.isEmpty(basUsmBiLnkgMappMgmtVo[i].rpstyCd) ||
                        _.isEmpty(basUsmBiLnkgMappMgmtVo[i].userGrpCd)
                    ) {
                        this.showTcComAlert(
                            i +
                                1 +
                                '번째 BI ID, HR부서코드, HR부서명, 직책코드, 그룹은 필수 입력사항입니다.'
                        )

                        // grd_list.MoveToNextCell()
                        return
                    }
                }
            }

            if (saveParam.basUsmBiLnkgMappMgmtVo.length === 0) {
                // msgTxt.MSG_00071
                this.openAlert('처리할 대상이 없습니다.') // '처리할 대상이 없습니다.'
                return
            }

            API.saveBiUserList(saveParam)
                .then((result) => {
                    console.log('result : ', result)
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    // 매핑정보 재조회
                    this.onSearch()
                })
                .catch((error) => {
                    this.showTcComAlert('저장에 실패했습니다.')
                    throw error
                    // 매핑정보 재조회
                    // this.onSearch()
                })
        },

        // 초기화
        onResetPage() {
            console.log('🚀  Clear()')
            this.setInit()
        },
        setInit() {
            this.gridObj.gridInit()
            this.div_search.biId = ''
            this.div_search.deptCd = ''
            this.div_search.deptNm = ''
            this.div_search.aplyYn = '0'
        },

        // 추가근무지 목록 - 행추가
        btn_add_OnClick() {
            let rowCount = this.gridObj.dataProvider.getRowCount()
            let rowData = {
                userGrpNm: '--선택--',
            }
            this.gridObj.dataProvider.insertRow(rowCount, rowData)
            // let popUpData = {
            //     dealcoCd: this.searchInrDealcosParam.dealcoCd,
            //     dealcoNm: this.searchInrDealcosParam.dealcoNm,
            // }
            // this.gridData.gridRows = this.gridHeaderObj.addRow(
            //     this.gridData.gridRows
            // )
        },

        //추가근무지 목록 - 행삭제
        btn_del_OnClick() {
            this.gridData = this.gridHeaderObj.focusDelRow(this.gridData)
            console.log('gridData', this.gridData)
        },

        // 그리드에 그룹명 dropdown셋팅 공통코드 api
        async dropDownSetting() {
            console.log('dropDownSetting')
            // biid set
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00740',
                columnName: 'biId',
                option: '--선택--',
            })
            // // 사용자그룹명 set
            // await this.dropDownCmmonCodes({
            //     key: 'ZBAS_C_00250',
            //     columnName: 'userGrpNm',
            //     option: '--선택--',
            // })

            await this.dropDowUserGrpCodes({
                key: 'ZBAS_C_00250',
                columnName: 'userGrpNm',
                option: '--선택--',
            })
            // 직무코드 set
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00730',
                columnName: 'dutyCd',
                option: '--선택--',
            })
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00720',
                columnName: 'rpstyCd',
                option: '--선택--',
            })
        },

        async dropDownCmmonCodes({ key, columnName, option }) {
            console.log('key columnName option', key, columnName, option)
            let result = await API.dropDownCmmonCodes_(key)

            console.log('result', result)
            // let current = this.gridObj.gridView.getCurrent()
            var values = []
            var labels = []
            if (columnName == 'biId') {
                this.biIdList = result
                // this.ds_list.map((row, itemIndex) => {
                //     this.biIdList.map((duty) => {
                //         // let getData = this.gridObj.gridView.getValue(idx, 'biId')
                //         if (row.biId == duty.commCdVal) {
                //             this.gridObj.gridView.setValue(
                //                 itemIndex,
                //                 'biIdNm',
                //                 duty.commCdValNm
                //             )
                //             // this.gridObj.gridView.setColumn(col1)
                //             return
                //         }
                //     })
                // })
            }
            if (columnName == 'userGrpNm') {
                this.userGrpList = result
            }
            if (columnName == 'dutyCd') {
                this.dutyCdList = result
            }
            if (columnName == 'rpstyCd') {
                this.rpstyCdList = result
            }

            values = result.map((a) => a.commCdVal)
            console.log('values', values)
            labels = result.map((a) => a.commCdValNm)
            console.log('labels', labels)
            if (option != undefined) {
                values.unshift('')
                labels.unshift(option)
            }
            if (columnName == 'userGrpNm') {
                let col1 = this.gridObj.gridView.columnByName(columnName)
                console.log('col1', col1)
                console.log('getColumn', col1)
                col1.values = values
                col1.labels = labels
                this.gridObj.gridView.setColumn(col1)
            }

            // if (field == 1) {
            //     this.biIdList.map((duty) => {
            //         if (duty.commCdVal == this.getData) {
            //             grid.setValue(itemIndex, 'biIdNm', duty.commCdValNm)
            //             return
            //         }
            //     })
            // } else if (field == 4) {
            //     grid.setValue(itemIndex, 'userGrpCd', this.getData)
            // } else if (field == 7) {
            //     this.dutyCdList.map((duty) => {
            //         if (duty.commCdVal == this.getData) {
            //             grid.setValue(itemIndex, 'dutyNm', duty.commCdValNm)
            //             return
            //         }
            //     })
            // } else if (field == 9) {
            //     this.rpstyCdList.map((rpsty) => {
            //         if (rpsty.commCdVal == this.getData) {
            //             grid.setValue(itemIndex, 'rpstyNm', rpsty.commCdValNm)
            //             return
            //         }
            //     })
            // }
        },

        async dropDowUserGrpCodes({ key, columnName, option }) {
            console.log('key columnName option', key, columnName, option)
            let result = await API.dropDowUserGrpCodes_()
            this.userGrpList = result
            var values = []
            var labels = []
            values = result.map((a) => a.commCdVal)
            console.log('values', values)
            labels = result.map((a) => a.commCdValNm)
            console.log('labels', labels)
            if (option != undefined) {
                values.unshift('')
                labels.unshift(option)
            }
            let col1 = this.gridObj.gridView.columnByName(columnName)
            console.log('col1', col1)
            console.log('getColumn', col1)
            col1.values = values
            col1.labels = labels
            this.gridObj.gridView.setColumn(col1)
        },

        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/usm/usmBiLnkgMappMgmtExcelList',
                this.div_search
            )
        },
    },
}
</script>
