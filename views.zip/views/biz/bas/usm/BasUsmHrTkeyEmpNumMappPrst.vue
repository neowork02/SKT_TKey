<template>
    <div class="content">
        <!-- Tit -->
        <!-- // Tit -->
        <h1>HR사번매핑현황</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="ds_st"
                        labelName="재/휴직 구분"
                        v-model="div_search.st"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="ds_mapYn"
                        labelName="매핑여부"
                        v-model="div_search.mappYn"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="ds_effUserYn"
                        labelName="유효사용자여부"
                        v-model="div_search.effUserYn"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>

                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="ds_userGrpMapYn"
                        labelName="권한그룹 매핑여부"
                        labelClass="line2"
                        v-model="div_search.userGrpMapYn"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="ds_userBiMapYn"
                        labelName="BI매핑여부"
                        v-model="div_search.userBiMapYn"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="div_search.tUserNm"
                        labelName="이름"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    ></TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="div_search.tUserCd"
                        labelName="사번"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    ></TCComInput>
                </div>
                <div class="formitem div4"></div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="HR사번 매핑현황"
                :gridObj="gridObj"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getHrTkeyMappList"
                :rowCnt="rowCnt"
                :gridObj="gridObj1"
                @input="chgRowCnt1"
            />
        </div>
    </div>
</template>

<style>
/* @import '@/node_modules/realgrid/dist/realgrid-style.css'; */
</style>

<script>
import { CommonGrid } from '@/utils'
import _ from 'lodash'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMsg from '@/utils/CommonMsg'
import { HEADER } from '@/const/grid/bas/usm/BasUsmHrTkeyEmpNumMappPrstHeader'
import API from '@/api/biz/bas/usm/BasUsmHrTkeyEmpNumMappPrst'
import CommonMixin from '@/mixins'

export default {
    name: 'BasUsmHrTkeyEmpNumMappPrst',
    mixins: [CommonMixin],
    components: {},

    data() {
        return {
            // gridStyle: {
            //     height: '500px', //그리드 높이 조절
            // },
            objAuth: {},
            gridData: this.gridSetData(),
            gridObj: {},
            gridObj1: {},
            gridHeaderObj: {},
            view: HEADER,
            radio1: '1',
            radio2: '2',
            checkbox: true,
            radios: null,
            ds_st: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: '0',
                    commCdValNm: '퇴직',
                },
                {
                    commCdVal: '1',
                    commCdValNm: '휴직',
                },
                {
                    commCdVal: '3',
                    commCdValNm: '재직',
                },
            ],
            ds_mapYn: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
            ds_effUserYn: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
            ds_userGrpMapYn: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
            ds_userBiMapYn: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
            // 조회조건
            div_search: {
                attcClCd: '', //소속구분
                st: '', // 재/휴직구분
                mappYn: '', //매핑여부
                effUserYn: '', // 유효사용자여부
                tUserCd: '', // 사번
                userGrpMapYn: '', // 사용자그룹매핑여부
                userBiMapYn: '', // BI매핑여부
                tUserNm: '', // 이름
            },
            reqParam: {
                attcClCd: '',
                st: '',
                mappYn: '',
                effUserYn: '',
                userGrpMapYn: '',
                userBiMapYn: '',
                tUserCd: '',
                tUserNm: '',
                pageSize: '',
                pageNum: 1, //첫번째 페이지
                totalPage: 0, // 이전페이지정보 초기화
            },
            rowCnt: 15,
            layout: [
                'st',
                {
                    name: 'group',
                    direction: 'horizontal',
                    items: [
                        'comp',
                        'userCd',
                        'portalUserId',
                        'userId',
                        'attcClCd',
                        'userGrpCd',
                        'orgTreeNm',
                        // 'orgCdNm',
                        // 'bizDivOrgCdNm',
                        // 'bizChrgOrgCdNm',
                        // 'teamOrgCdNm',
                        // 'ptOrgCdNm',
                        'sktDealCd',
                        'orglDealCoCdNm',
                        'orglDealCoCd',
                        'userNm',
                        'effUserYn',
                        'biId',
                    ],
                    header: {
                        text: 'T.Key Taka 정보',
                    },
                },
                {
                    name: 'group',
                    direction: 'horizontal',
                    items: [
                        'empNo',
                        'hanNm',
                        'deptCd',
                        'postDeptNm',
                        'jobGrpCd',
                        'jobGrpNm',
                        'posCd',
                        'posNm',
                        'rpstyCd',
                        'rpstyNm',
                        'dutyCd',
                        'dutyNm',
                        'empSubGrpCd',
                        'empSubGrpNm',
                        'chatyYn',
                        'inOfcNm',
                        'dutypCd',
                        'dutypNm',
                        'costCntrCd',
                        'entDt',
                        'retirDt',
                    ],
                    header: {
                        text: 'HR정보',
                    },
                    rowCnt: 15,
                },
            ],
        }
    },
    mounted() {
        //체크바
        // this.$refs.grid1.gridView.setCheckBar({
        //     visible: true,
        // })
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState()
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.gridSetData()
        },
        //GridSet Init
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수),
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        // 페이징 처리
        // 페이지 표시 행의 수 변경처리
        chgRowCnt1(val) {
            this.rowCnt = val
            this.onSearch()
        },
        /* 다음페이지 노출여부 */
        isShowNext(pageInfo) {
            this.showNext =
                pageInfo.totalDataCnt === pageInfo.pageSize ? true : false
        },
        //조회 버튼 이벤트
        onSearch: function () {
            console.log('this.div_search : ', this.div_search)
            this.gridObj.setRows()
            this.reqParam.attcClCd = '1' // 임직원 고정
            this.reqParam.st = this.div_search.st
            this.reqParam.mappYn = this.div_search.mappYn
            this.reqParam.effUserYn = this.div_search.effUserYn
            this.reqParam.userGrpMapYn = this.div_search.userGrpMapYn
            this.reqParam.userBiMapYn = this.div_search.userBiMapYn
            this.reqParam.tUserCd = this.div_search.tUserCd
            this.reqParam.tUserNm = this.div_search.tUserNm
            this.reqParam.pageSize = this.rowCnt
            this.reqParam.pageNum = 1 //첫번째 페이지
            this.reqParam.totalPage = 0 // 이전페이지정보 초기화

            this.getHrTkeyMappList(this.reqParam.pageNum)
        },

        getHrTkeyMappList(pageNum) {
            this.reqParam.pageNum = pageNum //첫번째 페이지
            console.log('this.reqParam : ', this.reqParam)

            API.getHrTkeyMappList(this.reqParam).then((resultData) => {
                console.log('resultData : ', resultData)
                // // INDEX 셋팅

                // if (resultData.gridList.length === 0) {
                //     alert('데이터가 없습니다')
                // }
                if (_.isEmpty(resultData.gridList)) {
                    this.showTcComAlert('조회된 데이터가 없습니다')
                    return
                }
                for (let idx = 0; idx < resultData.gridList.length; idx++) {
                    if (resultData.gridList[idx].st == '1') {
                        resultData.gridList[idx].st = 'Y'
                    } else {
                        resultData.gridList[idx].st = 'N'
                    }
                }
                this.gridObj.setRows(resultData.gridList)
                this.gridData = this.gridSetData() //초기화
                this.isShowNext(resultData.pagingDto)
                this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                // this.gridData = this.gridObj.setGirdPaging(this.gridData)
                this.gridHeaderObj.setPageCount(resultData.pagingDto)

                console.log('조회완료')
            })
        },

        // 초기화
        onResetPage() {
            // CommonUtil.clearPage(this.$router)
            this.gridObj.gridInit()
            this.div_search.attcClCd = ''
            this.div_search.st = ''
            this.div_search.mappYn = 'N'
            this.div_search.effUserYn = 'N'
            this.div_search.tUserCd = ''
            this.div_search.userGrpMapYn = 'N'
            this.div_search.userBiMapYn = 'N'
            this.div_search.tUserNm = ''
        },

        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/usm/usmHrTkeypEmpNumMappPrstExcelList',
                this.div_search
            )
        },
    },
}
</script>
