<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1600px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">수기카드 입금정산상세</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridPopupHeader1"
                                ref="gridPopupHeader1"
                                gridTitle=""
                                :gridObj="gridObj"
                                :isExceldown="true"
                                class="notit"
                                @excelDownBtn="
                                    exportExcelDownButton(
                                        '수기카드입금정산상세'
                                    )
                                "
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="gridPopup1"
                                ref="gridPopup1"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
// import moment from 'moment'
import pacApi from '@/api/biz/acc/pac'
import CommonMixin from '@/mixins'
import { GRID_HEADER } from '@/const/grid/acc/pac/accPacHndopCardDpstAccMgmtPopupGrid'

export default {
    name: 'accPacHndopCardDpstAccMgmtPopup',
    title: '수기카드입금정산관리 팝업',
    mixins: [CommonMixin],
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list: [],
            gridObj: {},
            searchParams: {
                searchStartYmd: this.popupParams.searchStartYmd,
                searchEndYmd: this.popupParams.searchEndYmd,
                searchOrgCd: this.popupParams.searchOrgCd,
                searchOrgNm: this.popupParams.searchOrgNm,
                searchOrgLvl: this.popupParams.searchOrgLvl,
                searchLvOrgCd: this.popupParams.searchLvOrgCd,
                searchFixYn: this.popupParams.searchFixYn,
                searchCardCoCd: this.popupParams.searchCardCoCd,
                searchAccDealcoCd: this.popupParams.accDealcoCd,
                searchDealcoCd: this.popupParams.dealcoCd,
                excelFileName: '',
            },
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        this.gridObj = this.$refs.gridPopup1
        this.gridObj.setGridState(false, false, false, false)

        // 넘어온 파라미터로 조회하기
        this.onSearch()
    },
    methods: {
        onSearch: function () {
            console.log('search')
            pacApi
                .getAccPacHndopCardDpstAccMgmtPopupList(this.searchParams)
                .then((resultData) => {
                    this.$refs.gridPopup1.setRows(resultData)
                })
        },
        onClose: function () {
            this.activeOpenAgency = false
        },
        /* 화면 상단의 엑셀다운로드 버튼 클릭시 실행 */
        exportExcelDownButton: function (excelFileName) {
            //  엑셀파일명(정산월 + 조직명)
            this.searchParams.excelFileName =
                '수작업카드입금정산상세_' +
                excelFileName +
                '_' +
                this.searchParams.searchStartYmd +
                '_' +
                this.searchParams.searchEndYmd +
                '_' +
                this.searchParams.searchOrgNm

            pacApi
                .getAccPacHndopCardDpstAccMgmtPopupListExcelDown(
                    this.searchParams
                )
                .then(() => {
                    this.showTcComAlert('엑셀파일이 다운로드되었습니다.')
                })
        },
    },
}
</script>
