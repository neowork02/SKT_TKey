<template>
    <div class="content">
        <!-- Tit -->
        <h1>권역별 매장관리</h1>
        <!-- Top BTN  STA-->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onDealcoIconClick"
                    :objAuth="objAuth"
                >
                    매장선택
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clear"
                    :objAuth="objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :disabled="saveDisable"
                    @click="onSave"
                    :objAuth="objAuth"
                >
                    저장
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onDelete"
                    :objAuth="objAuth"
                >
                    삭제
                </TCComButton>
            </li>
        </ul>
        <!-- Top BTN  END-->
        <!-- contBoth  STA-->
        <div class="contBoth">
            <!-- searchLayer_wrap  STA-->
            <div class="searchLayer_wrap">
                <!-- searchform  STA-->
                <div class="searchform">
                    <div class="formitem div4">
                        <TCComInput
                            v-model="searchParam.rgnCd"
                            :maxlength="12"
                            labelName="권역코드"
                            :objAuth="objAuth"
                        />
                    </div>
                    <div class="formitem div4">
                        <TCComInput
                            v-model="searchParam.rgnNm"
                            :maxlength="12"
                            labelName="권역명"
                            :objAuth="objAuth"
                        />
                    </div>
                    <div class="formitem div4">
                        <TCComInput
                            v-model="searchParam.dealcoCd"
                            :maxlength="12"
                            labelName="매장코드"
                            :objAuth="objAuth"
                        />
                    </div>
                    <div class="formitem div4">
                        <TCComInput
                            v-model="searchParam.dealcoNm"
                            :maxlength="12"
                            labelName="매장명"
                            :objAuth="objAuth"
                        />
                    </div>
                </div>
                <div class="searchform">
                    <!-- 소속조직 -->
                    <div class="formitem div4">
                        <TCComInputSearchText
                            v-model="searchParam.orgNm"
                            :codeVal.sync="searchParam.orgCd"
                            labelName="소속조직"
                            placeholder="선택해주세요"
                            :disabledAfter="true"
                            :objAuth="objAuth"
                            @enterKey="onAuthOrgTreeEnterKey"
                            @appendIconClick="onAuthOrgTreeIconClick"
                            @input="onAuthOrgTreeInput"
                        />
                        <BasBcoAuthOrgTreesPopup
                            v-if="showBcoAuthOrgTrees"
                            :parentParam="searchParam"
                            :rows="resultAuthOrgTreeRows"
                            :dialogShow.sync="showBcoAuthOrgTrees"
                            @confirm="onAuthOrgTreeReturnData"
                        />
                    </div>
                    <!-- //소속조직 -->

                    <div class="formitem div4">
                        <TCComComboBox
                            v-model="searchParam.svcObj"
                            labelName="권역정보"
                            :itemList="searchType"
                            :addBlankItem="true"
                            blankItemText="전체"
                            blankItemValue=""
                            :objAuth="objAuth"
                        ></TCComComboBox>
                    </div>
                    <div class="formitem div2"></div>
                </div>
                <!-- searchform  END-->
            </div>
            <!-- searchLayer_wrap  END-->

            <!-- searchLayer_wrap STA 엑셀업로드 -->
            <div class="searchLayer_wrap">
                <div class="searchform">
                    <div class="formitem div4">
                        <TCComFileInput
                            v-model="files"
                            labelName="파일선택"
                            @change="onFilesChange"
                        ></TCComFileInput>
                    </div>
                    <div class="formitem div4_6">
                        <div class="rightArea btn">
                            <span class="inner">
                                <TCComButton
                                    labelName="오류검증"
                                    eClass="btn_s btn_ty03"
                                    eAttr="ico_verification"
                                    :Vuetify="false"
                                    :disabled="errVerithDisable"
                                    @click="errCheck"
                                />
                                <TCComButton
                                    labelName="오류일괄제거"
                                    eClass="btn_s btn_ty03"
                                    eAttr="ico_del"
                                    :Vuetify="false"
                                    :disabled="errDeleteDisable"
                                    @click="errClear"
                                />
                                <TCComButton
                                    labelName="양식다운로드"
                                    eClass="btn_s btn_ty03"
                                    eAttr="ico_save"
                                    :Vuetify="false"
                                    @click="excelTemplateDownBtn"
                                />
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- searchLayer_wrap END 엑셀업로드 -->
        </div>
        <!-- contBoth  END-->

        <!-- gridWrap  STA-->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="권역 별 매장관리"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @excelDownBtn="this.excelDown"
            />

            <TCRealGrid
                id="gridTable"
                ref="gridTable"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
            />
            <TCComPaging
                :totalPage="gridData1.totalPage"
                :apiFunc="fSearch"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt1"
            />
            <TCRealGridHeader
                v-show="false"
                id="gridHeaderExcel"
                ref="gridHeaderExcel"
                gridTitle="엑셀업로드 양식다운로드(숨김)"
                :gridObj="gridObj3"
            />
            <TCRealGrid
                v-show="false"
                id="gridExcel3"
                ref="gridExcel3"
                :gridObj="gridObj3"
                :fields="view.fields"
                :columns="view.columns2"
            />
        </div>
        <!-- gridWrap  END-->

        <!-- Popup -->
        <BasBcoDealcosPopup
            v-if="basBcoDealcoShow"
            :parentParam="searchDealcoParam"
            :dialogShow.sync="basBcoDealcoShow"
            @confirm="onDealcoReturnData"
        />
        <!-- Popup -->
    </div>
</template>

<style></style>

<script>
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처(권한조직)====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
//====================//내부거래처(권한조직)==================
import { GRID_HEADER } from '@/const/grid/bas/prm/basPrmDirArrvlDealMgmtHeader'
import { CommonGrid, FileUtil } from '@/utils'
import { msgTxt } from '@/const/msg.Properties.js'
import basPrmApi from '@/api/biz/bas/prm/basPrmDirArrvlMgmt'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMixin from '@/mixins'
import _ from 'lodash'
import * as XLSX from 'xlsx'
export default {
    name: 'BasPrmDirArrvlDealMgmt',
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
    },
    mixins: [CommonMixin],
    props: {},
    data() {
        return {
            //====================공통기능====================
            objAuth: {},
            searchParam: {
                rgnCd: '',
                rgnNm: '',
                dealcoCd: '',
                dealcoNm: '',
                svcObj: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
            },

            //GRID
            gridObj: {},
            gridHeaderObj: {},
            gridHeaderObjExcel: {},
            gridObj3: {},
            view: GRID_HEADER,
            // paging
            rowCnt: 15, // 표시할 행의 갯수
            pageNum: 1,
            pageSize: 15,
            gridData1: {},

            //file
            files: null,

            errDeleteDisable: null,
            saveDisable: null,
            errVerithDisable: null,
            fvFile: 0, //0 엑셀업로드가 아님, 1: 엑셀업로드

            codeYn: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],

            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            showAlertBool: false,
            headerText: '',
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처(권한 조직))====================
            basBcoDealcoShow: false,
            searchDealcoParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한 조직)==================
            searchType: [
                {
                    commCdVal: 'STRD',
                    commCdValNm: '바로도착',
                },
                {
                    commCdVal: 'PRIM',
                    commCdValNm: '바로도착 행복배송',
                },
            ],
        }
    },

    created() {
        this.gridData1 = this.gridSetData(this.rowCnt)
    },

    mounted() {
        this.gridObj = this.$refs.gridTable
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.setGridState(true, false, true, false)

        // 엑셀양식다운로드 Grid 기본세팅(Hiddend)
        this.gridObj3 = this.$refs.gridExcel3
        this.gridHeaderObj3 = this.$refs.gridHeaderExcel
        this.gridObj3.setGridState(false, false, false)
        this.gridHeaderObjExcel = this.$refs.gridHeaderExcel

        this.dropDownSetting()
    },

    computed: {},
    methods: {
        async dropDownSetting() {
            var values = []
            var labels = []
            if (this.codeYn.length > 0) {
                this.codeYn.map(function (item) {
                    values.push(item.commCdVal)
                    labels.push(item.commCdValNm)
                })

                var columns = this.view.columns
                for (var i = 0; i < columns.length; i++) {
                    if (
                        columns[i].name == 'primSvcYn' ||
                        columns[i].name == 'strdSvcYn'
                    ) {
                        columns[i].values = values
                        columns[i].labels = labels
                        columns[i].editor.values = values
                        columns[i].editor.labels = labels
                    }
                }
            }
        },

        /* 초기화 */
        clear() {
            console.log('🚀 ~ Clear()')
            this.setInit()
            this.files = null
        },
        /* 엑셀다운로드 */
        excelDown() {
            if (this.fvFile == 1) {
                this.openAlert('엑셀업로드 이후에 다운로드 가능합니다.')
                return
            }

            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-max/resource/bas/prm/getRgnDealCoXlsDload',
                this.searchParam
            )
        },
        /* 양식다운로드 */
        excelTemplateDownBtn() {
            attachedFileApi.downloadSampleFile('501')
        },
        // CRUD STA
        // 조회 BTN
        onSearch() {
            console.log('🚀 ~ onSearch')
            this.gridObj.gridView.commit()
            this.gridData1.totalPage = 0
            this.fSearch(1)
        },
        // 조회
        fSearch(pageNum) {
            let paramObj = { ...this.searchParam }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt
            console.log('🚀 ~ onSearch Param', paramObj)
            basPrmApi.getRgnDealCo(paramObj).then((resultData) => {
                if (_.isEmpty(resultData.gridList)) {
                    this.openAlert('조회된 데이터가 없습니다')
                    return
                }
                this.gridObj.setRows(resultData.gridList)
                this.gridObj.setGridIndicator(resultData.pagingDto) // 순번이 필요한경우 계산하는 함수
                this.gridData1 = this.gridSetData(this.rowCnt) //초기화
                this.gridData1.totalPage = resultData.pagingDto.totalPageCnt
                // GridHeader (총 ?건)
                this.gridHeaderObj.setPageCount(resultData.pagingDto)
            })
        },
        //저장
        onSave() {
            this.gridObj.gridView.commit()

            if (this.fvFile == 1) {
                // 엑셀 업로드시
                const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
                if (rowData.length === 0) {
                    // msgTxt.MSG_00071
                    this.openAlert('처리할 대상이 없습니다.') // '처리할 대상이 없습니다.'
                    return
                }
                console.log('🚀 ~  onSave fvFile 1', rowData)
                this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                    if (confirm) {
                        basPrmApi.saveDealCoRgn(rowData).then((res) => {
                            if (res === 1) {
                                this.fvFile = 0
                                this.onSearch()
                                this.errVerithDisable = true
                                this.errDeleteDisable = true
                            }
                        })
                    }
                })
            } else {
                let jsonData = this.getGridEditRows()
                if (jsonData.length === 0) {
                    // msgTxt.MSG_00071
                    this.openAlert('처리할 대상이 없습니다.') // '처리할 대상이 없습니다.'
                    return
                }
                console.log('🚀 ~  onSave fvFile 0', jsonData)
                this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                    if (confirm) {
                        basPrmApi.updateDealCoRgn(jsonData).then((res) => {
                            if (res === 1) {
                                this.onSearch()
                                this.errVerithDisable = false // 활성화
                                this.errDeleteDisable = false // 활성화
                            }
                        })
                    }
                })
            }
        },
        //삭제
        async onDelete() {
            if (this.fvFile == 1) {
                this.gridObj.gridView.commit()
                const checkRows = this.gridObj.gridView.getCheckedRows(true)
                this.gridObj.dataProvider.removeRows(checkRows)
            } else {
                let deleteList = await Promise.all(this.getRows(this.gridObj))

                if (deleteList.length === 0) {
                    // msgTxt.MSG_00071
                    this.openAlert('처리할 대상이 없습니다.') // '처리할 대상이 없습니다.'
                    return
                } else {
                    this.showTcComConfirm(
                        '체크된 거래처의 권역을 삭제하시겠습니까?'
                    ).then((confirm) => {
                        if (confirm) {
                            basPrmApi.delDealCoRgn(deleteList).then((res) => {
                                if (res === 1) {
                                    this.onSearch()
                                }
                            })
                        }
                    })
                }
            }
        },
        // CRUD END

        getGridEditRows: function () {
            // 아래 commit을 해야 Row 값을 가져올 수 있음
            this.gridObj.gridView.commit()
            const arr = []
            const cIndex = this.gridObj.dataProvider.getStateRows('created')
            const uIndex = this.gridObj.dataProvider.getStateRows('updated')
            arr.push(...cIndex)
            arr.push(...uIndex)

            let jsonData = []
            arr.forEach((data) => {
                jsonData = [
                    ...jsonData,
                    ...this.gridObj.dataProvider.getJsonRows(data, data, true),
                ]
            })
            return jsonData
        },
        // 삭제로우
        getRows(grid) {
            grid.gridView.commit()
            let jsonData = []
            const checkRows = grid.gridView.getCheckedRows(true)
            checkRows.forEach((row) => {
                jsonData.push(grid.dataProvider.getJsonRow(row))
            })
            return [...jsonData] // 테스트용
        },

        // file
        // 오류검증 버튼 이벤트
        errCheck: function () {
            if (this.fvFile == 0) {
                this.openAlert(msgTxt.MSG_00106)
                return
            }

            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)

            if (
                rowData.length == 0 ||
                (rowData.length == 1 && _.isEmpty(rowData[0].dealcoCd))
            ) {
                this.openAlert(msgTxt.MSG_00106)
                return
            }
            basPrmApi.chkErrorByExcelt(rowData).then((res) => {
                this.errDeleteDisable = false // 오류일괄제거버튼 활성화
                this.errVerithDisable = true // 오류검증버튼 비활성화
                this.gridObj.setRows(res)
            })
        },
        // Alert창 호출
        openAlert(alertBodyTxt) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: '450',
            })
        },

        // 오류일괄제거 버튼 이벤트
        errClear: function () {
            if (this.fvFile == 0) {
                this.openAlert(msgTxt.MSG_00106)
                return
            }

            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.(데이터 없음)')
                return
            }
            if (_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('처리할 데이터가 없습니다.(에러 없음)')
                this.saveDisable = false // 저장버튼 활성화
                this.errDeleteDisable = true // 오류일괄제거버튼 비활성화
            } else {
                this.gridObj.dataProvider.removeRows(this.getErrRow())
                this.saveDisable = false // 저장버튼 활성화
                this.errDeleteDisable = true // 오류일괄제거버튼 비활성화
            }
        },

        //오류ROW 조회
        getErrRow() {
            let errRow = []
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            rowData.forEach((data, i) => {
                if (!_.isEmpty(_.get(data, 'errDesc'))) {
                    errRow.push(i)
                }
            })
            return errRow
        },

        onFilesChange: function (files) {
            this.setInit()
            this.fvFile = 1
            this.errDeleteDisable = true // 오류일괄제거버튼 비활성화
            this.errVerithDisable = false // 오류검증버튼 활성화
            this.saveDisable = true // 저장버튼 비활성화
            this.excelUploadFile(files)
        },
        setInit() {
            this.gridObj.gridInit()
            this.errDeleteDisable = false // 오류일괄제거버튼 활성화
            this.errVerithDisable = false // 오류검증버튼 활성화
            this.saveDisable = false // 저장버튼 활성화
            this.searchParam = {
                pageSize: this.rowCnt,
                pageNum: 1,
            }
            this.fvFile = 0
        },
        excelUploadFile(files) {
            const f = files
            if (!_.isUndefined(f) && !_.isNull(f)) {
                const reader = new FileReader()
                // const name = f.name

                reader.onload = (e) => {
                    const data = e.target.result

                    // Array Buffer인 경우 base64로 변환 처리
                    const arr = FileUtil.arrayBufferFixdata(data)
                    const workbook = XLSX.read(FileUtil.encodeBase64(arr), {
                        type: 'base64',
                        cellText: true,
                        cellDates: true,
                    })
                    // 워크북 처리(1줄 헤더 포함 처리)
                    this.processWorkbook(workbook)
                }
                // binary
                // reader.readAsBinaryString(f)
                // Array Buffer
                reader.readAsArrayBuffer(f)
            }
        },

        // 워크북 처리(1줄 헤더 포함 처리)
        processWorkbook(wb) {
            const output = FileUtil.excelTojson(wb, {
                raw: false,
            })
            const sheetNames = Object.keys(output)
            if (sheetNames.length) {
                const colsObj = output[sheetNames][0]
                if (colsObj) {
                    const data = output[sheetNames]
                    console.log('processWorkbook: ', output[sheetNames])
                    if (data.length > 3000) {
                        this.showTcComAlert(
                            '1회당 업로드 데이터는 3000건까지 가능합니다.'
                        )
                        return
                    } else {
                        this.gridObj.gridView.commit()
                    }
                    const mappedData = data.map((item) => {
                        return {
                            rgnCd: item['권역코드'],
                            dealcoCd: item['거래처코드'],
                            strdSvcYn: item['바로도착'],
                            primSvcYn: item['바로도착 행복배송'],
                        }
                    })
                    this.gridObj.dataProvider.fillJsonData(mappedData, {})
                }
            } else {
                this.openAlert(msgTxt.MSG_00106)
            }
        },

        // 페이징 처리
        // 페이지 표시 행의 수 변경처리
        chgRowCnt1(val) {
            this.rowCnt = val
        },

        //GridSet Init
        gridSetData(rowCnt) {
            return new CommonGrid(0, rowCnt, '', '')
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchParam.orgNm = _.get(res[0], 'orgNm')
                        this.searchParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showAlert(
                    '검색조건 필수',
                    '내부조직팝업(권한)명을 입력해주세요.'
                )
                return false
            }

            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchParam.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            this.gridObj.gridView.commit()
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 팝업오픈
            this.basBcoDealcoShow = true
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchDealcoParam.dealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            //로우 추가
            let rowCount = this.gridObj.dataProvider.getRowCount()
            let rowData = {
                dealcoCd: _.get(retrunData, 'dealcoCd'),
                dealcoNm: _.get(retrunData, 'dealcoNm'),
            }
            this.gridObj.dataProvider.insertRow(rowCount, rowData)

            // 행추가 되면 해당 위치로 focused 하기
            let focuscell = this.gridObj.gridView.getCurrent()
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)

            this.gridObj.gridView.commit()
        },
        //===================== //내부거래처(권한조직) methods ================================
    },

    watch: {},
}
</script>
