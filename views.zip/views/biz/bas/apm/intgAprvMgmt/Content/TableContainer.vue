<template>
    <div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="승인통합관리"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="paging1.totalPageCnt"
                :apiFunc="pageMove"
                :rowCnt="paging1.pageSize"
                @input="pageSizeChange"
            />
        </div>
        <DetailPopup
            v-if="localDialogShow"
            ref="popup"
            :dialogShow.sync="localDialogShow"
            :dtlData.sync="dtlParam"
        />
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/apm/intgAprvMgmt/helpers'
import { M_HEADER } from '@/const/grid/bas/apm/basApmIntgAprvMgmtHeader'
import attachedFileApi from '@/api/common/attachedFile'
import { CommonGrid } from '@/utils'
import DetailPopup from './PopupContainer.vue'
import _ from 'lodash'

export default {
    name: 'TableContainer',
    mixins: [CommonMixin],
    components: { DetailPopup },
    data() {
        return {
            activePage: 1, // 현재페이지
            rowCnt: 30,
            objAuth: {},
            gridObj: {},
            gridHeaderObj: {},
            gridData: this.GridSetData(),

            view: M_HEADER,
            layout: [
                'reqDtm', // 요청일시
                'aprvStNm', // 요청상태
                'aprvTypNm', // 승인유형명
                'menuGrpNm', // 업무구분명
                'reqMenuNm', // 요청화면
                'aprvDtlInfo01', // 추가정보01
                'aprvDtlInfo02', // 추가정보02
                'aprvDtlInfo03', // 추가정보03
                'reqUserNm', // 요청자
                'treeOrgNm', // 소속조직
                'dealSktCd', // 소속매장
                'aprvUserNm', // 승인자
                'aprvDtm', // 승인일시
            ],
            localDialogShow: false,
            dtlParam: {
                aprvSeq: '', // 통합승인관리SEQ
            },
            aprvSeqs: new Set(),
            selectedJsonData: {},
        }
    },
    async mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.setGridState(false, false, true)

        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

        // ALL CHECK BOX
        this.gridObj.gridView.onItemAllChecked = (grid) => {
            this.gridClick(grid)
        }

        // CHECK BOX
        this.gridObj.gridView.onItemChecked = () => {
            this.gridClick()
        }
        // 싱글클릭 시 저장데이터 SET
        // this.gridObj.gridView.onCellClicked = (grid, clickData) => {
        //     this.gridClick(clickData)
        //     this.selectedJsonData = this.gridObj.dataProvider.getJsonRow(
        //         clickData.dataRow
        //     )
        //     console.log('saveparam set', this.selectedJsonData)
        //     if (
        //         this.selectedJsonData.aprvStNm == '취소' ||
        //         this.selectedJsonData.aprvStNm == '기간만료'
        //     ) {
        //         this.showTcComAlert(
        //             '요청/승인/반려 상태인 데이터만 승인 반려처리가 가능합니다'
        //         )
        //     }
        // }

        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            if (typeof clickData.itemIndex !== 'undefined') {
                this.dtlParam['aprvSeq'] = grid.getValue(
                    clickData.itemIndex,
                    'aprvSeq'
                )
                this.detailPopup()
            }
        }
    },
    computed: {
        ...serviceComputed,
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        searchParam: {
            get() {
                return this.searchParams
            },
        },
    },
    methods: {
        ...serviceMethods,
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging1, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging1, pageNum: 1, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging',
                value: { ...this.paging1, pageNum: 1, pageSize: pageSize },
            })
            if (this.paging1.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging1.totalPageCnt // 총페이지수
            this.gridHeaderObj.setPageCount(this.paging1)
        },
        detailPopup() {
            this.localDialogShow = true
        },
        gridClick() {
            let checkedRows = this.gridObj.gridView.getCheckedRows(false)

            this.aprvSeqs = new Set()
            if (!_.isEmpty(checkedRows)) {
                for (let i = 0; i < checkedRows.length; i++) {
                    let rowData = this.gridObj.dataProvider.getJsonRow(
                        checkedRows[i]
                    )
                    if (rowData.aprvStNm != '요청') {
                        this.showTcComAlert(
                            '요청 상태인 데이터만 승인 반려처리가 가능합니다'
                        )
                        this.gridObj.gridView.checkRow(checkedRows[i], false)
                        return false
                    }
                    this.aprvSeqs.add(rowData.aprvSeq)
                }
            } else {
                this.aprvSeqs = new Set()
            }

            let params = {}
            params['aprvSeqs'] = Array.from(this.aprvSeqs)

            this.defaultAssign_({
                key: 'requestParams',
                value: params,
            })
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/apm/apmAprvMgmtsExcelList',
                this.searchParam
            )
        },
    },

    watch: {
        resultList1(val, oldVal) {
            console.log('resultList1 watched: ', val, oldVal, this.pageSize)
            let params = {}
            _.forEach(this.resultList, (item) => {
                params[item.aprvSeq] = item.aprvApiUrl
            })
            this.defaultAssign_({
                key: 'aprvUrlList',
                value: params,
            })
            this.gridObj.setRows(this.resultList)
        },
        paging1() {
            this.SetPaging()
        },
    },
}
</script>

<style scoped></style>
