<template>
    <v-sheet>
        <v-treeview
            ref="treeview"
            v-model="selection"
            :activatable="activatable"
            :items="items"
            :color="color"
            :dense="dense"
            :hoverable="hoverable"
            :selectable="selectable"
            :selected-color="selectedColor"
            :item-disabled="disabled"
            :open-all="openAll"
            :open-on-click="openOnClick"
            :rounded="rounded"
            :shaped="shaped"
            :selection-type="selectionType"
            :return-object="returnObject"
            :search="search"
            :filter="filter"
            :open="openNode"
            @input="emitInput"
            @update:active="emitActive"
            @update:open="emitOpen"
        >
            <template v-slot:prepend="{ item, open }">
                <v-container fill-height fluid class="x-ctn">
                    <v-row
                        align="center"
                        justify="center"
                        class="x-row grey lighten-5"
                    >
                        <v-icon
                            v-if="item.children && item.children.length > 0"
                        >
                            {{ open ? 'mdi-folder-open' : 'mdi-folder' }}
                        </v-icon>
                        <v-icon v-else>
                            {{ 'mdi-folder-text-outline' }}
                        </v-icon>
                        <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
                        <v-row
                            v-if="item.name == '새조직' || item.name == ''"
                            align="center"
                            justify="start"
                            class="x-row grey lighten-5"
                        >
                            <v-text-field
                                x-small
                                height="23px"
                                :label="item.name"
                                solo
                                v-model="itemName"
                                dense
                                autofocus
                            >
                            </v-text-field>
                            <span>&nbsp;</span>
                            <v-btn x-small @click="renameChild(item)"
                                ><v-icon small>
                                    {{ 'mdi-check' }}
                                </v-icon></v-btn
                            >
                        </v-row>
                        <v-row
                            v-else
                            align="center"
                            justify="start"
                            class="x-row grey lighten-5"
                            >{{ item.name }}
                            <span>&nbsp;&nbsp;&nbsp;</span>
                        </v-row>
                        <span>&nbsp;&nbsp;&nbsp;</span>
                        <v-btn
                            v-if="item.depth <= 3"
                            x-small
                            @click="addChild(item)"
                        >
                            <v-icon small>{{ 'mdi-plus' }}</v-icon>
                        </v-btn>
                        <v-btn x-small @click="removeChild(item)">
                            <v-icon small>{{ 'mdi-delete' }}</v-icon>
                        </v-btn>
                    </v-row>
                </v-container>
            </template>
            <template v-slot:label="{}"> </template>
        </v-treeview>
    </v-sheet>
</template>

<script>
export default {
    inheritAttrs: false,
    name: 'TreeviewDrag',
    components: {},
    props: {
        activatable: { type: Boolean, default: false, required: false }, // 노드 활성화 설정
        items: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        }, // 노드 정보
        value: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        }, // 선택한 노드 정보
        color: { type: String, default: '', required: false }, // 노드 색상
        dense: { type: Boolean, default: false, required: false }, // Dense mode 설정(트리 사이 간격을 줄어줌)
        hoverable: { type: Boolean, default: true, required: false }, //  hover effect 설정
        selectable: { type: Boolean, default: false, required: false }, // 노드 체크박스 설정
        selectedColor: { type: String, default: '', required: false }, // 노드 체크박스 색상
        disabled: { type: String, default: '', required: false }, // 노드 Disable 설정(locked)
        openAll: { type: Boolean, default: false, required: false }, // OPEN ALL 여부 설정
        openOnClick: { type: Boolean, default: false, required: false }, // 노드 클릭시 OPEN 여부 설정
        rounded: { type: Boolean, default: false, required: false }, // 노드 rounded 설정
        shaped: { type: Boolean, default: false, required: false }, // 노드 shaped 설정
        // Selection Type 설정(leaf, independent)
        // leaf: 부모노드 클릭시 자식 노드까지 Selection
        // independent: 노드 독릭적인 Selection
        selectionType: { type: String, required: false },
        returnObject: { type: Boolean, default: false, required: false }, // 오브젝트 리턴 설정 여부
        search: { type: String, required: false }, // 필터링 결과를 위한 검색 모델
        filter: { type: Function, required: false }, // 필터 함수 설정
        open: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        }, // Open 노드 제어 속성(Open 할 노드 id 값을 배열로 넘긴다.)
        objAuth: { type: Object, default: () => {}, required: false }, // auth
    },

    data() {
        return {
            selection: [],
            itemName: '',
        }
    },
    computed: {
        openNode: {
            get() {
                return this.open
            },
            set(value) {
                this.$emit('update:open', value)
            },
        },
    },
    watch: {
        value: {
            handler: function () {
                this.selection = this.value
            },
            deep: true,
            immediate: false,
        },
        search: function (newVal) {
            if (newVal) {
                this.$refs.treeview.updateAll(true)
            } else {
                if (this.openAll) {
                    this.$refs.treeview.updateAll(true)
                } else {
                    this.$refs.treeview.updateAll(false)
                }
            }
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.selection = this.value
        },
        emitInput(node) {
            // console.log('emit node: ', node)
            this.$emit('input', node)
        },
        emitActive(node) {
            // console.log('emit active: ', node)
            this.$emit('active', node)
        },
        emitOpen(node) {
            this.$emit('open', node)
        },
        addChild(node) {
            this.$emit('addChild', node)
        },
        renameChild(node) {
            this.$emit('renameChild', node)
        },
        removeChild(item) {
            this.$emit('removeChild', item)
        },
    },
}
</script>

<style></style>
