<!-----------------------------------------------
 * 업무 그룹명 : 재고 수탁재고관리>수탁재고관리현황>수탁종합재고현황
 * 서브 업무명 : 수탁종합재고현황상세
 * 설 명 : 수탁종합재고현황에대한 상세정보를 조회한다.
 * 작 성 자 : P180182
 * 작 성 일 : 2022.06.02
 * Copyright ⓒ SK TELECOM. All Right Reserved
 ------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">수탁 종합 재고 현황 상세</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- gridWrap -->
                    <TCRealGridHeader
                        id="dtlGridHeader"
                        ref="dtlGridHeader"
                        gridTitle="재고 현황 상세"
                        :gridObj="gridObj"
                        :isPageRows="true"
                        :isExceldown="true"
                        @excelDownBtn="excelDownBtn"
                        class="pop"
                    />
                    <TCRealGrid
                        id="dtlGrid"
                        ref="dtlGrid"
                        :fields="dtlGridHeader.fields"
                        :columns="dtlGridHeader.columns"
                    />
                    <!-- //gridWrap -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { DETAIL_GRID_HEADER } from '@/const/grid/dis/csm/disCsmConsigmentTmsPtDisPrstHeader.js'
import restApi from '@/api/biz/dis/csm/disCsmConsigmentTmsPtDisPrst.js'
import attachedFileApi from '@/api/common/attachedFile'

export default {
    name: 'DisCsmConsigmentTmsPtDisPrstDtlPopup',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
    },
    data() {
        return {
            dtlGridHeader: DETAIL_GRID_HEADER,
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            rowCnt: 15,
            reqParam: {
                // 요청파라미터
                hldDealcoCd: '', // 보유처코드
                orgCd: '', // 조직코드
                orgLvl: '', // 조직레벨
                prodCd: '', // 상품코드
                colorCd: '', // 색상코드
                strdDt: '', // 기준일자
                inoutDtlClCd: '', // 입출고상세구분코드
                dtlBrwsClCd: '', // 상세조회구분코드
                inoutClCd: '', // 입출고구분코드
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.reqParam.hldDealcoCd = value['hldDealcoCd']
                this.reqParam.orgCd = value['orgCd']
                this.reqParam.orgLvl = value['orgLvl']
                this.reqParam.prodCd = value['prodCd']
                this.reqParam.colorCd = value['colorCd']
                this.reqParam.strdDt = value['strdDt']
                this.reqParam.dealcoClCd = value['dealcoClCd']
                this.reqParam.prodClCd = value['prodClCd']
                this.reqParam.prchTypCd = value['prchTypCd']
                this.reqParam.inoutDtlClCd = value['inoutDtlClCd']
                this.reqParam.dtlBrwsClCd = value['dtlBrwsClCd']
                this.reqParam.inoutClCd = value['inoutClCd']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.gridData = this.gridSetData(this.rowCnt)
    },
    mounted() {
        this.gridObj = this.$refs.dtlGrid
        this.gridHeaderObj = this.$refs.dtlGridHeader
        this.gridObj.setGridState(false, false, false, false)

        // 전월재고는 yyyy-MM 형식으로 변환
        if (this.reqParam.dtlBrwsClCd == 'B') {
            var header = this.gridObj.gridView.getColumnProperty(
                'inoutDt',
                'header'
            )
            header.text = '입출고월'

            this.gridObj.gridView.setColumnProperty('inoutDt', 'header', header)
            this.gridObj.gridView.setColumnProperty(
                'inoutDt',
                'datetimeFormat',
                'yyyy-MM'
            )
        }

        this.getStaDisPrstDtlList()
    },
    methods: {
        // Grid Init
        gridSetData(rowCnt) {
            // CommonGrid(현재페이지 번호, 총 페이지, Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(0, rowCnt, '', '')
        },
        //Grid ExcelDown
        excelDownBtn() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-max/resource/dis/csm/consigment-start-point-inventory-detail-excel-download',
                this.reqParam
            )
        },
        // 수탁종합재고현황 상세 조회
        getStaDisPrstDtlList() {
            restApi.getStaDisPrstDtlList(this.reqParam).then((res) => {
                this.gridObj.setRows(res.gridList)
                this.gridData = this.gridSetData(this.rowCnt) // 초기화

                // 그리드 No 셋팅
                const rowCount = this.gridObj.dataProvider.getRowCount()
                this.gridHeaderObj.setPageCount({ totalDataCnt: rowCount })
                for (var i = 0; i < rowCount; i++) {
                    this.gridObj.gridView.setValue(i, 'NO', i + 1)
                }
                this.gridObj.gridView.commit()
            })
        },
        // 팝업닫기
        closeBtn() {
            this.activeOpen = false
        },
    },
}
</script>
