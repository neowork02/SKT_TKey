import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'NO',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'rgnCd',
            dataType: ValueType.TEXT, //권역코드
        },
        {
            fieldName: 'rgnNm',
            dataType: ValueType.TEXT, //권역명
        },
        {
            fieldName: 'sktDealCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, // 레벨0조직코드
        },
        {
            fieldName: 'lvOrgCd1',
            dataType: ValueType.TEXT, // 레벨1조직코드
        },
        {
            fieldName: 'lvOrgCd2',
            dataType: ValueType.TEXT, // 레벨2조직코드
        },
        {
            fieldName: 'lvOrgCd3',
            dataType: ValueType.TEXT, // 레벨3조직코드
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, // 조직
        },
        {
            fieldName: 'strdSvcYn',
            dataType: ValueType.TEXT, //바로도착
        },
        {
            fieldName: 'primSvcYn',
            dataType: ValueType.TEXT, //바로도착 행복배송
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //errDesc
        },
    ],
    columns: [
        {
            name: 'NO',
            fieldName: 'NO',
            type: 'data',
            width: '40',
            editable: false,
            styleName: 'center-column',
            numberFormat: '##0',
            header: {
                text: 'No',
            },
        },
        {
            name: 'rgnCd',
            fieldName: 'rgnCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '권역코드',
            },
        },
        {
            name: 'rgnNm',
            fieldName: 'rgnNm',
            type: 'data',
            width: '80',
            editable: false,
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '권역명',
            },
        },
        {
            name: 'sktDealCd',
            fieldName: 'sktDealCd',
            type: 'data',
            width: '100',
            editable: false,
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '100',
            editable: false,
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '100',
            editable: false,
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '거래처명',
            },
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '200',
            editable: false,
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '조직',
            },
        },
        {
            name: 'strdSvcYn',
            fieldName: 'strdSvcYn',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '바로도착',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 2,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'primSvcYn',
            fieldName: 'primSvcYn',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '바로도착 행복배송',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 2,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '200',
            editable: false,
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '오류메시지',
            },
        },
    ],

    //엑셀업로드 그리드용 columns
    columns2: [
        {
            name: 'rgnCd',
            fieldName: 'rgnCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '권역코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'strdSvcYn',
            fieldName: 'strdSvcYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '바로도착',
                showTooltip: false,
            },
        },
        {
            name: 'primSvcYn',
            fieldName: 'primSvcYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '바로도착 행복배송',
                showTooltip: false,
            },
        },
    ],
}
