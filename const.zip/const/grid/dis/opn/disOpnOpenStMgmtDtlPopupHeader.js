import { ValueType } from 'realgrid'

export const DisOpnOpenStMgmtDtl_GRID_HEADER = {
    fields: [
        {
            fieldName: 'opnOrdDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', //개봉지시일자
        },
        {
            fieldName: 'newOrgNm',
            dataType: ValueType.TEXT, //조직
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, //보유처
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //모델코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델명
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'openYn',
            dataType: ValueType.TEXT, //개봉상태
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT, //처리자
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, //처리자ID
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'toOpenYn',
            dataType: ValueType.TEXT, //상태변경
        },
        {
            fieldName: 'hldPlcId',
            dataType: ValueType.TEXT, //보유처코드
        },
    ],
    columns: [
        {
            name: 'opnOrdDt',
            fieldName: 'opnOrdDt',
            header: {
                text: '개봉일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'newOrgNm',
            fieldName: 'newOrgNm',
            type: 'data',
            width: 350,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcId',
            fieldName: 'hldPlcId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처',
                showTooltip: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'openYn',
            fieldName: 'openYn',
            header: {
                text: '개봉상태',
            },
            lookupDisplay: true,
            values: ['Y', 'N'],
            labels: ['개봉', '미개봉'],
            editor: {
                type: 'dropDown',
                dropDownCount: 2,
            },
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'toOpenYn',
            fieldName: 'toOpenYn',
            type: 'data',
            visible: false,
        },
    ],
}
