import { ValueType } from 'realgrid'

export const DisCioConsigmentSaleOutMgmtDtl_GRID_HEADER = {
    fields: [
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ordQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asgnQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'outQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'amt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchTyp',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCdOrg',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCdOrg',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outSeq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mdlClCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
            footer: {
                text: '합계',
            },
            width: '120',
        },
        {
            name: 'ordQty',
            fieldName: 'ordQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문수량',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'asgnQty',
            fieldName: 'asgnQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정수량',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'outQty',
            fieldName: 'outQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고지시',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            numberFormat: '#,##0',
            width: '120',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            visible: false,
            type: 'data',
        },
        {
            name: 'amt',
            fieldName: 'amt',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            visible: false,
            type: 'data',
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'prchTyp',
            fieldName: 'prchTyp',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCdOrg',
            fieldName: 'colorCdOrg',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCdOrg',
            fieldName: 'prodCdOrg',
            visible: false,
            type: 'data',
        },
        {
            name: 'outSeq',
            fieldName: 'outSeq',
            visible: false,
            type: 'data',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            visible: false,
            type: 'data',
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            visible: false,
            type: 'data',
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            visible: false,
            type: 'data',
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'mdlClCd',
            fieldName: 'mdlClCd',
            type: 'data',
            visible: false,
        },
    ],
}
