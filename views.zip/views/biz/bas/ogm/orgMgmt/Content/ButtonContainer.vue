<template>
    <div class="div5_5 cont3">
        <ul class="btnOrder">
            <li>
                <TCComButton
                    :Vuetify="false"
                    color=""
                    eClass="btnOrderleft"
                    @click="addBtn"
                    :objAuth="this.objAuth"
                >
                </TCComButton>
            </li>
            <li>
                <TCComButton
                    :Vuetify="false"
                    color=""
                    eClass="btnOrderright"
                    @click="delBtn"
                    :objAuth="this.objAuth"
                >
                </TCComButton>
            </li>
        </ul>
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/ogm/orgMgmt/helpers'
export default {
    components: {},
    data() {
        return {
            objAuth: {},
            showFlag: false,
            title: 'BasOgmOrgMgmtButtonCont',
            status: 1,
            isReadOnly: false,
            form: {},
        }
    },
    created() {},
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        async addBtn() {
            console.log('add 매장')
            await this.defaultAssign_({
                key: 'moveStore',
                value: 'add',
            })
        },
        async delBtn() {
            console.log('del 매장')
            await this.defaultAssign_({
                key: 'moveStore',
                value: 'del',
            })
        },
    },
}
</script>
