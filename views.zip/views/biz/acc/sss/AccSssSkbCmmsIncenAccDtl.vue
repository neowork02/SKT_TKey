<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">SKB수수료/인센티브 정산관리 세부내역</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="right">
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="onClose"
                                >닫기</TCComButton
                            >
                        </li>
                    </ul>
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="M"
                                    v-model="accYm_"
                                    labelName="정산월"
                                    :eRequired="true"
                                    :disabled="true"
                                >
                                </TCComDatePicker>
                            </div>
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="searchParams.srchAgencyNm"
                                    :codeVal.sync="searchParams.srchAgencyCd"
                                    labelName="대리점"
                                    :disabled="true"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="searchParams.srchWireAccClNm"
                                    :codeVal.sync="searchParams.srchWireAccClCd"
                                    labelName="구분"
                                    :disabled="true"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="searchParams.srchProdClNm"
                                    :codeVal.sync="searchParams.srchProdClCd"
                                    labelName="상품"
                                    :disabled="true"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                />
                            </div>
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeader1"
                                ref="gridHeader1"
                                gridTitle="SKB수수료/인센티브 정산관리 세부내역"
                                :gridObj="gridHeaderObj"
                                :isExceldown="true"
                                @excelDownBtn="downloadExcelAll"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid1"
                                ref="grid1"
                                :editable="false"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
import sktCmmApi from '@/api/biz/acc/sss/AccSssSkbCmmsIncenAccMgmt'
import { CommonGrid, CommonUtil } from '@/utils'
import { GRID_HEADER } from '@/const/grid/acc/sss/AccSssSkbCmmsIncenAccDtlGrid'

export default {
    name: 'AccSssSkbCmmsIncenAccDtl',
    mixins: [CommonMixin],
    title: 'T에코폰 정산 파일 UPLOAD',
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list: [],
            gridData: this.gridSetData(this.rowcnt),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '350px', //그리드 높이 조절
            },

            searchForms: {},
            resultData: '',
            res: {},
            rowData: '',
            rowCnt: 15,
            accYm_: '',

            searchParams: {
                srchAccYm: '', // 정산월,
                srchAgencyCd: '',
                srchAgencyNm: '',
                srchWireAccClCd: '',
                srchWireAccClNm: '',
                srchProdClCd: '',
                srchProdClNm: '',
            },
        }
    },
    computed: {
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        console.log('mounted')
        this.accYm_ = moment(this.popupParams.accYm_).format('YYYY-MM')
        this.searchParams.srchAgencyNm = this.popupParams.agencyNm
        this.searchParams.srchAgencyCd = this.popupParams.agencyCd
        this.searchParams.srchWireAccClCd = this.popupParams.wireAccClCd
        this.searchParams.srchWireAccClNm = this.popupParams.wireAccClNm
        this.searchParams.srchProdClCd = this.popupParams.prodClCd
        this.searchParams.srchProdClNm = this.popupParams.prodClNm

        // grid 기본세팅
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, false, true)
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: '번호',
        })
        this.onSearch()
    },
    methods: {
        gridSetData: function (rowCnt) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, rowCnt, '', '')
        },
        //================================================
        // 상세 조회 :::: getSkbCmmsIncenAccDetail
        //================================================
        onSearch() {
            const srchAccYm = this.accYm_
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
            } else {
                this.searchForms = { ...this.searchParams }
                this.searchForms.srchAccYm = CommonUtil.onlyNumber(this.accYm_)
                this.getSkbCmmsIncenAccDetail(this.searchForms)
                console.log('전체리스트조회 ::::::: 시작')
            }
        },
        async getSkbCmmsIncenAccDetail() {
            await sktCmmApi
                .getSkbCmmsIncenAccDetail(this.searchForms)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        console.log('전체리스트조회 ::::::: ', res)
                        this.tecoAccListDtl = res
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator(res)
                        this.gridData = this.gridSetData()
                        this.gridHeaderObj.setPageCount(res)
                        console.log('전체리스트조회 ::::::: 끝')
                    } else {
                        this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                    }
                })
        },
        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcelAll: function () {
            sktCmmApi.downloadSkbCmmsIncenAccListDtlExcel(this.searchForms)
        },

        onClose: function () {
            this.activeOpenAgency = false
        },
        // exportGridBtn: function () {
        //     this.gridData =
        //         this.gridHeaderObj.exportGrid('test.xls')
        // },
    },
}
</script>
