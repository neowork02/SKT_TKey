<template>
    <div class="content">
        <h1>수작업카드입금정산관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    :disabled="this.buttonDisabled"
                    @click="excelUploadPopup"
                    >카드정산엑셀업로드</TCComButton
                >
                <!-- 카드정산엑셀업로드 팝업 -->
                <AccPacHndopCardDpstAccMgmtExcelPopup
                    v-if="showBoolExcelPopup === true"
                    ref="popup"
                    :dialogShow.sync="showBoolExcelPopup"
                />
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    :disabled="this.buttonDisabled"
                    @click="onSave('OPERATION_EXCEPT')"
                    >처리제외</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    :disabled="this.buttonDisabled"
                    @click="onSave('EXCEPT_CANCEL')"
                    >제외취소</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    :disabled="this.buttonDisabled"
                    @click="onSave('CONFIRM_CANCEL')"
                    >확정취소</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onReset"
                    :objAuth="objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="objAuth"
                    >조회</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave('CONFIRM')"
                    :objAuth="objAuth"
                    >저장</TCComButton
                >
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComDatePicker
                        labelName="조회일자"
                        calType="DP"
                        :eRequired="true"
                        v-model="searchParams.searchYmd_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="searchParams.searchOrgNm"
                        :codeVal.sync="searchParams.searchOrgCd"
                        labelName="조직"
                        placeholder="선택해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :eRequired="true"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoOrgTreesPopup
                        v-if="showBcoOrgTrees"
                        :parentParam="searchOrgPopupParams"
                        :rows="resultOrgTreeRows"
                        :dialogShow.sync="showBcoOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="searchParams.searchCardCoNm"
                        :codeVal.sync="searchParams.searchCardCoCd"
                        labelName="카드사"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOutDealEnterKey"
                        @appendIconClick="onOutDealIconClick"
                        @input="onOutDealInput"
                    />
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onOutDealReturnData"
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="searchParams.searchDealcoNm"
                        :codeVal.sync="searchParams.searchDealcoCd"
                        labelName="수납처"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchAccDealcoParams"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="확정여부"
                        :objAuth="objAuth"
                        :itemList="[
                            { commCdVal: '', commCdValNm: '전체' },
                            { commCdVal: 'Y', commCdValNm: '확정' },
                            { commCdVal: 'N', commCdValNm: '미확정' },
                            { commCdVal: 'X', commCdValNm: '처리제외' },
                        ]"
                        v-model="searchParams.searchFixYn"
                    ></TCComComboBox>
                </div>
                <div class="formitem div3">
                    <TCComCheckBox
                        labelName=" "
                        v-model="searchParams.searchType_"
                        :itemList="[
                            { commCdVal: 'Y', commCdValNm: '이전미정산포함' },
                        ]"
                        :objAuth="objAuth"
                    ></TCComCheckBox>
                </div>
            </div>
        </div>
        <!-- //Search_div -->

        <!-- gridWrap -->
        <div class="gridWrap">
            <TCComTab
                :tab.sync="tab.tabSync1"
                :items="['writeTab', 'handTab']"
                :itemName="['수기카드입금정산관리', '수작업카드입금정산']"
                @click="onActiveTabClick"
                sliderSize="8"
            >
                <template #writeTab>
                    <TCRealGridHeader
                        id="gridHeader0"
                        ref="gridHeader0"
                        :gridObj="tab.grid[0]"
                        gridTitle="수기카드입금정산관리"
                        :isExceldown="true"
                        @excelDownBtn="
                            exportExcelDownButton('수기카드입금정산관리')
                        "
                    />
                    <TCRealGrid
                        id="grid0"
                        ref="grid0"
                        :fields="view.fields0"
                        :columns="view.columns0"
                        :styles="gridStyle"
                    />
                </template>
                <template #handTab>
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="수작업카드입금정산"
                        :gridObj="tab.grid[1]"
                        :isExceldown="true"
                        @excelDownBtn="
                            exportExcelDownButton('수작업카드입금정산')
                        "
                    >
                        <!-- 정산일 -->
                        <template #gridElementArea>
                            <TCComDatePicker
                                labelName="정산일"
                                calType="D"
                                :eRequired="true"
                                v-model="searchParams.searchAccYmd_"
                            />
                        </template>
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :fields="view.fields1"
                        :columns="view.columns1"
                        :styles="gridStyle"
                        @hook:mounted="tabGridMounted(1)"
                    />
                </template>
            </TCComTab>
        </div>
        <!-- //gridWrap -->
        <!-- 수기카드입금정산관리 팝업 -->
        <AccPacHndopCardDpstAccMgmtPopup
            v-if="showBoolPopup === true"
            ref="popup"
            :dialogShow.sync="showBoolPopup"
            :popupParams.sync="searchPopupParams"
        />
    </div>
</template>

<script>
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
import { AccUtil } from '@/views/biz/acc'
import pacApi from '@/api/biz/acc/pac'
import { GRID_HEADER } from '@/const/grid/acc/pac/accPacHndopCardDpstAccMgmtGrid'
import AccPacHndopCardDpstAccMgmtPopup from '@/views/biz/acc/pac/AccPacHndopCardDpstAccMgmtPopup'
import AccPacHndopCardDpstAccMgmtExcelPopup from '@/views/biz/acc/pac/AccPacHndopCardDpstAccMgmtExcelPopup'

//  내부조직팝업(전체)
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//  내부조직팝업(전체)

//  내부거래처(권한조직)
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//  내부거래처(권한조직)

//  외부거래처(제조사,매입처,배송사 등) 팝업
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//  외부거래처(제조사,매입처,배송사 등)

export default {
    name: 'AccPacHndopCardDpstAccMgmt',
    title: '수작업카드입금정산관리',
    mixins: [CommonMixin],
    components: {
        AccPacHndopCardDpstAccMgmtPopup,
        AccPacHndopCardDpstAccMgmtExcelPopup,
        BasBcoOutDealsPopup,
        BasBcoOrgTreesPopup,
        BasBcoDealcosPopup,
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            buttonDisabled: true,
            showBoolPopup: false,
            showBoolExcelPopup: false,
            gridStyle: {
                height: '360px',
            },
            tab: {
                nowIndex: 0,
                tabSync1: 0,
                grid: [{}, {}],
                list: [[], []],
            },
            tabDefault: {},
            searchParams: {
                searchYmd_: [
                    moment().format('YYYY-MM-01'),
                    moment().format('YYYY-MM-DD'),
                ] /*조회일자*/,
                searchStartYmd: '' /*조회일자(시작일자)*/,
                searchEndYmd: '' /*조회일자(종료일자)*/,
                searchOrgCd: '' /*조직코드*/,
                searchOrgNm: '' /*조직명*/,
                searchOrgLvl: '' /* 조직Level */,
                searchLvOrgCd: '' /* 0레벨조직코드 */,
                searchCardCoCd: '' /*카드사코드*/,
                searchCardCoNm: '' /*카드사명*/,
                searchDealcoCd: '' /*수납처코드*/,
                searchDealcoNm: '' /*수납처명*/,
                searchFixYn: '' /*확정여부*/,
                searchType_: [] /*카드사*/,
                searchType: '' /*카드사*/,
                searchTabIndex: 0 /*현재 Tab index*/,
                saveType: 'CONFIRM',
                checkedRows: [] /*체크Rows*/,
                searchAccYmd_: moment().format('YYYY-MM-DD'),
                searchAccYmd: moment().format('YYYYMMDD'),
            },
            searchParamsDefault: {},
            searchPopupParams: {},

            //  내부조직팝업(전체)
            showBcoOrgTrees: false,
            searchOrgPopupParams: {},
            resultOrgTreeRows: [],
            //  내부조직팝업(전체)

            //  외부거래처(제조사,매입처,배송사 등) 팝업
            showBcoOutDeals: false,
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '7X', // 거래처그룹
                dealcoClCd1: '', // 거래처구분
            },
            resultOutDealRows: [],
            //  외부거래처(제조사,매입처,배송사 등) 팝업

            //  내부거래처(권한조직)
            basBcoDealcoShow: false,
            resultDealcoRows: [],
            searchAccDealcoParams: {
                basDay: '',
                orgCd: '',
                orgNm: '',
                dealcoCd: '',
                dealcoNm: '',
                dealcoGrpCd: '',
            },
            //  내부거래처(권한조직)
        }
    },
    watch: {
        'searchParams.searchType_'(newVal) {
            if (!_.isEmpty(newVal)) {
                this.searchParams.searchType = newVal[0]
            }
        },
        'searchParams.searchYmd_'(newArr) {
            this.searchParams.searchStartYmd = newArr[0]
            this.searchParams.searchEndYmd = newArr[1]
            if (!_.isEmpty(newArr[0])) {
                this.searchParams.searchStartYmd = newArr[0].replace(/-/g, '')
            }
            if (!_.isEmpty(newArr[1])) {
                this.searchParams.searchEndYmd = newArr[1].replace(/-/g, '')
            }
            this.searchAccDealcoParams.basDay = moment(
                this.searchParams.searchStartYmd
            )
                .endOf('month')
                .format('YYYYMMDD')
        },
        'searchParams.searchOrgCd'(newVal) {
            this.searchAccDealcoParams.orgCd = newVal
        },
        'searchParams.searchOrgNm'(newVal) {
            this.searchAccDealcoParams.orgNm = newVal
        },
        'searchParams.searchDealcoCd'(newVal) {
            this.searchAccDealcoParams.dealcoCd = newVal
        },
        'searchParams.searchDealcoNm'(newVal) {
            this.searchAccDealcoParams.dealcoNm = newVal
        },
        'searchParams.searchAccYmd_'(newVal) {
            var _newVal = newVal
            if (!_.isEmpty(newVal)) {
                _newVal = newVal.replace(/-/g, '')
            }
            this.searchParams.searchAccYmd = _newVal
        },
    },
    mounted() {
        // 초기화를 위해 초기값 변수에 저장하기
        this.tabDefault = _.cloneDeep(this.tab)
        this.searchParamsDefault = _.cloneDeep(this.searchParams)
        this.fileDefault = _.cloneDeep(this.file)

        this.tab.grid[0] = this.$refs.grid0
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.tab.grid[0].setGridState(false, false, false, false)

        //  회사구분조직코드
        this.searchParams.searchLvOrgCd = this.orgInfo.orgCdLvl0

        // 그리드 더블클릭시
        // this.tab.grid[0].gridView.onCellDblClicked = (grid, clickData) => {
        //     // [수기카드 입금정산상세] 팝업 오픈하기
        //     this.showBoolPopup = true
        //     this.searchPopupParams = Object.assign(
        //         grid.getValues(clickData.itemIndex),
        //         this.searchParams
        //     )
        // }
    },
    methods: {
        tabGridMounted: function (tabIndex) {
            this.tab.grid[tabIndex] = this.$refs['grid' + tabIndex]
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            this.tab.grid[tabIndex].setGridState(false, false, true, false)

            // 수작업카드입금정산(Tab1)일 경우
            if (tabIndex == 1) {
                //편집가능
                this.tab.grid[tabIndex].gridView.setEditOptions({
                    editable: true,
                    updatable: true,
                })

                // 그리드 클릭시 체크된 row만 편집가능하게 수정
                this.tab.grid[tabIndex].gridView.onCellClicked = (
                    grid,
                    clickData
                ) => {
                    // [수작업카드입금정산] tab인 경우
                    if (tabIndex == 1) {
                        console.log(grid + clickData)
                        var isChecked = grid.isCheckedRow(clickData.itemIndex)
                        var fixYn = grid.getValue(clickData.itemIndex, 'fixYn')
                        if (isChecked && fixYn != 'Y') {
                            grid.setEditOptions({ editable: true })
                            setTimeout(() => {
                                grid.showEditor() // 그리드 한번 클릭시 편집기 상태로 변경
                            }, 300)
                        } else {
                            grid.setEditOptions({ editable: false })
                            grid.hideEditor() // 그리드 한번 클릭시 편집기 상태 닫기
                        }
                    }
                }

                // 그리드의 체크박스 체크/체크해제시
                this.tab.grid[tabIndex].gridView.onItemChecked = (
                    grid,
                    itemIndex,
                    checked
                ) => {
                    // [수작업카드입금정산] tab인 경우
                    if (tabIndex == 1) {
                        console.log(grid + itemIndex)
                        var fixYn = grid.getValue(itemIndex, 'fixYn')
                        if (checked && fixYn != 'Y') {
                            // 정산일,입금금액,수수료 컬럼에 값 자동 세팅
                            grid.setValue(
                                itemIndex,
                                'fixDt',
                                this.searchParams.searchAccYmd
                            )
                            grid.setValue(
                                itemIndex,
                                'dpstAccAmt',
                                grid.getValue(itemIndex, 'calcDpstAccAmt')
                            )
                            grid.setValue(
                                itemIndex,
                                'dpstAccCmmsAmt',
                                grid.getValue(itemIndex, 'calcDpstAccCmms')
                            )
                        } else {
                            grid.setEditOptions({ editable: false })
                            grid.hideEditor() // 그리드 한번 클릭시 편집기 상태 닫기
                        }
                        console.log('KYJ checke => ', checked, fixYn)
                        if (!checked && fixYn != 'Y') {
                            // 정산일,입금금액,수수료 컬럼에 값 자동 세팅
                            grid.setValue(itemIndex, 'fixDt', '')
                            grid.setValue(itemIndex, 'dpstAccAmt', 0)
                            grid.setValue(itemIndex, 'dpstAccCmmsAmt', 0)
                        }
                    }
                }

                // 그리드의 수납금액, 수수료 값 변경시
                this.tab.grid[tabIndex].gridView.onEditRowChanged = (
                    grid,
                    itemIndex,
                    dataRow,
                    field,
                    oldValue,
                    newValue
                ) => {
                    var cmms_limit_lt = 0
                    var cmms_limit_gt = 0.04
                    var cmms_rate = 0
                    var payAmt = grid.getValue(itemIndex, 'payAmt')
                    if (oldValue == undefined) oldValue = 0
                    if (newValue == undefined) newValue = 0

                    // 입금금액이 변경되었을 경우
                    if (field == 21) {
                        if (
                            (payAmt > 0 && newValue < 0) ||
                            (payAmt < 0 && newValue > 0)
                        ) {
                            this.showTcComAlert(
                                '입력하신 금액 오류입니다. 확인하십시오.'
                            )
                            // grid.setValue(itemIndex, 'dpstAccAmt', oldValue)
                        } else {
                            cmms_rate =
                                Math.round(
                                    ((payAmt - newValue) / payAmt) * 100
                                ) / 100

                            if (
                                cmms_rate < cmms_limit_lt ||
                                cmms_rate > cmms_limit_gt
                            ) {
                                this.showTcComAlert(
                                    '수수료를 다시한번 확인하세요.수수료가 0%이하 4%초과시 관리자에게 문의하세요.'
                                )
                                grid.setValue(
                                    itemIndex,
                                    'dpstAccCmmsAmt',
                                    grid.getValue(itemIndex, 'calcDpstAccCmms')
                                )
                                return
                            }
                            grid.setValue(
                                itemIndex,
                                'dpstAccCmmsAmt',
                                payAmt - newValue
                            )
                        }
                    }

                    // 수수료가 변경되었을 경우
                    if (field == 22) {
                        if (
                            (payAmt > 0 && newValue < 0) ||
                            (payAmt < 0 && newValue > 0)
                        ) {
                            this.showTcComAlert(
                                '입력하신 금액 오류입니다. 확인하십시오.'
                            )
                            // grid.setValue(itemIndex, 'dpstAccCmmsAmt', oldValue)
                        } else {
                            cmms_rate =
                                Math.round((newValue / payAmt) * 100) / 100

                            if (
                                cmms_rate < cmms_limit_lt ||
                                cmms_rate > cmms_limit_gt
                            ) {
                                this.showTcComAlert(
                                    '수수료를 다시한번 확인하세요. 수수료가 0%이하 4%초과시 관리자에게 문의하세요.'
                                )
                                grid.setValue(
                                    itemIndex,
                                    'dpstAccAmt',
                                    grid.getValue(itemIndex, 'calcDpstAccAmt')
                                )
                                return
                            }

                            grid.setValue(
                                itemIndex,
                                'dpstAccAmt',
                                payAmt - newValue
                            )
                        }
                    }
                }
            }
        },
        // 화면초기화
        onReset: function () {
            // 현재Tab번호를 변수에 저장한다.
            var tabNowIndex = _.cloneDeep(this.tab.nowIndex)

            // 변수 초기화
            this.searchParams = _.cloneDeep(this.searchParamsDefault)
            this.tab = _.cloneDeep(this.tabDefault)
            this.searchParams.searchTabIndex = this.tab.nowIndex

            // Grid 초기화
            for (var i = 0; i < 2; i++) {
                this.tab.list[i] = []
                this.$refs['grid' + i].setRows(this.tab.list[i])
            }

            // 원래 보였던 Tab으로 다시 이동시키기
            this.tab.nowIndex = tabNowIndex
            this.tab.tabSync1 = tabNowIndex

            //  회사구분조직코드
            this.searchParams.searchLvOrgCd = this.orgInfo.orgCdLvl0
            // this.gridObj.gridView.orderBy([]) // 정렬 초기화
            this.tab.grid[0].gridView.orderBy([]) // 정렬 초기화
            this.tab.grid[1].gridView.orderBy([]) // 정렬 초기화
        },
        setParamJson: function (_method) {
            let _searchParams = _.cloneDeep(this.searchParams)
            _searchParams.searchTabIndex = this.tab.nowIndex

            // get방식으로 파라미터 넘길 때 오류로 인해 아래 제거함
            if (_method == 'GET') {
                delete _searchParams['searchYmd_']
                delete _searchParams['checkedRows']
            }

            delete _searchParams['searchType_']
            return _searchParams
        },
        onActiveTabClick(tabIndex) {
            this.tab.nowIndex = tabIndex
            if (tabIndex == 0) {
                this.buttonDisabled = true
                this.gridObjWrite = this.$refs.gridWrite
            } else if (tabIndex == 1) {
                this.buttonDisabled = false
                this.gridObjHand = this.$refs.gridHand
            }
        },
        getSearchTypeInfo(saveType) {
            var modeName = ''
            if (saveType == 'CONFIRM') {
                modeName = '확정'
            } else if (saveType == 'OPERATION_EXCEPT') {
                modeName = '처리제외'
            } else if (saveType == 'EXCEPT_CANCEL') {
                modeName = '제외취소'
            } else if (saveType == 'CONFIRM_CANCEL') {
                modeName = '확정취소'
            }

            return modeName
        },
        getCheckedRows: function () {
            var checkedRows = []
            var checkedIndexRows =
                this.tab.grid[this.tab.nowIndex].gridView.getCheckedRows(true)

            for (var i = 0; i < checkedIndexRows.length; i++) {
                var rowData = this.tab.grid[
                    this.tab.nowIndex
                ].gridView.getValues(checkedIndexRows[i])

                checkedRows.push(rowData)
            }

            return checkedRows
        },
        onSearchValidate: function (_searchParams) {
            if (
                _.isEmpty(_searchParams.searchStartYmd) ||
                _.isEmpty(_searchParams.searchEndYmd)
            ) {
                this.showTcComAlert('조회일자를 선택해 주세요')
                return false
            }
            if (_.isEmpty(_searchParams.searchOrgCd)) {
                this.showTcComAlert('조직을 선택해 주세요')
                return false
            }

            return true
        },
        onSearch: function () {
            console.log('onSearch')
            let _searchParams = this.setParamJson('GET')

            // 조회조건 체크
            if (this.onSearchValidate(_searchParams) == false) {
                return
            }
            this.tab.grid[this.tab.nowIndex].gridView.commit()

            pacApi
                .getAccPacHndopCardDpstAccMgmtList(_searchParams)
                .then((res) => {
                    this.tab.list[this.tab.nowIndex] = res
                    this.tab.grid[this.tab.nowIndex].setRows(
                        this.tab.list[this.tab.nowIndex]
                    )
                })
        },
        onCommonCheck: function () {
            if (this.tab.grid[this.tab.nowIndex].gridView) {
                this.tab.grid[this.tab.nowIndex].gridView.commit()
            }

            // Tab1이 아니면 저장 로직이 없으므로 return한다.
            if (this.tab.nowIndex == 0) {
                return false
            }

            // 그리드에서 저장할 목록을 변수에 담는다.
            this.searchParams.checkedRows = this.getCheckedRows()

            if (this.searchParams.checkedRows.length == 0) {
                this.showTcComAlert('대상 목록이 없습니다.')
                return false
            }

            var isFixErp = false
            this.searchParams.checkedRows.map((json) => {
                if (json.isFixYn == 'Y') {
                    isFixErp = true
                    return false
                }
            })

            // ERP전송여부가 전송인 경우
            if (isFixErp) {
                this.showTcComAlert('ERP전송이 완료된 목록이 있습니다.')
                return false
            }

            return true
        },
        onConfirmValidate() {
            var resultJson = {
                json: {},
                isFix: false,
                isFixErp: false,
                isNotEqualsAmt: false,
                isUnbalanceAmt: false,
                isMistakeCmmsRate: false,
            }

            this.searchParams.checkedRows.map((json) => {
                resultJson.json = json
                if (json.fixYn == 'Y') {
                    resultJson.isFix = true
                    return false
                }

                if (
                    Number(json.payAmt) !=
                    Number(json.dpstAccAmt) + Number(json.dpstAccCmmsAmt)
                ) {
                    resultJson.isNotEqualsAmt = true
                    return false
                }

                if (
                    (Number(json.payAmt) > 0 &&
                        (Number(json.dpstAccAmt) < 0 ||
                            Number(json.dpstAccCmmsAmt) < 0)) ||
                    (Number(json.payAmt) < 0 &&
                        (Number(json.dpstAccAmt) > 0 ||
                            Number(json.dpstAccCmmsAmt) > 0))
                ) {
                    resultJson.isUnbalanceAmt = true
                    return false
                }

                var cmmsRate =
                    Math.round(
                        (Number(json.dpstAccCmmsAmt) / Number(json.payAmt)) *
                            100
                    ) / 100

                if (cmmsRate < 0 || cmmsRate > 0.04) {
                    resultJson.isMistakeCmmsRate = true
                    return false
                }

                if (!AccUtil.isEmpty(json.fixDt)) {
                    json.fixDt = AccUtil.dateToFormat(json.fixDt, 'YYYYMMDD')
                }
            })

            // 확정여부가 확정인 경우
            if (resultJson.isFix) {
                this.showTcComAlert(
                    '[' +
                        resultJson.json.accDealcoNm +
                        '] 정산처의 확정여부가 미확정일 경우 처리 가능합니다.'
                )
                return false
            }

            // 금액이 일치하지 않는 경우
            if (resultJson.isNotEqualsAmt) {
                this.showTcComAlert(
                    '[' +
                        resultJson.json.accDealcoNm +
                        '] 정산처의 입금금액을 확인해 주세요.'
                )
                return false
            }

            // 금액의 양수/음수가 서로 일치하지 않을 경우
            if (resultJson.isUnbalanceAmt) {
                this.showTcComAlert(
                    '[' +
                        resultJson.json.accDealcoNm +
                        '] 정산처의 수수료 또는 입금금액을 다시 한번 확인해 주세요.'
                )
                return false
            }

            // 수수료 비율이 안 맞는 경우
            if (resultJson.isMistakeCmmsRate) {
                this.showTcComAlert(
                    '[' +
                        resultJson.json.accDealcoNm +
                        '] 정산처의 수수료를 다시 한번 확인해 주세요. 수수료가 0% 미만, 4% 초과시 관리자에서 문의하세요.'
                )
                return false
            }

            return true
        },
        onNoConfirmValidate(saveType) {
            var fixVal = ''
            var fixName = ''

            // 제외취소일 경우
            if (saveType == 'OPERATION_EXCEPT') {
                fixVal = 'N'
                fixName = '미확정'
            }
            // 제외취소일 경우
            else if (saveType == 'EXCEPT_CANCEL') {
                fixVal = 'X'
                fixName = '처리제외'
            }
            // 확정취소일 경우
            else if (saveType == 'CONFIRM_CANCEL') {
                fixVal = 'Y'
                fixName = '확정'
            }

            var isNotPass = false
            this.searchParams.checkedRows.map((json) => {
                if (json.fixYn != fixVal) {
                    isNotPass = true
                    return false
                }
            })

            // 확정여부가 처리제외가 아닌 경우
            if (isNotPass) {
                this.showTcComAlert(
                    '확정여부가 ' + fixName + '일 경우만 처리 가능합니다.'
                )
                return false
            }
        },
        // 저장(확정)/처리제외/제외취소/확정취소 처리
        async onSave(saveType) {
            this.searchParams.saveType = saveType

            // 공통 체크 사항 확인
            if (this.onCommonCheck() == false) {
                return
            }

            // validation 체크
            var isPass = true
            if (saveType == 'CONFIRM') {
                isPass = this.onConfirmValidate()
            } else {
                isPass = this.onNoConfirmValidate(saveType)
            }

            if (isPass == false) {
                return
            }

            // 확정/처리제외/제외취소/확정취소 실행여부 확인
            const confirmMsg = await this.showTcComConfirm(
                this.getSearchTypeInfo(saveType) + '하시겠습니까?'
            )
            if (!confirmMsg) {
                return
            }

            pacApi
                .saveAccPacHndopCardDpstAccMgmtList(this.setParamJson())
                .then((res) => {
                    if (res.resultCode == 'SUCCESS') {
                        this.showTcComAlert(
                            this.getSearchTypeInfo(saveType) + '되었습니다.'
                        )
                    } else if (res.resultCode == 'FAIL') {
                        this.showTcComAlert(res.resultMessage)
                    }
                    this.onSearch()
                })
        },
        /* 화면 상단의 엑셀다운로드 버튼 클릭시 실행 */
        exportExcelDownButton(excelFileName) {
            let _searchParams = this.setParamJson('GET')

            // 조회조건 Validation 체크
            if (this.onSearchValidate(_searchParams) == false) {
                return
            }

            //  엑셀파일명(정산월 + 조직명)
            _searchParams.excelFileName =
                '수작업칻입금정산관리_' +
                excelFileName +
                '_' +
                this.searchParams.searchStartYmd +
                '_' +
                this.searchParams.searchEndYmd +
                '_' +
                this.searchParams.searchOrgNm

            pacApi
                .getAccPacHndopCardDpstAccMgmtListExcelDown(_searchParams)
                .then(() => {
                    this.showTcComAlert('엑셀파일이 다운로드되었습니다.')
                })
        },
        excelUploadPopup() {
            if (AccUtil.isEmpty(this.searchAccDealcoParams.orgNm)) {
                this.showTcComAlert('조직을 입력하십시오.')
                return
            }

            if (AccUtil.isEmpty(this.searchParams.searchAccYmd)) {
                this.showTcComAlert('정산일을 입력하십시오.')
                return
            }

            this.showBoolExcelPopup = true
        },
        // 내부조직팝업(전체) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(전체) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchOrgPopupParams.orgNm = this.searchParams.searchOrgNm
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchOrgPopupParams)
                .then((res) => {
                    console.log('getOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(전체) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(전체) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(전체) 팝업 오픈
                    if (res.length === 1) {
                        this.searchParams.searchOrgCd = _.get(res[0], 'orgCd')
                        this.searchParams.searchOrgNm = _.get(res[0], 'orgNm')
                        this.searchParams.searchOrgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultOrgTreeRows = res
                        this.showBcoOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(전체) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이 아니면 내부조직팝업(전체) 정보 조회
            // 그 이외는 내부조직팝업(전체) 팝업 오픈
            if (!_.isEmpty(this.searchParams.orgNm)) {
                this.getOrgTreeList()
            } else {
                this.showBcoOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParams.searchOrgNm)) {
                this.showTcComAlert('조직명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(전체) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(전체) 코드 초기화
            this.searchParams.searchOrgCd = ''
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParams.searchOrgCd = _.get(retrunData, 'orgCd')
            this.searchParams.searchOrgNm = _.get(retrunData, 'orgNm')
            this.searchParams.searchOrgLvl = _.get(retrunData, 'orgLvl')
        },
        //  내부조직팝업(전체)팝업

        //  외부거래처(제조사,매입처,배송사 등) 팝업
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            this.searchOutDealParam.dealcoNm = this.searchParams.searchCardCoNm
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.searchParams.searchCardCoCd = _.get(
                            res[0],
                            'dealcoCd'
                        )
                        this.searchParams.searchCardCoNm = _.get(
                            res[0],
                            'dealcoNm'
                        )
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            if (!_.isEmpty(this.searchParams.searchCardCoNm)) {
                this.getOutDealList()
            } else {
                this.showBcoOutDeals = true
            }
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParams.searchCardCoNm)) {
                this.showTcComAlert('카드사명을 입력하십시오.')
                return
            }
            // 외부거래처 정보 조회
            this.getOutDealList()
        },
        // 외부거래처 TextField Input 이벤트 처리
        onOutDealInput() {
            // 입력되는 값이 있으면 외부거래처 코드 초기화
            this.searchParams.searchCardCoCd = ''
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParams.searchCardCoCd = _.get(retrunData, 'dealcoCd')
            this.searchParams.searchCardCoNm = _.get(retrunData, 'dealcoNm')
        },
        //  외부거래처(제조사,매입처,배송사 등) 팝업

        //  내부거래처(권한조직))
        getDealcosList() {
            this.searchAccDealcoParams.orgCd = this.searchParams.searchOrgCd
            this.searchAccDealcoParams.orgNm = this.searchParams.searchOrgNm
            this.searchAccDealcoParams.orgLvl = this.searchParams.searchOrgLvl
            this.searchAccDealcoParams.dealcoNm =
                this.searchParams.searchDealcoNm

            basBcoDealcosApi
                .getDealcosList(this.searchAccDealcoParams)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.searchParams.searchDealcoCd = _.get(
                            res[0],
                            'dealcoCd'
                        )
                        this.searchParams.searchDealcoNm = _.get(
                            res[0],
                            'dealcoNm'
                        )
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        onDealcoIconClick() {
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 팝업오픈
            this.basBcoDealcoShow = true
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            this.resultDealcoRows = []
            if (_.isEmpty(this.searchParams.searchOrgCd)) {
                this.showTcComAlert('조직을 선택하십시오.')
                return
            }
            if (_.isEmpty(this.searchParams.searchDealcoNm)) {
                this.showTcComAlert('수납처명을 입력하십시오.')
                return
            }

            this.getDealcosList()
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchParams.dealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParams.searchDealcoCd = _.get(retrunData, 'dealcoCd')
            this.searchParams.searchDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //  내부거래처(권한조직))
    },
}
</script>

<style scoped>
.grid {
    height: 330px;
}
</style>
