<template>
    <div v-if="this.isDisabledGridBizRgstInfo1">
        <!-- SubTit  -->
        <div class="stitHead">
            <h4 class="subTit">대리점 추가정보</h4>
        </div>
        <!-- //SubTit -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="agencyAddInfo.sktAgencyNm"
                        :codeVal.sync="agencyAddInfo.sktAgencyCd"
                        labelName="U.Key대리점"
                        :eRequired="true"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        @enterKey="onOrgAgencyEnterKey"
                        @appendIconClick="onOrgAgencyIconClick"
                        @input="onOrgAgencyInput"
                    />
                    <BasBcoOrgAgencysPopup
                        v-if="showBcoOrgAgencys"
                        :parentParam="searchOrgAgencyParam"
                        :rows="resultOrgAgencyRows"
                        :dialogShow.sync="showBcoOrgAgencys"
                        @confirm="onOrgAgencyReturnData"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="agencyAddInfo.orgNm"
                        :codeVal.sync="agencyAddInfo.orgCd"
                        labelName="소속조직"
                        :eRequired="true"
                        placeholder="선택해주세요"
                        :disabledAfter="true"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="popupParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
            </div>
            <!-- //Search_line 1 -->
        </div>
        <!-- //Search_div -->
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dirDlvMgmt/helpers'
//====================조직별대리점팝업====================
import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
//====================//조직별대리점팝업====================
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
import _ from 'lodash'
//====================//내부조직팝업(권한)팝업====================
import CommonMixin from '@/mixins'

export default {
    name: 'AgencyAddInfoContainer',
    components: {
        BasBcoOrgAgencysPopup,
        BasBcoAuthOrgTreesPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            agencyAddInfo: {
                sktAgencyNm: '',
                sktAgencyCd: '',
                orgNm: '',
                orgCd: '',
            },
            storeKey: 'agencyAddInfoData',
            //====================조직별대리점팝업관련====================
            showBcoOrgAgencys: false, // 조직별대리점 팝업 오픈 여부
            searchOrgAgencyParam: {
                sktAgencyCd: '', // 대리점코드
                sktAgencyNm: '', // 대리점명
            },
            resultOrgAgencyRows: [], // 조직별대리점 팝업 오픈 여부
            //====================//조직별대리점팝업관련==================
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            popupParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부

            //====================//내부조직팝업(권한)팝업관련==================
        }
    },
    computed: {
        ...serviceComputed,
        //==================== 상세데이터 ==================
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
        //==================== //상세데이터 ==================
        isDisabledGridBizRgstInfo1: {
            get() {
                return this.isDisabledGridBizRgstInfo
            },
        },
    },
    mounted() {
        this.initData()
    },
    methods: {
        ...serviceMethods,
        initData() {
            this.agencyAddInfo = {
                sktAgencyNm: '',
                sktAgencyCd: '',
                orgNm: '',
                orgCd: '',
            }
        },
        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        //===================== 조직별 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getOrgAgencyList() {
            basBcoOrgAgencysApi
                .getOrgAgencyList(this.basPrmDealcoDtlVo)
                .then((res) => {
                    console.log('getOrgAgencyList then : ', res)
                    // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                    // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                    if (res.length === 1) {
                        this.agencyAddInfo.sktAgencyCd = _.get(
                            res[0],
                            'sktAgencyCd'
                        )
                        this.agencyAddInfo.sktAgencyNm = _.get(
                            res[0],
                            'sktAgencyNm'
                        )
                    } else {
                        this.resultOrgAgencyRows = res
                        this.showBcoOrgAgencys = true
                    }
                })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onOrgAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (_.isEmpty(this.agencyAddInfo.orgCd)) {
                this.showTcComAlert('소속조직을 먼저 입력해주세요.')
                return false
            }
            if (!_.isEmpty(this.agencyAddInfo.sktAgencyNm)) {
                this.getOrgAgencyList()
            } else {
                this.showBcoOrgAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onOrgAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.agencyAddInfo.sktAgencyNm)) {
                this.showTcComAlert('대리점명을 입력해주세요.')
                return false
            }
            // 대리점 정보 조회
            this.getOrgAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onOrgAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.agencyAddInfo.sktAgencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onOrgAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.agencyAddInfo.sktAgencyCd = _.get(retrunData, 'sktAgencyCd')
            this.agencyAddInfo.sktAgencyNm = _.get(retrunData, 'sktAgencyNm')

            let params = { ...this.agencyAddInfo }
            this.storeSet(this.storeKey, params)
        },
        //===================== //조직별대리점팝업관련 methods ================================
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.basPrmDealcoDtlVo)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.agencyAddInfo.orgCd = _.get(res[0], 'orgCd')
                        this.agencyAddInfo.orgNm = _.get(res[0], 'orgNm')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.agencyAddInfo.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.agencyAddInfo.orgNm)) {
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return false
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.agencyAddInfo.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.agencyAddInfo.orgCd = _.get(retrunData, 'orgCd')
            this.agencyAddInfo.orgNm = _.get(retrunData, 'orgNm')

            let params = { ...this.agencyAddInfo }
            this.storeSet(this.storeKey, params)
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
    },
    watch: {
        basPrmDealcoDtlVo: {
            handler: function (values) {
                let detailData = this.agencyAddInfo // 데이터 Set

                _.forEach(Object.keys(detailData), (key) => {
                    if (!_.isEmpty(key)) {
                        // 기본정보셋팅
                        let value = values[key]
                        //let isValue = false
                        //let currentDate = moment(new Date()).format('YYYY-MM-DD')
                        if (
                            _.isEqual(value, undefined) ||
                            _.isEqual(value, null) ||
                            _.isEqual(value, '')
                        ) {
                            if (typeof detailData[key] === 'object') {
                                value = []
                            } else {
                                value = ''
                            }
                        } else {
                            //isValue = true
                        }

                        // 필터정보셋팅
                        detailData[key] = value
                    }
                })

                let param = { ...detailData }
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
