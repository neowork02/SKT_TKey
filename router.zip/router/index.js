import Vue from 'vue'
import VueRouter from 'vue-router'

import guide from './modules/guide'
import pages from './modules/pages'
import mobile from './modules/mobile'
import uiSample from './modules/uiSample'
import TBaseLayout from '@/layout/TBaseLayout'
import SsoLogin from '@/views/login/SsoLogin'
import Login from '@/views/login/Login'
import SmLogOff from '@/views/login/SmLogOff'
import Main from '@/views/Main'
import store from '@/store'
import _ from 'lodash'
import addRouter from './addRouter'
Vue.use(VueRouter)

const routes = [
    {
        path: '/ssoLogin',
        name: '/ssoLogin',
        component: SsoLogin,
        meta: {
            menuNm: 'T.Key-Taka Login',
            menuNo: '0',
            screenId: 'SSO0000',
            logined: false,
        },
    },
    {
        path: '/login',
        name: '/login',
        component: Login,
        meta: {
            menuNm: 'T.Key-Taka Login',
            menuNo: '0',
            screenId: 'LOG0000',
            logined: false,
        },
    },
    {
        path: '/smlogoff',
        name: '/smlogoff',
        component: SmLogOff,
        meta: {
            menuNm: 'smlogoff',
            menuNo: '0',
            screenId: 'LOGOUT',
            logined: false,
        },
    },
    {
        path: '/main',
        name: '/main',
        component: Main,
        meta: {
            menuNm: 'T.Key-Taka Main',
            menuNo: '0',
            screenId: 'MAI0000',
        },
    },
    {
        path: '/',
        name: 'base',
        component: TBaseLayout,
        redirect: '/login',
        children: [
            {
                path: '/prototype/prototype1',
                component: () =>
                    import('@/views/prototype/prototype1.vue') /* 퍼블파일1 */,
                meta: {
                    menuNm: 'prototype1',
                    menuNo: '100',
                    screenId: 'PRO0000',
                },
            },
            {
                path: '/prototype/prototype2',
                component: () =>
                    import('@/views/prototype/prototype2.vue') /* 퍼블파일2 */,
            },
            {
                path: '/prototype/prototype3',
                component: () =>
                    import('@/views/prototype/prototype3.vue') /* 퍼블파일3 */,
            },
            {
                path: '/prototype/prototype4',
                component: () =>
                    import('@/views/prototype/prototype4.vue') /* 샘플파일4 */,
            },
            {
                name: '/prototype/prototype5',
                path: '/prototype/prototype5',
                component: () =>
                    import('@/views/prototype/prototype5.vue') /* 샘플파일5 */,
            },
            {
                name: '/prototype/prototype5Detail',
                path: '/prototype/prototype5Detail',
                component: () =>
                    import(
                        '@/views/prototype/prototype5Detail.vue'
                    ) /* 샘플파일5 상세 */,
            },
            //임시 대시보드 라우터설정 - 개발완료되면 제거
            {
                path: '/pages/basic/dashboardAcc',
                name: '/pages/basic/dashboardAcc',
                component: () =>
                    import(
                        '@/views/pages/basic/dashboardAcc.vue'
                    ) /* 대시보드_정산 */,
            },
            {
                path: '/pages/basic/dashboardRm',
                name: '/pages/basic/dashboardRm',
                component: () =>
                    import(
                        '@/views/pages/basic/dashboardRm.vue'
                    ) /* 대시보드_RM */,
            },
            {
                path: '/pages/basic/dashboardSal',
                name: '/pages/basic/dashboardSal',
                component: () =>
                    import(
                        '@/views/pages/basic/dashboardSal.vue'
                    ) /* 대시보드_판매 */,
            },
            {
                path: '/pages/basic/dashboardStore',
                name: '/pages/basic/dashboardStore',
                component: () =>
                    import(
                        '@/views/pages/basic/dashboardStore.vue'
                    ) /* 대시보드_판매점관리 */,
            },
        ],
    },
    ...guide,
    ...uiSample,
    ...pages,
    ...mobile,
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes,
})

addRouter(router)

router.beforeEach((to, from, next) => {
    // 에러회피
    // ;(to == from) == next
    console.log('라우터 시작시 인터셉터', to)

    if (to.fullPath !== '/' && to.fullPath === from.fullPath) {
        next(false)
    } else {
        const loginedPage = to.meta.logined ?? true
        const toRouterName = to.name ?? ''
        // 로그인 페이지는 승인 처리
        if (
            loginedPage === false ||
            to.fullPath.startsWith('/pages') ||
            to.fullPath.startsWith('/mobile') ||
            to.fullPath.startsWith('/guide')
        ) {
            next()
            // 로그인이 필요한 페이지
        } else {
            const userInfo = store.getters['login/userInfo']
            // user 정보가 없으면 로그인 페이지로 이동
            if (_.isEmpty(userInfo) || !userInfo) {
                next('/login')
            } else {
                new Promise((resolve) => {
                    resolve(next())
                }).then(() => {
                    // to가 main 인 경우
                    if (toRouterName === '/main') {
                        addRouter(router)
                    }
                })
            }
        }
    }
})
router.afterEach((to, from) => {
    // 에러회피
    to == from

    let menuGrpCd = ''
    let menuNo = to.meta.menuNo ?? ''
    let screenId = to.meta.screenId ?? ''
    if (_.isEmpty(to.params.menuGrpCd)) {
        // // 기준
        // if (to.fullPath.startsWith('/bas')) {
        //     menuGrpCd = '500'
        //     // 재고
        // } else if (to.fullPath.startsWith('/dis')) {
        //     menuGrpCd = '100'
        //     // 판매
        // } else if (to.fullPath.startsWith('/sal')) {
        //     menuGrpCd = '300'
        //     // 정책
        // } else if (to.fullPath.startsWith('/pol')) {
        //     menuGrpCd = '200'
        //     // 정산
        // } else if (to.fullPath.startsWith('/acc')) {
        //     menuGrpCd = '400'
        //     // 판매회계
        // } else if (to.fullPath.startsWith('/sac')) {
        //     menuGrpCd = '900'
        // }
        menuGrpCd = String(to.meta.menuNo).substring(0, 3)
    } else {
        menuGrpCd = to.params.menuGrpCd
    }

    //탭제목 지정(메뉴명)
    const menuNm = to.meta.menuNm
    document.title = menuNm

    //모바일 여부
    const mblGubun = to.meta?.mblGubun ?? 'N'

    let curMenuInfo = {
        menuNo: menuNo,
        screenId: screenId,
        menuGrpCd: menuGrpCd,
        menuNm: menuNm,
        mblGubun: mblGubun,
        toName: to.name ?? '',
    }
    store.dispatch('menu/setCurrentMenuInfo', curMenuInfo)
    console.log('라우터 종료시 인터셉터', to)
})

export default router
