<!-----------------------------------------------
 * 업무그룹명: 사고기기유심엑셀업로드
 * 서브업무명: 사고기기유심엑셀업로드
 * 설명: 사고기기유심엑셀업로드 엑셀업로드.
 * 작성자: P179234
 * 작성일: 2022.05.24
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">사고기기유심엑셀업로드</p>
                <div class="layerCont">
                    <div class="stitHead pop">
                        <h4 class="subTit">엑셀입력</h4>
                        <span class="stitBtnRef2">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="init"
                                :objAuth="objAuth"
                            >
                                초기화
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="saveBtn"
                                :disabled="saveBtnDisabled"
                                :objAuth="objAuth"
                            >
                                저장
                            </TCComButton>
                            <!-- <TCComButton
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                @click="closeBtn"
                            >
                                닫기
                            </TCComButton> -->
                        </span>
                    </div>
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComFileInput
                                    labelName="파일선택"
                                    v-model="files"
                                    @change="onFilesChange"
                                >
                                </TCComFileInput>
                            </div>
                            <div class="formitem div2">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            labelName="오류검증"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            :Vuetify="false"
                                            @click="errCheck"
                                        />
                                        <TCComButton
                                            labelName="오류일괄제거"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_del"
                                            :Vuetify="false"
                                            @click="errClear"
                                            :disabled="errClearDisabled"
                                        />
                                        <TCComButton
                                            labelName="양식다운로드"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_save"
                                            :Vuetify="false"
                                            @click="onExcelDown"
                                        />
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <p class="infoTxt">
                        <span class="color-red"
                            >양식 다운로드 버튼을 클릭하여 받으신 양식으로 입력
                            가능합니다.
                        </span>
                    </p>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader3"
                            ref="gridHeader3"
                            :gridObj="gridObj"
                            :isDelRow="true"
                            @chkDelRowBtn="gridchkDelRowBtn"
                            class="notit"
                        />
                        <TCRealGrid
                            id="gridField3"
                            ref="gridField3"
                            :fields="gridSet.fields"
                            :columns="gridSet.columns"
                            :styles="gridStyle"
                        />
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 콜백 서비스 아이디
 * 4 엑셀 업로드
 * 5 오류 검증 수정
 * 6 엑셀업로드
------------------------------------------------>
<script>
import { CommonGrid, FileUtil } from '@/utils'
import { GRID_HEADER } from '@/const/grid/dis/beq/disBeqLossRobberyProdMgmtXlsUpldHeader.js'
import getLossRobberyProdMgmtApi from '@/api/biz/dis/beq/disBeqLossRobberyProdMgmtXlsUpld.js'
import CommonMixin from '@/mixins'
// import moment from 'moment'
import _ from 'lodash'
import * as XLSX from 'xlsx'

import attachedFileApi from '@/api/common/attachedFile' // 엑셀 업로드양식 다운로드 관련

export default {
    name: 'DisInnAutoAsgnSetDlvDealcoMstMgmtRgst',
    mixins: [CommonMixin],
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        closeDemo: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            files: null,
            errChk: false,
            //
            objAuth: {},
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '400px',
            },
            gridSet: GRID_HEADER,
            reqParam: {
                orgCd: '',
                orgNm: '',
                dealCoCd: '',
                dealCoNm: '',
            },
            // 저장버튼 활성화여부
            saveBtnDisabled: true,
            // 오류일괄제거 활성화여부
            errClearDisabled: true,
        }
    },
    mounted() {
        this.initParam()
        this.setGrid()
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        /* 초기화 */
        init() {
            // this.initParam()
            this.setGrid()
            this.files = null
            this.errClearDisabled = true // 오류일괄제거
            this.saveBtnDisabled = true // 저장버튼
        },
        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                orgCd: '',
                orgNm: '',
                dealCoCd: '',
                dealCoNm: '',
            }
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.gridField3
            this.gridHeaderObj = this.$refs.gridHeader3
            this.gridObj.setGridState(false, false, true)
            this.gridObj.gridView.setRowIndicator({
                visible: true,
                headText: 'NO',
            })
            this.gridObj.setRows({})
        },
        gridSetData() {
            return new CommonGrid(-1, -1, 10, 0, '')
        },
        btnClick() {
            console.log('click')
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            this.gridObj.gridView.commit()
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
            this.deleleGridData = this.gridData.delRows
        },

        // 파일업로드
        onFilesChange(files) {
            // 엑셀 업로드 암호화문서 파싱 로직 추가 2023.01.03
            // this.excelUploadFile(files)
            const formData = new FormData()
            formData.append('files', files)
            getLossRobberyProdMgmtApi.parseXlsEncDoc(formData).then((res) => {
                this.gridObj.setRows(res)
            })

            this.errChk = false
            this.errClearDisabled = true // 오류일괄제거
            this.saveBtnDisabled = true // 저장버튼
        },
        excelUploadFile(files) {
            const f = files
            if (!_.isUndefined(f) && !_.isNull(f)) {
                const reader = new FileReader()
                // const name = f.name

                reader.onload = (e) => {
                    const data = e.target.result

                    // Array Buffer인 경우 base64로 변환 처리
                    const arr = FileUtil.arrayBufferFixdata(data)
                    const workbook = XLSX.read(FileUtil.encodeBase64(arr), {
                        type: 'base64',
                        cellText: true,
                        cellDates: true,
                    })
                    // 워크북 처리(1줄 헤더 포함 처리)
                    this.processWorkbook(workbook)
                }
                // binary
                // reader.readAsBinaryString(f)
                // Array Buffer
                reader.readAsArrayBuffer(f)
            }
        },
        // 워크북 처리(1줄 헤더 포함 처리)
        processWorkbook(wb) {
            const output = FileUtil.excelTojson(wb, {
                raw: false,
            })
            const sheetNames = Object.keys(output)
            if (sheetNames.length) {
                const colsObj = output[sheetNames][0]
                if (colsObj) {
                    const data = output[sheetNames]
                    if (data.length > 3000) {
                        this.showTcComAlert(
                            '1회당 업로드 데이터는 3000건까지 가능합니다.'
                        )
                        return
                    }
                    const mappedData = data.map((item) => {
                        return {
                            prchsDealcoNm: item['출고처'],
                            prchsDealcoCd: item['출고처코드'],
                            prodNm: item['유심모델'],
                            prodCd: item['유심모델코드'],
                            serNum: item['일련번호'],
                            riskStNm: item['Risk사유'],
                            riskStCd: item['Risk사유코드'],
                            inDealcoNm: item['이동창고'],
                            inDealcoCd: item['이동창고코드'],
                            rmks: item['비고'],
                        }
                    })
                    this.gridObj.dataProvider.fillJsonData(mappedData, {})
                }
            } else {
                this.showTcComAlert(
                    '업로드 문서에 처리 할 데이터가 없습니다.\n업로드 문서를 확인하시기 바랍니다.'
                )
            }
        },
        //오류검증
        errCheck() {
            const rowData = this.gridObj.dataProvider.getOutputRows(
                { datetimeFormat: 'yyyyMMdd' },
                0,
                -1
            )
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
                return
            }
            if (rowData.length > 3000) {
                this.showTcComAlert(
                    '1회당 업로드 데이터는 3000건까지 가능합니다.'
                )
                return
            }

            console.log('오류검증데이터 ==============>> ', rowData)
            getLossRobberyProdMgmtApi
                .chkLossRobberyUsimXlsErrChk(rowData)
                .then((res) => {
                    this.gridObj.setRows(res)
                    this.errChk = true
                    this.errClearDisabled = false // 오류일괄제거 버튼 활성화
                    this.saveBtnDisabled = false // 저장버튼 활성화
                })
        },
        //오류일괄변경
        errClear() {
            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
                return
            }
            if (_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
            } else {
                this.gridObj.dataProvider.removeRows(this.getErrRow())
                this.gridObj.gridView.commit()
            }
        },

        // 저장
        saveBtn() {
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('저장할 데이터가 없습니다.')
                return
            }
            if (!this.errChk) {
                this.showTcComAlert('오류검증을 하시기 바랍니다.')
                return
            }
            if (!_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('오류제거를 하시기 바랍니다.')
                return
            }
            this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    getLossRobberyProdMgmtApi
                        .addLossRobberyUsimXlsUpld(rowData)
                        .then(() => {
                            this.$emit('confirm', true)
                            this.activeOpen = false
                        })
                }
            })
        },
        //오류ROW 조회
        getErrRow() {
            let errRow = []
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            rowData.forEach((data, i) => {
                if (!_.isEmpty(_.get(data, 'errDesc'))) {
                    errRow.push(i)
                }
            })
            return errRow
        },
        //양식다운로드
        onExcelDown() {
            attachedFileApi.downloadSampleFile('111') // seq 정해지면 넣는다.
            // this.gridHeaderObj.exportSampleGrid(
            //     '사고기기유심_' +
            //         moment(new Date()).format('YYYYMMDDHHmmss') +
            //         '.xls'
            // )
        },
        /* 팝업 창닫기 */
        closeBtn() {
            this.activeOpen = false
        },
    },
}
</script>
