//import Const from "@/service/Const";
import { utils as xlsxUtils } from 'xlsx'
export default {
    hasMimeType(mimeTypes, file) {
        return mimeTypes.find((type) => {
            return type === file.raw.type
        })
    },
    hasFileExt(fileExts, file) {
        return fileExts.find((ext) => {
            return ext === file.name.substr(file.name.lastIndexOf('.') + 1)
        })
    },
    isMaxSize(maxSize, file) {
        return maxSize >= file.size
    },
    duplicateFiles(fileList, file) {
        return fileList.filter((e) => e.name === file.name).length > 0
    },
    isTotalMaxSize(totalMaxSize, fileList) {
        let fileSizes = fileList.map((e) => e.size)
        return totalMaxSize >= fileSizes.reduce((a, b) => a + b, 0)
    },
    fileValid(
        fileList,
        file,
        type = {
            maxSize: 1024 * 1024 * 30,
            totalMaxSize: 1024 * 1024 * 100,
            mimeTypes: null,
            fileExts: null,
        }
    ) {
        console.log('file.raw.type : ' + file.raw.type)
        let warnningMessage
        // 파일 타입 체크
        if (
            type.mimeTypes !== null &&
            !this.hasMimeType(type.mimeTypes, file)
        ) {
            warnningMessage =
                '파일(' +
                file.name +
                ')은 업로드 할 수 없는 유형[' +
                file.raw.type +
                ']의 파일입니다.<br/>확장자를 확인하세요. (업로드 가능: ' +
                type.fileExts.join(', ') +
                ')'
            // this.$alert(warnningMessage, this.$Const.M_WARN, {dangerouslyUseHTMLString: true})
            alert(warnningMessage)
            // fileList.pop()
            return false
        }
        // 파일 확장자 체크
        if (type.fileExts !== null && !this.hasFileExt(type.fileExts, file)) {
            warnningMessage =
                '파일(' +
                file.name +
                ')은 업로드 할 수 없는 유형[' +
                file.raw.type +
                ']의 파일입니다.<br/>확장자를 확인하세요. (업로드 가능: ' +
                type.fileExts.join(', ') +
                ')'
            // this.$alert(warnningMessage, this.$Const.M_WARN, {dangerouslyUseHTMLString: true})
            alert(warnningMessage)
            // fileList.pop()
            return false
        }

        // 파일 사이즈 체크
        if (!this.isMaxSize(type.maxSize, file)) {
            // this.$alert(this.$Const.M_FILE_UPL_MAX_SIZE) // '파일 업로드 용량은 30MB 입니다.'
            //        alert(Const.MSG_FILE_UPL_MAX_SIZE)
            // fileList.pop()
            return false
        }

        // 파일명 체크
        if (this.duplicateFiles(fileList, file)) {
            // this.$alert(this.$Const.M_FILE_UPL_EXIST) // '동일한 파일명이 존재합니다.'
            //        alert(Const.MSG_FILE_UPL_EXIST)
            // fileList.pop()
            return false
        }

        // 전체 파일 사이크 체크
        if (!this.isTotalMaxSize(type.totalMaxSize, fileList, file)) {
            // this.$alert(this.$Const.M_FILE_UPL_TOT_MAX_SIZE) // '전체 업로드 용량은 100MB 입니다.'
            //        alert(Const.MSG_FILE_UPL_TOT_MAX_SIZE)
            // fileList.pop()
            return false
        }
        return true
    },

    vFileValid(
        fileList,
        file,
        type = {
            maxSize: 1024 * 1024 * 30,
            totalMaxSize: 1024 * 1024 * 100,
            mimeTypes: null,
            fileExts: null,
        }
    ) {
        let res = {
            errCode: '',
            warnningMessage: '',
        }
        // 파일 타입 체크
        if (
            type.mimeTypes !== null &&
            !this.hasMimeType(type.mimeTypes, file)
        ) {
            res.errCode = 'mimeTypes'
            res.warnningMessage =
                '파일(' +
                file.name +
                ')은 업로드 할 수 없는 유형의 파일입니다.\n확장자를 확인하세요. (업로드 가능: ' +
                type.fileExts.join(', ') +
                ')'
            // this.$alert(warnningMessage, this.$Const.M_WARN, {dangerouslyUseHTMLString: true})ssage)
            // fileList.pop()
            return res
        }
        // 파일 확장자 체크
        if (type.fileExts !== null && !this.hasFileExt(type.fileExts, file)) {
            res.errCode = 'fileExts'
            res.warnningMessage =
                '파일(' +
                file.name +
                ')은 업로드 할 수 없는 유형의 파일입니다.\n확장자를 확인하세요. (업로드 가능: ' +
                type.fileExts.join(', ') +
                ')'
            // this.$alert(warnningMessage, this.$Const.M_WARN, {dangerouslyUseHTMLString: true})
            // alert(warnningMessage)
            // fileList.pop()
            return res
        }

        // 파일 사이즈 체크
        if (!this.isMaxSize(type.maxSize, file)) {
            // this.$alert(this.$Const.M_FILE_UPL_MAX_SIZE) // '파일 업로드 용량은 30MB 입니다.'
            //        alert(Const.MSG_FILE_UPL_MAX_SIZE)
            // fileList.pop()
            res.errCode = 'isMaxSize'
            res.warnningMessage =
                '파일(' +
                file.name +
                ')파일 업로드 용량은 ' +
                this.formatSize(file.size) +
                ' 입니다.'
            return res
        }

        // 파일명 체크
        if (this.duplicateFiles(fileList, file)) {
            // this.$alert(this.$Const.M_FILE_UPL_EXIST) // '동일한 파일명이 존재합니다.'
            //        alert(Const.MSG_FILE_UPL_EXIST)
            // fileList.pop()
            res.errCode = 'duplicateFiles'
            res.warnningMessage =
                '파일(' + file.name + ')파일 동일한 파일명이 존재합니다.'
            return res
        }

        // 전체 파일 사이크 체크
        if (!this.isTotalMaxSize(type.totalMaxSize, fileList, file)) {
            // this.$alert(this.$Const.M_FILE_UPL_TOT_MAX_SIZE) // '전체 업로드 용량은 100MB 입니다.'
            //        alert(Const.MSG_FILE_UPL_TOT_MAX_SIZE)
            // fileList.pop()
            res.errCode = 'isTotalMaxSize'
            res.warnningMessage =
                '전체파일 업로드 용량은 ' +
                this.formatSize(type.totalMaxSize) +
                ' 입니다.'
            return res
        }
        return true
    },
    formatSize(size) {
        if (size > 1024 * 1024 * 1024 * 1024) {
            return (size / 1024 / 1024 / 1024 / 1024).toFixed(2) + ' TB'
        } else if (size > 1024 * 1024 * 1024) {
            return (size / 1024 / 1024 / 1024).toFixed(2) + ' GB'
        } else if (size > 1024 * 1024) {
            return (size / 1024 / 1024).toFixed(2) + ' MB'
        } else if (size > 1024) {
            return (size / 1024).toFixed(2) + ' KB'
        }
        return size.toString() + ' B'
    },
    /** Excel Upload 관련 함수 start */
    // Array Buffer를 처리한다. ( 오직 readAsArrayBuffer 데이터만 가능하다 )
    arrayBufferFixdata(data) {
        let o = '',
            l = 0
        const w = 10240
        for (; l < data.byteLength / w; ++l) {
            o += String.fromCharCode(
                ...new Uint8Array(data.slice(l * w, l * w + w))
            )
        }
        o += String.fromCharCode(...new Uint8Array(data.slice(l * w)))
        return o
    },
    //workbook json으로 변환 처리
    excelTojson(workbook, option) {
        let result = {}
        workbook.SheetNames.forEach(function (sheetName) {
            const roa = xlsxUtils.sheet_to_row_object_array(
                workbook.Sheets[sheetName],
                { rawNumbers: true, ...option }
            )

            if (roa.length) {
                result[sheetName] = roa
            }
        })
        return result
    },
    encodeBase64(data) {
        // return Buffer.from(data).toString('base64')
        return btoa(data)
    },
    decodeBase64(data) {
        // return Buffer.from(data, 'base64').toString('ascii')
        return atob(data)
    },
    /** Excel Upload 관련 함수 end */
}
