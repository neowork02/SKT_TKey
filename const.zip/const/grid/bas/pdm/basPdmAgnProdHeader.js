/*****************************************
* 업무 그룹명 : 대리점별운영상품관리
* 서브 업무명 : 대리점별운영상품관리
* 설 명 : 상품목록 Grid 헤더 정보
* 작 성 자 : 김태훈
* 작 성 일 : 2022.09.29
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* ---------------------------------------
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const PROD_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'origin',
            fieldName: 'origin',
            header: {
                text: 'origin',
            },
            visible: false,
        },
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            header: {
                text: '모델명',
            },
            editable: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            header: {
                text: '모델코드',
            },
            editable: false,
            button: 'action',
            buttonVisibility: 'always',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            header: {
                text: '제조사명',
            },
            editable: false,
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            type: 'data',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '출시일자',
            },
            editable: false,
        },
        {
            name: 'eqpClNm',
            fieldName: 'eqpClNm',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분',
            },
            editable: false,
        },
    ],
}
