<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccSearchField.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <v-form ref="formSearch" class="formSearch">
        <component
            :is="buttonList"
            :formSearchQuery="formSearchQuery"
            :preventEvent="preventEvent"
            :statusDisableBtn="statusDisableBtn"
            :statusHiddenBtn="statusHiddenBtn"
        >
            <template v-for="(_, name) in $scopedSlots" :slot="name"
                ><slot :name="name" :formSearchQuery="formSearchQuery"
            /></template>
        </component>

        <component
            :is="searchFieldList"
            :divideCellCount="divideCellCount"
            :formSearchQuery="formSearchQuery"
            class="searchFieldList"
        >
            <template v-for="(_, name) in $scopedSlots" :slot="name"
                ><slot :name="name" :divideCellCount="divideCellCount"
            /></template>
        </component>

        <!-- 매입사팝업 -->
        <PopupCardCoCd
            v-if="showBcoCommCdDtl"
            :parentParam="popupParamCardCoCd"
            :rows="resultCommCdDtlRows"
            :dialogShow.sync="showBcoCommCdDtl"
            @confirm="onCommCdDtlReturnData"
        />

        <!-- 대리점 팝업 -->
        <PopupUkeyAgencyCd
            v-if="popupUkeyAgencyCd.status.show"
            :parentParam="popupParamUkeyAgencyCd"
            :dialogShow.sync="popupUkeyAgencyCd.status.show"
            :rows="popupUkeyAgencyCd.data"
            @confirm="confirmUkeyAgencyCd"
        />

        <PopupUkeyOrgCd
            v-if="popupUkeyOrgCd.status.show"
            :parentParam="popupParamUkeyOrgCd"
            :dialogShow.sync="popupUkeyOrgCd.status.show"
            :rows="popupUkeyOrgCd.data"
            @confirm="confirmUkeyOrgCd"
        />

        <!-- 내부조직팝업(권한) 팝업 -->
        <BasBcoAuthOrgTreesPopup
            v-if="showBcoAuthOrgTrees"
            :parentParam="popupParamOrgCd"
            :rows="resultAuthOrgTreeRows"
            :dialogShow.sync="showBcoAuthOrgTrees"
            @confirm="onAuthOrgTreeReturnData"
        />

        <!-- 입금처팝업 -->
        <PopupStlPlc
            v-if="popupStlPlc.status.show"
            :parentParam="popupParamDealcoCd"
            :rows="resultDealcoRows"
            :dialogShow.sync="showBasBcoDealcos"
            @confirm="onDealcoReturnData"
        />

        <!-- 거래처(권한) 팝업 -->
        <BasBcoDealcosPopup
            v-if="showBasBcoDealcos"
            :parentParam="popupParamDealcoCd"
            :rows="resultDealcoRows"
            :dialogShow.sync="showBasBcoDealcos"
            @confirm="onDealcoReturnData"
        />

        <AccFileLoader
            ref="accFileLoader"
            labelName="파일선택"
            isHidden
            @load="loadExcel"
        />

        <TCComAlert
            v-model="showAlertBool"
            :headerText="headerText"
            :bodyText="alertBodyText"
        ></TCComAlert>
    </v-form>
</template>

<style scoped>
.formSearch
    :deep(.searchFieldList)
    .searchform
    .formitem.formitem--patmentDtPayDt
    .typeSelect {
    width: 40%;
    float: left;
}

.formSearch
    :deep(.searchFieldList)
    .searchform
    .formitem.formitem--patmentDtPayDt
    .datePicker {
    width: 60%;
    float: left;
}

.formSearch
    :deep(.searchFieldList)
    .searchform
    .formitem.formitem--svcMgmtNum
    .itemtit {
    font-size: 14px;
    letter-spacing: -1px;
}
</style>
<script>
import _ from 'lodash'

import { mapGetters } from 'vuex'
import { CommonUtil } from '@/utils'
import CommonMixin from '@/mixins'

import { searchSelector, getCalcDays } from '@/utils/accUtil'

import AccFileLoader from '@/components/biz/common/acc/AccFileLoader'

import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
import basBcoTbasDealIfPopApi from '@/api/biz/bas/bco/basBcoTbasDealIfPop'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
import basBcoCommCdDtlApi from '@/api/biz/bas/bco/basBcoCommCdDtl'

import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup' // 내부조직팝업(권한)팝업

import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup' // 내부거래처(권한조직) 팝업
import BasBcoCommCdDtlPopup from '@/components/common/BasBcoCommCdDtlPopup' // 공통팝업
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup' // 대리점팝업
import BasBcoTbasDealIfPopup from '@/components/common/BasBcoTbasDealIfPopup' // 스윙대리점팝업

/**
 * 날짜에 포함된 특수문자 제거
 */
function replaceDateField(orgQuery) {
    const query = Object.assign({}, orgQuery)
    const dateField = [
        'accMth',
        'mskMonth',
        'baseMth',
        'clsMth',
        'clsDt',
        'accDt',
        'lastDayCls',
        'bondFromDt',
        'bondToDt',
        'expDueDt',
        'payEndDtm',
        'payStaDtm',
        'brwsTo',
        'brwsFr',
        'rfndDt',
        'dpstYymm',
        'aplyStaDt',
        'aplyEndDt',
        'searchDtmTo',
    ]

    dateField.forEach((fieldName) => {
        if (Object.prototype.hasOwnProperty.call(query, fieldName)) {
            if (!query[fieldName]) return
            query[fieldName] = query[fieldName].replace(/-|\./g, '')
        }
    })

    return query
}

/**
 * 내부 처리용으로 사용되는 속성 제거 (API 통신시에는 불필요한 속성들)
 */
function arrangeQuery(orgQuery) {
    let query = Object.assign({}, replaceDateField(orgQuery))
    const outsideField = ['bond', 'brws', 'patmentDtPayDt', 'aplyDt']

    outsideField.forEach((arr) => delete query[arr])

    return query

    // 값이 비어있는 내용 걸러내기
    // return Object.keys(query).reduce((acc, cur) => {
    //     if (query[cur]) acc[cur] = query[cur]
    //     return acc
    // }, {})
}

/**
 * 버튼템플릿 그룹
 */
const buttonTemplate = {
    sendErp: `
        <TCComButton
            v-if="!statusHiddenBtn.sendErp"
            :eOutlined="true"
            :disabled="statusDisableBtn.sendErp"
            eClass="btn_ty"
            @click="clickSendErp"
            >ERP전송</TCComButton
        >
    `,

    downloadForm: `
        <TCComButton
            v-if="!statusHiddenBtn.downloadForm"
            :eOutlined="true"
            :disabled="statusDisableBtn.downloadForm"
            eClass="btn_ty"
            @click="clickDownloadForm"
            >업로드양식 다운로드</TCComButton
        >
    `,

    excelUpload: `
        <TCComButton
            v-if="!statusHiddenBtn.excelUpload"
            :eOutlined="true"
            :disabled="statusDisableBtn.excelUpload"
            eClass="btn_ty"
            @click="clickExcelUpload"
            >엑셀업로드</TCComButton
        >
    `,

    noticeEtcSetting: `
        <TCComButton
            v-if="!statusHiddenBtn.noticeEtcSetting"
            :eOutlined="true"
            :disabled="statusDisableBtn.noticeEtcSetting"
            eClass="btn_ty"
            @click="clickNoticeEtcSetting"
            >공지사항및비고설정</TCComButton
        >
    `,

    closeThePeriod: `
        <TCComButton
            v-if="!statusHiddenBtn.closeThePeriod"
            :eOutlined="true"
            :disabled="statusDisableBtn.closeThePeriod"
            eClass="btn_ty"
            @click="clickCloseThePeriod"
            >마감</TCComButton
        >
    `,

    openThePeriod: `
        <TCComButton
            v-if="!statusHiddenBtn.openThePeriod"
            :eOutlined="true"
            :disabled="statusDisableBtn.openThePeriod"
            eClass="btn_ty"
            @click="clickOpenThePeriod"
            >마감취소</TCComButton
        >
    `,

    deleteUpload: `
        <TCComButton
            v-if="!statusHiddenBtn.deleteUpload"
            :eOutlined="true"
            :disabled="statusDisableBtn.deleteUpload"
            eClass="btn_ty"
            @click="clickDeleteUpload"
            >업로드삭제</TCComButton
        >
    `,

    confirm: `
        <TCComButton
            v-if="!statusHiddenBtn.confirm"
            :eOutlined="true"
            :disabled="statusDisableBtn.confirm"
            eClass="btn_ty"
            @click="clickConfirm"
            >확정</TCComButton
        >
    `,

    confirmCancel: `
        <TCComButton
            v-if="!statusHiddenBtn.confirmCancel"
            :eOutlined="true"
            :disabled="statusDisableBtn.confirmCancel"
            eClass="btn_ty"
            @click="clickConfirmCancel"
            >확정취소</TCComButton
        >
    `,

    forceConfirm: `
        <TCComButton
            v-if="!statusHiddenBtn.forceConfirm"
            :eOutlined="true"
            :disabled="statusDisableBtn.forceConfirm"
            eClass="btn_ty"
            @click="clickForceConfirm"
            >강제확정</TCComButton
        >
    `,

    reset: `
        <TCComButton
            v-if="!statusHiddenBtn.reset"
            eClass="btn_ty01"
            :disabled="statusDisableBtn.reset"
            @click="clickReset"
            >초기화</TCComButton
        >
    `,

    new: `
        <TCComButton
            v-if="!statusHiddenBtn.new"
            eClass="btn_ty01"
            :disabled="statusDisableBtn.new"
            @click="clickNew"
            >신규</TCComButton
        >
    `,

    list: `
        <TCComButton
            v-if="!statusHiddenBtn.list"
            eClass="btn_ty01"
            :disabled="statusDisableBtn.list"
            @click="clickList"
            >목록</TCComButton
        >
    `,

    view: `
        <TCComButton
            v-if="!statusHiddenBtn.view"
            eClass="btn_ty01"
            :disabled="statusDisableBtn.view"
            @click="clickView"
            >조회</TCComButton
        >
    `,

    delete: `
        <TCComButton
            v-if="!statusHiddenBtn.delete"
            eClass="btn_ty01"
            :disabled="statusDisableBtn.delete"
            @click="clickDelete"
            >삭제</TCComButton
        >
    `,

    save: `
        <TCComButton
            v-if="!statusHiddenBtn.save"
            eClass="btn_ty01"
            :disabled="statusDisableBtn.save"
            @click="clickSaveItem"
            >저장</TCComButton
        >
    `,

    check: `
        <TCComButton
            v-if="!statusHiddenBtn.check"
            eClass="btn_ty01"
            :disabled="statusDisableBtn.check"
            @click="clickCheck"
            >확인</TCComButton
        >
    `,

    forceAprove: `
        <TCComButton
            v-if="!statusHiddenBtn.forceAprove"
            eClass="btn_ty01"
            :disabled="statusDisableBtn.forceAprove"
            @click="clickForceAprove"
            >강제승인</TCComButton
        >
    `,

    close: `
        <TCComButton
            v-if="!statusHiddenBtn.close"
            eClass="btn_ty01"
            :disabled="statusDisableBtn.close"
            @click="clickClose"
            >닫기</TCComButton
        >
    `,

    closed: `
        <TCComButton
            v-if="!statusHiddenBtn.closed"
            eClass="btn_ty"
            :eOutlined="true"
            :disabled="statusDisableBtn.closed"
            @click="clickClosed"
            >마감</TCComButton
        >
    `,

    closedCancel: `
        <TCComButton
            v-if="!statusHiddenBtn.closedCancel"
            eClass="btn_ty"
            :disabled="statusDisableBtn.closedCancel"
            @click="clickClosedCancel"
            >마감취소</TCComButton
        >
    `,
}

/**
 * 검색템플릿 그룹
 */
const searchFieldTemplate = {
    accMth: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="정산월"
                calType="M"
                :eRequired="isComponentRequired('search-accMth')"
                :disabled="statusDisableSearch.accMth"
                v-model="formSearchQuery.accMth"
                @change="changeAccMth"
            />
        </div>
    `,

    mskMonth: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="정산월"
                calType="M"
                :eRequired="isComponentRequired('search-mskMonth')"
                :disabled="statusDisableSearch.mskMonth"
                v-model="formSearchQuery.mskMonth"
                @change="changeMskMonth"
            />
        </div>
    `,

    clsMth: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="마감월"
                calType="M"
                :eRequired="isComponentRequired('search-clsMth')"
                :disabled="statusDisableSearch.clsMth"
                v-model="formSearchQuery.clsMth"
                @change="changeClsmth"
            />
        </div>
    `,

    clsDt: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="마감일"
                calType="D"
                :eRequired="isComponentRequired('search-clsDt')"
                :disabled="statusDisableSearch.clsDt"
                v-model="formSearchQuery.clsDt"

                @change="changeClsDt"
            />
        </div>
    `,

    accDt: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="기준월"
                calType="M"
                :eRequired="isComponentRequired('search-accDt')"
                :disabled="statusDisableSearch.accDt"
                v-model="formSearchQuery.accDt"
                @change="changeAccDt"
            />
        </div>
    `,

    searchDtmTo: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="기준일"
                calType="D"
                :eRequired="isComponentRequired('search-searchDtmTo')"
                :disabled="statusDisableSearch.searchDtmTo"
                v-model="formSearchQuery.searchDtmTo"

                @change="changeSearchDtmTo"
            />
        </div>
    `,

    lastDayCls: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="최종마감일"
                calType="D"
                :eRequired="isComponentRequired('search-lastDayCls')"
                :disabled="statusDisableSearch.lastDayCls"
                v-model="formSearchQuery.lastDayCls"
                @change="changeLastDayCls"
            />
        </div>
    `,

    dpstYymm: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="입금월"
                calType="M"
                :eRequired="isComponentRequired('search-dpstYymm')"
                :disabled="statusDisableSearch.dpstYymm"
                v-model="formSearchQuery.dpstYymm"
                @change="changeDpstYymm"
            />
        </div>
    `,

    'patmentDt-payDt': `
        <div
            class="formitem div2 formitem--patmentDtPayDt"
        >
            <TCComComboBox
                labelName="조회일자"
                itemText="label"
                itemValue="value"
                :eRequired="
                    isComponentRequired('search-patmentDt-payDt')
                "
                :disabled="statusDisableSearch.patmentDtPayDtSel"
                :itemList="searchSelector.patmentDtPayDt"
                v-model="formSearchQuery.patmentDtPayDtSel"
                class="typeSelect"
                @change="changePatmentDtPayDtSel"
            />
            <TCComDatePicker
                calType="DP"
                class="datePicker"
                :disabled="statusDisableSearch.patmentDtPayDt"
                v-model="formSearchQuery.patmentDtPayDt"
                @change="changePatmentDtPayDt"
            />
        </div>
    `,

    brws: `
        <div
            class="formitem formitem--brws"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="일자"
                :eRequired="
                    isComponentRequired('search-brws')
                "
                :disabled="statusDisableSearch.brws"
                v-model="formSearchQuery.brws"
                calType="DP"
                class="datePicker"
                @change="changeBrws"
            />
        </div>
    `,

    baseMth: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="조회월"
                calType="M"
                :eRequired="isComponentRequired('search-baseMth')"
                :disabled="statusDisableSearch.baseMth"
                v-model="formSearchQuery.baseMth"
                @change="changeBaseMth"
            />
        </div>
    `,

    aplyDt: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="조회일자"
                v-model="formSearchQuery.aplyDt"
                :eRequired="isComponentRequired('search-aplyDt')"
                :disabled="statusDisableSearch.aplyDt"
                calType="DP"
                class="datePicker"
                @change="changeAplyDt"
            />
        </div>
    `,

    orgCd: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInputSearchText
                labelName="조직"
                placeholder="입력해주세요"
                :eRequired="isComponentRequired('search-orgCd')"
                :disabled="statusDisableSearch.orgCd"
                :disabledAfter="true"
                v-model="formSearchQuery.orgNm"
                :codeVal.sync="formSearchQuery.orgCd"
                @enterKey="onAuthOrgTreeEnterKey"
                @appendIconClick="onAuthOrgTreeIconClick"
                @input="onAuthOrgTreeInput"
            />
        </div>
    `,

    payTypCd: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComComboBox
                codeId="ZACC_C_00460"
                labelName="유형"
                v-model="formSearchQuery.payTypCd"
                :eRequired="isComponentRequired('search-payTypCd')"
                :disabled="statusDisableSearch.payTypCd"
                :addBlankItem="true"
                blankItemText="전체"
                blankItemValue="0"
            />
        </div>
    `,

    stlPlc: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInputSearchText
                labelName="입금처"
                placeholder="입력해주세요"
                :disabledAfter="true"
                :eRequired="isComponentRequired('search-stlPlc')"
                :disabled="statusDisableSearch.stlPlc"
                v-model="formSearchQuery.dealNm"
                :codeVal.sync="formSearchQuery.stlPlc"
                @enterKey="onDealcoEnterKey"
                @appendIconClick="onDealcoIconClick"
                @input="onDealcoInput"
            />
        </div>
    `,

    dealcoCd: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInputSearchText
                labelName="거래처"
                placeholder="입력해주세요"
                :disabledAfter="true"
                :eRequired="isComponentRequired('search-dealcoCd')"
                :disabled="statusDisableSearch.dealcoCd"
                v-model="formSearchQuery.dealcoNm"
                :codeVal.sync="formSearchQuery.dealcoCd"
                @enterKey="onDealcoEnterKey"
                @appendIconClick="onDealcoIconClick"
                @input="onDealcoInput"
            />
        </div>
    `,

    accDealcoCd: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInputSearchText
                labelName="정산처"
                placeholder="입력해주세요"
                :disabledAfter="true"
                :eRequired="isComponentRequired('search-accDealcoCd')"
                :disabled="statusDisableSearch.accDealcoCd"
                :searchIconDisabled="statusDisableSearch.searchIcon"
                v-model="formSearchQuery.accDealcoNm"
                :codeVal.sync="formSearchQuery.accDealcoCd"
                @enterKey="onDealcoEnterKey"
                @appendIconClick="onDealcoIconClick"
                @input="onDealcoInput"
            />
        </div>
    `,

    rfndDealCo: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInputSearchText
                labelName="환불처"
                placeholder="입력해주세요"
                :disabledAfter="true"
                :eRequired="isComponentRequired('search-rfndDealCo')"
                :disabled="statusDisableSearch.rfndDealCo"
                v-model="formSearchQuery.rfndDealCoNm"
                :codeVal.sync="formSearchQuery.rfndDealCo"
                @enterKey="onDealcoEnterKey"
                @appendIconClick="onDealcoIconClick"
                @input="onDealcoInput"
            />
        </div>
    `,

    accPlc: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInput
                labelName="정산처"
                :eRequired="isComponentRequired('search-accPlc')"
                :disabled="statusDisableSearch.accPlc"
                v-model="formSearchQuery.accPlc"
            />
        </div>
    `,

    cardCoCd: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInputSearchText
                labelName="매입사"
                placeholder="입력해주세요"
                :disabledAfter="true"
                :eRequired="isComponentRequired('search-cardCoCd')"
                :disabled="statusDisableSearch.cardCoCd"
                v-model="formSearchQuery.cardCoNm"
                :codeVal.sync="formSearchQuery.cardCoCd"
                :objAuth="objAuth"
                @enterKey="onCommCdDtlEnterKey"
                @appendIconClick="onCommCdDtlIconClick"
                @input="onCommCdDtlInput"
            />
        </div>
    `,

    bondClCd: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComComboBox
                itemText="label"
                itemValue="value"
                labelName="채권상계기간 설정"
                labelClass="line2"
                :eRequired="isComponentRequired('search-bondClCd')"
                :disabled="statusDisableSearch.bondClCd"
                :itemList="searchSelector.bondClCd"
                :objAuth="objAuth"
                v-model="formSearchQuery.bondClCd"
                @change="changeBondClCd"
            />
        </div>
    `,

    bond: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="조회일자"
                v-model="formSearchQuery.bond"
                calType="DP"
                @change="changeBond"
            />
        </div>
    `,

    expDueDt: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="지출예정일"
                :eRequired="isComponentRequired('search-expDueDt')"
                :disabled="statusDisableSearch.expDueDt"
                calType="D"
                v-model="formSearchQuery.expDueDt"
            />
        </div>
    `,

    verifyYn: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComComboBox
                itemText="label"
                itemValue="value"
                labelName="검증상태"
                :eRequired="isComponentRequired('search-verifyYn')"
                :disabled="statusDisableSearch.verifyYn"
                :itemList="searchSelector.verifyYn"
                :objAuth="objAuth"
                v-model="formSearchQuery.verifyYn"
            />
        </div>
    `,

    expObjYn: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComComboBox
                itemText="label"
                itemValue="value"
                labelName="지출대상여부"
                :eRequired="isComponentRequired('search-expObjYn')"
                :disabled="statusDisableSearch.expObjYn"
                :itemList="searchSelector.expObjYn"
                :objAuth="objAuth"
                v-model="formSearchQuery.expObjYn"
            />
        </div>
    `,

    saleMgmtNo: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInput
                labelName="수납관리번호"
                :eRequired="isComponentRequired('search-saleMgmtNo')"
                :disabled="statusDisableSearch.saleMgmtNo"
                v-model="formSearchQuery.saleMgmtNo"
            />
        </div>
    `,

    aprvNum: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInput
                labelName="승인번호"
                :eRequired="isComponentRequired('search-aprvNum')"
                :disabled="statusDisableSearch.aprvNum"
                v-model="formSearchQuery.aprvNum"
            />
        </div>
    `,

    rfndDt: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComDatePicker
                labelName="환불월"
                :eRequired="isComponentRequired('search-rfndDt')"
                :disabled="statusDisableSearch.rfndDt"
                calType="M"
                v-model="formSearchQuery.rfndDt"
                @change="changeRfndDt"
            />
        </div>
    `,

    // rfndCl: `
    //     <div
    //         class="formitem"
    //         :class="'div' + divideCellCount"
    //     >
    //         <TCComComboBox
    //             itemText="label"
    //             itemValue="value"
    //             labelName="환불구분"
    //             :eRequired="isComponentRequired('search-rfndCl')"
    //             :disabled="statusDisableSearch.rfndCl"
    //             :itemList="searchSelector.rfndCl"
    //             :objAuth="objAuth"
    //             v-model="formSearchQuery.rfndCl"
    //             @change="changeRfndCl"
    //         />
    //     </div>
    // `,

    rfndCl: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInput
                labelName="환불구분"
                :eRequired="isComponentRequired('search-rfndCl')"
                :disabled="statusDisableSearch.rfndCl"
                value="환불"
            />
            <input type="hidden" v-model="formSearchQuery.rfndCl" />
        </div>
    `,

    // dpstCl: `
    //     <div
    //         class="formitem"
    //         :class="'div' + divideCellCount"
    //     >
    //         <TCComComboBox
    //             itemText="label"
    //             itemValue="value"
    //             labelName="환불구분"
    //             :eRequired="isComponentRequired('search-dpstCl')"
    //             :disabled="statusDisableSearch.dpstCl"
    //             :itemList="searchSelector.rfndCl"
    //             :objAuth="objAuth"
    //             v-model="formSearchQuery.dpstCl"
    //             @change="changeDpstCl"
    //         />
    //     </div>
    // `,

    dpstCl: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInput
                labelName="환불구분"
                :eRequired="isComponentRequired('search-dpstCl')"
                :disabled="statusDisableSearch.dpstCl"
                value="환불"
            />
            <input type="hidden" v-model="formSearchQuery.dpstCl" />
        </div>
    `,

    ukeyAgencyCd: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInputSearchText
                labelName="대리점"
                placeholder="입력해주세요"
                :disabledAfter="true"
                :objAuth="objAuth"
                :eRequired="isComponentRequired('search-ukeyAgencyCd')"
                :disabled="statusDisableSearch.ukeyAgencyCd"
                v-model="formSearchQuery.ukeyAgencyNm"
                :codeVal.sync="formSearchQuery.ukeyAgencyCd"
                @appendIconClick="clickUkeyAgencyCd"
                @enterKey="keyEnterUkeyAgencyCd"
                @input="inputUkeyAgencyCd"
            />

        </div>
    `,

    ukeyOrgCd: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInputSearchText
                labelName="대리점"
                :disabledAfter="true"
                :objAuth="objAuth"
                :eRequired="isComponentRequired('search-ukeyOrgCd')"
                :disabled="statusDisableSearch.ukeyOrgCd"
                v-model="formSearchQuery.ukeyOrgNm"
                :codeVal.sync="formSearchQuery.ukeyOrgCd"
                @appendIconClick="clickUkeyUkeyOrgCd"
                @enterKey="keyEnterUkeyOrgCd"
                @input="inputUkeyOrgCd"
            />
        </div>
    `,

    accumuCl: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >

            <TCComRadioBox
                itemText="label"
                itemValue="value"
                labelName="누적"
                :eRequired="isComponentRequired('search-accumuCl')"
                :disabled="statusDisableSearch.accumuCl"
                :itemList="searchSelector.accumuCl"
                :objAuth="objAuth"
                v-model="formSearchQuery.accumuCl"
                @change="changeAccumuCl"
            />

        </div>
    `,

    dealStatus: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComMultiComboBox
                v-model="formSearchQuery.dealStatus"
                labelName="거래상태"
                codeId="ZBAS_C_00120"
                :objAuth="objAuth"
            ></TCComMultiComboBox>
        </div>
    `,

    svcMgmtNum: `
        <div
            class="formitem formitem--svcMgmtNum"
            :class="'div' + divideCellCount"
        >
            <TCComInput
                labelName="서비스관리번호"
                :eRequired="isComponentRequired('search-svcMgmtNum')"
                :disabled="statusDisableSearch.svcMgmtNum"
                v-model="formSearchQuery.svcMgmtNum"
            />
        </div>
    `,

    salePlc: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInput
                labelName="판매처"
                :eRequired="isComponentRequired('search-salePlc')"
                :disabled="statusDisableSearch.salePlc"
                v-model="formSearchQuery.salePlc"
            />
        </div>
    `,

    saleChrgrNm: `
        <div
            class="formitem"
            :class="'div' + divideCellCount"
        >
            <TCComInput
                labelName="영업담당자"
                :eRequired="isComponentRequired('search-saleChrgrNm')"
                :disabled="statusDisableSearch.saleChrgrNm"
                v-model="formSearchQuery.saleChrgrNm"
            />
        </div>
    `,
}

export default {
    name: 'AccSearchField',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
        PopupCardCoCd: BasBcoCommCdDtlPopup,
        PopupStlPlc: BasBcoDealcosPopup,
        PopupUkeyAgencyCd: BasBcoAgencysPopup,
        PopupUkeyOrgCd: BasBcoTbasDealIfPopup,
        AccFileLoader,
    },

    provide() {
        return this.shareResource
    },

    props: {
        /**
         * 진입 시 초기값
         */
        initValue: {
            default: () => ({}),
        },

        /**
         * 한줄에 표현되는 검색필드 개수
         */
        divideCellCount: {
            default: 4,
        },

        /**
         * 화면에 표시할 항목
         * @description
         *    btn-left-{buttonTemplate[property]} 왼쪽에 배치될 버튼
         *    { slotButtonLeft: {slotName} 제공되는 버튼 외에 왼쪽에 배치할 버튼이 필요한 경우, slot 을 지정
         *
         *    btn-right-{buttonTemplate[property]} 오른쪽에 배치될 버튼
         *    { slotButtonRight: {slotName} 제공되는 버튼 외에 왼쪽에 배치할 버튼이 필요한 경우, slot 을 지정
         *
         *    search-{searchFieldTemplate[property]} (필수값) 검색항목에 배치될 항목
         *    !search-{searchFieldTemplate[property]} (필수값x) 검색항목에 배치될 항목
         *    { slotSearch: {slotName} } 제공되는 검색항목 외에 처리가 필요한 경우 slot, 을 지정
         */
        offset: {
            default: () => [],
        },

        /**
         * 컴포넌트에서 기본으로 실행하는 동작 방어
         */
        preventEvent: {
            default: () => [],
        },

        /**
         * 검색필드영역 disable 상태값
         */
        statusDisableSearch: {
            default: () => ({
                rfndCl: false,
            }),
        },

        /**
         * 버튼영역 disable 상태값
         */
        statusDisableBtn: {
            default: () => ({}),
        },

        /**
         * 버튼영역 hidden 상태값
         */
        statusHiddenBtn: {
            default: () => ({}),
        },

        /**
         * 조직팝업 전달 파라미터
         */
        popupParamOrgCd: {
            default: () => ({
                basMth: '', // 기준년월
                orgCd: '',
                orgNm: '', // 내부조직팝업(권한)명
                vLevel: '', // 디스플레이제한레벨
                sLvlList: '', //선택가능레벨 '2,3' : as-is 와동일하게 쉼표로 나열
                all: 'Y', //전체검색여부 Y or null , N..
            }),
        },

        /**
         * 거래처팝업 전달 파라미터
         */
        popupParamDealcoCd: {
            default: () => ({
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: '', //거래처그룹코드
                dealcoClCd1: '', //거래처구분코드
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            }),
        },

        /**
         * 매입사팝업 전달 파라미터
         */
        popupParamCardCoCd: {
            default: () => ({
                commCdId: '', // 공통상세팝업코드 변경가능
                commCdVal: '',
                commCdValNm: '',
            }),
        },

        /**
         * 대리점팝업 전달 파라미터
         */
        popupParamUkeyAgencyCd: {
            default: () => ({
                agencyTypCd: '1', // 대리점유형
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            }),
        },

        /**
         * 스윙대리점팝업 전달 파라미터
         */
        popupParamUkeyOrgCd: {
            default: () => ({
                sktOrgClCd: '06', // 조직구분
                sktOrgCd: '', // 대리점코드
                orgNm: '', // 조직명
                sktSubCdNm: '', // 서브점코드
            }),
        },
    },

    data() {
        return {
            searchSelector,
            buttonList: null,
            searchFieldList: null,

            objAuth: {},
            formSearchQuery: {},

            popupCardCoCd: {
                status: {
                    show: false,
                },
                query: [],
            },

            popupStlPlc: {
                status: {
                    show: false,
                },
                query: [],
            },

            popupUkeyAgencyCd: {
                status: {
                    show: false,
                },
                query: {},
                data: [],
            },

            popupUkeyOrgCd: {
                status: {
                    show: false,
                },
                query: {},
                data: [],
            },

            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================

            //====================내부거래처-권한조직====================
            showBasBcoDealcos: false,
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================

            //====================공통상세팝업관련====================
            showBcoCommCdDtl: false, // 공통상세팝업 팝업 오픈 여부
            resultCommCdDtlRows: [], // 공통상세팝업 팝업 오픈 여부
            //====================//공통상세팝업관련==================

            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
        }
    },

    computed: {
        /**
         * 자식 컴포넌트에 공유할 데이터
         */
        shareResource() {
            const share = Object.keys(this).reduce((acc, arr) => {
                if (
                    !arr.match(
                        /(^\$.+?$|^_.+?$|^formSearchQuery$|^divideCellCount$)/g
                    )
                )
                    acc[arr] = this[arr]
                return acc
            }, {})

            share.statusDisableSearch = this.statusDisableSearch

            return share
        },

        ...mapGetters('login', ['userInfo', 'orgInfo', 'authInfo']),
    },

    watch: {
        formSearchQuery: {
            immediate: false,
            deep: true,
            handler(val) {
                this.$emit('onChanged', val)
            },
        },

        offset: {
            immediate: true,
            deep: true,
            handler(val, oldval) {
                if (JSON.stringify(val) === JSON.stringify(oldval)) return
                this.generateButtonList()
                this.generateSearchFieldList()
            },
        },
    },
    created() {
        this.initSearchQuery()
    },
    mounted() {},
    methods: {
        /**
         * 버튼목록 생성
         */
        generateButtonList() {
            const component = {
                template: `<ul class="btn_area top">`,
                left: `<li class="left">`,
                right: `<li class="right">`,
            }

            this.offset.forEach((arr) => {
                if (typeof arr == 'string') {
                    if (arr.match(/btn-left-/g)) {
                        component.left +=
                            buttonTemplate[arr.replace('btn-left-', '')]
                    }

                    if (arr.match(/btn-right-/g)) {
                        component.right +=
                            buttonTemplate[arr.replace('btn-right-', '')]
                    }
                } else {
                    if (arr.slotButtonLeft) {
                        component.left += `<slot name="${arr.slotButtonLeft}"></slot>`
                    }

                    if (arr.slotButtonRight) {
                        component.right += `<slot name="${arr.slotButtonRight}"></slot>`
                    }
                }
            })

            component.left += `</li>`
            component.right += `</li>`

            component.template += component.left + component.right + `</ul>`
            component.props = [
                'formSearchQuery',
                'preventEvent',
                'statusDisableBtn',
                'statusHiddenBtn',
            ]
            component.inject = Object.keys(this.shareResource)
            this.buttonList = component
        },

        /**
         * 검색목록 생성
         */
        generateSearchFieldList() {
            const component = {
                template: `<div class="searchLayer_wrap"><div class="searchform">`,
            }

            this.offset.forEach((arr) => {
                if (typeof arr == 'string') {
                    if (arr.match(/search-/g)) {
                        component.template +=
                            searchFieldTemplate[
                                arr.replace('!', '').replace('search-', '')
                            ]
                    }
                } else {
                    if (arr.slotSearch) {
                        component.template += `<slot name="${arr.slotSearch}"></slot>`
                    }
                }
            })

            component.template += `</div></div>`
            component.props = ['formSearchQuery', 'divideCellCount']
            component.inject = Object.keys(this.shareResource)

            this.searchFieldList = component
        },

        /**
         * 기본값 설정
         */
        initSearchQuery() {
            const searchCoClOrgCd = this.orgInfo.orgCdLvl0
            const initQuery = Object.assign(
                {
                    searchCoClOrgCd: searchCoClOrgCd,
                },
                this.initValue
            )
            this.formSearchQuery = initQuery

            // CommonUtil.clearPage 대응
            const orgQuery = Object.assign(this.$options.data(), {
                formSearchQuery: Object.assign({}, this.formSearchQuery),
            })

            this.$options.data = () => orgQuery
        },

        /**
         * 초기화 기본값 변경
         */
        refreshSearchQuery() {
            this.initSearchQuery()
        },

        /**
         * 화면에 표현되는 항목의 필수값 여부
         * @param {string} name - 속성 이름
         * @description
         *    필수값이면 true
         */
        isComponentRequired(name) {
            return !this.offset.includes('!' + name)
        },

        /**
         * 현재 쿼리값 얻기
         */
        getQuery() {
            return arrangeQuery(replaceDateField(this.formSearchQuery))
        },

        /**
         * 쿼리값 주입
         * @param {object} query - 주입될 속성객체
         */
        setQuery(query) {
            const merged = Object.assign({}, this.formSearchQuery, query)
            this.$set(this, 'formSearchQuery', merged)
        },

        /**
         * 사용중인 필드명 얻기
         */
        getFieldName() {
            const fields = []
            this.offset.forEach((arr) => {
                if (typeof arr == 'string') {
                    if (arr.match(/search-/g)) {
                        fields.push(arr.replace('!', '').replace('search-', ''))
                    }
                } else {
                    if (arr.slotSearch) {
                        fields.push(arr.slotSearch)
                    }
                }
            })

            return fields
        },

        /**
         * 팝업 활성 상태 변경
         * @param {string} name - 활성 팝업 이름
         */
        openPopup(name) {
            this[name].status.show = true
        },

        /**
         * 엑셀 파일 로드 후 콜백
         * @param {string} xlsData - 로딩된 데이터
         * @description
         *    input[type=file] 에 의한 파일 선택 후 호출되는 콜백으로 사용됨
         */
        loadExcel(xlsData) {
            this.$emit('excelUpload', xlsData)
        },

        /**
         * 초기화 버튼 클릭 시
         */
        clickReset() {
            const exception = ['searchCoClOrgCd']

            CommonUtil.clearPage(this, 'formSearchQuery')

            Object.keys(this.formSearchQuery).forEach((arr) => {
                if (!this.initValue[arr] && !exception.includes(arr)) {
                    this.formSearchQuery[arr] = ''
                }
            })

            this.$emit('reset', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 조회 버튼 클릭 시
         */
        clickView() {
            const query = arrangeQuery({ ...this.formSearchQuery })
            query.pageNum = 1 // 조회 시 1page 로 세팅

            this.$emit('view', query)
        },

        /**
         * 저장 버튼 클릭 시
         */
        clickSaveItem() {
            this.$emit('save', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 버튼 클릭 시
         */
        clickDelete() {
            this.$emit('delete', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 확정 버튼 클릭 시
         */
        clickConfirm() {
            this.$emit('confirm', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 확정취소 버튼 클릭 시
         */
        clickConfirmCancel() {
            this.$emit('confirmCancel', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 강제확정 버튼 클릭 시
         */
        clickForceConfirm() {
            this.$emit('forceConfirm', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 업로드양식 다운로드 버튼 클릭 시
         */
        clickDownloadForm() {
            this.$emit('downloadForm', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 엑셀업로드 버튼 클릭 시
         */
        clickExcelUpload() {
            if (this.preventEvent.includes('clickExcelUpload')) {
                this.$emit('excelUpload', null)
            } else {
                this.$refs.accFileLoader.openSelector('excel')
            }
        },

        /**
         * 삭제 버튼 클릭 시
         */
        clickForceAprove() {
            this.$emit('forceAprove', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 신규 버튼 클릭 시
         */
        clickNew() {
            this.$emit('new', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 목록 버튼 클릭 시
         */
        clickList() {
            this.$emit('list', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 확인 버튼 클릭 시
         */
        clickCheck() {
            this.$emit('check', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 닫기 버튼 클릭 시
         */
        clickClose() {
            this.$emit('close', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 마감 버튼 클릭 시
         */
        clickClosed() {
            this.$emit('closed', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 마감취소 버튼 클릭 시
         */
        clickClosedCancel() {
            this.$emit('closedCancel', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 공지사항및비고설정 버튼 클릭 시
         */
        clickNoticeEtcSetting() {
            this.$emit('noticeEtcSetting', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 마감 버튼 클릭 시
         */
        clickCloseThePeriod() {
            this.$emit('closeThePeriod', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 마감취소 버튼 클릭 시
         */
        clickOpenThePeriod() {
            this.$emit('openThePeriod', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 업로드삭제 버튼 클릭 시
         */
        clickDeleteUpload() {
            this.$emit('deleteUpload', arrangeQuery(this.formSearchQuery))
        },

        /**
         * ERP전송 버튼 클릭 시
         */
        clickSendErp() {
            this.$emit('sendErp', arrangeQuery(this.formSearchQuery))
        },

        /**
         * 정산월 날짜변경 시
         */
        changeAccMth(date) {
            this.$emit('changeAccMth', date.replace(/-/g, ''))
        },

        /**
         * 다른 정산월 날짜변경 시
         */
        changeMskMonth(date) {
            this.formSearchQuery.accMth = date.replace(/-/g, '')

            this.$emit('changeMskMonth', date.replace(/-/g, ''))
        },

        /**
         * 마감월 날짜변경 시
         */
        changeClsmth(date) {
            this.$emit('changeClsmth', date.replace(/-/g, ''))
        },

        /**
         * 마감일 날짜변경 시
         */
        changeClsDt(date) {
            this.$emit('changeClsDt', date.replace(/-/g, ''))
        },

        /**
         * 기준월 날짜변경 시
         */
        changeAccDt(date) {
            this.$emit('changeAccDt', date.replace(/-/g, ''))
        },

        /**
         * 기준일 날짜변경 시
         */
        changeSearchDtmTo(date) {
            this.$emit('changeSearchDtmTo', date.replace(/-/g, ''))
        },

        /**
         * 최종마감일 날짜변경 시
         */
        changeLastDayCls(date) {
            this.$emit('changeLastDayCls', date.replace(/-/g, ''))
        },

        /**
         * 조회월 날짜변경 시
         */
        changeBaseMth(date) {
            this.$emit('changeBaseMth', date.replace(/-/g, ''))
        },

        /**
         * 일자 날짜변경 시
         */
        changeBrws(date) {
            this.formSearchQuery.brwsFr = date[0]
            this.formSearchQuery.brwsTo = date[1]

            this.$emit(
                'changeBrws',
                date.map((d) => d.replace(/-/g, ''))
            )
        },

        /**
         * 조회일자 날짜변경 시
         */
        changeAplyDt(date) {
            this.formSearchQuery.aplyStaDt = date[0]
            this.formSearchQuery.aplyEndDt = date[1]

            this.$emit(
                'changeAplyDt',
                date.map((d) => d.replace(/-/g, ''))
            )
        },

        /**
         * 채권상계기간설정 타입 변경 시
         */
        changeBondClCd(value) {
            this.$emit('changeBondClCd', value)
        },

        /**
         * 채권상계기간설정 날짜변경 시
         */
        changeBond(date) {
            this.formSearchQuery.bondToDt = date[0]
            this.formSearchQuery.bondFromDt = date[1]

            this.$emit(
                'changeBond',
                date.map((d) => d.replace(/-/g, ''))
            )
        },

        /**
         * 조회일자 타입변경 시
         */
        changePatmentDtPayDtSel(value) {
            this.$emit('changePatmentDtPayDtSel', value)
        },

        /**
         * 조회일자 날짜변경 시
         */
        changePatmentDtPayDt(date) {
            this.formSearchQuery.payStaDtm = date[0]
            this.formSearchQuery.payEndDtm = date[1]

            this.$emit(
                'changePatmentDtPayDt',
                date.map((d) => d.replace(/-/g, ''))
            )
        },

        /**
         * 환불월 날짜변경 시
         */
        changeRfndDt(date) {
            this.$emit('changeRfndDt', date.replace(/-/g, ''))
        },

        /**
         * 입금월 날짜변경 시
         */
        changeDpstYymm(date) {
            this.$emit('changeDpstYymm', date.replace(/-/g, ''))
        },

        /**
         * 환불구분 날짜변경 시
         */
        changeRfndCl(val) {
            this.$emit('changeRfndCl', val)
        },

        /**
         * 환불구분 날짜변경 시
         */
        changeDpstCl(val) {
            this.$emit('changeDpstCl', val)
        },

        /**
         * 누적 날짜변경 시
         */
        changeAccumuCl(query) {
            this.$emit('changeAccumuCl', query)
        },

        /**
         * 입금처 팝업 선택 후
         */
        confirmStlPlc(query) {
            const { dealcoCd, dealcoNm } = query

            this.formSearchQuery.stlPlc = dealcoCd
            this.formSearchQuery.dealNm = dealcoNm

            this.$emit('changeStlPlc', query)
        },

        clickUkeyAgencyCd() {
            this.popupUkeyAgencyCd.data = []

            if (this.formSearchQuery.agencyNm) {
                this.getAgencyList().then(
                    () => (this.popupUkeyAgencyCd.status.show = true)
                )
            } else {
                this.popupUkeyAgencyCd.status.show = true
            }
        },

        keyEnterUkeyAgencyCd() {
            if (!this.formSearchQuery.agencyNm) {
                return this.showTcComAlert('대리점명을 입력해주세요')
            } else {
                this.clickUkeyAgencyCd()
            }
        },

        inputUkeyAgencyCd(val) {
            this.formSearchQuery.agencyCd = ''
            this.popupParamUkeyAgencyCd.agencyCd = ''

            this.popupParamUkeyAgencyCd.agencyNm = val
        },

        confirmUkeyAgencyCd(query) {
            // agencyCd: "T15144"
            // agencyNm: "테스트대리점1"
            // agencyClCd: "D"
            // agencyTypCd: "1"
            // aplyEndDt: "99991231"
            // aplyStaDt: "20220506"
            // operDealcoNm: null

            const { agencyCd, agencyNm } = query

            this.formSearchQuery.ukeyAgencyCd = agencyCd
            this.formSearchQuery.ukeyAgencyNm = agencyNm

            this.$emit('changeUkeyAgencyCd', query)
        },

        getAgencyList() {
            return basBcoAgencysApi
                .getAgencyList(this.popupParamUkeyAgencyCd)
                .then((res) => {
                    if (res) {
                        if (res.length === 1) {
                            this.popupParamUkeyAgencyCd.agencyCd =
                                res[0].agencyCd
                            this.popupParamUkeyAgencyCd.agencyNm =
                                res[0].agencyNm
                        } else {
                            this.popupUkeyAgencyCd.data = res
                        }
                    }

                    return res
                })
        },

        clickUkeyUkeyOrgCd() {
            this.popupUkeyOrgCd.data = []

            if (this.formSearchQuery.ukeyOrgNm) {
                this.getSwingDealIfPop().then(
                    () => (this.popupUkeyOrgCd.status.show = true)
                )
            } else {
                this.popupUkeyOrgCd.status.show = true
            }
        },

        keyEnterUkeyOrgCd() {
            if (!this.formSearchQuery.ukeyOrgNm) {
                return this.showTcComAlert('대리점명을 입력해주세요')
            } else {
                this.clickUkeyUkeyOrgCd()
            }
        },

        inputUkeyOrgCd(val) {
            this.formSearchQuery.ukeyOrgCd = ''
            this.popupParamUkeyOrgCd.sktOrgCd = ''

            this.popupParamUkeyOrgCd.orgNm = val
        },

        confirmUkeyOrgCd(query) {
            // operDealcoNm: undefined
            // orgNm: "그레이트(본점)"
            // sktOrgCd: "D00011"
            // sktOrgClCd: "06"
            // sktSubCd: "0000"
            const { orgNm, sktOrgCd, sktSubCd } = query

            this.formSearchQuery.ukeyOrgNm = orgNm
            this.formSearchQuery.ukeyOrgCd = sktOrgCd
            this.formSearchQuery.ukeySubCd = sktSubCd
            // this.formSearchQuery.ukeySubCd = `${sktOrgCd}${sktSubCd}`

            this.$emit('changeUkeyOrgCd', query)
        },

        getSwingDealIfPop() {
            return basBcoTbasDealIfPopApi
                .getTbasDealIfPop(this.popupParamUkeyOrgCd)
                .then((res) => {
                    this.popupUkeyOrgCd.data = res
                    return res
                })
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            let query = Object.assign(
                this.popupParamOrgCd,
                this.formSearchQuery
            )

            delete query.dealStatus

            // 조회 API 가 배열필드 포함 시 에러나므로, 예외처리
            query = arrangeQuery(query)

            if (query.basMth) query.basMth = query.basMth.replace('-', '')

            basBcoAuthOrgTreesApi.getAuthOrgTreeList(query).then((res) => {
                console.log('getAuthOrgTreeList then : ', res)
                // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                if (res.length === 1) {
                    this.formSearchQuery.basMth = _.get(res[0], 'basMth')
                    this.formSearchQuery.orgCd = _.get(res[0], 'orgCd')
                    this.formSearchQuery.orgId = _.get(res[0], 'orgId')
                    this.formSearchQuery.orgNm = _.get(res[0], 'orgNm')
                    this.formSearchQuery.vLevel = _.get(res[0], 'vLevel')

                    this.$emit('changeOrgCd', this.formSearchQuery)
                } else {
                    this.resultAuthOrgTreeRows = res
                    this.showBcoAuthOrgTrees = true
                }
            })
        },

        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []

            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.formSearchQuery.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },

        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.formSearchQuery.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },

        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.formSearchQuery.orgCd = ''
            this.formSearchQuery.orgId = ''
            this.formSearchQuery.orgLvl = ''
            this.formSearchQuery.orgLevel = ''

            this.$forceUpdate()
            this.$emit('changeOrgCd', this.formSearchQuery)
        },

        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            const { orgCd, orgNm, orgLvl } = retrunData
            console.log('retrunData: ', retrunData)

            this.formSearchQuery.orgCd = orgCd
            this.formSearchQuery.orgId = orgCd
            this.formSearchQuery.orgNm = orgNm
            this.formSearchQuery.orgLvl = orgLvl
            this.formSearchQuery.orgLevel = orgLvl

            this.$emit('changeOrgCd', this.formSearchQuery)
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================

        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            let dealcoCdStr = 'dealcoCd'
            let dealcoNmStr = 'dealcoNm'

            if (
                this.offset.includes('search-accDealcoCd') ||
                this.offset.includes('!search-accDealcoCd')
            ) {
                dealcoCdStr = 'accDealcoCd'
                dealcoNmStr = 'accDealcoNm'
            }

            if (
                this.offset.includes('search-rfndDealCo') ||
                this.offset.includes('!search-rfndDealCo')
            ) {
                dealcoCdStr = 'rfndDealCo'
                dealcoNmStr = 'rfndDealCoNm'
            }

            if (
                this.offset.includes('search-stlPlc') ||
                this.offset.includes('!search-stlPlc')
            ) {
                dealcoCdStr = 'stlPlc'
                dealcoNmStr = 'dealNm'
            }

            let query = Object.assign(
                this.popupParamDealcoCd,
                {
                    dealcoCd: this.formSearchQuery[dealcoCdStr],
                    dealcoNm: this.formSearchQuery[dealcoNmStr],
                },
                this.formSearchQuery
            )

            // 조회 API 가 배열필드 포함 시 에러나므로, 예외처리
            query = arrangeQuery(query)
            query.basDay = getCalcDays(
                'lastday',
                { target: query.accMth },
                'YYYYMMDD'
            )

            basBcoDealcosApi.getDealcosList(query).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.$set(
                        this.formSearchQuery,
                        dealcoCdStr,
                        res[0]['dealcoCd']
                    )
                    this.$set(
                        this.formSearchQuery,
                        dealcoNmStr,
                        res[0]['dealcoNm']
                    )

                    this.$emit('changeDealcoCd', this.formSearchQuery)
                    this.$emit('changeAccDealcoCd', this.formSearchQuery)
                    this.$emit('changeRfndDealCo', this.formSearchQuery)
                    this.$emit('changeStlPlc', this.formSearchQuery)

                    //  매장등록 사용자일 경우 돋보기 버튼을 클릭하면 팝업오픈(추가근무지조회를 위해)
                    if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                        this.showBasBcoDealcos = true
                    }
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },

        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            let dealcoCdStr = 'dealcoCd'
            let dealcoNmStr = 'dealcoNm'

            if (
                this.offset.includes('search-accDealcoCd') ||
                this.offset.includes('!search-accDealcoCd')
            ) {
                dealcoCdStr = 'accDealcoCd'
                dealcoNmStr = 'accDealcoNm'
            }

            if (
                this.offset.includes('search-rfndDealCo') ||
                this.offset.includes('!search-rfndDealCo')
            ) {
                dealcoCdStr = 'rfndDealCo'
                dealcoNmStr = 'rfndDealCoNm'
            }

            if (
                this.offset.includes('search-stlPlc') ||
                this.offset.includes('!search-stlPlc')
            ) {
                dealcoCdStr = 'stlPlc'
                dealcoNmStr = 'dealNm'
            }

            this.popupParamDealcoCd.dealcoCd = this.formSearchQuery[dealcoCdStr]
            this.popupParamDealcoCd.dealcoNm = this.formSearchQuery[dealcoNmStr]

            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.formSearchQuery[dealcoNmStr])) {
                // this.getDealcosList()
                this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },

        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            let dealcoNmStr = 'dealcoNm'

            if (
                this.offset.includes('search-accDealcoCd') ||
                this.offset.includes('!search-accDealcoCd')
            ) {
                dealcoNmStr = 'accDealcoNm'
            }

            if (
                this.offset.includes('search-rfndDealCo') ||
                this.offset.includes('!search-rfndDealCo')
            ) {
                dealcoNmStr = 'rfndDealCoNm'
            }

            if (
                this.offset.includes('search-stlPlc') ||
                this.offset.includes('!search-stlPlc')
            ) {
                dealcoNmStr = 'dealNm'
            }

            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈

            if (_.isEmpty(this.formSearchQuery[dealcoNmStr])) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-권한조직명 입력해주세요.'
                return
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },

        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            let dealcoCdStr = 'dealcoCd'

            if (
                this.offset.includes('search-accDealcoCd') ||
                this.offset.includes('!search-accDealcoCd')
            ) {
                dealcoCdStr = 'accDealcoCd'
            }

            if (
                this.offset.includes('search-rfndDealCo') ||
                this.offset.includes('!search-rfndDealCo')
            ) {
                dealcoCdStr = 'rfndDealCo'
            }

            if (
                this.offset.includes('search-stlPlc') ||
                this.offset.includes('!search-stlPlc')
            ) {
                dealcoCdStr = 'stlPlc'
            }

            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.$set(this.formSearchQuery, dealcoCdStr, '')
            this.$forceUpdate()

            this.$emit('changeDealcoCd', this.formSearchQuery)
            this.$emit('changeAccDealcoCd', this.formSearchQuery)
            this.$emit('changeRfndDealCo', this.formSearchQuery)
            this.$emit('changeStlPlc', this.formSearchQuery)
        },

        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)

            let dealcoCdStr = 'dealcoCd'
            let dealcoNmStr = 'dealcoNm'

            if (
                this.offset.includes('search-accDealcoCd') ||
                this.offset.includes('!search-accDealcoCd')
            ) {
                dealcoCdStr = 'accDealcoCd'
                dealcoNmStr = 'accDealcoNm'
            }

            if (
                this.offset.includes('search-rfndDealCo') ||
                this.offset.includes('!search-rfndDealCo')
            ) {
                dealcoCdStr = 'rfndDealCo'
                dealcoNmStr = 'rfndDealCoNm'
            }

            if (
                this.offset.includes('search-stlPlc') ||
                this.offset.includes('!search-stlPlc')
            ) {
                dealcoCdStr = 'stlPlc'
                dealcoNmStr = 'dealNm'
            }

            this.formSearchQuery[dealcoCdStr] = _.get(retrunData, 'dealcoCd')
            this.formSearchQuery[dealcoNmStr] = _.get(retrunData, 'dealcoNm')

            this.$emit('changeDealcoCd', this.formSearchQuery)
            this.$emit('changeAccDealcoCd', this.formSearchQuery)
            this.$emit('changeRfndDealCo', this.formSearchQuery)
            this.$emit('changeStlPlc', this.formSearchQuery)
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================

        //===================== 매입사용도: 공통팝업상세팝업관련 methods ================================
        // 공통팝업상세 조회 후 1건이면 TextField에 바로 설정하고 아니면 공통팝업상세 팝업 오픈
        getCommCdDtlList() {
            const query = {
                ...this.popupParamCardCoCd,
                nm: this.formSearchQuery.cardCoNm,
                cd: '',
            }

            basBcoCommCdDtlApi.getCommCdDtlList(query).then((res) => {
                console.log('getCommCdDtlList then : ', res)

                // 검색된 공통팝업상세 정보가 1건이면 TextField에 바로 설정
                // 검색된 공통팝업상세 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 공통팝업상세 팝업 오픈
                if (res.length === 1) {
                    this.popupParamCardCoCd.cd = _.get(res[0], 'commCdVal')
                    this.popupParamCardCoCd.nm = _.get(res[0], 'commCdValNm')

                    this.formSearchQuery.cardCoCd = _.get(res[0], 'commCdVal')
                    this.formSearchQuery.cardCoNm = _.get(res[0], 'commCdValNm')
                } else {
                    this.resultCommCdDtlRows = res
                    this.showBcoCommCdDtl = true
                }
            })
        },
        // 공통팝업상세 TextField 돋보기 Icon 이벤트 처리
        onCommCdDtlIconClick() {
            // 공통팝업상세 팝업 Row 설정 Prop 변수 초기화
            this.resultCommCdDtlRows = []

            // 검색조건 공통팝업상세명이 빈값이 아니면 공통팝업상세 조회
            // 그 이외는 공통팝업상세 팝업 오픈
            if (!_.isEmpty(this.formSearchQuery.cardCoNm)) {
                this.getCommCdDtlList()
            } else {
                this.showBcoCommCdDtl = true
            }
        },

        // 공통팝업상세 TextField 엔터키 이벤트 처리
        onCommCdDtlEnterKey() {
            // 공통팝업상세 팝업 Row 설정 Prop 변수 초기화
            this.resultCommCdDtlRows = []
            // 검색조건 공통팝업상세명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.formSearchQuery.cardCoNm)) {
                this.showTcComAlert('매입사명을 입력해주세요.')
                return
            }
            // 공통팝업상세 정보 조회
            this.getCommCdDtlList()
        },

        // 공통팝업상세 TextField Input 이벤트 처리
        onCommCdDtlInput() {
            // 입력되는 값이 있으면 공통팝업상세 코드 초기화
            this.popupParamCardCoCd.cd = ''
            this.popupParamCardCoCd.nm = ''
            this.formSearchQuery.cardCoCd = ''

            this.$forceUpdate()
        },

        // 공통팝업상세 팝업 리턴 이벤트 처리
        onCommCdDtlReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.formSearchQuery.cardCoCd = _.get(retrunData, 'commCdVal')
            this.formSearchQuery.cardCoNm = _.get(retrunData, 'commCdValNm')
        },
        //===================== //공통팝업상세팝업관련 methods ================================
    },
}
</script>
