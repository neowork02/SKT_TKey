<!-----------------------------------------------
 * 업무그룹명: 판매수수료 선지급 검증관리
 * 서브업무명: 판매수수료 선지급 검증관리
 * 설명: 판매수수료 선지급 관리 조회,삭제,강제승인 한다.
 * 작성자: P180190
 * 작성일: 2022.09.14
------------------------------------------------>
<template>
    <div class="content">
        <h1>판매수수료 선지급 검증관리</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="screenInit"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="searchBtn"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="saveBtn"
                    >저장</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="deletBtn"
                    >삭제</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="forceFixBtn"
                    :disabled="onConfirm"
                    >강제승인</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        v-model="accYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchFormData.orgNm"
                        :codeVal.sync="searchFormData.orgCd"
                        :eRequired="true"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchFormData"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchFormData.dealcoNm"
                        :codeVal.sync="searchFormData.dealCoCd"
                        labelName="거래처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchFormData"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="채권상계기간 설정"
                        :eRequired="true"
                        :itemList="bondClCdList"
                        :objAuth="objAuth"
                        v-model="searchFormData.bondClCd"
                    />
                </div>
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="지출예정일"
                        :eRequired="true"
                        :disabled="expDueYnAbled"
                        calType="D"
                        v-model="expDueDt_"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="검증상태"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue="0"
                        :disabled="verifyYnAbled"
                        :itemList="verifyYnList"
                        :objAuth="objAuth"
                        v-model="searchFormData.verifyYn"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="지출대상여부"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue="0"
                        :disabled="expObjYnAbled"
                        :itemList="expObjYnList"
                        :objAuth="objAuth"
                        v-model="searchFormData.expObjYn"
                    />
                </div>
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="조회일자"
                        calType="DP"
                        v-model="bond"
                    >
                    </TCComDatePicker>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="판매수수료 선지급 검증관리"
                :isExceldown="true"
                :gridObj="gridObj"
                @excelDownBtn="this.downloadExcel"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :editable="true"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <!-- <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getAccSacSaleCmmsAdpayVrfList"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            /> -->
        </div>
    </div>
</template>
<script>
import { CommonUtil } from '@/utils'
import commonApi from '@/api/common/commonCode'
import adpayVrf from '@/api/biz/acc/sac/NewAccSacSaleCmmsAdpayVrfMgmt'
import moment from 'moment'
import _ from 'lodash'
// 내부조직팝업
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
// 내부조직팝업
//  내부거래처(권한조직)
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//  내부거래처(권한조직)
import { GRID_HEADER } from '@/const/grid/acc/sac/newAccSacSaleCmmsAdpayVrfMgmtGrid'
import CommonMixin from '@/mixins'
export default {
    name: 'NewAccSacSaleCmmsAdpayVrfMgmt',
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
    },
    mixins: [CommonMixin],
    props: {},
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,

            //Grid
            objAuth: {},
            gridObj: {},
            gridData: {},
            gridHeaderObj: {},
            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            searchForms: {
                adpayMgmtVrfVoList: [],
            },

            // rowCnt: '999999',

            accYm_: moment(new Date()).format('YYYY-MM'),
            bondFromDt_: moment(new Date())
                .add(-40, 'days')
                .format('YYYY-MM-DD'),
            bondToDt_: moment(new Date()).add(-1, 'days').format('YYYY-MM-DD'),
            expDueDt_: moment(new Date()).format('YYYY-MM-DD'),

            //요청 파라미터
            searchFormData: {
                // pageSize: 15,
                // pageNum: 1,
                searchCoClOrgCd: '',
                bondFromDt: '',
                bondToDt: '',
                expDueDt: '',
                accMth: '',
                orgLvl: '',
                orgCd: '',
                orgNm: '',
                orgLevel: '',
                dealCoCd: '',
                basMth: '',
                basDay: '',
                bondClCd: '1',
                verifyYn: '0',
                expObjYn: '0',
                // basDay: this.accYm_,
            },

            expDueYnAbled: false,
            verifyYnAbled: false,
            expObjYnAbled: false,

            /* popup영역 */
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                // orgCd: '', // 내부조직팝업(권한)코드
                // orgNm: '', // 내부조직팝업(권한)명
                // srchCoClOrgCd: '',
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부

            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            //====================//내부조직팝업(권한)팝업관련==================

            //  내부거래처(권한조직)
            basBcoDealcoShow: false,
            resultDealcoRows: [],
            //  내부거래처(권한조직)

            //강제버튼 활성화/비활성화
            onConfirm: true,

            bondClCdList: [
                {
                    commCdVal: '1',
                    commCdValNm: '수납+매출-입금+오입금',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '수납-입금+오입금',
                },
            ],

            verifyYnList: [
                {
                    commCdVal: '0',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: '검증',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '미검증',
                },
            ],

            expObjYnList: [
                {
                    commCdVal: '0',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: '대상',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '비대상',
                },
            ],
        }
    },
    mounted() {
        this.searchFormData.searchCoClOrgCd = this.orgInfo.orgCdLvl0
        //PARMA초기화
        //GRID초기화
        this.setGrid()

        //  강제승인권한
        this.getForceFixAuthCodeList()
    },
    computed: {
        bond: {
            get() {
                return [this.bondFromDt_, this.bondToDt_]
            },
            set(val) {
                this.bondFromDt_ = val[0]
                this.bondToDt_ = val[1]
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchFormData.basMth = CommonUtil.onlyNumber(
                    val[1]
                ).substr(0, 6)
                return val
            },
        },
    },
    watch: {},
    created() {
        // this.gridData = this.gridSetData(this.rowCnt)
    },
    methods: {
        async getForceFixAuthCodeList() {
            //  강제확정버튼 사용여부
            var allForceFixAuthCodeList = []
            allForceFixAuthCodeList = await commonApi.getCommonCodeListById(
                'ZBAS_USER_S'
            )
            for (var i in allForceFixAuthCodeList) {
                if (
                    allForceFixAuthCodeList[i].commCdVal ==
                    // this.userInfo.portalUserId
                    'D1514620029'
                ) {
                    this.onConfirm = false
                    break
                }
            }
        },

        // gridSetData: function () {
        //     return new CommonGrid(0, this.rowCnt, '', '')
        // },
        // //페이지 표시 행의수 변경처리
        // chgRowCnt(val) {
        //     this.rowCnt = val
        // },

        //================================================
        // 전체 조회 ::::
        //================================================
        searchBtn: function () {
            if (_.isEmpty(this.searchFormData.orgCd)) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }
            if (_.isEmpty(this.expDueDt_)) {
                return this.showTcComAlert('지출예정일을 선택해 주세요.')
            }
            if (_.isEmpty(this.bondToDt_)) {
                return this.showTcComAlert('채권상계기간을 입력하십시요.')
            }
            if (_.isEmpty(this.bondFromDt_)) {
                return this.showTcComAlert('채권상계기간을 입력하십시요.')
            }
            if (moment(this.expDueDt_).diff(moment(new Date()), 'days') < 0) {
                return this.showTcComAlert('지출예정일이 현재일 이전입니다.')
            }
            if (
                moment(this.bondFromDt_).diff(moment(this.bondToDt_), 'days') >
                0
            ) {
                return this.showTcComAlert(
                    '채권상계기간 시작일자가 종료일자보다 큽니다.'
                )
            }
            this.searchFormData.expDueDt = CommonUtil.onlyNumber(this.expDueDt_)
            this.searchFormData.bondToDt = CommonUtil.onlyNumber(this.bondToDt_)
            this.searchFormData.bondFromDt = CommonUtil.onlyNumber(
                this.bondFromDt_
            )
            this.searchFormData.accMth = this.accYm_
            if (_.isEmpty(this.searchFormData.accMth)) {
                this.showTcComAlert('정산월을 확인하세요.')
            } else {
                // this.searchFormData.pageSize = this.rowCnt
                this.searchFormData.accMth = CommonUtil.onlyNumber(this.accYm_)
                // this.gridData.totalPage = 0 // 이전페이지정보 초기화
                // this.searchFormData.pageNum = 1
                this.getAccSacSaleCmmsAdpayVrfList()
            }
        },
        getAccSacSaleCmmsAdpayVrfList() {
            // this.searchForms = { ...this.searchFormData }
            // this.searchFormData.pageNum = page
            adpayVrf
                .getAccSacSaleCmmsAdpayVrfList(this.searchFormData)
                .then((res) => {
                    if (res) {
                        console.log('res', res)
                        this.gridObj.setRows(res)
                        // this.gridObj.setGridIndicator(res.pagingDto)
                        // this.gridData = this.gridSetData()
                        // this.gridData.totalPage = res.pagingDto.totalPageCnt
                        // this.gridHeaderObj.setPageCount(res.pagingDto)
                        console.log('전체리스트조회 ::::::: 끝')
                    } else {
                        this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                    }
                })
        },

        //================================================
        // 강제승인
        //================================================
        forceFixBtn() {
            this.$refs.grid.gridView.commit()
            const rows = this.$refs.grid.gridView.getCheckedItems(true)
            if (rows.length == 0) {
                return this.showTcComAlert('선택된 항목이 없습니다.')
            } else {
                for (var i = 0; i < rows.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(rows[i])
                    if (
                        row.verifyYn == '미검증' ||
                        row.expObjYn == 'Y' ||
                        row.forceAprvYn == 'Y'
                    ) {
                        return this.showTcComAlert(
                            '강제승인은 검증상태이거나 지출대상이 아니거나\n강제승인이 아닐 경우 가능합니다.(',
                            row.dealCoNm,
                            ')'
                        )
                    }
                    row.forceAprvYn = 'Y'
                    this.searchForms.adpayMgmtVrfVoList.push(row)
                }
                adpayVrf
                    .postAccSacSaleCmmsAdpayVrfList(this.searchForms)
                    .then((res) => {
                        console.log(res)
                        this.getAccSacSaleCmmsAdpayVrfList()
                        this.showTcComAlert('정상적으로 처리되었습니다.')
                    })
            }
        },

        //================================================
        // 저장
        //================================================
        saveBtn() {
            var chgRow = this.$refs.grid.gridView.getCheckedItems(true)
            this.searchForms.adpayMgmtVrfVoList = []
            if (chgRow.length == 0) {
                return this.showTcComAlert('선택된 항목이 없습니다.')
            } else {
                for (var i = 0; i < chgRow.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(chgRow[i])
                    this.searchForms.adpayMgmtVrfVoList.push(row)
                }
                console.log('row', row)
                adpayVrf
                    .postAccSacSaleCmmsAdpayVrfList(this.searchForms)
                    .then((res) => {
                        console.log(res)
                        this.getAccSacSaleCmmsAdpayVrfList()
                        this.showTcComAlert('정상적으로 처리되었습니다.')
                    })
            }
        },

        //================================================
        // 삭제
        //================================================
        deletBtn() {
            this.$refs.grid.gridView.commit()
            this.searchForms.adpayMgmtVrfVoList = []
            var deletList = this.$refs.grid.gridView.getCheckedItems(true)
            if (deletList == null || deletList.length == 0) {
                return this.showTcComAlert('선택된 항목이 없습니다.')
            } else {
                for (var i = 0; i < deletList.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(deletList[i])
                    // 정산되지 않거나 삭제되어 있는건 :: confirmYn
                    if (row.verifyYn == 'N') {
                        return this.showTcComAlert(
                            row.dealCoNm,
                            ' 거래처는 미검증상태입니다.\n검증상태의 거래처만 삭제가능합니다.'
                        )
                    }
                    console.log('row', row)
                    this.searchForms.adpayMgmtVrfVoList.push(row)
                    row.__rowState = 'deleted'
                }
                adpayVrf
                    .deleteAccSacSaleCmmsAdpayVrfList(this.searchForms)
                    .then((resultData) => {
                        if (resultData) {
                            this.getAccSacSaleCmmsAdpayVrfList()
                            console.log(
                                'this.searchForms.pageNum----',
                                this.searchForms.pageNum
                            )
                            this.showTcComAlert('정상적으로 처리되었습니다.')
                        }
                    })
            }
        },
        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcel: function () {
            adpayVrf.getExcelDownloadAccSacSaleCmmsAdpayVrfMgmt(
                this.searchFormData
            )
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchFormData)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchFormData.orgCd = _.get(res[0], 'orgCd')
                        this.searchFormData.orgId = _.get(res[0], 'orgCd')
                        this.searchFormData.orgNm = _.get(res[0], 'orgNm')
                        this.searchFormData.orgLvl = _.get(res[0], 'orgLvl')
                        this.searchFormData.orgLevel = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.searchFormData.basMth = this.accYm_
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            // if (!_.isEmpty(this.searchFormData.orgNm)) {
            // this.getAuthOrgTreeList()
            // } else {
            this.showBcoAuthOrgTrees = true
            // }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.searchFormData.basMth = this.accYm_
            this.resultAuthOrgTreeRows = []

            this.showBcoAuthOrgTrees = true
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchFormData.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchFormData.orgCd = _.get(returnData, 'orgCd')
            this.searchFormData.orgId = _.get(returnData, 'orgCd')
            this.searchFormData.orgNm = _.get(returnData, 'orgNm')
            this.searchFormData.orgLvl = _.get(returnData, 'orgLvl')
            this.searchFormData.orgLevel = _.get(returnData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================

        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.searchFormData).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.searchFormData.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.searchFormData.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.basBcoDealcoShow = true
                }
            })
        },

        //  내부거래처(권한조직))
        onDealcoIconClick() {
            this.resultDealcoRows = []
            this.searchFormData.basDay = moment(this.accYm_)
                .endOf('month')
                .format('YYYYMMDD')
            if (!_.isEmpty(this.searchFormData.dealcoNm)) {
                this.getDealcosList()
            } else {
                // 팝업오픈
                this.basBcoDealcoShow = true
            }
        },

        onDealcoEnterKey() {
            this.resultDealcoRows = []
            this.searchFormData.basDay = moment(this.accYm_)
                .endOf('month')
                .format('YYYYMMDD')
            if (!_.isEmpty(this.searchFormData.dealcoNm)) {
                this.getDealcosList()
            } else {
                // 팝업오픈
                this.basBcoDealcoShow = true
            }
        },

        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchFormData.dealCoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchFormData.dealcoCd = _.get(returnData, 'dealcoCd')
            this.searchFormData.dealcoNm = _.get(returnData, 'dealcoNm')
        },
        //  내부거래처(권한조직))

        // 초기화
        screenInit: function () {
            CommonUtil.clearPage(this, 'searchFormData', this.gridObj)
            this.accYm_ = moment(new Date()).format('YYYY-MM')
            this.expDueDt_ = ''
            this.bondFromDt_ = moment(new Date())
                .add(-40, 'days')
                .format('YYYY-MM-DD')
            this.bondToDt_ = moment(new Date())
                .add(-1, 'days')
                .format('YYYY-MM-DD')
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader

            this.gridObj.setGridState(false, false, true, false)
            this.gridObj.gridView.setColumnLayout(this.view.layout)
            this.$refs.grid.gridView.displayOptions.selectionStyle = 'rows'
        },
    },
}
</script>
