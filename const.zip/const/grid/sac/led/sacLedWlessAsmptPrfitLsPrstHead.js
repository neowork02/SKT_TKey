import { ValueType } from 'realgrid'

export const ORG_HEADER = {
    fields: [
        {
            fieldName: 'accDealcoNm', // 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd', // D코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agrmtClCdNm', // 약정구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agrmtPrdCdNm', // 약정기간
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'allotPrdCdNm', // 단말기 할부개월
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'crdtSaleCostPrc', // 할부원금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'custNm', // 고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpColorNm', // 단말기 색상
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpDisClCdNm', // 단말기 재고구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpSettlCondNm', // 단말기 결제조건
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlColorNm', // 일반상품 색상
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlDisClNm', // 일반상품 재고구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlProdNm', // 일반상품 모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleChgSeq', // 판매변경순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleNo', // 판매번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSerNo', // 일반상품_일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSettlCondNm', // 일반상품_결제조건
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mnpCmmsAmt', // MNP수수료
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'orgNm2', // 사업담당명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd2', // 사업담당코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm3', // 영업팀명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd3', // 영업팀코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm4', // 영업센터명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd4', // 영업센터코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 단말기_모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgHstClNm', // 판매변경이력
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgrUserId', // 판매담당사용자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgrUserNm', // 판매담당사용자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleClNm', // 판매구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd', // 판매처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoNm', // 판매처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtlTypNm', // 판매유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtm', // UKEY처리일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleStNm', // 판매상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'scrbFee', // 가입비
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'serNum', // 단말기_일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', // 서브코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smartColorNm', // 스마트디바이스_색상
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smartDisClCdNm', // 스마트디바이스_재고구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smartSettlCondNm', // 스마트디바이스_결제조건
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smrtProdNm', // 스마트디바이스_모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smrtSerNo', // 스마트디바이스_일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', // 서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNum', // 개통번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'uscanAcptDtm', // USCAN접수일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimDisClCdNm', // USIM_재고구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimProdCd', // USIM_모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimSerNo', // USIM_일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimSettlCondNm', // USIM_결제조건
            dataType: ValueType.TEXT,
        },

        //

        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgLvl', // 조직레벨
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tnewSaleQty', // T판매수량 신규
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tchgSaleQty', // T판매수량 기변
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tetcSaleQty', // T판매수량 중고
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tsaleQty', // T판매수량 소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'eqpSaleQty', // 일반판매수량 단말기
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'usimSaleQty', // 일반판매수량 USIM
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'etcSaleQty', // 일반판매수량 기타
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totSaleQty', // 일반판매수량 소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleCostPrcCrdt', // 매입원가 or 매출원가..?
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleCostPrcCrdt2', // 매입원가 or 매출원가..?
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'allotSaleAmt', // 할부매출 단말기
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'usimAllotSaleAmt', // 할부매출 USIN
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cashSaleAmt', // 현금성매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'adjtCashSaleAmt', // 현금성매출조정
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cashPayAmt', // 수납 현금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'posPayAmt', // 수납 POS/PG
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'crdtPayAmt', // 수납 카드
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totPayAmt', // 수납 소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'phoneSafeAmt', // 폰세이프
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tecoDcAmt', // T에코할인
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cardDcAmt', // 제휴카드할인
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'agreeAmt', // 약정보조금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totPreDcAmt', // 선할인합계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'agrmtAstAmt', // 고객지원금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktPrMnyAmt1', // 인센티브 SKT본사
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktPrMnyAmt2', // 인센티브 SKT본부
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pickupSuprtAmt', // 인센티브 SKT본부(추가)
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktPrMnyAmt3', // 인센티브 SKT팀
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'infraPrMnyAmt', // 인센티브 인프라정책
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktPrMnyAmt', // 인센티브 SKT소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sknPrMnyAmt', // 인센티브 SKN
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactPrMnyAmt', // 인센티브 제조사
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totPrMnyAmt', // 인센티브 합계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totPrMnyDiv', // 인센티브 객단가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmt1', // PS&M인센티브 본사
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmt2', // PS&M인센티브 사업담당
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmt3', // PS&M인센티브 영업팀
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmt', // PS&M인센티브 소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmtDiv', // PS&M인센티브 객단가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gnrlCmmsAmt', // 판매수수료 일반
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'suplCmmsAmt', // 판매수수료 부가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'addsCmmsAmt', // 판매수수료 추가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'untCmmsAmt', // 판매수수료 연합/특판수수료
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'adjtCmmsAmt', // 판매수수료 조정
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totCmmsAmt', // 판매수수료 소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'freeAllotPpayAmt', // 프리할부선납  // 유통망지원금 freeAllotPpay
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsAddSubAmt', // 수수료가감
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tclsInfraPrMnyAmt', // 인프라재원
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsInfraAmt', // 수수료 인프라정책
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cntrctMgmtNum', // 서비스관리번호 <-----
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'accMtchAmt', // 전산상계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asmptCmmsAmt', // 추정수수료
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totCmmsAmtDiv', //추정수수료_객단가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asmptPrfitLsPrchs', //매입 추정손익_전체 <-----
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asmptPrfitLsPrchsDiv', //매입 추정손익_객단가 <-----
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'usimCmmsAmt', // UISM후불예수금 판매수수료_USIM
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rpayAmt', // 수납외
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleChgDtm', // 매출일
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', //수납외(+VAT)
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'exp3Amt', // 타계정판촉출고
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'fixCrdtPrchsPrc', // 매출원가<-----
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'eventAmt', // VIP
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vip', // VIP ??
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gapBudgetOverAmt', //가이드초과 BUDGET 초과금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asmptPrfitLs', // 추정손익 전체
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asmptPrfitLsDiv', // 추정손익 객단가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asmptPrfitLs2', // 추정손익 전체
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asmptPrfitLsDiv2', // 추정손익 객단가
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'orgNm2',
            fieldName: 'orgNm2',
            type: 'data',
            header: '사업담당',
        },
        {
            name: 'orgNm3',
            fieldName: 'orgNm3',
            type: 'data',
            header: '영업팀',
        },
        {
            name: 'orgNm4',
            fieldName: 'orgNm4',
            type: 'data',
            header: '영업센터',
        },
        // T판매수량
        {
            name: 'tnewSaleQty',
            fieldName: 'tnewSaleQty',
            type: 'data',
            header: '신규',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tchgSaleQty',
            fieldName: 'tchgSaleQty',
            type: 'data',
            header: '기변',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tetcSaleQty',
            fieldName: 'tetcSaleQty',
            type: 'data',
            header: '중고',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tsaleQty',
            fieldName: 'tsaleQty',
            type: 'data',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        //일반판매수량
        {
            name: 'eqpSaleQty',
            fieldName: 'eqpSaleQty',
            type: 'data',
            header: '단말기',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'usimSaleQty',
            fieldName: 'usimSaleQty',
            type: 'data',
            header: 'USIM',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'etcSaleQty',
            fieldName: 'etcSaleQty',
            type: 'data',
            header: '기타',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totSaleQty',
            fieldName: 'totSaleQty',
            type: 'data',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'fixCrdtPrchsPrc',
            fieldName: 'fixCrdtPrchsPrc',
            type: 'data',
            header: '매출원가',
            visible: true,
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 할부매출 - 단말기, usim
        {
            name: 'allotSaleAmt',
            fieldName: 'allotSaleAmt',
            type: 'data',
            header: '단말기',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'usimAllotSaleAmt',
            fieldName: 'usimAllotSaleAmt',
            type: 'data',
            header: 'USIM',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cashSaleAmt',
            fieldName: 'cashSaleAmt',
            type: 'data',
            header: '현금성매출',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'adjtCashSaleAmt',
            fieldName: 'adjtCashSaleAmt',
            type: 'data',
            header: '현금매출조정',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        //수납 - 현금, pos/pg, 카드, 소계
        {
            name: 'cashPayAmt',
            fieldName: 'cashPayAmt',
            type: 'number',
            header: '현금',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'posPayAmt',
            fieldName: 'posPayAmt',
            type: 'data',
            header: 'POS/PG',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'crdtPayAmt',
            fieldName: 'crdtPayAmt',
            type: 'data',
            header: '카드',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totPayAmt',
            fieldName: 'totPayAmt',
            type: 'data',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'phoneSafeAmt',
            fieldName: 'phoneSafeAmt',
            type: 'data',
            header: '폰세이프',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tecoDcAmt',
            fieldName: 'tecoDcAmt',
            type: 'data',
            header: 'T에코할인',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cardDcAmt',
            fieldName: 'cardDcAmt',
            type: 'data',
            header: '제휴카드할인',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'agreeAmt',
            fieldName: 'agreeAmt',
            type: 'data',
            header: '약정보조금',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totPreDcAmt',
            fieldName: 'totPreDcAmt',
            type: 'data',
            header: '선할인합계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'agrmtAstAmt',
            fieldName: 'agrmtAstAmt',
            type: 'data',
            header: '고객지원금',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 인센티브 - SKT본사, SKT본부, ...
        {
            name: 'sktPrMnyAmt1',
            fieldName: 'sktPrMnyAmt1',
            type: 'data',
            header: 'SKT본사',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'sktPrMnyAmt2',
            fieldName: 'sktPrMnyAmt2',
            type: 'data',
            header: 'SKT본부',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'pickupSuprtAmt',
            fieldName: 'pickupSuprtAmt',
            type: 'data',
            header: 'SKT본부(추가)',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'sktPrMnyAmt3',
            fieldName: 'sktPrMnyAmt3',
            type: 'data',
            header: 'SKT팀',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'infraPrMnyAmt',
            fieldName: 'infraPrMnyAmt',
            type: 'data',
            header: '인프라정책',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'sktPrMnyAmt',
            fieldName: 'sktPrMnyAmt',
            type: 'data',
            header: 'SKT소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'sknPrMnyAmt',
            fieldName: 'sknPrMnyAmt',
            type: 'data',
            header: 'SKN',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'mfactPrMnyAmt',
            fieldName: 'mfactPrMnyAmt',
            type: 'data',
            header: '제조사',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totPrMnyAmt',
            fieldName: 'totPrMnyAmt',
            type: 'data',
            header: '합계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totPrMnyDiv',
            fieldName: 'totPrMnyDiv',
            type: 'data',
            header: '객단가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        //PS&M인센티브 - 본사, 사업담당, 영업팀, 소계, 객단가
        {
            name: 'psnmPrMnyAmt1',
            fieldName: 'psnmPrMnyAmt1',
            type: 'data',
            header: '본사',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt2',
            fieldName: 'psnmPrMnyAmt2',
            type: 'data',
            header: '사업담당',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt3',
            fieldName: 'psnmPrMnyAmt3',
            type: 'data',
            header: '영업팀',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt',
            fieldName: 'psnmPrMnyAmt',
            type: 'data',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmtDiv',
            fieldName: 'psnmPrMnyAmtDiv',
            type: 'data',
            header: '객단가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 판매수수료 - 일반, 부가, 추가, 연합/특판수수료, 조정, 소계
        {
            name: 'gnrlCmmsAmt',
            fieldName: 'gnrlCmmsAmt',
            type: 'data',
            header: '일반',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'suplCmmsAmt',
            fieldName: 'suplCmmsAmt',
            type: 'data',
            header: '부가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'addsCmmsAmt',
            fieldName: 'addsCmmsAmt',
            type: 'data',
            header: '추가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'untCmmsAmt',
            fieldName: 'untCmmsAmt',
            type: 'data',
            header: '연합/특판수수료',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'adjtCmmsAmt',
            fieldName: 'adjtCmmsAmt',
            type: 'data',
            header: '조정',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totCmmsAmt',
            fieldName: 'totCmmsAmt',
            type: 'data',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cmmsAddSubAmt',
            fieldName: 'cmmsAddSubAmt',
            type: 'data',
            header: '수수료가감',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tclsInfraPrMnyAmt',
            fieldName: 'tclsInfraPrMnyAmt',
            type: 'data',
            header: '인프라재원',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cmmsInfraAmt',
            fieldName: 'cmmsInfraAmt',
            type: 'data',
            header: '수수료인프라정책',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'freeAllotPpayAmt',
            fieldName: 'freeAllotPpayAmt',
            type: 'data',
            header: '유통망지원금',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'accMtchAmt',
            fieldName: 'accMtchAmt',
            type: 'data',
            header: '정산상계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'asmptCmmsAmt',
            fieldName: 'asmptCmmsAmt',
            type: 'data',
            header: '추정수수료',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totCmmsAmtDiv',
            fieldName: 'totCmmsAmtDiv',
            type: 'data',
            header: '추정수수료_객단가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'usimCmmsAmt',
            fieldName: 'usimCmmsAmt',
            type: 'data',
            header: 'USIM후불예수금',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'rpayAmt',
            fieldName: 'rpayAmt',
            type: 'data',
            header: '수납외',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            header: '수납외(*VAT)',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'exp3Amt',
            fieldName: 'exp3Amt',
            type: 'data',
            header: '타계정판촉출고',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'eventAmt',
            fieldName: 'eventAmt',
            type: 'data',
            header: 'VIP',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'gapBudgetOverAmt',
            fieldName: 'gapBudgetOverAmt',
            type: 'data',
            header: '가이드초과',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 추정손익 - 전체, 객단가
        {
            name: 'asmptPrfitLs',
            fieldName: 'asmptPrfitLs',
            type: 'data',
            header: '전체',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'asmptPrfitLsDiv',
            fieldName: 'asmptPrfitLsDiv',
            type: 'data',
            header: '객단가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],
    layout: [
        'orgNm2',
        'orgNm3',
        'orgNm4',
        {
            name: 'T판매수량',
            direction: 'horizontal',
            items: ['tnewSaleQty', 'tchgSaleQty', 'tetcSaleQty', 'tsaleQty'],
        },
        {
            name: '일반판매수량',
            direction: 'horizontal',
            items: ['eqpSaleQty', 'usimSaleQty', 'etcSaleQty', 'totSaleQty'],
        },
        'fixCrdtPrchsPrc',
        {
            name: '할부매출',
            direction: 'horizontal',
            items: ['allotSaleAmt', 'usimAllotSaleAmt'],
        },
        'cashSaleAmt',
        'adjtCashSaleAmt',
        {
            name: '수납',
            direction: 'horizontal',
            items: ['cashPayAmt', 'posPayAmt', 'crdtPayAmt', 'totPayAmt'],
        },
        'phoneSafeAmt',
        'tecoDcAmt',
        'cardDcAmt',
        'agreeAmt',
        'totPreDcAmt',
        'agrmtAstAmt',
        {
            name: '인센티브',
            direction: 'horizontal',
            items: [
                'sktPrMnyAmt1',
                'sktPrMnyAmt2',
                'pickupSuprtAmt',
                'sktPrMnyAmt3',
                'infraPrMnyAmt',
                'sktPrMnyAmt',
                'mfactPrMnyAmt',
                'totPrMnyAmt',
            ],
        },
        {
            name: '판매수수료',
            direction: 'horizontal',
            items: [
                'gnrlCmmsAmt',
                'suplCmmsAmt',
                'addsCmmsAmt',
                'adjtCmmsAmt',
                'totCmmsAmt',
            ],
        },
        'cmmsAddSubAmt',
        'tclsInfraPrMnyAmt',
        'cmmsInfraAmt',
        'freeAllotPpayAmt',
        'accMtchAmt',
        'asmptCmmsAmt',
        'totCmmsAmtDiv',
        'usimCmmsAmt',
        'rpayAmt',
        'vatAmt',
        'exp3Amt',
        'eventAmt',
        'gapBudgetOverAmt',
        {
            name: 'calcPl',
            header: {
                text: '추정손익',
            },
            direction: 'horizontal',
            items: ['asmptPrfitLs', 'asmptPrfitLsDiv'],
        },
    ],
}

export const SHOP_HEADER = {
    columns: [
        {
            name: 'orgNm2',
            fieldName: 'orgNm2',
            type: 'data',
            width: '150',
            header: '사업담당',
        },
        {
            name: 'orgNm3',
            fieldName: 'orgNm3',
            type: 'data',
            width: '150',
            header: '영업팀',
        },
        {
            name: 'orgNm4',
            fieldName: 'orgNm4',
            type: 'data',
            width: '150',
            header: '영업센터',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            width: '150',
            header: '정산처',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            width: '150',
            header: '정산처명',
        },
        {
            name: 'dealcoClNm',
            fieldName: 'dealcoClNm',
            type: 'data',
            width: '150',
            header: '거래처구분',
        },

        //dealcoClNm
        // '거래처구분'
        // T판매수량
        {
            name: 'tnewSaleQty',
            fieldName: 'tnewSaleQty',
            type: 'data',
            width: '150',
            header: '신규',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tchgSaleQty',
            fieldName: 'tchgSaleQty',
            type: 'data',
            width: '150',
            header: '기변',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tetcSaleQty',
            fieldName: 'tetcSaleQty',
            type: 'data',
            width: '150',
            header: '중고',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tsaleQty',
            fieldName: 'tsaleQty',
            type: 'data',
            width: '150',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        //일반판매수량
        {
            name: 'eqpSaleQty',
            fieldName: 'eqpSaleQty',
            type: 'data',
            width: '150',
            header: '단말기',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'usimSaleQty',
            fieldName: 'usimSaleQty',
            type: 'data',
            width: '150',
            header: 'USIM',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'etcSaleQty',
            fieldName: 'etcSaleQty',
            type: 'data',
            width: '150',
            header: '기타',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totSaleQty',
            fieldName: 'totSaleQty',
            type: 'data',
            width: '150',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'fixCrdtPrchsPrc',
            fieldName: 'fixCrdtPrchsPrc',
            type: 'data',
            width: '150',
            header: '매출원가',
            visible: true,
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 할부매출 - 단말기, usim
        {
            name: 'allotSaleAmt',
            fieldName: 'allotSaleAmt',
            type: 'data',
            width: '150',
            header: '단말기',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'usimAllotSaleAmt',
            fieldName: 'usimAllotSaleAmt',
            type: 'data',
            width: '150',
            header: 'USIM',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cashSaleAmt',
            fieldName: 'cashSaleAmt',
            type: 'data',
            width: '150',
            header: '현금성매출',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'adjtCashSaleAmt',
            fieldName: 'adjtCashSaleAmt',
            type: 'data',
            width: '150',
            header: '현금매출조정',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        //수납 - 현금, pos/pg, 카드, 소계
        {
            name: 'cashPayAmt',
            fieldName: 'cashPayAmt',
            type: 'data',
            width: '150',
            header: '현금',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'posPayAmt',
            fieldName: 'posPayAmt',
            type: 'data',
            width: '150',
            header: 'POS/PG',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'crdtPayAmt',
            fieldName: 'crdtPayAmt',
            type: 'data',
            width: '150',
            header: '카드',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totPayAmt',
            fieldName: 'totPayAmt',
            type: 'data',
            width: '150',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'phoneSafeAmt',
            fieldName: 'phoneSafeAmt',
            type: 'data',
            width: '150',
            header: '폰세이프',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tecoDcAmt',
            fieldName: 'tecoDcAmt',
            type: 'data',
            width: '150',
            header: 'T에코할인',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cardDcAmt',
            fieldName: 'cardDcAmt',
            type: 'data',
            width: '150',
            header: '제휴카드할인',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'agreeAmt',
            fieldName: 'agreeAmt',
            type: 'data',
            width: '150',
            header: '약정보조금',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totPreDcAmt',
            fieldName: 'totPreDcAmt',
            type: 'data',
            width: '150',
            header: '선할인합계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'agrmtAstAmt',
            fieldName: 'agrmtAstAmt',
            type: 'data',
            width: '150',
            header: '고객지원금',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 인센티브 - SKT본사, SKT본부, ...
        {
            name: 'sktPrMnyAmt1',
            fieldName: 'sktPrMnyAmt1',
            type: 'data',
            width: '150',
            header: 'SKT본사',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'sktPrMnyAmt2',
            fieldName: 'sktPrMnyAmt2',
            type: 'data',
            width: '150',
            header: 'SKT본부',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'pickupSuprtAmt',
            fieldName: 'pickupSuprtAmt',
            type: 'data',
            width: '150',
            header: 'SKT본부(추가)',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'sktPrMnyAmt3',
            fieldName: 'sktPrMnyAmt3',
            type: 'data',
            width: '150',
            header: 'SKT팀',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'infraPrMnyAmt',
            fieldName: 'infraPrMnyAmt',
            type: 'data',
            width: '150',
            header: '인프라정책',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'sktPrMnyAmt',
            fieldName: 'sktPrMnyAmt',
            type: 'data',
            width: '150',
            header: 'SKT소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'sknPrMnyAmt',
            fieldName: 'sknPrMnyAmt',
            type: 'data',
            width: '150',
            header: 'SKN',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'mfactPrMnyAmt',
            fieldName: 'mfactPrMnyAmt',
            type: 'data',
            width: '150',
            header: '제조사',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totPrMnyAmt',
            fieldName: 'totPrMnyAmt',
            type: 'data',
            width: '150',
            header: '합계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totPrMnyDiv',
            fieldName: 'totPrMnyDiv',
            type: 'data',
            width: '150',
            header: '객단가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        //PS&M인센티브 - 본사, 사업담당, 영업팀, 소계, 객단가
        {
            name: 'psnmPrMnyAmt1',
            fieldName: 'psnmPrMnyAmt1',
            type: 'data',
            width: '150',
            header: '본사',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt2',
            fieldName: 'psnmPrMnyAmt2',
            type: 'data',
            width: '150',
            header: '사업담당',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt3',
            fieldName: 'psnmPrMnyAmt3',
            type: 'data',
            width: '150',
            header: '영업팀',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt',
            fieldName: 'psnmPrMnyAmt',
            type: 'data',
            width: '150',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmtDiv',
            fieldName: 'psnmPrMnyAmtDiv',
            type: 'data',
            width: '150',
            header: '객단가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 판매수수료 - 일반, 부가, 추가, 연합/특판수수료, 조정, 소계
        {
            name: 'gnrlCmmsAmt',
            fieldName: 'gnrlCmmsAmt',
            type: 'data',
            width: '150',
            header: '일반',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'suplCmmsAmt',
            fieldName: 'suplCmmsAmt',
            type: 'data',
            width: '150',
            header: '부가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'addsCmmsAmt',
            fieldName: 'addsCmmsAmt',
            type: 'data',
            width: '150',
            header: '추가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'adjtCmmsAmt',
            fieldName: 'adjtCmmsAmt',
            type: 'data',
            width: '150',
            header: '조정',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totCmmsAmt',
            fieldName: 'totCmmsAmt',
            type: 'data',
            width: '150',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cmmsAddSubAmt',
            fieldName: 'cmmsAddSubAmt',
            type: 'data',
            width: '150',
            header: '수수료가감',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'tclsInfraPrMnyAmt',
            fieldName: 'tclsInfraPrMnyAmt',
            type: 'data',
            width: '150',
            header: '인프라재원',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cmmsInfraAmt',
            fieldName: 'cmmsInfraAmt',
            type: 'data',
            width: '150',
            header: '수수료인프라정책',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'freeAllotPpayAmt',
            fieldName: 'freeAllotPpayAmt',
            type: 'data',
            width: '150',
            header: '유통망지원금',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'accMtchAmt',
            fieldName: 'accMtchAmt',
            type: 'data',
            width: '150',
            header: '정산상계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'asmptCmmsAmt',
            fieldName: 'asmptCmmsAmt',
            type: 'data',
            width: '150',
            header: '추정수수료',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totCmmsAmtDiv',
            fieldName: 'totCmmsAmtDiv',
            type: 'data',
            width: '150',
            header: '추정수수료_객단가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'usimCmmsAmt',
            fieldName: 'usimCmmsAmt',
            type: 'data',
            width: '150',
            header: 'USIM후불예수금',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'rpayAmt',
            fieldName: 'rpayAmt',
            type: 'data',
            width: '150',
            header: '수납외',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            width: '150',
            header: '수납외(*VAT)',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'exp3Amt',
            fieldName: 'exp3Amt',
            type: 'data',
            width: '150',
            header: '타계정판촉출고',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'eventAmt',
            fieldName: 'eventAmt',
            type: 'data',
            width: '150',
            header: 'VIP',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'gapBudgetOverAmt',
            fieldName: 'gapBudgetOverAmt',
            type: 'data',
            width: '150',
            header: '가이드초과',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 추정손익 - 전체, 객단가
        {
            name: 'asmptPrfitLs',
            fieldName: 'asmptPrfitLs',
            type: 'data',
            width: '150',
            header: '전체',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'asmptPrfitLsDiv',
            fieldName: 'asmptPrfitLsDiv',
            type: 'data',
            width: '150',
            header: '객단가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],
    layout: [
        'orgNm2',
        'orgNm3',
        'orgNm4',
        'accDealcoCd',
        'accDealcoNm',
        'dealcoClNm',
        {
            name: 'T판매수량',
            direction: 'horizontal',
            items: ['tnewSaleQty', 'tchgSaleQty', 'tetcSaleQty', 'tsaleQty'],
        },
        {
            name: '일반판매수량',
            direction: 'horizontal',
            items: ['eqpSaleQty', 'usimSaleQty', 'etcSaleQty', 'totSaleQty'],
        },
        'fixCrdtPrchsPrc',
        {
            name: '할부매출',
            direction: 'horizontal',
            items: ['allotSaleAmt', 'usimAllotSaleAmt'],
        },
        'cashSaleAmt',
        'adjtCashSaleAmt',
        {
            name: '수납',
            direction: 'horizontal',
            items: ['cashPayAmt', 'posPayAmt', 'crdtPayAmt', 'totPayAmt'],
        },
        'phoneSafeAmt',
        'tecoDcAmt',
        'cardDcAmt',
        'agreeAmt',
        'totPreDcAmt',
        'agrmtAstAmt',
        {
            name: '인센티브',
            direction: 'horizontal',
            items: [
                'sktPrMnyAmt1',
                'sktPrMnyAmt2',
                'pickupSuprtAmt',
                'sktPrMnyAmt3',
                'infraPrMnyAmt',
                'sktPrMnyAmt',
                'mfactPrMnyAmt',
                'totPrMnyAmt',
            ],
        },
        {
            name: '판매수수료',
            direction: 'horizontal',
            items: [
                'gnrlCmmsAmt',
                'suplCmmsAmt',
                'addsCmmsAmt',
                'adjtCmmsAmt',
                'totCmmsAmt',
            ],
        },
        'cmmsAddSubAmt',
        'tclsInfraPrMnyAmt',
        'cmmsInfraAmt',
        'freeAllotPpayAmt',
        'accMtchAmt',
        'asmptCmmsAmt',
        'totCmmsAmtDiv',
        'usimCmmsAmt',
        'rpayAmt',
        'vatAmt',
        'exp3Amt',
        'eventAmt',
        'gapBudgetOverAmt',
        {
            name: 'calcPl',
            header: {
                text: '추정손익',
            },
            direction: 'horizontal',
            items: ['asmptPrfitLs', 'asmptPrfitLsDiv'],
        },
    ],
}
