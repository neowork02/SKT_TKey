/**************************************************************************************************************
 * 가상데이터 선언 영역
 **************************************************************************************************************/
import send from '@/api/axios-tdcs'
import _ from 'lodash'

export default {
    namespaced: true,
    state: {
        // 검색조건
        dsCondition: {
            ictId: '', // 정책ID
            swgPolCd: '', // T정책코드
            swgPolNm: '', // 정책명
            useYn: '',
            swgPolIdxTyp: '', // 정책지표유형코드
            swgPolTyp: '', // 정책유형코드
            modUserId: '',
            modUserNm: '',
        },
        dsSwgPolIdxTyp: [], // 정책지표유형List
        dsSwgPolTyp: [], // 정책유형List
        dsUseYn: [], // 사용여부List
        dsObjCemp: [],
    },
    mutations: {
        setInit(state, payload) {
            console.log('setInit[mutations]::::', payload)
            _.forEach(payload, (item) => {
                if (item.commCdId == 'ZPOL_SWG_IDX_TYP') {
                    state.dsSwgPolIdxTyp.push(item)
                } else if (item.commCdId == 'ZPOL_SWG_TYP') {
                    state.dsSwgPolTyp.push(item)
                } else if (item.commCdId == 'USE_YN') {
                    state.dsUseYn.push(item)
                }
            })
            state.dsSwgPolIdxTyp.unshift({ commCdVal: '', commCdValNm: '전체' })
            state.dsSwgPolTyp.unshift({ commCdVal: '', commCdValNm: '전체' })
            state.dsUseYn.unshift({ commCdVal: '', commCdValNm: '전체' })
        },
        setDsSwgPolIdxTyp(state, payload) {
            state.dsSwgPolIdxTyp = payload
        },
        setSwgPolTyp(state, payload) {
            state.dsSwgPolTyp = payload
        },
        setDsUseYn(state, payload) {
            state.dsUseYn = payload
        },
        setDsCondition(state, payload) {
            state.dsCondition = payload
        },
        setDsObjCemp(state, payload) {
            state.dsObjCemp = payload
        },
    },
    actions: {
        async getInit({ commit }, payload) {
            console.log('getInit::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'post',
                    url: '/api/v1/backend/pol/com/getCommCdMgmtList',
                    data: payload,
                })
                    .then((res) => {
                        console.log('getInit[then]', res)
                        commit('setInit', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
            // let list = restComApi.getCommonCodeList(payload)
            // console.log('getInit[actions]::::', list)
            // commit('setInit', list)
            // return new Promise((resolve) => {
            //     let list = restComApi.getCommonCodeList(payload)
            //     console.log('promise::::', list)
            //     commit('setInit', list)
            //     resolve()
            // })
            // return new Promise((resolve) => {
            //     commit('setInit', {
            //         dsSwgPolIdxTyp: MOCKUP_DATA.zpolSwgIdxTyp,
            //         dsSwgPolTyp: MOCKUP_DATA.zpolSwgTyp,
            //         dsUseYn: MOCKUP_DATA.useYn,
            //     })
            //     resolve()
            // })
        },
        async getObjCemp({ commit }, payload) {
            console.log('getObjCemp::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'get',
                    url: '/api/v1/backend/pol/cmp/getObjCemp',
                    params: payload,
                })
                    .then((res) => {
                        console.log('getInit[then]', res)
                        commit('setInit', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
    },
    getters: {
        //
    },
}
