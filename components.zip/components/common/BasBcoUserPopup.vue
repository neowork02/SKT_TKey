<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">사용자 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="searchForm.orgNm"
                                    :codeVal.sync="searchForm.orgCd"
                                    placeholder="입력해주세요"
                                    labelName="조직"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :eRequired="true"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchForm"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    v-model="searchForm.userGrpCd"
                                    codeId="ZBAS_C_00250"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    labelName="사용자그룹"
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                            <!-- // item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchForm.userNm"
                                    labelName="사용자명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 1-3 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-2 -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    v-model="searchForm.effUseYn"
                                    codeId="USE_YN"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    labelName="유효사용자 "
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                            <!-- //item 2-2 -->
                            <!-- item 2-3 -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchForm.userId"
                                    labelName="사용자ID"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 2-3 -->
                            <!-- item 2-5 -->
                            <div class="formitem div3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-5 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="basBcoUserGridHeader"
                            ref="basBcoUserGridHeader"
                            :gridObj="gridObj"
                            :isPageRows="true"
                        />
                        <TCRealGrid
                            id="basBcoUserGrid"
                            ref="basBcoUserGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                        <TCComPaging
                            :totalPage="gridData.totalPage"
                            :apiFunc="getUserPopList"
                            :gridObj="gridObj"
                            @input="chgRowCnt"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { BAS_BCO_USER_HEADER } from '@/const/grid/bas/bco/basBcoUserHeader'
import basBcoUserApi from '@/api/biz/bas/bco/basBcoUserPop'
import commonApi from '@/api/common/commonCode'
import { prototype } from '@/views/prototype/js/prototype'
import CommonMixin from '@/mixins'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
import _ from 'lodash'
export default {
    name: 'basBcoUserPopup',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },

    data() {
        return {
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchForm: {
                basMth: '',
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                vLevel: '', // 디스플레이제한레벨
                sLvlList: '', //선택가능레벨 '2,3' : as-is 와동일하게 쉼표로 나열
                all: 'Y', //전체검색여부 Y or null , N..

                //orgCd: '', // 조직코드
                //orgNm: '', // 조직코드
                attcCat: '1', //소속구분
                userGrpCd: '', // 사용여부
                userNm: '', // 서비스구분
                userCd: '',
                effUseYn: '', // 유효사용자
                userId: '', //사용자ID
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //Paging Class init
            gridData: this.gridSetData(),
            headerText: '',
            objAuth: {},
            view: BAS_BCO_USER_HEADER,
            content: '',
            gridObj: {},
            gridHeaderObj: {},
            rowCnt: 15,
            forms: new prototype(),
            activePage: 1, // 현재페이지

            showAgencyPopup: false,
        }
    },

    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.basBcoUserGrid
        this.gridHeaderObj = this.$refs.basBcoUserGridHeader
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.initGrid()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchForm.userNm =
                    value['userNm'] == undefined ? '' : value['userNm'] //사용자명
                this.searchForm.userId =
                    value['userId'] == undefined ? '' : value['userId'] //사용자아이디
                this.searchForm.userCd =
                    value['userCd'] == undefined ? '' : value['userCd'] //사용자코드
                this.searchForm.orgCd =
                    value['orgCd'] == undefined ? '' : value['orgCd'] // 내부조직팝업(권한)코드
                this.searchForm.orgNm =
                    value['orgNm'] == undefined ? '' : value['orgNm'] // 내부조직팝업(권한)명
                this.searchForm.vLevel =
                    value['vLevel'] == undefined ? '' : value['vLevel'] // 디스플레이제한레벨
                this.searchForm.sLvlList =
                    value['sLvlList'] == undefined ? '' : value['sLvlList']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        //GridSetData
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            //return new CommonGrid(-1, -1, 10, 0, '')
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false)
            const commUserGrpCd = await this.getCommCodeList('ZBAS_C_00250')

            // 사용자 구분
            this.gridObj.gridView.columnByName('userGrpCd').values =
                CommonUtil.convListToGridLovValues(commUserGrpCd, 'commCdVal')
            this.gridObj.gridView.columnByName('userGrpCd').labels =
                CommonUtil.convListToGridLovLabels(commUserGrpCd, 'commCdValNm')

            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },
        getUserPopList(page) {
            this.searchForm.pageNum = page //첫번째 페이지
            // basBcoUserApi.getUserPopList(this.searchForm).then((res) => { -> backend오류남. 코딩은 기존사람이 getUserPopList 게 안쓰고 getSaleChrgrPopList 를 썼는데 진짜 getUserPopList 가 폐기인지확인.
            basBcoUserApi.getSaleChrgrPopList(this.searchForm).then((res) => {
                console.log('getSaleChrgrPopList : ', res)
                this.forms = this.searchForm //검색조건 저장
                console.log('res ', res)
                this.gridObj.setRows(res.gridList)
                this.gridObj.setGridIndicator(res.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData() //초기화
                this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수

                //Grid Row 가져올때 총건수 Setting
                this.gridHeaderObj.setPageCount(res.pagingDto)
            })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('사용자를 선택해주세요.', {
                    header: '사용자',
                    size: '500',
                    confirmLabel: 'OK',
                })

                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        onSearch() {
            if (_.isEmpty(this.searchForm.orgNm)) {
                this.showTcComAlert('조직을 선택해주세요.', {
                    //header: '내부거래처',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            this.searchForm.pageSize = this.rowCnt
            this.searchForm.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getUserPopList(this.searchForm.pageNum)
        },

        onEnterKey() {
            this.onSearch()
        },
        // 조직 공통 팝업 이벤트
        onOrgNmEnterKey() {
            if (!_.isEmpty(this.searchForm.orgNm)) {
                //this.getAgencyList()
            } else {
                this.showAgencyPopup = true
            }
        },
        /*
        onInput() {},
        onOrgNmIconClick() {
            alert(1)
        },
*/
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchForm)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchForm.basMth = _.get(res[0], 'basMth')
                        this.searchForm.orgCd = _.get(res[0], 'orgCd')
                        this.searchForm.orgNm = _.get(res[0], 'orgNm')
                        this.searchForm.vLevel = _.get(res[0], 'vLevel')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchForm.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchForm.orgNm)) {
                this.showTcComAlert('조직을 선택해주세요.')

                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchForm.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchForm.orgCd = _.get(retrunData, 'orgCd')
            this.searchForm.orgNm = _.get(retrunData, 'orgNm')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //---// 조직 공통 팝업 이벤트
    },
}
</script>
