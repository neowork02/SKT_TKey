import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'check',
            dataType: ValueType.BOOLEAN,
        },
        {
            fieldName: 'biId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'biIdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'deptCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'deptCdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dutyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dutyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpstyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpstyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'check',
            fieldName: 'check',
            type: 'data',
            editable: false,
            renderer: {
                type: 'check',
            },
            header: {
                text: '삭제',
            },
        },
        {
            name: 'biId',
            fieldName: 'biId',
            header: {
                text: '아이디',
            },
            sortable: true,
            lookupDisplay: true,
        },
        {
            name: 'biIdNm',
            fieldName: 'biIdNm',
            editable: false,
            header: {
                text: 'BI ID명',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'userGrpCd',
            fieldName: 'userGrpCd',
            editable: false,
            header: {
                text: '그룹코드',
            },
        },
        {
            name: 'userGrpNm',
            fieldName: 'userGrpNm',
            header: {
                text: '그룹명',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'deptCd',
            fieldName: 'deptCd',
            editable: false,
            header: {
                text: 'HR부서코드',
            },
        },
        {
            name: 'deptCdNm',
            fieldName: 'deptCdNm',
            editable: false,
            header: {
                text: 'HR부서명',
            },
        },
        {
            name: 'dutyCd',
            fieldName: 'dutyCd',
            header: {
                text: '직무코드',
            },
        },
        {
            name: 'dutyNm',
            fieldName: 'dutyNm',
            editable: false,
            header: {
                text: '직무명',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'rpstyCd',
            fieldName: 'rpstyCd',
            header: {
                text: '직책코드',
            },
        },
        {
            name: 'rpstyNm',
            fieldName: 'rpstyNm',
            editable: false,
            header: {
                text: '직책명',
            },
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            editable: false,
            header: {
                text: '등록자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            editable: false,
            header: {
                text: '등록일시',
            },
        },
    ],
}
