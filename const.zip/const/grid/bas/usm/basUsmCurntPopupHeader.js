import { ValueType } from 'realgrid'

export const HEADER1 = {
    fields: [
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'staDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expirDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNo',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'sktId',
            fieldName: 'sktId',
            header: {
                text: 'Swing ID',
            },
        },
        {
            name: 'sktIdNm',
            fieldName: 'sktIdNm',
            header: {
                text: 'Swing ID명',
            },
        },
        {
            name: 'sktUserId',
            fieldName: 'sktUserId',
            header: {
                text: 'Swing User ID',
            },
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            header: {
                text: '사용여부',
            },
        },
    ],
}

export const HEADER2 = {
    fields: [
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: {
                text: '거래처명',
            },
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            header: {
                text: '적용시작일자',
            },
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            header: {
                text: '적용종료일자',
            },
        },
    ],
}
