import { ValueType } from 'realgrid'

export const GRID_INFO_LEFT = {
    fields: [
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpTypClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpTypClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'eqpTypClNm',
            fieldName: 'eqpTypClNm',
            type: 'data',
            width: '60',
            header: {
                text: '단말방식',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '240',
            header: {
                text: '모델명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'petNm',
            fieldName: 'petNm',
            type: 'data',
            width: '130',
            header: {
                text: '펫네임',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_RIGHT = {
    fields: [
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktMnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktChg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactMnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfactChg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sknNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sknMnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sknChg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'agencyNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'agencyMnp',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'agencyChg',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prodCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '100',
            header: {
                text: '모델명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'sktNum',
            fieldName: 'sktNum',
            type: 'number',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'sktMnp',
            fieldName: 'sktMnp',
            type: 'number',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'sktChg',
            fieldName: 'sktChg',
            type: 'number',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'mfactNum',
            fieldName: 'mfactNum',
            type: 'number',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'mfactMnp',
            fieldName: 'mfactMnp',
            type: 'number',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'mfactChg',
            fieldName: 'mfactChg',
            type: 'number',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'sknNum',
            fieldName: 'sknNum',
            type: 'number',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'sknMnp',
            fieldName: 'sknMnp',
            type: 'number',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'sknChg',
            fieldName: 'sknChg',
            type: 'number',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'agencyNum',
            fieldName: 'agencyNum',
            type: 'number',
            header: {
                text: '010',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'agencyMnp',
            fieldName: 'agencyMnp',
            type: 'number',
            header: {
                text: 'MNP',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'agencyChg',
            fieldName: 'agencyChg',
            type: 'number',
            header: {
                text: '기변',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
    ],

    layout: [
        'prodNm',
        {
            name: 'SKT',
            direction: 'horizontal',
            items: ['sktNum', 'sktMnp', 'sktChg'],
        },
        {
            name: '제조사',
            direction: 'horizontal',
            items: ['mfactNum', 'mfactMnp', 'mfactChg'],
        },
        // {
        //     name: 'SKN',
        //     direction: 'horizontal',
        //     items: ['sknNum', 'sknMnp', 'sknChg'],
        // },
        // {
        //     name: '대리점',
        //     direction: 'horizontal',
        //     items: ['agencyNum', 'agencyMnp', 'agencyChg'],
        // },
    ],
}

export const GRID_INFO_GRADE_LEFT = {
    fields: [
        {
            fieldName: 'eqpTypClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpTypClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'eqpTypClNm',
            fieldName: 'eqpTypClNm',
            type: 'data',
            width: '70',
            header: {
                text: '단말방식',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            header: {
                text: '모델명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'petNm',
            fieldName: 'petNm',
            type: 'data',
            width: '100',
            header: {
                text: '펫네임',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_GRADE_RIGHT = {
    fields: [
        {
            fieldName: 'saleType',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gradeFrom',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gradeTo',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'skt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mfact',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'skn',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'agency',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'saleType',
            fieldName: 'saleType',
            type: 'data',
            width: '100',
            header: {
                text: '판매유형',
                showTooltip: false,
            },
            styleName: 'center-column',
            lookupDisplay: true,
            editable: true,
            editor: {
                type: 'dropdown',
                textReadOnly: true,
            },
            values: [],
            labels: [],
        },
        {
            name: 'gradeFrom',
            fieldName: 'gradeFrom',
            type: 'number',
            header: {
                text: 'From',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'gradeTo',
            fieldName: 'gradeTo',
            type: 'number',
            header: {
                text: 'To',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'skt',
            fieldName: 'skt',
            type: 'number',
            header: {
                text: 'SKT',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'mfact',
            fieldName: 'mfact',
            type: 'number',
            header: {
                text: '제조사',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'skn',
            fieldName: 'skn',
            type: 'number',
            header: {
                text: 'SKN',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'agency',
            fieldName: 'agency',
            type: 'number',
            header: {
                text: '대리점',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
    ],

    layout: [
        'saleType',
        {
            name: 'Grade',
            direction: 'horizontal',
            items: ['gradeFrom', 'gradeTo'],
        },
        'skt',
        'mfact',
        // 'skn',
        // 'agency',
    ],
}
