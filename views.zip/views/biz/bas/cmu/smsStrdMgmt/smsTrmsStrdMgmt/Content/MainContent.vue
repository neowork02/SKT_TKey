<template>
    <div>
        <search-container ref="searchContainer" />
        <table-container @PopupOpen="PopupOpen" @Refresh="Refresh" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/cmu/smsStrdMgmt/smsTrmsStrdMgmt/helpers'
import SearchContainer from './SearchContainer.vue'
import TableContainer from './TableContainer.vue'
//import PopupContainer from './Popup/PopupContainer.vue'

export default {
    components: {
        SearchContainer,
        TableContainer,
        //PopupContainer,
    },
    data() {
        return {
            objAuth: {},
        }
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        PopupOpen(param) {
            this.$refs.popupContainer.open(param)
        },
        Refresh() {
            this.$refs.searchContainer.searchData()
        },
    },
}
</script>

<style>
.content {
    max-width: 100%;
    margin: 0 auto;
}
.flexbox {
    display: flex;
    height: 560px;
    gap: 1em;
}
.item1 {
    min-width: 70%;
    flex-basis: 150px;
    flex-grow: 1;
    flex-shrink: 1;
}
.item2 {
    flex-basis: 150px;
    flex-grow: 1;
    flex-shrink: 1;
}
</style>
