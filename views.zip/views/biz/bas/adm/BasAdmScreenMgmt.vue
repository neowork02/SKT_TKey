<template>
    <div class="content">
        <!-- Tit -->
        <h1>메뉴관리</h1>
        <!-- // Tit -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton eClass="btn_ty01" @click="initClick"
                    >초기화</TCComButton
                >
                <TCComButton eClass="btn_ty01" @click="rgstPop"
                    >신규등록</TCComButton
                >
                <TCComButton eClass="btn_ty01" @click="copyPop"
                    >복사등록</TCComButton
                >
            </li>
            <MgmtPopup
                v-if="showBasAdmScreenMgmtPop"
                ref="popup"
                :dialogShow.sync="showBasAdmScreenMgmtPop"
                :parentParam="searchPopParam"
                @confirm="onPopupReturnData"
            />
        </ul>

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridMenuListHeader"
                ref="gridMenuListHeader"
                gridTitle="메뉴관리"
                :gridObj="gridObj"
            >
                <template #gridElementArea>
                    <TCComInputSearch
                        v-model="forms.menuNm4"
                        labelName="소메뉴명검색"
                        :objAuth="objAuth"
                        @enterKey="onEnterKey"
                        @appendIconClick="getMenuList"
                    ></TCComInputSearch>
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="gridMenuList"
                ref="gridMenuList"
                :editable="true"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
        </div>
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import basMenuApi from '@/api/biz/bas/adm/BasAdmScreenMgmt'
import { BAS_MENU_HEADER } from '@/const/grid/bas/adm/basAdmScreenMgmtHeader'
import MgmtPopup from '@/views/biz/bas/adm/BasAdmScreenMgmtPop'
export default {
    name: 'BasMenu',
    mixins: [CommonMixin],
    props: {},
    components: { MgmtPopup },
    data() {
        return {
            gridObj: {},
            gridData: {},
            gridHeaderObj: {},
            gridList: [],
            objAuth: {},
            forms: {
                menuNm4: '',
            },
            view: BAS_MENU_HEADER,
            rows: [],
            searchWord: '',
            gridStyle: {
                height: '600px',
            },
            showBasAdmScreenMgmtPop: false,

            searchPopParam: {
                menuNo4: '',
                screenNo: '',
                readType: '',
            },
        }
    },
    computed: {},
    watch: {},
    created() {},
    mounted() {
        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.gridMenuList
        this.gridHeaderObj = this.$refs.gridMenuListHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, false, false, false)

        //수정불가
        this.gridObj.gridView.setEditOptions({
            editable: false,
        })

        this.getMenuList()

        //복사모드 -->  클릭때 값을 가지고 있다가 버튼클릭시 팝업오픈.
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            if (undefined == clickData.dataRow) {
                return
            }
            console.log('복사모드클릭')
            console.log(clickData)
            console.log(clickData.fieldName)
            console.log(clickData.dataRow)
            console.log(clickData.fieldIndex)

            let menuNo4 = grid.getValue(clickData.dataRow, 'menuNo4')
            let screenNo = grid.getValue(clickData.dataRow, 'screenNo')
            this.searchPopParam.menuNo4 = menuNo4
            this.searchPopParam.screenNo = screenNo
        }

        //더블클릭(수정모드)
        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            if (undefined == clickData.dataRow) {
                return
            }
            console.log('더블클릭')
            console.log(clickData)
            console.log(clickData.fieldName)
            console.log(clickData.dataRow)
            console.log(clickData.fieldIndex)

            let menuNo4 = grid.getValue(clickData.dataRow, 'menuNo4')
            let screenNo = grid.getValue(clickData.dataRow, 'screenNo')
            this.searchPopParam.menuNo4 = menuNo4
            this.searchPopParam.screenNo = screenNo
            this.searchPopParam.readType = 'U'
            //테스트
            // this.searchPopParam.menuNo4 = '100010002'
            // this.searchPopParam.screenNo = '100010002'

            this.showBasAdmScreenMgmtPop = true
        }
    },
    methods: {
        initClick() {
            this.forms.menuNm4 = ''
            this.getMenuList()
        },
        getMenuList() {
            basMenuApi.getMenuList(this.forms).then((resultData) => {
                this.gridList = resultData
                this.gridObj.setRows(this.gridList)
                let pageInfo = {}
                pageInfo.type = 'noPaging' //페이징이 없는경우
                pageInfo.totalDataCnt = this.gridObj.dataProvider.getRowCount()
                this.gridObj.setGridIndicator(pageInfo)
            })
        },
        rgstPop() {
            this.searchPopParam.readType = 'C'
            this.showBasAdmScreenMgmtPop = true
        },
        copyPop() {
            if (this.searchPopParam.menuNo4) {
                this.searchPopParam.readType = 'B'
                this.showBasAdmScreenMgmtPop = true
            } else {
                this.showTcComAlert('대상 ROW를 선택하세요.', {
                    header: '선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
        },
        onEnterKey() {
            this.getMenuList()
        },
        //등록 수정 후 다시조회.
        onPopupReturnData(retrunData) {
            console.log(retrunData)
            if (0 < retrunData.saveCnt) {
                this.showTcComAlert('처리되었습니다.', {
                    header: '확인',
                    size: '500',
                    confirmLabel: 'OK',
                })

                this.getMenuList()
            }
        },
    },
}
</script>

<style></style>
