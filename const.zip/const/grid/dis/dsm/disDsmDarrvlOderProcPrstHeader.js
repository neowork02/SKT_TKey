import { ValueType } from 'realgrid'

export const DisDsmDarrvlOderProcPrstGRID_HEADER = {
    fields: [
        {
            fieldName: 'sendRcvSt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ordProdStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ordProdStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ordId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ordRcvDtm',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMddhhmmss',
        },
        {
            fieldName: 'opDtmNew',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMddhhmmss',
        },
        {
            fieldName: 'sktAgnCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mbrNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rcvrNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpProdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpColorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpSerNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimProdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'usimSerNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zip',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addr1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addr2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rcvrCntcPlc1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rcvrCntcPlc2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ldongCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcTyp',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcpln',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tdayCmpYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'clubCellChgYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dlvChrgr',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dlvChrgrCntcPlc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dlvFnshDtm',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMddhhmmss',
        },
        {
            fieldName: 'tdayCmpDpstYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ordCnclDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvDtm',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMddhhmmss',
        },
        {
            fieldName: 'rsvSaleYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dlvCoNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'sendRcvSt',
            fieldName: 'sendRcvSt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스유형',
                showTooltip: false,
            },
        },
        {
            name: 'ordProdStCd',
            fieldName: 'ordProdStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전문번호',
                showTooltip: false,
            },
        },
        {
            name: 'ordProdStNm',
            fieldName: 'ordProdStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '진행상태',
                showTooltip: false,
            },
        },
        {
            name: 'ordId',
            fieldName: 'ordId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문번호',
                showTooltip: false,
            },
        },
        {
            name: 'ordRcvDtm',
            fieldName: 'ordRcvDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문일시',
                showTooltip: false,
            },
            width: '130',
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            },
        },
        {
            name: 'opDtmNew',
            fieldName: 'opDtmNew',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            width: '130',
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            },
        },
        {
            name: 'sktAgnCd',
            fieldName: 'sktAgnCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'mbrNm',
            fieldName: 'mbrNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '회원명',
                showTooltip: false,
            },
        },
        {
            name: 'rcvrNm',
            fieldName: 'rcvrNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수령인명',
                showTooltip: false,
            },
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통번호',
                showTooltip: false,
            },
        },
        {
            name: 'eqpProdNm',
            fieldName: 'eqpProdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델명',
                showTooltip: false,
            },
        },

        {
            name: 'eqpColorNm',
            fieldName: 'eqpColorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'eqpSerNum',
            fieldName: 'eqpSerNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'usimYn',
            fieldName: 'usimYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'USIM여부',
                showTooltip: false,
            },
        },
        {
            name: 'usimProdNm',
            fieldName: 'usimProdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'USIM모델명',
                showTooltip: false,
            },
        },
        {
            name: 'usimSerNum',
            fieldName: 'usimSerNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'USIM일련번호',
                showTooltip: false,
            },
        },

        {
            name: 'svcMgmtNo',
            fieldName: 'svcMgmtNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'zip',
            fieldName: 'zip',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '우편번호',
                showTooltip: false,
            },
        },
        {
            name: 'addr1',
            fieldName: 'addr1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배송지주소1',
                showTooltip: false,
            },
        },
        {
            name: 'addr2',
            fieldName: 'addr2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배송지주소2',
                showTooltip: false,
            },
        },
        {
            name: 'rcvrCntcPlc1',
            fieldName: 'rcvrCntcPlc1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수령인연락처1',
                showTooltip: false,
            },
        },

        {
            name: 'rcvrCntcPlc2',
            fieldName: 'rcvrCntcPlc2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수령인연락처2',
                showTooltip: false,
            },
        },
        {
            name: 'ldongCd',
            fieldName: 'ldongCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '법정동코드',
                showTooltip: false,
            },
        },
        {
            name: 'svcTyp',
            fieldName: 'svcTyp',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개통유형',
                showTooltip: false,
            },
        },
        {
            name: 'prcpln',
            fieldName: 'prcpln',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요금제',
                showTooltip: false,
            },
        },
        {
            name: 'tdayCmpYn',
            fieldName: 'tdayCmpYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '바로보상여부',
                showTooltip: false,
            },
        },

        {
            name: 'clubCellChgYn',
            fieldName: 'clubCellChgYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '클럽기변여부',
                showTooltip: false,
            },
        },
        {
            name: 'dlvChrgr',
            fieldName: 'dlvChrgr',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '방문구성원',
                showTooltip: false,
            },
        },
        {
            name: 'dlvChrgrCntcPlc',
            fieldName: 'dlvChrgrCntcPlc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '방문구성원연락처',
                showTooltip: false,
            },
        },
        {
            name: 'dlvFnshDtm',
            fieldName: 'dlvFnshDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배송완료일시',
                showTooltip: false,
            },
            width: '130',
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            },
        },
        {
            name: 'tdayCmpDpstYn',
            fieldName: 'tdayCmpDpstYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '바로보상입금여부',
                showTooltip: false,
            },
        },

        {
            name: 'ordCnclDt',
            fieldName: 'ordCnclDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '취소일',
                showTooltip: false,
            },
        },
        {
            name: 'aprvDtm',
            fieldName: 'aprvDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '결제일',
                showTooltip: false,
            },
            width: '130',
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            },
        },
        {
            name: 'rsvSaleYn',
            fieldName: 'rsvSaleYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '예약판매건여부',
                showTooltip: false,
            },
        },
        {
            name: 'dlvCoNm',
            fieldName: 'dlvCoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배송사',
                showTooltip: false,
            },
        },
    ],
}
