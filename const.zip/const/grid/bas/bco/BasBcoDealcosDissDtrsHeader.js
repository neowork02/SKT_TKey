import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stlPlc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disHldPlc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNmTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoRgstClCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'dealCoCd',
            fieldName: 'dealCoCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            styleName: 'left-column',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '거래처명',
            },
            width: 200,
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채널코드',
            },
        },
        /*        
        {
            name: 'orgNm1',
            fieldName: 'orgNm1',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업부',
            },
        },
        {
            name: 'orgNm2',
            fieldName: 'orgNm2',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업담당',
            },
        },
        {
            name: 'orgNm3',
            fieldName: 'orgNm3',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업팀',
            },
        },
        {
            name: 'orgNm4',
            fieldName: 'orgNm4',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업파트',
            },
        },
*/
        {
            name: 'orgNmTree',
            fieldName: 'orgNmTree',
            type: 'data',
            width: 350,
            styleName: 'left-column',
            header: {
                text: '조직',
            },
        },
        {
            name: 'dealcoRgstClCd',
            fieldName: 'dealcoRgstClCd',
            type: 'data',
            header: {
                text: '거래처등록구분',
            },
        },
        {
            name: 'dealcoGrpCd',
            fieldName: 'dealcoGrpCd',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처그룹',
            },
        },
        {
            name: 'dealcoClCd1',
            fieldName: 'dealcoClCd1',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분',
            },
        },
        {
            name: 'dealcoClCd2',
            fieldName: 'dealcoClCd2',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처유형',
            },
        },
        {
            name: 'stlPlc',
            fieldName: 'stlPlc',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처코드',
            },
        },
        {
            name: 'disHldPlc',
            fieldName: 'disHldPlc',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고보유처코드',
            },
        },
        {
            name: 'dealEndYn',
            fieldName: 'dealEndYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래상태',
            },
        },
    ],
}
