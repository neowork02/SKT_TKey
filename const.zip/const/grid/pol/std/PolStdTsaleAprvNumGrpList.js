import { ValueType } from 'realgrid'

export let GRID_PROPERTYINFO = {
    fields: [
        {
            fieldName: 'dataStatus', // 데이터상태코드(inserted, updated)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'grpMgmtNo', // 그룹관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'grpMgmtNm', // 그룹관리명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt', // 적용시작일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDt', // 적용종료일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn', // 사용여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvCount', // rjstn
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'grpMgmtNo',
            fieldName: 'grpMgmtNo',
            type: 'data',
            width: '100',
            header: {
                text: '관리번호',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'grpMgmtNm',
            fieldName: 'grpMgmtNm',
            type: 'data',
            width: '280',
            header: {
                text: '영업승인번호 그룹명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            type: 'data',
            width: '100',
            header: {
                text: '유효시작일',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            type: 'data',
            width: '100',
            header: {
                text: '유효종료일',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'saleAprvCount',
            fieldName: 'saleAprvCount',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '건수',
                showTooltip: false,
            },
            editor: {
                type: 'number',
                editFormat: '#,##0',
            },
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            width: '100',
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                // dropDownCount: 4,
                // displayLabels: 'valueLabel',
                // textReadOnly: true
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            width: '100',
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
            editable: false,
            styleName: 'left-column',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '100',
            header: {
                text: '처리자',
                showTooltip: false,
            },
            editable: false,
            styleName: 'left-column',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '150',
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            editable: false,
            styleName: 'left-column',
        },
    ],

    layout: [
        'grpMgmtNo', // 관리번호
        'grpMgmtNm', // 영업승인번호 그룹명
        'aplyStaDt', // 유효시작일
        'aplyEndDt', // 유효종료일
        'saleAprvCount', // 건수
        'useYn', // 사용여부
        'modUserId',
        'modUserNm',
        'modDtm',
    ],

    grouping: ['saleAprvCount'],
}
