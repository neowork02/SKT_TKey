<!-----------------------------------------------
 * 업무그룹명: 분실,도난단말기관리현황
 * 서브업무명: 분실,도난단말기등록
 * 설명: 분실,도난단말기등록 업데이트한다.
 * 작성자: P179234
 * 작성일: 2022.06.21
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1100px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">분실,도난단말기등록</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :codeVal.sync="reqParam.orgCd"
                                    :disabledAfter="true"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.orgNm"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :disabled="dataInfoDisabled01"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="reqParam.hldDealcoNm"
                                    :codeVal.sync="reqParam.hldDealcoCd"
                                    labelName="보유처"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onDealcoEnterKey"
                                    @appendIconClick="onDealcoIconClick"
                                    @input="onDealcoInput"
                                    :disabled="dataInfoDisabled01"
                                />
                                <BasBcoDealcosPop
                                    v-if="showBasBcoDealcos"
                                    :parentParam="searchForm"
                                    :rows="resultDealcoRows"
                                    :dialogShow.sync="showBasBcoDealcos"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="등록일자"
                                    calType="D"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="setDate"
                                    @change="onChangeOpDt"
                                    :disabled="dataInfoDisabled02"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="일련번호"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.serNum"
                                    :disabled="dataInfoDisabled01"
                                    @enterKey="serNumChk"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="상품구분"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.prodClNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="모델"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.prodNm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="등록자"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.oprUserNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="여신가"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.fixCrdtAmt"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="제조사"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.mfactNm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="색상"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.colorNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="실제매입가"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.realPrchsPrc"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="이동창고"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.inDealcoNm"
                                />
                                <!--  <TCComComboBox
                                    labelName="이동창고"
                                    :itemList="itemList"
                                    :objAuth="objAuth"
                                    :addBlankItem="true"
                                    blankItemValue=""
                                    v-model="reqParam.inPlcNm"
                                /> -->
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <div class="formitem div3">
                                    <TCComComboBox
                                        labelName="RISK사유"
                                        codeId="ZDIS_C_00170"
                                        ref="prchTypComboBox"
                                        :objAuth="objAuth"
                                        v-model="reqParam.riskLclCd"
                                        @change="onChangeRiskStCd"
                                        :disabled="dataInfoDisabled02"
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    labelName="비고"
                                    :rows="5"
                                    v-model="reqParam.rmks"
                                    :disabled="dataInfoDisabled02"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="search"
                            :disabled="dataInfoDisabled02"
                            >조회</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="save"
                            :disabled="dataInfoDisabled02"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                </div>
                <!-- 재고상품 리스트 조회 -->
                <DisDsmProdHstBrwsSerNumPopup
                    v-if="showPopupSerNum === true"
                    ref="popup"
                    :dialogShow.sync="showPopupSerNum"
                    :popupParams.sync="popupParamsSerNum"
                    @confirm="onReturnDisDsmProdHstBrwsSerNum"
                />
            </div>
        </template>
    </TCComDialog>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 리스크 기기정보 체크
 * 4 일련번호 바코드로 조회
 * 5 등록일자 onchange 이벤트
------------------------------------------------>
<script>
// import { AddBadProd } from './js/disBeqBadProd.js'
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
// import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
import disBeqLossRobberyProdApi from '@/api/biz/dis/beq/disBeqLossRobberyProdMgmt.js'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

//====================내부거래처-권한조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================

import { SacCommon } from '@/views/biz/sac/js'
import { CommonBizClosing, CommonMsg, CommonUtil } from '@/utils'

// import dsmApi from '@/api/biz/dis/dsm/disDsmProdHstBrws'
import DisDsmProdHstBrwsSerNumPopup from '@/views/biz/dis/dsm/DisDsmProdHstBrwsSerNumPopup'

export default {
    name: 'DisBeqLossRobberyProdMgmtRgst',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
        DisDsmProdHstBrwsSerNumPopup,
    },
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        lossRobberyProd: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
                this.$emit('update:addBadProd', value)
            },
        },
        setDate: {
            get() {
                return this.reqParam.opDt
            },
            set(val) {
                this.reqParam.opDt = val
                this.searchParam.basMth = CommonUtil.onlyNumber(val).substr(
                    0,
                    6
                )
                this.searchForm.basDay = CommonUtil.onlyNumber(val)
                return val
            },
        },
    },
    data() {
        return {
            objAuth: {},
            showBcoAuthOrgTrees: false,
            rowCnt: 15,
            searchForms: {},
            reqParam: {
                orgCd: '',
                orgLvl: '',
                hldDealcoCd: '',
                opDt: this.getToday(),
                serNum: '',
                prodClCd: '',
                prodClNm: '',
                prodCd: '',
                prodNm: '',
                chrgrUserId: '',
                fixCrdtAmt: '',
                mfactId: '',
                mfactNm: '',
                colorCd: '',
                colorNm: '',
                realPrchsPrc: '',
                lastInoutDt: '',
                riskLclCd: '',
                inPlcNm: '',
                rmks: '',
                inDealcoCd: '', // 이동창고??
                inDealcoNm: '', // 이동창고??
            },
            itemList: [],
            info: this.lossRobberyProd,

            // 상세 조회시 활성화여부
            dataInfoDisabled01: false,
            dataInfoDisabled02: false,

            //====================내부거래처-권한조직====================
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: '', //거래처그룹코드
                dealcoClCd1: '', //거래처구분코드
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================
            // 내부조직 관련
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            //일련번호 조회팝업
            popupParamsSerNum: {},
            showPopupSerNum: false,
        }
    },
    mounted() {
        this.initParam()
        this.searchRiskHldPlc()
        this.setInfoData()
    },
    methods: {
        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                orgCd: '',
                orgLvl: '',
                hldDealcoCd: '',
                hldDealcoNm: '',
                opDt: this.getToday(),
                serNum: '',
                prodClCd: '',
                prodClNm: '',
                prodCd: '',
                prodNm: '',
                chrgrUserId: '',
                fixCrdtAmt: '',
                mfactId: '',
                mfactNm: '',
                colorCd: '',
                colorNm: '',
                realPrchsPrc: '',
                lastInoutDt: '',
                riskLclCd: '',
                rmks: '',
                inDealcoCd: '', // 이동창고??
                inDealcoNm: '', // 이동창고??
            }
        },
        // 조회시 데이터 set
        setInfoData() {
            if (!_.isEmpty(this.lossRobberyProd)) {
                // 상세조회
                if ('N' == this.lossRobberyProd.FV_NEW_INSERT_YN) {
                    this.reqParam = this.lossRobberyProd
                    this.reqParam.orgCd = this.lossRobberyProd.outOrgCd
                    this.reqParam.orgNm = this.lossRobberyProd.outLvOrgNm3
                    this.reqParam.hldDealcoCd = this.lossRobberyProd.outDealcoCd
                    this.reqParam.hldDealcoNm = this.lossRobberyProd.outDealcoNm

                    this.dataInfoDisabled01 = true
                    if ('01' !== this.reqParam.riskLclCd)
                        this.dataInfoDisabled02 = true
                } else {
                    // 신규등록
                    this.reqParam.orgCd = this.lossRobberyProd.orgCd
                        ? this.lossRobberyProd.orgCd
                        : ''
                    this.reqParam.orgNm = this.lossRobberyProd.orgNm
                        ? this.lossRobberyProd.orgNm
                        : ''
                    this.reqParam.orgLvl = this.lossRobberyProd.orgLvl
                        ? this.lossRobberyProd.orgLvl
                        : ''
                    this.reqParam.hldDealcoNm = this.lossRobberyProd.hldDealcoNm
                        ? this.lossRobberyProd.hldDealcoNm
                        : ''
                    this.reqParam.hldDealcoCd = this.lossRobberyProd.hldDealcoCd
                        ? this.lossRobberyProd.hldDealcoCd
                        : ''
                }
            }
        },
        serNumChk() {
            let sSerNum = this.reqParam.serNum.replace('%', '')
            this.reqParam.serNum = sSerNum
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return
            }
            // const formData = {
            //     serNum: this.reqParam.serNum,
            // }
            const formData = {
                orgCd: this.reqParam.orgCd,
                orgLvl: this.reqParam.orgLvl,
                orgNm: this.reqParam.orgNm,
                serNum: this.reqParam.serNum,
                opDt: this.reqParam.opDt,
            }

            disBeqLossRobberyProdApi
                .getDisProdInfo(formData)
                .then((resultData) => {
                    if (resultData && resultData.length > 1) {
                        this.popupParamsSerNum.params = formData
                        this.popupParamsSerNum.api = 'lossRobberyProd'
                        this.showPopupSerNum = true
                    } else if (resultData && resultData.length == 1) {
                        resultData[0].opDt = _.isEmpty(resultData[0].opDt)
                            ? this.getToday()
                            : resultData[0].opDt
                        this.reqParam = Object.assign(
                            this.reqParam,
                            resultData[0]
                        )
                        this.reqParam.orgCd = formData.orgCd
                        this.reqParam.orgNm = formData.orgNm
                        this.reqParam.orgLvl = formData.orgLvl
                    } else if (!resultData || resultData.length == 0) {
                        this.showTcComAlert('등록된 재고가 없습니다.') // 상품 검색 정보가 없습니다.
                    }
                })
        },
        onReturnDisDsmProdHstBrwsSerNum: function (retVal) {
            if (retVal.flag) {
                this.reqParam.serNum = retVal.data.serNum
                this.reqParam.colorCd = retVal.data.colorCd
                this.reqParam.prodCd = retVal.data.prodCd
                this.search()
            }
        },
        /* 불량기기 검색 */
        async search() {
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return
            }
            // this.searchForms = { ...this.reqParam }
            this.searchForms = {
                orgLvl: this.reqParam.orgLvl,
                orgCd: this.reqParam.orgCd,
                orgNm: this.reqParam.orgNm,
                serNum: this.reqParam.serNum,
                prodCd: this.reqParam.prodCd,
                colorCd: this.reqParam.colorCd,
                opDt: this.reqParam.opDt,
            }

            //testdata
            // this.searchForms = { serNum: '05237144' }
            await disBeqLossRobberyProdApi
                .getDisProdInfo(this.searchForms)
                .then((res) => {
                    if (!res) {
                        this.showTcComAlert('상품 검색 정보가 없습니다.')
                    } else {
                        res[0].opDt = _.isEmpty(res[0].opDt)
                            ? this.getToday()
                            : res[0].opDt
                        this.reqParam = Object.assign(this.reqParam, res[0])

                        this.reqParam.orgCd = this.searchForms.orgCd
                        this.reqParam.orgNm = this.searchForms.orgNm
                        this.reqParam.orgLvl = this.searchForms.orgLvl
                    }
                    // else {
                    //     this.showTcComAlert(
                    //         '불량기기 검색 정보를 불러오지 못했습니다.'
                    //     )
                    // }
                })
        },
        /* 불량기기 이동 창고 목록 검색 */
        async searchRiskHldPlc() {
            //this.searchForms = { ...this.reqParam }
            this.searchForms = { orgCd: 'A1003' }
            // let list = []
            await disBeqLossRobberyProdApi
                .getRiskHldPlc(this.searchForms)
                .then((res) => {
                    if (res) {
                        if (res.length === 0) {
                            this.showTcComAlert(
                                '이동창고 검색 정보가 없습니다.'
                            )
                        } else {
                            this.itemList = res
                            this.onChangeRiskStCd(this.reqParam.riskLclCd)
                        }
                    }
                })
        },
        onChangeRiskStCd(value) {
            if ('03' === value) {
                //도난
                this.reqParam.inDealcoCd = this.itemList[0].hldDealcoCd
                this.reqParam.inDealcoNm = this.itemList[0].hldDealcoNm
            } else if ('04' === value) {
                //분실
                this.reqParam.inDealcoCd = this.itemList[1].hldDealcoCd
                this.reqParam.inDealcoNm = this.itemList[1].hldDealcoNm
            } else if ('05' === value) {
                //횡령
                this.reqParam.inDealcoCd = this.itemList[0].hldDealcoCd
                this.reqParam.inDealcoNm = this.itemList[0].hldDealcoNm
            }
        },
        /* 불량기기 저장 */
        async save() {
            this.reqParam.outDealcoNm = this.reqParam.hldDealcoNm
            this.reqParam.outDealcoCd = this.reqParam.hldDealcoCd
            this.reqParam.crdtPrchsPrc = this.reqParam.fixCrdtAmt
            // 2022/10/12 최초저장 시 RISK상태코드 '06' 승인중 추가
            this.reqParam.riskStCd = '06'
            // 2022/10/12 RISK유형명 추가
            this.reqParam.riskLclNm = this.$refs.prchTypComboBox.getValueText

            const checked = this.check(this.reqParam)
            if (!checked) return
            const list = []
            list.push(checked)
            const formData = { rowDatas: list }

            // const formData = {
            //     rowDatas: [
            //         {
            //             opDt: '20220802',
            //             oprUserId: '',
            //             oprUserNm: '',
            //             modDt: '',
            //             bondTrmsDt: null,
            //             debtSetoffTrmsDt: null,
            //             clsDt: null,
            //             outOrgCd: '',
            //             outOrgNm: '',
            //             outLvOrgCd: '',
            //             outLvOrgNm: '',
            //             outLvOrgCd1: '',
            //             outLvOrgNm1: '',
            //             outLvOrgCd2: '',
            //             outLvOrgNm2: '',
            //             outLvOrgCd3: '',
            //             outLvOrgNm3: '',
            //             hldDealcoCd: '77399',
            //             hldDealcoNm: '',
            //             outShopCd: '',
            //             inOrgCd: '',
            //             inOrgNm: '',
            //             inLvOrgCd: '',
            //             inLvOrgNm: '',
            //             inLvOrgCd1: '',
            //             inLvOrgNm1: '',
            //             inLvOrgCd2: '',
            //             inLvOrgNm2: '',
            //             inLvOrgCd3: '',
            //             inLvOrgNm3: '',
            //             dealcoCd: '67558',
            //             dealcoNm: '',
            //             inShopCd: '',
            //             chrgrUserId: null,
            //             chrgrUserNm: null,
            //             dealcoClCd: '',
            //             dealcoClNm: '',
            //             sktAgencyCd: '',
            //             sktSubCd: '',
            //             sktChnlCd: '',
            //             prodClCd: '',
            //             prodClNm: '',
            //             mfactCd: '',
            //             mfactNm: '',
            //             prodCd: 'A2VW',
            //             prodNm: '',
            //             colorCd: '10',
            //             colorNm: '',
            //             serNum: '1935991',
            //             riskLclCd: '04',
            //             riskLclNm: '',
            //             riskMclCd: '01',
            //             riskMclNm: '',
            //             riskStCd: '01',
            //             riskStNm: '',
            //             clsYn: null,
            //             clsYnNm: '',
            //             fixCrdtAmt: '909000',
            //             realPrchsPrc: '898000',
            //             fixCrdtAmt: '909000',
            //             dpstAmt: null,
            //             etcDpstAmt: null,
            //             costOpAmt: null,
            //             debtSetoffAmt: null,
            //             rmks: null,
            //             chk: '',
            //             riskId: '',
            //             riskSeq: '',
            //             bondClctAmt: null,
            //             bondErpTrmsYn: null,
            //             costErpTrmsYn: null,
            //             dpstTrmsDt: null,
            //             debtSetoffErpTrmsYn: null,
            //             updCnt: '9',
            //             erpTrmsYn: null,
            //             badYn: null,
            //             badYnNm: null,
            //             disStCd: null,
            //             disStNm: null,
            //             hldDealcoCd: null,
            //             inDealcoNm: null,
            //             hldShopCd: null,
            //             lastInoutDt: null,
            //             posDealcoCd: null,
            //             posDealcoNm: null,
            //             posShopCd: null,
            //             reqUserId: null,
            //             outMgmtNo: null,
            //             movSeq: null,
            //             movOutQty: null,
            //             outClCd: null,
            //             movHldDealcoCd: null,
            //             riskCnclRsn: null,
            //             orgLvl: null,
            //             orgCd: null,
            //         },
            //     ],
            // }
            await disBeqLossRobberyProdApi
                .disBeqLossRobberyProdSaving(formData)
                .then(() => {
                    // if (res === 'success') {
                    // --임시주석
                    // 팝업종료
                    this.$emit('confirm', true)
                    this.activeOpen = false
                    // --임시주석
                    //this.getDisInnAutoCnsgSet(this.searchForms.pageNum)
                    // }
                    // else {
                    //     this.showTcComAlert('배정대상 저장에 실패하였습니다.')
                    // }
                })
        },
        /* 불량기기 저장시 조건 체크 */
        check(data) {
            const returnData = _.isEmpty(data.orgCd)
                ? this.showTcComAlert('조직 정보가 없습니다.')
                : _.isEmpty(data.hldDealcoCd)
                ? this.showTcComAlert('보유처 정보가 없습니다.')
                : _.isEmpty(data.opDt)
                ? this.showTcComAlert('등록일자 정보가 없습니다.')
                : _.isEmpty(data.serNum)
                ? this.showTcComAlert('일련번호 정보가 없습니다.')
                : _.isEmpty(data.prodClCd)
                ? this.showTcComAlert('상품구분 정보가 없습니다.')
                : // : data.prodNm === ''
                // ? this.showTcComAlert('모델 정보가 없습니다.')
                // : data.chrgrUserId === ''
                // ? this.showTcComAlert('등록자 정보가 없습니다.')
                // : data.fixCrdtAmt === ''
                // ? this.showTcComAlert('여신가 정보가 없습니다.')
                // : data.mfactNm === ''
                // ? this.showTcComAlert('제조사 정보가 없습니다.')
                // : data.colorNm === ''
                // ? this.showTcComAlert('색상 정보가 없습니다.')
                // : data.realPrchsPrc === ''
                // ? this.showTcComAlert('실제매입가 정보가 없습니다.')
                // data.inPlcNm === ''
                // ? this.showTcComAlert('이동창고 정보가 없습니다.')
                _.isEmpty(data.riskLclCd)
                ? this.showTcComAlert('RISK사유 정보가 없습니다.')
                : data // : data.rmks === ''
            // ? this.showTcComAlert('비고 정보가 없습니다.')

            if (_.isEmpty(returnData)) return false
            if (
                SacCommon.onlyNumber(this.reqParam.opDt) > this.getNextMonth()
            ) {
                this.showTcComAlert(
                    'RISK 등록일자는 현재일자보다 30일 이상 일자는 선택할 수 없습니다.'
                )
            } else if (
                SacCommon.onlyNumber(this.reqParam.opDt) <
                SacCommon.onlyNumber(returnData.lastInoutDt)
            ) {
                this.showTcComAlert(
                    'RISK 등록일자는 상품최종입출고일자 ' +
                        returnData.lastInoutDt +
                        ' 보다 과거로 과거로 등록할 수 없습니다.'
                )
            } else {
                return returnData
            }
        },
        async onChangeOpDt(date) {
            if (_.isEmpty(this.lossRobberyProd)) {
                const clsStatus = await CommonBizClosing.getClsStatus(
                    'D',
                    SacCommon.removeHyphen(date),
                    'STK',
                    this.reqParam.orgCd
                )
                if (clsStatus && 'CLS' == clsStatus.clsStCd) {
                    this.showTcComAlert(CommonMsg.getMessage('MSG_00185', ''))
                    setTimeout(() => {
                        this.reqParam.opDt = this.getToday()
                    }, 1000)
                }
            }
        },
        /* 내부조직팝업 */
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.reqParam.orgCd
            this.searchParam.orgNm = this.reqParam.orgNm
            this.searchParam.orgLvl = this.reqParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        /* 내부조직팝업 - Icon 이벤트 처리 */
        onAuthOrgTreeIconClick() {
            this.resultAuthOrgTreeRows = []
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        /* 내부조직팝업 - TextField 엔터키 이벤트 처리 */
        onAuthOrgTreeEnterKey() {
            this.resultAuthOrgTreeRows = []
            // if (_.isEmpty(this.reqParam.orgNm)) {
            //     this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
            //     return
            // }
            this.getAuthOrgTreeList()
        },
        /* 내부조직팝업 - TextField Input 이벤트 이벤트 처리 */
        onAuthOrgTreeInput() {
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
            this.reqParam.hldDealcoCd = ''
            this.reqParam.hldDealcoNm = ''
        },
        /* 내부조직팝업 - 팝업 리턴 이벤트 이벤트 처리 */
        onAuthOrgTreeReturnData(returnData) {
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.orgLvl = _.get(returnData, 'orgLvl')
            // 내부거래처 팝업 검색조건 조직정보 세팅
            this.searchForm.orgCd = _.get(returnData, 'orgCd')
            this.searchForm.orgNm = _.get(returnData, 'orgNm')
            this.searchForm.orgLvl = _.get(returnData, 'orgLvl')
        },
        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            this.searchForm.orgCd = this.reqParam.orgCd
            this.searchForm.orgNm = this.reqParam.orgNm
            this.searchForm.orgLvl = this.reqParam.orgLvl
            this.searchForm.dealcoCd = this.reqParam.hldDealcoCd
            this.searchForm.dealcoNm = this.reqParam.hldDealcoNm
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.hldDealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.hldDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.dealcoNm)) {
                this.searchForm.basDay = CommonUtil.replaceDash(
                    this.reqParam.opDt
                ).substr(0, 6)
                this.getDealcosList()
                // this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.reqParam.hldDealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            this.reqParam.hldDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.hldDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================

        closeBtn() {
            this.activeOpen = false
        },
        /* 현재일자 확인(yyyy-mm-dd)*/
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
        /* 다음달 확인(yyyy-mm-dd)*/
        getNextMonth() {
            return moment().add(1, 'M').format('YYYYMMDD') ?? ''
        },
    },
}
</script>
