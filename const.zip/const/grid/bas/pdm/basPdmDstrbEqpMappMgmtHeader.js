import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'prodMapCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodMapClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodMapClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodMapCd',
            fieldName: 'prodMapCd',
            header: {
                text: '상품매핑코드',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            editable: false,
            header: {
                text: '상품코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            editable: false,
            header: {
                text: '상품명',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            header: {
                text: '색상',
            },
        },
        {
            name: 'prodMapClNm',
            fieldName: 'prodMapClNm',
            header: {
                text: '상품매핑구분',
            },
        },
    ],
}
