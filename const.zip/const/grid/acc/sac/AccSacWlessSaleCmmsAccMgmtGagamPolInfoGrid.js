import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = [
    {
        fieldName: 'cmmsId',
        header: { text: '오프라인정책ID' },
        width: '150',
    },
    {
        fieldName: 'cmmsTs',
        header: { text: '오프라인정책 차수' },
        width: '150',
    },
    {
        fieldName: 'polNm',
        header: { text: '오프라인정책명' },
        width: '350',
        styleName: 'left-column',
    },
    {
        fieldName: 'offlineAmt',
        header: { text: '오프라인정책 금액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'rmks',
        header: { text: '비고' },
        width: '300',
        styleName: 'left-column',
    },
]

const GRID_HEADER = {}
GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)

export { GRID_HEADER }
