import { ValueType } from 'realgrid'

export const BAS_ADM_QUICK_MENU_HEADER = {
    fields: [
        {
            fieldName: 'maxMenu',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'midMenu',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'minMenu',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuNm',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'menuNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuUse',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuUrl',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'menuNo',
            fieldName: 'menuNo',
            header: {
                text: '메뉴번호',
            },
            editable: false,
        },
        {
            name: 'maxMenu',
            fieldName: 'maxMenu',
            header: {
                text: '대메뉴명',
            },
            editable: false,
        },
        {
            name: 'midMenu',
            fieldName: 'midMenu',
            header: {
                text: '중메뉴명',
            },
            editable: false,
        },
        {
            name: 'minMenu',
            fieldName: 'minMenu',
            header: {
                text: '소메뉴명',
            },
        },
        {
            name: 'menuNm',
            fieldName: 'menuNm',
            header: {
                text: '화면명',
            },
        },
        {
            name: 'menuUse',
            fieldName: 'menuUse',
            header: {
                text: '메뉴사용여부',
            },
            editable: false,
        },
    ],
}
