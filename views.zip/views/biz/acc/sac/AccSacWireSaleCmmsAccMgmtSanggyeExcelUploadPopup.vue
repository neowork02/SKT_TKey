<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1600px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">정산 상계 엑셀업로드</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="searchParams.searchOrgCd"
                                    :codeVal.sync="searchParams.searchOrgNm"
                                    :disabled="true"
                                    :disabledAfter="true"
                                    labelName="조직"
                                >
                                </TCComInputSearchText>
                            </div>
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="M"
                                    v-model="searchParams.searchAccYm_"
                                    labelName="정산월"
                                    :disabled="true"
                                >
                                </TCComDatePicker>
                            </div>
                            <div class="formitem div4">
                                <TCComButton
                                    :Vuetify="false"
                                    eClass="btn_noline btn_ty04"
                                    eAttr="ico_exeldown"
                                    labelName="양식다운로드"
                                    @click="onDownExcelUpTemplate"
                                ></TCComButton>
                                <v-file-input
                                    id="excelFileGagam"
                                    ref="excelFileGagam"
                                    label="엑셀업로드 파일선택(숨김)"
                                    style="display: none"
                                    @change="onChangeExcelFileGagam"
                                ></v-file-input>
                            </div>
                            <!-- // input -->
                            <!-- item 2-4 -->
                            <div class="formitem div4">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="초기화"
                                            :objAuth="objAuth"
                                            @click="onReset"
                                        >
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridSanggyeHeader1"
                                ref="gridSanggyeHeader1"
                                gridTitle="정산 상계"
                                :gridObj="gridObj1"
                                :isExcelup="true"
                                @excelUploadBtn="onSelectExcelFileGagam"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="gridSanggye1"
                                ref="gridSanggye1"
                                :gridObj="gridObj1"
                                :editable="false"
                                :fields="view.fields1"
                                :columns="view.columns1"
                                :styles="gridStyle"
                            />
                            <p class="infoTxt">
                                <span class="color-red"
                                    >수수료구분 코드 : B01(VOC공제),
                                    B02(명의도용공제), B03(파파라치공제),
                                    B04(기타상계)<br />
                                </span>
                            </p>
                        </div>
                        <!-- //gridWrap -->
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridSanggyeHeader2"
                                ref="gridSanggyeHeader2"
                                gridTitle="오류데이터"
                                :gridObj="gridObj2"
                            />
                            <TCRealGrid
                                id="gridSanggye2"
                                ref="gridSanggye2"
                                :gridObj="gridObj2"
                                :editable="false"
                                :fields="view.fields2"
                                :columns="view.columns2"
                                :styles="gridStyle"
                            />
                            <TCRealGridHeader
                                v-show="false"
                                id="gridGagamHeader3"
                                ref="gridGagamHeader3"
                                gridTitle="엑셀업로드 양식다운로드(숨김)"
                                :gridObj="gridObj3"
                            />
                            <TCRealGrid
                                v-show="false"
                                id="gridGagam3"
                                ref="gridGagam3"
                                :gridObj="gridObj3"
                                :fields="view.fields3"
                                :columns="view.columns3"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onSave"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
import CommonMixin from '@/mixins'
import sacApi from '@/api/biz/acc/sac'
import commonApi from '@/api/common/prototype'
import attachApi from '@/api/common/attachedFile'
import { CommonUtil } from '@/utils'
import { AccUtil } from '@/views/biz/acc'
import { AccExcelUpload } from '@/views/biz/acc'
// import sacApi from '@/api/biz/acc/sac'
import { GRID_HEADER } from '@/const/grid/acc/sac/accSacWireSaleCmmsAccMgmtSanggyeExcelUploadPopupGrid'

export default {
    name: 'AccSacWireSaleCmmsAccMgmtSanggyeExcelUploadPopup',
    title: '정산 상계 엑셀업로드',
    mixins: [CommonMixin],
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list1: [],
            list2: [],
            list3: [
                {
                    accDealcoCd: '97601',
                    accDealcoNm: '제이정보통신',
                    saleDealcoCd: '',
                    saleDealcoNm: '',
                    accMtchClNm: 'B01',
                    accMtchItmNm: '21.12월 후불차이금액',
                    accMtchAmt: '5000',
                    saleDt: '20220201',
                    custNm: '홍길동',
                    svcNum: '010-3333-4444',
                    svcMgmtNum: '232',
                    prodNm: 'T-1000',
                    serNum: '12345',
                    rmks: '이관중',
                },
                {
                    accDealcoCd: '97647',
                    accDealcoNm: '아우디통신',
                    saleDealcoCd: 'A220998',
                    saleDealcoNm: 'HJ네트웍스',
                    accMtchClNm: 'B02',
                    accMtchItmNm: '수수료설명 테스트',
                    accMtchAmt: '900',
                    saleDt: '20220301',
                    custNm: '이순신',
                    svcNum: '010-2222-3333',
                    svcMgmtNum: 'A232',
                    prodNm: 'T-2000',
                    serNum: '1234567890',
                    rmks: '테스트중',
                },
                {
                    accDealcoCd: '100389',
                    accDealcoNm: '행복한마을',
                    saleDealcoCd: 'A220998',
                    saleDealcoNm: 'HJ네트웍스',
                    accMtchClNm: 'B03',
                    accMtchItmNm: '수수료설명 테스트2',
                    accMtchAmt: '11000',
                    saleDt: '20220401',
                    custNm: '이황',
                    svcNum: '010-7777-3333',
                    svcMgmtNum: 'B111',
                    prodNm: 'TA330',
                    serNum: '1234567890123456789012345678901234567890A1234567890',
                    rmks: '테스트중2',
                },
            ], // 엑셀업로드양식다운로드 그리드 목록(테스트용)
            listAccDealco: [],
            gridObj1: {},
            gridObj2: {},
            gridObj3: {},
            gridHeaderObj1: {},
            gridHeaderObj2: {},
            gridHeaderObj3: {},
            gridStyle: { height: '180px' },
            code: {
                accMtchClCd: {
                    id: 'WIRE_ACC_MTCH_ITM_CD',
                    list: [],
                },
            },
            paramJson: {},
            searchParams: {
                searchPageType: 'SANGGYE-POPUP',
                searchQueryMode: 'EXCEL_UPLOAD',
                searchOrgCd: this.popupParams.searchOrgCd,
                searchOrgNm: this.popupParams.searchOrgNm,
                searchOrgLvl: this.popupParams.searchOrgLvl,
                searchLvOrgCd: this.popupParams.searchLvOrgCd,
                searchAccYm_: this.popupParams.searchAccYm_,
                searchAccYm: this.popupParams.searchAccYm,
                checkedRows: [],
            },
            requiredExcelGrid: {
                accDealcoCd: '정산처코드',
                accMtchClCd: '수수료구분코드',
                // accMtchItmNm: '수수료설명',
                accMtchAmt: '금액',
            },
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        console.log('mounted')

        // 수수료구분 combo 목록 세팅하기
        this.setComboAccMtchClCd()

        // 엑셀업로드 Grid 기본세팅
        this.gridObj1 = this.$refs.gridSanggye1
        this.gridHeaderObj1 = this.$refs.gridSanggyeHeader1
        this.gridObj1.setGridState(false, false, false)

        // 오류데이터 Grid 기본세팅
        this.gridObj2 = this.$refs.gridSanggye2
        this.gridHeaderObj2 = this.$refs.gridSanggyeHeader2
        this.gridObj2.setGridState(false, false, false)

        // 엑셀양식다운로드 Grid 기본세팅(Hiddend)
        this.gridObj3 = this.$refs.gridGagam3
        this.gridHeaderObj3 = this.$refs.gridGagamHeader3
        this.gridObj3.setGridState(false, false, false)
        this.gridObj3.setRows(this.list3)
    },
    methods: {
        setGetParamJson: function () {
            this.paramJson = _.cloneDeep(this.searchParams)

            // get방식으로 파라미터 넘길 때 오류로 인해 아래 제거함
            delete this.paramJson['checkedRows']

            return this.paramJson
        },
        /* DB에서 처리할 수 있게 row데이터를 가공해서 return */
        getChangeRowData: function (rowData) {
            // 목록에 정산월 추가
            rowData.accYm = this.searchParams.searchAccYm

            // 판매일 날짜를 String으로 변경한다.
            if (!AccUtil.isEmpty(rowData.saleDt)) {
                rowData.saleDt = rowData.saleDt.replace(/-/g, '')
            }

            return rowData
        },
        //초기화 버튼 이벤트
        onReset: function () {
            this.list1 = []
            this.list2 = []
            this.gridObj1.setRows(this.list1)
            this.gridObj2.setRows(this.list2)
        },
        onClose: function () {
            this.$parent.onSearch()
            this.activeOpenAgency = false
        },
        onSave: function () {
            if (this.onSaveValidate() == false) {
                return
            }

            // 엑셀업로드 그리드의 목록 세팅
            this.searchParams.checkedRows = _.cloneDeep(this.list1)

            // 저장할 데이터 가공하기
            this.searchParams.checkedRows.map((json) => {
                return this.getChangeRowData(json)
            })

            this.gridObj1.gridView.commit()
            sacApi
                .saveAccSacWireSaleCmmsAccMgmtList(this.searchParams)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert('저장되었습니다.')
                    this.onReset()
                })
        },
        onSaveValidate: function () {
            if (_.isEmpty(this.list1) || this.list1.length == 0) {
                this.showTcComAlert('저장할 목록이 없습니다.')
                return false
            }

            return true
        },
        onSelectExcelFileGagam: function () {
            document.getElementById('excelFileGagam').click()
        },
        onDownExcelUpTemplate: function () {
            attachApi.downloadSampleFile('423') //  수수료가감엑셀업로드양식
            // this.gridHeaderObj3.exportGrid('정산상계엑셀업로드양식.xlsx')
        },
        onChangeExcelFileGagam: function (f) {
            var tabNum = 3
            var pageType = 'wire'
            AccExcelUpload.onChange(
                pageType,
                tabNum,
                f,
                this.view.columns3,
                this.onReset,
                this.callbackExcelUploadGagam
            )
        },
        /**
         * 엑셀업로드 파일을 선택한 이후에 실행되는 callback 함수
         */
        callbackExcelUploadGagam: function (list) {
            // validate체크하여 정상인 경우 list에 push, 아닌 경우 list2에 push한다.
            if (list) {
                // 정산처/ERP확정여부 목록 조회
                this.listAccDealco = []
                this.searchParams.checkedRows = list
                this.gridObj1.gridView.commit()
                sacApi
                    .getAccSacWireSaleCmmsAccMgmtAccDealcoList(
                        this.searchParams
                    )
                    .then((resultData) => {
                        this.listAccDealco = resultData
                        this.callbackExcelUploadValidateGagam(list)
                    })
            }

            document.getElementById('excelFileGagam').value = ''
        },
        /**
         * 엑셀업로드 파일을 선택한 이후에 validation 체크
         */
        callbackExcelUploadValidateGagam: function (list) {
            // validate체크하여 정상인 경우 list에 push, 아닌 경우 list2에 push한다.
            this.list1 = []
            this.list2 = []

            for (var i = 0; i < list.length; i++) {
                list[i].amt = list[i].accMtchAmt

                // 수수료구분 컬럼에 코드값을 코드명으로 변경한다.
                list[i].accMtchClCd = list[i].accMtchClNm
                var tCodeList = this.code.accMtchClCd.list
                if (!AccUtil.isEmpty(tCodeList)) {
                    var accMtchClNm = ''
                    var isExistsAccMtchClCd = tCodeList.some((data) => {
                        accMtchClNm = data.commCdValNm
                        return data.commCdVal == list[i].accMtchClCd
                    })
                    if (isExistsAccMtchClCd) {
                        list[i].accMtchClNm = accMtchClNm
                    }
                }

                // 필수항목 체크
                var checkRequired = AccExcelUpload.getCheckRequired(
                    list[i],
                    this.requiredExcelGrid
                )
                if (checkRequired.isPass == false) {
                    this.list2.push(
                        AccExcelUpload.getErrGridJson(
                            list[i],
                            checkRequired.errMsg
                        )
                    )

                    continue
                }
                // 정산처 존재여부 체크
                if (
                    AccExcelUpload.isExistsAccDealcoCd(
                        list[i].accDealcoCd,
                        this.listAccDealco
                    ) == false
                ) {
                    this.list2.push(
                        AccExcelUpload.getErrGridJson(
                            list[i],
                            '존재하지 않는 정산처코드입니다'
                        )
                    )
                    continue
                }
                // 직영점 여부 체크
                if (
                    AccExcelUpload.isDirectDealco(
                        list[i].accDealcoCd,
                        this.listAccDealco
                    )
                ) {
                    this.list2.push(
                        AccExcelUpload.getErrGridJson(
                            list[i],
                            '직영점은 정산처가 될 수 없습니다.'
                        )
                    )
                    continue
                }
                // 정산처의 정산완료여부 체크
                if (
                    AccExcelUpload.isErpFix(
                        list[i].accDealcoCd,
                        this.listAccDealco
                    )
                ) {
                    this.list2.push(
                        AccExcelUpload.getErrGridJson(
                            list[i],
                            '정산완료된 정산처입니다'
                        )
                    )
                    continue
                }
                // 금액이 숫자인지 체크
                if (isNaN(list[i].accMtchAmt)) {
                    this.list2.push(
                        AccExcelUpload.getErrGridJson(
                            list[i],
                            '금액은 숫자만 입력해 주세요.'
                        )
                    )
                    continue
                }
                // 금액이 0보다 큰지 체크
                if (Number(list[i].accMtchAmt) == 0) {
                    this.list2.push(
                        AccExcelUpload.getErrGridJson(
                            list[i],
                            '금액이 0입니다.'
                        )
                    )
                    continue
                }
                // 일련번호 byte 체크
                if (CommonUtil.getByteLength(list[i].serNum + '') > 30) {
                    this.list2.push(
                        AccExcelUpload.getErrGridJson(
                            list[i],
                            '일련번호는 30자 이하로 입력해 주세요.'
                        )
                    )
                    continue
                }

                // 입력값이 정상인 경우는 list에 push한다.
                this.list1.push(list[i])
            }

            this.gridObj1.dataProvider.fillJsonData(this.list1, {})
            this.gridObj2.dataProvider.fillJsonData(this.list2, {})
        },
        // 수수료구분 combo 목록 가져와 세팅하기
        setComboAccMtchClCd: function () {
            commonApi
                .getCommonCodeList(this.code.accMtchClCd.id)
                .then((list) => {
                    this.code.accMtchClCd.list = list
                })
        },
    },
}
</script>
