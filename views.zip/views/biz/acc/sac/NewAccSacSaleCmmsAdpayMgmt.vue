<!-----------------------------------------------
 * 업무그룹명: 판매수수료 선지급 관리
 * 서브업무명: 판매수수료 선지급 관리
 * 설명: 판매수수료 선지급 관리 조회,삭제,확정,강제확정,excel업로드 한다.
 * 작성자: P180190
 * 작성일: 2022.09.14
------------------------------------------------>
<template>
    <div class="content">
        <h1>판매수수료 선지급 관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="openExcelUploadPopup"
                    >엑셀업로드</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="fixBtn"
                    >확정</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="forceFixBtn"
                    :disabled="onConfirm"
                    >강제확정</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="screenInit"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="searchBtn"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="saveBtn"
                    >저장</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="deletBtn"
                    >삭제</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        v-model="accYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div5">
                    <TCComInputSearchText
                        v-model="searchFormData.orgNm"
                        :codeVal.sync="searchFormData.orgCd"
                        :eRequired="true"
                        labelName="조직"
                        placeholder="선택해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchFormData"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div5">
                    <TCComInputSearchText
                        v-model="searchFormData.dealcoNm"
                        :codeVal.sync="searchFormData.dealcoCd"
                        labelName="거래처"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchFormData"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                    <BasBcoDealcosPopupAdd
                        v-if="basBcoDealcoShowAdd"
                        :parentParam="searchFormData"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShowAdd"
                        @confirm="confirmBasBcoDealcosPopup"
                    />
                </div>
                <div class="formitem div5">
                    <TCComInput
                        labelName="처리자"
                        v-model="searchFormData.procUserId"
                    />
                </div>
                <div class="formitem div5">
                    <TCComDatePicker
                        labelName="마감월"
                        calType="M"
                        v-model="clsYm_"
                    >
                    </TCComDatePicker>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="판매수수료 선지급 관리"
                :isExceldown="true"
                :isAddRow="true"
                :isDelRow="true"
                :gridObj="this.gridObj"
                @addRowBtn="this.openOrgPopup"
                @chkDelRowBtn="this.gridchkDelRowBtn"
                @excelDownBtn="this.downloadExcel"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :editable="true"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <!-- Excell upload popup 영역 -->
            <NewAccSacSaleCmmsAdpayMgmtExcelUpload
                name="판매수수료지급업로드"
                v-if="NewAccSacSaleCmmsAdpayMgmtExcelUploadShow"
                :popupParams.sync="popupParams"
                :dialogShow.sync="NewAccSacSaleCmmsAdpayMgmtExcelUploadShow"
                @close="searchBtn"
            />
        </div>
    </div>
</template>
<script>
import { CommonUtil } from '@/utils'
import commonApi from '@/api/common/commonCode'
import adpayApi from '@/api/biz/acc/sac/NewAccSacSaleCmmsAdpayMgmt'
import moment from 'moment'
import _ from 'lodash'
// 내부조직팝업
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
// 내부조직팝업
//  내부거래처(권한조직)
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//  내부거래처(권한조직)
import BasBcoDealcosPopupAdd from '@/components/common/BasBcoDealcosPopup'
import NewAccSacSaleCmmsAdpayMgmtExcelUpload from '@/components/biz/acc/sac/NewAccSacSaleCmmsAdpayMgmtExcelUpload'
import { GRID_HEADER } from '@/const/grid/acc/sac/newAccSacSaleCmmsAdpayMgmtGrid'
import CommonMixin from '@/mixins'

export default {
    name: 'NewAccSacSaleCmmsAdpayMgmt',
    components: {
        BasBcoAuthOrgTreesPopup,
        NewAccSacSaleCmmsAdpayMgmtExcelUpload,
        BasBcoDealcosPopup,
        BasBcoDealcosPopupAdd,
        // BasBcoUserPopup,
    },
    mixins: [CommonMixin],
    props: {},
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,

            //Grid
            objAuth: {},
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            rowData: '',
            // rowCnt: '999999',

            accYm_: moment(new Date()).format('YYYY-MM'),
            clsYm_: '',
            saveRows: [],
            chgRow: [],

            //요청 파라미터
            searchFormData: {
                accMth: '',
                searchCoClOrgCd: '',
                orgLvl: '',
                orgCd: '',
                orgNm: '',
                orgLevel: '',
                dealcoCd: '',
                clsMth: '',
                pageSize: '',
                pageNum: 1,
                adpayMgmtVoList: [],
                basMth: '',
                basDay: '',
                dealcoNm: '',
                prodUserId: '',
                prodUserNm: '',
            },
            /* popup영역 */
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                // orgCd: '', // 내부조직팝업(권한)코드
                // orgNm: '', // 내부조직팝업(권한)명
                // srchCoClOrgCd: '',
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부

            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            //====================//내부조직팝업(권한)팝업관련==================

            //  내부거래처(권한조직)
            basBcoDealcoShow: false,
            basBcoDealcoShowAdd: false,
            resultDealcoRows: [],

            //  내부거래처(권한조직)
            popupParams: {},
            NewAccSacSaleCmmsAdpayMgmtExcelUploadShow: false,

            //강제버튼 활성화/비활성화
            onConfirm: true,
        }
    },
    mounted() {
        //PARMA초기화
        //GRID초기화
        this.setGrid()

        //  강제승인권한
        this.getForceFixAuthCodeList()
    },
    computed: {},
    watch: {},
    created() {},
    methods: {
        async getForceFixAuthCodeList() {
            //  강제확정버튼 사용여부
            var allForceFixAuthCodeList = []
            allForceFixAuthCodeList = await commonApi.getCommonCodeListById(
                'ZBAS_USER_S'
            )
            for (var i in allForceFixAuthCodeList) {
                if (
                    allForceFixAuthCodeList[i].commCdVal ==
                    this.userInfo.portalUserId
                ) {
                    this.onConfirm = false
                    break
                }
            }
        },
        //================================================
        // 전체 조회 ::::
        //================================================

        searchBtn: function () {
            this.$refs.grid.gridView.commit()
            //  회사구분조직코드
            this.searchFormData.searchCoClOrgCd = this.orgInfo.orgCdLvl0
            this.searchFormData.prodUserId = this.searchFormData.procUserId
            //  조직을 선택하지 않았을 경우 전체
            if (_.isEmpty(this.searchFormData.orgCd)) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }

            this.searchFormData.accMth = this.accYm_
            if (_.isEmpty(this.searchFormData.accMth)) {
                this.showTcComAlert('정산월을 확인하세요.')
            } else {
                this.searchForms = { ...this.searchFormData }
                this.searchForms.accMth = CommonUtil.onlyNumber(this.accYm_)
                this.getAccSacSaleCmmsAdpayList()
            }
        },
        getAccSacSaleCmmsAdpayList() {
            // this.searchForms.pageNum = page
            adpayApi
                .getAccSacSaleCmmsAdpayList(this.searchForms)
                .then((res) => {
                    if (res) {
                        console.log('res', res.adpayMgmtVoList)
                        this.gridObj.setRows(res.adpayMgmtVoList)
                        console.log('전체리스트조회 ::::::: 끝')
                    } else {
                        this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                    }
                })
        },
        //================================================
        // 확정 ::::
        //================================================
        fixBtn: function () {
            this.$refs.grid.gridView.commit()
            const adPayAccList = this.$refs.grid.gridView.getCheckedItems(true)
            if (adPayAccList == null || adPayAccList.length == 0) {
                this.showTcComAlert('확정할 데이터를 선택해주세요.')
                return
            } else {
                for (var i = 0; i < adPayAccList.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(
                        adPayAccList[i]
                    )
                    // 정산처가 매핑되지 않은 건 :: accDealcoCd
                    if (!row.preAccAmt) {
                        this.showTcComAlert('선지급금액을 입력해주세요.')
                        return
                    }
                    if (row.accSt == '정산확정' || row.accSt == '추정') {
                        this.showTcComAlert(
                            row.accDealcoNm +
                                '은(는)' +
                                row.accSt +
                                ' 상태입니다.\n확인후 다시 처리하십시오.'
                        )
                        return
                    }
                    console.log('row', row)
                    if (row.verifyObjYn == 'Y') {
                        if (
                            row.chkAccMth == '000000' &&
                            row.chkAccPlc == '000000'
                        ) {
                            this.showTcComAlert(
                                '지출 조건에 부합하지 않는 거래처가 있습니다.' +
                                    row.accDealcoNm +
                                    '\n=>지출대상 미검증'
                            )
                            return
                        }
                        if (row.expObjYn == 'N' && row.forceAprvYn == 'N') {
                            this.showTcComAlert(
                                '지출 조건에 부합하지 않는 거래처가 있습니다.(' +
                                    row.accDealcoNm +
                                    ')\n=>지출대상아님'
                            )
                            return
                        }
                        if (
                            parseInt(row.preAccAmt, 10) >
                            parseInt(row.expDueAmt, 10)
                        ) {
                            this.showTcComAlert(
                                '지출 조건에 부합하지 않는 거래처가 있습니다.(' +
                                    row.accDealcoNm +
                                    ')\n=>지출가능최대금액초과'
                            )
                            return
                        }
                    }
                }
                this.showTcComConfirm(
                    '판매수수료선지급을 확정하시겠습니까?'
                ).then((confirm) => {
                    if (confirm) {
                        // 선택한 row로 API 호출
                        // list 초기화
                        this.searchForms = {}
                        this.searchForms.adpayMgmtVoList = []
                        var rowData = {}
                        for (i = 0; i < adPayAccList.length; i++) {
                            rowData = this.$refs.grid.gridView.getValues(
                                adPayAccList[i]
                            )
                            rowData.fixYn = '1'
                            this.searchForms.adpayMgmtVoList.push(rowData)
                        }
                        adpayApi
                            .postConfirmAccSacSaleCmmsAdpayList(
                                this.searchForms
                            )
                            .then((res) => {
                                console.log(res)
                                this.showTcComAlert(
                                    '정상적으로 처리되었습니다.'
                                )
                                this.searchBtn()
                            })
                    }
                })
            }
        },

        //================================================
        // 강제확정
        //================================================
        forceFixBtn() {
            this.$refs.grid.gridView.commit()
            const rows = this.$refs.grid.gridView.getCheckedItems(true)
            console.log('KYJ FORCED => ', rows)
            // ADMIN 권한일 경우 선지급검증 없이 확정가능
            if (rows.length == 0) {
                return this.showTcComAlert('확정할 데이터를 선택해주세요.')
            } else {
                for (var i = 0; i < rows.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(rows[i])
                    if (!row.preAccAmt) {
                        console.log(row['preAccAmt'])
                        this.showTcComAlert('선지급금액을 입력해주세요.')
                        return
                    }
                    if (row.accSt == '정산확정' || row.accSt == '추정') {
                        this.showTcComAlert(
                            row.accDealcoNm +
                                '은(는)' +
                                row.accSt +
                                ' 상태입니다.\n확인후 다시 처리하십시오.'
                        )
                        return
                    }
                }
                this.showTcComConfirm(
                    '강제확정버튼을 클릭했습니다. 선지급검증없이 확정처리됩니다.\n확정하시겠습니까?'
                ).then((confirm) => {
                    if (confirm) {
                        // 선택한 row API 호출
                        // list 초기화
                        this.searchForms = {}
                        this.searchForms.adpayMgmtVoList = []
                        var rowData = {}
                        for (i = 0; i < rows.length; i++) {
                            rowData = this.$refs.grid.gridView.getValues(
                                rows[i]
                            )
                            rowData.fixYn = '1'
                            this.searchForms.adpayMgmtVoList.push(rowData)
                        }
                        adpayApi
                            .postConfirmAccSacSaleCmmsAdpayList(
                                this.searchForms
                            )
                            .then((res) => {
                                console.log(res)
                                this.showTcComAlert(
                                    '정상적으로 처리되었습니다.'
                                )
                                this.searchBtn()
                            })
                    }
                })
            }
        },

        //================================================
        // 저장
        //================================================
        saveBtn() {
            this.$refs.grid.gridView.commit()
            this.chgRow = []
            //변경된 행 데이터 가져오기
            this.chgRow = this.gridObj.setModifyData(this.chgRow)
            var today = moment(new Date()).format('YYYY-MM-DD')
            this.searchForms = {}
            this.searchForms.adpayMgmtVoList = []
            this.saveRows = this.chgRow.saveRows
            console.log('this.saveRows', this.saveRows)
            // var rowData = {}
            if (this.saveRows.length == 0) {
                this.showTcComAlert('수정된 항목이 없습니다.')
                return
            } else {
                for (var i = 0; i < this.saveRows.length; i++) {
                    if (
                        this.saveRows[i].__rowState == 'updated' &&
                        moment(this.saveRows[i].modDtm).format('YYYY-MM-DD') !==
                            today
                    ) {
                        this.showTcComAlert('당일 저장건만 수정가능합니다.')
                        return
                    }
                    if (!this.saveRows[i].preAccAmt) {
                        this.showTcComAlert('선지급금액을 입력해주세요.')
                        return
                    }
                    this.searchForms.adpayMgmtVoList = this.chgRow.saveRows
                }
                adpayApi
                    .postAccSacSaleCmmsAdpayList(this.searchForms)
                    .then((res) => {
                        console.log(res)
                        this.showTcComAlert('정상적으로 처리되었습니다.')
                        this.searchBtn()
                    })
            }
        },

        //================================================
        // 삭제
        //================================================
        deletBtn() {
            this.$refs.grid.gridView.commit()
            var today = moment(new Date()).format('YYYY-MM-DD')
            this.searchForms.adpayMgmtVoList = []
            var deletList = this.$refs.grid.gridView.getCheckedItems(true)
            if (deletList == null || deletList.length == 0) {
                this.showTcComAlert('선택된 항목이 없습니다.')
                return
            } else {
                for (var i = 0; i < deletList.length; i++) {
                    var row = this.$refs.grid.gridView.getValues(deletList[i])
                    // 정산되지 않거나 삭제되어 있는건 :: confirmYn
                    if (moment(row.modDtm).format('YYYY-MM-DD') !== today) {
                        this.showTcComAlert('당일 저장건만 삭제가능합니다.')
                        console.log(moment(row.modDtm).format('YYYY-MM-DD'))
                        return
                    }
                    // if ((row.fixYn = 'Y')) {
                    row.fixYn = '1'
                    row.__rowState = 'deleted'
                    console.log('row', row)
                    // }
                    this.searchForms.adpayMgmtVoList.push(row)
                }
                this.showTcComConfirm('삭제하시겠습니까??').then((confirm) => {
                    console.log('showTcComConfirm confirm: ', confirm)
                    if (confirm) {
                        // 선택한 row로 삭제
                        adpayApi
                            .deleteAccSacSaleCmmsAdpayList(this.searchForms)
                            .then((resultData) => {
                                if (resultData) {
                                    this.showTcComAlert(
                                        '정상적으로 처리되었습니다.'
                                    )
                                    this.searchBtn()
                                }
                            })
                    }
                })
            }
        },

        //================================================
        // 그리드 행추가
        // 그리드 행 추가용 거래처 팝업
        //================================================
        openOrgPopup() {
            const qurentData = this.searchFormData
            qurentData.basDay = this.accYm_
            qurentData.dealcoGrpCd = '하부망'
            console.log('qurentData', qurentData)
            if (!qurentData.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            } else {
                this.basBcoDealcoShowAdd = true
            }
        },

        // (팝업)내부 거래처 조회된 리스트 선택시 그리드 데이터 "추가"
        confirmBasBcoDealcosPopup(rowData) {
            this.$refs.grid.gridView.commit()
            const qurentData = this.searchFormData
            const newRow = {}

            Object.assign(newRow, qurentData, rowData)

            newRow.fixYn = 'A'
            newRow.accMth = this.accYm_.replace(/-/g, '')
            newRow.__rowState = 'create'
            return adpayApi
                .getAccSacSaleCmmsAdpayNewList(newRow)
                .then((res) => {
                    console.log('response', res)
                    res.adpayMgmtVoList.forEach((row) => {
                        console.log('row ===> ', row)
                        this.addRowData(row, 'last')
                    })
                })
        },

        //================================================
        // 그리드 행삭제
        //================================================
        gridchkDelRowBtn: function () {
            this.$refs.grid.gridView.commit()
            var today = moment(new Date()).format('YYYY-MM-DD')
            var deletRowList = this.$refs.grid.gridView.getCheckedItems(true)
            if (deletRowList == null || deletRowList.length == 0) {
                this.showTcComAlert('선택된 데이터가 없습니다.')
                return
            } else {
                for (var i = 0; i < deletRowList.length; i++) {
                    let state = this.gridObj.dataProvider.getRowState(
                        deletRowList[i]
                    )
                    var row = this.$refs.grid.gridView.getValues(
                        deletRowList[i]
                    )
                    if (
                        state !== 'created' &&
                        moment(row.modDtm).format('YYYY-MM-DD') !== today
                    ) {
                        this.showTcComAlert(
                            '신규 추가된 데이터만 삭제가 가능합니다.'
                        )
                        return
                    }
                    this.gridObj.dataProvider.removeRows(deletRowList)
                }
            }
        },

        addRowData(rowsData, locate = 'last') {
            const idx =
                locate == 'first' ? 0 : this.$refs.grid.gridView.getItemCount()

            this.gridObj.dataProvider.insertRow(idx, rowsData)
            this.$refs.grid.gridView.commit()
            this.$emit('addRowData', rowsData)
        },

        //================================================
        // EXCEL UPLOAD POPUP 열기
        //================================================
        openExcelUploadPopup: function () {
            this.popupParams.accMth = this.accYm_
            this.NewAccSacSaleCmmsAdpayMgmtExcelUploadShow = true
        },
        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcel: function () {
            adpayApi.getExcelDownloadAccSacSaleCmmsAdpayList(this.searchForms)
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchFormData)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchFormData.orgCd = _.get(res[0], 'orgCd')
                        this.searchFormData.orgId = _.get(res[0], 'orgCd')
                        this.searchFormData.orgNm = _.get(res[0], 'orgNm')
                        this.searchFormData.orgLvl = _.get(res[0], 'orgLvl')
                        this.formSearchQuery.orgLevel = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.searchFormData.basMth = this.accYm_.replace(/-/g, '')
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            this.showBcoAuthOrgTrees = true
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.searchFormData.basMth = this.accYm_
            this.resultAuthOrgTreeRows = []
            this.showBcoAuthOrgTrees = true
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchFormData.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchFormData.orgCd = _.get(returnData, 'orgCd')
            this.searchFormData.orgNm = _.get(returnData, 'orgNm')
            this.searchFormData.orgLvl = _.get(returnData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.searchFormData).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.searchFormData.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.searchFormData.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.basBcoDealcoShow = true
                }
            })
        },
        //  내부거래처(권한조직))
        onDealcoIconClick() {
            this.resultDealcoRows = []
            this.searchFormData.basDay = moment(this.accYm_)
                .endOf('month')
                .format('YYYYMMDD')
            if (!_.isEmpty(this.searchFormData.dealcoNm)) {
                this.getDealcosList()
            } else {
                // 팝업오픈
                this.basBcoDealcoShow = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            this.resultDealcoRows = []
            this.searchFormData.basDay = moment(this.accYm_)
                .endOf('month')
                .format('YYYYMMDD')
            if (!_.isEmpty(this.searchFormData.dealcoNm)) {
                this.getDealcosList()
            } else {
                // 팝업오픈
                this.basBcoDealcoShow = true
            }
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchFormData.dealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchFormData.dealcoCd = _.get(returnData, 'dealcoCd')
            this.searchFormData.dealcoNm = _.get(returnData, 'dealcoNm')
        },
        //  내부거래처(권한조직))

        // 초기화
        screenInit: function () {
            CommonUtil.clearPage(this, 'searchFormData', this.gridObj)
            this.accYm_ = moment(new Date()).format('YYYY-MM')
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader

            this.gridObj.setGridState(false, false, true, false)
            this.gridObj.gridView.setColumnLayout(this.view.layout)
            this.$refs.grid.gridView.displayOptions.selectionStyle = 'rows'
        },
    },
}
</script>
