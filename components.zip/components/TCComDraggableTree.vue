<!-----------------------------------------------
 * 업무그룹명: Draggable Tree 컴포넌트
 * 서브업무명: Draggable Tree 공통함수
 * 설명: Draggable Tree 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.05.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <v-list nav>
        <v-list-item-group color="primary">
            <TCComDraggableTreeNode
                :items="items"
                :itemKey="itemKey"
                :itemChild="itemChild"
                :itemText="itemText"
                :options="initOptions"
                @selectTreeNode="selectTreeNode"
                @addTreeNode="addTreeNode"
                @deleteTreeNode="deleteTreeNode"
            />
        </v-list-item-group>
    </v-list>
</template>

<script>
import TCComDraggableTreeNode from './TCComDraggableTreeNode.vue'

export default {
    inheritAttrs: false,
    name: 'TCComDraggableTree',
    components: { TCComDraggableTreeNode },
    props: {
        items: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        }, // 노드 정보
        itemKey: { type: String, default: 'id', required: false }, // 노드 키
        itemText: { type: String, default: 'name', required: false }, // 노드 Text
        itemChild: { type: String, default: 'children', required: false }, // 자식 노드
        options: {
            type: Object,
            default: () => ({
                openAll: false,
                add: true,
                delete: true,
                group: false,
            }),
            required: false,
        }, // 옵션
        objAuth: { type: Object, default: () => {}, required: false }, // auth
    },

    data() {
        return {}
    },
    computed: {
        initOptions() {
            const options = Object.assign({}, this.options)
            if (options.openAll == undefined) options.openAll = false
            if (options.add == undefined) options.add = true
            if (options.delete == undefined) options.delete = true
            if (options.group == undefined) {
                options.group = false
            } else {
                this.items.forEach((item) => {
                    item.groupName = item[this.itemKey]
                })
            }
            return options
        },
    },
    watch: {},
    created() {},
    mounted() {},
    methods: {
        selectTreeNode(item) {
            this.$emit('selectTreeNode', item)
        },
        addTreeNode(item) {
            this.$emit('addTreeNode', item)
        },
        deleteTreeNode(item) {
            this.$emit('deleteTreeNode', item)
        },
    },
}
</script>

<style scoped></style>
