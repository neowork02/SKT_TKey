import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT, // 조직트리
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, // 대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, // 대리점명
        },
        {
            fieldName: 'agreeYn',
            dataType: ValueType.TEXT, // 동의여부
        },
        {
            fieldName: 'spbillNum',
            dataType: ValueType.TEXT, // 분리과금번호
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, // 비고
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT, // 최초등록시간
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 최초수정시간
        },
        {
            fieldName: 'updBtn',
            dataType: ValueType.TEXT, // 수정버튼
        },
        {
            fieldName: 'chkBizLicence',
            dataType: ValueType.TEXT, // 사업자등록증수령여부
        },
        {
            fieldName: 'ipAddr',
            dataType: ValueType.TEXT, // ip주소
        },
        {
            fieldName: 'smsPcodeYn',
            dataType: ValueType.TEXT, // smsP코드여부
        },
        {
            fieldName: 'smsAgencyTel',
            dataType: ValueType.TEXT, // sms대리점번호
        },
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, // seq
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT, // 삭제여부
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, // update count
        },
    ],
    columns: [
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
            width: '80',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점명',
                showTooltip: false,
            },
            width: '80',
        },
        {
            name: 'agreeYn',
            fieldName: 'agreeYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '동의여부',
                showTooltip: false,
            },
            width: '50',
        },
        {
            name: 'spbillNum',
            fieldName: 'spbillNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '분리과금번호',
                showTooltip: false,
            },
            width: '80',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초등록시간',
                showTooltip: false,
            },
            width: '130',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초수정시간',
                showTooltip: false,
            },
            width: '130',
        },
        {
            name: 'updBtn',
            fieldName: 'updBtn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수정',
                showTooltip: false,
            },
            editable: false,
            renderer: {
                type: 'button',
            },
            width: '50',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'chkBizLicence',
            fieldName: 'chkBizLicence',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사업자등록증수령여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'ipAddr',
            fieldName: 'ipAddr',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'ip주소',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'smsPcodeYn',
            fieldName: 'smsPcodeYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'smsP코드여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'smsAgencyTel',
            fieldName: 'smsAgencyTel',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'sms대리점번호',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'seq',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'delYn',
            fieldName: 'delYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '삭제여부',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'update count',
                showTooltip: false,
            },
            visible: false,
        },
    ],
}
