import { ValueType } from 'realgrid'

export const DisOpnProdInsBarcdGRID_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사명
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'qty',
            dataType: ValueType.NUMBER, //수량
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER, //단가
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'barCdTyp',
            dataType: ValueType.TEXT, //바코드타입
        },
        {
            fieldName: 'prchTyp',
            dataType: ValueType.TEXT, //구매유형
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TENUMBERXT, // 수정횟수
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'openYn',
            dataType: ValueType.TEXT, //개봉상태
        },
        {
            fieldName: 'toOpenYn',
            dataType: ValueType.TEXT, //상품변경
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '100',
            editable: false,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            width: '150',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '150',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            editable: false,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
            },
            header: {
                text: '색상',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            editable: true,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량여부',
                showTooltip: false,
            },
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고상태',
                showTooltip: false,
            },
        },
        {
            name: 'qty',
            fieldName: 'qty',
            type: 'data',
            width: '80',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            width: '80',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            visible: false,
            type: 'data',
        },
        {
            name: 'barCdTyp',
            fieldName: 'barCdTyp',
            visible: false,
            type: 'data',
        },
        {
            name: 'prchTyp',
            fieldName: 'prchTyp',
            visible: false,
            type: 'data',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            visible: false,
            type: 'data',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'openYn',
            fieldName: 'openYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'toOpenYn',
            fieldName: 'toOpenYn',
            visible: false,
            type: 'data',
        },
    ],
}
