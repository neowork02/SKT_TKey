import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        // 납부기한
        // 서비스관리번호
        // 대리점코드
        // 서브점코드
        // 거래구분???
        {
            fieldName: 'arSeq', //매출순번 <<-- 반드시잇어야한다***조정내역 조회조건임
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgArSeq', //원매출순번 <<-- 반드시잇어야한다***조정내역 조회조건임
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtm', // 판매일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wrtDt', // 전기일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'evdDt', // 증빙일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refId', // 판매/출고번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refSeq', // 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleClNm', // 판매구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleClCd', // 판매구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arClNm', // 매출항목
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arClCd', // 매출항목코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlNm', // 영업채널
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlCd', // 영업채널코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleShopCd', // 판매처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoNm', // 판매처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd', // 판매처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 정산처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 상품명코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleQty', // 수량
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleAmt', // 판매가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'splyPrc', // 공급가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'wrtDt',
            fieldName: 'wrtDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전기일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'evdDt',
            fieldName: 'evdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '증빙일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'refId',
            fieldName: 'refId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매/출고번호',
        },
        {
            name: 'refSeq',
            fieldName: 'refSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '순번',
        },
        {
            name: 'saleClNm',
            fieldName: 'saleClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매구분',
        },
        {
            name: 'arClNm',
            fieldName: 'arClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매출항목',
        },
        {
            name: 'saleChnlNm',
            fieldName: 'saleChnlNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '영업채널',
        },
        {
            name: 'saleShopCd',
            fieldName: 'saleShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처매장코드',
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처',
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처명',
        },
        {
            name: 'accShopCd',
            fieldName: 'accShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처매장코드',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처명',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품명',
        },
        {
            name: 'saleQty',
            fieldName: 'saleQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '수량',
            numberFormat: '#,##0',
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매가',
            numberFormat: '#,##0',
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공급가',
            numberFormat: '#,##0',
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '부가세',
            numberFormat: '#,##0',
        },
    ],
}

export const DETAIL_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 신규저장시 1 입력
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'oldWrtDt', // <<---- 화면에만 있는건지 모르겟음..일단정의해둠
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trClNm', // 거래구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trClCd', // 거래구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arClNm', // 매출항목
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arClCd', // 매출항목코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 상품코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleQty', // 수량
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'splyPrc', // 공급가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totAmt', // 합계 <-- 화면에만있음
            dataType: ValueType.NUMBER,
            valueExpression: "values['splyPrc'] + values['vatAmt']",
        },
        {
            fieldName: 'rmks', // 조정사유
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAmt', // 판매가 <<--- 화면에없음
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleShopCd', // 판매처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 정산처매장코드
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'trClNm',
            fieldName: 'trClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래구분',
            editable: false,
        },
        {
            name: 'arClNm',
            fieldName: 'arClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매출항목',
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품',
            editable: false,
        },
        {
            name: 'saleQty',
            fieldName: 'saleQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '수량',
            editable: false,
            numberFormat: '#,##0',
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공급가',
            editable: true,
            numberFormat: '#,##0',
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '부가세',
            editable: true,
            numberFormat: '#,##0',
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '합계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            editable: false,
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: '조정사유',
            editable: false,
        },
    ],
}
