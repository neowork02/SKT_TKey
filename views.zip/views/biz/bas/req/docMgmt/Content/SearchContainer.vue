<template>
    <div>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="regBtn"
                    :objAuth="this.objAuth"
                >
                    요건서 등록
                </TCComButton>
            </li>
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="요청구분"
                        v-model="formSearchParams.reqClCd"
                        :itemList="searchCode[0]"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    />
                </div>
                <div class="formitem div3">
                    <TCComDatePicker
                        v-model="schdDt"
                        :calType="calType5"
                        labelName="요청일자"
                    />
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        labelName="요청대리점"
                        v-model="searchAuthOrgParam.orgNm"
                        :codeVal.sync="searchAuthOrgParam.orgCd"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <!-- <TCComComboBox
                        v-model="payClCd"
                        codeId="ZSAL_C_00080"
                        labelName="수납방법"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="objAuth"
                    ></TCComComboBox> -->
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div3">
                    <TCComInput
                        v-model="formSearchParams.reqUserNm"
                        labelName="요청자"
                        :size="150"
                        :maxlength="20"
                        :objAuth="objAuth"
                        @input="inputEvent()"
                        @enterKey="searchBtn"
                    />
                    <!-- <TCComInputSearchText
                        labelName="조직"
                        v-model="searchAuthOrgParam.orgNm"
                        :codeVal.sync="searchAuthOrgParam.orgCd"
                        :eRequired="true"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    /> -->
                </div>
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="진행상태"
                        v-model="formSearchParams.reqStNm"
                        :itemList="searchCode[1]"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    />
                    <!-- <TCComInputSearchText
                        v-model="searchParamAgency.agencyNm"
                        :codeVal.sync="searchParamAgency.agencyCd"
                        labelName="대리점"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAgencyEnterKey"
                        @appendIconClick="onAgencyIconClick"
                        @input="onAgencyInput"
                    /> -->
                </div>
                <div class="formitem div3">
                    <TCComInput
                        v-model="formSearchParams.reqTitle"
                        labelName="요건명"
                        :size="150"
                        :maxlength="100"
                        :objAuth="objAuth"
                        @input="inputEvent()"
                        @enterKey="searchBtn"
                    />
                    <!-- <TCComInputSearchText
                        v-model="searchSwingDealIfForm.orgNm"
                        :codeVal.sync="searchSwingDealIfForm.sktSubCd"
                        labelName="수납처"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onSwingDealIfEnterKey"
                        @appendIconClick="onSwingDealIfIconClick"
                        @input="onSwingDealIfInput"
                    /> -->
                </div>
            </div>
            <!-- <div class="searchform">
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchProdForm.prodNm"
                        :codeVal.sync="searchProdForm.prodCd"
                        labelName="모델"
                        :disabledAfter="true"
                        :appendIconShow="true"
                        :appendIconClass="''"
                        @enterKey="onProdsEnterKey"
                        @appendIconClick="onProdsIconClick"
                        @input="onProdsInput"
                        :objAuth="objAuth"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="수납의뢰처"
                        v-model="searchDealParam2.accDealcoNm"
                        :codeVal.sync="searchDealParam2.accDealcoCd"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onInrDealcosEnterKey2"
                        @appendIconClick="onInrDealcosIconClick2"
                        @input="onInrDealcosInput2"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="정산처"
                        v-model="searchDealParam.accDealcoNm"
                        :codeVal.sync="searchDealParam.accDealcoCd"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onInrDealcosEnterKey"
                        @appendIconClick="onInrDealcosIconClick"
                        @input="onInrDealcosInput"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.payChgrgUserId"
                        labelName="Swing처리자"
                        :size="150"
                        :maxlength="15"
                        :objAuth="objAuth"
                        @input="inputEvent()"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.svcMgmtNum"
                        labelName="서비스관리번호"
                        :size="150"
                        :maxlength="10"
                        :objAuth="objAuth"
                        @input="inputEvent()"
                    />
                </div>
            </div> -->
        </div>
        <BasBcoAuthOrgTreesPopup
            v-if="showBcoAuthOrgTrees"
            :parentParam="searchAuthOrgParam"
            :rows="resultAuthOrgTreeRows"
            :dialogShow.sync="showBcoAuthOrgTrees"
            @confirm="onAuthOrgTreeReturnData"
        />
        <BasBcoProdsPopup
            v-if="basBcoProdsShow"
            :parentParam="searchProdForm"
            :rows="resultProdsRows"
            :dialogShow.sync="basBcoProdsShow"
            @confirm="onProdsReturnData"
        />
        <BasBcoInrDealcosPopup
            v-if="showBasBcoInrDealcos"
            :parentParam="searchDealParam"
            :rows="resultInrDealcosRows"
            :dialogShow.sync="showBasBcoInrDealcos"
            @confirm="onInrDealcosReturnData"
        />
        <BasBcoInrDealcosPopup2
            v-if="showBasBcoInrDealcos2"
            :parentParam="searchDealParam2"
            :rows="resultInrDealcosRows2"
            :dialogShow.sync="showBasBcoInrDealcos2"
            @confirm="onInrDealcosReturnData2"
        />
        <BasBcoTbasDealIfPopup
            v-if="basBcoSwingDealIfShow"
            :parentParam="searchSwingDealIfForm"
            :rows="resultSwingDealIfRows"
            :dialogShow.sync="basBcoSwingDealIfShow"
            @confirm="onSwingDealIfReturnData"
        />
        <BasBcoAgencysPopup
            v-if="showBcoAgencys"
            :parentParam="searchParamAgency"
            :rows="resultAgencyRows"
            :dialogShow.sync="showBcoAgencys"
            @confirm="onAgencyReturnData"
        />
        <!-- <Detail1Popup
            v-if="showPopup1"
            :parentParam="searchPopup1"
            :rows="resultPopup1Rows"
            :dialogShow.sync="showPopup1"
            @confirm="onPopup1ReturnData"
        /> -->
    </div>
</template>
<script>
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/docMgmt/helpers'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
//import CommonUtil from '@/utils/CommonUtil.js'
// eslint-disable-next-line no-unused-vars
import { msgTxt } from '@/const/msg.Properties.js'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees' //--BasReqDaySalePrst.vue code 사용참조
//====================//내부조직팝업(권한)팝업====================
//====================모델(상품팝업)====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//모델(상품팝업)==================
//====================내부거래처 팝업====================
import BasBcoInrDealcosPopup from '@/components/common/BasBcoInrDealcosPopup'
import basBcoInrDealcosApi from '@/api/biz/bas/bco/BasBcoInrDealcos'
import BasBcoInrDealcosPopup2 from '@/components/common/BasBcoInrDealcosPopup'
//====================내부거래처 팝업====================
//====================SWING대리점/서브점/판매점팝업====================
import BasBcoTbasDealIfPopup from '@/components/common/BasBcoTbasDealIfPopup'
import basBcoTbasDealIfPopApi from '@/api/biz/bas/bco/basBcoTbasDealIfPop'
//====================//SWING대리점/서브점/판매점팝업==================
//====================대리점팝업====================
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
//====================//대리점팝업====================

//====================팝업1 팝업====================
//import Detail1Popup from './Detail1Popup'
//import Detail1Popup from '@/views/biz/bas/req/docRgst/BasReqDocRgst.vue'
//====================//팝업1 팝업====================
import CommonMixin from '@/mixins'
export default {
    mixins: [CommonMixin],
    components: {
        //TCComComboBox,
        BasBcoAuthOrgTreesPopup,
        BasBcoProdsPopup,
        BasBcoInrDealcosPopup,
        BasBcoInrDealcosPopup2,
        BasBcoTbasDealIfPopup,
        BasBcoAgencysPopup,
        //Detail1Popup,
    },
    async created() {
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            calType5: 'D', //'M' //'DP' //'D'
            schdDt: '', //[],
            searchCode: [
                [
                    {
                        commCdVal: '신규요건',
                        commCdValNm: '신규요건',
                    },
                    {
                        commCdVal: '변경요건',
                        commCdValNm: '변경요건',
                    },
                    {
                        commCdVal: '오류수정',
                        commCdValNm: '오류수정',
                    },
                    {
                        commCdVal: '데이타보정',
                        commCdValNm: '데이타보정',
                    },
                    {
                        commCdVal: '데이타추출',
                        commCdValNm: '데이타추출',
                    },
                    {
                        commCdVal: '운영업무',
                        commCdValNm: '운영업무',
                    },
                ],
                [
                    {
                        commCdVal: '요청',
                        commCdValNm: '요청',
                    },
                    {
                        commCdVal: '승인',
                        commCdValNm: '승인',
                    },
                    {
                        commCdVal: '반려',
                        commCdValNm: '반려',
                    },
                    {
                        commCdVal: '취소',
                        commCdValNm: '취소',
                    },
                    {
                        commCdVal: '진행',
                        commCdValNm: '진행',
                    },
                    // {
                    //     commCdVal: '1차테스트',
                    //     commCdValNm: '1차테스트',
                    // },
                    // {
                    //     commCdVal: '2차테스트',
                    //     commCdValNm: '2차테스트',
                    // },
                    {
                        commCdVal: '배포',
                        commCdValNm: '배포',
                    },
                    {
                        commCdVal: '취소',
                        commCdValNm: '취소',
                    },
                    // {
                    //     commCdVal: '완료',
                    //     commCdValNm: '완료',
                    // },
                ],
            ],
            //clsDt: '',
            payDtFrom: '',
            payDtTo: '',
            orgCd: '' /*조직코드*/,

            formSearchParams: {
                reqDt: '',
                reqDtFrom: '',
                reqDtTo: '',
                uuid: '',
                reqClCd: '',
                reqOrgCd: '',
                reqUserNm: '',
                reqStNm: '',
                reqTitle: '',
                devClCd: '',
            },
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchAuthOrgParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                orgLvl: '',
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================모델(상품팝업관련)====================
            basBcoProdsShow: false,
            searchProdForm: {
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
            },
            resultProdsRows: [],
            //====================//모델(상품팝업관련)==================
            //====================내부거래처 팝업====================
            showBasBcoInrDealcos: false,
            searchDealParam: {
                accDealcoCd: '',
                accDealcoNm: '',
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultInrDealcosRows: [],
            //====================내부거래처 팝업====================
            //====================내부거래처 팝업 2====================
            showBasBcoInrDealcos2: false,
            searchDealParam2: {
                accDealcoCd: '',
                accDealcoNm: '',
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultInrDealcosRows2: [],
            //====================내부거래처 팝업 2====================
            //==================== 개통처 : SWING대리점/서브점/판매점팝업관련====================
            basBcoSwingDealIfShow: false,
            searchSwingDealIfForm: {
                sktOrgClCd: '06', // 조직구분
                sktOrgCd: '', // 대리점코드
                orgNm: '', // 조직명
                sktSubCdNm: '', // 서브점코드
                sktSubCd: '',
            },
            resultSwingDealIfRows: [],
            //====================// 개통처 : SWING대리점/서브점/판매점팝업관련==================
            //====================//대리점팝업관련==================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            searchParamAgency: {
                orgCd: '',
                orgNm: '',
                agencyRgstCl: '', // 대리점등록구분
                agencyTypCd: '', // 대리점유형
                agencyPtn: '', // 대리점구분코드
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
                searchDateModel: '', // 조회기준일(v-model)
                searchDate: '', // 조회기준일
            },
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
            // //====================팝업1 팝업관련====================
            // showPopup1: false, // 팝업1 팝업 오픈 여부
            // searchPopup1: {},
            // resultPopup1Rows: [], // 팝업1 팝업 오픈 여부
            // //====================//팝업1 팝업관련==================
        }
    },
    async mounted() {
        //화면초기 로딩시 바로 검색
        this.searchBtn()
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        copyObjExist(obj1, obj2) {
            Object.keys(obj2).forEach(function (key) {
                if (key in obj1) {
                    obj1[key] = _.isEmpty(obj2[key]) ? '' : obj2[key]
                }
            })
        },
        initObj(obj1) {
            for (let prop in obj1) {
                if (Object.prototype.hasOwnProperty.call(obj1, prop)) {
                    obj1[prop] = ''
                }
            }
        },
        async initData() {
            //let today = moment(new Date()).add(-7, 'd').format('YYYY-MM-DD')
            let today1 = moment(new Date()).format('YYYY-MM-DD')
            //this.schdDt = [today, today1]
            this.schdDt = today1

            this.searchAuthOrgParam.orgNm = '' /*조직코드*/
            this.searchAuthOrgParam.orgLvl = '' /*조직코드*/
            this.searchAuthOrgParam.orgCd = '' /*조직코드*/
            this.searchProdForm.prodCd = ''
            this.searchProdForm.prodNm = ''
            this.searchDealParam.accDealcoCd = ''
            this.searchDealParam.accDealcoNm = ''
            this.searchDealParam2.accDealcoCd = ''
            this.searchDealParam2.accDealcoNm = ''

            this.searchParamAgency.agencyCd = ''
            this.searchParamAgency.agencyNm = ''
            this.searchParamAgency.orgNm = ''
            this.searchParamAgency.orgCd = ''

            this.searchSwingDealIfForm.sktOrgCd = ''
            this.searchSwingDealIfForm.orgNm = ''
            this.searchSwingDealIfForm.sktSubCd = ''
            this.searchSwingDealIfForm.sktSubCdNm = ''

            this.initObj(this.formSearchParams)

            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
        },
        async initBtn() {
            await this.initData()
            //this.searchBtn() //이화면은 초기화가 다시 조회처리

            //CommonUtil.clearPage(this.$router)
        },
        async regBtn() {
            //this.searchPopup1 = {} //추가
            //this.showPopup1 = true
            console.log('요건서등록 flag on')
            await this.defaultAssign_({
                key: 'popupOpenNew',
                value: true,
            })
            this.$nextTick(() => {
                this.defaultAssign_({
                    key: 'popupOpenNew',
                    value: false,
                })
            })
        },
        async searchBtn() {
            // let payDtFrom = new Date(this.schdDt[0])
            // let payDtTo = new Date(this.schdDt[1])
            // if (payDtFrom > payDtTo) {
            //     this.showTcComAlert('시작일자가 마지막일자 보다 큽니다.')
            //     return
            // }
            // if (
            //     moment(payDtFrom).format('YYYY-MM') !=
            //         moment(payDtTo).format('YYYY-MM') &&
            //     _.isEmpty(this.formSearchParams.svcMgmtNum)
            // ) {
            //     this.showTcComAlert('같은 월 검색만 됩니다.')
            //     return
            // }
            // if (_.isEmpty(this.searchAuthOrgParam.orgCd)) {
            //     this.showTcComAlert('조직은 필수 입니다.')
            //     return //test 시 조건 해제
            // }

            // //this.formSearchParams.clsDt = this.clsDt.replace(/-/g, '')
            // this.formSearchParams.payDtFrom = this.schdDt[0].replace(/-/g, '')
            // this.formSearchParams.payDtTo = this.schdDt[1].replace(/-/g, '')

            this.formSearchParams.reqDt = this.schdDt.replace(/-/g, '')
            this.formSearchParams.reqOrgCd = this.searchAuthOrgParam.orgCd
            // this.formSearchParams.orgLvl = this.searchAuthOrgParam.orgLvl
            // this.formSearchParams.agencyCd = this.searchParamAgency.agencyCd //대리점
            // this.formSearchParams.sktSubCd = this.searchSwingDealIfForm.sktSubCd //수납처

            await this.defaultAssign_({ key: 'paging', value: this.initPaging })

            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 197 ~ searchBtn ~ this.formSearchParams',
                this.formSearchParams
            )
            let par1 = _.clone(this.formSearchParams)

            // Test data
            // let par1 = {
            //     reqDt: '',
            //     reqDtFrom: '',
            //     reqDtTo: '',
            //     uuid: '',
            //     reqClCd: '',
            //     reqOrgCd: '',
            //     reqUserNm: '',
            //     reqStNm: '',
            //     reqTitle: '',
            //     devClCd: '',
            // }

            await this.defaultAssign_({
                key: 'searchParams',
                value: par1,
            })
            //페이징 조회 ------------------------------
            //await this.searchData()

            //전체조회 --------------------------------
            await this.searchAllData(par1)
        },
        // async searchData() {
        //     //페이징 조회 ------------------------------
        //     await this.getBasReqDocMgmtList_()
        // },
        async searchAllData(param1) {
            //전체조회 --------------------------------
            let data = await this.getBasReqDocMgmtDetails_({
                param: param1,
            })
            if (data.length > 0) {
                await this.defaultAssign_({
                    key: 'resultList',
                    value: data,
                })
            } else {
                await this.defaultAssign_({
                    key: 'resultList',
                    value: [],
                })
            }
        },
        async inputEvent() {},
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchAuthOrgParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchAuthOrgParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchAuthOrgParam.orgNm = _.get(res[0], 'orgNm')
                        this.searchAuthOrgParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchAuthOrgParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            this.onAuthOrgTreeIconClick()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchAuthOrgParam.orgCd = ''
            this.searchAuthOrgParam.orgLvl = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchAuthOrgParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchAuthOrgParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchAuthOrgParam.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 모델(상품팝업관련 methods) ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                console.log('getProdsList : ', res)
                if (res.length === 1) {
                    this.searchProdForm.prodCd = _.get(res[0], 'prodCd')
                    this.searchProdForm.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.searchProdForm.prodCd)) {
                this.getProdsList()
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchProdForm.prodCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchProdForm.prodNm = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchProdForm.prodCd = _.get(retrunData, 'prodCd')
            this.searchProdForm.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== // 모델(상품팝업관련 methods) ================================
        //====================내부거래처 팝업====================
        /* 정산처 조회 */
        onInrDealcosIconClick() {
            console.log('checking where1')
            this.searchDealParam.orgCd = this.searchAuthOrgParam.orgCd
            this.searchDealParam.orgNm = this.searchAuthOrgParam.orgNm
            this.resultInrDealcosRows = []
            if (!_.isEmpty(this.searchDealParam.accDealcoNm)) {
                this.getInrDealcosList()
            } else {
                this.showBasBcoInrDealcos = true
            }
        },
        onInrDealcosEnterKey() {
            this.resultInrDealcosRows = []
            if (_.isEmpty(this.searchDealParam.accDealcoNm)) {
                this.showTcComAlert('정산처명을 입력해주세요.')
                return
            }
            this.getInrDealcosList()
        },
        getInrDealcosList() {
            this.searchDealParam.orgCd = this.searchAuthOrgParam.orgCd
            this.searchDealParam.orgNm = this.searchAuthOrgParam.orgNm
            console.log('getList then : ', this.searchDealParam)

            const reqParams = {
                dealcoCd: this.searchDealParam.accDealcoCd,
                dealcoNm: this.searchDealParam.accDealcoNm,
            }
            basBcoInrDealcosApi.getList(reqParams).then((res) => {
                console.log('getList then : ', res)
                if (res.length === 1) {
                    this.searchDealParam.accDealcoCd = _.get(res[0], 'dealCoCd')
                    this.searchDealParam.accDealcoNm = _.get(res[0], 'dealCoNm')
                } else {
                    this.resultInrDealcosRows = res
                    this.showBasBcoInrDealcos = true
                }
            })
        },
        onInrDealcosInput() {
            this.searchDealParam.accDealcoCd = ''
        },
        onInrDealcosReturnData(retrunData) {
            console.log('retrunData: ', JSON.stringify(retrunData))
            this.searchDealParam.accDealcoCd = _.get(retrunData, 'dealcoCd')
            this.searchDealParam.accDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //====================내부거래처 팝업====================
        //====================내부거래처 팝업 2====================
        /* 수납의뢰처 조회 */
        onInrDealcosIconClick2() {
            this.searchDealParam2.orgCd = this.searchAuthOrgParam.orgCd
            this.searchDealParam2.orgNm = this.searchAuthOrgParam.orgNm
            this.resultInrDealcosRows2 = []
            if (!_.isEmpty(this.searchDealParam2.accDealcoNm)) {
                this.getInrDealcosList2()
            } else {
                this.showBasBcoInrDealcos2 = true
            }
        },
        onInrDealcosEnterKey2() {
            this.resultInrDealcosRows2 = []
            if (_.isEmpty(this.searchDealParam2.accDealcoNm)) {
                this.showTcComAlert('수납의뢰처명을 입력해주세요.')
                return
            }
            this.getInrDealcosList2()
        },
        getInrDealcosList2() {
            this.searchDealParam2.orgCd = this.searchAuthOrgParam.orgCd
            this.searchDealParam2.orgNm = this.searchAuthOrgParam.orgNm
            console.log('getList then : ', this.searchDealParam2)

            const reqParams = {
                dealcoCd: this.searchDealParam2.accDealcoCd,
                dealcoNm: this.searchDealParam2.accDealcoNm,
            }
            basBcoInrDealcosApi.getList(reqParams).then((res) => {
                console.log('getList then : ', res)
                if (res.length === 1) {
                    this.searchDealParam2.accDealcoCd = _.get(
                        res[0],
                        'dealCoCd'
                    )
                    this.searchDealParam2.accDealcoNm = _.get(
                        res[0],
                        'dealCoNm'
                    )
                } else {
                    this.resultInrDealcosRows2 = res
                    this.showBasBcoInrDealcos2 = true
                }
            })
        },
        onInrDealcosInput2() {
            this.searchDealParam2.accDealcoCd = ''
        },
        onInrDealcosReturnData2(retrunData) {
            console.log('retrunData: ', JSON.stringify(retrunData))
            this.searchDealParam2.accDealcoCd = _.get(retrunData, 'dealcoCd')
            this.searchDealParam2.accDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //====================내부거래처 팝업 2====================
        //===================== SWING대리점/서브점/판매점팝업 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getSwingDealIfPop() {
            this.searchSwingDealIfForm.sktOrgCd =
                this.searchParamAgency.agencyCd

            basBcoTbasDealIfPopApi
                .getTbasDealIfPop(this.searchSwingDealIfForm)
                .then((res) => {
                    console.log('getSwingDealIfPopdsList : ', res)
                    console.log('getList then : ', res)
                    if (res.length === 1) {
                        this.searchSwingDealIfForm.orgNm = _.get(
                            res[0],
                            'orgNm'
                        )
                        this.searchSwingDealIfForm.sktSubCd = _.get(
                            res[0],
                            'sktSubCd'
                        )
                    } else {
                        this.resultSwingDealIfRows = res
                        this.basBcoSwingDealIfShow = true
                    }
                })
        },
        onSwingDealIfIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultSwingDealIfRows = []
            if (!_.isEmpty(this.searchParamAgency.agencyCd)) {
                this.getSwingDealIfPop()
            } else {
                this.basBcoSwingDealIfShow = false
                this.showTcComAlert('대리점을 먼저 선택하세요.')
            }
        },
        // TextField 엔터키 이벤트 처리
        onSwingDealIfEnterKey() {
            // 팝업 Row 설정 Prop 변수 초기화
            this.resultSwingDealIfRows = []
            // 검색조건 명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchSwingDealIfForm.orgNm)) {
                this.showTcComAlert('수납처명을 입력해주세요.')
                return
            }
            if (_.isEmpty(this.searchSwingDealIfForm.sktOrgCd)) {
                this.onSwingDealIfIconClick()
            }
        },
        // 팝업 TextField Input 이벤트 처리
        onSwingDealIfInput() {
            // 입력되는 값이 있으면 코드 초기화
            // this.searchProdForm.prodNm = ''
            this.searchSwingDealIfForm.sktSubCd = ''
        },
        // 팝업 리턴 이벤트 처리
        onSwingDealIfReturnData(retrunData) {
            console.log('retrunData: ', JSON.stringify(retrunData))
            this.searchSwingDealIfForm.orgNm = _.get(retrunData, 'orgNm')
            this.searchSwingDealIfForm.sktSubCd = _.get(retrunData, 'sktSubCd')
        },
        //===================== //SWING대리점/서브점/판매점팝업 methods ================================
        //===================== 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getAgencyList() {
            this.searchParamAgency.orgCd = this.searchAuthOrgParam.orgCd
            this.searchParamAgency.orgNm = this.searchAuthOrgParam.orgNm

            basBcoAgencysApi
                .getAgencyList(this.searchParamAgency)
                .then((res) => {
                    console.log('getAgencyList then : ', res)
                    // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                    // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                    if (res.length === 1) {
                        this.searchParamAgency.agencyCd = _.get(
                            res[0],
                            'agencyCd'
                        )
                        this.searchParamAgency.agencyNm = _.get(
                            res[0],
                            'agencyNm'
                        )
                    } else {
                        this.resultAgencyRows = res
                        this.showBcoAgencys = true
                    }
                })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.searchParamAgency.agencyNm)) {
                this.getAgencyList()
            } else {
                this.showBcoAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParamAgency.agencyNm)) {
                this.showTcComAlert('대리점명을 입력해주세요.')
                return
            }
            // 대리점 정보 조회
            this.getAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.searchParamAgency.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParamAgency.agencyCd = _.get(retrunData, 'agencyCd')
            this.searchParamAgency.agencyNm = _.get(retrunData, 'agencyNm')
        },
        //===================== //대리점팝업관련 methods ================================
        //====================내부거래처 팝업====================
        // 팝업1 팝업 리턴 이벤트 처리
        async onPopup1ReturnData(returnData) {
            console.log('Popup1 returnData new: ', returnData)
            // this.gridObj.gridView.commit()
            // this.gridObj.dataProvider.setValue(
            //     this.popupRowIndex,
            //     'agencyCd',
            //     returnData.orgCd
            // )
            //저장후 다시 조회 하는 경우
            //this.$emit('Refresh')
            //this.searchBtn()
            await this.searchAllData(this.searchParams)
        },
    },
}
</script>
