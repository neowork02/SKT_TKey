import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'st',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comp',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'portalUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'attcClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTreeNm',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'orgCdNm',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'bizDivOrgCdNm',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'bizChrgOrgCdNm',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'teamOrgCdNm',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'ptOrgCdNm',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'sktDealCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orglDealCoCdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orglDealCoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effUserYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'biId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'empNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hanNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'deptCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'postDeptNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'jobGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'jobGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'posCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'posNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpstyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rpstyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dutyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dutyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'empSubGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'empSubGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chatyYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOfcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dutypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dutypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'costCntrCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'entDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'retirDt',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'st',
            fieldName: 'st',
            editable: false,
            header: {
                text: '매핑여부',
            },
        },
        {
            name: 'comp',
            fieldName: 'comp',
            editable: false,
            header: {
                text: '소속회사',
            },
        },
        {
            name: 'userCd',
            fieldName: 'userCd',
            editable: false,
            header: {
                text: '사번',
            },
        },
        {
            name: 'portalUserId',
            fieldName: 'portalUserId',
            editable: false,
            header: {
                text: '통합로그인ID',
            },
        },
        {
            name: 'userId',
            fieldName: 'userId',
            editable: false,
            header: {
                text: '사용자ID',
            },
        },
        {
            name: 'attcClCd',
            fieldName: 'attcClCd',
            editable: false,
            header: {
                text: '소속구분',
            },
        },
        {
            name: 'userGrpCd',
            fieldName: 'userGrpCd',
            editable: false,
            header: {
                text: '사용자그룹',
            },
        },
        {
            name: 'orgTreeNm',
            fieldName: 'orgTreeNm',
            editable: false,
            width: '400',
            header: {
                text: '조직',
            },
            styleName: 'left-column',
        },
        // {
        //     name: 'orgCdNm',
        //     fieldName: 'orgCdNm',
        //     header: {
        //         text: '관리조직',
        //     },
        // },
        // {
        //     name: 'bizDivOrgCdNm',
        //     fieldName: 'bizDivOrgCdNm',
        //     header: {
        //         text: '사업부',
        //     },
        // },
        // {
        //     name: 'bizChrgOrgCdNm',
        //     fieldName: 'bizChrgOrgCdNm',
        //     header: {
        //         text: '사업담당',
        //     },
        // },
        // {
        //     name: 'teamOrgCdNm',
        //     fieldName: 'teamOrgCdNm',
        //     header: {
        //         text: '팀/센터',
        //     },
        // },
        // {
        //     name: 'ptOrgCdNm',
        //     fieldName: 'ptOrgCdNm',
        //     header: {
        //         text: 'PT',
        //     },
        // },
        {
            name: 'sktDealCd',
            fieldName: 'sktDealCd',
            editable: false,
            header: {
                text: '근무지매장코드',
            },
        },
        {
            name: 'orglDealCoCdNm',
            fieldName: 'orglDealCoCdNm',
            editable: false,
            header: {
                text: '근무지',
            },
        },
        {
            name: 'orglDealCoCd',
            fieldName: 'orglDealCoCd',
            editable: false,
            header: {
                text: '근무지코드',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            editable: false,
            header: {
                text: '사용자명',
            },
        },
        {
            name: 'effUserYn',
            fieldName: 'effUserYn',
            editable: false,
            header: {
                text: '유효사용자여부',
            },
        },
        {
            name: 'biId',
            fieldName: 'biId',
            editable: false,
            header: {
                text: 'BI ID',
            },
        },
        {
            name: 'empNo',
            fieldName: 'empNo',
            editable: false,
            header: {
                text: '사번',
            },
        },
        {
            name: 'hanNm',
            fieldName: 'hanNm',
            editable: false,
            header: {
                text: '이름',
            },
        },
        {
            name: 'deptCd',
            fieldName: 'deptCd',
            editable: false,
            header: {
                text: '부서코드',
            },
        },
        {
            name: 'postDeptNm',
            fieldName: 'postDeptNm',
            editable: false,
            header: {
                text: '부서명',
            },
        },
        {
            name: 'jobGrpCd',
            fieldName: 'jobGrpCd',
            editable: false,
            header: {
                text: '직군코드',
            },
        },
        {
            name: 'jobGrpNm',
            fieldName: 'jobGrpNm',
            editable: false,
            header: {
                text: '직군',
            },
        },
        {
            name: 'posCd',
            fieldName: 'posCd',
            editable: false,
            header: {
                text: '직위코드',
            },
        },
        {
            name: 'posNm',
            fieldName: 'posNm',
            editable: false,
            header: {
                text: '직위명',
            },
        },
        {
            name: 'rpstyCd',
            fieldName: 'rpstyCd',
            editable: false,
            header: {
                text: '직책코드',
            },
        },
        {
            name: 'rpstyNm',
            fieldName: 'rpstyNm',
            editable: false,
            header: {
                text: '직책명',
            },
        },
        {
            name: 'dutyCd',
            fieldName: 'dutyCd',
            editable: false,
            header: {
                text: '직무코드',
            },
        },
        {
            name: 'dutyNm',
            fieldName: 'dutyNm',
            editable: false,
            header: {
                text: '직무명',
            },
        },
        {
            name: 'empSubGrpCd',
            fieldName: 'empSubGrpCd',
            editable: false,
            width: '120',
            header: {
                text: '사원하위그룹코드',
            },
        },
        {
            name: 'empSubGrpNm',
            fieldName: 'empSubGrpNm',
            editable: false,
            header: {
                text: '사원하위그룹명',
            },
        },
        {
            name: 'chatyYn',
            fieldName: 'chatyYn',
            editable: false,
            header: {
                text: '장애여부',
            },
        },
        {
            name: 'inOfcNm',
            fieldName: 'inOfcNm',
            editable: false,
            header: {
                text: '재직/휴직 구분',
            },
        },
        {
            name: 'dutypCd',
            fieldName: 'dutypCd',
            editable: false,
            header: {
                text: '근무장소 코드',
            },
        },
        {
            name: 'dutypNm',
            fieldName: 'dutypNm',
            editable: false,
            header: {
                text: '근무장소명',
            },
        },
        {
            name: 'costCntrCd',
            fieldName: 'costCntrCd',
            editable: false,
            header: {
                text: '코스트센터',
            },
        },
        {
            name: 'entDt',
            fieldName: 'entDt',
            editable: false,
            header: {
                text: '입사일자',
            },
        },
        {
            name: 'retirDt',
            fieldName: 'retirDt',
            editable: false,
            header: {
                text: '퇴사일자',
            },
        },
    ],
}
