<template>
    <TCComDialog :dialogShow.sync="activeOpen1" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">승인</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- <ul class="btn_area top">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                @click="onUserCancel"
                                :objAuth="objAuth"
                            >
                                사용자취소
                            </TCComButton>
                        </li>
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="onConfirm"
                                :objAuth="objAuth"
                            >
                                저장
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="onClose"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton>
                        </li>
                    </ul> -->
                    <!-- <div class="stitHead pop">
                        <h4 class="subTit">승인</h4>
                    </div> -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="parentParam1.aprvOrgNmView"
                                    labelName="승인조직"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                            <div class="formitem div2"></div>
                        </div>
                        <!-- // Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="parentParam1.aprvDtl"
                                    labelName="고려사항/제한조건"
                                    labelClass="line2"
                                    class="boxtype"
                                    :rows="10"
                                    :maxlength="5000"
                                ></TCComTextArea>
                                <!-- <TCComInput
                                    v-model="parentParam1.aprvDtl"
                                    labelName="고려사항/제한조건"
                                    labelClass="line2"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :disabled="true"
                                ></TCComInput> -->
                            </div>
                        </div>
                        <!-- // Search_line 2 -->
                        <!-- Search_line 3 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="parentParam1.aprvUserNmView"
                                    labelName="승인자"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :disabled="true"
                                ></TCComInput>
                            </div>
                            <div class="formitem div2"></div>
                        </div>
                        <!-- // Search_line 3 -->
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
                <!-- <Detail2Popup
                    v-if="showPopup2"
                    :parentParam="searchPopup2"
                    :rows="resultPopup2Rows"
                    :dialogShow.sync="showPopup2"
                    @confirm2="onPopup2ReturnData"
                /> -->
                <!-- <BasBcoInrDealcosPopup
                    v-if="showBasBcoInrDealcos"
                    :parentParam="searchDealParam"
                    :rows="resultInrDealcosRows"
                    :dialogShow.sync="showBasBcoInrDealcos"
                    @confirm="onInrDealcosReturnData"
                /> -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/docMgmt/helpers'
// eslint-disable-next-line no-unused-vars
import commonApi from '@/api/common/commonCode'
// eslint-disable-next-line no-unused-vars
import { CommonMsg, CommonBizClosing } from '@/utils'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
import CommonMixin from '@/mixins'
// //====================팝업1 팝업====================
// import Detail2Popup from './Detail2Popup'
// //====================//팝업1 팝업====================
// //====================내부거래처 팝업====================
// import BasBcoInrDealcosPopup from '@/components/common/BasBcoInrDealcosPopup'
// import basBcoInrDealcosApi from '@/api/biz/bas/bco/BasBcoInrDealcos'
// //====================내부거래처 팝업====================

export default {
    mixins: [CommonMixin],
    components: {
        //Detail2Popup,
        //BasBcoInrDealcosPopup,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            objAuth: {},
            parentParam0: [],
            parentParam1: {
                aprvOrgCd: '',
                aprvOrgNm: '',
                aprvOrgNmView: '',
                aprvUserId: '',
                aprvUserNm: '',
                aprvUserNmView: '',
                aprvDtl: '',
            },
            //parentParam_origin: {},
            //lastClsDtm: '', //마감일자
            saveParam: {},
            userCancelSave: false,
            // //====================팝업1 팝업관련====================
            // showPopup2: false, // 팝업1 팝업 오픈 여부
            // searchPopup2: {},
            // resultPopup2Rows: [], // 팝업1 팝업 오픈 여부
            // //====================//팝업1 팝업관련==================
            // //====================내부거래처 팝업====================
            // showBasBcoInrDealcos: false,
            // searchDealParam: {
            //     accDealcoCd: '',
            //     accDealcoNm: '',
            // },
            // resultInrDealcosRows: [],
            // //====================내부거래처 팝업====================
        }
    },
    created() {
        //this.init()
    },
    mounted() {
        //this.gridObj = this.$refs.agencyMgmtAgencyGrid // Grid Object 설정
        //this.initGrid()
    },
    computed: {
        ...serviceComputed,
        activeOpen1: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        ...serviceMethods,
        async init() {
            this.parentParam0 = []
            this.parentParam1 = {}
            this.saveParam = {}
            this.userCancelSave = false

            //this.searchDealParam.accDealcoCd = ''
            //this.searchDealParam.accDealcoNm = ''
        },
        async onConfirm() {
            const check1 = await this.checkCloseDate()
            if (!check1) {
                return
            }
            await this.save()
            console.log('onConfirm done')
            this.$emit('confirm', this.saveParam)
            this.onClose()
        },
        // onUserCancel() {
        //     const dtl1 = this.parentParam_origin
        //     this.resultPopup2Rows = []
        //     this.searchPopup2 = {
        //         nsokReqSerNo: dtl1.nsokReqSerNo,
        //         opDt: dtl1.opDt,
        //         opTm: dtl1.opTm,
        //         opSeq: dtl1.opSeq,
        //         rmks: '', //'비고',
        //     }
        //     this.showPopup2 = true
        //     console.log('UserCancel Popup', this.searchPopup2)
        // },
        onClose() {
            if (this.userCancelSave) {
                this.$emit('confirm', this.saveParam)
            }
            this.activeOpen1 = false
        },

        onSearch() {
            //this.getAgencyList()
        },

        onEnterKey() {
            //this.onSearch()
        },
        // async cfGetClsStatus(sMonthDayCl, sStrdDt, sWorkClCd, sOrgId = '*') {
        //     const clsStatus = await CommonBizClosing.getClsStatus(
        //         sMonthDayCl,
        //         sStrdDt,
        //         sWorkClCd,
        //         sOrgId
        //     )
        //     console.log('cfGetClsStatus', clsStatus)
        //     this.lastClsDtm = clsStatus.lastClsDtm
        //     if (clsStatus && 'CLS' == clsStatus.clsStCd) {
        //         //this.showTcComAlert(CommonMsg.getMessage('MSG_00185', ''))
        //         return false
        //     }
        //     return true
        // },
        async checkCloseDate() {
            console.log('checkCloseDate', this.parentParam0)
            //const dtl1 = this.parentParam_origin //팝업에서 호출할 detail api value
            //const par1 = this.parentParam0 //전달 받은 value

            // let saleChgDtm = new Date(this.saleChgDtm)
            // let procDt1 = new Date(this.parentParam1.procDt)
            // let todatDt = new Date()
            // if (saleChgDtm > todatDt) {
            //     this.showTcComAlert('매출일자가 오늘일자 보다 큽니다.')
            //     return false
            // }

            const confirm = await this.showTcComConfirm(
                `${this.parentParam0.length}건을 저장 하시겠습니까?`
            )

            if (!confirm) {
                return false
            }
            return true
        },
        async save() {
            let saveRows = []
            const lng1 = this.parentParam0.length
            for (let i = 0; i < lng1; i++) {
                saveRows.push({
                    //...this.parentParam0[i],
                    rowState: 'updated',
                    reqDt: this.parentParam0[i].reqDt,
                    uuid: this.parentParam0[i].uuid,
                    reqStNm: '승인',
                    ...this.parentParam1,
                })
            }

            console.log('save 승인', saveRows)
            await this.saveDocMgmt_({ saveRows })
            this.saveParam = saveRows
        },
        maskingName(strName) {
            if (_.isEmpty(strName)) return strName
            if (strName.length > 2) {
                let originName = strName.split('')
                originName.forEach(function (name, i) {
                    if (i === 0 || i === originName.length - 1) return
                    originName[i] = '*'
                })
                let joinName = originName.join()
                return joinName.replace(/,/g, '')
            } else {
                let pattern = /.$/ // 정규식
                return strName.replace(pattern, '*')
            }
        },

        // // 팝업1 팝업 리턴 이벤트 처리
        // async onPopup2ReturnData(returnData) {
        //     console.log('onPopup2ReturnData: ', returnData)
        //     // this.gridObj.gridView.commit()
        //     // this.gridObj.dataProvider.setValue(
        //     //     this.popupRowIndex,
        //     //     'agencyCd',
        //     //     retrunData.orgCd
        //     // )
        //     // this.$emit('Refresh', '') //next paging api call
        //     this.userCancelSave = true
        //     this.saveParam = returnData

        //     //사용자취소처리 완료후 닫기 실행시 팝업창 닫기
        //     if (this.userCancelSave) {
        //         this.$emit('confirm', this.saveParam)
        //     }
        //     this.activeOpen1 = false
        // },
        // //====================내부거래처 팝업====================
        // /* 판매처 - 내부거래처 팝업 TextField 돋보기 Icon 이벤트 처리 */
        // onInrDealcosIconClick() {
        //     console.log('checking where1')
        //     this.resultInrDealcosRows = []
        //     if (!_.isEmpty(this.searchDealParam.accDealcoCd)) {
        //         this.showBasBcoInrDealcos = true
        //     } else {
        //         this.showBasBcoInrDealcos = true
        //     }
        // },
        // /* 판매처 - 내부거래처팝업(권한) TextField 엔터키 이벤트 처리 */
        // onInrDealcosEnterKey() {
        //     this.resultInrDealcosRows = []
        //     if (_.isEmpty(this.searchDealParam.accDealcoNm)) {
        //         this.showTcComAlert('판매처명을 입력해주세요.')
        //         return
        //     }
        //     this.getInrDealcosList()
        // },
        // getInrDealcosList() {
        //     const reqParams = {
        //         dealcoCd: this.searchDealParam.accDealcoCd,
        //         dealcoNm: this.searchDealParam.accDealcoNm,
        //     }
        //     basBcoInrDealcosApi.getList(reqParams).then((res) => {
        //         console.log('getList then : ', res)
        //         if (res.length === 1) {
        //             this.searchDealParam.accDealcoCd = _.get(res[0], 'dealCoCd')
        //             this.searchDealParam.accDealcoNm = _.get(res[0], 'dealCoNm')
        //         } else {
        //             this.resultInrDealcosRows = res
        //             this.showBasBcoInrDealcos = true
        //         }
        //     })
        // },
        // /* 판매처 - 내부거래처팝업(권한) TextField Input 이벤트 처리 */
        // onInrDealcosInput() {
        //     this.searchDealParam.accDealcoCd = ''
        //     this.searchDealParam.accDealcoNm = ''
        // },
        // /* 판매처 - 내부거래처팝업(권한) 팝업 리턴 이벤트 처리 */
        // onInrDealcosReturnData(retrunData) {
        //     if (retrunData.saleStopYn === 'Y') {
        //         this.showTcComAlert(
        //             '판매정지 거래처로 판매등록 할 수 없습니다.'
        //         )
        //     } else {
        //         this.searchDealParam.accDealcoCd = _.get(retrunData, 'dealcoCd')
        //         this.searchDealParam.accDealcoNm = _.get(retrunData, 'dealcoNm')
        //     }
        // },
        // //====================내부거래처 팝업====================
    },
    watch: {
        parentParam: {
            handler: async function (value) {
                console.log('receive popup param', value)
                //await this.init()
                // console.log('menuInfo', this.menuInfo) //메뉴정보
                // console.log('orgInfo', this.orgInfo) //조직정보
                // console.log('userInfo', this.userInfo) //사용자정보
                // console.log('authInfo', this.authInfo) // 권한정보(속성권한)

                // //test data end -----------------
                const lst1 = _.clone(value.chkList)
                this.parentParam0 = lst1

                //파라메터 포맷팅 -------------------------------
                this.parentParam1.aprvOrgCd = this.orgInfo.orgCd
                this.parentParam1.aprvOrgNm = this.orgInfo.orgNm
                this.parentParam1.aprvOrgNmView = this.orgInfo.orgNm
                this.parentParam1.aprvUserId = this.userInfo.userId
                this.parentParam1.aprvUserNm = this.userInfo.userNm
                this.parentParam1.aprvUserNmView = `${this.maskingName(
                    this.userInfo.userNm
                )}(${this.userInfo.userId})`

                console.log(
                    'receive 승인 popup param value',
                    this.parentParam0,
                    this.parentParam1
                )
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>
