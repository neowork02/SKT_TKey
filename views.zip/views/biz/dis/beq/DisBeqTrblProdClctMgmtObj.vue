<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">사고단말기 회수 대상 목록</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Top BTN -->
                    <ul class="btn_area top pop">
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="searchBtn"
                                >조회</TCComButton
                            >
                        </li>
                    </ul>
                    <!-- // Top BTN -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap mgb-10">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="dsConditionPopup.orgNm"
                                    :codeVal.sync="dsConditionPopup.orgCd"
                                    labelName="조직"
                                    :eRequired="true"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :disabled="true"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="dsConditionPopup.dealcoNm"
                                    :codeVal.sync="dsConditionPopup.dealcoCd"
                                    labelName="보유처"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onDealcoEnterKey"
                                    @appendIconClick="onDealcoIconClick"
                                    @input="onDealcoInput"
                                    :disabled="true"
                                />
                                <BasBcoChrgrDealcosPop
                                    v-if="showBasBcoChrgrDealcos"
                                    :parentParam="searchForm"
                                    :rows="resultDealcoRows"
                                    :dialogShow.sync="showBasBcoChrgrDealcos"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="Risk 중분류"
                                    v-model="dsConditionPopup.riskMclNm"
                                    :disabled="true"
                                />
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="일련번호"
                                    v-model="dsConditionPopup.serNum"
                                    @enterKey="onEnterKey"
                                />
                            </div>
                        </div>
                        <!-- //Search_line 1 -->
                    </div>
                    <!-- //Search_div -->
                    <!-- gridWrap -->
                    <TCRealGridHeader
                        id="gridHeader11"
                        ref="gridHeader11"
                        gridTitle="사고단말기 회수대상"
                        :gridObj="gridObjPop11"
                        :isPageRows="true"
                        :isExceldown="true"
                        @excelDownBtn="onClickDownload"
                    />
                    <TCRealGrid
                        id="grid11"
                        ref="grid11"
                        :fields="view.fields"
                        :columns="view.columns"
                        :styles="gridStyle"
                    />
                    <TCComPaging
                        :totalPage="gridData.totalPage"
                        :apiFunc="getPagingData"
                        :rowCnt="rowCnt"
                        :gridObj="gridObjPop11"
                        @input="chgRowCnt"
                    />
                    <!-- //gridWrap -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="btnConfirmOnclick"
                            >확인</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonGrid, CommonUtil } from '@/utils'
import _ from 'lodash'
import { SacCommon } from '@/views/biz/sac/js'

import { G_HEADER } from '@/const/grid/dis/beq/disBeqTrblProdClctMgmtObjHead'
import api from '@/api/biz/dis/beq/disBeqTrblProdClctMgmt'

import attachedFileApi from '@/api/common/attachedFile'

//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-영업담당자====================
import BasBcoChrgrDealcosPop from '@/components/common/BasBcoChrgrDealcosPopup'
import basBcoChrgrDealcosApi from '@/api/biz/bas/bco/basBcoChrgrDealcos'
//====================//내부거래처-영업담당자==================

export default {
    name: 'DisBeqTrblProdClctMgmtObj',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoChrgrDealcosPop,
    },
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            // main grid 영역
            gridObjPop11: {},
            gridHeaderObjPop11: {},
            gridData: this.GridSetData(),

            view: G_HEADER,
            dsResult: [],

            gridStyle: {
                height: '200px', //그리드 높이 조절
            },

            dsConditionPopup: {},
            dsRiskClct: [], // 부모창 데이터셋 ***

            dsSelect: [], // 선택한  rows

            objAuth: {}, // ?????

            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처-영업담당자====================
            showBasBcoChrgrDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: '', //거래처그룹코드
                dealcoClCd1: '', //거래처구분코드
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-영업담당자==================
            // paging
            rowCnt: 15, // 표시할 행의 갯수
            //조회 파라미터
            reqParams: {},
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    created() {},
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 초기값 세팅
        this.fInit()
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObjPop11 = this.$refs.grid11
            this.gridHeaderObjPop11 = this.$refs.gridHeader11
            this.gridObjPop11.gridView.displayOptions.fitStyle = 'even'
            this.gridObjPop11.setGridState(true, false, true)
            this.gridData = this.GridSetData()
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        fInit: function () {
            console.log('this.popupParams=============>> ', this.popupParams)

            this.dsConditionPopup = this.popupParams.dsCondition
            this.dsRiskClct = this.popupParams.dsRiskClct

            // 조직, 거래처 날짜세팅
            this.searchParam.basMth = CommonUtil.onlyNumber(
                this.dsConditionPopup.tranDt
            ).substr(0, 6)
            this.searchForm.basDay = CommonUtil.onlyNumber(
                this.dsConditionPopup.tranDt
            ).substr(0, 6)

            this.searchBtn()
        },
        // 일련번호 EnterKey Event
        onEnterKey() {
            let sSerNum = this.dsConditionPopup.serNum.replace('%', '')
            this.dsConditionPopup.serNum = sSerNum

            this.searchBtn()
        },
        // 조회 버튼 이벤트
        searchBtn() {
            if (this.fCheckCondition()) {
                this.dsResult = []
                this.gridObjPop11.setRows([])
                this.dsConditionPopup.pageSize = this.rowCnt
                this.gridData.totalPage = 0 // 이전페이지정보 초기화

                this.reqParams = this.dsConditionPopup
                this.getPagingData(1)
            }
        },
        getPagingData: function (pageNum) {
            console.log(pageNum)

            this.dsConditionPopup.pageNum = pageNum

            const formData = {
                dsCondition: {
                    ...this.dsConditionPopup,
                },
            }

            console.log('formData popup =========>', formData)
            this.dsResult = []
            this.gridObjPop11.setRows(this.dsResult)

            api.getTrblProdClctObjs(formData).then((resultData) => {
                console.log(resultData)

                this.dsResult = resultData.gridList
                this.gridObjPop11.setRows(this.dsResult)
                // 페이징 관련
                this.gridObjPop11.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData = this.GridSetData() //초기화
                this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObjPop11.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },
        fCheckCondition: function () {
            if (_.isEmpty(this.dsConditionPopup.orgCd)) {
                this.showTcComAlert('조직을 검색하신 후 조회 하시기 바랍니다.') //cf_getMessage(MSG_00083,'조직')
                return false
            }
            if (_.isEmpty(this.dsConditionPopup.dealcoCd)) {
                this.showTcComAlert(
                    '거래처를 검색하신 후 조회 하시기 바랍니다.'
                ) //cf_getMessage(MSG_00083,'거래처')
                return false
            }
            if (_.isEmpty(this.dsConditionPopup.riskMclCd)) {
                this.showTcComAlert(
                    'Risk 중분류를 검색하신 후 조회 하시기 바랍니다.'
                ) //cf_getMessage(MSG_00083,'Risk 중분류')
                return false
            }
            return true
        },
        btnConfirmOnclick: function () {
            console.log('확인')
            this.dsSelect = []

            const rows = this.gridObjPop11.gridView.getCheckedRows(true)
            if (0 == rows.length) {
                this.showTcComAlert('선택된 사고 단말기가 없습니다.')
                return
            }
            // 체크된 row를 dsSelect에 담는다
            for (let i in rows) {
                const idx = rows[i]
                const jsonRow = this.gridObjPop11.dataProvider.getJsonRow(idx)
                jsonRow.chk = 1
                this.dsSelect.push(jsonRow)
            }

            const removeArr = []

            _.forEach(this.dsSelect, (item) => {
                const filtered = _.filter(this.dsRiskClct, {
                    riskId: item.riskId,
                    riskIdSeq: item.riskIdSeq,
                })
                if (filtered.length > 0) {
                    removeArr.push(item)
                    // this.dsSelect.splice(idx, 1)
                    // console.log('제거후 dsSelect', this.dsSelect)
                } else if (!_.isEmpty(item.dtlRiskId)) {
                    const msg1 = item.riskMclNm + '/' + item.riskStNm
                    const msg2 =
                        '[' +
                        item.prodNm +
                        '/' +
                        item.colorNm +
                        '/' +
                        item.serNum +
                        '] 처리'
                    this.showTcComAlert(
                        msg1 + '입니다. ' + msg2 + '할 수 없습니다.'
                    )
                    //this.dsSelect.splice(idx, 1)
                    removeArr.push(item)
                }
            })

            if (removeArr.length > 0) {
                this.dsSelect = _.filter(this.dsSelect, (item) => {
                    return removeArr.indexOf(item) < 0
                })
            }

            console.log('this.dsSelect============>>>', this.dsSelect)

            if (this.dsSelect.length == 0) {
                this.showTcComAlert('모든 상품이 이미 등록 되어있습니다.')
                this.closeBtn()
            }

            // 부모창에 DATASET 던지기. 마약 동일한 일련번호의 상품이 존재하면 제외
            const obj = {
                postProcess: true,
                passDataset: this.dsSelect,
            }
            this.$emit('confirm', obj)
            this.activeOpen = false
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //Grid ExcelDown
        onClickDownload: function () {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/beq/trblProdClctObjsExcelDown',
                this.reqParams
            )
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.dsConditionPopup.orgCd
            this.searchParam.orgNm = this.dsConditionPopup.orgNm
            this.searchParam.orgLvl = this.dsConditionPopup.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(
                    SacCommon.objectRemovedArray(this.searchParam)
                )
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.dsConditionPopup.orgCd = _.get(res[0], 'orgCd')
                        this.dsConditionPopup.orgNm = _.get(res[0], 'orgNm')
                        this.dsConditionPopup.orgLvl = _.get(res[0], 'orgLvl')
                        this.searchForm.orgCd = this.dsConditionPopup.orgCd
                        this.searchForm.orgNm = this.dsConditionPopup.orgNm
                        this.searchForm.orgLvl = this.dsConditionPopup.orgLvl
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            console.log(this.dsConditionPopup)
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.dsConditionPopup.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsConditionPopup.orgNm)) {
                // this.headerText = '검색조건 필수'
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.dsConditionPopup.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsConditionPopup.orgCd = _.get(retrunData, 'orgCd')
            this.dsConditionPopup.orgNm = _.get(retrunData, 'orgNm')
            this.dsConditionPopup.orgLvl = _.get(retrunData, 'orgLvl')
            this.searchForm.orgCd = this.dsConditionPopup.orgCd
            this.searchForm.orgNm = this.dsConditionPopup.orgNm
            this.searchForm.orgLvl = this.dsConditionPopup.orgLvl
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-영업담당자팝업관련 methods ================================
        // 내부거래처-영업담당자 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-영업담당자 팝업 오픈
        getChrgrDealcosList() {
            this.searchForm.dealcoCd = this.dsConditionPopup.dealcoCd
            this.searchForm.dealcoNm = this.dsConditionPopup.dealcoNm
            basBcoChrgrDealcosApi
                .getChrgrDealcosList(this.dsConditionPopup)
                .then((res) => {
                    console.log('getChrgrDealcosList then : ', res)
                    // 검색된 내부거래처-영업담당자 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-영업담당자 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-영업담당자 팝업 오픈
                    if (res.length === 1) {
                        this.dsConditionPopup.dealcoCd = _.get(
                            res[0],
                            'dealcoCd'
                        )
                        this.dsConditionPopup.dealcoNm = _.get(
                            res[0],
                            'dealcoNm'
                        )
                    } else {
                        this.resultDealcoRows = res
                        this.showBasBcoChrgrDealcos = true
                    }
                })
        },
        // 내부거래처-영업담당자 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-영업담당자 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-영업담당자명이 빈값이 아니면 내부거래처-영업담당자 정보 조회
            // 그 이외는 내부거래처-영업담당자 팝업 오픈
            if (!_.isEmpty(this.dsConditionPopup.dealcoNm)) {
                // this.getChrgrDealcosList()
                this.showBasBcoChrgrDealcos = true
            } else {
                this.showBasBcoChrgrDealcos = true
            }
        },
        // 내부거래처-영업담당자 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-영업담당자 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-영업담당자명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsConditionPopup.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-영업담당자명 입력해주세요.'
                return
            }
            // 내부거래처-영업담당자 정보 조회
            this.getChrgrDealcosList()
        },
        // 내부거래처-영업담당자 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-영업담당자 코드 초기화
            this.dsConditionPopup.dealcoCd = ''
        },
        // 내부거래처-영업담당자 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsConditionPopup.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.dsConditionPopup.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-영업담당자팝업관련 methods ================================
    },
}
</script>
