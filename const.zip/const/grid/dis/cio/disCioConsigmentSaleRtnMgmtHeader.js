import { ValueType } from 'realgrid'

export const DisCioConsigmentSaleRtnMgmt_GRID_HEADER = {
    fields: [
        {
            fieldName: 'inMgmtNo',
            dataType: ValueType.TEXT, // 입고관리번호
        },
        {
            fieldName: 'outSktCd',
            dataType: ValueType.TEXT, // 거래처매장코드
        },
        {
            fieldName: 'outPlcId',
            dataType: ValueType.TEXT, // 거래처코드
        },
        {
            fieldName: 'outPlcNm',
            dataType: ValueType.TEXT, // 거래처
        },
        {
            fieldName: 'inSktCd',
            dataType: ValueType.TEXT, // 입고처매장코드
        },
        {
            fieldName: 'inPlcId',
            dataType: ValueType.TEXT, // 입고처코드
        },
        {
            fieldName: 'inPlcNm',
            dataType: ValueType.TEXT, // 입고처
        },
        {
            fieldName: 'inSchdDt',
            dataType: ValueType.TEXT, // 반품지시일
        },
        {
            fieldName: 'inFixDt',
            dataType: ValueType.TEXT, // 입고일
        },
        {
            fieldName: 'inQty',
            dataType: ValueType.NUMBER, // 반품수량
        },
        {
            fieldName: 'inFixQty',
            dataType: ValueType.NUMBER, // 입고수량
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 처리자ID
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT, // 처리자
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'inOrgId',
            dataType: ValueType.TEXT, // 입고조직코드
        },
        {
            fieldName: 'inOrgNm',
            dataType: ValueType.TEXT, // 입고조직명
        },
        {
            fieldName: 'inDealCoGrp',
            dataType: ValueType.TEXT, // 입고처그룹코드
        },
        {
            fieldName: 'outOrgId',
            dataType: ValueType.TEXT, // 거래조직코드
        },
        {
            fieldName: 'outOrgNm',
            dataType: ValueType.TEXT, // 거래조직명
        },
        {
            fieldName: 'outDealCoGrp',
            dataType: ValueType.TEXT, // 거래처그룹코드
        },
    ],
    columns: [
        {
            name: 'inMgmtNo',
            fieldName: 'inMgmtNo',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'outSktCd',
            fieldName: 'outSktCd',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcId',
            fieldName: 'outPlcId',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcNm',
            fieldName: 'outPlcNm',
            type: 'data',
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처',
                showTooltip: false,
            },
        },
        {
            name: 'inSktCd',
            fieldName: 'inSktCd',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcId',
            fieldName: 'inPlcId',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcNm',
            fieldName: 'inPlcNm',
            type: 'data',
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처',
                showTooltip: false,
            },
        },
        {
            name: 'inSchdDt',
            fieldName: 'inSchdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반품지시일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'inFixDt',
            fieldName: 'inFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'inQty',
            fieldName: 'inQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반품수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'inFixQty',
            fieldName: 'inFixQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: 100,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: 150,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
                showTooltip: false,
            },
        },
        {
            name: 'inOrgId',
            fieldName: 'inOrgId',
            type: 'data',
            visible: false,
        },
        {
            name: 'inOrgNm',
            fieldName: 'inOrgNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'inDealCoGrp',
            fieldName: 'inDealCoGrp',
            type: 'data',
            visible: false,
        },
        {
            name: 'outOrgId',
            fieldName: 'outOrgId',
            type: 'data',
            visible: false,
        },
        {
            name: 'outOrgNm',
            fieldName: 'outOrgNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'outDealCoGrp',
            fieldName: 'outDealCoGrp',
            type: 'data',
            visible: false,
        },
    ],
}
