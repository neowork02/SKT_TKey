import { ValueType } from 'realgrid'

export const GRIDHEADER = {
    fields: [
        {
            fieldName: 'tblNm',
            dataType: ValueType.TEXT, //테이블명
        },
        {
            fieldName: 'procDt',
            dataType: ValueType.TEXT, //처리일자
        },
        {
            fieldName: 'procTm' /* PROD_TM */,
            dataType: ValueType.TEXT, //처리시간
        },
        {
            fieldName: 'ifRecTypCd',
            dataType: ValueType.TEXT, //전문유형
        },
        {
            fieldName: 'ifRecTypGbCd',
            dataType: ValueType.TEXT, //전문유형구분코드
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT, //전문일자
        },
        {
            fieldName: 'opTm',
            dataType: ValueType.TEXT, //전문시간
        },
        {
            fieldName: 'seq',
            dataType: ValueType.TEXT, //IF전문순번
        },
        {
            fieldName: 'iniSaleNo',
            dataType: ValueType.TEXT, //원판매번호
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, //일반판매번호
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT, //일반판매변경순번
        },
        {
            fieldName: 'saleChgHstClCd',
            dataType: ValueType.TEXT, //판매변경구분코드
        },
        {
            fieldName: 'saleChgHstNm',
            dataType: ValueType.TEXT, //판매변경구분명
        },
        {
            fieldName: 'opStCd',
            dataType: ValueType.TEXT, //처리상태코드
        },
        {
            fieldName: 'opStNm',
            dataType: ValueType.TEXT, //처리상태명
        },
        {
            fieldName: 'svcTypNm',
            dataType: ValueType.TEXT, //개통구분
        },
        {
            fieldName: 'svcDtm',
            dataType: ValueType.DATETIME, //개통일시
            datetimeFormat: 'yyyyMMddHHmmss',
        },
        {
            fieldName: 'uscanAcptDtm',
            dataType: ValueType.TEXT, //접수일시
            //datetimeFormat: 'yyyyMMddHHmmss',
        },
        {
            fieldName: 'sktAgencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'sktAgencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT, //서브점코드
        },
        {
            fieldName: 'sktSubNm',
            dataType: ValueType.TEXT, //서브점명
        },
        {
            fieldName: 'svcDealcoCd',
            dataType: ValueType.TEXT, //개통처코드
        },
        {
            fieldName: 'svcDealcoNm',
            dataType: ValueType.TEXT, //개통처명
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT, //채널코드
        },
        {
            fieldName: 'sktChnlNm',
            dataType: ValueType.TEXT, //채널명
        },
        {
            fieldName: 'saleDealcoCd',
            dataType: ValueType.TEXT, //판매처코드
        },
        {
            fieldName: 'saleDealcoNm',
            dataType: ValueType.TEXT, //판매처명
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, //서비스관리번호
        },
        {
            fieldName: 'custNm',
            dataType: ValueType.TEXT, //고객명
        },
        {
            fieldName: 'svcNum',
            dataType: ValueType.TEXT, //개통번호
        },
        {
            fieldName: 'mdlCd',
            dataType: ValueType.TEXT, //단말기모델코드
        },
        {
            fieldName: 'mdlNm',
            dataType: ValueType.TEXT, //단말기모델명
        },
        {
            fieldName: 'mdlExp',
            dataType: ValueType.TEXT, //모델설명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //단말기일련번호
        },
        {
            fieldName: 'usimMdlCd',
            dataType: ValueType.TEXT, //USIM모델코드
        },
        {
            fieldName: 'usimSerNo',
            dataType: ValueType.TEXT, //USIM일련번호
        },
        {
            fieldName: 'usimMdlNm',
            dataType: ValueType.TEXT, //USIM모델명
        },
        {
            fieldName: 'eqpSettlCondCd',
            dataType: ValueType.TEXT, //단말기결제조건
        },
        {
            fieldName: 'eqpSettlCondNm',
            dataType: ValueType.TEXT, //단말기결제조건명
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT, //요금제코드
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT, //요금제명
        },
        {
            fieldName: 'dsNetCd',
            dataType: ValueType.TEXT, //약정유형코드
        },
        {
            fieldName: 'dsNetNm',
            dataType: ValueType.TEXT, //약정유형
        },
        {
            fieldName: 'agrmtPrdCd',
            dataType: ValueType.TEXT, //약정기간
        },
        {
            fieldName: 'agrmtPrdNm',
            dataType: ValueType.TEXT, //약정기간명
        },
        {
            fieldName: 'procChgrgUserId',
            dataType: ValueType.TEXT, //개통담당자ID
        },
        {
            fieldName: 'procChgrgUserNm',
            dataType: ValueType.TEXT, //개통담당자명
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, //처리자ID
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT, //처리자명
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, //처리일시
        },
        // {
        //     fieldName: 'modDtm',
        //     dataType: ValueType.DATETIME, //처리일시
        //     datetimeFormat: 'yyyyMMddHHmmss',
        // },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, //UPDATECOUNT
        },
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT, //선택
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'saleDtlTypNm',
            dataType: ValueType.TEXT, //판매세부유형
        },
        {
            fieldName: 'clubDcNm',
            dataType: ValueType.TEXT, //클럽할인구분
        },
        {
            fieldName: 'saleStCd',
            dataType: ValueType.TEXT, //판매상태코드
        },
        {
            fieldName: 'saleChnlNm',
            dataType: ValueType.TEXT, //판매채널명
        },
        {
            fieldName: 'spSaleDealcoCd',
            dataType: ValueType.TEXT, //특판처코드
        },
        {
            fieldName: 'spSaleDealcoNm',
            dataType: ValueType.TEXT, //특판처명
        },
        {
            fieldName: 'rn',
            dataType: ValueType.TEXT, //XXXX
        },
        {
            fieldName: 'cntrctMgmtNo',
            dataType: ValueType.TEXT, //계약관리번호
        },
        {
            fieldName: 'saleChnlClCd',
            dataType: ValueType.TEXT, //판매채널구분코드
        },
        {
            fieldName: 'saleChnlClNm',
            dataType: ValueType.TEXT, //판매채널구분명
        },
        {
            fieldName: 'usimAllotClCd',
            dataType: ValueType.TEXT, //유심할부구분코드
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
    ],
    columns: [
        {
            name: 'opStNm',
            fieldName: 'opStNm',
            type: 'data',
            width: '100',
            header: {
                text: '처리구분',
            },
            editable: false,
        },
        {
            name: 'saleChgHstNm',
            fieldName: 'saleChgHstNm',
            type: 'data',
            width: '100',
            header: {
                text: '판매상태',
            },
            editable: false,
        },
        {
            name: 'svcTypNm',
            fieldName: 'svcTypNm',
            type: 'data',
            width: '100',
            header: {
                text: '개통구분',
            },
            editable: false,
        },
        {
            name: 'svcDtm',
            fieldName: 'svcDtm',
            type: 'data',
            width: '130',
            header: {
                text: '개통일시',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            },
            editable: false,
        },
        {
            name: 'uscanAcptDtm',
            fieldName: 'uscanAcptDtm',
            type: 'data',
            width: '130',
            header: {
                text: '접수일시',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            },
            editable: false,
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            width: '100',
            //           styleName: 'left-column',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            width: '100',
            header: {
                text: '대리점',
            },
            editable: false,
        },
        {
            name: 'sktSubNm',
            fieldName: 'sktSubNm',
            type: 'data',
            width: '100',
            header: {
                text: '서브점명',
            },
            editable: false,
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            width: '100',
            header: {
                text: '서브점코드',
            },
            editable: false,
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            width: '100',
            header: {
                text: '채널코드',
            },
            editable: false,
        },
        {
            name: 'saleChnlClCd',
            fieldName: 'saleChnlClCd',
            type: 'data',
            width: '100',
            header: {
                text: '판매채널구분코드',
            },
            editable: false,
        },
        {
            name: 'saleChnlClNm',
            fieldName: 'saleChnlClNm',
            type: 'data',
            width: '100',
            header: {
                text: '판매채널구분명',
            },
            editable: false,
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            width: '150',
            header: {
                text: '판매처',
            },
            editable: false,
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '판매처코드',
            },
            editable: false,
        },
        {
            name: 'spSaleDealcoNm',
            fieldName: 'spSaleDealcoNm',
            type: 'data',
            width: '150',
            header: {
                text: '특판처',
            },
            editable: false,
        },
        {
            name: 'spSaleDealcoCd',
            fieldName: 'spSaleDealcoCd',
            type: 'data',
            width: '100',
            header: {
                text: '특판처코드',
            },
            editable: false,
        },
        {
            name: 'saleChnlNm',
            fieldName: 'saleChnlNm',
            type: 'data',
            width: '100',
            header: {
                text: '영업채널',
            },
            editable: false,
        },
        {
            name: 'saleDtlTypNm',
            fieldName: 'saleDtlTypNm',
            type: 'data',
            width: '100',
            header: {
                text: '판매유형',
            },
            editable: false,
        },
        {
            name: 'clubDcNm',
            fieldName: 'clubDcNm',
            type: 'data',
            width: '100',
            header: {
                text: '클럽할인',
            },
            editable: false,
        },
        {
            name: 'cntrctMgmtNo',
            fieldName: 'cntrctMgmtNo',
            type: 'data',
            width: '100',
            header: {
                text: '계약관리번호',
            },
            editable: false,
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            width: '100',
            header: {
                text: '서비스관리번호',
            },
            editable: false,
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            width: '100',
            header: {
                text: '고객명',
            },
            editable: false,
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            width: '100',
            header: {
                text: '개통번호',
            },
            editable: false,
        },
        {
            name: 'eqpSettlCondNm',
            fieldName: 'eqpSettlCondNm',
            type: 'data',
            width: '100',
            header: {
                text: '결제조건',
            },
            editable: false,
        },
        {
            name: 'mdlNm',
            fieldName: 'mdlNm',
            type: 'data',
            width: '100',
            header: {
                text: '모델명',
            },
            editable: false,
        },
        {
            name: 'mdlExp',
            fieldName: 'mdlExp',
            type: 'data',
            width: '100',
            header: {
                text: '모델설명',
            },
            editable: false,
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            header: {
                text: '일련번호',
            },
            editable: false,
        },
        {
            name: 'usimMdlNm',
            fieldName: 'usimMdlNm',
            type: 'data',
            width: '100',
            header: {
                text: 'USIM모델',
            },
            editable: false,
        },
        {
            name: 'usimSerNo',
            fieldName: 'usimSerNo',
            type: 'data',
            width: '100',
            header: {
                text: 'USIM일련번호',
            },
            editable: false,
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            width: '100',
            header: {
                text: '요금제',
            },
            editable: false,
        },
        {
            name: 'dsNetNm',
            fieldName: 'dsNetNm',
            type: 'data',
            width: '100',
            header: {
                text: '약정유형',
            },
            editable: false,
        },
        {
            name: 'agrmtPrdNm',
            fieldName: 'agrmtPrdNm',
            type: 'data',
            width: '100',
            header: {
                text: '약정기간',
            },
            editable: false,
        },
        {
            name: 'procChgrgUserId',
            fieldName: 'procChgrgUserId',
            type: 'data',
            width: '100',
            header: {
                text: '개통담당ID',
            },
            editable: false,
        },
        {
            name: 'procChgrgUserNm',
            fieldName: 'procChgrgUserNm',
            type: 'data',
            width: '100',
            header: {
                text: '개통담당명',
            },
            editable: false,
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            width: '100',
            header: {
                text: '처리자ID',
            },
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '100',
            header: {
                text: '처리자',
            },
            editable: false,
        },
        // {
        //     name: 'modDtm',
        //     fieldName: 'modDtm',
        //     type: 'data',
        //     width: '130',
        //     header: {
        //         text: '처리일시',
        //         showTooltip: false,
        //     },
        //     datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
        //     editor: {
        //         datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
        //     },
        // },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '130',
            styleName: 'left-column',
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMddhhmmss',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99 99:99:99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editable: false,
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '100',
            header: {
                text: '비고',
            },
            editable: true,
        },
    ],
}
