import { ValueType } from 'realgrid'

export const hdayCl_values = []
export const hdayCl_labels = []

export let GRID_PROPERTYINFO = {
    fields: [
        {
            fieldName: 'dataStatus', // 데이터상태코드(inserted, updated)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDt', // 일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hdayClCd', // 휴일구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hdayRsn', // 휴일사유
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleWght', // 영업가중치
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'weekDay', // 요일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleCumulatWght', // 누적가중치
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'saleDt',
            fieldName: 'saleDt',
            type: 'data',
            width: '100',
            header: {
                text: '일자',
                showTooltip: false,
            },
            styleName: 'left-column',
            datetimeFormat: 'yyyy-MM-dd',
            editable: false,
        },
        {
            name: 'weekDay',
            fieldName: 'weekDay',
            type: 'data',
            width: '100',
            header: {
                text: '요일',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'hdayClCd',
            fieldName: 'hdayClCd',
            type: 'data',
            width: '100',
            header: {
                text: '휴일구분',
                showTooltip: false,
            },
            styleName: 'left-column',
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                // dropDownCount: 4,
                // displayLabels: 'valueLabel',
                // textReadOnly: true
            },
        },
        {
            name: 'hdayRsn',
            fieldName: 'hdayRsn',
            type: 'data',
            width: '300',
            header: {
                text: '휴일사유',
                showTooltip: false,
            },
            styleName: 'left-column',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'saleWght',
            fieldName: 'saleWght',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '영업가중치',
                showTooltip: false,
            },
            editor: {
                type: 'number',
                editFormat: '#,##0.00',
            },
            numberFormat: '#,##0.00',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'saleCumulatWght',
            fieldName: 'saleCumulatWght',
            type: 'data',
            width: '100',
            header: {
                text: '누적가중치',
                showTooltip: false,
            },
            editor: {
                type: 'number',
                editFormat: '#,##0.00',
            },
            numberFormat: '#,##0.00',
            editable: false,
            styleName: 'right-column',
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            width: '100',
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
            editable: false,
            styleName: 'left-column',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '100',
            header: {
                text: '처리자',
                showTooltip: false,
            },
            editable: false,
            styleName: 'left-column',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '150',
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            editable: false,
            styleName: 'left-column',
        },
    ],

    layout: [
        'saleDt', // 일자
        'weekDay', // 요일
        'hdayClCd', // 휴일구분
        'hdayRsn', // 휴일사유
        'saleWght', // 영업가중치
        'saleCumulatWght', // 누적가중치
        'modUserId',
        'modUserNm',
        'modDtm',
    ],

    grouping: ['saleWght'],
}
