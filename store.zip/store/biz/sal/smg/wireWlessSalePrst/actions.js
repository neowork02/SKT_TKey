import api from '@/api/biz/sal/smg/salSmgWireWlessSalePrst'
import types from './mutation-types'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    async dropDownCmmonCodes_({ state, commit }, { key, columnName, option }) {
        let result = await api.dropDownCmmonCodes_(key)
        let values = []
        let labels = []
        values = result.map((a) => a.commCdVal)
        labels = result.map((a) => a.commCdValNm)
        if (option != undefined) {
            values.unshift('')
            labels.unshift(option)
        }

        let obj1 = {}
        obj1[columnName] = {
            values: values,
            labels: labels,
        }
        commit(types.DEFAULT_ASSIGN, {
            key: 'commDropDown',
            value: { ...state.commDropDown, ...obj1 },
        })
    },
    // eslint-disable-next-line no-unused-vars
    async getSalSmgWireWlessSalePrstDetails_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ file: actions.js sub ~ auths', searchParams)
        await api
            .getSalSmgWireWlessSalePrstDetails_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ getSalSmgWireWlessSalePrstDetails_ ~ .then ~ data',
                    data
                )
                resultData = data
            })
        return resultData
    },
    async getSalSmgWireWlessSalePrstList_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum
        console.log(
            '🚀 ~ file: actions.js ~ line 87 ~ searchParams',
            searchParams
        )
        await api
            .getSalSmgWireWlessSalePrstList_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ file: actions.js ~ getSalSmgWireWlessSalePrstList_ ~ .then ~ data',
                    data
                )
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: data.pagingDto,
                    })
                    let body = data.gridList
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: body,
                    })
                } else {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: state.initPaging,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: [],
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })
        const _sleep = (delay) =>
            new Promise((resolve) => setTimeout(resolve, delay))
        const timer = async () => {
            await _sleep(200)
        }
        await timer()

        return resultData
    },
    // // eslint-disable-next-line no-unused-vars
    // async saveWireWlessSalePrst_({ state, commit }, { saveRows }) {
    //     console.log('🚀 ~ file: actions.js ~ line 128 ~ saveRows', saveRows)
    //     let result = 0
    //     await api
    //         .saveWireWlessSalePrst_(saveRows)
    //         .then((data) => {
    //             console.log(
    //                 '🚀 ~ file: actions.js ~ saveWireWlessSalePrst_~ .then ~ data',
    //                 data
    //             )
    //             result = data
    //         })
    //         .catch((error) => {
    //             throw error
    //         })
    //     // const _sleep = (delay) =>
    //     //     new Promise((resolve) => setTimeout(resolve, delay))
    //     // const timer = async () => {
    //     //     await _sleep(1000)
    //     // }
    //     // await timer()
    //     return result
    // },
}
