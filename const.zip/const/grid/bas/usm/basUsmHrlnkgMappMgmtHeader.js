import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'deptCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'deptNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'psApndYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizChrgOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'teamOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ptOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ptOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orglDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orglDealcoNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'deptCd',
            fieldName: 'deptCd',
            editable: false,
            header: {
                text: '부서코드',
            },
        },
        {
            name: 'deptNm',
            fieldName: 'deptNm',
            editable: false,
            header: {
                text: '부서명',
            },
        },
        {
            name: 'psApndYn',
            fieldName: 'psApndYn',
            editable: false,
            header: {
                text: '반영여부',
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            editable: false,
            header: {
                text: '부여조직코드',
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            width: 300,
            button: 'action',
            buttonVisibility: 'always',
            header: {
                text: '부여조직',
                showTooltip: false,
            },
            styleName: 'left-column',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            editable: false,
            header: {
                text: '근무지코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            button: 'action',
            buttonVisibility: 'always',

            header: {
                text: '근무지',
                showTooltip: false,
            },
        },
        // {
        //     name: 'bizChrgOrgCd',
        //     fieldName: 'bizChrgOrgCd',
        //     header: {
        //         text: '담당코드',
        //     },
        // },
        // {
        //     name: 'bizChrgOrgNm',
        //     fieldName: 'bizChrgOrgNm',
        //     type: 'data',
        //     editable: false,
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     button: 'action',
        //     buttonVisibility: 'always',

        //     header: {
        //         text: '사업담당',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: 'teamOrgCd',
        //     fieldName: 'teamOrgCd',
        //     header: {
        //         text: '센터코드',
        //     },
        // },
        // {
        //     name: 'teamOrgNm',
        //     fieldName: 'teamOrgNm',
        //     header: {
        //         text: '팀/센터',
        //     },
        // },
        // {
        //     name: 'ptOrgCd',
        //     fieldName: 'ptOrgCd',
        //     header: {
        //         text: 'PT코드',
        //     },
        // },
        // {
        //     name: 'ptOrgNm',
        //     fieldName: 'ptOrgNm',
        //     header: {
        //         text: 'PT',
        //     },
        // },
        // {
        //     name: 'orglDealcoCd',
        //     fieldName: 'orglDealcoCd',
        //     header: {
        //         text: '매장코드',
        //     },
        // },
        // {
        //     name: 'orglDealcoNm',
        //     fieldName: 'orglDealcoNm',
        //     header: {
        //         text: '매장명',
        //     },
        // },
    ],
}
