import { ValueType } from 'realgrid'

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'asgnQty',
            dataType: ValueType.NUMBER, //배정수량
        },
        {
            fieldName: 'lmtQty',
            dataType: ValueType.NUMBER, //최대배정수량
        },
        {
            fieldName: 'autoAsgnQty',
            dataType: ValueType.NUMBER, //자동배정수량
        },
        {
            fieldName: 'gap',
            dataType: ValueType.NUMBER, //GAP
            // valueExpression: "values['asgnQty']-values['autoAsgnQty']",
        },
        {
            fieldName: 'asgnDt',
            dataType: ValueType.TEXT, //배정일자
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
    ],
    columns: [
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'asgnQty',
            fieldName: 'asgnQty', //sknAsgnQty
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '배정수량',
                showTooltip: false,
            },
            editable: true,
        },
        {
            name: 'lmtQty',
            fieldName: 'lmtQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '최대배정수량',
                showTooltip: false,
            },
            editable: true,
        },
        {
            name: 'autoAsgnQty',
            fieldName: 'autoAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '자동배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'gap',
            fieldName: 'gap',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: 'GAP',
                showTooltip: false,
            },
            editable: false,
        },
    ],
}
export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT, // 조직
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, // 거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, // 거래처명
        },
        {
            fieldName: 'crdtBalAmt',
            dataType: ValueType.NUMBER, // 여신잔액
        },
    ],
    columns: [
        {
            name: 'orgTree',
            fieldName: 'orgTree',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'crdtBalAmt',
            fieldName: 'crdtBalAmt',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신잔액',
                showTooltip: false,
            },
            editable: false,
        },
    ],
}

export const GRID_HEADER3 = {
    fields: [
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT, // 조직
        },
        {
            fieldName: 'lvOrgNm',
            dataType: ValueType.TEXT, // 회사명
        },
        {
            fieldName: 'lvOrgNm1',
            dataType: ValueType.TEXT, // 담당명
        },
        {
            fieldName: 'lvOrgNm2',
            dataType: ValueType.TEXT, // 팀명
        },
        {
            fieldName: 'lvOrgNm3',
            dataType: ValueType.TEXT, // 파트명
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, // 대리점코드
        },
        {
            fieldName: 'dealcoShopCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'saleDealcoCd',
            dataType: ValueType.TEXT, // 거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, // 거래처명
        },
        {
            fieldName: 'repDlvDealcoCd',
            dataType: ValueType.TEXT, // 배송지코드
        },
        {
            fieldName: 'rcvSknDelvPlcCd',
            dataType: ValueType.TEXT, // SKN배송지코드
        },
        {
            fieldName: 'sknDelvDealcdNm',
            dataType: ValueType.TEXT, // 배송지명
        },
        {
            fieldName: 'sknDelvPlcNm',
            dataType: ValueType.TEXT, // SKN배송지명
        },
        {
            fieldName: 'crdtOverYn',
            dataType: ValueType.TEXT, // 여신초과여부
        },
        {
            fieldName: 'crdtAmt',
            dataType: ValueType.NUMBER, // 여신금액
        },
        {
            fieldName: 'crdtBalAmt',
            dataType: ValueType.NUMBER, // 여신잔액
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'currHldQty',
            dataType: ValueType.TEXT, // 현보유수량
        },
        {
            fieldName: 'salePlcProdQty',
            dataType: ValueType.TEXT, // 30일실적
        },
        {
            fieldName: 'autoAsgnQty',
            dataType: ValueType.NUMBER, // 자동배정수량
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER, // 단가
        },
        {
            fieldName: 'ordAmt',
            dataType: ValueType.NUMBER, // 주문금액
        },
    ],
    columns: [
        {
            name: 'lvOrgNm',
            fieldName: 'lvOrgNm',
            type: 'data',
            header: {
                text: '회사명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'lvOrgNm1',
            fieldName: 'lvOrgNm1',
            type: 'data',
            header: {
                text: '담당명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'lvOrgNm2',
            fieldName: 'lvOrgNm2',
            type: 'data',
            header: {
                text: '팀명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'lvOrgNm3',
            fieldName: 'lvOrgNm3',
            type: 'data',
            header: {
                text: '파트명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealcoShopCd',
            fieldName: 'dealcoShopCd',
            type: 'data',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'rcvSknDelvPlcCd',
            fieldName: 'rcvSknDelvPlcCd',
            type: 'data',
            header: {
                text: 'SKN배송지코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sknDelvDealcdNm',
            fieldName: 'sknDelvDealcdNm',
            type: 'data',
            header: {
                text: '배송지명',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'sknDelvPlcNm',
            fieldName: 'sknDelvPlcNm',
            type: 'data',
            header: {
                text: 'SKN배송지명',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'crdtOverYn',
            fieldName: 'crdtOverYn',
            type: 'data',
            header: {
                text: '여신초과여부',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'crdtAmt',
            fieldName: 'crdtAmt',
            type: 'data',
            numberFormat: '#,###,###,##0',
            header: {
                text: '여신금액',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            header: {
                text: '상품코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            header: {
                text: '상품명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            header: {
                text: '색상명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'currHldQty',
            fieldName: 'currHldQty',
            type: 'data',
            header: {
                text: '현보유수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'salePlcProdQty',
            fieldName: 'salePlcProdQty',
            type: 'data',
            header: {
                text: '30일실적',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'autoAsgnQty',
            fieldName: 'autoAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            header: {
                text: '배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'crdtBalAmt',
            fieldName: 'crdtBalAmt',
            type: 'data',
            numberFormat: '#,###,###,##0',
            header: {
                text: '여신잔액',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'number',
            numberFormat: '#,###,###,##0',
            header: {
                text: '단가',
                showTooltip: false,
            },
            editable: false,
            // numberFormat: '#,##0',
        },
        {
            name: 'ordAmt',
            fieldName: 'ordAmt',
            type: 'number',
            numberFormat: '#,###,###,##0',
            header: {
                text: '주문금액',
                showTooltip: false,
            },
            editable: false,
            // numberFormat: '#,##0',
        },
    ],
}
