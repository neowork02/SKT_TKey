<!-----------------------------------------------
 * 업무그룹명: 시연재고해제팝업
 * 서브업무명: 시연재고해제팝업
 * 설명: 시연재고해제한다.
 * 작성자: P179234
 * 작성일: 2022.04.05
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1500px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">시연재고해제</p>
                <div class="layerCont">
                    <ul class="btn_area top pop">
                        <li class="left">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="delDemo"
                                :objAuth="objAuth"
                            >
                                상태해제
                            </TCComButton>
                        </li>
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="init"
                                :objAuth="objAuth"
                            >
                                초기화
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="searchDemos"
                                :objAuth="objAuth"
                            >
                                조회
                            </TCComButton>
                            <!-- <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="closeBtn"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton> -->
                        </li>
                    </ul>
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="등록일자"
                                    :calType="calType5"
                                    :eRequired="true"
                                    v-model="setDate"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :codeVal.sync="reqParam.orgCd"
                                    :disabledAfter="true"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.orgNm"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="reqParam.hldDealcoNm"
                                    :codeVal.sync="reqParam.hldDealcoCd"
                                    labelName="보유처"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onDealcoEnterKey"
                                    @appendIconClick="onDealcoIconClick"
                                    @input="onDealcoInput"
                                />
                                <BasBcoDealcosPop
                                    v-if="showBasBcoDealcos"
                                    :parentParam="searchForm"
                                    :rows="resultDealcoRows"
                                    :dialogShow.sync="showBasBcoDealcos"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                        </div>
                    </div>
                    <TCRealGridHeader
                        id="gridHeader"
                        ref="gridHeader"
                        gridTitle="시연재고관리"
                        :gridObj="gridObj"
                        :isPageRows="true"
                        :isExceldown="false"
                        :isNextPage="false"
                        :isPageCnt="true"
                    />
                    <TCRealGrid
                        id="gridField"
                        ref="gridField"
                        :fields="gridSet.fields"
                        :columns="gridSet.columns"
                        :styles="gridStyle"
                    />
                    <TCComPaging
                        :totalPage="gridData.totalPage"
                        :apiFunc="getDisDemDemoYs"
                        :gridObj="gridObj"
                    />
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 사용자 정의 파라메터 기반 공통팝업 호출
 * 4 시연재고 해제 부분 테스트 필요
------------------------------------------------>
<script>
import { CommonGrid, CommonUtil } from '@/utils'
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
import { GRID_HEADER } from '@/const/grid/dis/dem/disDemDemoDisMgmtHeader.js'
import demApi from '@/api/biz/dis/dem/disDemDemoDisMgmt.js'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

import { SacCommon } from '@/views/biz/sac/js'
//====================내부거래처-권한조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================

export default {
    name: 'DisDemDemoDelPop',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
    },
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        parentParam: { type: Object, default: () => {}, required: false },
        closeDemo: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            objAuth: {},
            indicatorOpt: { sort: 'ASC' },
            calType5: 'DP',
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '400px',
            },
            searchForms: {},
            rowCnt: 15,
            gridSet: GRID_HEADER,
            badEquip: this.closeDemo,
            reqParam: {
                // regStaDt: '',
                // regEndDt: '',
                chargrUserId: '',
                hldDealcoCd: '',
                hldDealcoNm: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
            },
            searchable: false,
            // 내부조직 관련
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            showBcoAuthOrgTrees: false,
            // 보유처 관련
            //====================내부거래처-권한조직====================
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: '', //거래처그룹코드
                dealcoClCd1: '', //거래처구분코드
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        setDate: {
            get() {
                return [this.reqParam.regStaDt, this.reqParam.regEndDt]
            },
            set(val) {
                this.reqParam.regStaDt = val[0]
                this.reqParam.regEndDt = val[1]

                this.searchable = val[0] === '' || val[1] === '' ? false : true

                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val[1])
                return val
            },
        },
    },
    created() {
        this.initParam()
    },
    mounted() {
        this.setGrid()
    },
    methods: {
        /* 초기화 */
        init() {
            this.initParam()
            this.gridObj.setRows({})
        },
        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                // regStaDt: '',
                // regEndDt: '',
                chargrUserId: '',
                hdlDealCo: '',
                pageSize: '',
                pageNum: 0,
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                hldDealcoNm: '',
                hldDealcoCd: '',
            }
            this.reqParam.regStaDt = SacCommon.getFirstday()
            this.reqParam.regEndDt = SacCommon.getToday()

            this.reqParam.orgCd = this.orgInfo.orgCd
            this.reqParam.orgNm = this.orgInfo.orgNm
            this.reqParam.orgLvl = this.orgInfo.orgLvl
            this.searchForm.orgCd = this.orgInfo.orgCd
            this.searchForm.orgNm = this.orgInfo.orgNm
            this.searchForm.orgLvl = this.orgInfo.orgLvl
            this.reqParam.hldDealcoNm = this.userInfo.dealcoNm
            this.reqParam.hldDealcoCd = this.userInfo.dealcoCd
            console.log('userInfo==========>>> ', this.userInfo)
            // this.reqParam.regStaDt =
            //     this.parentParam.regStaDt || SacCommon.getFirstday()
            // this.reqParam.regEndDt =
            //     this.parentParam.regEndDt || SacCommon.getToday()
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.gridField
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.setGridState(true, false, true)
        },
        gridSetData() {
            return new CommonGrid(-1, -1, 10, 0, '')
        },
        /* 시연재고 조회 - 최초 */
        searchDemos() {
            const startMonth = this.reqParam.regStaDt.substring(5, 7)
            const endMonth = this.reqParam.regEndDt.substring(5, 7)

            if (this.searchable === false) {
                this.showTcComAlert('등록일자를 지정해주세요.')
            } else if (startMonth !== endMonth) {
                this.showTcComAlert(
                    '등록일자의 시작일과 종료일을 동일한 월로 지정해 주세요.'
                )
            } else if (this.reqParam.orgCd === '') {
                this.showTcComAlert('조직을 입력 해 주세요.')
            } else {
                this.gridData.totalPage = 0
                this.searchForms = { ...this.reqParam }
                this.searchForms.pageSize = this.rowCnt
                this.searchForms.pageNum = 1
                this.searchForms.regStaDt = CommonUtil.onlyNumber(
                    this.reqParam.regStaDt
                )
                this.searchForms.regEndDt = CommonUtil.onlyNumber(
                    this.reqParam.regEndDt
                )

                //testdata
                // const teatdata = {
                //     regStaDt: '20220804',
                //     regEndDt: '20220804',
                //     pageSize: this.rowCnt,
                //     pageNum: 1,
                // }
                // this.searchForms = { ...teatdata }
                //testdata

                this.getDisDemDemoYs(this.searchForms.pageNum)
            }
        },
        /* 시연재고 조회 - 페이징호출 */
        async getDisDemDemoYs(page) {
            this.searchForms.pageNum = page

            await demApi.getDemoDisCnclMgmts(this.searchForms).then((res) => {
                console.log(res)
                if (res) {
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator(
                        res.pagingDto,
                        this.indicatorOpt
                    )
                    this.gridData = this.gridSetData()
                    this.gridData.totalPage = res.pagingDto.totalPageCnt
                    this.gridHeaderObj.setPageCount(res.pagingDto)
                }
            })
        },
        /* 시연재고 해제 */
        async delDemo() {
            let pDatas = []
            let rows = this.gridObj.gridView.getCheckedRows(true)
            for (let i in rows) {
                const jsonRow = this.gridObj.dataProvider.getJsonRow(rows[i])
                pDatas.push(jsonRow)
            }
            const formdata = {
                rowDatas: pDatas,
            }

            console.log('formdata 해제데이터 ====> ', formdata)

            demApi.setDemoDisCnclMgmts(formdata).then(() => {
                // 화면재조회
                this.searchDemos()
            })
        },
        btnClick() {
            console.log('click')
        },
        /* 팝업 창닫기 */
        closeBtn() {
            this.activeOpen = false
        },
        /* 내부조직팝업 */
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.reqParam.orgCd
            this.searchParam.orgNm = this.reqParam.orgNm
            this.searchParam.orgLvl = this.reqParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.reqParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        /* 내부조직팝업 - Icon 이벤트 처리 */
        onAuthOrgTreeIconClick() {
            this.resultAuthOrgTreeRows = []
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        /* 내부조직팝업 - TextField 엔터키 이벤트 처리 */
        onAuthOrgTreeEnterKey() {
            this.resultAuthOrgTreeRows = []
            // if (_.isEmpty(this.reqParam.orgNm)) {
            //     this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
            //     return
            // }
            this.getAuthOrgTreeList()
        },
        /* 내부조직팝업 - TextField Input 이벤트 이벤트 처리 */
        onAuthOrgTreeInput() {
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
        },
        /* 내부조직팝업 - 팝업 리턴 이벤트 이벤트 처리 */
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.orgLvl = _.get(returnData, 'orgLvl')
        },
        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            this.searchForm.dealcoCd = this.reqParam.hldDealcoCd
            this.searchForm.dealcoNm = this.reqParam.hldDealcoNm
            this.searchForm.orgCd = this.reqParam.orgCd
            this.searchForm.orgNm = this.reqParam.orgNm
            this.searchForm.orgLvl = this.reqParam.orgLvl
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.hldDealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.hldDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.hldDealcoNm)) {
                // this.searchForm.basDay = CommonUtil.replaceDash(this.rgstDt[1])
                this.getDealcosList()
                // this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.reqParam.hldDealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.reqParam.hldDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.hldDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================

        /* 현재일자 확인(yyyy-mm-dd)*/
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
    },
}
</script>
