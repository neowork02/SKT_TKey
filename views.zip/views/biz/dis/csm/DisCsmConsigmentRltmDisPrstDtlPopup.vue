<!-----------------------------------------------
 * 업무 그룹명 : 재고 수탁재고관리>수탁재고관리현황>수탁실시간재고현황
 * 서브 업무명 : 수탁실시간재고현황상세
 * 설 명 : 수탁실시간재고현황에대한 상세정보를 조회한다.
 * 작 성 자 : P180182
 * 작 성 일 : 2022.05.19
 * Copyright ⓒ SK TELECOM. All Right Reserved
 ------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">수탁실시간 재고 현황 상세</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- gridWrap -->
                    <TCRealGridHeader
                        id="dtlGridHeader"
                        ref="dtlGridHeader"
                        gridTitle="재고 현황 상세"
                        :gridObj="gridObj"
                        :isPageRows="true"
                        :isExceldown="true"
                        :isNextPage="true"
                        :isPageCnt="true"
                        @excelDownBtn="excelDownBtn"
                        class="pop"
                    />
                    <TCRealGrid
                        id="dtlGrid"
                        ref="dtlGrid"
                        :fields="dtlGridHeader.fields"
                        :columns="dtlGridHeader.columns"
                    />
                    <TCComPaging
                        :totalPage="gridData.totalPage"
                        :apiFunc="getRltmDisPrstDtlList"
                        :gridObj="gridObj"
                        :rowCnt="rowCnt"
                        @input="chgRowCnt"
                    />
                    <!-- //gridWrap -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { DETAIL_GRID_HEADER } from '@/const/grid/dis/csm/disCsmConsigmentRltmDisPrstHeader.js'
import restApi from '@/api/biz/dis/csm/disCsmConsigmentRltmDisPrst.js'
import attachedFileApi from '@/api/common/attachedFile'

export default {
    name: 'DisCsmConsigmentRltmDisPrstDtlPopup',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
    },
    data() {
        return {
            dtlGridHeader: DETAIL_GRID_HEADER,
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            indicatorOpt: { sort: 'ASC' },
            objAuth: {},
            rowCnt: 15,
            searchForms: {},
            reqParam: {
                // 요청파라미터
                strdYm: '', // 기준년월
                staDt: '', // 시작일자
                strdDt: '', // 기준일자
                orgCd: '', // 조직코드
                orgLvl: '', // 조직레벨
                chrgrId: '', // 담당자ID
                hldDealcoCd: '', // 보유처코드
                prodClCd: '', // 상품구분코드
                disStCd: '', // 재고상태코드
                dlvStCd: '', // 배송상태코드
                openYn: '', // 개봉여부
                demoYn: '', // 시연여부
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
                colorCd: '', // 색상코드
                lvOrgCd: '', // 레벨0조직코드
                lvOrgCd1: '', // 레벨1조직코드
                lvOrgCd2: '', // 레벨2조직코드
                lvOrgCd3: '', // 레벨3조직코드
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.reqParam.strdYm = value['strdYm']
                this.reqParam.staDt = value['staDt']
                this.reqParam.strdDt = value['strdDt']
                this.reqParam.orgCd = value['orgCd']
                this.reqParam.orgLvl = value['orgLvl']
                this.reqParam.chrgrId = value['chrgrId']
                this.reqParam.hldDealcoCd = value['hldDealcoCd']
                this.reqParam.prodClCd = value['prodClCd']
                this.reqParam.disStCd = value['disStCd']
                this.reqParam.dlvStCd = value['dlvStCd']
                this.reqParam.openYn = value['openYn']
                this.reqParam.demoYn = value['demoYn']
                this.reqParam.badYn = value['badYn']
                this.reqParam.serNum = value['serNum']
                this.reqParam.prodCd = value['prodCd']
                this.reqParam.prodNm = value['prodNm']
                this.reqParam.colorCd = value['colorCd']
                this.reqParam.lvOrgCd = value['lvOrgCd']
                this.reqParam.lvOrgCd1 = value['lvOrgCd1']
                this.reqParam.lvOrgCd2 = value['lvOrgCd2']
                this.reqParam.lvOrgCd3 = value['lvOrgCd3']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.gridData = this.gridSetData(this.rowCnt)
    },
    mounted() {
        this.gridObj = this.$refs.dtlGrid
        this.gridHeaderObj = this.$refs.dtlGridHeader
        this.gridObj.setGridState(true)

        // 첫 조회시 표시할 행의 갯수
        this.searchForms = { ...this.reqParam }
        this.searchForms.pageSize = this.rowCnt
        this.searchForms.pageNum = 1 // 첫번째 페이지
        this.gridData.totalPage = 0 // 이전페이지정보 초기화
        this.getRltmDisPrstDtlList(this.searchForms.pageNum)
    },
    methods: {
        // Grid Init
        gridSetData(rowCnt) {
            // CommonGrid(현재페이지 번호, 총 페이지, Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(0, rowCnt, '', '')
        },
        // 페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
            this.searchForms.pageSize = this.rowCnt
            this.getRltmDisPrstDtlList(this.searchForms.pageNum)
        },
        //Grid ExcelDown
        excelDownBtn() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-max/resource/dis/csm/consigment-real-times-inventory-detail-excel-download',
                this.reqParam
            )
        },
        // 수탁실시간재고현황 상세 조회
        getRltmDisPrstDtlList(page) {
            this.searchForms.pageNum = page

            restApi.getRltmDisPrstDtlList(this.searchForms).then((res) => {
                this.gridObj.setRows(res.gridList)
                this.gridObj.setGridIndicator(res.pagingDto, this.indicatorOpt) // 순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData(this.rowCnt) // 초기화
                this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj.setPageCount(res.pagingDto) // Grid Row 가져올때 페이지정보 Setting
            })
        },
        // 팝업닫기
        closeBtn() {
            this.activeOpen = false
        },
    },
}
</script>
