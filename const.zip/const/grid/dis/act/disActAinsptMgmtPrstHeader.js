import { ValueType } from 'realgrid'

export const DisActAinsptMgmtPrst_GRID_HEADER = {
    fields: [
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, // 조직
        },
        {
            fieldName: 'hldPlcId',
            dataType: ValueType.TEXT, // 보유처코드
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, // 보유처
        },
        {
            fieldName: 'onTkey',
            dataType: ValueType.NUMBER, // New T.key+보유
        },
        {
            fieldName: 'onAct',
            dataType: ValueType.NUMBER, // 재고실사
        },
        {
            fieldName: 'onlyTkey',
            dataType: ValueType.NUMBER, // New T.key+ Only
        },
        {
            fieldName: 'onlyAct',
            dataType: ValueType.NUMBER, // 보유처 Only
        },
        {
            fieldName: 'overShort',
            dataType: ValueType.NUMBER, // 검증
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT, // 처리자
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'strdDt',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, // 조직코드
        },
        {
            fieldName: 'orgLevel',
            dataType: ValueType.TEXT, // 조직레벨
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, // 0레벨조직코드
        },
    ],
    columns: [
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcId',
            fieldName: 'hldPlcId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'far',
            },
            header: {
                text: '보유처',
                showTooltip: false,
            },
        },
        {
            name: 'onTkey',
            fieldName: 'onTkey',
            type: 'data',
            width: '140',
            styleName: 'right-column',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'TkeyTaka 보유',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'onAct',
            fieldName: 'onAct',
            type: 'data',
            width: '110',
            styleName: 'right-column',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고실사',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'onlyTkey',
            fieldName: 'onlyTkey',
            type: 'data',
            width: '140',
            styleName: 'right-column',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'TkeyTaka Only',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'onlyAct',
            fieldName: 'onlyAct',
            type: 'data',
            width: '110',
            styleName: 'right-column',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처 Only',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'overShort',
            fieldName: 'overShort',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '검증',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'userId',
            fieldName: 'userId',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '140',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
                showTooltip: false,
            },
        },
        {
            name: 'strdDt',
            fieldName: 'strdDt',
            type: 'data',
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'orgLevel',
            fieldName: 'orgLevel',
            type: 'data',
            visible: false,
        },
        {
            name: 'lvOrgCd',
            fieldName: 'lvOrgCd',
            type: 'data',
            visible: false,
        },
    ],
}
