<!-----------------------------------------------
 * 업무그룹명: Swing출고상품입력팝업
 * 서브업무명: Swing출고상품입력팝업
 * 설명: Swing출고상품을 조회한다.
 * 작성자: P179890
 * 작성일: 2022.06.21
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">Swing출고상품입력</p>
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="left">
                            <TCComButton
                                eClass="btn_ty"
                                :eOutlined="true"
                                :objAuth="objAuth"
                                @click="errCheckBtn"
                                >오류검증</TCComButton
                            >
                        </li>
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="clearBtn"
                                >초기화</TCComButton
                            >
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="searchBtn"
                            >
                                조회
                            </TCComButton>
                            <!-- <TCComButton
                                    color="btn2"
                                    eClass="btn_ty01"
                                    :objAuth="objAuth"
                                    @click="closeBtn"
                                >
                                    닫기
                                </TCComButton> -->
                        </li>
                    </ul>

                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComDatePicker
                                    :calType="calType"
                                    v-model="setDate"
                                    labelName="출고예정일"
                                >
                                </TCComDatePicker>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="출고처"
                                    :disabled="true"
                                    v-model="reqParam.outPlcNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComComboBox
                                    labelName="반영여부"
                                    :itemList="reflYnComboItems"
                                    :objAuth="objAuth"
                                    v-model="reqParam.reflYn"
                                    :addBlankItem="false"
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="대리점"
                                    :disabled="true"
                                    v-model="reqParam.posAgnecyNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="출고구분"
                                    :disabled="true"
                                    v-model="reqParam.inOutClNm"
                                />
                            </div>
                        </div>
                    </div>

                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="swingProdPopGridHeader"
                            ref="gridHeader"
                            gridTitle="상품내역"
                            :gridObj="gridObj"
                            :isPageRows="true"
                            :isDelRow="true"
                            @excelDownBtn="exportGridBtn"
                            @chkDelRowBtn="gridchkDelRowBtn"
                        />
                        <TCRealGrid
                            id="swingProdPopGrid"
                            ref="grid"
                            :fields="view.fields"
                            :columns="view.columns"
                            :styles="gridStyle"
                        />
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil, CommonMsg } from '@/utils'
import { DisDcoSwingOutProdInsPopup_GRID_HEADER } from '@/const/grid/dis/dco/disDcoSwingOutProdInsPopupHeader.js'
import dcoApi from '@/api/biz/dis/dco/disDcoSwingOutProdIns.js'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'

export default {
    name: 'DisDcoSwingOutProdInsPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        params: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
        prodOrgList: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        },
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        setDate: {
            get() {
                return [this.reqParam.staInDt, this.reqParam.endInDt]
            },
            set(val) {
                this.reqParam.staInDt = val[0]
                this.reqParam.endInDt = val[1]
                return val
            },
        },
    },
    data() {
        return {
            objAuth: {},
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},
            view: DisDcoSwingOutProdInsPopup_GRID_HEADER,
            searchForms: {},
            calType: 'DP',
            confirmDisable: true,
            alertHeadTxt: 'Swing출고상품입력',
            gridStyle: {
                height: '300px', //그리드 높이 조절
            },
            mfactComboList: [],
            reqParam: {
                // 요청파라미터
                staInDt: '', // 출고예정시작일
                endInDt: '', // 출고예정종료일
                posAgnecyId: '', // 대리점ID
                posAgnecyNm: '', // 대리점명
                inOutCl: '', // 출고구분
                inOutClNm: '', // 출고구분명
                outPlcId: '', // 출고처코드
                outPlcNm: '', // 출고처명
                reflYn: '', // 반영여부
            },
            reflYnComboItems: [
                { commCdValNm: 'Y', commCdVal: 'Y' },
                { commCdValNm: 'N', commCdVal: 'N' },
            ],
        }
    },
    created() {
        // 화면 default설정
        this.gridData = this.gridSetData()
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.init()
    },
    methods: {
        init() {
            this.reqParam.staInDt = moment(new Date()).format('YYYY-MM-01') // 출고예정시작일
            this.reqParam.endInDt = moment(new Date()).format('YYYY-MM-DD') // 출고예정종료일

            this.reqParam.orgId = this.params['orgId']
            this.reqParam.orgNm = this.params['orgNm']
            this.reqParam.orgLevel = this.params['orgLevel']
            this.reqParam.outPlcId = this.params['outPlcId']
            this.reqParam.outPlcNm = this.params['outPlcNm']
            this.reqParam.inOutCl = this.params['inOutCl']
            this.reqParam.inOutClNm = this.params['inOutClNm']
            this.reqParam.posAgnecyId = this.params['agencyId']
            this.reqParam.posAgnecyNm = this.params['agencyNm']
            this.reqParam.reflYn = 'N'

            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
        },
        closeBtn() {
            this.activeOpen = false
        },
        //GridSetData
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(0, 0, '', '')
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            this.gridHeaderObj.exportGrid('Swing출고상품입력.xls')
        },
        // Validation 체크
        isValidChk() {
            if (_.isEmpty(this.reqParam.staInDt)) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00083', '출고예정시작일')
                )
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.staInDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            if (_.isEmpty(this.reqParam.endInDt)) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00083', '출고예정종료일')
                )
                return false
            }
            if (
                !CommonUtil.validDateType(
                    '02',
                    this.reqParam.endInDt.replaceAll('-', '')
                )
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00176'))
                return false
            }
            if (
                this.reqParam.staInDt.substr(0, 7) !==
                this.reqParam.endInDt.substr(0, 7)
            ) {
                // MSG_00086
                this.openAlert('시작일자와 종료일자을 동일한 월로 지정하세요.')
                return false
            }
            if (
                this.reqParam.staInDt.replaceAll('-', '') >
                this.reqParam.endInDt.replaceAll('-', '')
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_01026'))
                return false
            }
            return true
        },
        // 개봉상품등록 그리드에 선택된 상품 중복 제외
        setNewProd(prodList) {
            if (this.prodOrgList.length > 0) {
                this.prodOrgList.forEach((item1) => {
                    prodList.forEach((item2, i) => {
                        if (
                            item1['serNum'] == item2['serNum'] &&
                            item1['colorCd'] == item2['colorCd'] &&
                            item1['prodCd'] == item2['prodCd']
                        ) {
                            prodList.splice(i, 1)
                        }
                    })
                })
            }
            return prodList
        },
        clearBtn() {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.init()
        },
        // 확인버튼
        async confirmBtn() {
            var prodList = this.gridObj.dataProvider.getJsonRows()
            let errCnt = 0

            if (prodList.length == 0) {
                this.openAlert(CommonMsg.getMessage('MSG_00071', ''))
                return
            }

            const resList = []
            for (var i = 0; i < prodList.length; i++) {
                if (_.isEmpty(prodList[i].errDesc)) {
                    resList.push(prodList[i])
                } else {
                    errCnt++
                }
            }

            if (errCnt > 0) {
                const confirm = await this.showTcComConfirm(
                    CommonMsg.getMessage('MSG_00107')
                )

                if (confirm) {
                    // 로직처리
                    if (resList.length == 0) {
                        this.openAlert(CommonMsg.getMessage('MSG_00117'))
                        return
                    }
                    this.$emit('addSwingProdList', resList)
                    this.activeOpen = false
                }
            } else {
                this.$emit('addSwingProdList', resList)
                this.activeOpen = false
            }
        },
        //조회 버튼 이벤트
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            //첫 조회시 표시할 행의 갯수
            this.searchForms = { ...this.reqParam }
            this.searchForms.staInDt = CommonUtil.onlyNumber(
                this.searchForms.staInDt
            )
            this.searchForms.endInDt = CommonUtil.onlyNumber(
                this.searchForms.endInDt
            )
            this.getUkeyInOutList()
        },
        getUkeyInOutList() {
            dcoApi.getUkeyInOutList(this.searchForms).then((res) => {
                const girdList = this.setNewProd(res.gridList)
                this.gridObj.setRows(girdList)
                this.gridHeaderObj.setPageCount({
                    totalDataCnt: girdList.length,
                })
                this.confirmDisable = true // 확인버튼 비활성화
            })
        },
        // alert창 호출
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        errCheckBtn() {
            const errCheckData = this.gridObj.dataProvider.getJsonRows()

            if (errCheckData.length == 0) {
                this.openAlert(CommonMsg.getMessage('MSG_00071', ''))
                return
            }

            dcoApi.getCheckUkeyOutList(errCheckData).then((res) => {
                const girdList = this.setNewProd(res.gridList)
                this.gridObj.setRows(girdList)
                this.gridHeaderObj.setPageCount({
                    totalDataCnt: girdList.length,
                })
                this.confirmDisable = false // 확인버튼 활성화
            })
        },
    },
}
</script>
