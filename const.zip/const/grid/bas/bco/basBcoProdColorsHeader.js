import { ValueType } from 'realgrid'

export const basBcoProdColorsHeader = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
    ],
}
