<template>
    <div></div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/cmu/smsTrmsPrstMgmt/helpers'
export default {
    components: {},
    data() {
        return {
            showFlag: false,
            title: 'BasCmuSmsTrmsPrstMgmt',
            status: 1,
            isReadOnly: false,
            form: {},
        }
    },
    created() {},
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        open(param) {
            console.log('open-----', param)
        },
        close() {
            this.status = 1
            this.form = {}
            this.showFlag = false
        },
        clear() {},
    },
}
</script>

<style></style>
