import { ValueType } from 'realgrid'

export const UPRC_HEADER = {
    fields: [
        {
            fieldName: 'polYm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polTs',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyEndDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prdMdYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mdlCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'crudFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'uplstId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hstFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disCmpFnshYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'polYm',
            fieldName: 'polYm',
            editable: false,
            header: {
                text: '적용년월',
            },
        },
        {
            name: 'polTs',
            fieldName: 'polTs',
            editable: false,
            header: {
                text: '차수',
            },
        },
        {
            name: 'aplyStaDtm',
            fieldName: 'aplyStaDtm',
            editable: false,
            header: {
                text: '적용시작일시',
            },
        },
        {
            name: 'aplyEndDtm',
            fieldName: 'aplyEndDtm',
            editable: false,
            header: {
                text: '적용종료일시',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            editable: false,
            header: {
                text: '비고',
            },
        },
        {
            name: 'prdMdYn',
            fieldName: 'prdMdYn',
            editable: false,
            header: {
                text: '상품관리 변경여부',
            },
            styleCallback: function (grid, dataCell) {
                let ret = {}
                ret.styleName = 'red-column'
                ret.editable = false
                if (dataCell.value == '변경발생' || dataCell.value == 'U') {
                    return ret
                }
            },
        },
        {
            name: 'mdlCnt',
            fieldName: 'mdlCnt',
            editable: false,
            header: {
                text: '상품대상수',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            editable: false,
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            editable: false,
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            editable: false,
            header: {
                text: '처리일시',
            },
        },
    ],
}

// export const GNRL_HEADER = {
//     fields: [
//         {
//             fieldName: 'polYm',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'polTs',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'aplyStaDtm',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'aplyEndDtm',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'rmks',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'prdMdYn',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'mdlCnt',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'modUserId',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'modUserNm',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'modDtm',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'uplstId',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'delYn',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'disCmpFnshYn',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'hstFlag',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'crudFlag',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'popFlag',
//             dataType: ValueType.TEXT,
//         },
//     ],
//     columns: [
//         {
//             name: 'polYm',
//             fieldName: 'polYm',
//             header: {
//                 text: '적용년월',
//             },
//         },
//         {
//             name: 'polTs',
//             fieldName: 'polTs',
//             editable: false,
//             header: {
//                 text: '차수',
//             },
//         },
//         {
//             name: 'aplyStaDtm',
//             fieldName: 'aplyStaDtm',
//             editable: false,
//             header: {
//                 text: '적용시작일시',
//             },
//         },
//         {
//             name: 'aplyEndDtm',
//             fieldName: 'aplyEndDtm',
//             editable: false,
//             header: {
//                 text: '적용종료일시',
//             },
//         },
//         {
//             name: 'rmks',
//             fieldName: 'rmks',
//             editable: false,
//             header: {
//                 text: '비고',
//             },
//         },
//         {
//             name: 'prdMdYn',
//             fieldName: 'prdMdYn',
//             editable: false,
//             header: {
//                 text: '상품관리 변경여부',
//             },
//         },
//         {
//             name: 'mdlCnt',
//             fieldName: 'mdlCnt',
//             editable: false,
//             header: {
//                 text: '상품대상수',
//             },
//         },
//         {
//             name: 'modUserId',
//             fieldName: 'modUserId',
//             editable: false,
//             header: {
//                 text: '처리자ID',
//             },
//         },
//         {
//             name: 'modUserNm',
//             fieldName: 'modUserNm',
//             editable: false,
//             header: {
//                 text: '처리자',
//             },
//         },
//         {
//             name: 'modDtm',
//             fieldName: 'modDtm',
//             editable: false,
//             header: {
//                 text: '처리일시',
//             },
//         },
//     ],
// }
