import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'fixYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: '__rowState',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accSt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accMth',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd1',
            visible: false,
        },
        {
            fieldName: 'orgNm1',
            visible: false,
        },
        {
            fieldName: 'orgCd2',
            visible: false,
        },
        {
            fieldName: 'orgNm2',
            visible: false,
        },
        {
            fieldName: 'orgCd3',
            visible: false,
        },
        {
            fieldName: 'orgNm3',
            visible: false,
        },
        {
            fieldName: 'orgTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'evdDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'preAccAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'verifyObjYn',
            visible: false,
        },
        {
            fieldName: 'chkAccMth',
            visible: false,
        },
        {
            fieldName: 'chkAccPlc',
            visible: false,
        },
        {
            fieldName: 'expObjYn',
            visible: false,
        },
        {
            fieldName: 'forceAprvYn',
            visible: false,
        },
        {
            fieldName: 'expDueAmt',
            visible: false,
        },
        {
            fieldName: 'payReqDt',
            visible: false,
        },
    ],
    columns: [
        {
            name: 'fixYn',
            fieldName: 'fixYn',
            type: 'data',
            visible: false,
            width: '150',
        },
        {
            name: '__rowState',
            fieldName: '__rowState',
            type: 'data',
            visible: false,
            width: '150',
        },
        {
            name: 'accSt',
            fieldName: 'accSt',
            type: 'data',
            header: { text: '정산상태' },
            width: '150',
        },
        {
            name: 'accMth',
            fieldName: 'accMth',
            header: { text: '정산월' },
            type: 'data',
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            fieldName: 'orgCd1',
            visible: false,
        },
        {
            fieldName: 'orgNm1',
            header: { text: '사업담당' },
            visible: false,
        },
        {
            fieldName: 'orgCd2',
            visible: false,
        },
        {
            fieldName: 'orgNm2',
            header: { text: '영업팀' },
            visible: false,
        },
        {
            fieldName: 'orgCd3',
            visible: false,
        },
        {
            fieldName: 'orgNm3',
            header: { text: '영업파트' },
            visible: false,
        },
        {
            fieldName: 'orgTree',
            header: { text: '조직' },
            type: 'data',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd',
            header: { text: '정산처코드' },
            type: 'data',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm',
            header: { text: '정산처명' },
            type: 'data',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            header: { text: '매장코드' },
            type: 'data',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm',
            header: { text: '거래처구분' },
            type: 'data',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqSeq',
            header: { text: '요청순번' },
            type: 'data',
            dataType: ValueType.TEXT,
        },
        {
            name: 'fixDt',
            fieldName: 'fixDt',
            header: { text: '전기일' },
            type: 'data',
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            fieldName: 'evdDt',
            name: 'evdDt',
            header: { text: '증빙일' },
            type: 'data',
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            fieldName: 'preAccAmt',
            editor: { type: 'line' },
            header: { text: '선지급금액' },
            type: 'data',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            editable: true,
        },
        {
            fieldName: 'modUserNm',
            header: { text: '처리자' },
            type: 'data',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            header: { text: '처리일시' },
            type: 'data',
            dataType: ValueType.TEXT,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            fieldName: 'verifyObjYn',
            visible: false,
        },
        {
            fieldName: 'chkAccMth',
            visible: false,
        },
        {
            fieldName: 'chkAccPlc',
            visible: false,
        },
        {
            fieldName: 'expObjYn',
            visible: false,
        },
        {
            fieldName: 'forceAprvYn',
            visible: false,
        },
        {
            fieldName: 'expDueAmt',
            visible: false,
        },
        {
            fieldName: 'payReqDt',
            visible: false,
        },
    ],
}
