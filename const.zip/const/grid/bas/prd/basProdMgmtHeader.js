/*****************************************
* 업무 그룹명 : 게시판
* 서브 업무명 : 게시판
* 설 명 : 게시판 Grid 헤더 정보
* 작 성 자 : 배수현
* 작 성 일 : 2022.00.00
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 배수현  / 2022.00.00
* 변경사유/내역 : 
* ---------------------------------------
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const BAS_PROD_HEADER = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            header: {
                text: '운영상품코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            header: {
                text: '운영상품이름',
            },
        },
    ],
}

export const BAS_PROD_ACT_HEADER = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            header: {
                text: '운영상품코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            header: {
                text: '운영상품이름',
            },
        },
    ],
}
