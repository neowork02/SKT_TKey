<template>
    <div>
        <ul class="btn_area top">
            <!-- <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="regBtn"
                    :objAuth="this.objAuth"
                >
                    요건서 등록
                </TCComButton>
            </li> -->
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <!-- <div class="formitem div4">
                    <TCComDatePicker
                        v-model="schdDt"
                        :calType="calType5"
                        labelName="배치작업일자"
                        :eRequired="true"
                    />
                </div> -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="formSearchParams.bizId"
                        codeId="TKEY_BIS_ID"
                        labelName="업무구분"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="formSearchParams.midId"
                        codeId="TKEY_MID_ID"
                        labelName="업무중분류"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="수행주기"
                        v-model="formSearchParams.runCycleCd"
                        :itemList="searchCode[0]"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.batchProgId"
                        labelName="BATCH ID"
                        :size="150"
                        :maxlength="30"
                        :objAuth="objAuth"
                        @input="inputEvent()"
                        @enterKey="searchBtn"
                    />
                    <!-- <TCComInputSearchText
                        labelName="조직"
                        v-model="searchAuthOrgParam.orgNm"
                        :codeVal.sync="searchAuthOrgParam.orgCd"
                        :eRequired="true"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    /> -->
                </div>
            </div>
        </div>
        <!-- <Detail1Popup
            v-if="showPopup1"
            :parentParam="searchPopup1"
            :rows="resultPopup1Rows"
            :dialogShow.sync="showPopup1"
            @confirm="onPopup1ReturnData"
        /> -->
    </div>
</template>
<script>
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/batchOperRgstMgmt/helpers'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
//import CommonUtil from '@/utils/CommonUtil.js'
// eslint-disable-next-line no-unused-vars
import { msgTxt } from '@/const/msg.Properties.js'
//====================팝업1 팝업====================
//import Detail1Popup from './Detail1Popup'
//import Detail1Popup from '@/views/biz/bas/adm/docRgst/BasAdmDocRgst.vue'
//====================//팝업1 팝업====================
import CommonMixin from '@/mixins'
export default {
    mixins: [CommonMixin],
    components: {
        //TCComComboBox,
        //Detail1Popup,
    },
    async created() {
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            calType5: 'DP', //'M' //'DP' //'D'
            schdDt: [], //[]DP , ''D M
            searchCode: [
                [
                    {
                        commCdVal: 'HOUR',
                        commCdValNm: 'Hourly',
                    },
                    {
                        commCdVal: 'DAY',
                        commCdValNm: 'Daily',
                    },
                    {
                        commCdVal: 'WEEK',
                        commCdValNm: 'Weekly',
                    },
                    {
                        commCdVal: 'MON',
                        commCdValNm: 'Monthly',
                    },
                ],
                [
                    {
                        commCdVal: 'OP_DT',
                        commCdValNm: '작업일',
                    },
                    {
                        commCdVal: 'OBJ_DT',
                        commCdValNm: '대상일',
                    },
                    {
                        commCdVal: 'END_OF_MTH_DT',
                        commCdValNm: '월말일',
                    },
                ],
            ],
            //clsDt: '',
            payDtFrom: '',
            payDtTo: '',
            orgCd: '' /*조직코드*/,

            formSearchParams: {
                staDtm: '', //배치작업시작일시
                endDtm: '', //배치작업종료일시
                batchProgId: '', //배치ID
                bizId: '', //업무구분
                midId: '', //업무중분류
                opRsltCd: '', //작업결과
                dateFlag: '', //조회일자기준
                runCycleCd: '', //실행주기
            },
            // //====================팝업1 팝업관련====================
            // showPopup1: false, // 팝업1 팝업 오픈 여부
            // searchPopup1: {},
            // resultPopup1Rows: [], // 팝업1 팝업 오픈 여부
            // //====================//팝업1 팝업관련==================
        }
    },
    async mounted() {
        //화면초기 로딩시 바로 검색
        this.searchBtn()
    },
    computed: {
        ...serviceComputed,
        saveDone1: {
            get() {
                return this.saveDoneA && this.saveDoneB
            },
        },
    },
    methods: {
        ...serviceMethods,
        copyObjExist(obj1, obj2) {
            Object.keys(obj2).forEach(function (key) {
                if (key in obj1) {
                    obj1[key] = _.isEmpty(obj2[key]) ? '' : obj2[key]
                }
            })
        },
        initObj(obj1) {
            for (let prop in obj1) {
                if (Object.prototype.hasOwnProperty.call(obj1, prop)) {
                    obj1[prop] = ''
                }
            }
        },
        async initData() {
            let today = moment(new Date()).add(0, 'd').format('YYYY-MM-DD')
            let today1 = moment(new Date()).format('YYYY-MM-DD')
            this.schdDt = [today, today1] //DP
            //this.schdDt = today1 //D,M

            this.initObj(this.formSearchParams)
            this.formSearchParams.dateFlag = 'OP_DT' //조회일자기준:작업일 기본값

            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
        },
        async initBtn() {
            await this.initData()
            //this.searchBtn() //이화면은 초기화가 다시 조회처리

            //CommonUtil.clearPage(this.$router)
        },
        async searchBtn() {
            //DP 날짜범위경우
            // let payDtFrom = new Date(this.schdDt[0])
            // let payDtTo = new Date(this.schdDt[1])
            // if (payDtFrom > payDtTo) {
            //     this.showTcComAlert('시작일자가 마지막일자 보다 큽니다.')
            //     return
            // }

            // if (
            //     moment(payDtFrom).format('YYYY-MM') !=
            //         moment(payDtTo).format('YYYY-MM') &&
            //     _.isEmpty(this.formSearchParams.svcMgmtNum)
            // ) {
            //     this.showTcComAlert('같은 월 검색만 됩니다.')
            //     return
            // }
            // if (_.isEmpty(this.searchAuthOrgParam.orgCd)) {
            //     this.showTcComAlert('조직은 필수 입니다.')
            //     return //test 시 조건 해제
            // }

            // //this.formSearchParams.clsDt = this.clsDt.replace(/-/g, '')
            // this.formSearchParams.payDtFrom = this.schdDt[0].replace(/-/g, '') //DP
            // this.formSearchParams.payDtTo = this.schdDt[1].replace(/-/g, '') //DP

            //this.formSearchParams.reqDt = this.schdDt.replace(/-/g, '') //D, M
            //this.formSearchParams.reqOrgCd = this.searchAuthOrgParam.orgCd
            // this.formSearchParams.orgLvl = this.searchAuthOrgParam.orgLvl
            // this.formSearchParams.agencyCd = this.searchParamAgency.agencyCd //대리점
            // this.formSearchParams.sktSubCd = this.searchSwingDealIfForm.sktSubCd //수납처

            // this.formSearchParams.staDtm = this.schdDt[0].replace(/-/g, '') //DP
            // this.formSearchParams.endDtm = this.schdDt[1].replace(/-/g, '') //DP

            await this.defaultAssign_({ key: 'paging', value: this.initPaging })

            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 197 ~ searchBtn ~ this.formSearchParams',
                this.formSearchParams
            )
            let par1 = _.clone(this.formSearchParams)

            // Test data
            // let par1 = {
            //     staDtm: this.formSearchParams.staDtm, //'20221030', //배치작업시작일시
            //     endDtm: this.formSearchParams.endDtm, //'20221031', //배치작업종료일시
            //     batchProgId: '', //배치ID
            //     bizId: '', //업무구분
            //     midId: '', //업무중분류
            //     opRsltCd: '', //작업결과
            //     dateFlag: 'OP_DT', //조회일자기준
            //     runCycleCd: '', //실행주기
            // }

            await this.defaultAssign_({
                key: 'searchParams',
                value: par1,
            })
            //페이징 조회 ------------------------------
            //await this.searchData()

            //전체조회 --------------------------------
            await this.searchAllData(par1)
        },
        // async searchData() {
        //     //페이징 조회 ------------------------------
        //     await this.getBasAdmBatchOperRgstMgmtList_()
        // },
        async searchAllData(param1) {
            //전체조회 --------------------------------
            let data = await this.getBasAdmBatchOperRgstMgmtAllDatas_({
                param: param1,
            })
            if (data.length > 0) {
                await this.defaultAssign_({
                    key: 'resultList',
                    value: data,
                })
            } else {
                await this.defaultAssign_({
                    key: 'resultList',
                    value: [],
                })
            }
        },
        async inputEvent() {},
        //====================내부거래처 팝업====================
        // 팝업1 팝업 리턴 이벤트 처리
        // async onPopup1ReturnData(returnData) {
        //     console.log('Popup1 returnData new: ', returnData)
        //     // this.gridObj.gridView.commit()
        //     // this.gridObj.dataProvider.setValue(
        //     //     this.popupRowIndex,
        //     //     'agencyCd',
        //     //     returnData.orgCd
        //     // )
        //     //저장후 다시 조회 하는 경우
        //     //this.$emit('Refresh')
        //     //this.searchBtn()
        //     await this.searchAllData(this.searchParams)
        // },
        async saveBtn() {
            await this.defaultAssign_({
                key: 'saveAction',
                value: true,
            })
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        async saveDone1(val, oldVal) {
            if (val == true) {
                console.log('saveDone1: ', val, oldVal)
                //saveAction 작업들이 모두 완료 되면 default 상태로 변환

                await this.defaultAssign_({
                    key: 'saveAction',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: false,
                })
            }
        },
    },
}
</script>
