import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'apSeq', //매출순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgApSeq', //원매입순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDtm', // 매입일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wrtDt', // 전기일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'evdDt', // 증빙일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refId', // 입고번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refSeq', // 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inClNm', // 입고구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 정산처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsShopCd', // 매입처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoNm', // 매입처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoCd', // 매입처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsQty', // 수량
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prchsAmt', // 매입가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'splyPrc', // 공급가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세
            dataType: ValueType.NUMBER,
        },
        //////
        {
            fieldName: 'unsetAmt', // 미결금액
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'prchsDtm',
            fieldName: 'prchsDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'wrtDt',
            fieldName: 'wrtDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전기일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'evdDt',
            fieldName: 'evdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '증빙일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'refId',
            fieldName: 'refId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고번호',
        },
        {
            name: 'refSeq',
            fieldName: 'refSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '순번',
        },
        {
            name: 'inClNm',
            fieldName: 'inClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고구분',
        },
        {
            name: 'accShopCd',
            fieldName: 'accShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처매장코드',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처명',
        },
        {
            name: 'prchsShopCd',
            fieldName: 'prchsShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처매장코드',
        },
        {
            name: 'prchsDealcoCd',
            fieldName: 'prchsDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처',
        },
        {
            name: 'prchsDealcoNm',
            fieldName: 'prchsDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처명',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품명',
        },
        {
            name: 'prchsQty',
            fieldName: 'prchsQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '수량',
            numberFormat: '#,##0',
        },
        {
            name: 'prchsAmt',
            fieldName: 'prchsAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입가',
            numberFormat: '#,##0',
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공급가',
            numberFormat: '#,##0',
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '부가세',
            numberFormat: '#,##0',
        },
    ],
}

export const DETAIL_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 신규저장시 1 입력
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trClNm', // 거래구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trClCd', // 거래구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsQty', // 수량
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc', // 공급가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totAmt', // 합계 <-- 화면에만있음
            dataType: ValueType.NUMBER,
            valueExpression: "values['splyPrc'] + values['vatAmt']",
        },
        {
            fieldName: 'rmks', // 조정사유
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 정산처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsShopCd', // 매입처매장코드
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'trClNm',
            fieldName: 'trClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래구분',
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품',
            editable: false,
        },
        {
            name: 'prchsQty',
            fieldName: 'prchsQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '수량',
            numberFormat: '#,##0',
            editable: false,
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공급가',
            numberFormat: '#,##0',
            editable: true,
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '부가세',
            numberFormat: '#,##0',
            editable: true,
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '합계', // <-------   공급가+부가세 찾아보기 *****
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
            editable: false,
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: '조정사유',
            editable: true,
        },
    ],
}
