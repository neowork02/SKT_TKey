import api from '@/api/biz/bas/apm/basApmIntgAprvMgmt'
import types from './mutation-types'
import _ from 'lodash'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    async getBasAprmIntgAprvMgmt_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum

        await api
            .getBasAprmIntgAprvMgmt_({ searchParams })
            .then((data) => {
                let resultList = []
                let paging = state.initPaging
                console.log('data > ', data)
                if (data !== undefined) {
                    resultList = data.gridList
                    paging = data.pagingDto
                }

                commit(types.DEFAULT_ASSIGN, {
                    key: 'resultList',
                    value: resultList,
                })
                commit(types.DEFAULT_ASSIGN, {
                    key: 'paging',
                    value: paging,
                })
                resultData = data
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },

    async getBasAprmIntgAprvDtlMgmt_({ state, commit }) {
        let resultData
        let searchParams = state.searchParamsDtl
        searchParams.pageSize = state.initPagingDtl.pageSize
        searchParams.pageNum = state.pagingDtl.pageNum

        await api
            .getBasAprmIntgAprvDtlMgmt_({ searchParams })
            .then((data) => {
                let content = {}
                let resultList = []
                let paging = state.initPagingDtl

                if (data !== undefined) {
                    content = data
                    resultList = data.contentList.gridList
                    paging = data.contentList.pagingDto
                }

                commit(types.DEFAULT_ASSIGN, {
                    key: 'dltContent',
                    value: content,
                })
                commit(types.DEFAULT_ASSIGN, {
                    key: 'resultDtlList',
                    value: resultList,
                })
                commit(types.DEFAULT_ASSIGN, {
                    key: 'pagingDtl',
                    value: paging,
                })
                resultData = data
            })
            .catch((error) => {
                throw error
            })

        return resultData
    },
    async getAprvTypNmList_({ commit }, { menuGrpCd }) {
        let resultData

        await api
            .getAprvTypNmList_(menuGrpCd)
            .then((data) => {
                resultData = data
                if (_.isEmpty(data)) {
                    resultData = []
                }

                commit(types.DEFAULT_ASSIGN, {
                    key: 'aprvTypNmList',
                    value: resultData,
                })
            })
            .catch((error) => {
                throw error
            })
        return resultData
    },

    async postBasAprmIntgAprvMgmt_({ state }, { url }) {
        let result = 0
        let params = state.params

        await api
            .postBasAprmIntgAprvMgmt_({ params }, url)
            .then((data) => {
                result = data
            })
            .catch((error) => {
                throw error
            })
        return result
    },
}
