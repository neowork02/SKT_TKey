<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: SKT인센티브세금계산서관리
 * 설명: SKT인센티브세금계산서관리 조회,ERP 전송
 * 작성자: P180190
 * 작성일: 2022.06.28
------------------------------------------------>
<template>
    <div class="content">
        <h1>SKT인센티브세금계산서관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onSendErp"
                    >ERP 전송</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="init()"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="영업월"
                        calType="M"
                        :eRequired="true"
                        v-model="accYm_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchOrgAgencyParam.agencyNm"
                        :codeVal.sync="searchOrgAgencyParam.agencyCd"
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOrgAgencyEnterKey"
                        @appendIconClick="onOrgAgencyIconClick"
                        @input="onOrgAgencyInput"
                    />
                    <BasBcoOrgAgencysPopup
                        v-if="showBcoOrgAgencys"
                        :parentParam="searchOrgAgencyParam"
                        :rows="resultOrgAgencyRows"
                        :dialogShow.sync="showBcoOrgAgencys"
                        @confirm="onOrgAgencyReturnData"
                    />
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="인센티브 추정/확정 세부내역"
                :gridObj="gridObj"
                :isExceldown="true"
                @excelDownBtn="downloadExcelAll"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :editable="true"
                :movable="false"
                :columnMovable="false"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
// import commonApi from '@/api/common/prototype'
import { CommonUtil } from '@/utils'
import moment from 'moment'
//====================조직별대리점팝업====================
import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
//====================//조직별대리점팝업====================
import sktIncenApi from '@/api/biz/acc/sss/AccSssIncenTaxBillMgmt'
import { GRID_HEADER } from '@/const/grid/acc/sss/AccSssIncenTaxBillMgmtGrid'
import CommonMixin from '@/mixins'
export default {
    name: 'AccSssIncenTaxBillMgmt',
    title: 'SKT인센티브세금계산서관리',
    components: {
        BasBcoOrgAgencysPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            //Grid
            objAuth: {},
            tabDefault: {},
            gridObj: {},
            gridHeaderObj: {},
            checked: 'false',

            searchForms: {},
            searchFormsList: {},
            rowData: '',
            chk: '',

            accYm_: moment(new Date()).format('YYYY-MM'),
            accYm: moment(new Date()).format('YYYY-MM'),

            //요청 파라미터
            searchFormData: {
                accYm: '',
                agencyCd: '',
                chk1: '',
                chk2: '',
            },
            // searchListData: {
            //     transList1: [],
            //     transList2: [],
            // },

            /* popup영역 */
            //====================조직별대리점팝업관련====================
            showBcoOrgAgencys: false, // 조직별대리점 팝업 오픈 여부
            searchOrgAgencyParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultOrgAgencyRows: [], // 조직별대리점 팝업 오픈 여부
            //====================//조직별대리점팝업관련==================

            popupParams: {},
            dtlParam: {},
            popup: {
                adjustDtl: {
                    showBool: false,
                },
            },
        }
    },
    mounted() {
        // 첫번째 그리드 세팅
        this.grid = this.$refs.grid
        this.gridHeader = this.$refs.gridHeader
        this.grid.setGridState(false, false, true, true)
        // this.grid.gridView.setRowIndicator({
        //     visible: true,
        //     headText: '번호',
        // })
        this.$refs.grid.gridView.setColumnLayout(this.view.layout) //그리드 Header Layout 세팅하기
        this.grid.gridView.displayOptions.selectionStyle = 'rows'
        this.grid.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        // 미전송건만 체크 가능하게
        this.grid.gridView.applyCheckables()
        this.grid.gridView.setCheckableExpression(
            "values['erpTrnsYn1'] = 'N'",
            false
        )
        this.grid.gridView.onColumnCheckedChanged = this.onColumnCheckedChanged
        this.grid.gridView.onColumnPropertyChanged =
            this.onColumnPropertyChanged
        this.checkColumn = this.grid.gridView.columnByName('chk2')
        this.checked = this.checkColumn.checked
        console.log(this.checked)
        this.grid.gridView.onEditRowChanged = this.onEditRowChanged
        this.grid.gridView.onGetEditValue = this.onGetEditValue
    },
    computed: {},
    watch: {
        checked(chk) {
            console.log('chk2 헤더체크::::', chk)
        },
    },
    methods: {
        onEditRowChanged: function (
            grid,
            itemIndex,
            dataRow,
            field,
            oldValue,
            newValue
        ) {
            grid.getValue(itemIndex, field)
            console.log(
                'onEditRowChanged, ' +
                    field +
                    ': ' +
                    oldValue +
                    ' => ' +
                    newValue
            )

            if (oldValue == 1) {
                if (newValue == 0) {
                    this.checkColumn.checked = false
                    console.log(this.checked)
                }
            }
        },
        onGetEditValue: function (grid, index, editResult) {
            console.log(grid, ':', index, ':', editResult)
        },
        onColumnCheckedChanged: function (grid, col, chk) {
            console.log(col.name + 'was checked as: ' + chk)
            var fieldRow = this.grid.dataProvider.getFieldValues('chk2', 0, -1)
            fieldRow.forEach((data, i) => {
                if (chk && fieldRow[i] != 'E') {
                    this.grid.gridView.setValue(i, 'chk2', '1')
                } else {
                    if (fieldRow[i] == '1') {
                        this.grid.gridView.setValue(i, 'chk2', '0')
                    }
                }
                this.grid.gridView.commit()
            })
        },

        // 초기화
        init: function () {
            this.accYm_ = moment(new Date()).format('YYYY-MM')
            this.searchForms = {}
            this.searchFormData = {
                srchSettlOperClCd: '',
            }
            this.grid.setRows([])
            this.searchOrgAgencyParam = {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            }
            this.resultOrgAgencyRows = []
            this.checkColumn.checked = false
        },

        //===================== //내부거래처(거래종료확인) methods ================================

        //===================== //내부거래처(권한조직) methods ================================

        //===================== 조직별 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getOrgAgencyList() {
            basBcoOrgAgencysApi
                .getOrgAgencyList(this.searchOrgAgencyParam)
                .then((res) => {
                    console.log('getOrgAgencyList then : ', res)
                    // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                    // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                    if (res.length === 1) {
                        this.searchOrgAgencyParam.agencyCd = _.get(
                            res[0],
                            'agencyCd'
                        )
                        this.searchOrgAgencyParam.agencyNm = _.get(
                            res[0],
                            'agencyNm'
                        )
                    } else {
                        this.resultOrgAgencyRows = res
                        this.showBcoOrgAgencys = true
                    }
                })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onOrgAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            // if (!_.isEmpty(this.searchOrgAgencyParam.agencyNm)) {
            //     this.getOrgAgencyList()
            // } else {
            this.showBcoOrgAgencys = true
            // }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onOrgAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgAgencyRows = []
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            // if (_.isEmpty(this.searchOrgAgencyParam.agencyNm)) {
            //     this.showTcComAlert('대리점명을 입력해주세요.')
            //     return
            // }
            // 대리점 정보 조회
            // this.getOrgAgencyList()
            this.showBcoOrgAgencys = true
        },
        // 대리점 TextField Input 이벤트 처리
        onOrgAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.searchOrgAgencyParam.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onOrgAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchOrgAgencyParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.searchOrgAgencyParam.agencyNm = _.get(retrunData, 'agencyNm')
        },
        //===================== //조직별대리점팝업관련 methods ================================

        //================================================
        // :::: 전체 조회 ::::
        // getSktCmmsIncenAccList
        //================================================
        onSearch: function () {
            const srchAccYm = this.accYm_
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('영업월을 확인하세요.')
            } else {
                this.grid.gridView.commit()
                this.searchFormData.srchAccYm = CommonUtil.onlyNumber(
                    this.accYm_
                )
                this.searchForms.pageNum = 1
                this.searchFormData.srchAgencyCd =
                    this.searchOrgAgencyParam.agencyCd
                this.searchForms = { ...this.searchFormData }
                this.getIncenTaxBillList(this.searchForms)
                console.log('인센티브세금계산서관리 전체조회 ::::::: 시작')
            }
        },
        getIncenTaxBillList() {
            sktIncenApi.getIncenTaxBillList(this.searchForms).then((res) => {
                if (res) {
                    console.log(
                        '인센티브세금계산서관리(조직) 전체조회 ::::::: ',
                        res
                    )
                    this.grid.setRows(res.gridList)
                    this.grid.setGridIndicator()
                    console.log('인센티브세금계산서관리 전체조회 ::::::: 끝')
                    this.checkColumn.checked = false
                    this.grid.gridView.commit()
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },

        //================================================
        // 선택한 row ERP 전송 1차/ 2차 ::::
        //================================================
        onSendErp: function () {
            this.searchForms.accYm = CommonUtil.onlyNumber(this.accYm_)
            //1차 체크된 row count
            var transList1 = this.$refs.grid.gridView.getCheckedItems(true)
            //그리드 모든 row count
            var transListsCount = this.$refs.grid.gridView.getItemCount()
            this.searchForms.transList2 = []
            //2차 체크된 row값 가져와 transList2에 담기
            for (var j = 0; j < transListsCount; j++) {
                var rowData2 = this.$refs.grid.gridView.getValues(j)
                if (rowData2.chk2 == '1') {
                    this.searchForms.transList2.push({
                        accYm: this.searchForms.accYm,
                        agencyCd: rowData2.agencyCd,
                        chk1: '0',
                        chk2: rowData2.chk2,
                    })
                    if (
                        rowData2['erpTrnsYn1'] == 'N' &&
                        rowData2['totAmt1'] > 0
                    ) {
                        console.log(rowData2['erpTrnsYn1'])
                        this.showTcComAlert(
                            rowData2['agencyNm'] +
                                '은(는) 1차발급건에 대해서 ERP전송이 이루어지지 않았습니다.'
                        )
                        return
                    }
                }
            }
            this.grid.gridView.commit()
            console.log(
                '2차 ERP전송 데이터 생성(transLists) :::::::',
                this.searchForms.transList2
            )
            console.log(
                '2차 ERP전송 데이터',
                this.searchForms.transList2.length,
                '개'
            )
            //1차 체크된 row값 가져와 transList1에 담기
            this.searchForms.transList1 = []
            this.searchForms.accYm = CommonUtil.onlyNumber(this.accYm_)
            for (var i = 0; i < transList1.length; i++) {
                var rowData1 = this.$refs.grid.gridView.getValues(transList1[i])
                this.searchForms.transList1.push({
                    accYm: this.searchForms.accYm,
                    agencyCd: rowData1.agencyCd,
                    chk1: '1',
                    chk2: rowData1.chk2,
                })
            }
            console.log(
                '1차 ERP전송 데이터 생성(transLists) :::::::',
                this.searchForms.transList1
            )
            console.log('1차 ERP전송 데이터', transList1.length, '개')
            // this.transIncenTaxBillList()
            if (transList1.length == 0 && this.searchForms.transList2 == 0) {
                this.showTcComAlert('처리할 대상이 없습니다.')
                return
            } else {
                this.searchFormsList.transList = [
                    ...this.searchForms.transList1,
                    ...this.searchForms.transList2,
                ]
                console.log(this.searchFormsList.transList)
                this.transIncenTaxBillList()
            }
        },
        async transIncenTaxBillList() {
            sktIncenApi
                .transIncenTaxBillList(this.searchFormsList)
                .then((resultData) => {
                    if (resultData == undefined) {
                        this.showTcComAlert('ERP전송 처리실패하였습니다.')
                        return
                    } else {
                        console.log(
                            this.rowData + '선택리스트확정 ::::::: 종료'
                        )
                        this.showTcComAlert('확정 처리되었습니다.')
                        this.grid.gridView.commit()
                        this.onSearch()
                    }
                })
        },

        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcelAll: function () {
            sktIncenApi.downloadIncenTaxBillListExcel(this.searchFormData)
            console.log(this.searchFormData)
        },
    },
}
</script>
