<template>
    <TCComDialog :dialogShow.sync="showBbsUserMgmt" size="1500px">
        <template #content>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
            <CsvPopup
                v-if="showBool === true"
                ref="popup"
                :dialogShow.sync="showBool"
            />
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">대상아이디 선택</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            labelName="CSV 업로드(엑셀파일양식)"
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_save"
                                            @click="onCsvClick"
                                        >
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>

                            <div class="formitem div2">
                                <TCComFileInput
                                    v-model="files"
                                    ref="fileExcelTemplate"
                                    @change="onFilesChange"
                                ></TCComFileInput>
                            </div>
                        </div>
                    </div>
                    <div class="contBoth mgt-20">
                        <div class="div5_5 cont1-1 left">
                            <TCRealGridHeader
                                id="gridUserHeader"
                                ref="gridUserHeader"
                                gridTitle="선택대상아이디"
                                :gridObj="gridObj1"
                            >
                                <template #gridElementArea>
                                    <TCComInput
                                        v-model="searchWord1"
                                        labelName="검색"
                                        :objAuth="objAuth"
                                        @enterKey="onEnterKey1"
                                    ></TCComInput>
                                </template>
                            </TCRealGridHeader>

                            <TCRealGrid
                                id="gridUser"
                                ref="gridUser"
                                :fields="view1.fields"
                                :columns="view1.columns"
                            />
                            <div>
                                대상아이디가 있는 경우 대상아이디와 작성자만
                                해당 게시물을 조회 할 수 있습니다.
                            </div>
                        </div>

                        <div class="div5_5 cont3">
                            <ul class="btnOrder">
                                <li>
                                    <TCComButton
                                        :Vuetify="false"
                                        color=""
                                        eClass="btnOrderleft"
                                        @click="onLeft"
                                    >
                                    </TCComButton>
                                </li>
                                <li>
                                    <TCComButton
                                        :Vuetify="false"
                                        color=""
                                        eClass="btnOrderright"
                                        @click="onRight"
                                    >
                                    </TCComButton>
                                </li>
                            </ul>
                        </div>
                        <div class="div5_5 cont1-1 right pl0">
                            <TCRealGridHeader
                                id="gridUserListHeader"
                                ref="gridUserListHeader"
                                gridTitle="리스트"
                                :gridObj="gridObj"
                            >
                                <template #gridElementArea>
                                    <TCComInput
                                        v-model="searchWord"
                                        labelName="검색"
                                        :objAuth="objAuth"
                                        @enterKey="onEnterKey"
                                    ></TCComInput>
                                </template>
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="gridUserList"
                                ref="gridUserList"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                    </div>

                    <!--layerCont-->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            선택
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            :objAuth="objAuth"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import {
    USER_LIST_HEADER,
    USER_CHK_LIST_HEADER,
} from '@/const/grid/bas/bbs/basBbsMgmtHeader'
import CsvPopup from '@/views/biz/bas/bbs/BasBbsCsvPopMgmt'
import { FileUtil } from '@/utils'
import * as XLSX from 'xlsx'
import _ from 'lodash'
import CommonUtil from '@/utils/CommonUtil.js'
import basBbsMgmtApi from '@/api/biz/bas/bbs/basBbsMgmt'
// import _ from 'lodash'
export default {
    name: 'BasBbsUser',
    mixins: [CommonMixin],
    components: { CsvPopup },
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },

        parentParam: { type: Object, default: () => [], required: false },
    },
    data() {
        return {
            gridObj: {},
            gridData: {},
            gridHeaderObj: {},
            gridObj1: {},
            gridData1: {},
            gridHeaderObj1: {},
            objAuth: {},
            forms: {
                userNm: '', // 사용자명
                userId: '', // 사용자아이디
                orgCd: '',
            },
            users: {
                userId: [], // 사용자아이디
            },
            gridList: [],
            selectedData: {},
            showAlertBool: false,
            headerText: '',
            alertBodyText: '',
            view: USER_LIST_HEADER,
            view1: USER_CHK_LIST_HEADER,
            searchWord: '',
            searchWord1: '',
            files: null,
            showBool: false,
        }
    },
    computed: {
        showBbsUserMgmt: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.parentParam = value
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {},
    mounted() {
        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.gridUserList
        this.gridHeaderObj = this.$refs.gridUserListHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, false, true, false)

        this.gridObj1 = this.$refs.gridUser
        this.gridHeaderObj1 = this.$refs.gridUserHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj1.setGridState(false, false, true, false)
        this.initGrid()
        this.getBasBbsUserList()
        //this.getBasBbsUserList2()
    },
    methods: {
        initGrid() {
            // 그리드 이벤트 처리
            if (!this.rows.length) {
                this.onLeft()
            } else {
                this.onRight()
            }
        },
        onCsvClick() {
            this.showBool = true
        },
        onFilesChange(files) {
            this.excelUploadFile(files)
        },
        excelUploadFile(files) {
            const f = files
            if (!_.isUndefined(f) && !_.isNull(f)) {
                const reader = new FileReader()

                reader.onload = (e) => {
                    const data = e.target.result
                    // Array Buffer인 경우 base64로 변환 처리
                    const arr = FileUtil.arrayBufferFixdata(data)
                    const workbook = XLSX.read(FileUtil.encodeBase64(arr), {
                        type: 'base64',
                        cellText: true,
                        cellDates: true,
                    })
                    // 워크북 처리(1줄 헤더 포함 처리)
                    this.processWorkbook(workbook)
                }
                reader.readAsArrayBuffer(f)
            }
        },
        // 워크북 처리(1줄 헤더 포함 처리)
        processWorkbook(wb) {
            const output = FileUtil.excelTojson(wb)
            const sheetNames = Object.keys(output)
            let sameCnt = 0
            if (sheetNames.length) {
                const colsObj = output[sheetNames][0]
                if (colsObj) {
                    const data = output[sheetNames]
                    let lists = this.gridObj.dataProvider.getJsonRows()
                    let listLength = this.gridObj.dataProvider.getRowCount()
                    let arrayIdx = []
                    console.log('processWorkbook: ', data)
                    if (CommonUtil.checkJsonStrDocSecurity(data)) {
                        this.showTcComAlert(
                            '문서보안 엑셀 파일입니다.\n확인 후 다시 업로드해주세요.'
                        )
                        return
                    }

                    data.map((item) => {
                        for (let idx = 0; idx < listLength; idx++) {
                            if (lists[idx].userId == Object.values(item)) {
                                this.gridObj1.dataProvider.insertRow(
                                    0,
                                    lists[idx]
                                )
                                //console.log('1111111111', lists[idx])
                                arrayIdx.push(idx)
                                sameCnt++
                            }
                        }
                    })
                    this.gridObj.dataProvider.removeRows(arrayIdx)
                }
            }

            if (0 === sameCnt) {
                this.showTcComAlert(
                    '리스트 내 동일한 아이디가 존재하지 않습니다. <br> 확인 후 다시 업로드해주세요.'
                )
            } else {
                this.showTcComAlert(
                    '성공 <br> 선택대상아이디에 추가되었습니다.'
                )
            }
        },
        onExcelUpload() {
            this.$refs.fileExcelTemplate.clearFileInputValue()
            this.gridObj1.dataProvider.clearRows()
            this.$refs.fileExcelTemplate.fileInputClick()
        },
        getBasBbsUserList() {
            this.forms.orgCd = this.parentParam.orgCd
            this.parentParam.orgCd = this.forms.orgCd
            console.log('11111', this.parentParam)
            basBbsMgmtApi
                .getBasBbsUserList(this.parentParam)
                .then((resultData) => {
                    console.log('resultData', resultData)
                    this.gridList = resultData
                    this.gridObj.setRows(this.gridList)
                    // if (this.gridList.length) {
                    //     for (let i = 0; i < this.gridList.length; i++) {
                    //         if (
                    //             this.gridList[i].userId ==
                    //             this.parentParam.userId[i]
                    //         ) {
                    //             this.gridObj1.setRows(this.gridList)
                    //         }
                    //     }
                    // }
                    let pageInfo = {}
                    pageInfo.type = 'noPaging' //페이징이 없는경우
                    pageInfo.totalDataCnt =
                        this.gridObj.dataProvider.getRowCount()
                    this.gridObj.setGridIndicator(pageInfo)
                })
        },
        getBasBbsUserList2() {
            basBbsMgmtApi
                .getBasBbsChkUserList(this.parentParam)
                .then((resultData) => {
                    this.gridList = resultData
                    this.gridObj1.setRows(this.gridList)
                    let pageInfo = {}
                    pageInfo.type = 'noPaging' //페이징이 없는경우
                    pageInfo.totalDataCnt =
                        this.gridObj1.dataProvider.getRowCount()
                    this.gridObj1.setGridIndicator(pageInfo)
                })
        },
        onClose() {
            this.showBbsUserMgmt = false
        },
        onLeft() {
            //체크된
            let chkRow = this.gridObj.gridView.getCheckedRows(true)
            //체크된 행 이동
            for (var i = 0; i < chkRow.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(chkRow[i])
                //그리드에 표시
                this.gridObj1.dataProvider.insertRow(0, row)
            }
            this.gridObj.dataProvider.removeRows(chkRow)
        },
        onRight() {
            let chkRow = this.gridObj1.gridView.getCheckedRows(true)
            //체크된 행 이동
            for (var i = 0; i < chkRow.length; i++) {
                let row = this.gridObj1.dataProvider.getJsonRow(chkRow[i])
                //그리드에 표시
                this.gridObj.dataProvider.addRow(row)
            }
            this.gridObj1.dataProvider.removeRows(chkRow)
        },
        onConfirm() {
            const jsonData = this.gridObj1.dataProvider.getJsonRows()
            if (jsonData.length == 0) {
                this.showAlertBool = true
                this.headerText = '대상자'
                this.alertBodyText = '대상자를 선택해주세요.'
                return
            }
            this.$emit('confirm', jsonData)
            this.onClose()
        },
        searchItem(startIndex) {
            console.log('111')
            const leng1 = this.gridObj.dataProvider.getJsonRows().length
            const rows1 = this.gridObj.dataProvider.getJsonRows()
            for (let i = startIndex; i < leng1; i++) {
                let val1 = rows1[i].userNm
                let val2 = rows1[i].orgNm
                let val3 = rows1[i].dealcoCd
                let val4 = rows1[i].dealcoNm

                if (val1) {
                    if (val1.includes(this.searchWord)) {
                        this.gridObj.gridView.setCurrent({ itemIndex: i })
                        return true
                    }
                }
                if (val2) {
                    if (val2.includes(this.searchWord)) {
                        this.gridObj.gridView.setCurrent({ itemIndex: i })
                        return true
                    }
                }
                if (val3) {
                    if (val3.includes(this.searchWord)) {
                        this.gridObj.gridView.setCurrent({ itemIndex: i })
                        return true
                    }
                }
                if (val4) {
                    if (val4.includes(this.searchWord)) {
                        this.gridObj.gridView.setCurrent({ itemIndex: i })
                        return true
                    }
                }
            }
            return false
        },
        onEnterKey() {
            //if (_.isEmpty(this.resultData)) return

            let startIndex =
                (this.gridObj.gridView.getCurrent().itemIndex + 1) %
                this.gridObj.gridView.getItemCount()

            if (
                this.gridObj.gridView.getCurrent().itemIndex ==
                this.gridObj.gridView.getItemCount() - 1
            )
                startIndex = 0

            let found = this.searchItem(startIndex)
            if (startIndex != 0 && !found) {
                found = this.searchItem(0)
            }
            if (!found) {
                this.showTcComSnackbar('검색 해당 건이 없습니다.')
            }
        },
        searchItem1(startIndex) {
            const leng1 = this.gridObj1.dataProvider.getJsonRows().length
            const rows1 = this.gridObj1.dataProvider.getJsonRows()
            for (let i = startIndex; i < leng1; i++) {
                let val1 = rows1[i].userNm
                let val2 = rows1[i].orgNm
                let val3 = rows1[i].dealcoCd
                let val4 = rows1[i].dealcoNm
                if (val1) {
                    if (val1.includes(this.searchWord1)) {
                        this.gridObj1.gridView.setCurrent({ itemIndex: i })
                        return true
                    }
                }
                if (val2) {
                    if (val2.includes(this.searchWord1)) {
                        this.gridObj1.gridView.setCurrent({ itemIndex: i })
                        return true
                    }
                }
                if (val3) {
                    if (val3.includes(this.searchWord1)) {
                        this.gridObj1.gridView.setCurrent({ itemIndex: i })
                        return true
                    }
                }
                if (val4) {
                    if (val4.includes(this.searchWord1)) {
                        this.gridObj1.gridView.setCurrent({ itemIndex: i })
                        return true
                    }
                }
            }
            return false
        },
        onEnterKey1() {
            //if (_.isEmpty(this.resultData)) return
            let startIndex =
                (this.gridObj1.gridView.getCurrent().itemIndex + 1) %
                this.gridObj1.gridView.getItemCount()
            if (
                this.gridObj1.gridView.getCurrent().itemIndex ==
                this.gridObj1.gridView.getItemCount() - 1
            )
                startIndex = 0

            let found = this.searchItem1(startIndex)
            if (startIndex != 0 && !found) {
                found = this.searchItem1(0)
            }
            if (!found) {
                this.showTcComSnackbar('검색 해당 건이 없습니다.')
            }
        },
    },
}
</script>
<style scoped>
.fl_left {
    display: block;
    float: left;
}
.wd40p {
    width: 40%;
}
.wd43p {
    width: 43%;
}
.btn_ds {
    width: 13%;
    height: 60px;
    position: relative;
    margin-top: 25%;
}
</style>
