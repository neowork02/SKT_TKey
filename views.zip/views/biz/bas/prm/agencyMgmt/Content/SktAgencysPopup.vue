<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="700px">
        <template #content>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyTextAgency"
            ></TCComAlert>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">SKT대리점 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParam.orgCd"
                                    labelName="대리점코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchParam.orgNm"
                                    labelName="대리점명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- <div class="formitem div4">
                                <TCComComboBox
                                    v-model="searchParam.agencyTyp"
                                    codeId="AGENCY_TYP"
                                    labelName="대리점 유형"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div> -->
                            <!-- // input -->
                        </div>
                        <!-- // Search_line 1 -->
                        <!-- Search_line 2 -->
                        <!-- <div class="searchform">
                            <div class="formitem div4">
                                <TCComDatePicker
                                    v-model="searchParam.searchDateModel"
                                    labelName="조회기준일"
                                    :objAuth="objAuth"
                                ></TCComDatePicker>
                            </div>
                            <div class="formitem div4"></div>
                            <div class="formitem div4"></div>
                            <div class="formitem div4">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                        </div> -->
                        <!-- // Search_line 2 -->
                    </div>
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">대리점 목록</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="agencyMgmtAgencyGrid"
                                ref="agencyMgmtAgencyGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                                @hook:mounted="gridMounted"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/agencyMgmt/helpers'
import { CommonGrid, CommonUtil } from '@/utils'
import { SKT_AGENCYS_HEADER } from '@/const/grid/bas/prm/basPrmAgencyMgmtHeader'
//import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
import commonApi from '@/api/common/commonCode'
import moment from 'moment'
// import _ from 'lodash'

export default {
    name: 'basPrmAgencyMgmtAgencysPopup',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: SKT_AGENCYS_HEADER,
            showAlertBool: false,
            alertBodyTextAgency: '',
            headerText: '',
            searchParam: {
                agencyRgstCl: '', // 대리점등록구분
                agencyTyp: '', // 대리점유형
                agencyPtn: '', // 대리점구분코드
                orgCd: '', // 대리점코드
                orgNm: '', // 대리점명
                searchDateModel: '', // 조회기준일(v-model)
                searchDate: '', // 조회기준일
            },
        }
    },
    computed: {
        ...serviceComputed,
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchParam.orgNm = value['orgNm']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },
    mounted() {
        this.gridObj = this.$refs.agencyMgmtAgencyGrid // Grid Object 설정
        this.initGrid()
    },
    methods: {
        ...serviceMethods,
        init() {
            this.gridData = this.gridSetData()
            this.searchParam.searchDateModel = moment().format('YYYY-MM-DD')
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false)
            this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

            //const commAgencyPtn = await this.getCommCodeList('AGENCY_PTN')
            //const commAgencyTyp = await this.getCommCodeList('AGENCY_TYP')

            // // 대리점 구분 lOV
            // this.gridObj.gridView.columnByName('agencyClCd').values =
            //     CommonUtil.convListToGridLovValues(commAgencyPtn, 'commCdVal')
            // this.gridObj.gridView.columnByName('agencyClCd').labels =
            //     CommonUtil.convListToGridLovLabels(commAgencyPtn, 'commCdValNm')
            // // 대리점 유형 lOV
            // this.gridObj.gridView.columnByName('agencyTypCd').values =
            //     CommonUtil.convListToGridLovValues(commAgencyTyp, 'commCdVal')
            // this.gridObj.gridView.columnByName('agencyTypCd').labels =
            //     CommonUtil.convListToGridLovLabels(commAgencyTyp, 'commCdValNm')

            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },

        gridMounted() {
            //console.log('gridMounted')
        },

        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            //console.log('getCommCodeList res: ', res)
            return res
        },

        async getAgencyList() {
            this.searchParam.searchDate = CommonUtil.replaceDash(
                this.searchParam.searchDateTemp
            )
            await this.getBasPrmAgencyMgmtAgencys_({
                param: this.searchParam,
            }).then((res) => {
                //console.log('getAgencyList then : ', res)
                this.gridObj.setRows(res)
            })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showAlertBool = true
                this.headerText = '대리점 선택'
                this.alertBodyTextAgency = '대리점을 선택해주세요.'
                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenAgency = false
        },

        onSearch() {
            this.getAgencyList()
        },

        onEnterKey() {
            this.onSearch()
        },
    },
}
</script>
