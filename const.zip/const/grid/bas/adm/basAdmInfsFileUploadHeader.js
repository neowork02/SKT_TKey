import { ValueType } from 'realgrid'

export const FILE_UPLOAD_HEADER = {
    fields: [
        {
            fieldName: 'templetSeq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'seq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'templetCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'templetNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'calYearMonth',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'titleNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'phyFileNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zipFileNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stateCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stateNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstrUserId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'templetNm',
            fieldName: 'templetNm',
            header: {
                text: '업로드구분',
            },
        },
        {
            name: 'calYearMonth',
            fieldName: 'calYearMonth',
            header: {
                text: '정산월',
            },
        },
        {
            name: 'titleNm',
            fieldName: 'titleNm',
            header: {
                text: '제목',
            },
        },
        {
            name: 'phyFileNm',
            fieldName: 'phyFileNm',
            header: {
                text: '파일',
            },
        },
        {
            name: 'zipFileNm',
            fieldName: 'zipFileNm',
            header: {
                text: 'ZIP',
            },
        },
        {
            name: 'stateNm',
            fieldName: 'stateNm',
            header: {
                text: '상태',
            },
            editable: false,
            styleCallback() {
                const ret = { styleName: 'underLine' }
                return ret
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            header: {
                text: '등록자',
            },
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            header: {
                text: '등록일',
            },
        },
    ],
}
