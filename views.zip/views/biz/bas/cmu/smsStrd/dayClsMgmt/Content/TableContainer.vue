<template lang="">
    <div class="gridWrap">
        <TCRealGridHeader
            id="smsTrmsStrdMgmtGridHeader1"
            ref="smsTrmsStrdMgmtGridHeader1"
            gridTitle="목록"
            :gridObj="gridObj"
            :isPageRows="true"
            :isExceldown="true"
            :isNextPage="false"
            :isPageCnt="false"
            :editable="true"
            :isAddRow="false"
            :isDelRow="false"
            :addData="this.addData"
            @excelDownBtn="onClickDownload"
            @addRowBtn="this.gridAddRowBtn"
            @chkDelRowBtn="this.gridchkDelRowBtn"
        />
        <TCRealGrid
            id="smsTrmsStrdMgmtGrid1"
            ref="smsTrmsStrdMgmtGrid1"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
        <!-- 개발vdi BE 리소스 부족으로 테스트 못함 state.js 파일에서 initPaging.pageSize 를 100 이하로 조정해서 테스트 할것-->
        <!-- 테스트시 페이지 해제와 페이지 사이즈 100 이하 조정후 테스트 할것 -->
        <!-- AS-IS 방식말고 새로운 BE 에서 필터링하는 방식으로 바꿔야 함.  2022-10-26 스크럼 회의때 이슈화 : 이재호 차장 담당 -->
        <!-- 새로운 방식으로 바꾼다면 새 일정이 필요함.  2022-10-26 스크럼 회의때 이슈화 : 이재호 차장 담당 -->
        <TCComPaging
            :totalPage="paging1.totalPageCnt"
            :apiFunc="pageMove"
            :rowCnt="paging1.pageSize"
            @input="pageSizeChange"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/cmu/smsStrd/saleChgMgmt/helpers'
import { M_HEADER } from '@/const/grid/bas/cmu/basSmsSaleChgMgmtHeader'
import { CommonGrid } from '@/utils'
import CommonMsg from '@/utils/CommonMsg'
import { msgTxt } from '@/const/msg.Properties.js'
import attachedFileApi from '@/api/common/attachedFile'
import _ from 'lodash'
import CommonMixin from '@/mixins'
export default {
    mixins: [CommonMixin],
    components: {},
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '340px', //그리드 높이 조절
            },
            view: M_HEADER,
            layout: [
                //'pagingSeq',
                'chk', //체크
                'treeOrgNm', //조직
                'mblPhonNo1', //권한
                'mblPhonNo2', //사용자
                'smsYn', //전체
                // {
                //     name: 'group01',
                //     direction: 'horizontal',
                //     items: ['smsSaleYn', 'smsAllotAddYn', 'smsAllotCnclYn'],
                //     header: {
                //         text: '변경이력',
                //     },
                // },
                'smsSaleYn', //판매SMS전송여부
                'smsAllotAddYn', //할부추가여부
                'smsAllotCnclYn', //할부취소SMS전송여부
                'smsSuplYn', //부가상품여부
            ],
            //행추가시 기본값
            // addData: [
            // '', //chk 체크
            // '', //sktChnlCd UKEY채널코드
            // '', //dealcoCd 거래처코드
            // '', //dealcoNm 거래처명
            // '', //orgNm 소속조직
            // '', //mblPhonNo1 전화번호1
            // '', //mblPhonNo2 전화번호2
            // '', //mblPhonNo3 전화번호3
            // '', //mblPhonNo4 전화번호4
            // '', //mblPhonNo5 전화번호5
            // '', //mblPhonNo6 전화번호6
            // '', //mblPhonNo7 전화번호7
            // '', //mblPhonNo8 전화번호8
            // '', //mblPhonNo9 전화번호9
            // '', //mblPhonNo10 전화번호10
            // '', //smsYn SMS전송여부
            // '', //smsSaleYn 판매SMS전송여부
            // '', //smsAllotAddYn 할부추가여부
            // '', //smsAllotCnclYn 할부취소SMS전송여부
            // '', //smsSuplYn 부가상품여부
            // '', //modUserId 수정사용자ID
            // '', //modDtm 수정일시
            // ],
            //행추가시 기본값 테스트용
            addData: [
                '', //chk 체크
                '', //sktChnlCd UKEY채널코드
                '', //dealcoCd 거래처코드
                '', //dealcoNm 거래처명
                '', //orgNm 소속조직
                '', //mblPhonNo1 전화번호1
                '', //mblPhonNo2 전화번호2
                '', //mblPhonNo3 전화번호3
                '', //mblPhonNo4 전화번호4
                '', //mblPhonNo5 전화번호5
                '', //mblPhonNo6 전화번호6
                '', //mblPhonNo7 전화번호7
                '', //mblPhonNo8 전화번호8
                '', //mblPhonNo9 전화번호9
                '', //mblPhonNo10 전화번호10
                '', //smsYn SMS전송여부
                '', //smsSaleYn 판매SMS전송여부
                '', //smsAllotAddYn 할부추가여부
                '', //smsAllotCnclYn 할부취소SMS전송여부
                '', //smsSuplYn 부가상품여부
                '', //modUserId 수정사용자ID
                '', //modDtm 수정일시
            ],
            //행추가,수정시 필수 입력 컬럼
            requiredCols: [
                'sktChnlCd', //UKEY채널코드
            ],
        }
    },
    async mounted() {
        //체크바
        // this.$refs.smsTrmsStrdMgmtGrid1.gridView.setCheckBar({
        //     visible: true,
        // })
        this.gridObj = this.$refs.smsTrmsStrdMgmtGrid1
        this.gridHeaderObj = this.$refs.smsTrmsStrdMgmtGridHeader1
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.setCopyOptions({
            singleMode: true,
            includeHeaderText: false,
        })

        /*
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         */
        //this.$refs.smsTrmsStrdMgmtGrid1.setGridState(true, true, true, false)
        //    this.gridObj.setGridState()
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, false, false, false)
        //체크바
        this.$refs.smsTrmsStrdMgmtGrid1.gridView.setCheckBar({
            visible: true,
        })
        this.$refs.smsTrmsStrdMgmtGrid1.gridView.checkBar.fieldName = 'chk'
        //편집가능
        this.$refs.smsTrmsStrdMgmtGrid1.gridView.setEditOptions({
            editable: true,
            updatable: true,
            editWhenFocused: true,
            enterToTab: true,
        })
        //컬럼 고정
        // this.gridObj.gridView.setFixedOptions({
        //     colCount: 3,
        // })
        //dropdown combo
        //await this.dropDownSetting()

        // this.gridObj.gridView.onCellButtonClicked = function (
        //     grid,
        //     index,
        //     column
        // ) {
        //     //운영사 공통 팝업 : 외부거래처 팝업(공통)
        //     if (column.fieldName == 'operCmpNm') {
        //         //TODO operDealcoCd 값을 팝업에서 받아와야 함
        //         alert(
        //             '운영사 팝업:' +
        //                 index.itemIndex +
        //                 ', fieldName=' +
        //                 column.fieldName
        //         )
        //     }
        //     //관리조직 공통 팝업 : 내부조직팝업(전체)(공통)
        //     if (column.fieldName == 'orgNm') {
        //         //TODO orgCd , ukeyOrgClCd , ukeySubCd 값을 팝업에서 받아와야 함
        //         alert(
        //             '관리조직 팝업:' +
        //                 index.itemIndex +
        //                 ', fieldName=' +
        //                 column.fieldName
        //         )
        //     }
        // }
    },
    computed: {
        ...serviceComputed,
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        saveAction1: {
            get() {
                return this.saveAction
            },
        },
        searchParam: {
            get() {
                return this.searchParams
            },
        },
    },
    methods: {
        ...serviceMethods,
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 9999, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging',
                value: { ...this.paging, pageSize: pageSize },
            })
            if (this.paging1.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/cmu/cmuSmsTrmsStrdMgmtsExcelList',
                this.searchParam
            )
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            this.gridHeaderObj.setPageCount(this.paging)
        },
        gridAddRowBtn: function () {
            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            let focuscell = this.gridObj.gridView.getCurrent()
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
        },
        gridDelRowBtn: function () {
            // not used
            console.log('del current row')
            this.gridData.gridRows = this.gridHeaderObj.selDelRow()
        },
        gridchkDelRowBtn: function () {
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        // async dropDownSetting() {
        //     //등록구분
        //     await this.dropDownCmmonCodes_({
        //         key: 'AGENCY_RGST_CL',
        //         columnName: 'agencyRgstClCd',
        //         option: '선택',
        //     })
        //     await this.changeDropDown('agencyRgstClCd')
        //     //대리점구분
        //     await this.dropDownCmmonCodes_({
        //         key: 'AGENCY_PTN',
        //         columnName: 'agencyClCd',
        //         option: '선택',
        //     })
        //     await this.changeDropDown('agencyClCd')
        //     //대리점유형
        //     await this.dropDownCmmonCodes_({
        //         key: 'AGENCY_TYP',
        //         columnName: 'agencyTypCd',
        //         option: '선택',
        //     })
        //     await this.changeDropDown('agencyTypCd')
        //     //자동배정
        //     await this.dropDownCmmonCodes_({
        //         key: 'USE_YN',
        //         columnName: 'disAsgnYn',
        //         option: '선택',
        //     })
        //     await this.changeDropDown('disAsgnYn')
        //     //유선이용여부
        //     await this.dropDownCmmonCodes_({
        //         key: 'USE_YN',
        //         columnName: 'wlClYn',
        //         option: '선택',
        //     })
        //     await this.changeDropDown('wlClYn')
        // },
        // async changeDropDown(key) {
        //     let col1 = this.gridObj.gridView.columnByName(key)
        //     col1.values = this.commDropDown[key].values
        //     col1.labels = this.commDropDown[key].labels
        //     this.gridObj.gridView.setColumn(col1)
        // },
        errorCellFocus(chkCell, message) {
            this.showTcComSnackbar(message)

            //cell focus : { index: -1, fieldName: '' }
            this.gridObj.validationChkGrid(chkCell)
        },
        validationCheck() {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            var chk = { index: -1, fieldName: '' }
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.gridObj.dataProvider.getJsonRow(
                        index[i],
                        true
                    )

                    if (
                        row.__rowState == 'created' ||
                        row.__rowState == 'updated'
                    ) {
                        //필수 입력 체크
                        if (this.requiredCols.length) {
                            // created(추가) / updated(수정) 인경우 필수입력항목 체크
                            for (var j = 0; j < this.requiredCols.length; j++) {
                                //필수입력항목이 누락된경우
                                if (!row[this.requiredCols[j]]) {
                                    chk.index = index[i]
                                    chk.fieldName = this.requiredCols[j]

                                    this.errorCellFocus(
                                        chk,
                                        this.gridObj.gridView.columnByField(
                                            chk.fieldName
                                        ).header.text + ' 필수 입력 입니다.'
                                    )
                                    return false
                                }
                            }
                        }

                        // //적용일자 체크
                        // let fromDt = moment(row.aplyStaDt, 'YYYYMMDD').toDate()
                        // let toDt = moment(row.aplyEndDt, 'YYYYMMDD').toDate()
                        // if (fromDt > toDt) {
                        //     chk.index = index[i]
                        //     chk.fieldName = 'aplyStaDt'

                        //     this.errorCellFocus(
                        //         chk,
                        //         '적용시작일자가 적용마지막일자 보다 큽니다.'
                        //     )
                        //     return false
                        // }
                    }

                    //코드 중복 체크
                    if (row.__rowState == 'created') {
                        let all1 = this.gridObj.dataProvider.getJsonRows(0, -1)
                        let dup1 = all1.filter(
                            (e) => e.sktChnlCd === row.sktChnlCd //'sktChnlCd', //UKEY채널코드
                        )
                        //UKEY채널코드 체크
                        if (dup1.length > 1) {
                            chk.index = index[i]
                            chk.fieldName = 'sktChnlCd'

                            this.errorCellFocus(chk, '중복 채널코드 입니다.')
                            return false
                        }
                    }
                }
            } else {
                if (!this.gridData.delRows.length) {
                    this.showTcComSnackbar(msgTxt.MSG_01002)

                    return false
                }
            }

            return true
        },
        async saveData() {
            let saveRows = []

            for (let i = 0; i < this.gridData.delRows.length; i++) {
                let e = this.gridData.delRows[i]
                saveRows.push({
                    ...e,
                    rowState: e.__rowState,
                })
            }

            var arr = []
            var cIndex = this.gridObj.dataProvider.getStateRows('created')
            var uIndex = this.gridObj.dataProvider.getStateRows('updated')
            arr.push(...cIndex)
            arr.push(...uIndex)
            for (var i = 0; i < arr.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(arr[i], true)
                saveRows.push({
                    ...row,
                    rowState: row.__rowState,
                })
            }

            //checkBar 를 사용할 경우 체크된 건만 저장처리
            // if (
            //     this.$refs.smsTrmsStrdMgmtGrid1.gridView.checkBar.fieldName ==
            //     'chk'
            // ) {
            //     saveRows = saveRows.filter((x) => {
            //         return x['chk'] != null && x['chk'] == 'true'
            //     })
            // }
            console.log('crud api call', saveRows)

            let res1
            await this.saveSmsTrmsStrdMgmt_({ saveRows })
                .then((res) => {
                    res1 = res
                })
                .finally(() => {
                    if (res1 == 1) {
                        //this.showTcComSnackbar('정상처리 되었습니다.')
                        //저장후 다시 조회 하는 경우
                        this.$emit('Refresh', '')

                        //저장후 그리드 초기화 하는 경우
                        //this.gridObj.gridInit()
                    }
                })
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        resultList1(val, oldVal) {
            //console.log('resultList1 watched: ', val, oldVal, this.pageSize)
            //this.$refs.smsTrmsStrdMgmtGrid1.setRows(this.resultList)
            this.gridObj.gridView.commit()
            this.gridObj.setRows(_.clone(val))

            //this.gridData = this.GridSetData() //초기화
        },
        // eslint-disable-next-line no-unused-vars
        paging1(val, oldVal) {
            //console.log('paging1 watched: ', val, oldVal)
            this.SetPaging()
        },
        // eslint-disable-next-line no-unused-vars
        async saveAction1(val, oldVal) {
            if (val == true) {
                //console.log('saveAction1: ', val, oldVal)
                this.gridObj.gridView.commit()

                console.log(
                    '변경 데이타',
                    this.gridObj.modifyGrid(), // 추가/수정 건 체크
                    this.gridData.delRows
                )
                //bug ?? saveRows 로는 추가/수정 건을 알수 없음.
                //console.log('변경 데이타 saverows ', this.gridData.saveRows)

                if (this.validationCheck()) {
                    await this.saveData()
                } else {
                    console.log('validation false')
                }

                //에러든 정상종료든 완료되면 flag처리
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: true,
                })

                //temp 임시로 두개의 saveAction 이 있다고 간주
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: true,
                })
            }
        },
    },
}
</script>
