<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">주소등록 팝업</p>
                <!--// Popup_tit -->

                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- SubTit  -->
                    <div class="stitHead">
                        <h4 class="subTit">주소 등록</h4>
                    </div>
                    <!-- //SubTit -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div6">
                                <TCComInput
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName="우편번호"
                                    placeholder="ex) 04212"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div6">
                                <TCComInput
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName="도로명주소"
                                    placeholder="ex) 서울특별시"
                                />
                            </div>
                            <div class="formitem div6">
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) 마포구"
                                />
                            </div>
                            <div class="formitem div6">
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) ~읍, ~면"
                                />
                            </div>
                            <div class="formitem div6">
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) ~리"
                                />
                            </div>
                            <div class="formitem div6">
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) 마포대로 144"
                                />
                            </div>
                            <div class="formitem div6">
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) 공덕동"
                                />
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) 마포T타운"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div6">
                                <TCComInput
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName="지번"
                                    placeholder="ex) 서울특별시"
                                />
                            </div>
                            <div class="formitem div6">
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) 마포구"
                                />
                            </div>
                            <div class="formitem div6">
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) ~읍, ~면"
                                />
                            </div>
                            <div class="formitem div6">
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) ~리"
                                />
                            </div>
                            <div class="formitem div6">
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) 252-5"
                                />
                            </div>
                            <div class="formitem div6">
                                <TCComTextField
                                    v-model="inputType"
                                    class="inBlock w100"
                                    labelName=""
                                    placeholder="ex) 마포T타운"
                                />
                            </div>
                        </div>
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            @click="save"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="close"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="close"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                    <TCComAlert
                        v-model="showAlertBool"
                        :headerText="headerText"
                        :bodyText="alertBodyText"
                    ></TCComAlert>
                </div>
                <!-- //Popup_Cont -->
            </div></template
        >
    </TCComDialog>
</template>

<script>
export default {
    name: 'BasBcoAddressRgstPopup',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: '',
            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            inputType: '',
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function () {},
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {},
    mounted() {},
    methods: {
        validation() {},
        save() {
            if (!confirm('저장하시겠습니까?')) {
                return
            } else {
                console.log('TODO API 호출!!')
                this.close()
            }
        },
        close() {
            this.activeOpen = false
        },
    },
}
</script>

<style scoped></style>
