import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'menuNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuNm2',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'menuNm3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuNm4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuUrl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'excelMenuId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'excelSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'url',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'menuNm1',
            fieldName: 'menuNm1',
            header: {
                text: '메뉴1',
            },
            editable: false,
        },
        {
            name: 'menuNm2',
            fieldName: 'menuNm2',
            header: {
                text: '메뉴2',
            },
            editable: false,
        },
        {
            name: 'menuNm3',
            fieldName: 'menuNm3',
            header: {
                text: '메뉴3',
            },
            editable: false,
        },
        {
            name: 'menuNm4',
            fieldName: 'menuNm4',
            header: {
                text: '메뉴4',
            },
            editable: false,
        },
        {
            name: 'menuUrl',
            fieldName: 'menuUrl',
            header: {
                text: 'URL',
            },
            editable: false,
        },
        {
            name: 'excelMenuId',
            fieldName: 'excelMenuId',
            header: {
                text: 'MENU_NO',
            },
            editable: false,
        },
        {
            name: 'excelSeq',
            fieldName: 'excelSeq',
            header: {
                text: 'EXCEL_SEQ',
            },
            editable: false,
        },
        {
            name: 'url',
            fieldName: 'url',
            header: {
                text: 'EXCEL_URL',
            },
            editable: false,
        },
    ],
}
