<!-----------------------------------------------
 * 업무그룹명: Real Grid 컴포넌트
 * 서브업무명: Real Grid 공통함수
 * 설명: Real Grid 컴포넌트및 공통함수 
 * 작성자: 홍길동
 * 작성일: 2005.01.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div :id="id" ref="grid" class="grid" :style="cStyle"></div>
</template>
<script>
import { GridView, LocalDataProvider } from 'realgrid'
import store from '@/store'
import { CommonMsg } from '@/utils'
import _ from 'lodash'
// let dataProvider = LocalDataProvider
// let gridView = GridView
export default {
    name: 'RealGrid',
    props: {
        id: {
            type: String,
            required: true,
        },
        fields: {
            type: Array,
            required: true,
        },
        columns: {
            type: Array,
            required: true,
        },
        editable: {
            type: Boolean,
            default: false,
        },
        movable: {
            type: Boolean,
            default: false,
        },
        columnMovable: {
            type: Boolean,
            default: false,
        },
        summaryMode: {
            type: String,
            default: 'aggregate',
        },
        styles: {
            type: Object,
        },
        options: {
            type: Object,
        },
        isGridReSize: {
            type: Boolean,
            default: false,
        },
        editWhenFocused: {
            type: Boolean,
            default: false,
        },
        isRowColor: {
            type: Boolean,
            default: true,
        },
        attachClickFunc: {
            type: Function,
        },
        isCellCopyOption: {
            type: Boolean,
            default: false,
        },
        isRowCellCopyOption: {
            type: Boolean,
            default: true,
        },
    },
    data() {
        return {
            dataProvider: null,
            gridView: null,
            dStyle: '',
        }
    },
    watch: {
        //데이터의 객체 안의 값 변경을 감지하는 경우
        // gridSetData: {
        //     deep: true,
        //     handler(obj) {
        //         self.gridSetData = obj
        //         console.log('watch ', self.gridSetData)
        //     },
        // },
    },
    mounted() {
        this.dataProvider = new LocalDataProvider(false)
        this.gridView = new GridView(this.id)

        this.gridView.setDataSource(this.dataProvider)
        this.dataProvider.setFields(this.fields)
        this.gridView.setColumns(this.columns)

        //행 편집여부
        this.gridView.setEditOptions({
            editable: this.editable, // 그리드 데이터 수정여부
            movable: this.movable, // 그리드 행 이동가능여부
        })

        this.gridView.displayOptions.columnMovable = this.columnMovable //컬럼이동여부

        this.gridView.summaryMode = this.summaryMode //컬럼의 합계를 계산하는 방식

        this.dataProvider.setOptions({ softDeleting: false }) //삭제방법(false : 행바로삭제 / true : 상태변경(행삭제))

        this.gridView.setRowGroup({
            expandedAdornments: 'footer', // 행그룹이 펼쳐진 상태일때 footer 표시
            collapsedAdornment: 'footer', // 행그룹이 접힌 상태일때 footer 표시
        })
        this.gridView.rowGroup.mergeMode = true //그룹핑된 컬럼의 머지표현여부
        this.gridView.rowGroup.mergeExpanderVisibility = 'none' //행 그룹핑시 Expander를 표시하지 않는다.
        this.gridView.sortingOptions.enabled = true //컬럼헤더에 정렬가능여부
        this.gridView.setDisplayOptions({ focusVisible: true }) //포커스 표시 여부
        //this.gridView.displayOptions.syncGridHeight = 'always' // 조회된 Data가 모두 보이도록 그리드의 높이를 변경
        this.gridView.displayOptions.selectionStyle = 'rows' // 셀 선택 영역에 대한 스타일
        this.gridView.setRowIndicator({ visible: false }) //인디케이터 사용여부
        this.gridView.displayOptions.useFocusClass = true //focus 색상적용

        //그리드 복사관련 설정
        this.gridView.setCopyOptions({
            enabled: true, //복사 가능여부
            includeHeaderText: true, //컬럼명 포함 복사여부
        })

        //단, 아래설정사용시 더블클릭이벤트는 사용할 수 없음
        this.gridView.editOptions.editWhenFocused = this.editWhenFocused //셀 포커스시 편집기 표시여부

        //표시한 컬럼들의 전체 너비가 그리드 너비보다 작을 경우 비율에 맞춰 남는 크기를 분배
        this.gridView.displayOptions.fitStyle = 'even'
        //그리드 콤보박스 변경시 상단으로 스크롤 되는 문제가 있어서 아래 옵션 설정
        this.gridView.editorOptions.viewGridInside = true
        // const f = function () {
        //     return {
        //         rowHoverType: 'none',
        //     }
        // }
        // 각각의 컬럼의 타입을 확인 후 속성을 적용
        this.gridView.getColumnNames().forEach((e) => {
            let columnByName = this.gridView.columnByName(e)
            // dropDownWhenClick 셀 클릭시 목록표시
            if (columnByName.editor?.type === 'dropdown') {
                columnByName.editor.dropDownWhenClick = true
            }

            //renderer 값이 renderer_attachbtn이면 attachbtn 버튼 추가
            if (columnByName?.renderer === 'renderer_attachbtn') {
                let attachClicked = this.attachClickFunc
                this.gridView.registerCustomRenderer('renderer_attachbtn', {
                    initContent(parent) {
                        let span = (this._span = document.createElement('span'))
                        span.className = 'custom_render_span'
                        parent.appendChild(span)
                        parent.appendChild(
                            (this._button1 = document.createElement('span'))
                        )
                    },
                    canClick() {
                        return true
                    },
                    clearContent(parent) {
                        parent.innerHTML = ''
                    },
                    render(grid, model, width, height, info) {
                        info = info || {}
                        let span = this._span
                        // text설정.
                        span.textContent = model.value
                        this._value = model.value
                        this._button1.className = ''
                        //value 값이 있는경우에만 클립이미지 표시
                        if (model.value) {
                            this._button1.className =
                                'custom_search custom-hover' +
                                (info.focused ? ' custom-focused' : '')
                        }
                    },
                    click(event) {
                        //attachClicked
                        let ret = ''
                        if (event.target === this._button1) {
                            if (typeof attachClicked === 'function') {
                                //value 값이 undefined 이면 빈값으로 넘겨준다
                                ret = attachClicked(
                                    this._value === undefined ? '' : this._value
                                )
                            }
                        }

                        return {
                            cellType: 'data',
                            target: event.target,
                            value: this._value,
                            ret: ret,
                        }
                        // if (event.target === this._button1) {
                        //     alert('조회버튼: ' + this._value)
                        // }
                    },
                })
            }
        })

        //체크바 선택시 행 선택 표시
        this.gridView.onItemChecked = (grid, itemIndex) => {
            if (this.isRowColor === true)
                grid.setCurrent({ itemIndex: itemIndex })
        }

        //빈 그리드에 메세지 표시
        this.gridView.setDisplayOptions({
            showEmptyMessage: true,
            emptyMessage: '조회된 데이터가 없습니다.',
        })

        // this.gridView.displayOptions.rowBlockCallback = f
        // https://docs.realgrid.com/refs/local-data-provider#onrowupdated 추가시 참고
        this.dataProvider.onRowUpdated = (provider, row) => {
            this.$emit('onRowUpdated', provider, row)
        }

        //https://docs.realgrid.com/refs/grid-view#onpagechanged 추가시 참고
        this.gridView.onPageChanged = (grid, page) => {
            this.$emit('onPageChanged', grid, page)
        }
        // this.dStyle = this.setStyle()

        // 그리드 셀 복사 옵션
        if (this.isCellCopyOption) {
            this.gridView.setCopyOptions({
                singleMode: true,
                includeHeaderText: false,
            })
        }

        // 그리드 행,셀 복사 옵션
        if (this.isRowCellCopyOption) {
            this.gridView.setCopyOptions({
                singleMode: true,
                includeHeaderText: false,
            })
            this.gridView.onKeyDown = (grid, event) => {
                if (event.shiftKey && event.code === 'KeyC') {
                    // const sel = this.gridView.getSelection()
                    // this.gridView.copyToClipboard(sel, true)

                    const sel = grid.getSelection()
                    const txt = grid.copyToClipboard(sel, false)
                    const container = this.gridView.getContainer()
                    const area = document.createElement('textarea')
                    const css = area.style
                    css.position = 'absolute'
                    css.top =
                        window.pageYOffset +
                        container.getBoundingClientRect().top +
                        'px'
                    css.width = '10px'
                    css.height = '10px'
                    css.zIndex = '-1'
                    container.appendChild(area)
                    area.value = txt
                    area.select()
                    document.execCommand('copy')
                    setTimeout(function () {
                        container.removeChild(area)
                    }, 100)
                }
                this.$emit('onGridKeyDown', grid, event)
            }
        }
    },

    computed: {
        cStyle() {
            let style = {}
            let strHeight = ''
            let height = 0
            if (window.innerHeight && window.outerHeight) {
                let windowHeight = window.outerHeight - window.innerHeight
                if (windowHeight < 0) windowHeight = windowHeight * -1
                if (this.styles) {
                    height = parseInt(this.styles.height.replace('px', ''))
                    strHeight = height + windowHeight
                } else {
                    strHeight = 250 + windowHeight
                }
                //innerHeight 높이에서 60%정도 크기로 그리드 크기 변경(60은 페이징컴포넌트크기)
                if (this.isGridReSize === true) {
                    strHeight = window.innerHeight * 0.6 - 60
                }
            }

            //최소 Grid 크기 지정(150이하이면 150으로 고정)
            if (strHeight < 100) strHeight = 100
            style.height = strHeight + 'px'
            return style
        },
    },
    // 그리드 관련 메쏘드 프록시 처리하여 사용. [https://docs.realgrid.com/refs/local-data-provider]
    methods: {
        // setStyle() {
        //     let style = {}
        //     let strHeight = ''
        //     let height = 0
        //     if (window.innerHeight && window.outerHeight) {
        //         let windowHeight = window.outerHeight - window.innerHeight
        //         if (this.styles) {
        //             height = parseInt(this.styles.height.replace('px', ''))
        //             strHeight = height + windowHeight
        //         } else {
        //             strHeight = 250 + windowHeight
        //         }
        //     }

        //     //innerHeight 높이에서 60%정도 크기로 그리드 크기 변경(60은 페이징컴포넌트크기)
        //     if (this.isGridReSize === true) {
        //         strHeight = window.innerHeight * 0.6 - 60
        //     }
        //     //최소 Grid 크기 지정(100이하이면 100으로 고정)
        //     if (strHeight < 100) strHeight = 100
        //     style.height = strHeight + 'px'
        //     return style
        // },
        /*************************************************
         * Grid State Setting
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         *************************************************/
        setGridState(
            indicatorBl = false,
            stateBarBl = false,
            checkBarBl = false,
            footerBl = false,
            opt = { headCheck: true }
        ) {
            //인디게이터
            if (indicatorBl) {
                this.addIndicator()
            }
            this.gridView.setStateBar({ visible: stateBarBl })
            //체크바
            this.gridView.setCheckBar({ visible: checkBarBl })

            //체크바 사용할경우 체크바헤드연동설정
            if (checkBarBl == true && opt.headCheck == true) {
                //체크바셋팅
                this.$nextTick(function () {
                    this.gridView.checkBar.syncHeadCheck = true
                })
            }

            this.gridView.setFooters({ visible: footerBl })
        },

        /*************************************************
         * ADD Indicator
         *************************************************/
        addIndicator() {
            //NO 컬럼 존재여부 확인후 생성
            let isNo = this.gridView.getColumn(0)
            if (isNo.fieldName != 'NO') {
                const columnIndex = {
                    name: 'NO',
                    fieldName: 'NO',
                    header: {
                        text: 'No',
                    },
                    width: 60,
                    editor: {
                        textReadOnly: false,
                    },
                }
                this.dataProvider.addField({
                    fieldName: 'NO',
                    dataType: 'data',
                })
                this.gridView.addColumn(columnIndex, 0)
            }
        },
        /*************************************************
         * Grid Indicator Setting
         * pageInfo  : 페이지정보
         *************************************************/
        setGridIndicator(pageInfo, indicatorOpt = {}) {
            //indicatorOpt 값이 없으면 내림차순으로 순번표시
            if (_.isEmpty(indicatorOpt)) indicatorOpt.sort = 'ASC'

            this.gridView.onDataLoadComplated = () => {
                if (this.dataProvider.getRowCount() > 0) {
                    //NO 컬럼 존재여부 확인후 생성
                    let isNo = this.gridView.getColumn(0)
                    if (isNo.fieldName == 'NO') {
                        //순번 구분이없는경우 페이징 있는것으로 처리
                        if (pageInfo.type == undefined)
                            pageInfo.type == 'paging'

                        //페이징이 없는 그리드인경우
                        if (pageInfo.type == 'noPaging') {
                            let state = [] //순번변경 되는 index 배열변수
                            let totalDataCnt = pageInfo.totalDataCnt //총건수
                            if (indicatorOpt.sort === 'DESC') {
                                for (
                                    let i = 0;
                                    i < pageInfo.totalDataCnt;
                                    i++
                                ) {
                                    state.push(i)
                                    //그리드 순번 변경
                                    this.dataProvider.setValue(
                                        i,
                                        'NO',
                                        totalDataCnt--
                                    )
                                }
                            } else {
                                for (let i = 0; i < totalDataCnt; i++) {
                                    state.push(i)
                                    //그리드 순번 변경
                                    this.dataProvider.setValue(i, 'NO', i + 1)
                                }
                            }
                            //순번변경 되는 index를 배열로 받아서 상태변경처리
                            this.dataProvider.setRowStates(state, 'none')
                            this.gridView.commit()
                        } else {
                            let state = [] //순번변경 되는 index 배열변수
                            let totalDataCnt = pageInfo.totalDataCnt //총건수
                            let pageSize = pageInfo.pageSize //페이지 건수
                            let pageNum = pageInfo.pageNum //페이지 번호

                            if (indicatorOpt.sort === 'DESC') {
                                // 순번계산
                                let no = totalDataCnt - (pageNum - 1) * pageSize

                                //순번이 페이지건수보다 작으면
                                if (no < pageSize) {
                                    pageSize = no
                                }
                                for (let i = 0; i < pageSize; i++) {
                                    state.push(i)
                                    //그리드 순번 변경
                                    this.dataProvider.setValue(i, 'NO', no--)
                                }
                            } else {
                                // 순번계산
                                let no =
                                    pageNum == 1
                                        ? 1
                                        : (pageNum - 1) * pageSize + 1

                                //총건수가 페이지건수보다 작으면
                                if (totalDataCnt < pageSize * pageNum) {
                                    pageSize =
                                        totalDataCnt - pageSize * (pageNum - 1)
                                }
                                for (let i = 0; i < pageSize; i++) {
                                    state.push(i)
                                    //그리드 순번 변경
                                    this.dataProvider.setValue(i, 'NO', no++)
                                }
                            }
                            //순번변경 되는 index를 배열로 받아서 상태변경처리
                            this.dataProvider.setRowStates(state, 'none')
                            this.gridView.commit()
                        }
                    }
                }
            }
        },
        setRows: function (data) {
            this.dataProvider.setRows(data)
        },
        getRows: function () {
            return this.dataProvider.getRows()
        },
        setEvent: function (gridObj) {
            gridObj.dataProvider.onRowDeleting = (provider, row) => {
                this.$emit('onRowDeleting', provider, row)
            }
        },

        /*************************************************
         * Grid 변경된 행만 Json으로 가져오기
         * gridData : Grid Data
         *************************************************/
        setModifyData: function (gridData) {
            var arr = []
            var cIndex = this.dataProvider.getStateRows('created')
            var dIndex = this.dataProvider.getStateRows('deleted')
            var uIndex = this.dataProvider.getStateRows('updated')
            arr.push(...cIndex)
            arr.push(...dIndex)
            arr.push(...uIndex)
            var jsonData = []
            for (var i = 0; i < arr.length; i++) {
                var row = this.dataProvider.getJsonRow(arr[i], true)
                jsonData.push(row)
            }

            //삭제된값이 있으면 배열을 합치기
            if (gridData.saveRows) {
                gridData.saveRows = jsonData.concat(gridData.saveRows)
            } else {
                gridData.saveRows = jsonData
            }
            return gridData
        },
        /*************************************************
         * Grid 변경된 행 index 가져오기
         *************************************************/
        modifyGrid() {
            var arr = []
            var cIndex = this.dataProvider.getStateRows('created')
            var uIndex = this.dataProvider.getStateRows('updated')
            var dIndex = this.dataProvider.getStateRows('deleted')
            arr.push(...dIndex)
            arr.push(...cIndex)
            arr.push(...uIndex)
            return arr
        },

        validationChkGrid(chk) {
            //필수입력항목 확인
            if (chk.index >= 0) {
                //focus
                this.gridView.setCurrent({
                    itemIndex: chk.index,
                    fieldName: chk.fieldName,
                })

                //focus간 셀 편집
                this.gridView.showEditor()
                return false
            } else {
                return true
            }
        },

        validationGrid(gridData, requiredCol) {
            let res = {}
            let index = this.modifyGrid() //변경한 행 index 가져오기
            var jsonData = []
            var chk = {}
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.dataProvider.getJsonRow(index[i], true)

                    if (requiredCol.length) {
                        // created(추가) / updated(수정) 인경우 필수입력항목 체크
                        if (
                            row.__rowState == 'created' ||
                            row.__rowState == 'updated'
                        ) {
                            for (var j = 0; j < requiredCol.length; j++) {
                                //필수입력항목이 누락된경우
                                if (!row[requiredCol[j]]) {
                                    chk.index = index[i]
                                    chk.fieldName = requiredCol[j]
                                    break
                                }
                            }
                            //필수입력항목이 누락된경우
                            if (chk.index) {
                                break
                            }
                        }
                    }

                    jsonData.push(row)
                }

                if (this.validationChkGrid(chk)) {
                    if (gridData.saveRows) {
                        gridData.saveRows = jsonData.concat(gridData.saveRows)
                    } else {
                        gridData.saveRows = jsonData
                    }
                } else {
                    //필수입력항목 누락경우
                    res.error = 'require'
                }
            } else {
                //변경된 index가 없는경우
                res.error = 'index'
            }
            return res
        },

        /*************************************************
         * Paging 생성
         * gridData : Grid Data
         *************************************************/
        setGirdPaging: function (gridData) {
            this.gridView.setPaging(true, gridData.gridRows)
            gridData.currentPage = this.getPage(gridData.currentPage) // 현재페이지
            gridData.totalPage = this.gridView.getPageCount() // 총 페이지

            //페이지 셋팅시 첫번째 페이지로 이동
            this.gridView.setPage(0)
            gridData.pageRows = this.gridView.getItemCount()
            return gridData
        },

        /*************************************************
         * 현재 Page 가져오는 함수
         *  - 최초 페이지순서가 0으로 시작하기때문에 +1을 해줌
         *  - 현재페이지가 1보다 크거나 같으면 1페이지 셋팅
         * curPage : 현재페이지
         *************************************************/
        getPage: function (curPage) {
            let getPage = 1
            if (curPage >= 1) {
                getPage = 1
            } else {
                getPage = this.gridView.getPage() + 1
            }
            return getPage
        },
        /*************************************************
         * Page 이동 함수
         * page      : 이동할 페이지
         *************************************************/
        setPage: function (page) {
            this.gridView.setPage(page)
        },
        /*************************************************
         * 현재 Page Row 갯수 가져오는 함수
         *************************************************/
        getItemCount: function () {
            return this.gridView.getItemCount()
        },
        /*************************************************
         * 지정된 컬럼기준으로 그룹핑
         * col      : 그룹핑 기준되는 컬럼 (Array)
         * opt      : Grid ROW Group설정 (Object)
         *************************************************/
        groupBy: function (col, opt = {}) {
            this.gridView.setRowGroup({
                opt,
            })
            this.gridView.groupBy(col)
        },

        /*************************************************
         * Grid 초기화
         *************************************************/
        gridInit: function () {
            this.dataProvider.clearRows()
        },
        /*************************************************
         * 체크된 행들에 index 반환
         * bl       : 기본값 false, true일경우 보이지않는행은 제외(페이징, collapse)
         *************************************************/
        getCheckedRows: function (bl) {
            this.gridView.getCheckedRows(bl)
        },
        /*************************************************
         * 동일값 존재여부 체크
         * sColID : 비교를 원하는 컬럼ID
         * sColNM : 메세지에 표시할 컬럼명
         *************************************************/
        chkDuplicateValue(sColID, sColNM) {
            for (let i = 0; i < this.dataProvider.getRowCount(); i++) {
                for (let j = 0; j < this.dataProvider.getRowCount(); j++) {
                    if (
                        i != j &&
                        this.dataProvider.getValue(i, sColID) ==
                            this.dataProvider.getValue(j, sColID)
                    ) {
                        if (sColNM.length > 0) {
                            store.dispatch('showTcComAlert', {
                                message: CommonMsg.getMessage(
                                    'MSG_00173',
                                    sColNM +
                                        ';' +
                                        this.dataProvider.getValue(j, sColID)
                                ),
                                options: {
                                    header: '동일값 체크',
                                    size: '500',
                                    confirmLabel: 'OK',
                                },
                            })
                            return false
                        }
                    }
                }
            }
            return true
        },

        /*************************************************
         * 동일값 존재여부 체크
         * sColID : 비교를 원하는 컬럼ID
         * sColID2 : 비교를 원하는 컬럼ID
         * sColNM : 메세지에 표시할 컬럼명
         *************************************************/
        chkDuplicateValue2(sColID, sColID2, sColNM) {
            for (let i = 0; i < this.dataProvider.getRowCount(); i++) {
                for (let j = 0; j < this.dataProvider.getRowCount(); j++) {
                    if (
                        i != j &&
                        this.dataProvider.getValue(i, sColID) ==
                            this.dataProvider.getValue(j, sColID) &&
                        this.dataProvider.getValue(i, sColID2) ==
                            this.dataProvider.getValue(j, sColID2)
                    ) {
                        if (sColNM.length > 0) {
                            store.dispatch('showTcComAlert', {
                                message: CommonMsg.getMessage(
                                    'MSG_00173',
                                    sColNM +
                                        ';' +
                                        this.dataProvider.getValue(j, sColID)
                                ),
                                options: {
                                    header: '동일값 체크',
                                    size: '500',
                                    confirmLabel: 'OK',
                                },
                            })

                            return false
                        }
                    }
                }
            }
            return true
        },
        /*************************************************
         * 동일값 존재여부 체크
         * sColID : 비교를 원하는 컬럼ID
         * sColID2 : 비교를 원하는 컬럼ID
         * sColID3 : 비교를 원하는 컬럼ID
         * sColNM : 메세지에 표시할 컬럼명
         *************************************************/
        chkDuplicateValue3(sColID, sColID2, sColID3, sColNM) {
            for (let i = 0; i < this.dataProvider.getRowCount(); i++) {
                for (let j = 0; j < this.dataProvider.getRowCount(); j++) {
                    if (
                        i != j &&
                        this.dataProvider.getValue(i, sColID) ==
                            this.dataProvider.getValue(j, sColID) &&
                        this.dataProvider.getValue(i, sColID2) ==
                            this.dataProvider.getValue(j, sColID2) &&
                        this.dataProvider.getValue(i, sColID3) ==
                            this.dataProvider.getValue(j, sColID3)
                    ) {
                        if (sColNM.length > 0) {
                            store.dispatch('showTcComAlert', {
                                message: CommonMsg.getMessage(
                                    'MSG_00173',
                                    sColNM +
                                        ';' +
                                        this.dataProvider.getValue(j, sColID)
                                ),
                                options: {
                                    header: '동일값 체크',
                                    size: '500',
                                    confirmLabel: 'OK',
                                },
                            })

                            return false
                        }
                    }
                }
            }
            return true
        },
    },
}
</script>
<style>
.grid {
    width: 100%;
    height: 250px;
}
</style>
