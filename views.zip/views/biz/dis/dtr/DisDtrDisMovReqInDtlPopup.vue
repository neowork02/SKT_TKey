<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 재고이동요청 상세
 * 설명: 재고이동요청 상세를 조회한다.
 * 작성자: P179229
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">재고이동요청</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="stitHead">
                        <h4 class="subTit">재고이동요청</h4>
                    </div>
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.reqDealcoNm"
                                    :readonly="true"
                                    :eRequired="true"
                                    labelName="입고처"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInputSearchText
                                    labelName="모델"
                                    @enterKey="onProdsEnterKey"
                                    @appendIconClick="onProdsIconClick"
                                    :objAuth="objAuth"
                                    :eRequired="true"
                                    v-model="reqParam.prodNm"
                                    :codeVal="reqParam.prodCd"
                                    :disabledAfter="true"
                                >
                                </TCComInputSearchText>
                                <BasBcoProdsPopup
                                    v-if="basBcoProdsShow === true"
                                    :dialogShow.sync="basBcoProdsShow"
                                    :parentParam="searchProdForm"
                                    :rows="resultProdsRows"
                                    @confirm="onProdsReturnData"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComComboBox
                                    :itemList="prodColorData"
                                    :objAuth="objAuth"
                                    labelName="색상"
                                    :disabled="!isEdit"
                                    :eRequired="true"
                                    v-if="isEdit"
                                    v-model="reqParam.colorCd"
                                ></TCComComboBox>
                                <TCComInput
                                    v-model="reqParam.colorNm"
                                    labelName="색상"
                                    v-if="!isEdit"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.mfactNm"
                                    labelName="제조사"
                                    :readonly="true"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.petNm"
                                    labelName="펫네임"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    codeId="ZDIS_C_00662"
                                    labelName="개봉상태"
                                    :eRequired="true"
                                    :readonly="!isEdit"
                                    :objAuth="objAuth"
                                    v-model="reqParam.reqClCd"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    :itemList="chkData"
                                    labelName="대표모델"
                                    :eRequired="true"
                                    :readonly="!isEdit"
                                    :objAuth="objAuth"
                                    v-model="reqParam.repProdYn"
                                />
                            </div>
                            <div class="formitem div1">
                                <TCComRadioBox
                                    :itemList="chkData"
                                    labelName="색상무관"
                                    :eRequired="true"
                                    :readonly="!isEdit"
                                    :objAuth="objAuth"
                                    v-model="reqParam.colorUnrelYn"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.qckSvcCoNm"
                                    labelName="퀵서비스 업체명"
                                    :eRequired="true"
                                    :readonly="!isEdit"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.qckSvcTelNo"
                                    :readonly="!isEdit"
                                    :eRequired="true"
                                    labelName="퀵서비스 연락처"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.reqQty"
                                    :readonly="!isEdit"
                                    :eRequired="true"
                                    inputRuleType="N"
                                    labelName="요청수량"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqUserNm"
                                    :readonly="true"
                                    labelName="요청자"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                        </div>
                        <div class="searchform" v-if="!isEdit">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.reqStNm"
                                    labelName="진행상태"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                        <div class="searchform" v-if="!isEdit">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="reqParam.reqFixDesc"
                                    :readonly="true"
                                    labelName="요청확정비고"
                                    :rows="5"
                                />
                            </div>
                        </div>
                    </div>
                    <!-- // Search_div -->

                    <!-- Close BTN-->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            v-show="isEdit"
                            @click="saveBtn"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            v-show="
                                !isEdit &&
                                reqParam.reqStCd != '05' &&
                                reqParam.movQty < 1
                            "
                            @click="deleteBtn"
                        >
                            취소
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty01"
                            @click="closeBtn"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="closeBtn()"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import disDtrDisMovReqInApi from '@/api/biz/dis/dtr/disDtrMovReqIn'
import disDcoProdInsInApi from '@/api/biz/dis/dco/disDcoProdInsIn'
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'DisDtrDisMovReqInDtlPopup',
    mixins: [CommonMixin],
    components: { BasBcoProdsPopup },
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            objAuth: {},
            showProdSrchPop: false,
            srchProdPopParam: {},
            isEdit: false,
            prodColorData: [],
            reqUserNm: '',
            reqParam: {
                reqMgmtNo: '', //요청관리번호
                dealcoCd: '', //요청거래처
                prodCd: '', //상품코드
                mfactNm: '', //제조사명
                petNm: '', //펫네임
                colorCd: '', //색상코드
                colorNm: '', //색상명
                reqDealcoNm: '', //입고처명
                reqStCd: '', //요청상태
                reqClCd: '', //요청구분코드
                reqQty: '', //요청수량
                reqDesc: '', //요청사항비고
                reqFixDesc: '', //요청확정비고
                repProdYn: 'N', //대표모델여부
                colorUnrelYn: 'N', //색상무관여부
                qckSvcCoNm: '', //퀵서비스 업체명
                qckSvcTelNo: '', //퀵서비스 전화번호
            },
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            searchProdForm: {
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
                repProdYn: '', //대표모델여부
            },
            chkData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
            //====================//상품팝업관련==================
        }
    },
    created() {},
    mounted() {
        this.reqParam.reqMgmtNo = this.dtlData.reqMgmtNo
        this.reqParam.dealcoCd = this.dtlData.dealcoCd
        this.reqParam.reqDealcoNm = this.dtlData.reqDealcoNm
        //요청정보 조회
        if (_.isEmpty(this.dtlData.reqMgmtNo)) {
            this.isEdit = true
            this.reqParam.reqClCd = '01'
            //퀵서비스 조회
            this.getDisQckSvcInfo()
        } else {
            this.getDisMovReqInDtl()
        }
        //요청자
        this.reqUserNm = this.dtlData.userNm + '(' + this.dtlData.userId + ')'
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        closeBtn: function () {
            this.activeOpen = false
        },
        //색상조회
        searchProdColor() {
            disDcoProdInsInApi.getDisDcoProdColor(this.reqParam).then((res) => {
                res.disDcoProdColorVo.forEach((data, i) => {
                    const colorData = {}
                    colorData.commCdVal = _.get(data, 'colorCd')
                    colorData.commCdValNm = _.get(data, 'colorNm')
                    this.prodColorData.push(colorData)
                    if (i == 0) {
                        this.reqParam.colorCd = _.get(data, 'colorCd')
                    }
                })
            })
        },
        //요청상세조회
        getDisMovReqInDtl() {
            disDtrDisMovReqInApi
                .getDisDtrDisMovReqInDtl(this.reqParam)
                .then((res) => {
                    //Get Row Data
                    this.reqParam = Object.assign(
                        {},
                        res.disDtrDisMovReqInDtlVo
                    )
                })
        },
        //저장
        saveBtn() {
            if (!this.isValidChk()) {
                return false
            }
            this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    //신규등록
                    disDtrDisMovReqInApi
                        .addDisDtrDisMovReqInDtl(this.reqParam)
                        .then((res) => {
                            // 정상등록
                            if (!_.isEmpty(res)) {
                                this.reqParam.reqMgmtNo = res
                                this.getDisMovReqInDtl()
                                this.$parent.searchBtn()
                                this.isEdit = false
                            }
                        })
                }
            })
        },
        //취소
        deleteBtn() {
            this.showTcComConfirm('요청을 취소하시겠습니까?').then(
                (confirm) => {
                    if (confirm) {
                        //요청취소
                        disDtrDisMovReqInApi
                            .deleteDisDtrDisMovReqInDtl(this.reqParam)
                            .then((res) => {
                                if (res === 1) {
                                    this.closeBtn()
                                    this.$parent.searchBtn()
                                }
                            })
                    }
                }
            )
        },
        isValidChk() {
            if (_.isEmpty(this.reqParam.dealcoCd)) {
                this.showTcComAlert('요청 거래처 코드가 없습니다.')
                return false
            }
            if (_.isEmpty(this.reqParam.prodCd)) {
                this.showTcComAlert('모델정보(을)를 선택해 주십시오.')
                return false
            }
            if (_.isEmpty(this.reqParam.colorCd)) {
                this.showTcComAlert('색상정보(을)를 선택해 주십시오.')
                return false
            }
            if (_.isEmpty(this.reqParam.reqQty)) {
                this.showTcComAlert('요청수량(을)를 입력해 주십시오.')
                return false
            }
            if (this.reqParam.reqQty > 10) {
                this.showTcComAlert('10개이상 요청이 불가능합니다.')
                return false
            }
            if (_.isEmpty(this.reqParam.colorUnrelYn)) {
                this.showTcComAlert('색상무관여부(을)를 선택해 주십시오.')
                return false
            }
            if (_.isEmpty(this.reqParam.qckSvcCoNm)) {
                this.showTcComAlert('퀵서비스 업체명(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.reqParam.qckSvcTelNo)) {
                this.showTcComAlert('퀵서비스 연락처(을)를 입력해 주십시오.')
                return false
            }
            return true
        },
        //퀵서비스조회
        getDisQckSvcInfo() {
            let searchParam = {}
            searchParam.reqDealcoCd = this.reqParam.dealcoCd
            disDtrDisMovReqInApi.getDisQckSvc(searchParam).then((res) => {
                if (!_.isEmpty(res.disDtrDisQckSvcVo)) {
                    this.reqParam.qckSvcCoNm = res.disDtrDisQckSvcVo.qckSvcCoNm
                    this.reqParam.qckSvcTelNo =
                        res.disDtrDisQckSvcVo.qckSvcTelNo
                }
            })
        },
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                if (res.length === 1) {
                    this.reqParam.prodCd = _.get(res[0], 'prodCd')
                    this.reqParam.prodNm = _.get(res[0], 'prodNm')
                    this.reqParam.mfactNm = _.get(res[0], 'mfactNm')
                    this.reqParam.petNm = _.get(res[0], 'petNm')
                    //색상조회
                    this.searchProdColor()
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            this.searchProdForm['prodCd'] = this.reqParam['prodCd']
            this.searchProdForm['prodNm'] = this.reqParam['prodNm']
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            this.basBcoProdsShow = true
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            this.searchProdForm['prodCd'] = this.reqParam['prodCd']
            this.searchProdForm['prodNm'] = this.reqParam['prodNm']
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            if (_.isEmpty(this.reqParam.prodNm)) {
                // 팝업오픈
                this.basBcoProdsShow = true
            } else {
                // 상품팝업 정보 조회
                this.getProdsList()
            }
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log(JSON.stringify(retrunData))
            this.reqParam.prodCd = _.get(retrunData, 'prodCd')
            this.reqParam.prodNm = _.get(retrunData, 'prodNm')
            this.reqParam.mfactNm = _.get(retrunData, 'mfactNm')
            this.reqParam.petNm = _.get(retrunData, 'petNm')
            //색상조회
            this.searchProdColor()
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
