<template>
    <div>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="pageBtn"
                    :objAuth="this.objAuth"
                >
                    거래저조직이관엑셀업로드
                </TCComButton>
                <!-- <TCComButton
                        color="btn2"
                        eClass="btn_ty01"
                        @click="searchBtn"
                        :objAuth="this.objAuth"
                    >
                        조직조회
                    </TCComButton> -->
                <!-- <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveOrgBtn"
                    :objAuth="this.objAuth"
                >
                    조직저장
                </TCComButton> -->
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <!-- <TCComButton
                        color="btn2"
                        eClass="btn_ty01"
                        @click="searchStoreBtn"
                        :objAuth="this.objAuth"
                    >
                        매장조회
                    </TCComButton> -->
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="this.objAuth"
                >
                    매장저장
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComDatePicker
                        v-model="aplyStaDt"
                        :calType="calType5"
                        labelName="조회년월"
                        @change="dateChange"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div3">
                    <!-- <TCComComboBox
                        labelName="대리점유형"
                        v-model="formSearchParams.agencyTypCd"
                        :objAuth="objAuth"
                        @change="selectChange"
                        codeId="AGENCY_TYP"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox> -->
                    <!-- @input="inputEvent()" -->
                    <TCComInput
                        v-model="searchVal"
                        labelName="조직"
                        :size="150"
                        :maxlength="10"
                        :objAuth="this.objAuth"
                        @enterKey="keyEnterKey"
                    ></TCComInput>
                </div>
                <div class="formitem div3">
                    <!-- <TCComInputSearchText
                        labelName="대리점"
                        :appendIconClass="''"
                        @appendIconClick="searchCommon('agency')"
                        :objAuth="this.objAuth"
                        v-model="agencyNm"
                        :codeVal="formSearchParams.agencyCd"
                        :disabledAfter="true"
                        @input="onAgencyInput"
                    /> -->
                </div>
            </div>
        </div>
        <BasBcoAgencysPopup
            v-if="showBcoAgencys"
            :parentParam="searchParam"
            :rows="resultAgencyRows"
            :dialogShow.sync="showBcoAgencys"
            @confirm="onAgencyReturnData"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/ogm/orgMgmt/helpers'
import moment from 'moment'
//import CommonUtil from '@/utils/CommonUtil.js'
import { msgTxt } from '@/const/msg.Properties.js'
//====================대리점팝업====================
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
//====================//대리점팝업====================
import CommonMixin from '@/mixins'
import _ from 'lodash'
export default {
    mixins: [CommonMixin],
    components: {
        //TCComComboBox,
        BasBcoAgencysPopup,
    },
    async created() {
        await this.initControls()
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            calType5: 'M', //'D'
            aplyStaDt: '',
            agencyNm: '',
            formSearchParams: {
                aplyStaDt: '', //조회년월
                agencyTypCd: '', //대리점유형
                agencyCd: '', //대리점코드
            },
            //====================대리점팝업관련====================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            searchParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
            searchVal: '',
        }
    },
    async mounted() {
        //화면초기 로딩시 바로 검색
        this.searchBtn()
    },
    computed: {
        ...serviceComputed,
        commCdIds1: {
            get() {
                return this.commCdIds
            },
            //set(value) {},
        },
        saveDone1: {
            get() {
                return this.saveDoneA && this.saveDoneB
            },
            //set(value) {},
        },
        saveOrgDone1: {
            get() {
                return this.saveOrgDone
            },
            //set(value) {},
        },
        search1: {
            get() {
                return this.searchOrg
            },
            async set(value) {
                await this.defaultAssign_({
                    key: 'searchOrg',
                    value: value,
                })
            },
        },
        currentOrg1: {
            get() {
                return this.currentOrg
            },
            //set(value) {},
        },
        beforeSaveOrgAction1: {
            get() {
                return this.beforeSaveOrgAction
            },
            //set(value) {},
        },
    },
    methods: {
        ...serviceMethods,
        async initControls() {
            //await this.commonCodes_({ option: '전체' })
            //this.defaultAssign_({ key: 'plantCd', value: this.user.plantCd }); //watch call searchList()
        },
        async initData() {
            let today = moment(new Date()).format('YYYY-MM')
            this.aplyStaDt = today
            this.agencyNm = '' //대리점명
            this.formSearchParams.agencyCd = '' //대리점코드
            this.formSearchParams.aplyStaDt =
                // moment(new Date()).format('YYYYMM') + '01' //조회년월
                moment(new Date()).format('YYYYMM')
            this.formSearchParams.agencyTypCd = '' //대리점유형
            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.initDealcoStore()
        },
        async dateChange() {
            console.log(
                'date change',
                this.aplyStaDt,
                moment(this.aplyStaDt, 'YYYY-MM').isValid()
            )
            if (
                this.aplyStaDt.length > 6 &&
                moment(this.aplyStaDt, 'YYYY-MM').isValid()
            ) {
                console.log('date change search org')
                this.searchBtn()
            }
        },
        async keyEnterKey() {
            console.log('search enter', this.searchVal)
            //if (this.search1 != this.searchVal) this.search1 = this.searchVal
            if (
                (!_.isEmpty(this.currentOrg) &&
                    this.currentOrg.name.indexOf(this.searchVal) == -1) ||
                _.isEmpty(this.currentOrg)
            ) {
                this.search1 = this.searchVal
            }
        },
        async initDealcoStore() {
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
            await this.defaultAssign_({
                key: 'resultListAll',
                value: [],
            })
            await this.defaultAssign_({
                key: 'saveDataAdd',
                value: [],
            })
            await this.defaultAssign_({
                key: 'saveDataDel',
                value: [],
            })
            await this.defaultAssign_({
                key: 'currentOrg',
                value: '',
            })
        },
        selectChange(val) {
            console.log('🚀 ~ file: selectChange ~ line 58 ~ selectChange', val)
        },
        searchCommon(flag) {
            // TODO 공통팝업 호출
            if (flag === 'mfact') {
                alert('제조사')
            } else if (flag === 'org') {
                alert('조직')
            } else if (flag === 'prod') {
                alert('모델')
            } else if (flag === 'outPlc') {
                alert('보유처')
            } else if (flag === 'agency') {
                this.resultAgencyRows = []
                this.showBcoAgencys = true
            }
        },
        async initBtn() {
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 122 ~ data ',
                this.$data
            )
            const curOrg = _.clone(this.currentOrg1)
            await this.initData()
            await this.defaultAssign_({
                key: 'currentOrg',
                value: curOrg,
            })

            //await this.searchBtn()
            //CommonUtil.clearPage(this.$router)
        },
        async pageBtn() {
            console.log('🚀 ~ file: SearchContainer.vue ~ line 197 ~ pageBtn ~')
            this.$router.push({
                name: '/bas/prm/BasPrmOrgTrnsfMgmt',
                // params: { search: this.reqParam },
            })
        },
        async searchBtn() {
            // let fromDt = new Date(this.aplyStaDt[0])
            // let toDt = new Date(this.aplyStaDt[1])
            // if (fromDt > toDt) {
            //     this.showAlert_({
            //         title: '세금계산서일자 오류',
            //         message: '시작일자가 마지막일자 보다 큽니다.',
            //     })
            //     return
            // }
            // if (
            //     moment(fromDt).format('YYYY-MM') !=
            //     moment(toDt).format('YYYY-MM')
            // ) {
            //     this.showAlert_({
            //         title: '세금계산서일자 오류',
            //         message: '같은 월 검색만 됩니다.',
            //     })
            //     return
            // }
            await this.initDealcoStore()

            await this.defaultAssign_({ key: 'paging', value: this.initPaging })
            this.formSearchParams.aplyStaDt =
                // this.aplyStaDt.replace(/-/g, '') + '01'
                this.aplyStaDt.replace(/-/g, '')
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 197 ~ searchBtn ~ this.formSearchParams',
                this.formSearchParams
            )
            await this.defaultAssign_({
                key: 'searchParams',
                value: _.clone(this.formSearchParams),
            })
            await this.searchData()
        },
        async searchData() {
            await this.getBasOgmOrgMgmtList_()
        },
        async saveBtn() {
            if (this.currentOrg1.id == this.currentOrg1.orgCd) {
                this.showTcComAlert(
                    '저장되지 않은 신규 조직에 매장을 할당 할수 없습니다. 조직 저장을 먼저 수행하세요.'
                )
                return
            }
            this.formSearchParams.aplyStaDt =
                // this.aplyStaDt.replace(/-/g, '') + '01'
                this.aplyStaDt.replace(/-/g, '')
            console.log('🚀 ~ file: saveBtn~ line 122 ~ data ', this.$data)
            await this.defaultAssign_({
                key: 'searchParams',
                value: this.formSearchParams,
            })

            await this.defaultAssign_({
                key: 'saveAction',
                value: true,
            })
        },
        async saveOrgBtn() {
            this.formSearchParams.aplyStaDt =
                // this.aplyStaDt.replace(/-/g, '') + '01'
                this.aplyStaDt.replace(/-/g, '')
            console.log('🚀 ~ file: saveOrgBtn~ line 371 ~ data ', this.$data)
            await this.defaultAssign_({
                key: 'searchParams',
                value: this.formSearchParams,
            })

            await this.defaultAssign_({
                key: 'saveOrgAction',
                value: true,
            })
        },
        async searchStoreBtn() {
            if (this.currentOrg1.orgCd && this.currentOrg1.orgCd !== '') {
                this.formSearchParams.aplyStaDt =
                    // this.aplyStaDt.replace(/-/g, '') + '01'
                    this.aplyStaDt.replace(/-/g, '')
                await this.defaultAssign_({
                    key: 'searchParams',
                    value: this.formSearchParams,
                })

                //매장조회 Refresh
                await this.defaultAssign_({
                    key: 'refeshDealco',
                    value: true,
                })
            } else {
                this.showTcComSnackbar('매장조회할 조직을 선택하세요.')
            }
        },
        async inputEvent() {
            // if (
            //     this.formSearchParams.orgNm == '' &&
            //     this.formSearchParams.sktChnlCd == '' &&
            //     this.formSearchParams.mblPhonNo == ''
            // ) {
            //     await this.setUnFiltering_()
            // } else {
            //     let pass = {
            //         orgNm: this.formSearchParams.orgNm,
            //         sktChnlCd: this.formSearchParams.sktChnlCd,
            //         mblPhonNo: this.formSearchParams.mblPhonNo,
            //     }
            //     await this.setFiltering_(pass)
            // }
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.searchParam.agencyCd = ''
            this.formSearchParams.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.formSearchParams.agencyCd = retrunData.agencyCd
            this.agencyNm = retrunData.agencyNm
        },
        async saveData() {
            let saveRows = []

            for (let i = 0; i < this.saveDataAdd.length; i++) {
                let e = this.saveDataAdd[i]
                saveRows.push({
                    ...e,
                    rowState: e.__rowState,
                    opDt: this.formSearchParams.aplyStaDt,
                })
            }
            for (let i = 0; i < this.saveDataDel.length; i++) {
                let e = this.saveDataDel[i]
                saveRows.push({
                    ...e,
                    rowState: 'deleted',
                    opDt: this.formSearchParams.aplyStaDt,
                })
            }
            if (!saveRows.length) {
                this.showTcComSnackbar(msgTxt.MSG_01002)
                return false
            }
            console.log('saveDealCoMgmt crud api call', saveRows)

            let res1 = await this.saveDealCoMgmt_({ saveRows })
            if (res1 === 1) {
                this.showTcComAlert(' 일배치로 익일 반영됩니다')

                await this.defaultAssign_({
                    key: 'saveDataAdd',
                    value: [],
                })
                await this.defaultAssign_({
                    key: 'saveDataDel',
                    value: [],
                })
                //매장조회 Refresh
                await this.defaultAssign_({
                    key: 'refeshDealco',
                    value: true,
                })
            }
        },
    },
    watch: {
        async saveDone1(val, oldVal) {
            if (val == true) {
                console.log('saveDone1: ', val, oldVal)
                console.log('saveDone1 add: ', this.saveDataAdd)
                console.log('saveDone1 del: ', this.saveDataDel)
                //saveAction 작업들이 모두 완료 되면 default 상태로 변환
                await this.saveData()

                await this.defaultAssign_({
                    key: 'saveAction',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: false,
                })
            }
        },
        async saveOrgDone1(val, oldVal) {
            if (val == true) {
                console.log('saveOrgDone1: ', val, oldVal)

                await this.defaultAssign_({
                    key: 'saveOrgAction',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveOrgDone',
                    value: false,
                })
            }
        },
        async beforeSaveOrgAction1(val, oldVal) {
            if (val == true) {
                console.log('beforeSaveOrgAction1: ', val, oldVal)

                await this.defaultAssign_({
                    key: 'beforeSaveOrgAction',
                    value: false,
                })

                await this.saveOrgBtn()
            }
        },
    },
}
</script>
