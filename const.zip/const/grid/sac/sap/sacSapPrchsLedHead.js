import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'apSeq', // 매입순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDtm', // 매입일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wrtDt', // 전기일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'evdDt', //증빙일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trClCd', // 거래구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trClNm', //거래구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsClCd', // 매입구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsClNm', // 매입구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inClCd', // 입고구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inClNm', // 입고구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payCondCd', // 결제조건코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payCondNm', // 결제조건코드명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsShopCd', // 매입매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoCd', // 입고처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoNm', // 입고처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 정산매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 모델ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 모델명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsQty', // 매입수량
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prchsAmt', // 매입금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'taxClCd', // 과세구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxClNm', // 과세구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc', // 공급가액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ccId', // 코스트센터ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ccNm', // 코스트센터명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBilId', // 세금계산서발행ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBilSeq', // 세금계산서발행순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxCfmId', // 세금계산서승인ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxAprvDtm', // 세금계산서승인일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBilStNm', // 세금계산서상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTaxCfmId', // 원세금계산서승인ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTaxAprvDtm', // 원세금계산서승인일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'unsetAmt', // 미결금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'erpTrmsId', // ERP전송ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsDtm', // ERP전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpFixDtm', // ERP확정일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsId1', // ERP전송ID1 // ERP 추정 역분개?
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsDtm1', // ERP전송일시1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpFixDtm1', // ERP확정일시 << ????
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsId2', // ERP전송ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsDtm2', // ERP전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpFixDtm2', // ERP확정일시 << ???
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsId3', // ERP전송ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsDtm3', // ERP전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpFixDtm3', // ERP확정일시 << ???
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refId', // 참고ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refSeq', // 참고순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgRefId', // 원참고ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgRefSeq', // 원참고순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hitPgmId', // 발생PGM ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 매출조정절차비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm', //입력일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm', // 입력처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 수정일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm', // 수정처리자명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prchsDtm',
            fieldName: 'prchsDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입일시',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            // textFormat:
            //     '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'wrtDt',
            fieldName: 'wrtDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전기일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'evdDt',
            fieldName: 'evdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '증빙일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'trClCd',
            fieldName: 'trClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드',
        },
        {
            name: 'trClNm',
            fieldName: 'trClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드명',
        },
        {
            name: 'prchsClCd',
            fieldName: 'prchsClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드',
        },
        {
            name: 'prchsClNm',
            fieldName: 'prchsClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드명',
        },
        {
            name: 'inClCd',
            fieldName: 'inClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드',
        },
        {
            name: 'inClNm',
            fieldName: 'inClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드명',
        },
        {
            name: 'payCondCd',
            fieldName: 'payCondCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드',
        },
        {
            name: 'payCondNm',
            fieldName: 'payCondNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드명',
        },
        {
            name: 'prchsShopCd',
            fieldName: 'prchsShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고처매장코드',
        },
        {
            name: 'prchsDealcoCd',
            fieldName: 'prchsDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고처',
        },
        {
            name: 'prchsDealcoNm',
            fieldName: 'prchsDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고처명',
        },
        {
            name: 'accShopCd',
            fieldName: 'accShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산매장코드',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처명',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델ID',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델명',
        },
        {
            name: 'prchsQty',
            fieldName: 'prchsQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입수량',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'prchsAmt',
            fieldName: 'prchsAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입금액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'taxClCd',
            fieldName: 'taxClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '과세구분코드',
        },
        {
            name: 'taxClNm',
            fieldName: 'taxClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '과세구분명',
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공급가액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '부가세액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'ccId',
            fieldName: 'ccId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코스트센터ID',
        },
        {
            name: 'taxBilId',
            fieldName: 'taxBilId',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '발행ID',
        },
        {
            name: 'taxBilSeq',
            fieldName: 'taxBilSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발행순번',
        },
        {
            name: 'taxCfmId',
            fieldName: 'taxCfmId',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '승인ID',
        },
        {
            name: 'taxAprvDtm',
            fieldName: 'taxAprvDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '승인일시',
        },
        {
            name: 'taxBilStNm',
            fieldName: 'taxBilStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상태코드명',
        },
        {
            name: 'orgTaxCfmId',
            fieldName: 'orgTaxCfmId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '승인ID',
        },
        {
            name: 'orgTaxAprvDtm',
            fieldName: 'orgTaxAprvDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '승인일시',
        },
        {
            name: 'unsetAmt',
            fieldName: 'unsetAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '미결금액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'erpTrmsId',
            fieldName: 'erpTrmsId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송ID',
        },
        {
            name: 'erpTrmsDtm',
            fieldName: 'erpTrmsDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
        },
        {
            name: 'erpFixDtm',
            fieldName: 'erpFixDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '확정일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'erpTrmsId1',
            fieldName: 'erpTrmsId1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송ID',
        },
        {
            name: 'erpTrmsDtm1',
            fieldName: 'erpTrmsDtm1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
        },
        {
            name: 'erpFixDtm1',
            fieldName: 'erpFixDtm1',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '확정일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'erpTrmsId2',
            fieldName: 'erpTrmsId2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송ID',
        },
        {
            name: 'erpTrmsDtm2',
            fieldName: 'erpTrmsDtm2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
        },
        {
            name: 'erpFixDtm2',
            fieldName: 'erpFixDtm2',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '확정일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'erpTrmsId3',
            fieldName: 'erpTrmsId3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송ID',
        },
        {
            name: 'erpTrmsDtm3',
            fieldName: 'erpTrmsDtm3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
        },
        {
            name: 'erpFixDtm3',
            fieldName: 'erpFixDtm3',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '확정일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'refId',
            fieldName: 'refId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '참고ID',
        },
        {
            name: 'refSeq',
            fieldName: 'refSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '참고순번',
        },
        {
            name: 'orgRefId',
            fieldName: 'orgRefId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '원참고ID',
        },
        {
            name: 'orgRefSeq',
            fieldName: 'orgRefSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '원참고순번',
        },
        {
            name: 'hitPgmId',
            fieldName: 'hitPgmId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발생PGM ID',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '최초처리일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '최초처리자',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '변경처리일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '변경처리자',
        },
    ],
    layout: [
        'NO',
        'prchsDtm',
        'wrtDt',
        'evdDt',
        {
            name: '거래구분',
            direction: 'horizontal',
            items: ['trClCd', 'trClNm'],
        },
        {
            name: '매입구분',
            direction: 'horizontal',
            items: ['prchsClCd', 'prchsClNm'],
        },
        {
            name: '입고구분',
            direction: 'horizontal',
            items: ['inClCd', 'inClNm'],
        },
        {
            name: '결제조건',
            direction: 'horizontal',
            items: ['payCondCd', 'payCondNm'],
        },
        'prchsShopCd',
        'prchsDealcoCd',
        'prchsDealcoNm',
        'accShopCd',
        'accDealcoCd',
        'accDealcoNm',
        'prodCd',
        'prodNm',
        'prchsQty',
        'prchsAmt',
        'taxClCd',
        'taxClNm',
        'splyPrc',
        'vatAmt',
        //'ccId',
        {
            name: '세금계산서',
            direction: 'horizontal',
            items: [
                'taxBilId',
                'taxBilSeq',
                'taxCfmId',
                'taxAprvDtm',
                'taxBilStNm',
            ],
        },
        {
            name: '원세금계산서',
            direction: 'horizontal',
            items: ['orgTaxCfmId', 'orgTaxAprvDtm'],
        },
        'unsetAmt',
        {
            name: 'ERP',
            direction: 'horizontal',
            items: ['erpTrmsId', 'erpTrmsDtm', 'erpFixDtm'],
        },
        // {
        //     name: 'ERP 추정 역분개',
        //     direction: 'horizontal',
        //     items: ['erpTrmsId1', 'erpTrmsDtm1', 'erpFixDtm1'],
        // },
        {
            name: 'ERP 확정',
            direction: 'horizontal',
            items: ['erpTrmsId2', 'erpTrmsDtm2', 'erpFixDtm2'],
        },
        // {
        //     name: 'ERP 확정 역분개',
        //     direction: 'horizontal',
        //     items: ['erpTrmsId3', 'erpTrmsDtm3', 'erpFixDtm3'],
        // },
        'refId',
        'refSeq',
        'orgRefId',
        'orgRefSeq',
        'hitPgmId',
        'rmks',
        {
            name: '처리자 정보',
            direction: 'horizontal',
            items: ['insDtm', 'insUserNm', 'modDtm', 'modUserNm'],
        },
    ],
}
