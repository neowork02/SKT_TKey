<template>
    <div class="content">
        <TCComAlert
            v-model="showAlertBool"
            :headerText="headerText"
            :bodyText="alertBodyText"
        ></TCComAlert>
        <!-- Tit -->
        <h1>운영모델단가표상세 {{ info }}</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <!-- 230109 정책변경 주석
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="onPrcTbltnPolChgClick"
                    :objAuth="this.objAuth"
                    :disabled="modBtn"
                    >정책변경</TCComButton
                >
                -->
                <BasPdmPrcTbltnPolChgPopup
                    v-if="showPrcTbltnPolChg"
                    :parentParam="searchPrcTbltnPolChgParam"
                    :rows="resultPrcTbltnPolChgRows"
                    :dialogShow.sync="showPrcTbltnPolChg"
                    @confirm="onReturnData"
                />
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave"
                    :objAuth="this.objAuth"
                    :disabled="saveBtn"
                >
                    저장
                    <!--                    {{ btnName }}-->
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onDelete"
                    :objAuth="this.objAuth"
                    :disabled="deleteBtn"
                >
                    삭제
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onListClick"
                    :objAuth="this.objAuth"
                >
                    목록
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5">
                    <TCComDatePicker
                        calType="M"
                        v-model="div_search.cal_polYm"
                        labelName="적용년월"
                        :eRequired="true"
                        :disabled="true"
                    />
                </div>
                <div class="formitem div2">
                    <TCComDatePicker
                        v-if="v_aplyDtm.visible"
                        labelName="적용기간"
                        v-model="div_search.aplyDtm"
                        elementClass="iteminput"
                        calType="DHMP"
                        :hourVal.sync="div_search.aplyStaHour"
                        :minuVal.sync="div_search.aplyStaMin"
                        :endHourVal.sync="div_search.aplyEndHour"
                        :endMinuVal.sync="div_search.aplyEndMin"
                        :disabled="!v_aplyDtm.enable"
                        @change="onAplyDtmChange"
                    />
                </div>
                <br />
                <!-- <div class="formitem div5">
            <TCComCheckBox
                labelName="적용상품"
                v-model="div_search.aplyProd"
                :objAuth="this.objAuth"
                :itemList="ds_aplyProd"
            ></TCComCheckBox>
            <TCComComboBox
                labelName="적용상품"
                v-model="div_search.aplyProd"
                :itemList="this.ds_aplyProd"
                :addBlankItem="true"
                blankItemText="전체"
                blankItemValue=""
                :objAuth="this.objAuth"
            ></TCComComboBox>
        </div> -->
                <!-- <div class="formitem div5_2">
            <TCComInput
                labelName="판매가추가"
                :objAuth="this.objAuth"
                v-model="div_search.addPrice"
            />
        </div> -->
                <div class="formitem div5">
                    <TCComComboBox
                        codeId="ZBAS_C_00500"
                        labelName="단말기구분"
                        v-model="div_search.cmb_OpenCl"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="this.objAuth"
                        @change="onChange"
                    ></TCComComboBox>
                </div>
                <div class="formitem div5">
                    <TCComInput
                        labelName="모델ID/명"
                        :objAuth="this.objAuth"
                        v-model="findProd"
                        @enterKey="prodFocus"
                    />
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="운영모델단가표목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isPageCnt="true"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :isGridReSize="true"
                :editable="true"
                :updatable="true"
            />
        </div>
        <div class="textareaLayer_wrap">
            <TCComTextArea
                v-model="div_search.edt_Rmks"
                labelName="비고"
                class="boxtype"
            ></TCComTextArea>
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
import attachedFileApi from '@/api/common/attachedFile'
import _ from 'lodash'
// import BasUsmSaleChrgrMgmtPopup from '@/views/biz/bas/usm/BasUsmSaleChrgrMgmtPopup'
import { UPRC_DTL_HEADER } from '@/const/grid/bas/pdm/basPdmMdlUprcTbltnDtlHeader'
// import API from '@/api/biz/bas/pdm/basPdmOperMdlUprcTbltnMgmt'
import API from '@/api/biz/bas/pdm/basPdmUprcTbltnMgmt'
import CommonMixin from '@/mixins'
/**************************************************************************************************************
 * 공통 LIB import 영역
 **************************************************************************************************************/
// import { NewLib } from '@/views/newlib'
//====================정책변경팝업====================
import BasPdmPrcTbltnPolChgPopup from '@/views/biz/bas/pdm/BasPdmPrcTbltnPolChgPopup'
import { convertDate } from '@/utils/accUtil'

//====================정책변경팝업====================

export default {
    name: 'BasPdmOperMdlUprcTbltnMgmt',
    mixins: [CommonMixin],
    props: {},
    components: { BasPdmPrcTbltnPolChgPopup },
    data() {
        return {
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: UPRC_DTL_HEADER,
            type: 0,
            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            objAuth: {},
            rowCnt: 15, // 표시할 행의 갯수
            layout: [
                'prodClNm',
                'eqpClNm',
                'dealCoNm',
                'prodNm',
                'prodCd',
                // 'prodChrticCd1',
                // 'prodChrticCd2',
                {
                    name: 'group',
                    direction: 'horizontal',
                    items: [
                        'exitCashPrchsPrc',
                        'exitCrdtPrchsPrc',
                        'exitStrdSalePrc',
                        'exitUnitSalePrc',
                    ],
                    header: {
                        text: '기존정보',
                    },
                },
                {
                    name: 'group',
                    direction: 'horizontal',
                    items: [
                        'fixCashPrchsPrc',
                        'fixCrdtPrchsPrc',
                        'fixStrdSalePrc',
                        'fixUnitSalePrc',
                    ],
                    header: {
                        text: '확정정보',
                    },
                },
                'realPrchsPrc',
                'orgRealPrchsPrc',
            ],
            // 화면에 표기하는 용도
            div_search: {
                cal_polYm: '', // 정책연월
                aplyDtm: ['9999-01-01', '9999-01-31'], // index => 0 : 시작 , 1 : 끝
                aplyStaHour: '',
                aplyStaMin: '',
                aplyEndHour: '',
                aplyEndMin: '',
                cmb_OpenCl: '', //단말기구분
                aplyProd: '', // 적용상품
                addPrice: 0, // 판매가 추가
                edt_Rmks: '', // 비고에 적은 내용
                changeInfo: '',
            },
            ds_pol_uplst_aply_mdl: [], // 단가표에 등록되어있던 적용상품 리스트
            ds_cp_prod_mgmt: [], // 변경대상에서 넘어온 상품 리스트
            ds_condition: {}, // 이전 페이지에서 넘겨온 데이터를 받아둠
            v_aplyDtm: { visible: true, enable: true },

            // * 용도를 모르는 변수들 - 확인하고 삭제 예정
            showBool: false,

            // 적용상품(체크박스 -> 콤보박스로 변경)에 연동
            ds_aplyProd: [
                {
                    commCdVal: '1',
                    commCdValNm: '단말기',
                },
                {
                    commCdVal: '2',
                    commCdValNm: 'USIM',
                },
                {
                    commCdVal: '3',
                    commCdValNm: '기타재고',
                },
            ],
            // 모델ID/명 검색
            findProd: '',
            //====================정책변경팝업관련====================
            showPrcTbltnPolChg: false,
            searchPrcTbltnPolChgParam: {},
            resultPrcTbltnPolChgRows: [],
            //====================//내부조직팝업(권한)팝업관련==================

            valBeforeEdit: '', // 셀 데이터 음수 입력 방지 시 사용
            // 등록 시 사용
            PRE_APLY_STA_DTM: '', // 적용시작일자 변경 시, 이전 적용시작일자 저장
            PRE_FIX_STRD_SALE_PRC: 0, // 적용상품(체크박스), 판매가추가(인풋박스) 시 사용
            SAVE_FLAG: 'N', // 어느 값이든 수정했는지 여부
            save_uplst_aply_mdl: [], // 최종적으로 저장할 상품 리스트
            // 단말기 구분에 따른 필터링 관련
            filterLabels: [],
            filterValues: [],
            // 버튼 제어
            saveBtn: false,
            deleteBtn: false,
            modBtn: false, // 정책변경 버튼
            // btnName: '저장',
            info: '신규',
        }
    },
    beforeCreated() {
        console.log('------운영모델단가표상세 beforeCreated------')
    },
    mounted() {
        console.log('------운영모델단가표상세 mounted------')

        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState(true)

        this.init()

        // 특정 필드 가리기
        this.gridObj.gridView.columnByName('eqpClCd').visible = false
        this.gridObj.gridView.columnByName('prodClCd').visible = false

        // 적용기간 diabled 처리
        this.v_aplyDtm.enable = false
        //페이지 정보
        // let pageInfo = {}
        // pageInfo.type = 'noPaging' //페이징이 없는경우
        // pageInfo.totalDataCnt = this.gridObj.dataProvider.getRowCount() // 총건수
        // this.gridObj.setGridIndicator(pageInfo) //순번 셋팅

        let paramObj = {}
        paramObj.pageNum = 1
        paramObj.pageSize = 10

        if (CommonUtil.isNotEmptyObject(this.$route.params.search)) {
            this.ds_condition = this.$route.params.search
            this.div_search.cal_polYm = this.ds_condition.polYm
            this.div_search.edt_Rmks = this.ds_condition.rmks
        }
        this.ds_condition.prodGrpClCd = '1'
        console.log('ds_condition : ', this.ds_condition)

        // init 시 필요한 메서드 사용
        // 1. hstFlag 별 버튼, searchLayer 세팅
        this.checkHstFlag(this.ds_condition)

        // 2. admin의 경우, 재고보상금액 보여주기 ==> 확인 후 추가
        // if("TESTSKN01" == gds_session.GetColumn(0,"LOGINID")) {
        //     var idx_inv_cmp_amt = grd_pol_uplst.GetBindCellIndex("BODY", "INVE_CMP_AMT"); // 재고보상금액 컬럼의 idx를 찾아온다.
        //     grd_pol_uplst.SetColProp(idx_inv_cmp_amt,"WIDTH", 75);
        // }

        // 3. 이전 조회조건 중 단가표ID 존재여부에 따라 적용모델 리스트 조회 조건이 다름. => 추후에 따로 빼서 메서드로 만들기로
        // this.oldDivSearch() -> 230106 이전 로직 따로 분리하여 주석처리 setDivSearch로 코드정리
        //  1) 단가표 클릭해서(상품변경관리대상도 포함) 올 경우
        // 2) 해당 정책연월 단가표 신규 작성 시
        this.setDivSearch()

        // 4) polYm => null 여부 확인하고 값 넣어주기 => polYm을 첫 페이지부터 쭉 가져오지만, 혹여나 없을 경우 대비
        this.isPolYmNull()

        // 셀 데이터 수정 시
        this.gridObj.gridView.onCellEdited = (
            grid,
            itemIndex,
            dataRow,
            field
        ) => {
            console.log(field)
            this.SAVE_FLAG = 'Y'
            this.gridObj.gridView.commit()
            const getData = grid.getValue(itemIndex, field)
            console.log('getData', getData)
            if (parseInt(getData) < 0) {
                this.showTcComAlert('음수는 입력 불가입니다')
                this.gridObj.dataProvider.setValue(
                    dataRow,
                    field,
                    this.valBeforeEdit
                )
                return
            }
            const editedRow = this.gridObj.dataProvider.getJsonRow(dataRow)
            console.log('editedRow - ', editedRow)

            if (editedRow.cudFlag == 'I' && editedRow.editFlag == 'Y') {
                let exitValue
                let fieldNew
                if (7 <= field && field <= 10) {
                    fieldNew = field + 4
                    exitValue = grid.getValue(itemIndex, fieldNew)
                } else if (11 <= field && field <= 14) {
                    fieldNew = field - 4
                    exitValue = grid.getValue(itemIndex, field - 4)
                }
                console.log('exitValue', exitValue)
                this.gridObj.dataProvider.setValue(dataRow, field, exitValue)
            }
        }
        // 셀 더블 클릭 시
        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            const clickedRow = this.gridObj.dataProvider.getJsonRow(
                clickData.dataRow
            )
            console.log('clickedRow - ', clickedRow)
            this.valBeforeEdit = clickedRow[clickData.column]
            console.log('this.valBeforeEdit - ', this.valBeforeEdit)
        }

        this.cnt++
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        onActiveTabClick() {},

        // 쓰인 곳 없는 메서드
        onClick() {
            this.showBool = true
        },

        // 적용기간 변경 이벤트
        onAplyDtmChange(val) {
            console.log('onAplyDtmChange::::', val)
            this.div_search.aplyStaDtm = val[0]
            this.div_search.aplyEndDtm = val[1]
        },

        // 운영모델 단가표 상세 조회
        onSearch() {
            this.gridData.totalPage = 0
            this.getPolUpLstAplyMdlList()
        },

        getPolUpLstAplyMdlList() {
            let paramObj = {
                uplstId: this.ds_condition.uplstId,
                polYm: this.ds_condition.polYm,
                polTs: this.ds_condition.polTs,
                aplyEndDtm: this.ds_condition.aplyEndDtm,
                changeInfo: this.ds_condition.changeInfo,
            }
            API.getPolUpLstAplyMdlList(paramObj).then((result) => {
                if (result != undefined) {
                    this.ds_pol_uplst_aply_mdl = result // 단가표에 적용된 모델리스트
                    this.ds_cp_prod_mgmt = this.ds_condition.ds_prod_mgmt // 변경대상 모델리스트
                    console.log(
                        'this.ds_pol_uplst_aply_mdl : ',
                        this.ds_pol_uplst_aply_mdl
                    )
                    console.log('this.ds_cp_prod_mgmt : ', this.ds_cp_prod_mgmt)
                    const totalList = this.f_add_pol_uplst_aply_mdl()
                    console.log('totalList : ', totalList)

                    // DATA 가공
                    //const list = this.getTotalList(totalList)
                    //console.log('list : ', list)

                    // 합친 리스트로 세팅
                    this.gridObj.setRows(totalList)
                    //this.gridObj.setRows(list)
                    this.gridData = this.gridSetData() //초기화
                }
            })
        },

        //===================== 마운트 시 필요한 init methods =======================
        /** hstFlag 값에 따른 searchLayer 제어 */
        checkHstFlag(condition) {
            if (condition.hstFlag == 'Y') {
                console.log('default')
                // 해당 정책연월에 있는 단가표 중 종료일시가 말일인 단가표(차수가 가장 큰 단가표) -> crudFlag = 'Y'
                if (condition.crudFlag == 'Y') {
                    // 저장, 삭제 가능
                    this.saveBtn = false
                    this.deleteBtn = false
                    this.modBtn = false
                } else {
                    // 저장, 삭제 불가
                    this.saveBtn = true
                    this.deleteBtn = true
                    this.modBtn = true
                }
            } else {
                console.log('hstPolUplst')
                this.saveBtn = true
                this.deleteBtn = true
            }
        },
        getDateTime(type, dtm) {
            if (_.isEqual(type, 'date')) {
                return convertDate(dtm.substr(0, 8), 'YYYY-MM-DD')
            } else if (_.isEqual(type, 'hour')) {
                return dtm.substr(8, 2)
            } else if (_.isEqual(type, 'min')) {
                return dtm.substr(10, 2)
            } else if (_.isEqual(type, 'sec')) {
                return dtm.substr(12, 2)
            } else {
                return dtm
            }
        },
        // 230106 이전 로직 따로 분리하여 주석처리 setDivSearch로 코드정리
        oldDivSearch() {
            // 3. 이전 조회조건 중 단가표ID 존재여부에 따라 적용모델 리스트 조회 조건이 다름. => 추후에 따로 빼서 메서드로 만들기로
            //  1) 단가표 클릭해서(상품변경관리대상도 포함) 올 경우
            if (_.isEmpty(this.ds_condition.uplstId) == false) {
                console.log('uplstId exist...')
                let aplyStaDtm = this.ds_condition.aplyStaDtm
                let aplyEndDtm = this.ds_condition.aplyEndDtm
                this.div_search.aplyDtm = [
                    aplyStaDtm.substr(0, 8),
                    aplyEndDtm.substr(0, 8),
                ]

                this.div_search.aplyStaHour = aplyStaDtm.substr(8, 2)
                this.div_search.aplyStaMin = aplyStaDtm.substr(10, 2)
                this.div_search.aplyEndHour = aplyEndDtm.substr(8, 2)
                this.div_search.aplyEndMin = aplyEndDtm.substr(10, 2)

                if (this.ds_condition.prdMdYn == '변경대상') {
                    this.PRE_APLY_STA_DTM =
                        this.div_search.aplyDtm[0].replaceAll('-', '') +
                        this.div_search.aplyStaHour +
                        this.div_search.aplyStaMin
                    console.log(
                        '변경대상에서 온 경우 - PRE_APLY_STA_DTM : ',
                        this.PRE_APLY_STA_DTM
                    )
                }

                console.log('onSearch div_search : ', this.div_search)
                this.onSearch()
            } else {
                // 2) 해당 정책연월 단가표 신규 작성 시
                console.log('uplstId is null...')
                this.ds_condition.aplyStaDtm = this.ds_condition.polYm + '01'
                // 적용시작기간의 연월로 해당 정책연월의 말일을 계산해서 div_search의 적용마감기간란에 입력해준다.
                let lastday = new Date(
                    this.ds_condition.aplyStaDtm.substr(0, 4),
                    this.ds_condition.aplyStaDtm.substr(4, 6),
                    0
                ).getDate()
                console.log(lastday)
                this.ds_condition.aplyEndDtm =
                    this.ds_condition.aplyStaDtm.substr(0, 6) + lastday
                console.log('after ds_condition : ', this.ds_condition)
                this.div_search.aplyStaHour = '00'
                this.div_search.aplyStaMin = '00'
                this.div_search.aplyEndHour = '23'
                this.div_search.aplyEndMin = '59'
                this.div_search.aplyDtm = [
                    this.ds_condition.aplyStaDtm,
                    this.ds_condition.aplyEndDtm,
                ]
                this.onSearch()
            }
        },
        setDivSearch() {
            // 3. 이전 조회조건 중 단가표ID 존재여부에 따라 적용모델 리스트 조회 조건이 다름.
            const aplyStaDtm = this.ds_condition.aplyStaDtm
            const aplyEndDtm = this.ds_condition.aplyEndDtm
            const prdMdYn = this.ds_condition.prdMdYn
            // const uplstId = this.ds_condition.uplstId
            const changeInfo = this.ds_condition.changeInfo

            let aplyStaHour = '00'
            let aplyStaMin = '00'
            let aplyEndHour = '23'
            let aplyEndMin = '59'

            if (_.isEqual(changeInfo, 'CRD')) {
                // 신규작성하는 경우
                // 1) 단가표 클릭해서(상품변경관리대상도 포함) 올 경우
                if (_.isEqual(prdMdYn, '변경발생')) {
                    this.PRE_APLY_STA_DTM = aplyStaDtm
                    console.log('변경발생 -> ', this.PRE_APLY_STA_DTM)
                }
                aplyStaHour = this.getDateTime('hour', aplyStaDtm)
                aplyStaMin = this.getDateTime('min', aplyStaDtm)
                aplyEndHour = this.getDateTime('hour', aplyEndDtm)
                aplyEndMin = this.getDateTime('min', aplyEndDtm)
            } else {
                //this.btnName = '수정'
                this.info = '수정'
                // 수정인 경우
                // 2) 해당 정책연월 단가표 신규 작성 시
                // 적용시작기간의 연월로 해당 정책연월의 말일을 계산해서 div_search의 적용마감기간란에 입력해준다.
            }
            this.div_search.aplyDtm = [
                this.getDateTime('date', aplyStaDtm),
                this.getDateTime('date', aplyEndDtm),
            ]
            this.div_search.aplyStaHour = aplyStaHour
            this.div_search.aplyStaMin = aplyStaMin
            this.div_search.aplyEndHour = aplyEndHour
            this.div_search.aplyEndMin = aplyEndMin
            this.div_search.changeInfo = changeInfo
            this.onSearch()
        },
        /** polYm이 null인지 확인 */
        isPolYmNull() {
            if (
                this.div_search.cal_polYm == undefined ||
                this.div_search.cal_polYm == ''
            ) {
                if (
                    this.ds_condition.polYm == undefined ||
                    this.ds_condition.polYm == ''
                ) {
                    console.log('polYm is null!!!!!')
                    const today = new Date()
                    const y = today.getFullYear().toString()
                    const m =
                        today.getMonth() + 1 > 9
                            ? (today.getMonth() + 1).toString()
                            : '0' + (today.getMonth() + 1).toString()
                    const polYmToday = y + m
                    console.log('polYmToday : ', polYmToday)
                    this.ds_condition.polYm = polYmToday
                }
            }
        },

        //===================== 정책변경팝업 methods ================================
        onPrcTbltnPolChgClick() {
            this.resultPrcTbltnPolChgRows = []
            this.searchPrcTbltnPolChgParam = {
                aplyStaDtm: this.div_search.aplyDtm[0],
                aplyEndDtm: this.div_search.aplyDtm[1],
                aplyStaHour: this.div_search.aplyStaHour,
                aplyStaMin: this.div_search.aplyStaMin,
                aplyEndHour: this.div_search.aplyEndHour,
                aplyEndMin: this.div_search.aplyEndMin,
            }
            console.log(
                'onPrcTbltnPolChgClick-aplyDtm: ',
                this.searchPrcTbltnPolChgParam
            )
            this.showPrcTbltnPolChg = true
            // }
        },

        // 정책변경팝업 리턴 이벤트 처리
        onReturnData(returnData) {
            console.log('returnData: ', returnData)
            let aplyDtm = _.get(returnData, 'cal_polYm')
            let cal_polYmHour = _.get(returnData, 'cal_polYmHour')
            let cal_polYmMin = _.get(returnData, 'cal_polYmMin')
            this.div_search.aplyDtm[1] = aplyDtm
            this.div_search.aplyStaHour = cal_polYmHour
            this.div_search.aplyStaMin = cal_polYmMin

            // 정책버튼 사용하여 적용시작기간을 변경 시, 저장버튼 활성화
            this.saveBtn = false
        },

        //===================== //등록팝업수정 methods ================================

        // 운영모델단가표 화면 이동
        onListClick() {
            this.$router.push({
                name: '/bas/pdm/BasPdmUprcTbltnMgmt',
                params: { search: this.reqParam },
            })
        },

        // ==================== 저장 관련 ========================== //

        /** 1단계 - 저장 시 확인 필요한 항목들 체크 */
        checkBeforeSave() {
            const condition = this.ds_condition
            // 재고보상을 한 경우 리턴
            if (condition.disCmpObjYn == 'Y') {
                this.showTcComAlert(
                    '재고보상 완료된 운영모델 단가표는 저장이 불가합니다.'
                )
                return false
            }

            // 변경사항 확인
            if (condition.hstFlag != 'Y') {
                if (this.SAVE_FLAG == 'N') {
                    this.showTcComAlert('변경사항이 없습니다.')
                    return false
                }
            }

            // 리스트 카운트
            if (this.save_uplst_aply_mdl.length < 1) {
                this.showTcComAlert('선택된 단말기가 없습니다.')
                return false
            }

            return true
        },

        /** 2단계 - 운영모델 단가표의 기존여신매입가와 확정여신매입가 금액 비교 */
        f_disCmpObjYn(uplstAplyList) {
            let compMoney = false

            for (let i = 0; i < uplstAplyList.length; i++) {
                // 기존정보 여신매입가
                const exitCrdtPrchsPrc = parseInt(
                    uplstAplyList[i].exitCrdtPrchsPrc
                )
                // 확정정보 여신매입가
                const fixCrdtPrchsPrc = parseInt(
                    uplstAplyList[i].fixCrdtPrchsPrc
                )

                if (exitCrdtPrchsPrc - fixCrdtPrchsPrc != 0) {
                    compMoney = true
                }
            }
            return compMoney
        },

        getTotalList(totalList) {
            let list = []
            const changeInfo = this.ds_condition.changeInfo

            if (_.isEqual(changeInfo, 'UPT')) {
                return totalList
            }

            totalList.forEach((item) => {
                item.exitCashPrchsPrc = item.fixCashPrchsPrc
                item.exitCrdtPrchsPrc = item.fixCrdtPrchsPrc
                item.exitStrdSalePrc = item.fixStrdSalePrc
                item.exitUnitSalePrc = item.fixUnitSalePrc
                list.push(item)
            })
            return list
        },

        /** 저장 리스트 생성 - 기존의 운영모델 리스트와 변경대상 리스트를 flag 처리하여 하나로 합치기  */
        f_add_pol_uplst_aply_mdl() {
            let modRsnIsS = []
            let modRsnIsC = []
            // 기존 리스트 - 다음 차수에도 반영 필수.
            this.ds_pol_uplst_aply_mdl.forEach((prod) => {
                prod.cudFlag = 'I'
            })
            // 변경대상이 없을 경우 - 그리드에서 데이터 입력 X
            if (this.ds_cp_prod_mgmt == undefined) {
                this.ds_pol_uplst_aply_mdl.forEach((prod) => {
                    prod.editFlag = 'N'
                })
            } else {
                // 변경대상이 있을 경우
                modRsnIsS = this.ds_cp_prod_mgmt.filter(
                    (prod) => prod.modRsn == 'S'
                )
                modRsnIsC = this.ds_cp_prod_mgmt.filter(
                    (prod) => prod.modRsn == 'C'
                )
                console.log('modRsnIsS : ', modRsnIsS)
                console.log('modRsnIsC : ', modRsnIsC)
                // 사용 중지 리스트에 대해서 flag 처리
                if (modRsnIsS.length > 0) {
                    for (let i = 0; i < modRsnIsS.length; i++) {
                        this.ds_pol_uplst_aply_mdl.forEach((item) => {
                            if (item.prodCd == modRsnIsS[i].prodCd) {
                                // 사용중지 상품 => 단가표 저장 시 제외
                                item.cudFlag = 'D'
                                console.log('cudflag prod : ', item.prodCd)
                            } else {
                                if (item.exitStrdSalePrc <= 0) {
                                    // 기존정보 > 기준판매가가 0원 => 기존정보여도 편집 가능
                                    item.editFlag = 'Y'
                                }
                            }
                        })
                    }
                }

                // 해당 단가표에 신규 운영상품 등록
                if (modRsnIsC.length != 0) {
                    for (let i = 0; i < modRsnIsC.length; i++) {
                        modRsnIsC[i].cudFlag = 'I'
                        modRsnIsC[i].editFlag = 'Y'
                        modRsnIsC[i].uplstId = this.ds_condition.uplstId
                        modRsnIsC[i].polYm = this.ds_condition.polYm
                        modRsnIsC[i].polTs = this.ds_condition.polTs
                    }
                }
            }
            console.log('before fitered : ', this.ds_pol_uplst_aply_mdl)

            this.ds_pol_uplst_aply_mdl = this.ds_pol_uplst_aply_mdl.filter(
                (prod) => prod.cudFlag != 'D'
            )

            console.log('filtered "D" : ', this.ds_pol_uplst_aply_mdl)
            console.log('modRsnIsC : ', modRsnIsC)

            const totalList = [...this.ds_pol_uplst_aply_mdl, ...modRsnIsC]

            return totalList
        },

        /** 저장 = 소급변경 or 차수+1 단가표 저장 여부 결정  && 삭제 시에도 사용*/
        chooseSaveMethod() {
            const aplyStaDtmNow =
                this.div_search.aplyDtm[0].replaceAll('-', '') +
                this.div_search.aplyStaHour +
                this.div_search.aplyStaMin
            console.log('aplyStaDtmNow : ', aplyStaDtmNow)
            console.log('PRE_APLY_STA_DTM : ', this.PRE_APLY_STA_DTM)

            // 날짜 변경 X and 상품변경팝업 거치지 않았을 경우
            console.log(
                'this.ds_condition.popFlag ->',
                this.ds_condition.popFlag
            )

            const changeInfo = this.div_search.changeInfo
            console.log('changeInfo ->', changeInfo)
            // 날짜 변경 X and 상품변경팝업 거치지 않았을 경우
            if (
                _.isEqual(changeInfo, 'UPT')
                // 230109 기존 조건 삭제
                // (this.ds_condition.popFlag == 'N' &&
                //     this.PRE_APLY_STA_DTM == aplyStaDtmNow)
            ) {
                // 적용모델리스트 => inveYn == 'Y'인 수가 0 이상이
                let inveYnCount = 0
                this.ds_pol_uplst_aply_mdl.forEach((prod) => {
                    if (prod.inveYn == 'Y') {
                        inveYnCount++
                    }
                })
                console.log('inveYnCount : ', inveYnCount)
                if (inveYnCount > 0) {
                    this.showTcComAlert(
                        '재고보상 완료된 운영모델 단가표는 저장이 불가합니다.'
                    )
                    return
                }
                return 2 // 소급변경
            } else {
                return 1 // 단가표 저장(차수증가)
            }
        },

        saveList() {
            const jsonRows = this.gridObj.dataProvider.getJsonRows()
            let saveList = []
            _.forEach(this.ds_pol_uplst_aply_mdl, (item) => {
                saveList.push(item)
            })
            _.forEach(this.ds_cp_prod_mgmt, (item) => {
                saveList.push(item)
            })
            /*
              const saveList = [
                  ...this.ds_pol_uplst_aply_mdl,
                  ...this.ds_cp_prod_mgmt,
              ]
             */
            console.log('jsonRows : ', jsonRows)
            console.log('saveList : ', saveList)
            console.log('gap :', jsonRows.length - saveList.length)

            for (let i = 0; i < jsonRows.length; i++) {
                let item = saveList[i]
                item.exitCashPrchsPrc = parseInt(jsonRows[i].exitCashPrchsPrc)
                item.exitCrdtPrchsPrc = parseInt(jsonRows[i].exitCrdtPrchsPrc)
                item.exitStrdSalePrc = parseInt(jsonRows[i].exitStrdSalePrc)
                item.exitUnitSalePrc = parseInt(jsonRows[i].exitUnitSalePrc)
                item.fixCashPrchsPrc = parseInt(jsonRows[i].fixCashPrchsPrc)
                item.fixCrdtPrchsPrc = parseInt(jsonRows[i].fixCrdtPrchsPrc)
                item.fixStrdSalePrc = parseInt(jsonRows[i].fixStrdSalePrc)
                item.fixUnitSalePrc = parseInt(jsonRows[i].fixUnitSalePrc)
                item.realPrchsPrc = parseInt(jsonRows[i].realPrchsPrc)
                item.orgRealPrchsPrc = parseInt(jsonRows[i].orgRealPrchsPrc)
            }
            return saveList
        },

        // 운영 모델 단가표 저장
        onSave() {
            this.gridObj.gridView.commit()
            const changeInfo = this.ds_condition.changeInfo
            let title = '운영모델 단가표를 변경하시겠습니까?'
            if (_.isEqual(changeInfo, 'CRD')) {
                title = '새로운 적용연월에 ' + title
            }
            this.showTcComConfirm(title).then((confirm) => {
                if (!confirm) return

                // 저장할 리스트 생성
                this.save_uplst_aply_mdl = this.saveList()

                // 저장 시 체크 1단계 - 저장할 리스트의 상품들을 파악하여 재고보상여부를 파악
                const disCmpObjYnBeforeSave = this.f_disCmpObjYn(
                    this.save_uplst_aply_mdl
                )

                // 저장 시 체크 2단계
                const checkBeforeSave = this.checkBeforeSave()
                console.log('can Save? : ', checkBeforeSave)
                if (!checkBeforeSave) return

                if (disCmpObjYnBeforeSave) {
                    this.ds_condition.disCmpObjYn = 'Y'
                } else if (!disCmpObjYnBeforeSave) {
                    this.ds_condition.disCmpObjYn = 'N'
                } else {
                    // case undefined
                    this.$router.push({
                        name: '/bas/pdm/BasPdmUprcTbltnMgmt',
                        params: { msg: 'go to home' },
                    })
                }
                console.log('disCmpObjYnBeforeSave ? : ', disCmpObjYnBeforeSave)

                let saveParam = {}

                saveParam.prodGrpClCd = this.ds_condition.prodGrpClCd
                saveParam.polYm = this.div_search.cal_polYm
                    ? this.div_search.cal_polYm.replaceAll('-', '')
                    : ''
                saveParam.uplstId = this.ds_condition.uplstId
                    ? this.ds_condition.uplstId
                    : ''
                saveParam.polTs = this.ds_condition.polTs
                    ? this.ds_condition.polTs
                    : ''
                saveParam.aplyStaDtm = this.div_search.aplyDtm[0]
                    ? this.div_search.aplyDtm[0].replaceAll('-', '')
                    : ''
                saveParam.aplyEndDtm = this.div_search.aplyDtm[1]
                    ? this.div_search.aplyDtm[1].replaceAll('-', '')
                    : ''
                saveParam.hour = this.div_search.aplyStaHour
                    ? this.div_search.aplyStaHour
                    : ''
                saveParam.min = this.div_search.aplyStaMin
                    ? this.div_search.aplyStaMin
                    : ''
                saveParam.endHour = this.div_search.aplyEndHour
                    ? this.div_search.aplyEndHour
                    : ''
                saveParam.endMin = this.div_search.aplyEndMin
                    ? this.div_search.aplyEndMin
                    : ''
                saveParam.prodFindNm = this.ds_condition.prodFindNm
                    ? this.ds_condition.prodFindNm
                    : ''
                saveParam.disCmpObjYn = this.ds_condition.disCmpObjYn
                    ? this.ds_condition.disCmpObjYn
                    : ''
                saveParam.sequenceNo = this.ds_condition.sequenceNo
                    ? this.ds_condition.sequenceNo
                    : ''
                saveParam.aplyMdlList = this.save_uplst_aply_mdl
                saveParam.rmks = this.div_search.edt_Rmks
                    ? this.div_search.edt_Rmks
                    : ''

                console.log('saveParam : ', saveParam)

                const chooseSaveMethod = this.chooseSaveMethod(
                    this.ds_condition
                )
                console.log('chooseSaveMethod : ', chooseSaveMethod)

                // 정책연월 새 단가표 저장(기존차수 + 1)
                if (chooseSaveMethod == 1) {
                    console.log('단가표 저장')

                    API.savePolUpLst(saveParam).then((result) => {
                        console.log('result : ', result)
                        if (result !== undefined) {
                            this.showTcComAlert('정상적으로 처리되었습니다.')
                            this.$router.push({
                                name: '/bas/pdm/BasPdmUprcTbltnMgmt',
                                params: { msg: 'go to home' },
                            })
                        } else {
                            this.$router.push({
                                name: '/bas/pdm/BasPdmUprcTbltnMgmt',
                                params: { msg: 'go to home' },
                            })
                        }
                    })
                }
                // 소급변경 시
                else if (chooseSaveMethod == 2) {
                    console.log('소급변경')
                    API.savePolUpLstRtrvyChg(saveParam).then((result) => {
                        console.log('result : ', result)
                        if (result !== undefined) {
                            this.showTcComAlert('정상적으로 처리되었습니다.')
                            this.$router.push({
                                name: '/bas/pdm/BasPdmUprcTbltnMgmt',
                                params: { msg: 'go to home' },
                            })
                        } else {
                            this.$router.push({
                                name: '/bas/pdm/BasPdmUprcTbltnMgmt',
                                params: { msg: 'go to home' },
                            })
                        }
                    })
                }
            })
        },

        // ==================== /저장 관련 ========================== //
        // 삭제 전 체크사항
        f_pre_delete() {
            if (this.ds_condition.disCmpFnshYn == 'Y') {
                console.log(
                    '재고보상 완료된 운영모델 단가표는 삭제 불가합니다.'
                )
                return
            }

            /*  * ASIS 주석 그대로 옮겨옴
          재고보상된 모델이 하나라도 있는 경우 수정 X
          적용시작일시 변경이 없는 경우만 재고보상 체크, next ts를 입력하려는 경우엔 체크로직 제외
      */

            const aplyStaDtmNow =
                this.div_search.aplyDtm[0].replaceAll('-', '') +
                this.div_search.aplyStaHour +
                this.div_search.aplyStaMin
            console.log('aplyStaDtmNow : ', aplyStaDtmNow)
            console.log('PRE_APLY_STA_DTM : ', this.PRE_APLY_STA_DTM)

            if (this.PRE_APLY_STA_DTM == aplyStaDtmNow) {
                let inveYnCount = 0
                this.ds_pol_uplst_aply_mdl.forEach((prod) => {
                    if (prod.inveYn == 'Y') {
                        inveYnCount++
                    }
                })
                if (inveYnCount > 0) {
                    this.showTcComAlert(
                        '재고보상 완료된 운영모델 단가표는 저장이 불가합니다.'
                    )
                    return
                }
            }

            return true
        },

        // 운영 모델 단가표 삭제
        onDelete() {
            const preDelete = this.f_pre_delete() // true일 경우에만 삭제처리가 진행됨
            console.log('onDelete preDelete : ', preDelete)
            /*
          * AS-IS에서 체크하는 항목 두 가지 => 무얼 확인하는 건지 파악 못 함.. 추후에 추가
              f_CheckCloseMnth('04',ds_condition.getColumn(0,"APLY_STA_DTM"),'적용기간');
              if(FV_BOOLEAN_CLOSE) return;
      */
            this.showTcComConfirm(
                '해당 운영모델 단가표를 삭제하시겠습니까?'
            ).then((confirm) => {
                if (!confirm) return

                let delParam = {
                    uplstId: this.ds_condition.uplstId
                        ? this.ds_condition.uplstId
                        : '',
                    polYm: this.ds_condition.polYm
                        ? this.ds_condition.polYm
                        : '',
                    polTs: this.ds_condition.polTs
                        ? this.ds_condition.polTs
                        : '',
                    prodGrpClCd: this.ds_condition.prodGrpClCd
                        ? this.ds_condition.prodGrpClCd
                        : '',
                }
                console.log('onDelete delParam : ', delParam)
                API.deletePolUpLst(delParam).then((resultData) => {
                    console.log('resultData : ', resultData)
                    this.$router.push({
                        name: '/bas/pdm/BasPdmUprcTbltnMgmt',
                        params: { msg: 'go to home' },
                    })
                })
            })
        },

        // 정책변경 팝업 오픈
        onProdClick() {
            this.$router.push({
                name: '/dis/oao/DisOaoEtcOutMgmtDtl',
                params: { search: this.reqParam },
            })
        },

        // 콤보박스 값 변경 시
        onChange() {
            this.classifyList(this.div_search.cmb_OpenCl)
        },

        /**  value에 따른 label 리턴 함수 */
        executePayment(paymentMap, paymentType) {
            return paymentMap[paymentType]
        },

        classifyList(val) {
            const paymentMap = {
                '01': '일반형',
                '02': 'OMD',
                '03': '개방형',
                '04': '에코형',
                '': '',
            }

            const name = this.executePayment(paymentMap, val)
            console.log('name : ', name)
            // 필터링할 값 설정
            const filters = [
                {
                    name: '일반형',
                    criteria: "value = '일반형'",
                    active: false, // 필터 적용 시 적용 여부
                },
                {
                    name: 'OMD',
                    criteria: "value = 'OMD'",
                    active: false,
                },
                {
                    name: '개방형',
                    criteria: "value = '개방형'",
                    active: false,
                },
                {
                    name: '에코형',
                    criteria: "value = '에코형'",
                    active: false,
                },
            ]
            if (name == '') {
                // 전체('') 선택 시, 필터 해제
                this.gridObj.gridView.clearColumnFilters('eqpClNm')
            } else {
                this.gridObj.gridView.setColumnFilters('eqpClNm', filters) // 필터 적용할 컬럼명과 필터 배열로 세팅
                // name과 일치하는 항목 필터링
                this.gridObj.gridView.activateColumnFilters(
                    'eqpClNm',
                    [name],
                    true
                )
            }
        },

        // 검색한 상품에 포커싱
        prodFocus() {
            let target = this.findProd

            const gridView = this.gridObj.gridView
            const dataProvider = this.gridObj.dataProvider

            // RealGrid2 > 검색
            const fields = []
            fields.push(dataProvider.getOrgFieldName(5))
            fields.push(dataProvider.getOrgFieldName(6))
            let startFieldIndex =
                fields.indexOf(gridView.getCurrent().fieldName) + 1
            let options = {
                fields: fields,
                value: target,
                startIndex: gridView.getCurrent().itemIndex,
                startFieldIndex: startFieldIndex,
                wrap: true,
                caseSensitive: false,
                partialMatch: true,
            }
            let index = gridView.searchCell(options)
            gridView.setFocus(index)
        },

        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            let reqParam = {
                uplstId: this.ds_condition.uplstId,
                polYm: this.ds_condition.polYm,
                polTs: this.ds_condition.polTs,
                aplyEndDtm: this.ds_condition.aplyEndDtm,
                changeInfo: this.ds_condition.changeInfo,
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/pdm/pdmOperMdlExcelList',
                reqParam
            )
        },
    },
}
</script>
