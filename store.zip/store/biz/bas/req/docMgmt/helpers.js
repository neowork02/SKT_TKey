import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('bas.req.docMgmtStore', Object.keys(state)),
    ...mapGetters('bas.req.docMgmtStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('bas.req.docMgmtStore', Object.keys(actions)),
    ...mapMutations('bas.req.docMgmtStore', Object.keys(mutations)),
}
