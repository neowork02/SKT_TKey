<template lang="">
    <div>
        <div class="searchLayer_wrap">
            <!-- Search_line -->
            <div class="searchform">
                <div class="formitem div2">
                    <TCComComboBox
                        labelName="요청구분"
                        v-model="parentParam1.reqClCd"
                        :itemList="searchCode[0]"
                        :objAuth="objAuth"
                        :disabled="false"
                    />
                </div>
                <div class="formitem div2">
                    <TCComInput
                        v-model="parentParam1.itDocNo"
                        labelName="IT 지원요청서"
                        :objAuth="objAuth"
                        :disabled="readOnly"
                    ></TCComInput>
                </div>
            </div>
            <!-- Search_line -->
            <div class="searchform">
                <!-- input -->
                <div class="formitem div1">
                    <TCComInput
                        v-model="parentParam1.reqTitle"
                        labelName="요건 명"
                        :objAuth="objAuth"
                        :eRequired="true"
                        :disabled="readOnly"
                    ></TCComInput>
                </div>
            </div>
            <!-- Search_line -->
            <div class="searchform">
                <!-- input -->
                <div class="formitem div1">
                    <span class="itemtit">
                        <TCComLabel labelName="요건 상세" :eRequired="true" />
                    </span>
                    <span class="iteminput">
                        <TCComNoLabelTextArea
                            v-model="parentParam1.reqDtl"
                            class="boxtype"
                            :rows="6"
                            :maxlength="5000"
                            :readonly="readOnly"
                        />
                    </span>
                    <!-- <TCComTextArea
                        v-model="parentParam1.reqDtl"
                        labelName="* 요건 상세"
                        class="boxtype"
                        :rows="6"
                        :maxlength="5000"
                        :eRequired="true"
                        :readonly="readOnly"
                    ></TCComTextArea> -->
                </div>
            </div>
            <!-- Search_line -->
            <div class="searchform">
                <!-- input -->
                <div class="formitem div3">
                    <TCComInput
                        v-model="parentParam1.reqUserNmView"
                        labelName="요청자"
                        :objAuth="objAuth"
                        :disabled="true"
                    ></TCComInput>
                </div>
                <div class="formitem div3">
                    <TCComInput
                        v-model="parentParam1.reqOrgNmView"
                        labelName=""
                        :objAuth="objAuth"
                        :disabled="true"
                    ></TCComInput>
                </div>
                <div class="formitem div3" id="email1">
                    <TCComInput
                        v-model="parentParam1.reqUserEmail"
                        labelName="E-Mail"
                        :objAuth="objAuth"
                        :disabled="readOnly"
                        :eRequired="false"
                    ></TCComInput>
                </div>
            </div>
            <!-- Search_line -->
            <div class="searchform">
                <!-- input -->
                <div class="formitem div1">
                    <!-- 파일첨부 그리드 -->
                    <AttachedFileAdd
                        gridHeaderId="docRgstFileAddGridHeader"
                        gridId="docRgstFileAddGrid"
                        ref="attachedFileAdd"
                        :fileList="fileSearchList"
                        @file-change="onFileAddChange"
                        gridHeight="100px"
                    ></AttachedFileAdd>
                </div>
            </div>
            <!-- Search_line -->
            <div class="searchform">
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="개발담당자"
                        v-model="parentParam1.devClCd"
                        :itemList="searchCode[2]"
                        :objAuth="objAuth"
                        :disabled="readOnlyDev"
                    />
                </div>
                <div class="formitem div3"></div>
                <div class="formitem div3"></div>
            </div>
            <div class="searchform">
                <div class="formitem div3">
                    <TCComDatePicker
                        labelName="완료 예상일자"
                        :calType="calType4"
                        v-model="schdDt"
                        :disabled="readOnlyDev"
                    />
                    <!-- <TCComDatePicker
                        labelName="통화일자및시간"
                        :calType="calType4"
                        :hourVal.sync="
                            getDtHhMi(formSearchParams_offr.callDtm).Hh
                        "
                        :minuVal.sync="
                            getDtHhMi(formSearchParams_offr.callDtm).Mi
                        "
                        v-model="getDtHhMi(formSearchParams_offr.callDtm).Dt"
                    /> -->
                </div>
                <div class="formitem div3"></div>
                <div class="formitem div3"></div>
            </div>
        </div>
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/docRgst/helpers'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
// eslint-disable-next-line no-unused-vars
import commonApi from '@/api/common/commonCode'
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import AttachedFileAdd from '@/components/common/AttachedFileAdd'
export default {
    mixins: [CommonMixin],
    components: { AttachedFileAdd },
    data() {
        return {
            objAuth: {},
            calType5: 'DP', //'M' //'DP'
            schdDt: [''],
            //clsDt: '',
            searchCode: [
                [
                    {
                        commCdVal: '신규요건',
                        commCdValNm: '신규요건',
                    },
                    {
                        commCdVal: '변경요건',
                        commCdValNm: '변경요건',
                    },
                    {
                        commCdVal: '오류수정',
                        commCdValNm: '오류수정',
                    },
                    {
                        commCdVal: '데이타보정',
                        commCdValNm: '데이타보정',
                    },
                    {
                        commCdVal: '데이타추출',
                        commCdValNm: '데이타추출',
                    },
                    {
                        commCdVal: '운영업무',
                        commCdValNm: '운영업무',
                    },
                ],
                [
                    {
                        commCdVal: '요청',
                        commCdValNm: '요청',
                    },
                    {
                        commCdVal: '승인',
                        commCdValNm: '승인',
                    },
                    {
                        commCdVal: '반려',
                        commCdValNm: '반려',
                    },
                    {
                        commCdVal: '취소',
                        commCdValNm: '취소',
                    },
                    {
                        commCdVal: '진행',
                        commCdValNm: '진행',
                    },
                    // {
                    //     commCdVal: '1차테스트',
                    //     commCdValNm: '1차테스트',
                    // },
                    // {
                    //     commCdVal: '2차테스트',
                    //     commCdValNm: '2차테스트',
                    // },
                    {
                        commCdVal: '배포',
                        commCdValNm: '배포',
                    },
                    {
                        commCdVal: '취소',
                        commCdValNm: '취소',
                    },
                    // {
                    //     commCdVal: '완료',
                    //     commCdValNm: '완료',
                    // },
                ],
                [], //개발담당자 api 호출용
            ],
            fromDt: '',
            toDt: '',
            orgCd: '' /*조직코드*/,
            insDtm_format: '',
            modDtm_format: '',
            parentParam1: {
                reqDt: '',
                uuid: '',
                reqClCd: '',
                itDocNo: '',
                reqTitle: '',
                reqDtl: '',
                reqUserId: '',
                reqUserNm: '',
                reqOrgCd: '',
                reqUserEmail: '',
                reqStNm: '',
                reqDocId: '',
                reqOrgNmView: '',
                reqUserNmView: '',
                devClCd: '',
                expEndDt: '',
            },
            calType4: 'D', //'DHM',
            callDtm: [], //통화및일자시간
            callHour: '',
            callMin: '',
            fileSearchList: [],
            formData: new FormData(),
            screenId: 'BasReqDocRgst',
            docId: 'test1',
            readOnly: false,
            readOnlyDev: false,
            mode: 'new',
        }
    },
    async mounted() {
        console.log('mounted DataContainer')
        commonApi.getCommonCodeListById('ZADM_C_00010').then((commData) => {
            const devComm = commData.map((a) => {
                return {
                    commCdVal: a.commCdValNm + '담당',
                    commCdValNm: a.commCdValNm + '담당',
                }
            })
            this.searchCode[2] = devComm
            console.log('ZADM_C_00010', commData)
        })

        this.initData()
    },
    computed: {
        ...serviceComputed,
        popupParams1: {
            get() {
                return this.popupParams
            },
        },
        resultList1: {
            get() {
                return this.resultList
            },
        },
        saveAction1: {
            get() {
                return this.saveAction
            },
        },
        popupInit1: {
            get() {
                return this.popupInit
            },
        },
    },
    methods: {
        ...serviceMethods,
        initObj(obj1) {
            for (let prop in obj1) {
                if (Object.prototype.hasOwnProperty.call(obj1, prop)) {
                    obj1[prop] = ''
                }
            }
        },
        copyObjExist(obj1, obj2) {
            Object.keys(obj2).forEach(function (key) {
                if (key in obj1) {
                    obj1[key] = _.isEmpty(obj2[key]) ? '' : obj2[key]
                }
            })
        },
        async initData() {
            //let today = moment(new Date()).format('YYYY-MM-01')
            //let today1 = moment(new Date()).format('YYYY-MM-DD')
            this.schdDt = ['']
            this.initObj(this.parentParam1)
            this.parentParam1.reqClCd = '신규요건'
            this.parentParam1.reqDt = moment(new Date()).format('YYYYMMDD')
            this.parentParam1.uuid = this.uuidv4()
            this.fileSearchList = []

            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.defaultAssign_({
                key: 'resultList',
                value: '',
            })
        },
        async initBtn() {
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 122 ~ data ',
                this.$data
            )
            await this.initData()
            //this.searchBtn() //이화면은 초기화가 다시 조회처리

            //CommonUtil.clearPage(this.$router)
        },
        getDtHhMi(dtm) {
            if (dtm) {
                let data = {
                    Dt: CommonUtil.addDashDate(dtm.substr(0, 8)),
                    Hh: dtm.substr(8, 2),
                    Mi: dtm.substr(10, 2),
                }
                return data
            } else {
                let data = {
                    Dt: '',
                    Hh: '',
                    Mi: '',
                }
                return data
            }
        },
        changeEmail() {
            // if (this.validEmailCheck(this.parentParam1.reqUserEmail) == false) {
            //     // const el = document
            //     //     .getElementById('email1')
            //     //     .querySelectorAll('input')
            //     // console.log(el[0])
            //     // el[0].focus()
            //     this.showTcComAlert('올바른 이메일 주소를 입력해주세요.')
            // }
        },
        validEmailCheck(obj) {
            const pattern =
                /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i
            return obj.match(pattern) != null
        },
        async validationCheck() {
            // let fromDt = new Date(this.schdDt[0])
            // let toDt = new Date(this.schdDt[1])
            // if (fromDt > toDt) {
            //     this.showTcComAlert('시작일자가 마지막일자 보다 큽니다.')
            //     return false
            // }
            // if (
            //     moment(fromDt).format('YYYY-MM') !=
            //     moment(toDt).format('YYYY-MM')
            // ) {
            //     this.showTcComAlert('같은 월 검색만 됩니다.')
            //     return false
            // }
            if (_.isEmpty(this.parentParam1.reqTitle)) {
                this.showTcComAlert('요건명은 필수 입니다.')
                return false
            }
            if (_.isEmpty(this.parentParam1.reqDtl)) {
                this.showTcComAlert('요건상세는 필수 입니다.')
                return false
            }
            // if (this.validEmailCheck(this.parentParam1.reqUserEmail) == false) {
            //     this.showTcComAlert('올바른 이메일 주소를 입력해주세요.')
            //     return false
            // }

            if (this.mode == 'dev') {
                if (_.isEmpty(this.parentParam1.devClCd)) {
                    this.showTcComAlert('개발담당자를 선택하세요.')
                    return false
                }
                if (_.isEmpty(this.schdDt) || _.isEmpty(this.schdDt[0])) {
                    this.showTcComAlert('완료 예상일자를 입력하세요.')
                    return false
                }
            }

            const confirm = await this.showTcComConfirm('저장 하시겠습니까?')

            if (!confirm) {
                return false
            }

            return true
        },
        async saveData() {
            console.log('menuInfo', this.menuInfo) //메뉴정보
            console.log('orgInfo', this.orgInfo) //조직정보
            console.log('userInfo', this.userInfo) //사용자정보
            console.log('authInfo', this.authInfo) // 권한정보(속성권한)

            //
            let saveRows = []
            // const lng1 = this.parentParam0.length
            // for (let i = 0; i < lng1; i++) {
            //     saveRows.push({
            //         //...this.parentParam0[i],
            //         rowState: 'created',
            //         reqDt: this.parentParam0[i].reqDt,
            //         uuid: this.parentParam0[i].uuid,
            //         reqStNm: '요청',
            //         ...this.parentParam1,
            //     })
            // }

            console.log('save 요청', saveRows)
            const resultData = await this.saveAttachFile_(this.formData)
            console.log('save files', resultData, this.formData)
            saveRows.push({
                ...this.parentParam1,
                rowState: 'created',
                //reqDt: moment(new Date()).format('YYYYMMDD'),
                //uuid: this.uuidv4(),
                reqStNm: '요청',
                reqDocId: _.isEmpty(resultData) ? '' : resultData[0].docId,
            })

            await this.saveDocRgst_({ saveRows })
            this.saveParam = saveRows
        },
        async saveDataUpdateReq() {
            console.log('menuInfo', this.menuInfo) //메뉴정보
            console.log('orgInfo', this.orgInfo) //조직정보
            console.log('userInfo', this.userInfo) //사용자정보
            console.log('authInfo', this.authInfo) // 권한정보(속성권한)

            //
            let saveRows = []
            // const lng1 = this.parentParam0.length
            // for (let i = 0; i < lng1; i++) {
            //     saveRows.push({
            //         //...this.parentParam0[i],
            //         rowState: 'created',
            //         reqDt: this.parentParam0[i].reqDt,
            //         uuid: this.parentParam0[i].uuid,
            //         reqStNm: '요청',
            //         ...this.parentParam1,
            //     })
            // }

            const resultData = await this.saveAttachFile_(this.formData)
            console.log('save files', resultData, this.formData)
            saveRows.push({
                ...this.parentParam1,
                rowState: 'updated',
                reqDocId: _.isEmpty(resultData) ? null : resultData[0].docId,
            })
            console.log('save update req 요청', saveRows)

            await this.saveDocRgst_({ saveRows })
            this.saveParam = saveRows
        },
        async saveDataUpdateDev() {
            console.log('menuInfo', this.menuInfo) //메뉴정보
            console.log('orgInfo', this.orgInfo) //조직정보
            console.log('userInfo', this.userInfo) //사용자정보
            console.log('authInfo', this.authInfo) // 권한정보(속성권한)

            //
            let saveRows = []

            saveRows.push({
                reqDt: this.parentParam1.reqDt,
                uuid: this.parentParam1.uuid,
                rowState: 'updated',
                devClCd: this.parentParam1.devClCd,
                expEndDt: this.schdDt.replace(/-/g, ''),
                reqStNm: '진행', //개발팀 할당은 승인/반려에 관계없이 진행으로 간주
            })
            console.log('save update dev 요청', saveRows)

            await this.saveDocRgst_({ saveRows })
            this.saveParam = saveRows
        },
        uuidv4() {
            return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
                (
                    c ^
                    (crypto.getRandomValues(new Uint8Array(1))[0] &
                        (15 >> (c / 4)))
                ).toString(16)
            )
        },
        onFileAddChange(files) {
            console.log('files: ', files)
            this.formData = new FormData()
            const addFileLength = files.addFile.length

            _.forEach(files.addFile, (item, index) => {
                this.formData.append('files', item.file)
                this.formData.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].screenId`,
                    this.screenId
                )
                this.formData.append(
                    `admAppendFileList[${index}].docId`,
                    this.parentParam1.reqDocId
                )
                this.formData.append(
                    `admAppendFileList[${index}].__rowState`,
                    'created'
                )
            })
            _.forEach(files.delFile, (item, index) => {
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].filePathNm`,
                    item.filePathNm
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].fileType`,
                    item.fileType
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].screenId`,
                    item.screenId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].docId`,
                    item.docId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].__rowState`,
                    'deleted'
                )
            })
        },
        maskingName(strName) {
            if (_.isEmpty(strName)) return strName
            if (strName.length > 2) {
                let originName = strName.split('')
                originName.forEach(function (name, i) {
                    if (i === 0 || i === originName.length - 1) return
                    originName[i] = '*'
                })
                let joinName = originName.join()
                return joinName.replace(/,/g, '')
            } else {
                let pattern = /.$/ // 정규식
                return strName.replace(pattern, '*')
            }
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        async resultList1(val, oldVal) {
            await this.initData()
            if (_.isEmpty(val)) return

            const row1 = {
                ..._.clone(val[0]),
                reqOrgNmView: `${val[0].reqOrgNm}(${val[0].reqOrgCd})`,
                reqUserNmView: `${this.maskingName(val[0].reqUserNm)}(${
                    val[0].reqUserId
                })`,
            }
            this.copyObjExist(this.parentParam1, row1)

            this.schdDt = [
                _.isEmpty(row1.expEndDt)
                    ? ''
                    : moment(row1.expEndDt, 'YYYYMMDD').format('YYYY-MM-DD'),
            ]
            const data = await this.getAttachFile_({
                param: {
                    screenId: 'BasReqDocRgst',
                    docId: row1.reqDocId, //'1665476422263',
                },
            })
            console.log('get attach file', data)
            this.fileSearchList = []
            this.$refs.attachedFileAdd.init()
            if (!_.isEmpty(data)) {
                data.forEach((item) => {
                    this.fileSearchList.push({
                        screenId: item.screenId,
                        docId: item.docId,
                        name: item.fileNm,
                        size: item.fileSize,
                        filePathNm: item.filePathNm,
                        fileType: item.fileType,
                    })
                })
                //
            }

            //사용자 정보 조회 ---------------------------------------------------------
            // this.copyObjExist(this.formSearchParams, val.userInfo[0])
            // this.insDtm_format = _.isEmpty(this.formSearchParams.insDtm)
            //     ? ''
            //     : moment(this.formSearchParams.insDtm, 'YYYYMMDDHHmmss').format(
            //           'YYYY-MM-DD HH:mm:ss'
            //       )
        },
        popupInit1: {
            // eslint-disable-next-line no-unused-vars
            handler: async function (value) {
                if (value == true) {
                    console.log('DataContainer init: ', value)
                    await this.initData()
                    this.fileSearchList = []
                    if (this.$refs.attachedFileAdd != undefined)
                        this.$refs.attachedFileAdd.init()
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        popupParams1: {
            // eslint-disable-next-line no-unused-vars
            handler: async function (value) {
                const param1 = _.clone(value)
                await this.initData()
                console.log('popupParams1 DataContainder: ', param1)
                this.fileSearchList = []
                this.$refs.attachedFileAdd.init()
                if (_.isEmpty(param1)) return

                this.copyObjExist(this.parentParam1, param1)
                this.readOnly = param1.readOnly
                this.mode = param1.mode

                if (this.mode != 'dev') {
                    this.readOnlyDev = true
                } else {
                    this.readOnly = true
                    this.readOnlyDev = false
                }

                //사용자 정보 조회 ---------------------------------------------------------
                // this.insDtm_format = _.isEmpty(this.formSearchParams.insDtm)
                //     ? ''
                //     : moment(this.formSearchParams.insDtm, 'YYYYMMDDHHmmss').format(
                //           'YYYY-MM-DD HH:mm:ss'
                //       )
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        // eslint-disable-next-line no-unused-vars
        async saveAction1(val, oldVal) {
            if (val == true) {
                //console.log('saveAction1: ', val, oldVal)
                const chk1 = await this.validationCheck()
                if (chk1) {
                    if (this.mode == 'new') {
                        await this.saveData()
                    } else if (this.mode == 'req') {
                        await this.saveDataUpdateReq()
                    } else if (this.mode == 'dev') {
                        await this.saveDataUpdateDev()
                    }

                    await this.initData()
                    this.fileSearchList = []
                    this.$refs.attachedFileAdd.init()

                    //저장후 팝업창을 닫고 호출창에 반환
                    await this.defaultAssign_({
                        key: 'popupConfirm',
                        value: true,
                    })
                    return
                } else {
                    console.log('validation false')
                }

                //에러든 정상종료든 완료되면 flag처리
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: true,
                })

                //temp 임시로 두개의 saveAction 이 있다고 간주
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: true,
                })
            }
        },
    },
}
</script>
