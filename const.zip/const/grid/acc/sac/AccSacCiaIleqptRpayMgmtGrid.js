'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: 'fixYn',
        dataType: ValueType.TEXT,
        visible: false,
    },

    {
        fieldName: 'fixYnNm',
        editable: false,
        header: { text: '처리상태' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'orgNm2',
        editable: false,
        header: { text: '담당' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'orgNm3',
        editable: false,
        header: { text: '영업팀' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'orgNm4',
        editable: false,
        header: { text: '영업PT' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accPlc',
        editable: false,
        header: { text: '정산처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accPlcNm',
        editable: false,
        header: { text: '정산처명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'salePlc',
        editable: false,
        header: { text: '판매처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'salePlcNm',
        editable: false,
        header: { text: '판매처명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'dealCoCl1Nm',
        editable: false,
        header: { text: '거래처구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'saleDtlTypNm',
        editable: false,
        header: { text: '판매유형' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'saleStatNm',
        editable: false,
        header: { text: '판매상태' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeyAgencyCd',
        editable: false,
        header: { text: 'D코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeyAgencyNm',
        editable: false,
        header: { text: '대리점명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeySubCd',
        editable: false,
        header: { text: '서브코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeySubNm',
        editable: false,
        header: { text: '서브점명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeyChannelCd',
        editable: false,
        header: { text: '채널코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'bizProcDt',
        editable: false,
        header: { text: '업무처리일' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'pntyClNm',
        editable: false,
        header: { text: '패널티구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'svcMgmtNum',
        editable: false,
        header: { text: '서비스관리번호' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'barCdNum',
        editable: false,
        header: { text: '계약서번호' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ciaInsptClCd',
        editable: false,
        header: { text: 'CIA심사구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ciaInsptObjNm',
        editable: false,
        header: { text: 'CIA심사대상' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ciaInsptRsnNm',
        editable: false,
        header: { text: '미비사유' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'lastInsptRsltNm',
        editable: false,
        header: { text: '최종심사결과' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'operId',
        editable: false,
        header: { text: '업무처리자' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'operNm',
        editable: false,
        header: { text: '업무처리자명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'backAmt',
        editable: false,
        header: { text: '환수금액' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'backYn',
        readOnly: false,
        header: { text: '환수적용' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'rmks',
        readOnly: false,
        header: { text: '비고' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'modUserId',
        editable: false,
        header: { text: '처리자ID' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'modUserNm',
        editable: false,
        header: { text: '처리자' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'modDtm',
        editable: false,
        header: { text: '처리일시' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd HH:mm:ss',
        columnDatetimeFormat: 'yyyy-MM-dd HH:mm:ss',
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {
    accSacCiaIleqptRpayMgmtGridList: {
        gridList: [
            {
                fixYn: 'Y',
                backAmt: 1020202,
                backYn: 'Y',
                rmks: '비고',
                modUserId: '홍길동',
                modDtm: '19820102',
                barCdNum: '102938',
                bizProcDt: '19200304 11:22:33',
                accPlcNm: '바나나1',
            },
            {
                fixYn: 'Y',
                backAmt: 1020202,
                backYn: 'N',
                rmks: '',
                modUserId: '홍길동',
                modDtm: '19820102',
                barCdNum: '102938',
                bizProcDt: '19200304 11:22:33',
                accPlcNm: 'n 이면서 비고없음',
                ciaInsptClCd: '12341234',
            },
            {
                fixYn: 'N',
                backAmt: 1020202,
                backYn: 'Y',
                rmks: '비고',
                modUserId: '홍길동',
                modDtm: '19820102',
                barCdNum: '102938',
                bizProcDt: '19200304 11:22:33',
                accPlcNm: '바나나3',
            },
            {
                fixYn: 'N',
                backAmt: 1020202,
                backYn: 'Y',
                rmks: '비고',
                modUserId: '홍길동',
                modDtm: '19820102',
                barCdNum: '102938',
                bizProcDt: '19200304 11:22:33',
                accPlcNm: '바나나4',
            },
        ],
        pagingDto: {
            pageSize: 15,
            pageNum: 1,
            totalPageCnt: 5,
            totalDataCnt: 70,
        },
    },
}

export { GRID_HEADER, MOCK_DATA }
