<!-----------------------------------------------
 * 업무그룹명: File Input 컴포넌트
 * 서브업무명: File Input 공통함수
 * 설명: File Input 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.03.29
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div>
        <span v-if="labelName" class="itemtit" :class="labelClass">
            <span v-if="eRequired" class="emph_txt">* </span>
            {{ labelName }}
        </span>
        <span class="iteminput" :class="eClass">
            <v-file-input
                ref="fileInput"
                v-model="dValue"
                dense
                outlined
                :prepend-icon="prependIcon"
                :label="label"
                :placeholder="placeholder"
                :disabled="disabled"
                :multiple="multiple"
                :rules="rules"
                :style="cSize"
                :class="fileClass"
                :accept="cAccept"
                :show-size="showSize"
                :truncate-length="truncateLength"
                :hide-input="hideInput"
                :full-width="fullWidth"
                :clearable="clearable"
                :chips="chips"
                :loading="loading"
                :loader-height="loaderHeight"
                @click="emitClick"
                @change="emitChange"
            >
                <template v-slot:append>
                    <slot name="append">
                        <v-btn
                            plain
                            class="btn_ty_search"
                            @click="emitAppendIconClick"
                        >
                        </v-btn>
                    </slot>
                </template>
            </v-file-input>
        </span>
    </div>
</template>

<script>
import _ from 'lodash'
export default {
    inheritAttrs: false,
    name: 'TCComFileInput',
    components: {},
    props: {
        // v-model
        value: { required: false },
        // label
        label: { type: String, default: '', required: false },
        // placeholder 제어
        placeholder: { type: String, default: '', required: false },
        // 넓이
        size: { type: Number, default: null, required: false },
        // disabled
        disabled: { type: Boolean, default: false, required: false },
        // multiple
        multiple: { type: Boolean, default: false, required: false },
        // 파일 사이즈 Show 여부
        showSize: { type: Boolean, default: false, required: false },
        // 텍스트박스 명
        labelName: { type: String, default: '', required: false },
        // 필수입력여부
        eRequired: { type: Boolean, default: false, required: false },
        // Span CSS Class
        eClass: { type: String, default: '', required: false },
        // File Input CSS Class
        fileClass: { type: String, default: 'search-btn', required: false },
        // CSS Label Class
        labelClass: { type: String, default: '', required: false },
        // Icon 정렬
        iconAlign: { type: String, default: 'right', required: false },
        // 함수, 부울 및 문자열의 혼합 배열을 사용할 수 있습니다.
        // 함수는 입력값을 인수로 전달하며 true/false 또는 오류 메시지를 포함하는 문자열을 반환해야 합니다.
        // 함수가 false를 반환하거나(또는 배열의 모든 값에 포함됨) 문자열인 경우 입력 필드가 오류 상태가 됩니다.
        rules: { required: false },
        // 특정 미디어 형식/파일 유형 설정
        accept: {
            type: String,
            default: '',
            required: false,
        },
        // 잘리기 전의 파일 이름 길이
        truncateLength: {
            type: [Number, String],
            default: 22,
            required: false,
        },
        // Inupt Hide 여부 설정
        hideInput: { type: Boolean, default: false, required: false },
        // 앞에 아이콘 설정
        prependIcon: { type: String, default: '', required: false },
        // 입력유형을 전체 너비로 지정
        fullWidth: { type: Boolean, default: false, required: false },
        // 입력지우기 기능 추가
        clearable: { type: Boolean, default: true, required: false },
        // 선택 항목 표시를 칩으로 변경여부
        chips: { type: Boolean, default: false, required: false },
        // 로딩 표시 여부
        loading: { type: Boolean, default: false, required: false },
        // 로더 높이
        loaderHeight: {
            type: [Number, String],
            default: null,
            required: false,
        },
        // auth
        objAuth: { type: Object, default: () => {}, required: false },
    },
    data() {
        return {
            dValue: null,
        }
    },
    computed: {
        cSize() {
            let res = 'width:auto;'
            if (!_.isEmpty(this.size)) {
                res = 'width:' + this.size + '%;'
            }
            return res
        },
        cAccept() {
            let res =
                '.xls, .xlsx, .ppt, .pptx, .doc, .docx, .pdf, .txt, .git, image/png, image/jpeg, image/bmp'
            if (!_.isEmpty(this.accept)) {
                res = this.accept
            }
            return res
        },
    },
    watch: {
        value: function () {
            this.dValue = this.value
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.dValue = this.value
        },
        emitInput(value) {
            this.$emit('input', value)
        },
        emitClick(ev) {
            this.$emit('click', ev)
        },
        emitChange(value) {
            this.emitInput(value)
            this.$emit('change', value)
        },
        emitAppendIconClick() {
            this.$refs.fileInput.$el.querySelector('input').value = ''
            this.$refs.fileInput.$el.querySelector('input').click()
            this.$emit('appendIconClick')
        },
        fileInputClick() {
            this.$refs.fileInput.$el.querySelector('input').click()
        },
        clearFileInputValue() {
            // this.dValue = this.multiple ? [] : null
            this.$refs.fileInput.$refs.input.value = null
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
