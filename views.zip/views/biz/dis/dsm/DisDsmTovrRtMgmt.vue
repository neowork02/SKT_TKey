<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고관리현황
 * 서브업무명: 재고회전률관리[DISDSM17000] → 장기재고현황(명칭변경)
 * 설명: 장기재고현황을 조회한다.
 * 작성자: P179229
 * 작성일: 2022.04.05
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>장기재고현황</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="기준일자"
                        calType="D"
                        :eRequired="true"
                        v-model="setDate"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="this.hldPlcData"
                        labelName="상품구분"
                        :eRequired="true"
                        v-model="reqParam.prodClCd"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.orgNm"
                        :codeVal.sync="reqParam.orgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :eRequired="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchOrgForm"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.dealcoNm"
                        :codeVal.sync="reqParam.dealcoCd"
                        labelName="보유처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchDealcosForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="모델"
                        @enterKey="onProdsEnterKey"
                        @appendIconClick="onProdsIconClick"
                        @input="onProdInput"
                        :objAuth="objAuth"
                        v-model="reqParam.prodNm"
                        :codeVal="reqParam.prodCd"
                        :disabledAfter="true"
                    >
                    </TCComInputSearchText>
                    <BasBcoProdsPopup
                        v-if="basBcoProdsShow === true"
                        :dialogShow.sync="basBcoProdsShow"
                        :parentParam="searchProdForm"
                        :rows="resultProdsRows"
                        @confirm="onProdsReturnData"
                    />
                </div>
                <div class="formitem div4_6"></div>
            </div>
        </div>
        <!-- // Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="장기재고현황 내역"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            >
                <template #gridBtnArea>
                    <TCComButton
                        :Vuetify="false"
                        eClass="btn_noline btn_ty04"
                        eAttr="ico_exeldown"
                        labelName="상세다운로드"
                        :objAuth="objAuth"
                        @click="onClickDownloadDtl"
                    />
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisDsmTovrRtMgmts"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <!-- //gridWrap -->
        <!-- popup -->
        <DisDsmTovrRtDtlPopup
            v-if="showDisDsmTovrRtDtl === true"
            ref="popup"
            :dialogShow.sync="showDisDsmTovrRtDtl"
            :dtlData.sync="dtlParam"
        />
        <!-- //popup -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import {
    DisDsmTovrRtMgmtGRID_HEADER,
    DisDsmTovrRtMgmtGRID_LAYOUT,
} from '@/const/grid/dis/dsm/disDsmTovrRtMgmtHeader'
import disDsmTovrRtMgmtApi from '@/api/biz/dis/dsm/disDsmTovrRtMgmt'
import attachedFileApi from '@/api/common/attachedFile'
import DisDsmTovrRtDtlPopup from './DisDsmTovrRtDtlPopup'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-전체조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-전체조직==================
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================
import moment from 'moment'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'disDsmTovrRtMgmt',
    mixins: [CommonMixin],
    components: {
        DisDsmTovrRtDtlPopup,
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
        BasBcoProdsPopup,
    },
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            indicatorOpt: { sort: 'ASC' },
            codeIDView: true,
            codeIDViewVal: '',
            objAuth: {},
            view: DisDsmTovrRtMgmtGRID_HEADER,
            showDisDsmTovrRtDtl: false,
            //====================내부조직팝업(권한)팝업관련====================
            orgDisabled: false,
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchOrgForm: {
                orgCd: '', // 조직id
                orgNm: '', // 조직명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처-전체조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchDealcosForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
            },
            resultDealcoRows: [],
            //====================//내부거래처-전체조직==================
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            searchProdForm: {
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
                prodClCd: '', //상품구분
                sktOperYn: '', //skt운영여부
                useYn: '', //사용여부
            },
            //====================//상품팝업관련==================
            hldPlcData: [
                {
                    commCdVal: '1',
                    commCdValNm: '단말기',
                },
                {
                    commCdVal: '2',
                    commCdValNm: 'USIM',
                },
            ],
            reqParam: {
                strdDt: '', //기준일자
                orgCd: '', //조직id
                orgNm: '', //조직명
                orgLvl: '', //조직level
                orgCdLvl0: '', //레벨0조직코드
                dealcoCd: '', // 보유처
                dealcoNm: '', // 보유처명
                prodCd: '', // 모델코드
                prodNm: '', // 모델명
                repProdYn: '', // 대표모델여부
                prodClCd: '1', //상품구분
            },
            serchParam: {},
            dtlParam: {},
            rowCnt: 15,
        }
    },
    computed: {
        setDate: {
            get() {
                return this.reqParam.strdDt
            },
            set(val) {
                this.reqParam.strdDt = val
                this.searchDealcosForm.basDay = CommonUtil.getDayFormat(
                    val,
                    'YYYYMMDD'
                )
                this.searchOrgForm.basMth = CommonUtil.getDayFormat(
                    val,
                    'YYYYMM'
                )
                return val
            },
        },
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(true, false, false)
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.setColumnLayout(DisDsmTovrRtMgmtGRID_LAYOUT)
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked
        this.init()
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.strdDt = moment(new Date())
                .subtract(1, 'days')
                .format('YYYY-MM-DD') // 기준일자
            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLvl'] = this.orgInfo['orgLvl']
                this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.reqParam['dealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['dealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam')
            this.init()
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/disDsmTovrRtMgmtExcelList',
                this.searchForm
            )
        },
        //상세엑셀다운로드
        onClickDownloadDtl() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/disDsmTovrRtMgmtDtlExcelList',
                this.searchForm
            )
        },
        //리스트 조회
        searchBtn: function () {
            if (_.isEmpty(this.reqParam.strdDt)) {
                this.showTcComAlert('기준일자를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 입력해 주십시오.')
                return false
            }
            this.searchForm = { ...this.reqParam }
            this.searchForm.strdDt = CommonUtil.replaceDash(
                this.searchForm.strdDt
            )
            //첫 조회시 표시할 행의 갯수
            this.searchForm.pageSize = this.rowCnt
            this.searchForm.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getDisDsmTovrRtMgmts(this.searchForm.pageNum)
        },
        getDisDsmTovrRtMgmts(page) {
            this.searchForm.pageNum = page
            disDsmTovrRtMgmtApi
                .getDisDsmTovrRtMgmt(this.searchForm)
                .then((res) => {
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator(
                        res.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(res.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                })
        },
        onCellDblClicked(grid, clickData) {
            if (clickData?.dataRow >= 0) {
                const cellData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                if (
                    clickData.column != 'dealcoCd' &&
                    clickData.column != 'prodCd' &&
                    clickData.column != 'prodClCd'
                ) {
                    this.dtlParam = { ...cellData }
                    this.dtlParam.strdDt = CommonUtil.replaceDash(
                        this.reqParam.strdDt
                    )
                    this.dtlParam.orgCd = this.reqParam.orgCd
                    this.dtlParam.orgLvl = this.reqParam.orgLvl
                    this.dtlParam.orgCdLvl0 = this.reqParam.orgCdLvl0
                    this.dtlParam.repProdYn = 'N'
                    this.showDisDsmTovrRtDtl = true
                }
            }
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchOrgForm.orgCd = this.reqParam.orgCd
            this.searchOrgForm.orgNm = this.reqParam.orgNm
            this.searchOrgForm.orgLvl = this.reqParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchOrgForm)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                        this.reqParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
            this.reqParam.orgCdLvl0 = ''
            this.reqParam.dealcoCd = ''
            this.reqParam.dealcoNm = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            this.reqParam.orgCd = _.get(retrunData, 'orgCd')
            this.reqParam.orgNm = _.get(retrunData, 'orgNm')
            this.reqParam.orgLvl = _.get(retrunData, 'orgLvl')
            this.reqParam.orgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
            this.reqParam.dealcoCd = ''
            this.reqParam.dealcoNm = ''
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcosForm)
                .then((res) => {
                    // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.dealcoCd = _.get(res[0], 'dealcoCd')
                        this.reqParam.dealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultDealcoRows = res
                        this.showBasBcoDealcos = true
                    }
                })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            this.searchDealcosForm.orgCd = this.reqParam.orgCd
            this.searchDealcosForm.orgNm = this.reqParam.orgNm
            this.searchDealcosForm.orgLvl = this.reqParam.orgLvl
            this.searchDealcosForm.dealcoCd = this.reqParam.dealcoCd
            this.searchDealcosForm.dealcoNm = this.reqParam.dealcoNm
            // 팝업오픈
            this.showBasBcoDealcos = true
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            this.searchDealcosForm.orgCd = this.reqParam.orgCd
            this.searchDealcosForm.orgNm = this.reqParam.orgNm
            this.searchDealcosForm.orgLvl = this.reqParam.orgLvl
            this.searchDealcosForm.dealcoCd = this.reqParam.dealcoCd
            this.searchDealcosForm.dealcoNm = this.reqParam.dealcoNm
            if (_.isEmpty(this.reqParam.dealcoNm)) {
                // 팝업오픈
                this.showBasBcoDealcos = true
            } else {
                // 내부거래처-전체조직 정보 조회
                this.getDealcosList()
            }
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.reqParam.dealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            this.reqParam.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-전체조직팝업관련 methods ================================
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                if (res.length === 1) {
                    this.reqParam.prodCd = _.get(res[0], 'prodCd')
                    this.reqParam.prodNm = _.get(res[0], 'prodNm')
                    this.reqParam.repProdYn = _.get(res[0], 'repProdYn')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            this.searchProdForm['prodCd'] = this.reqParam['prodCd']
            this.searchProdForm['prodNm'] = this.reqParam['prodNm']
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            this.basBcoProdsShow = true
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            this.searchProdForm['prodCd'] = this.reqParam['prodCd']
            this.searchProdForm['prodNm'] = this.reqParam['prodNm']
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            if (_.isEmpty(this.reqParam.prodNm)) {
                // 팝업오픈
                this.basBcoProdsShow = true
            } else {
                // 상품팝업 정보 조회
                this.getProdsList()
            }
        },
        // 상품 TextField Input 이벤트 처리
        onProdInput() {
            // 입력되는 값이 있으면 상품 정보 초기화
            this.reqParam.prodCd = ''
            this.reqParam.repProdYn = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            this.reqParam.prodCd = _.get(retrunData, 'prodCd')
            this.reqParam.prodNm = _.get(retrunData, 'prodNm')
            this.reqParam.repProdYn = _.get(retrunData, 'repProdYn')
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
