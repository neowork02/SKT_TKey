<template>
    <div class="content">
        <h1>정산파일업로드</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onUploadClick"
                >
                    업로드
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearchClick"
                >
                    조회
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5_1">
                    <TCComComboBox
                        labelName="업로드"
                        v-model="searchParam.templetCd"
                        :itemList="templetList"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div3">
                    <TCComDatePicker
                        calType="M"
                        v-model="calYearMonth"
                        labelName="정산년월"
                        :eRequired="true"
                    ></TCComDatePicker>
                </div>
                <div class="formitem div3">
                    <TCComInput
                        v-model="searchParam.titleNm"
                        labelName="제목"
                        @enterKey="onSearchClick"
                    ></TCComInput>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="admfileUploadGridHeader"
                ref="admfileUploadGridHeader"
                gridTitle="목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="false"
            />
            <TCRealGrid
                id="admfileUploadGrid"
                ref="admfileUploadGrid"
                :fields="fileUploadHeader.fields"
                :columns="fileUploadHeader.columns"
                :editable="true"
                :updatable="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getFileUploadList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="onChgRowCnt"
            />
            <BasAdmInfsAgencyDownDtlPopup
                v-if="showBasAdmInfsAgencyDownDtl"
                :dialogShow.sync="showBasAdmInfsAgencyDownDtl"
                :parentParam="selectedGridRow"
            />
            <BasAdmInfsFileUploadPopup
                v-if="showBasAdmInfsFileUpload"
                :dialogShow.sync="showBasAdmInfsFileUpload"
                :parentParam="searchParam"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil'
import { FILE_UPLOAD_HEADER } from '@/const/grid/bas/adm/basAdmInfsFileUploadHeader'
import basAdmInfsFileUploadApi from '@/api/biz/bas/adm/basAdmInfsFileUploadApi'
import commonApi from '@/api/common/commonCode'
import CommonMixin from '@/mixins'
// import _ from 'lodash'

export default {
    name: 'BasAdmInfsFileUploadList',
    components: {
        BasAdmInfsAgencyDownDtlPopup: () =>
            import('./BasAdmInfsAgencyDownDtlPopup'),
        BasAdmInfsFileUploadPopup: () => import('./BasAdmInfsFileUploadPopup'),
    },
    mixins: [CommonMixin],

    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            fileUploadHeader: FILE_UPLOAD_HEADER,
            rowCnt: 15,
            //각각 엘리먼트 컴포넌트 v-model
            searchParam: {
                templetCd: '', // 업로드 구분
                calYearMonth: '', // 정산년월
                titleNm: '', // 제목
                pageNum: 1,
                pageSize: 15,
            },
            calYearMonth: '',
            templetList: [],
            showBasAdmInfsAgencyDownDtl: false,
            selectedGridRow: {},
            showBasAdmInfsFileUpload: false,
        }
    },

    watch: {},

    created() {
        this.init()
    },

    mounted() {
        this.gridObj = this.$refs.admfileUploadGrid
        this.gridHeaderObj = this.$refs.admileUploadGridHeader
        this.gridObj.setGridState(true, false, false, false)
        this.setBaseData()
        this.setGridEvent()
    },

    methods: {
        init: function () {
            this.gridData = this.gridSetData()
            // 정산년월
            this.calYearMonth = CommonUtil.getCurrentMonth('YYYY-MM')
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        async setBaseData() {
            this.templetList = await this.getCommCodeList('CIP_TEMPLET_CD')
        },

        setGridEvent() {
            this.gridObj.gridView.onCellClicked = (grid, clickData) => {
                console.log('onCellClicked: ', clickData)
                const column = clickData.column
                const dataRow = clickData.dataRow
                if (clickData.cellType === 'data') {
                    if (column === 'stateNm') {
                        this.selectedGridRow = grid
                            .getDataSource()
                            .getJsonRow(dataRow)
                        this.showBasAdmInfsAgencyDownDtl = true
                    }
                }
            }
        },

        // 페이지 표시 행의 수 변경처리
        onChgRowCnt(val) {
            this.rowCnt = val
        },

        // 조회 버튼 이벤트
        onSearchClick() {
            this.gridData.totalPage = 0
            this.getFileUploadList()
        },

        // 업로드 버튼
        onUploadClick() {
            this.showBasAdmInfsFileUpload = true
        },

        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        getFileUploadList(pageNum) {
            this.searchParam.calYearMonth = CommonUtil.replaceDash(
                this.calYearMonth
            )
            this.searchParam.pageNum = pageNum ?? 1
            this.searchParam.pageSize = this.rowCnt

            // 페이징 조회
            basAdmInfsFileUploadApi
                .getFileUploadList(this.searchParam)
                .then((result) => {
                    this.gridObj.dataProvider.setRows(result.gridList)
                    // 페이징 관련
                    // 순번(역순)이 필요한경우 계산하는 함수
                    this.gridObj.setGridIndicator(result.pagingDto)
                    // 초기화
                    this.gridData = this.gridSetData()
                    // 총페이지수
                    this.gridData.totalPage = result.pagingDto.totalPageCnt
                    // Grid Row 가져올때 페이지정보 Setting
                    this.gridHeaderObj.setPageCount(result.pagingDto)
                })
        },
    },
}
</script>
