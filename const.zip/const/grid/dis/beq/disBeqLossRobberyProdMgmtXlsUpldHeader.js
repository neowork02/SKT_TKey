import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'prchsDealcoCd',
            dataType: ValueType.TEXT, //출고처코드
        },
        {
            fieldName: 'prchsDealcoNm',
            dataType: ValueType.TEXT, //출고처명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'riskStCd',
            dataType: ValueType.TEXT, //Risk사유코드
        },
        {
            fieldName: 'riskStNm',
            dataType: ValueType.TEXT, //Risk사유
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT, //이동창고코드
        },
        {
            fieldName: 'inDealcoNm',
            dataType: ValueType.TEXT, //이동창고명
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //오류사항
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, //보유처코드
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT, //재고상태코드
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'outMgmtNo',
            dataType: ValueType.TEXT, //출고관리번호
        },
        {
            fieldName: 'outClCd',
            dataType: ValueType.TEXT, //출고구분코드
        },
        {
            fieldName: 'outDealcoCd',
            dataType: ValueType.TEXT, //출고처코드
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'riskLclCd',
            dataType: ValueType.TEXT, //RISK대분류코드
        },
        {
            fieldName: 'riskId',
            dataType: ValueType.TEXT, //RISK ID
        },
        {
            fieldName: 'fixCrdtAmt',
            dataType: ValueType.TEXT, //확정여신가
        },
        {
            fieldName: 'realPrchsPrc',
            dataType: ValueType.TEXT, //실매입금액
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT, //처리자ID
        },
    ],
    columns: [
        {
            name: 'prchsDealcoCd',
            fieldName: 'prchsDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'prchsDealcoNm',
            fieldName: 'prchsDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '유심모델코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '유심모델',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'riskStCd',
            fieldName: 'riskStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Risk사유코드',
                showTooltip: false,
            },
        },
        {
            name: 'riskStNm',
            fieldName: 'riskStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Risk사유',
                showTooltip: false,
            },
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동창고코드',
                showTooltip: false,
            },
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동창고',
                showTooltip: false,
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류사항',
                showTooltip: false,
            },
        },
    ],
}
