<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">내부거래처(거래종료확인)</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    labelName="조직"
                                    :eRequired="true"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    :itemList="codeYn"
                                    itemText="codeVal"
                                    itemValue="codeId"
                                    labelName="거래처그룹"
                                    :objAuth="objAuth"
                                    v-model="searchECDForm.dealcoGrpCd"
                                ></TCComComboBox>
                            </div>
                            <!-- // item 1-2 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    :itemList="codeYn"
                                    itemText="codeVal"
                                    itemValue="codeId"
                                    labelName="거래처구분"
                                    :objAuth="objAuth"
                                    v-model="searchECDForm.dealcoClCd1"
                                ></TCComComboBox>
                            </div>
                            <!-- // item 1-2 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    :itemList="codeYn"
                                    itemText="codeVal"
                                    itemValue="codeId"
                                    labelName="거래처유형"
                                    :objAuth="objAuth"
                                    v-model="searchECDForm.dealcoClCd2"
                                ></TCComComboBox>
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchECDForm.dealcoNm"
                                    labelName="거래처명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 2-2 -->
                            <!-- item 2-3 -->
                            <div class="formitem div4">
                                <TCComCheckBox
                                    labelName="판매정지,수납정지"
                                    :objAuth="objAuth"
                                    :itemList="chkData"
                                    :disabled="true"
                                    v-model="searchECDForm.dealEndYn"
                                ></TCComCheckBox>
                            </div>
                            <!-- //item 2-3 -->
                        </div>
                        <!-- //Search_line 2 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchECDForm.dealcoCd"
                                    labelName="거래처코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchECDForm.ukeyChannelCd"
                                    labelName="채널코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 2-2 -->
                            <!-- item 2-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchECDForm.basInMth"
                                    labelName="기준년월"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 2-3 -->
                            <!-- item 2-4 -->
                            <div class="formitem div4">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="eCDGridHeader"
                            ref="eCDGridHeader"
                            :gridObj="gridObj"
                        />
                        <TCRealGrid
                            id="eCDGrid"
                            ref="eCDGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { basBcoEndChkDealcoHeader } from '@/const/grid/bas/bco/basBcoEndChkDealcoHeader'
import basBcoEndChkDealcoApi from '@/api/biz/bas/bco/basBcoEndChkDealco'
import commonApi from '@/api/common/commonCode'
import CommonMixin from '@/mixins'

export default {
    name: 'basBcoEndChkDealcoPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            headerText: '',
            objAuth: {},
            view: basBcoEndChkDealcoHeader,
            codeYn: [
                {
                    codeId: '',
                    codeVal: '전체',
                },
                {
                    codeId: 'Y',
                    codeVal: 'Y',
                },
                {
                    codeId: 'N',
                    codeVal: 'N',
                },
            ],
            chkData: [
                {
                    codeId: '1',
                    codeNm: '',
                },
            ],
            content: '',
            gridObj: {},
            gridHeaderObj: {},
            searchECDForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '', // 거래처그룹
                dealcoClCd1: '', //
                dealcoClCd2: '', //
                ukeyChannelCd: '', // 채널코드
                orgLevel: '', //
                orgCd: '', //
                onlyAccDeaCoCd: '', // 정산
                onlyDisUse: '', //재고
                dealEndYn: '', // 거래상태
                basInMth: '', // 기준년월
            },
        }
    },

    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.eCDGrid
        this.gridHeaderObj = this.$refs.eCDGridHeader
        this.initGrid()
        //컬럼전체채우기
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchECDForm.prodCd =
                    value['prodCd'] == undefined ? '' : value['prodCd']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false)
            /*
            let rows = [
                {
                    dealcoCd: '57553',
                    dealcoNm: '역삼역점',
                },
                {
                    dealcoCd: '80473',
                    dealcoNm: '강남지점',
                },
            ]
            */
            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },
        getSvcProdList() {
            basBcoEndChkDealcoApi
                .getEndChkDealcoList(this.searchECDForm)
                .then((res) => {
                    console.log('getEndChkDealcoList : ', res)
                    this.gridObj.setRows(res)
                })
        },
        getEndChkDealco() {
            basBcoEndChkDealcoApi
                .getEndChkDealco(this.searchECDForm)
                .then((res) => {
                    console.log('getEndChkDealco : ', res)
                    this.gridObj.setRows(res)
                })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('거래처을 선택해주세요.', {
                    header: '거래처',
                    size: '500',
                    confirmLabel: 'OK',
                })

                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        onSearch() {
            this.getSvcProdList()
        },

        onEnterKey() {
            this.onSearch()
        },
    },
}
</script>
