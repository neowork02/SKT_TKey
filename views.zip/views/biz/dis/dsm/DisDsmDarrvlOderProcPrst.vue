<!-----------------------------------------------
 * 업무그룹명: 재고관리>바로도착Master관리
 * 서브업무명: 바로도착주문진행현황[DISDSM18100]
 * 설명: 바로도착주문진행현황을 조회한다.
 * 작성자: P179229
 * 작성일: 2022.04.12
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>바로도착주문진행현황</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="주문일자"
                        calType="DP"
                        v-model="setDate"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="주문번호"
                        :objAuth="this.objAuth"
                        v-model="reqParam.ordNum"
                        @enterKey="searchBtn"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="this.svcClData"
                        labelName="서비스유형"
                        v-model="reqParam.svcCl"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        @change="ckParam.procSt = []"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComMultiComboBox
                        v-model="ckParam.procSt"
                        :itemList="this.procStData"
                        labelName="진행상태"
                        :objAuth="objAuth"
                        :filterFunc="filterFunc"
                    ></TCComMultiComboBox>
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        labelName="방문구성원"
                        :objAuth="this.objAuth"
                        v-model="reqParam.dlvChrgr"
                        @enterKey="searchBtn"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4_6"></div>
            </div>
        </div>
        <!-- // Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="바로도착주문진행현황 내역"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisDsmDarrvlOderProcPrsts"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <!-- // gridWrap -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { DisDsmDarrvlOderProcPrstGRID_HEADER } from '@/const/grid/dis/dsm/disDsmDarrvlOderProcPrstHeader'
import disDsmDarrvlOderProcPrstApi from '@/api/biz/dis/dsm/disDsmDarrvlOderProcPrst'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'disDsmDarrvlOderProcPrst',
    mixins: [CommonMixin],
    components: {},
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            indicatorOpt: { sort: 'ASC' },
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
            codeIDView: true,
            codeIDViewVal: '',
            objAuth: {},
            view: DisDsmDarrvlOderProcPrstGRID_HEADER,
            svcClData: [
                {
                    commCdVal: '1',
                    commCdValNm: '바로도착',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '바로도착 행복배송',
                },
                {
                    commCdVal: '3',
                    commCdValNm: 'Unmanned',
                },
            ],
            procStData: [
                {
                    commCdVal: '201',
                    commCdValNm: '요청',
                    standard: '1',
                    unmanned: '',
                },
                {
                    commCdVal: '202',
                    commCdValNm: '접수',
                    standard: '1',
                    unmanned: '',
                },
                {
                    commCdVal: '211',
                    commCdValNm: '배송중',
                    standard: '1',
                    unmanned: '',
                },
                {
                    commCdVal: '213',
                    commCdValNm: '배송완료',
                    standard: '1',
                    unmanned: '',
                },
                {
                    commCdVal: '203',
                    commCdValNm: '주문취소',
                    standard: '1',
                    unmanned: '',
                },
                {
                    commCdVal: '214',
                    commCdValNm: '개통요청',
                    standard: '',
                    unmanned: '',
                },
                {
                    commCdVal: '215',
                    commCdValNm: '완료',
                    standard: '1',
                    unmanned: '',
                },
                {
                    commCdVal: '216',
                    commCdValNm: '고객취소',
                    standard: '1',
                    unmanned: '',
                },
            ],
            reqParam: {
                svcCl: '', //서비스유형
                procSt: '', //진행상태
                fromDt: '', //from일자
                toDt: '', // to일자
                ordNum: '', //주문번호
                dlvChrgr: '', //방문구성원
                orgCdLvl0: '', //레벨0조직코드
            },
            ckParam: {
                procSt: [],
            },
            serchParam: {},
            rowCnt: 15,
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.fromDt, this.reqParam.toDt]
            },
            set(val) {
                this.reqParam.fromDt = val[0]
                this.reqParam.toDt = val[1]
                return val
            },
        },
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(true, false, false)
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.init()
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.fromDt = moment(new Date()).format('YYYY-MM-01')
            this.reqParam.toDt = moment(new Date()).format('YYYY-MM-DD')
            this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam') // 초기화 함수
            this.init()
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dsm/disDsmDarrvlOderProcPrstExcelList',
                this.searchForm
            )
        },
        //리스트 조회
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            this.reqParam.procSt = ''
            if (this.ckParam.procSt.length > 0) {
                let procStList = []
                procStList.push(this.ckParam.procSt)
                if (this.ckParam.procSt.indexOf('211') > -1) {
                    procStList.push('210')
                    procStList.push('212')
                }
                this.reqParam.procStList = String(procStList)
                this.reqParam.procSt = 'Y'
            }
            this.searchForm = { ...this.reqParam }
            this.searchForm.fromDt = CommonUtil.replaceDash(
                this.searchForm.fromDt
            )
            this.searchForm.toDt = CommonUtil.replaceDash(this.searchForm.toDt)
            //첫 조회시 표시할 행의 갯수
            this.searchForm.pageSize = this.rowCnt
            this.searchForm.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getDisDsmDarrvlOderProcPrsts(this.searchForm.pageNum)
        },
        getDisDsmDarrvlOderProcPrsts(page) {
            this.searchForm.pageNum = page
            disDsmDarrvlOderProcPrstApi
                .getDisDsmDarrvlOderProcPrst(this.searchForm)
                .then((res) => {
                    //Get Row Data
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator(
                        res.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(res.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                })
        },
        filterFunc(items) {
            if (this.reqParam.svcCl == '1') {
                return items.filter((item) => item['standard'] === '1')
            } else if (this.reqParam.svcCl == '3') {
                return items.filter((item) => item['unmanned'] === '3')
            } else {
                return items
            }
        },
        isValidChk() {
            let validFromDt = CommonUtil.replaceDash(this.reqParam.fromDt)
            let validToDt = CommonUtil.replaceDash(this.reqParam.toDt)
            if (_.isEmpty(validFromDt)) {
                this.showTcComAlert('주문일자의 시작일(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(validToDt)) {
                this.showTcComAlert('주문일자의 종료일(을)를 입력해 주십시오.')
                return false
            }
            if (validFromDt.substr(0, 6) !== validToDt.substr(0, 6)) {
                this.showTcComAlert(
                    '시작일자와 종료일자를 동일한 월로 지정하세요.'
                )
                return false
            }
            if (validFromDt > validToDt) {
                this.showTcComAlert('주문일자의 시작일이 종료일보다 큽니다.')
                return false
            }
            return true
        },
    },
}
</script>
