<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1400px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">신규등록팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="searchParam.orgNm"
                                    :codeVal.sync="searchParam.orgCd"
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :eRequired="true"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchPopParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComComboBox
                                    :itemList="commUserGrpList"
                                    v-model="formSearchParams.userGrpCd"
                                    labelName="권한그룹"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :disabled="false"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="newPopGridHeader"
                            ref="newPopGridHeader"
                            :gridObj="gridObj"
                        />
                        <TCRealGrid
                            id="newPopGrid"
                            ref="newPopGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
//====================axios====================
import { P_HEADER } from '@/const/grid/bas/cmu/basSmsSaleChgMgmtHeader'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================axios====================
import commonApi from '@/api/common/commonCode'
import CommonMixin from '@/mixins'
import moment from 'moment'
import { SacCommon } from '@/views/biz/sac/js'

//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
import _ from 'lodash'
export default {
    name: 'PopupContainer',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
        // 멀티체크 여부
        multiple: { type: Boolean, default: false, required: false },
    },

    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: P_HEADER,
            selectedItem: '',
            dealcoRgstClList: [], // 내부거래처등록구분
            dealcoGubunList: [],
            orgDealcoGubunList: [],
            propsParam: {},
            searchParam: {
                orgLvl: '', //세션레벨
                orgCd: '', //조회조건orgCd
                orgNm: '',
                dealcoRgstClCd: '', // 내부거래처등록구분
                dealcoGrpCd: '', // 내부거래처그룹
                dealcoClCd1: '', // 내부거래처구분
                dealcoClCd2: '', //거래처유형
                //dealCd: '', // 내부거래처코드
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                dealcoNm: '', // 내부거래처명
                onlyAccDeaCoCd: '',
                onlyDisUse: '',
                dealEndYn: '', //거래종료
                basDay: '', //기준년월
                basDayTemp: '',
                reqYn: '', //선택여부
            },
            ckParam: {
                onlyAccDeaCoCd: [],
                dealEndYn: [], //거래종료
                dealcoRgstClCd: [], // 내부거래처등록구분
                dealcoGrpCd: [],
                dealcoClCd1: [],
            },
            commChgOrgDealcoPtn: [],
            chkData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '',
                },
            ],
            commUserGrpList: [],
            commUserGrpOriginList: [],
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchPopParam: {
                basMth: '', //예)202202, 2022-02 null이면 부모창현재월셋팅
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                vLevel: '', // 디스플레이제한레벨
                sLvlList: '', //선택가능레벨 '2,3' : as-is 와동일하게 쉼표로 나열
                //all: 'N', //전체검색여부 Y or null , N..
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            isDisabledDealEndYn: false,
            isDisabledOnlyAccDealCoCd: false,
        }
    },
    // async created() {
    //     this.gridData = this.GridSetData()
    //     this.init()
    // },
    async mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.newPopGrid
        this.gridHeaderObj = this.$refs.newPopGridHeader
        this.gridData = this.GridSetData()
        this.gridObj.setGridState(false, false, false, false)
        //체크바
        this.$refs.newPopGrid.gridView.setCheckBar({
            visible: true,
        })
        this.$refs.newPopGrid.gridView.checkBar.fieldName = 'chk'
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        //편집가능
        // this.initGrid()
        //컬럼전체채우기
        /*
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        */

        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentParam', value)
                this.propsParam = value
                this.commUserGrpList = value.commUserGrpList
                this.commUserGrpOriginList = value.commUserGrpOriginList
                this.formSearchParams = value.formSearchParams
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        async init() {
            // 2022.10.07 요구사항으로 거래처등록구분 추가
            this.dealcoRgstClList = await this.getCommCodeList(
                'DEALCO_RGST_CL_CD'
            )
            this.dealcoGubunList = await this.getCommCodeList('ZBAS_C_00240')
            this.orgDealcoGubunList = this.dealcoGubunList.slice()
            //const commDealCoClCd2Nm = await this.getCommCodeList('ZBAS_C_00110')`
            //this.gridData = this.gridSetData()
            this.gridData = this.GridSetData()
            if (!_.isEmpty(this.searchParam.searchDateModel)) {
                this.searchParam.searchDateModel = moment().format('YYYY-MM-DD')
            }

            if (this.rows.length > 0) {
                if ('Y' === String(this.ckParam.onlyAccDeaCoCd)) {
                    this.isDisabledOnlyAccDealCoCd = true
                }
            } else {
                if (this.searchParam.orgCd === this.orgInfo.orgCd) {
                    this.searchParam.orgNm = this.orgInfo.orgNm
                    this.searchParam.orgLvl = this.orgInfo.orgLvl
                }
            }
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수),
            return new CommonGrid(-1, -1, 10, 0, '')
        },
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj.setGridState(false, false, false, false)
            // this.gridObj.setRows(this.rows)
        },

        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },
        getEndChkDealco() {
            if (_.isEmpty(this.searchParam.orgCd)) {
                this.showTcComAlert('조직을 선택해주세요.')
                return
            }
            //##백앤드String으로 받게 되어있음
            // 2022.10.07 요구사항으로 거래처등록구분 추가
            this.searchParam.dealcoRgstClCd = String(
                this.ckParam.dealcoRgstClCd
            )
            //거래처그룹
            this.searchParam.dealcoGrpCd = String(this.ckParam.dealcoGrpCd)
            //거래처구분
            this.searchParam.dealcoClCd1 = String(this.ckParam.dealcoClCd1)

            //console.log(this.ckParam.onlyAccDeaCoCd)
            //정산처리여부
            this.searchParam.onlyAccDeaCoCd = String(
                this.ckParam.onlyAccDeaCoCd
            )
            //체크박스거래종료
            this.searchParam.dealEndYn = String(this.ckParam.dealEndYn)
            //##백앤드String으로 받게 되어있음

            let basDayTemp = CommonUtil.replaceDash(this.searchParam.basDayTemp)

            if ('' == basDayTemp) {
                let today = SacCommon.getToday()
                this.searchParam.basDay = CommonUtil.replaceDash(today)
            } else {
                if (basDayTemp.length == 6) {
                    let lastDay = SacCommon.uf_monthLastDay(basDayTemp)
                    this.searchParam.basDay = basDayTemp + lastDay
                } else if (this.searchParam.basDayTemp.length > 6) {
                    let today = SacCommon.getToday()
                    this.searchParam.basDay = CommonUtil.replaceDash(today)
                }
            }

            this.searchParam.searchDate = CommonUtil.replaceDash(
                this.searchParam.searchDateTemp
            )

            basBcoDealcosApi.getDealcosList(this.searchParam).then((res) => {
                console.log('getEndChkDealco : ', res)
                if (res.length > 0) {
                    for (let index = 0; index < res.length; index++) {
                        res[index].NO = index + 1
                    }
                }
                this.gridObj.setRows(res)
            })
        },

        onConfirm() {
            let jsonData
            const selectedRows = []
            if (this.multiple) {
                const checkedRows = this.gridObj.gridView.getCheckedRows(false)
                if (!checkedRows.length) {
                    this.showTcComAlert('거래처를 선택해주세요.')
                    return
                }
                checkedRows.forEach((item) => {
                    const row = this.gridObj.dataProvider.getJsonRow(item)
                    selectedRows.push(row)
                })
                jsonData = selectedRows
            } else {
                const current = this.gridObj.gridView.getCurrent()
                if (current.dataRow === -1) {
                    this.showTcComAlert('거래처를 선택해주세요.')
                    return
                }
                jsonData = this.gridObj.dataProvider.getJsonRow(current.dataRow)
            }

            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        onSearch() {
            this.getEndChkDealco()
        },

        onEnterKey() {
            this.onSearch()
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        setAuthOrgTreeParam() {
            this.searchPopParam.orgNm = this.searchParam.orgNm
            //기준년월에 따라 조직파라미터변경
            this.searchPopParam.basMth = CommonUtil.replaceDash(
                this.searchParam.basDayTemp
            )
        },
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchPopParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchParam.basMth = _.get(res[0], 'basMth')
                        this.searchParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchParam.orgNm = _.get(res[0], 'orgNm')
                        this.searchParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            this.setAuthOrgTreeParam()
            if (!_.isEmpty(this.searchParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showTcComAlert('내부조직팝업_(권한조직)명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.setAuthOrgTreeParam()
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchParam.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        filterDealcoGrpCd(items) {
            console.log('items:', items)
            return items.filter((items) => items['addInfo2'] === 'Y')
        },
        onChangeDealcoGrpCd() {
            this.dealcoGubunList = this.orgDealcoGubunList.filter((items) => {
                for (let idx in this.ckParam.dealcoGrpCd) {
                    let commCdVal = this.ckParam.dealcoGrpCd[idx]
                    if (commCdVal === items['addInfo1']) {
                        return true
                    }
                }
                return false
            })
        },
    },
}
</script>
