import { ValueType } from 'realgrid'

export const GRID_POP_HEADER = {
    fields: [
        {
            fieldName: 'sortNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'itemNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'swingAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'accAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'sortNm',
            fieldName: 'sortNm',
            type: 'data',
            styleName: 'left-column',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '구분',
            },
            mergeRule: {
                criteria: 'value',
            },
            width: '130',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'itemNm',
            fieldName: 'itemNm',
            type: 'data',
            styleName: 'left-column',
            styles: {
                textAlignment: 'left',
            },
            header: {
                text: '항목명',
            },
            width: '250',
        },
        {
            name: 'swingAmt',
            fieldName: 'swingAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing금액',
            },
            footer: {
                text: '합계',
                expression: 'sum',
                numberFormat: '#,###,###,##0',
            },
        },
        {
            name: 'accAmt',
            fieldName: 'accAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산금액',
            },
            footer: {
                text: '합계',
                expression: 'sum',
                numberFormat: '#,###,###,##0',
            },
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '확정금액',
            },
            footer: {
                text: '합계',
                expression: 'sum',
                numberFormat: '#,###,###,##0',
            },
        },
    ],
}

export const GRID_POP_HEADER2 = {
    fields: [
        {
            fieldName: 'sortNmSub',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'itemNmSub',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'swingAmtSub',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'accAmtSub',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totAmtSub',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'sortNmSub',
            fieldName: 'sortNmSub',
            type: 'data',
            styleName: 'left-column',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구분',
            },
            mergeRule: {
                criteria: 'value',
            },
            width: '130',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'itemNmSub',
            fieldName: 'itemNmSub',
            type: 'data',
            styleName: 'left-column',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '항목명',
            },
            width: '250',
        },
        {
            name: 'swingAmtSub',
            fieldName: 'swingAmtSub',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing금액',
                showTooltip: false,
            },
            footer: {
                text: '합계',
                expression: 'sum',
                numberFormat: '#,###,###,##0',
            },
        },
        {
            name: 'accAmtSub',
            fieldName: 'accAmtSub',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산금액',
                showTooltip: false,
            },
            footer: {
                text: '합계',
                expression: 'sum',
                numberFormat: '#,###,###,##0',
            },
        },
        {
            name: 'totAmtSub',
            fieldName: 'totAmtSub',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '확정금액',
            },
            footer: {
                text: '합계',
                expression: 'sum',
                numberFormat: '#,###,###,##0',
            },
        },
    ],
}
