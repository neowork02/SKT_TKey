<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 정산지원게시판 MAIN
 * 소스 ID : AccSacAcctBltnBrd.vue
 * 설명: 정산완료 내역에 대해 각 판매점에서 정산담당에게 문의하는 기능
 * 작성자: 고용진
 * 작성일: 2022.04.05
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- 업무명 -->
        <h1>정산지원게시판</h1>

        <!-- 사용버튼 -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    @click="screenInit()"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    @click="searchBoard()"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    @click="newBoard()"
                    >신규</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="this.objAuth"
                    :disabled="isDeleteBtn"
                    @click="deleteBoard()"
                    >삭제</TCComButton
                >
            </li>
        </ul>

        <!-- 조회 Key 입력 구성 -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchKeyData.searchOrgNm"
                        :codeVal.sync="searchKeyData.searchOrgCd"
                        labelName="조직"
                        placeholder=""
                        :eRequired="true"
                        :disabled="orgDisabled"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="조회기간"
                        calType="DP"
                        v-model="inputDate"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="순번"
                        :objAuth="this.objAuth"
                        v-model="searchKeyData.searchBoardNo"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="P코드"
                        :objAuth="this.objAuth"
                        v-model="searchKeyData.searchSktChnlCd"
                    >
                    </TCComInput>
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchKeyData.searchAccDealcoNm"
                        :codeVal.sync="searchKeyData.searchAccDealcoCd"
                        labelName="정산처"
                        :objAuth="objAuth"
                        :disabled="accDealcoCdDisabled"
                        :searchIconDisabled="searchIconDisabled"
                        :disabledAfter="true"
                        @appendIconClick="onDealcoIconClick"
                        @enterKey="onDealcoEnterKey"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchAccDealcoParams"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                    <!-- <TCComComboBox
                        labelName="정산처명"
                        v-if="addDealco.length"
                        :autocomplete="true"
                        :itemList="addDealco"
                        itemText="dealcoNm"
                        itemValue="dealcoCd"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText=""
                        blankItemValue=""
                        :disabled="accDealcoNmDisabled"
                        @change="accDealcoChange"
                        v-model="searchKeyData.searchAccDealcoNm"
                    ></TCComComboBox>
                    <TCComInput
                        v-else
                        labelName="정산처명"
                        :objAuth="objAuth"
                        :disabled="accDealcoNmDisabled"
                        v-model="searchKeyData.searchAccDealcoNm"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="정산처코드"
                        :objAuth="this.objAuth"
                        :disabled="accDealcoCdDisabled"
                        v-model="searchKeyData.searchAccDealcoCd"
                    >
                    </TCComInput> -->
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZACC_C_00200"
                        labelName="처리상태"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-model="searchKeyData.searchProcStCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZACC_C_00220"
                        labelName="문의유형"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-model="searchKeyData.SearchQueTypCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4"></div>
            </div>
        </div>

        <!-- GRID정의 -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="grdBoardListHeader"
                ref="grdBboardListHeader"
                gridTitle="게시판 목록"
                :gridObj="gridObj"
                :isExceldown="true"
                @excelDownBtn="downloadBoardList"
            />
            <TCRealGrid
                id="grdBoardList"
                ref="grdBoardList"
                :styles="gridStyle"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div>

        <!-- 질문등록 팝업 -->
        <inqRgstPopup
            v-if="inqShowPopupOrg === true"
            ref="popup"
            :dialogShow.sync="inqShowPopupOrg"
            :popupParams.sync="popupInqParams"
            @close="searchBoard"
        />
        <!-- 답변등록 팝업 -->
        <answRgstPopup
            v-if="answShowPopupOrg === true"
            ref="popup"
            :dialogShow.sync="answShowPopupOrg"
            :popupParams.sync="popupAnswParams"
            @close="searchBoard"
        />
        <!-- 비밀번호 팝업 -->
        <passInputPopup
            v-if="passShowPopupOrg === true"
            ref="popup"
            :dialogShow.sync="passShowPopupOrg"
            @confirm="passCheck"
        />
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import moment from 'moment'
import _ from 'lodash'
import boardApi from '@/api/biz/acc/sac/AccSacAccBltnBrdApi'
import commonApi from '@/api/common/commonCode'
import { GRID_HEADER } from '@/const/grid/acc/sac/accSacAcctBltnBrdGrid'

//  질문등록 팝업, 답변등록 팝업, 비밀번호체크 팝업
import inqRgstPopup from '@/views/biz/acc/sac/AccSacAccBltnBrdInqRgst'
import answRgstPopup from '@/views/biz/acc/sac/AccSacAccBltnBrdAnswRgst'
import passInputPopup from '@/views/biz/acc/sac/AccSacAccBltnBrdPassPopup'

//  내부조직팝업(권한)
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//  내부조직팝업(권한)

//  내부거래처(권한조직)
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//  내부거래처(권한조직)

export default {
    name: 'Home',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        inqRgstPopup,
        answRgstPopup,
        passInputPopup,
        BasBcoDealcosPopup, //  내부거래처(권한조직)
    },
    data() {
        return {
            objAuth: {},
            addUserGrp: [
                {
                    addUserGrpCd: '',
                },
            ],
            addDealco: [],
            isDeleteBtn: true,
            list: [],
            listCount: 0,
            view: GRID_HEADER,
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
            inputDate: [],
            searchKeyData: {
                searchCoClOrgCd: '',
                searchOrgCd: '',
                searchOrgNm: '',
                searchFromDt: '',
                searchToDt: '',
                searchBoardNo: '',
                searchSktChnlCd: '',
                searchAccDealcoNm: '',
                searchAccDealcoCd: '',
                searchProcStCd: '',
                SearchQueTypCd: '',
                searchOrgLvl: '',
                searchAddDealCoYn: '',
                searchLoginId: '',
            },

            orgDisabled: false,
            accDealcoCdDisabled: false,
            accDealcoNmDisabled: false,
            searchIconDisabled: false,

            //  내부조직팝업(권한)팝업
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {},
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //  내부조직팝업(권한)팝업

            //  내부거래처(권한조직)
            basBcoDealcoShow: false,
            resultDealcoRows: [],
            searchAccDealcoParams: {
                basDay: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                dealcoCd: '',
                dealcoNm: '',
            },
            //  내부거래처(권한조직)

            // 추가사용자그룹, 추가거래처를 조회여부를 판단하기위한 용도
            addInfoSearchUserId: '',

            //  정산담당권한, admin권한, 전사조직 공지권한
            accAuthYn: 'N',
            adminAuthYn: 'N',
            allNoticYn: 'N',

            //  팝업
            savePassword: '',
            password: '',
            popupInqParams: {},
            popupAnswParams: {},
            inqShowPopupOrg: false,
            answShowPopupOrg: false,
            passShowPopupOrg: false,
        }
    },
    mounted() {
        //  그리드 초기화
        this.gridInit()

        //  추가사용자그룹
        this.getAddUserGrpList()

        // 추가거래처
        // this.getAddDealCoList()

        //  전사조직 공지권한 공통코드
        this.getAllNoticAuthCodeList()

        // 그리드 셀 클릭 팝업 이벤트
        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            this.grdListOnCellDblClick(clickData.dataRow)
        }
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            this.grdListOnCellClick(clickData.dataRow)
        }

        this.searchKeyData.searchOrgCd = this.orgInfo.orgCd
        this.searchKeyData.searchOrgNm = this.orgInfo.orgNm
        this.searchKeyData.searchOrgLvl = this.orgInfo.orgLvl

        if (!_.isEmpty(this.userInfo['dealcoCd'])) {
            this.searchKeyData.searchAccDealcoNm = this.userInfo.dealcoNm
            this.searchKeyData.searchAccDealcoCd = this.userInfo.dealcoCd
            this.accDealcoCdDisabled = true
            this.searchIconDisabled = false
        }
    },
    methods: {
        // 그리드 초기화
        gridInit: function () {
            this.gridObj = this.$refs.grdBoardList
            this.gridHeaderObj = this.$refs.gridHeader1

            this.gridObj.setGridState(false)
            this.gridObj.gridView.setRowIndicator({
                visible: true,
                headText: '번호',
            })
            this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        },
        // 화면초기화
        screenInit: function () {
            CommonUtil.clearPage(this, 'searchKeyData', this.gridObj)
            this.searchKeyData.searchOrgCd = this.orgInfo.orgCd
            this.searchKeyData.searchOrgNm = this.orgInfo.orgNm
            this.searchKeyData.searchOrgLvl = this.orgInfo.orgLvl

            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.orgDisabled = true
                this.accDealcoCdDisabled = true
                this.accDealcoNmDisabled = true
                this.searchKeyData.searchAccDealcoNm = this.userInfo.dealcoNm
                this.searchKeyData.searchAccDealcoCd = this.userInfo.dealcoCd
            }

            this.gridObj.gridView.orderBy([]) // 정렬 초기화
        },
        //  추가사용자그룹
        getAddUserGrpList: function () {
            //  회사구분조직코드, Login사용자ID
            this.searchKeyData.searchCoClOrgCd = this.orgInfo.orgCdLv10
            this.searchKeyData.searchLoginId = this.userInfo.userId
            // this.searchKeyData.searchLoginId = 'D139850306'

            boardApi
                .getAddUserGrpList(this.searchKeyData)
                .then((resultData) => {
                    this.addUserGrp = resultData

                    if (!_.isEmpty(resultData)) {
                        //  권한setting(정산담당, admin)
                        for (var i = 0; i < this.addUserGrp.length; i++) {
                            if (
                                this.addUserGrp[i].addUserGrpCd == '1000000074'
                            ) {
                                this.accAuthYn = 'Y'
                            }
                            if (this.addUserGrp[i].addUserGrpCd == 'P12') {
                                this.adminAuthYn = 'Y'
                            }
                        }
                    }
                })
        },
        //  추가거래처
        getAddDealCoList: function () {
            boardApi.getAddDealCoList(this.searchKeyData).then((resultData) => {
                this.addDealco = resultData
                if (_.isEmpty(this.addDealco)) {
                    this.addDealco = []
                }
            })
        },
        //  정산처명이 변경되었을 경우 정산처코드 Set
        accDealcoChange: function (v) {
            if (_.isEmpty(v)) {
                this.searchKeyData.searchAccDealcoCd = ''
            } else {
                const get = this.addDealco.filter((arr) => arr.dealcoCd == v)
                this.searchKeyData.searchAccDealcoCd = get[0].dealcoCd
            }
        },
        //  전사조직 공지권한  공통코드를 가져와 권한여부를 Set
        async getAllNoticAuthCodeList() {
            var allNoticAuthCodeList = []
            allNoticAuthCodeList = await commonApi.getCommonCodeListById(
                'ZBAS_C_00250'
            )
            for (var i in allNoticAuthCodeList) {
                if (
                    allNoticAuthCodeList[i].commCdVal == this.userInfo.userGrpCd
                ) {
                    this.allNoticYn = 'Y'
                    break
                }
            }
        },
        searchBoard: function () {
            //  조회기간 hyphen(-) 삭제
            if (
                !_.isEmpty(this.inputDate[0]) &&
                !_.isEmpty(this.inputDate[1])
            ) {
                this.searchKeyData.searchFromDt = this.inputDate[0].replace(
                    /-/g,
                    ''
                )
                this.searchKeyData.searchToDt = this.inputDate[1].replace(
                    /-/g,
                    ''
                )
            }

            //  추가거래처여부
            if (!_.isEmpty(this.addDealco.length)) {
                this.searchKeyData.searchAddDealCoYn = 'Y'
            }
            //  조회대상 입력 데이터 정합성체크
            if (_.isEmpty(this.searchKeyData.searchOrgCd)) {
                this.showTcComAlert('조직을 선택하십시오')
                return
            }
            //  조회API 호출
            boardApi.getBoardList(this.searchKeyData).then((resultData) => {
                this.list = resultData
                this.$refs.grdBoardList.setRows(this.list)
            })
        },
        //  질문상세 팝업
        grdListOnCellDblClick: function (pRow) {
            if (pRow == undefined) return

            // 선택한 Row
            const rowData = this.list[pRow]

            //  popup Open
            if (rowData.boardLvl == '1') {
                this.popupInqParams.boardNo = rowData.boardNo
                this.popupInqParams.newOpenYn = 'N'
                this.popupInqParams.orgCd = this.searchKeyData.searchOrgCd
                this.popupInqParams.orgNm = this.searchKeyData.searchOrgNm
                this.popupInqParams.orgLvl = this.searchKeyData.searchOrgLvl

                if (
                    this.userInfo.userGrpCd == '1000000074' ||
                    this.userInfo.userGrpCd == 'P12' ||
                    this.accAuthYn == 'Y' ||
                    this.adminAuthYn == 'Y' ||
                    _.isEmpty(rowData.inqPwdNo)
                ) {
                    //  질문등록 팝업 오픈
                    // this.popupInqParams.boardNo = rowData.boardNo
                    // this.popupInqParams.newOpenYn = 'N'
                    this.inqShowPopupOrg = true
                } else if (!_.isEmpty(rowData.inqPwdNo)) {
                    //  비밀번호 입력 팝업 오픈
                    this.password = ''
                    this.savePassword = rowData.inqPwdNo
                    // this.popupInqParams.boardNo = rowData.boardNo
                    // this.popupInqParams.newOpenYn = 'N'
                    this.passShowPopupOrg = true
                }
            } else {
                //  답변등록 팝업 오픈
                this.popupAnswParams.boardNo = rowData.boardNo
                this.popupAnswParams.newOpenYn = 'N'
                this.answShowPopupOrg = true
            }
        },
        //  삭제버튼 가능여부
        grdListOnCellClick: function (pRow) {
            if (pRow == undefined) return

            // 선택한 Row
            const rowData = this.list[pRow]

            //  Admin그룹, 게시작성자 일 경우 삭제가능
            if (
                this.userInfo.userGrpCd == 'P12' ||
                this.userInfo.userGrpCd == 'P13' ||
                this.adminAuthYn == 'Y' ||
                this.userInfo.userId == rowData.modUserId
            ) {
                this.isDeleteBtn = false
            } else {
                this.isDeleteBtn = true
            }
        },
        //  신규문의
        newBoard: function () {
            if (
                this.searchKeyData.searchOrgCd == 'O00000' &&
                this.allNoticYn == 'N'
            ) {
                this.showTcComAlert('조직을 선택하십시오.')
                return
            }

            this.popupInqParams.newOpenYn = 'Y'
            this.popupInqParams.accYm = moment(new Date()).format('YYYYMM')
            this.popupInqParams.orgCd = this.searchKeyData.searchOrgCd
            this.popupInqParams.orgNm = this.searchKeyData.searchOrgNm
            this.popupInqParams.orgLvl = this.searchKeyData.searchOrgLvl
            this.popupInqParams.accDealcoCd =
                this.searchKeyData.searchAccDealcoCd
            this.popupInqParams.accDealcoNm =
                this.searchKeyData.searchAccDealcoNm
            this.popupInqParams.accAuthYn = this.accAuthYn
            this.popupInqParams.adminAuthYn = this.adminAuthYn

            this.inqShowPopupOrg = true
        },
        deleteBoard: function () {
            //  선택된 Row가져오기
            const getCurrentIdx =
                this.$refs.grdBoardList.gridView.getCurrent().dataRow

            //  선택된 Row Data가져오기
            const rowData =
                this.$refs.grdBoardList.dataProvider.getJsonRow(getCurrentIdx)

            this.showTcComConfirm(
                '삭제하시겠습니까?\n등록된 답글이 있을 경우 같이 삭제됩니다.'
            ).then((confirm) => {
                if (confirm) {
                    boardApi.deleteBoardList(rowData).then((res) => {
                        if (res === 1) {
                            this.showTcComAlert('정상처리 되었습니다.')
                            this.searchBoard()
                        }
                    })
                }
            })
        },
        passCheck(retrunData) {
            //  입력한 비밀번호와 저장된 비밀번호 일치여부 체크
            if (this.savePassword == retrunData) {
                //  질문등록(상세) 팝업 오픈
                this.inqShowPopupOrg = true
            } else {
                this.showTcComAlert('비밀번호가 틀립니다.')
            }
        },
        //  엑셀다운로드
        downloadBoardList: function () {
            boardApi.downloadBoardList(this.searchKeyData)
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.searchKeyData.searchOrgCd
            this.searchParam.orgNm = this.searchKeyData.searchOrgNm
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchKeyData.searchOrgCd = _.get(res[0], 'orgCd')
                        this.searchKeyData.searchOrgNm = _.get(res[0], 'orgNm')
                        this.searchKeyData.searchOrgLvl = _.get(
                            res[0],
                            'orgLvl'
                        )
                    } else {
                        if (this.allNoticYn == 'Y') {
                            this.searchParam.all = 'Y'
                        }
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchKeyData.searchOrgNm)) {
                this.getAuthOrgTreeList()
            } else {
                if (this.allNoticYn == 'Y') {
                    this.searchParam.all = 'Y'
                }

                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchKeyData.searchOrgNm)) {
                this.showTcComAlert('조직명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchKeyData.searchOrgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchKeyData.searchOrgCd = _.get(retrunData, 'orgCd')
            this.searchKeyData.searchOrgNm = _.get(retrunData, 'orgNm')
            this.searchKeyData.searchOrgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================

        //===================== 내부거래처(권한조직)) methods ================================
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchAccDealcoParams)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.searchKeyData.searchAccDealcoCd = _.get(
                            res[0],
                            'dealcoCd'
                        )
                        this.searchKeyData.searchAccDealcoNm = _.get(
                            res[0],
                            'dealcoNm'
                        )

                        //  매장등록 사용자일 경우 돋보기 버튼을 클릭하면 팝업오픈(추가근무지조회)
                        if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                            this.basBcoDealcoShow = true
                        }
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        onDealcoIconClick() {
            this.resultDealcoRows = []
            if (_.isEmpty(this.searchKeyData.searchOrgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            this.searchAccDealcoParams.orgCd = this.searchKeyData.searchOrgCd
            this.searchAccDealcoParams.orgNm = this.searchKeyData.searchOrgNm
            this.searchAccDealcoParams.orgLvl = this.searchKeyData.searchOrgLvl
            this.searchAccDealcoParams.dealcoCd =
                this.searchKeyData.searchAccDealcoCd
            this.searchAccDealcoParams.dealcoNm =
                this.searchKeyData.searchAccDealcoNm
            this.searchAccDealcoParams.basDay = moment(new Date()).format(
                'YYYYMMDD'
            )

            // 내부거래처조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            this.resultDealcoRows = []
            if (_.isEmpty(this.searchKeyData.searchOrgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            if (_.isEmpty(this.searchKeyData.searchAccDealcoNm)) {
                this.showTcComAlert('정산처를 입력해주세요.')
                return
            }
            this.searchAccDealcoParams.orgCd = this.searchKeyData.searchOrgCd
            this.searchAccDealcoParams.orgNm = this.searchKeyData.searchOrgNm
            this.searchAccDealcoParams.orgLvl = this.searchKeyData.searchOrgLvl
            this.searchAccDealcoParams.dealcoCd =
                this.searchKeyData.searchAccDealcoCd
            this.searchAccDealcoParams.dealcoNm =
                this.searchKeyData.searchAccDealcoNm
            this.searchAccDealcoParams.basDay = moment(new Date()).format(
                'YYYYMMDD'
            )

            // 내부거래처조회
            this.getDealcosList()
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchKeyData.searchAccDealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchKeyData.searchAccDealcoCd = _.get(returnData, 'dealcoCd')
            this.searchKeyData.searchAccDealcoNm = _.get(returnData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================
    },
}
</script>
