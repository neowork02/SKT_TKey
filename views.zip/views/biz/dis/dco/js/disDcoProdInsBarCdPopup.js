export const Prod = {
    chk: '', // 체크여부
    serNum: '', //번호
    inoutSchdDt: '', //입고예정일
    prodCd: '', //모델
    prodNm: '', //모델명
    colorCd: '', // 색상
    colorNm: '', //색상명
    toSerNo: '', //종료일련번호
    badYn: '', //불량여부
    disStCd: '', //재고상태
    errDesc: '', //오류내용
    errorClCd: '', //오류내용
    reflYn: '', //반영여부
    prodClCd: '', //상품구분코드
    opDt: '', //처리일자
    opTm: '', //if처리일자
    rgstSeq: '', //등록순번
    inoutClCd: '', //입출고구분코드
    inoutPlcCd: '', //입출고처코드
    lastInoutClCd: '', //최종입출고구분코드
    lastInoutDtlClCd: '', //최종입출고상세구분코드
    sknRnpTypCd: '', //SKN수불유형코드
    sknOpClCd: '', //SKN처리구분코드
    updCnt: '', //수정횟수
}
