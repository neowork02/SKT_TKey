export default {
    namespaced: true,
    state: {
        _menuInfo: [], //사용자메뉴정보
        _currentMenuInfo: {}, //현재 메뉴ID
    },
    actions: {
        setMenuInfo({ commit }, menuInfo) {
            commit('SET_MENU_INFO', menuInfo)
        },
        setCurrentMenuInfo({ commit }, currentMenuInfo) {
            commit('SET_CURRENT_MENU_INFO', currentMenuInfo)
        },
    },
    getters: {
        menuInfo: (state) => {
            return state._menuInfo
        },
        currentMenuInfo: (state) => {
            return state._currentMenuInfo
        },
    },
    mutations: {
        SET_MENU_INFO: (state, payload) => {
            state._menuInfo = payload.menuInfo
        },
        SET_CURRENT_MENU_INFO: (state, payload) => {
            state._currentMenuInfo = payload
        },
    },
}
