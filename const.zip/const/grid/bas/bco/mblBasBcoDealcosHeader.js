import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'sktAgencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCdLvl1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCdLvl2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCdLvl3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStatus',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNmTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoRgstClCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '거래처명',
            },
        },
    ],
}
