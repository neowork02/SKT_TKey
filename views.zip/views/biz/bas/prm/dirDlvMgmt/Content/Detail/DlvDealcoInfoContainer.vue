<template>
    <div v-if="this.isGridDlvDealcoInfo1">
        <!--<div>-->

        <!-- SubTit  -->
        <div class="stitHead">
            <h4 class="subTit">배송지정보</h4>
        </div>
        <!-- //SubTit -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div3">
                    <!--
            <TCComInput
                v-model="dlvDealcoInfo.sknDlvDealcoCd"
                labelName="배송지코드"
                :readonly="true"
                :disabled="isDlvDealco"
                
            />
            -->
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDlvDealcoCd"
                        labelName="배송지코드"
                        :disabled="isDlvDealco"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div3">
                    <TCComInput
                        v-model="dlvDealcoInfo.rcvSknDlvDealcoCd"
                        labelName="SKN배송지코드"
                        :disabled="true"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div3">
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDelvDealcdNm"
                        labelName="배송지명"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                    />
                </div>
                <!-- //item 1-3 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="dlvDealcoInfo.agencyNm"
                        :codeVal.sync="dlvDealcoInfo.sknDlvSktAgencyCd"
                        :eRequired="true"
                        labelName="배송대리점"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAgencyEnterKey"
                        @appendIconClick="onAgencyIconClick"
                        @input="onAgencyInput"
                        :disabled="isDlvDealco"
                    />
                    <BasBcoAgencysPopup
                        v-if="showBcoAgencys"
                        :parentParam="agencySearchParam"
                        :rows="resultAgencyRows"
                        :dialogShow.sync="showBcoAgencys"
                        @confirm="onAgencyReturnData"
                    />
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div3">
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDlvSktSubCd"
                        labelName="배송대리점 서브코드"
                        labelClass="line2"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                    />
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div3">
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDlvPwdNo"
                        labelName="직배송 인증번호"
                        labelClass="line2"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                    />
                </div>
                <!-- //item 2-3 -->
            </div>
            <div class="searchform">
                <div class="formitem div3">
                    <TCComComboBox
                        v-model="dlvDealcoInfo.sknDlvClCd"
                        labelName="SKN창고코드"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="objAuth"
                        :itemList="sknWhouseCdList"
                        :disabled="isDlvDealco"
                    ></TCComComboBox>
                </div>
            </div>
            <!-- //Search_line 2 -->
            <!-- Search_line 4 -->
            <div class="searchform">
                <!-- item 4-1 -->
                <div class="formitem div1">
                    <!-- label + 멀티폼_주소 -->
                    <div class="multiFormAddressType2">
                        <div class="col1">
                            <TCComInputSearch
                                labelName="배송지주소"
                                @appendIconClick="onNewZipSrchClick"
                                v-model="dlvDealcoInfo.sknDelvZipCd"
                                :disabled="isDlvDealco"
                            />
                            <BasBcoNewZipSrchPopup1
                                v-if="showBcoNewZipSrch"
                                :rows="resultNewZipSrchRows"
                                :dialogShow.sync="showBcoNewZipSrch"
                                :parentParam="searchNewZipSrchParam"
                                @confirm="onNewZipSrchSReturnData"
                            />
                        </div>
                        <div class="col2">
                            <TCComNoLabelInput
                                class="inBlock"
                                v-model="dlvDealcoInfo.sknDelvAddr"
                                :readonly="!isDlvDealco"
                                :disabled="isDlvDealco"
                            />
                        </div>
                        <div class="col3">
                            <TCComNoLabelInput
                                class="inBlock"
                                v-model="dlvDealcoInfo.sknDelvDtlAddr"
                                :disabled="isDlvDealco"
                            />
                        </div>
                        <div class="colbtn">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="복사"
                                @click="clickCopy"
                                :disabled="isDlvDealco"
                            />
                        </div>
                    </div>
                    <!-- // label + 멀티폼_주소 -->
                </div>
                <!-- //Search_line 4 -->
            </div>
            <!-- Search_line 6 -->
            <div class="searchform">
                <!-- item 6-1 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDlvChrgrUserId"
                        labelName="수취담당명"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                    />
                </div>
                <!-- //item 6-1 -->
                <!-- item 6-2 -->
                <div class="formitem div4">
                    <TCComInput
                        v-model="dlvDealcoInfo.sknDlvMblPhonNo"
                        labelName="수취담당 연락처"
                        labelClass="line2"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                    />
                </div>
                <!-- //item 6-2 -->
                <!-- item 6-3 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        v-model="dlvDealcoInfo.aplyStaDt"
                        labelName="적용시작일"
                        :eRequired="true"
                        :disabled="isDlvDealco"
                    />
                </div>
                <!-- //item 6-3 -->
                <!-- item 6-4 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="dlvDealcoInfo.useYn"
                        labelName="사용여부"
                        :addBlankItem="true"
                        :itemList="comYn"
                        blankItemText="선택"
                        blankItemValue=""
                        :eRequired="true"
                        :disabled="isDlvDealco"
                    ></TCComComboBox>
                </div>
                <!-- //item 6-4 -->
            </div>
            <!-- //Search_line 6 -->
            <!-- Search_line 7 -->
            <div class="searchform">
                <!-- item 7-1 -->
                <div class="formitem div1">
                    <TCComTextArea
                        v-model="dlvDealcoInfo.sknDlvRmks"
                        labelName="비고"
                        :disabled="isDlvDealco"
                    />
                </div>
                <!-- //item 7-1 -->
            </div>
            <!-- //Search_line 7 -->
        </div>
        <!-- //Search_div -->

        <!-- SubTit  -->
        <div class="stitHead">
            <span class="stitBtnRef notit mb10">
                <!--                <TCComButton-->
                <!--                    :Vuetify="false"-->
                <!--                    eClass="btn_noline btn_ty04"-->
                <!--                    eAttr="ico_basic"-->
                <!--                    labelName="배송지 정보수정"-->
                <!--                    @click="updateInfo"-->
                <!--                />-->
                <TCComButton
                    :disabled="true"
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_basic"
                    labelName="전송"
                    :objAuth="objAuth"
                    @click="submit"
                />
                <TCComButton
                    :disabled="true"
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_filesave"
                    labelName="입력저장"
                    :objAuth="objAuth"
                />
                <!--                <SendPopup-->
                <!--                    v-if="showSendDtPopup"-->
                <!--                    :parentParam="searchSendDtParam"-->
                <!--                    :rows="resultSendDtRows"-->
                <!--                    :dialogShow.sync="showSendDtPopup"-->
                <!--                />-->
                <TCComButton
                    :disabled="true"
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowadd"
                    labelName="행추가"
                    @click="gridAddRowBtn"
                />
                <TCComButton
                    :disabled="true"
                    :Vuetify="false"
                    eClass="btn_noline btn_ty04"
                    eAttr="ico_rowdel"
                    labelName="행삭제"
                    @click="gridChkDelRowBtn"
                />
            </span>
        </div>
        <!-- //SubTit -->
        <TCRealGrid
            id="gridDlvDealcoInfo"
            ref="gridDlvDealcoInfo"
            :editable="false"
            :updatable="false"
            :movable="false"
            :columnMovable="false"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
        <p class="infoTxt">
            <span class="color-red">
                수정/등록 후 입력저장 버튼을 눌러야 반영이 됩니다.
            </span>
        </p>
    </div>
</template>

<script>
import { CommonGrid } from '@/utils'
import { GRID_DLV_HEADER } from '@/const/grid/bas/prm/basPrmDealcoMgmtHeader'
import CommonMixin from '@/mixins'
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dirDlvMgmt/helpers'

import _ from 'lodash'
//====================대리점팝업====================
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
//====================//대리점팝업====================
//====================우편번호팝업====================
import BasBcoNewZipSrchPopup1 from '@/views/biz/bas/bco/BasBcoNewZipSrchPopup'
import basBcoNewZipSrchApi from '@/api/biz/bas/bco/basBcoNewZipSrch'
//====================//우편번호팝업====================

export default {
    name: 'DlvDealcoInfoContainer',
    props: {},
    components: {
        BasBcoAgencysPopup,
        BasBcoNewZipSrchPopup1,
    },
    mixins: [CommonMixin],
    computed: {
        ...serviceComputed,
        //==================== 상세데이터 ==================
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        basPrmDealcoDtlCmVo: {
            get() {
                return this.basPrmDealcoDtlCmListVo // 사업자등록정보
            },
        },
        basPrmDealcoDtlCardVo: {
            get() {
                return this.basPrmDealcoDtlCardListVo // 카드단말기
            },
        },
        basPrmDealcoDtlCrdVo: {
            get() {
                return this.basPrmDealcoDtlCrdListVo // 담보
            },
        },
        basPrmDealcoDtlDlvVo: {
            get() {
                return this.basPrmDealcoDtlDlvListVo // 배송지
            },
        },
        basPrmDealcoDtlChrgrVo: {
            get() {
                return this.basPrmDealcoDtlChrgrListVo // 영업담당자
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
        basPrmDealcoDtlDlvList1: {
            get() {
                return this.basPrmDealcoDtlDlvList
            },
        },
        dlvDealcoInfoData1: {
            get() {
                return this.dlvDealcoInfoData
            },
        },
        //==================== //상세데이터 ==================
        comYn: {
            get() {
                return this.COM_YN
            },
        },
        sknWhouseCdList1: {
            get() {
                return this.SKN_WHOUSE_CD
            },
        },
        isGridDlvDealcoInfo1: {
            get() {
                return this.isGridDlvDealcoInfo
            },
        },
    },
    created() {},
    data() {
        return {
            objCnt: 0,
            isDisabledAdd: true,
            view: GRID_DLV_HEADER,
            isDtlAdd: false,
            isDlvDealco: true,
            gridData: this.gridSetData(),
            objAuth: {},
            gridObj: {},
            dlvDealcoInfo: {
                sknDlvDealcoCd: '',
                rcvSknDlvDealcoCd: '',
                sknDelvDealcdNm: '',
                agencyNm: '',
                sknDlvSktAgencyCd: '',
                sknDlvSktSubCd: '',
                sknDlvPwdNo: '',
                sknDlvClCd: '',
                sknDelvZipCd: '',
                sknDelvAddr: '',
                sknDelvDtlAddr: '',
                sknDlvChrgrUserId: '',
                sknDlvMblPhonNo: '',
                aplyStaDt: '',
                useYn: '',
                sknDlvRmks: '',
                sknDlvAplyStaDt: '',
                sknDlvUseYn: '',
                __rowState: '',
            },
            gridStyle: {
                height: '130px', //그리드 높이 조절
            },
            layout3: [
                'sknDlvDealcoCd',
                'sknDelvDealcdNm',
                'sknDlvSktAgencyCd',
                'agencyNm',
                'sknDlvSktSubCd',
                'useYn',
                'applyYn',
            ],
            sknWhouseCdList: [{ commCdVal: '', commCdValNm: '선택' }], // SKN창고코드
            //====================대리점팝업관련====================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            agencySearchParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
            //====================우편번호팝업관련===================
            showBcoNewZipSrch: false, // 팝업 오픈 여부
            searchNewZipSrchParam: {
                sknDelvAddr: '',
                sknDelvDtlAddr: '',
            },
            resultNewZipSrchRows: [], // 팝업 오픈 여부
            //====================//우편번호팝업관련=================
            clickStatus: null,
        }
    },
    mounted() {
        this.initData()
        if (this.pIsNew) {
            this.initDlvDealcoInfo()
        }
    },
    methods: {
        ...serviceMethods,
        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        initData() {
            this.dlvDealcoInfo = {
                sknDlvDealcoCd: '',
                rcvSknDlvDealcoCd: '',
                sknDelvDealcdNm: '',
                agencyNm: '',
                sknDlvSktAgencyCd: '',
                sknDlvSktSubCd: '',
                sknDlvPwdNo: '',
                sknDlvClCd: '',
                sknDelvZipCd: '',
                sknDelvAddr: '',
                sknDelvDtlAddr: '',
                sknDlvChrgrUserId: '',
                sknDlvMblPhonNo: '',
                aplyStaDt: '',
                useYn: '',
                sknDlvRmks: '',
                sknDlvAplyStaDt: '',
                sknDlvUseYn: '',
                __rowState: '',
            }
            this.sknWhouseCdList = this.sknWhouseCdList1
        },
        initDlvDealcoInfo() {
            if (this.$refs.gridDlvDealcoInfo !== undefined) {
                this.gridObj = this.$refs.gridDlvDealcoInfo
                this.gridObj.gridView.setColumnLayout(this.layout3)
                this.gridObj.gridView.commit()
                this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
                this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
                this.gridObj.gridView.setDisplayOptions.focusVisible = false //포커스 표시 여부
                this.gridObj.setGridState(false, false, false, false)

                if (!this.isDtlAdd) {
                    if (!_.isEmpty(this.basPrmDealcoDtlDlvList1)) {
                        this.gridObj.setRows(this.basPrmDealcoDtlDlvList1)
                        this.gridObj.gridView.onCellClicked = (
                            grid,
                            clickData
                        ) => {
                            if (typeof clickData.itemIndex !== 'undefined') {
                                _.forEach(GRID_DLV_HEADER.fields, (item) => {
                                    const key = item.fieldName
                                    this.dlvDealcoInfo[key] = grid.getValue(
                                        clickData.itemIndex,
                                        key
                                    )
                                })
                            }
                        }
                    }
                    this.isDtlAdd = true
                }
            }
        },
        gridSetData() {
            return new CommonGrid(0, 10, '', '')
        },
        clickCopy() {
            this.dlvDealcoInfo.sknDelvZipCd = this.bizRgstInfoData.zipCd
            this.dlvDealcoInfo.sknDelvAddr = this.bizRgstInfoData.addr
            this.dlvDealcoInfo.sknDelvDtlAddr = this.bizRgstInfoData.dtlAddr
        },
        updateInfo() {
            if (this.isDlvDealco) {
                this.isDlvDealco = false
            } else {
                this.isDlvDealco = true
            }
        },
        submit() {
            alert('TODO 전송')
        },
        gridAddRowBtn: function () {
            this.initDlvDealcoInfo()
            this.isDisabledAdd = false

            this.gridData.gridRows = this.gridObj.dataProvider.addRow(
                this.gridData.gridRows
            )
            this.gridObj.gridView.onEditCommit = (grid) => {
                grid.editOptions.commitByCell = true
            }
            this.objCnt = this.gridData.gridRows
        },

        gridChkDelRowBtn: function () {
            this.gridObj.gridView.commit()
            let newRows = []
            let checkRows = this.gridObj.gridView.getCheckedRows(true)
            let rows = this.gridObj.dataProvider.getJsonRows()

            if (checkRows.length >= 1) {
                checkRows.forEach((n) => {
                    rows.forEach((v, i) => {
                        if (n === i) {
                            newRows.push(v)
                        }
                    })
                })
                this.gridObj.dataProvider.beginUpdate()
                this.gridObj.dataProvider.removeRows(checkRows)
                this.gridObj.dataProvider.endUpdate()
                this.objCnt -= checkRows.length
            } else {
                this.showTcComAlert('삭제할 대상을 선택해 주세요.')
                return false
            }

            if (this.objCnt < 0) {
                this.isDisabledAdd = true
            }
        },

        //===================== 대리점팝업관련 methods ================================
        // 대리정 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getAgencyList() {
            let searchParam = {}
            searchParam['agencyCd'] = this.dlvDealcoInfo.agencyCd
            searchParam['agencyNm'] = this.dlvDealcoInfo.agencyNm
            basBcoAgencysApi.getAgencyList(searchParam).then((res) => {
                // 검색된 대리점 정보가 1건이면 TextField에 바로 설정
                // 검색된 대리점 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                if (!_.isEmpty(res)) {
                    this.dlvDealcoInfo.agencyCd = _.get(res[0], 'agencyCd')
                    this.dlvDealcoInfo.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultAgencyRows = res
                    this.agencySearchParam.agencyCd =
                        this.dlvDealcoInfo.agencyCd
                    this.agencySearchParam.agencyNm =
                        this.dlvDealcoInfo.agencyNm
                    this.showBcoAgencys = true
                }
            })
        },
        // 대리점 TextField 돋보기 Icon 이벤트 처리
        onAgencyIconClick() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이 아니면 대리정 정보 조회
            // 그 이외는 대리점 팝업 오픈
            if (!_.isEmpty(this.dlvDealcoInfo.agencyNm)) {
                this.getAgencyList()
            } else {
                this.agencySearchParam.agencyCd = this.dlvDealcoInfo.agencyCd
                this.agencySearchParam.agencyNm = this.dlvDealcoInfo.agencyNm
                this.showBcoAgencys = true
            }
        },
        // 대리점 TextField 엔터키 이벤트 처리
        onAgencyEnterKey() {
            // 대리점 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 대리점명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dlvDealcoInfo.agencyNm)) {
                this.showTcComAlert('대리점명을 입력해주세요.')
                return false
            }
            // 대리점 정보 조회
            this.getAgencyList()
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.dlvDealcoInfo.agencyCd = ''
            let params = { ...this.dlvDealcoInfo }
            this.storeSet(this.storeKey, params)
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.dlvDealcoInfo.agencyCd = _.get(returnData, 'agencyCd')
            this.dlvDealcoInfo.agencyNm = _.get(returnData, 'agencyNm')
            let params = { ...this.dlvDealcoInfo }
            this.storeSet(this.storeKey, params)
        },
        //===================== //대리점팝업관련 methods ================================
        //===================== 우편번호팝업관련 methods ================================
        getZipList() {
            let searchParam = {}
            searchParam['streetNm'] = this.dlvDealcoInfo.sknDelvAddr
            basBcoNewZipSrchApi.getNewZipCode(searchParam).then((res) => {
                if (!_.isEmpty(res)) {
                    this.dlvDealcoInfo.sknDelvAddr = _.get(res[0], 'streetNm')
                    this.dlvDealcoInfo.sknDelvDtlAddr = _.get(
                        res[0],
                        'siGunGuBldnNm'
                    )
                } else {
                    this.resultAgencyRows = res
                    this.searchNewZipSrchParam.sknDelvAddr =
                        this.dlvDealcoInfo.sknDelvAddr
                    this.searchNewZipSrchParam.sknDelvDtlAddr =
                        this.dlvDealcoInfo.sknDelvDtlAddr
                    this.showBcoAgencys = true
                }
            })
        },
        // 사용자 TextField 돋보기 Icon 이벤트 처리
        onNewZipSrchClick() {
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultNewZipSrchRows = []
            if (!_.isEmpty(this.dlvDealcoInfo.sknDelvAddr)) {
                // API 호출
                this.getZipList()
            } else {
                this.searchNewZipSrchParam.sknDelvAddr =
                    this.dlvDealcoInfo.sknDelvAddr
                this.searchNewZipSrchParam.sknDelvDtlAddr =
                    this.dlvDealcoInfo.sknDelvDtlAddr

                this.showBcoNewZipSrch = true
            }
        },
        // 주소 TextField 엔터키 이벤트 처리
        onNewZipSrchEnterKey() {
            // 주소 팝업 Row 설정 Prop 변수 초기화
            this.resultAgencyRows = []
            // 검색조건 주소 빈값이면 알림창 오픈
            if (_.isEmpty(this.dlvDealcoInfo.sknDelvAddr)) {
                this.showTcComAlert('배송지를 입력해주세요.')
                return false
            }
            // 주소 정보 조회
            this.getZipList()
        },
        replaceStreetNm(returnData, path) {
            let street
            if (!_.isEmpty(path)) {
                street = _.get(returnData, path) + ' '
            }
            return street
        },
        // 사용자 팝업 리턴 이벤트 처리
        onNewZipSrchSReturnData(returnData) {
            let streetNm =
                this.replaceStreetNm(returnData, 'siDoNm') +
                this.replaceStreetNm(returnData, 'siGunGuNm') +
                this.replaceStreetNm(returnData, 'streetNm')

            this.dlvDealcoInfo.sknDelvZipCd = _.get(returnData, 'zipCd')
            this.dlvDealcoInfo.sknDelvAddr = streetNm.trim()
            this.dlvDealcoInfo.sknDelvDtlAddr = _.get(
                returnData,
                'siGunGuBldnNm'
            )
            let param = { ...this.dlvDealcoInfo }
            this.storeSet(this.storeKey, param)
        },
        //===================== //사용자영업담당자팝업관련 methods ================================
    },
    watch: {
        basPrmDealcoDtlDlvList1: {
            handler: function (values) {
                if (!_.isEmpty(values) && this.isGridDlvDealcoInfo1) {
                    clearTimeout(this.clickStatus)
                    this.clickStatus = setTimeout(() => {
                        this.initDlvDealcoInfo()
                    }, 200)
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        basPrmDealcoDtlDlvVo: {
            handler: function (values) {
                let detailData = this.dlvDealcoInfo // 데이터 Set

                _.forEach(Object.keys(detailData), (key) => {
                    if (!_.isEmpty(key)) {
                        // 기본정보셋팅
                        let value = values[key]
                        let isValue = false
                        //let currentDate = moment(new Date()).format('YYYY-MM-DD')
                        if (
                            _.isEqual(value, undefined) ||
                            _.isEqual(value, null) ||
                            _.isEqual(value, '')
                        ) {
                            if (typeof detailData[key] === 'object') {
                                value = []
                            } else {
                                value = ''
                            }
                        } else {
                            isValue = true
                        }
                        // 필터정보셋팅

                        if (_.isEqual(key, 'agencyNm')) {
                            let sktAgencyCd = this.etcAddInfoData.sktAgencyCd
                            let sktChnlCd = this.etcAddInfoData.sktChnlCd
                            let sktSubCd = this.etcAddInfoData.sknDlvSktSubCd

                            let newKey
                            /**
                             * 배송지코드 가공 (총 12자리)
                             * 채널코드값이 있는 경우
                             * Swing코드 : D09998(6) + 채널코드 : P12345(6)
                             * 기본 D09998(6) + 0035(4) + 00(2자리)
                             * TWSN : D09998(6) + 0035(4) + N0(2자리)
                             * TWSP : D09998(6) + 0035(4) + P0(2자리)
                             */
                            if (!_.isEmpty(sktChnlCd)) {
                                // 채널코드가 있는 경우
                                newKey = sktAgencyCd + sktChnlCd
                            } else {
                                if (_.isEqual(key, 'TWSN')) {
                                    newKey = sktAgencyCd + sktSubCd + 'N0'
                                } else if (_.isEqual(key, 'TWSP')) {
                                    newKey = sktAgencyCd + sktSubCd + 'P0'
                                } else {
                                    newKey = sktAgencyCd + sktSubCd + '00'
                                }
                            }

                            detailData['sknDlvDealcoCd'] = isValue ? newKey : ''
                        } else {
                            detailData[key] = value
                        }
                    }
                })

                let param = { ...detailData }
                this.storeSet(this.storeKey, param)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
