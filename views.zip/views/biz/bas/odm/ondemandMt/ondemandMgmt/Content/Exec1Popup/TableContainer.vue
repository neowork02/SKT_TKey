<template lang="">
    <div id="execGridWap" class="gridWrap">
        <TCRealGridHeader
            id="ondemandMgmtExec1Header1"
            ref="ondemandMgmtExec1Header1"
            gridTitle=""
            :gridObj="gridObj"
            :isPageRows="true"
            :isExceldown="false"
            :isNextPage="false"
            :isPageCnt="false"
            :editable="true"
            :isAddRow="false"
            :isDelRow="false"
            :addData="this.addData"
            @excelDownBtn="this.excelDownBtn"
            @addRowBtn="this.gridAddRowBtn"
            @chkDelRowBtn="this.gridchkDelRowBtn"
        />
        <TCRealGrid
            id="ondemandMgmtExec1Grid"
            ref="ondemandMgmtExec1Grid"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/odm/ondemandMt/ondemandMgmt/helpers'
import { EXEC_HEADER } from '@/const/grid/bas/odm/basOdmOndemandMgmtHeader'
import { CommonGrid } from '@/utils'
import CommonMsg from '@/utils/CommonMsg'
//import { msgTxt } from '@/const/msg.Properties.js'
import moment from 'moment'
//import { forEach } from 'lodash'

export default {
    name: 'BasOdmOndemandMgmtExecGrid1',
    components: {},
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '300px', //그리드 높이 조절
            },
            view: EXEC_HEADER,
            layout: [
                'pagingSeq',
                //'chk', //체크
                'condNm',
                'condVal',
                'condLen',
                //'condTypCd',
                //'condId',
            ],
            addData: [],
            //행추가,수정시 필수 입력 컬럼
            requiredCols: [],
            gridOnClick: '',
            popupRowIndex: '',
        }
    },
    async mounted() {
        this.gridObj = this.$refs.ondemandMgmtExec1Grid
        this.gridHeaderObj = this.$refs.ondemandMgmtExec1Header1
        this.gridObj.gridView.setColumnLayout(this.layout)

        /*
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         */
        //this.gridObj.setGridState(true, true, true, false)
        //    this.gridObj.setGridState()
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, false, false, false)
        //체크바
        this.gridObj.gridView.setCheckBar({
            visible: false,
        })
        //this.gridObj.gridView.checkBar.fieldName = 'chk'

        //편집가능
        this.gridObj.gridView.setEditOptions({
            editable: true,
            updatable: true,
        })
        //컬럼 고정
        // this.gridObj.gridView.setFixedOptions({
        //     colCount: 3,
        // })
        //dropdown combo
        //await this.dropDownSetting()

        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

        // this.gridOnClick =
        //     this.gridObj.gridView.onCellButtonClicked
        // this.gridObj.gridView.onCellButtonClicked = (
        //     grid,
        //     index,
        //     column
        // ) => {
        //     this.gridPopup(
        //         index.itemIndex,
        //         column.fieldName
        //     )
        // }

        this.gridObj.gridView.onCellEdited = (
            // eslint-disable-next-line no-unused-vars
            grid,
            // eslint-disable-next-line no-unused-vars
            itemIndex,
            // eslint-disable-next-line no-unused-vars
            row,
            // eslint-disable-next-line no-unused-vars
            field
        ) => {
            console.log('exec1grid onCellEdited')
            this.gridObj.gridView.commit()
            let arr1 = this.gridObj.dataProvider.getJsonRows()
            this.defaultAssign_({
                key: 'resultExecList',
                value: arr1,
            })
        }
    },
    computed: {
        ...serviceComputed,
        data1: {
            get() {
                return this.$data
            },
        },
        resultList1: {
            get() {
                return this.resultExecList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        // saveAction1: {
        //     get() {
        //         return this.saveAction
        //     },
        // },
        execListSave1: {
            get() {
                return this.execListSave
            },
        },
    },
    methods: {
        ...serviceMethods,
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 9999, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        excelDownBtn: function () {
            this.gridHeaderObj.exportGrid(
                `신조직관리목록_${moment(new Date()).format(
                    'YYYYMMDDHHmmss'
                )}.xls`
            )
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            //Grid Row 가져올때 페이지정보 Setting
            console.log(
                '🚀 ~ file: TableContainer.vue ~ line 129 ~ SetPaging ~ paging',
                this.paging
            )
            this.gridHeaderObj.setPageCount(this.paging)
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        gridAddRowBtn: function () {
            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            let focuscell = this.gridObj.gridView.getCurrent()
            console.log(focuscell)
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
        },
        gridDelRowBtn: function () {
            // one select line delete
            // @selDelRow="gridDelRowBtn"
            console.log('del current row')
            this.gridData.gridRows = this.gridHeaderObj.selDelRow()
        },
        gridchkDelRowBtn: function () {
            // Checked Row Delete Event
            //@chkDelRowBtn="gridchkDelRowBtn"
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        async dropDownSetting() {
            //등록구분
            await this.dropDownCmmonCodes_({
                key: 'AGENCY_RGST_CL',
                columnName: 'agencyRgstClCd',
                option: '선택',
            })
            await this.changeDropDown('agencyRgstClCd')
            //대리점구분
            await this.dropDownCmmonCodes_({
                key: 'AGENCY_PTN',
                columnName: 'agencyClCd',
                option: '선택',
            })
            await this.changeDropDown('agencyClCd')
            //대리점유형
            await this.dropDownCmmonCodes_({
                key: 'AGENCY_TYP',
                columnName: 'agencyTypCd',
                option: '선택',
            })
            await this.changeDropDown('agencyTypCd')
            //자동배정
            await this.dropDownCmmonCodes_({
                key: 'USE_YN',
                columnName: 'disAsgnYn',
                option: '선택',
            })
            await this.changeDropDown('disAsgnYn')
            //유선이용여부
            await this.dropDownCmmonCodes_({
                key: 'USE_YN',
                columnName: 'wlClYn',
                option: '선택',
            })
            await this.changeDropDown('wlClYn')
        },
        async changeDropDown(key) {
            let col1 = this.gridObj.gridView.columnByName(key)
            col1.values = this.commDropDown[key].values
            col1.labels = this.commDropDown[key].labels
            this.gridObj.gridView.setColumn(col1)
        },
        errorCellFocus(chkCell, message) {
            this.toasting_({
                message: message,
            })
            //cell focus : { index: -1, fieldName: '' }
            this.gridObj.validationChkGrid(chkCell)
        },
        validationCheck() {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            var chk = { index: -1, fieldName: '' }
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.gridObj.dataProvider.getJsonRow(
                        index[i],
                        true
                    )

                    if (
                        row.__rowState == 'created' ||
                        row.__rowState == 'updated'
                    ) {
                        //필수 입력 체크
                        if (this.requiredCols.length) {
                            // created(추가) / updated(수정) 인경우 필수입력항목 체크
                            for (var j = 0; j < this.requiredCols.length; j++) {
                                //필수입력항목이 누락된경우
                                if (!row[this.requiredCols[j]]) {
                                    chk.index = index[i]
                                    chk.fieldName = this.requiredCols[j]

                                    this.errorCellFocus(
                                        chk,
                                        this.gridObj.gridView.columnByField(
                                            chk.fieldName
                                        ).header.text + ' 필수 입력 입니다.'
                                    )
                                    return false
                                }
                            }
                        }

                        //적용일자 체크
                        // let fromDt = moment(row.aplyStaDt, 'YYYYMMDD').toDate()
                        // let toDt = moment(row.aplyEndDt, 'YYYYMMDD').toDate()
                        // if (fromDt > toDt) {
                        //     chk.index = index[i]
                        //     chk.fieldName = 'aplyStaDt'

                        //     this.errorCellFocus(
                        //         chk,
                        //         '적용시작일자가 적용마지막일자 보다 큽니다.'
                        //     )
                        //     return false
                        // }
                    }

                    //대리점 코드, 위탁창코 중복 체크
                    // if (row.__rowState == 'created') {
                    //     let all1 = this.gridObj.dataProvider.getJsonRows(0, -1)
                    //     let dup1 = all1.filter(
                    //         (e) => e.agencyCd === row.agencyCd
                    //     )
                    //     //대리점 체크
                    //     if (dup1.length > 1) {
                    //         chk.index = index[i]
                    //         chk.fieldName = 'agencyCd'

                    //         this.errorCellFocus(chk, '중복코드 입니다.')
                    //         return false
                    //     }
                    //     //위탁창고 체크
                    //     let dup2 = all1.filter(
                    //         (e) => e.cnsgHldPlcCd === row.cnsgHldPlcCd
                    //     )
                    //     if (dup2.length > 1 && row.cnsgHldPlcCd != '') {
                    //         chk.index = index[i]
                    //         chk.fieldName = 'cnsgHldPlcCd'

                    //         this.errorCellFocus(chk, '중복코드 입니다.')
                    //         return false
                    //     }
                    // }
                }
            } else {
                if (!this.gridData.delRows.length) {
                    // this.toasting_({
                    //     message: msgTxt.MSG_01002,
                    // })
                    return false
                }
            }

            return true
        },
        async saveData() {
            this.loading(true)
            let saveRows = []

            for (let i = 0; i < this.gridData.delRows.length; i++) {
                let e = this.gridData.delRows[i]
                saveRows.push({
                    ...e,
                    rowState: e.__rowState,
                    //agencyCd: e.agencyCd, //UKEY대리점코드
                })
            }

            var arr = []
            var cIndex = this.gridObj.dataProvider.getStateRows('created')
            var uIndex = this.gridObj.dataProvider.getStateRows('updated')
            arr.push(...cIndex)
            arr.push(...uIndex)
            for (var i = 0; i < arr.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(arr[i], true)
                saveRows.push({
                    ...row,
                    rowState: row.__rowState,
                })
            }

            console.log('crud api call', saveRows, this.resultDetailList)

            //checkBar 를 사용할 경우 체크된 건만 저장처리
            if (this.gridObj.gridView.checkBar.fieldName == 'chk') {
                saveRows = saveRows.filter((x) => {
                    return (
                        x['chk'] != null &&
                        x['chk'] == 'true' &&
                        x['origin'] != 'in'
                    )
                })
            }

            await this.defaultAssign_({
                key: 'saveDataAdd',
                value: saveRows,
            })

            // let res1
            // await this.saveDealCoMgmt_({ saveRows })
            //     .then((res) => {
            //         res1 = res
            //     })
            //     .finally(() => {
            //         this.loading(false)
            //         if (res1 === 1) {
            //             this.toasting_({
            //                 message: '정상처리 되었습니다.',
            //             })

            //             //정상등록시 다시 조회
            //             this.$emit('Refresh', '')

            //             //그리드 초기화 하는 경우
            //             //this.gridObj.gridInit()
            //         }
            //     })
        },
        gridPopup(row, col) {
            if (col == 'agencyCd') {
                //alert('준비중 UKEY대리점 팝업:' + row + ', fieldName=' + col)
            }
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        resultList1(val, oldVal) {
            this.gridObj.dataProvider.clearRows()
            this.gridData = this.GridSetData()
            //this.gridObj.gridView.commit()
            this.gridObj.setRows(this.resultList1)

            //신규 row 상태값 변경
            let arr1 = this.gridObj.dataProvider.getJsonRows()
            for (let j = 0; j < arr1.length; j++) {
                // if (arr1[j].chk == 'true') {
                //     // this.gridObj.dataProvider.setValue(
                //     //     j,
                //     //     'orgCd',
                //     //     this.currentOrg.orgCd
                //     // )
                //     this.gridObj.dataProvider.setRowState(j, 'updated', false) //updated
                // }
                this.gridObj.dataProvider.setRowState(j, 'updated', false) //updated
            }
            this.gridObj.gridView.commit()
        },
        // eslint-disable-next-line no-unused-vars
        paging1(val, oldVal) {
            this.SetPaging()
        },
        // eslint-disable-next-line no-unused-vars
        async execListSave1(val, oldVal) {
            this.gridObj.gridView.commit()
            let arr1 = this.gridObj.dataProvider.getJsonRows()
            await this.defaultAssign_({
                key: 'resultExecList',
                value: arr1,
            })
            await this.defaultAssign_({
                key: 'execListSave',
                value: '',
            })
        },
        // async saveAction1(val, oldVal) {
        //     if (val == true) {
        //         console.log('saveAction1: ', val, oldVal)
        //         this.gridObj.gridView.commit()

        //         console.log(
        //             '변경 데이타',
        //             this.gridObj.modifyGrid(), // 추가/수정 건 체크
        //             this.gridData.delRows
        //         )

        //         if (this.validationCheck()) {
        //             await this.saveData()
        //         } else {
        //             console.log('validation false')
        //         }

        //         //에러든 정상종료든 완료되면 flag처리
        //         await this.defaultAssign_({
        //             key: 'saveDoneA',
        //             value: true,
        //         })

        //         // //temp 임시로 두개의 saveAction 이 있다고 간주
        //         // await this.defaultAssign_({
        //         //     key: 'saveDoneB',
        //         //     value: true,
        //         // })
        //     }
        // },
    },
}
</script>
<style>
#execGridWap .stitHead {
    margin-top: -20px !important;
}
</style>
