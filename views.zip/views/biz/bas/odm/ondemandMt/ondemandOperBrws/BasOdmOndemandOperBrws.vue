<!-----------------------------------------------
 * 업무그룹명: 기준정보>기타
 * 서브업무명: 대용량자료요청-OnDemand작업조회
 * 설명: 대용량자료요청-OnDemand작업조회 조회/입력/수정/삭제 한다.
 * 작성자: P180392
 * 작성일: 2022.06.28
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <!-- <div class="content"> -->
    <div>
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/odm/ondemandMt/ondemandOperBrws/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/odm/ondemandMt/ondemandOperBrws'

export default {
    name: 'BasOdmOndemandOperBrws',
    created() {
        console.log('created:' + this.$options.name)
        if (this.$store.hasModule('bas.odm.ondemandOperBrwsStore') != true) {
            this.$store.registerModule('bas.odm.ondemandOperBrwsStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.odm.ondemandOperBrwsStore') == true) {
            this.$store.unregisterModule('bas.odm.ondemandOperBrwsStore')
        }
    },

    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>

<style></style>
