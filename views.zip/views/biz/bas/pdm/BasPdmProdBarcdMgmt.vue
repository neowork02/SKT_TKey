<template>
    <div class="content">
        <h1>상품바코드관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <!-- <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="onDelete"
                    v-if="v_btn_del.visible"
                    :objAuth="this.objAuth"
                    >삭제
                </TCComButton> -->
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="상품구분"
                        v-model="div_search.prodClCd"
                        :objAuth="this.objAuth"
                        codeId="ZBAS_C_00010"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="상품 바코드 목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isAddRow="true"
                :isDelRow="true"
                :isExceldown="false"
                @addRowBtn="btn_add_OnClick"
                @chkDelRowBtn="btn_del_OnClick"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :isGridReSize="true"
                :editable="true"
                :updatable="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getProductBarcodeList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
// import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
// import _ from 'lodash'
import { HEADER } from '@/const/grid/bas/pdm/basPdmProdBarcdMgmtHeader'
import API from '@/api/biz/bas/pdm/basPdmProdBarcdMgmt'
import CommonMixin from '@/mixins'

export default {
    name: 'BasPdmProdBarcdMgmt',
    components: {},
    mixins: [CommonMixin],

    data() {
        return {
            v_btn_del: { visible: false },
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            rowCnt: 15,
            layout: [
                'prodClCd',
                'barCdTypCd',
                'allLenCnt',
                {
                    name: 'group',
                    direction: 'horizontal',
                    items: ['mdlStaLenCnt', 'mdlEndLenCnt', 'mdlLenCnt'],
                    header: {
                        text: '모델코드',
                    },
                },
                {
                    name: 'group',
                    direction: 'horizontal',
                    items: ['colorStaLenCnt', 'colorEndLenCnt', 'colorLenCnt'],
                    header: {
                        text: '색상코드',
                    },
                },
                {
                    name: 'group',
                    direction: 'horizontal',
                    items: [
                        'serNumStaLenCnt',
                        'serNumEndLenCnt',
                        'serNumLenCnt',
                    ],
                    header: {
                        text: '일련번호',
                    },
                },
            ],
            //각각 엘리먼트 컴포넌트 v-model
            div_search: {
                prodClCd: '', //상품구분코드
            },
            objAuth: {},
            selectedJsonData: {},
            selectedRow: '',
            prod_bar_cd_mgmt: [],

            // alert 메세지
            msg: {
                isAllLenNull: '전체자리수 입력은 필수입니다.',
                isAllLenCorrect: '각 자리수의 합은 전체자리수와 동일해야합니다',
                isEndBiggerThanNextSta:
                    '현재 코드의 시작값은 이전 코드의 끝값보다 커야 합니다',
                compareEndSta:
                    '동일 코드에서 시작값은 0이거나 끝값보다 클 수 없습니다',
            },
        }
    },

    created() {
        this.init()
        console.log('this.$route Detail: ', this.$route)
        // this.searchParam = this.$route.params.search
    },

    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        // 삭제버튼 보이기 (임시 기존: =='P13'으로 바꿔야함)
        if (this.userInfo.userGrpCd !== 'P13') {
            this.v_btn_del.visible = true
        }

        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState(true)

        this.dropDownSetting()
        this.gridObj.gridView.columnByName('mdlLenCnt').editable = false
        this.gridObj.gridView.columnByName('colorLenCnt').editable = false
        this.gridObj.gridView.columnByName('serNumLenCnt').editable = false

        this.gridObj.gridView.onCellEdited = (
            grid,
            itemIndex,
            dataRow,
            field
        ) => {
            this.gridObj.gridView.commit()
            console.log(
                `itemIndex : ${itemIndex} / dataRow : ${dataRow} / field : ${field}`
            )

            this.selectedJsonData =
                this.gridObj.dataProvider.getJsonRow(dataRow)
            console.log('selectedJsonData', this.selectedJsonData)

            const data = this.selectedJsonData

            let isAllLenNull
            // 상품구분코드, 바코드유형코드 제외한 필드 수정 시
            if (field >= 3) {
                // 1.전체자리수 여부
                isAllLenNull = this.isAllLenNull(data)
            }
            console.log('isAllLenNull : ', isAllLenNull)

            // 코드의 끝값과 다음 코드의 시작값 체크
            //    1. 모델코드 끝 - 색상코드 시작 체크
            if (parseInt(data.mdlEndLenCnt) >= parseInt(data.colorStaLenCnt)) {
                console.log('모델코드 끝보다 색상코드 시작이 작음')
                console.log(data.mdlEndLenCnt + ' / ' + data.colorStaLenCnt)
                this.showTcComAlert(this.msg['isEndBiggerThanNextSta'])
            }
            //    2. 색상코드 끝 - 일련번호 시작 체크
            if (
                parseInt(data.colorEndLenCnt) >= parseInt(data.serNumStaLenCnt)
            ) {
                console.log('색상코드 끝보다 일련번호 시작이 작음')
                console.log(data.colorEndLenCnt + ' / ' + data.serNumStaLenCnt)
                this.showTcComAlert(this.msg['isEndBiggerThanNextSta'])
            }

            let mdlLenCnt
            let colorLenCnt
            let serNumLenCnt

            // 각 코드별 자리수 계산
            let sta = parseInt(data.mdlStaLenCnt)
            let end = parseInt(data.mdlEndLenCnt)
            if (sta != undefined && end != undefined) {
                mdlLenCnt = this.calLen(sta, end)
                if (mdlLenCnt == 'X')
                    this.showTcComAlert(this.msg['compareEndSta'])
            }

            sta = parseInt(data.colorStaLenCnt)
            end = parseInt(data.colorEndLenCnt)
            if (sta != undefined && end != undefined) {
                colorLenCnt = this.calLen(sta, end)
                if (colorLenCnt == 'X')
                    this.showTcComAlert(this.msg['compareEndSta'])
            }

            sta = parseInt(data.serNumStaLenCnt)
            end = parseInt(data.serNumEndLenCnt)

            if (sta != undefined && end != undefined) {
                serNumLenCnt = this.calLen(sta, end)
                if (serNumLenCnt == 'X')
                    this.showTcComAlert(this.msg['compareEndSta'])
            }

            // 계산한 자리수 그리드에 바로 적용
            let cnt1 = isNaN(mdlLenCnt) ? 0 : mdlLenCnt
            let cnt2 = isNaN(colorLenCnt) ? 0 : colorLenCnt
            let cnt3 = isNaN(serNumLenCnt) ? 0 : serNumLenCnt

            this.gridObj.gridView.setValue(dataRow, 'mdlLenCnt', cnt1)
            this.gridObj.gridView.setValue(dataRow, 'colorLenCnt', cnt2)
            this.gridObj.gridView.setValue(dataRow, 'serNumLenCnt', cnt3)

            if (mdlLenCnt + colorLenCnt + serNumLenCnt > data.allLenCnt) {
                this.showTcComAlert(this.msg['isAllLenCorrect'])
            }
        }

        // 싱글클릭 시 데이터 SET
        // this.gridObj.gridView.onCellClicked = (grid, clickData) => {
        //     if (clickData.dataRow >= 0) {
        //         this.selectedJsonData = this.gridObj.dataProvider.getJsonRow(
        //             clickData.dataRow
        //         )
        //         this.selectedRow = clickData.dataRow
        //         console.log('saveparam set', this.selectedJsonData)
        //         console.log('clickData.dataRow', clickData.dataRow)
        //     }
        // }

        // 그리드셀 키다운이벤트
        // this.gridObj.gridView.onKeyDown = this.onKeyDown
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.gridSetData()
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        //조회 버튼 이벤트
        onSearch: function () {
            this.gridData.totalPage = 0
            this.getProductBarcodeList(1)
        },

        getProductBarcodeList(pageNum) {
            let paramObj = {
                prodClCd: this.div_search.prodClCd,
            }
            console.log('paramObj : ', paramObj)
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt

            // 페이징 조회
            API.getProductBarcodeList(paramObj).then((result) => {
                this.prod_bar_cd_mgmt = result.gridList
                this.gridObj.setRows(result.gridList)
                // 페이징 관련
                this.gridObj.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData() //초기화
                this.gridData.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },
        // check
        // 1. 전체자리수
        isAllLenNull(barcd) {
            if (barcd.allLenCnt == undefined || barcd.allLenCnt == '') {
                this.showTcComAlert(this.msg['isAllLenNull'])
                return true
            }
            return false
        },

        /**
         * end : 코드 끝 ,
         * sta : 코드 시작 ,
         * role : end, sta의 값으로 해당 코드의 전체 자리수를 구함.
         */
        calLen(sta, end) {
            if (sta > end) {
                return 'X'
            }
            if (sta == 0 && sta == end) {
                return 0
            } else if (sta == 0 && sta != end) {
                return 'X'
            }
            if (sta > 0 && sta > 0) {
                return end - sta + 1
            }
        },
        //저장 버튼 이벤트
        onSave: function () {
            let saveParam = []
            let gridCreatedIndexArr =
                this.gridObj.dataProvider.getStateRows('created')
            let gridUpdatedIndexArr =
                this.gridObj.dataProvider.getStateRows('updated')

            console.log('gridCreatedIndexArr', gridCreatedIndexArr)
            console.log('gridUpdatedIndexArr', gridUpdatedIndexArr)

            for (let idx = 0; idx < gridCreatedIndexArr.length; idx++) {
                let getJson = this.gridObj.dataProvider.getJsonRow(
                    gridCreatedIndexArr[idx]
                )
                getJson.mdlStaLenCnt = getJson.mdlStaLenCnt
                    ? getJson.mdlStaLenCnt
                    : 0
                getJson.mdlEndLenCnt = getJson.mdlEndLenCnt
                    ? getJson.mdlEndLenCnt
                    : 0
                getJson.mdlLenCnt = getJson.mdlLenCnt ? getJson.mdlLenCnt : 0
                getJson.colorStaLenCnt = getJson.colorStaLenCnt
                    ? getJson.colorStaLenCnt
                    : 0
                getJson.colorEndLenCnt = getJson.colorEndLenCnt
                    ? getJson.colorEndLenCnt
                    : 0
                getJson.colorLenCnt = getJson.colorLenCnt
                    ? getJson.colorLenCnt
                    : 0
                getJson.serNumStaLenCnt = getJson.serNumStaLenCnt
                    ? getJson.serNumStaLenCnt
                    : 0
                getJson.serNumEndLenCnt = getJson.serNumEndLenCnt
                    ? getJson.serNumEndLenCnt
                    : 0
                getJson.serNumLenCnt = getJson.serNumLenCnt
                    ? getJson.serNumLenCnt
                    : 0
                getJson.prodClCd = getJson.prodClCd ? getJson.prodClCd : ''
                getJson.barCdTypCd = getJson.barCdTypCd
                    ? getJson.barCdTypCd
                    : ''
                getJson.allLenCnt = getJson.allLenCnt ? getJson.allLenCnt : 0
                saveParam.push(getJson)
            }

            for (let idx = 0; idx < gridUpdatedIndexArr.length; idx++) {
                let getJson = this.gridObj.dataProvider.getJsonRow(
                    gridUpdatedIndexArr[idx]
                )
                getJson.mdlStaLenCnt = getJson.mdlStaLenCnt
                    ? getJson.mdlStaLenCnt
                    : 0
                getJson.mdlEndLenCnt = getJson.mdlEndLenCnt
                    ? getJson.mdlEndLenCnt
                    : 0
                getJson.mdlLenCnt = getJson.mdlLenCnt ? getJson.mdlLenCnt : 0
                getJson.colorStaLenCnt = getJson.colorStaLenCnt
                    ? getJson.colorStaLenCnt
                    : 0
                getJson.colorEndLenCnt = getJson.colorEndLenCnt
                    ? getJson.colorEndLenCnt
                    : 0
                getJson.colorLenCnt = getJson.colorLenCnt
                    ? getJson.colorLenCnt
                    : 0
                getJson.serNumStaLenCnt = getJson.serNumStaLenCnt
                    ? getJson.serNumStaLenCnt
                    : 0
                getJson.serNumEndLenCnt = getJson.serNumEndLenCnt
                    ? getJson.serNumEndLenCnt
                    : 0
                getJson.serNumLenCnt = getJson.serNumLenCnt
                    ? getJson.serNumLenCnt
                    : 0
                getJson.prodClCd = getJson.prodClCd ? getJson.prodClCd : ''
                getJson.barCdTypCd = getJson.barCdTypCd
                    ? getJson.barCdTypCd
                    : ''
                getJson.allLenCnt = getJson.allLenCnt ? getJson.allLenCnt : 0
                getJson.__rowState = 'updated'
                console.log('getJson', getJson)

                saveParam.push(getJson)
            }

            if (saveParam.length < 1) {
                this.showTcComAlert('처리할 대상이 없습니다.')
                return
            }

            this.checkBeforeSave(saveParam)
        },

        // 저장 전 체크
        checkBeforeSave(saveParam) {
            let essentialValue = true
            let isAllLenNull = true // 전체자리수 입력 확인
            let isAllLenCorrect = true // 각 자리수 합과 전체자리수 일치여부 확인
            let isEndBiggerThanNextSta = true // 시작값과 다음 코드 끝값 확인
            let compareEndSta = true // 끝값이 시작값보다 큼 확인

            saveParam.forEach((saveObj) => {
                console.log('saveObj : ', saveObj)
                // 상품구분코드, 바코드유형코드 필수 입력
                if (
                    saveObj.prodClCd == '--선택--' ||
                    saveObj.barCdTypCd == '--선택--'
                ) {
                    essentialValue = false
                }

                // 전체자리수 여부 확인
                if (saveObj.allLenCnt == undefined) {
                    isAllLenNull = false
                    if (!isAllLenNull) {
                        this.showTcComAlert(this.msg['isAllLenNull'])
                    }
                }
                // 전체자리수와 각 자리수 합 일치 확인
                let lenSum =
                    parseInt(saveObj.mdlLenCnt) +
                    parseInt(saveObj.colorLenCnt) +
                    parseInt(saveObj.serNumLenCnt)
                console.log('lenSum : ', lenSum)
                if (saveObj.allLenCnt < lenSum) {
                    console.log('false2 : ', saveObj)
                    isAllLenCorrect = false
                    if (!isAllLenCorrect) {
                        this.showTcComAlert(this.msg['isAllLenCorrect'])
                    }
                }
                // 끝값과 다음 코드 시작값 확인
                //    1. 모델코드 끝 - 색상코드 시작 체크
                if (
                    parseInt(saveObj.mdlEndLenCnt) >=
                    parseInt(saveObj.colorStaLenCnt)
                ) {
                    if (
                        this.calLen(
                            parseInt(saveObj.colorStaLenCnt),
                            parseInt(saveObj.colorEndLenCnt)
                        ) != 0
                    ) {
                        isEndBiggerThanNextSta = false
                        console.log('false3 : ', saveObj)
                        if (!isEndBiggerThanNextSta) {
                            this.showTcComAlert(
                                this.msg['isEndBiggerThanNextSta']
                            )
                        }
                    }
                }
                //    2. 색상코드 끝 - 일련번호 시작 체크
                if (
                    parseInt(saveObj.colorEndLenCnt) >=
                    parseInt(saveObj.serNumStaLenCnt)
                ) {
                    if (
                        this.calLen(
                            parseInt(saveObj.serNumStaLenCnt),
                            parseInt(saveObj.serNumEndLenCnt)
                        ) != 0
                    ) {
                        isEndBiggerThanNextSta = false
                        console.log('false3 : ', saveObj)
                    }
                }

                // 각 코드별 끝값이 시작값보다 큰 지 확인
                let mdl = this.calLen(
                    parseInt(saveObj.mdlStaLenCnt),
                    parseInt(saveObj.mdlEndLenCnt)
                )
                let color = this.calLen(
                    parseInt(saveObj.colorStaLenCnt),
                    parseInt(saveObj.colorEndLenCnt)
                )
                let ser = this.calLen(
                    parseInt(saveObj.serNumStaLenCnt),
                    parseInt(saveObj.serNumEndLenCnt)
                )
                if (mdl == 'X' || color == 'X' || ser == 'X') {
                    compareEndSta = false
                    console.log('false4 : ', saveObj)
                    if (!compareEndSta) {
                        this.showTcComAlert(this.msg['compareEndSta'])
                    }
                }
            })

            if (!essentialValue) {
                this.showTcComAlert(
                    '상품구분코드, 바코드유형코드 선택은 필수입니다.'
                )
                return
            }

            const isPass =
                isAllLenNull +
                isAllLenCorrect +
                isEndBiggerThanNextSta +
                compareEndSta
            if (isPass == 4) {
                API.saveProductBarcodeList(saveParam).then((result) => {
                    if (null != result && undefined != result) {
                        this.showTcComAlert('정상적으로 처리되었습니다.')
                        // 매핑정보 재조회
                        this.onSearch()
                    } else {
                        this.showTcComAlert(
                            '동일한 상품구분, 바코드유형, 전체자리수를 가진 바코드가 존재합니다.'
                        )
                    }
                })
            }
        },

        //삭제 버튼 이벤트
        // onDelete: function () {
        //     let delParam = {
        //         prodClCd: this.selectedJsonData.prodClCd
        //             ? this.selectedJsonData.prodClCd
        //             : '',
        //         barCdTypCd: this.selectedJsonData.barCdTypCd
        //             ? this.selectedJsonData.barCdTypCd
        //             : '',
        //         allLenCnt: this.selectedJsonData.allLenCnt
        //             ? this.selectedJsonData.allLenCnt
        //             : '',
        //     }
        //     // this.gridObj.setRows(M_DATA)
        //     API.delProductBarcodeList(delParam).then((resultData) => {
        //         console.log('resultData : ', resultData.length)
        //     })
        // },

        // 초기화
        onResetPage() {
            this.div_search = { prodClCd: '' }
            this.gridData = this.gridSetData()
            this.gridObj.dataProvider.clearRows()
        },

        // 그리드에 상품구분, 바코드유형명 dropdown셋팅 공통코드 api
        async dropDownSetting() {
            console.log('dropDownSetting')
            // 상품구분 set
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00010',
                columnName: 'prodClCd',
            })
            // 바코드유형명 set
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00090',
                columnName: 'barCdTypCd',
            })
        },

        async dropDownCmmonCodes({ key, columnName, option }) {
            let result = await API.dropDownCmmonCodes_(key)
            if (columnName == 'prodClCd') {
                this.prodClCdList = result
            }
            if (columnName == 'barCdTypCd') {
                this.barCdTypCdList = result
            }

            let values = []
            let labels = []
            values = result.map((a) => a.commCdVal)
            labels = result.map((a) => a.commCdValNm)
            if (option != undefined) {
                values.unshift('')
                labels.unshift(option)
            }
            if (columnName == 'prodClCd') {
                let col1 = this.gridObj.gridView.columnByName(columnName)
                col1.values = values
                col1.labels = labels
                this.gridObj.gridView.setColumn(col1)
            }

            if (columnName == 'barCdTypCd') {
                let col1 = this.gridObj.gridView.columnByName(columnName)
                col1.values = values
                col1.labels = labels
                this.gridObj.gridView.setColumn(col1)
            }
        },

        // 추가근무지 목록 - 행추가
        btn_add_OnClick() {
            this.gridObj.gridView.commit()
            let rowData = {
                prodClCd: '--선택--',
                barCdTypCd: '--선택--',
                __rowState: 'created',
            }
            this.gridObj.dataProvider.insertRow(0, rowData)
        },

        //추가근무지 목록 - 행삭제
        btn_del_OnClick() {
            this.gridObj.gridView.commit()

            const row = this.gridObj.gridView.getCurrent().dataRow
            const selected = this.gridObj.dataProvider.getJsonRow(row)

            if (selected.__rowState != 'created') {
                this.showTcComAlert('기등록된 데이터는 삭제할 수 없습니다.') //MSG_01005
                return
            }

            this.gridObj.dataProvider.removeRow(row)
        },
    },

    // // 엔터 키로 조회
    // onKeyDown(grid, event) {
    //     if (event.key == 'Enter') {
    //         this.gridObj.gridView.commit()
    //         this.onSearch()
    //     }
    // },
}
</script>
