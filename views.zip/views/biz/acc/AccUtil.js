import _ from 'lodash'
import moment from 'moment'
export default {
    isEmpty: function (s) {
        if (!s && _.isEmpty(s)) {
            return true
        }
        return false
    },
    emptyCommaByNumber: function (s) {
        if (this.isEmpty(s)) {
            return s
        } else {
            return s.replace(/,/g, '')
        }
    },
    stringToDateFormat: function (d) {
        var sDate = ''
        if (d) {
            sDate = moment(d).add(1, 'days').format('YYYY-MM-DD')
        }

        return sDate
    },
    dateToFormat: function (d, format) {
        return moment(d).format(format)
    },
}
