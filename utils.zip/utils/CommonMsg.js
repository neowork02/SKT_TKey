/*****************************************
 * 업무그룹명: 공통업무
 * 서브업무명: 공통 메세지 Utility
 * 설명: 메세지 관련된 Util
 * 작성자: 홍길동
 * 작성일: 2022.02.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
 *****************************************/
import { msgTxt } from '@/const/msg.Properties.js'
import store from '@/store'
export default {
    /*************************************************
     * 콘솔 로그(사용하지않음)
     * attr1 메세지
     * attr2 메세지2
     *************************************************/
    $_log() {},

    getMessage(sFixedMsg, sMsgStr) {
        const FV_STR_MSG_KEY = ';'
        // param 이 없을 경우.
        //[code]
        if (sMsgStr == null) {
            return msgTxt[sFixedMsg]
        }
        let arrMsg = msgTxt[sFixedMsg].split('%s')
        let arrValue = sMsgStr.split(FV_STR_MSG_KEY)
        let nMsgLength = arrMsg.length
        if (nMsgLength != arrValue.length + 1) {
            store.dispatch('showTcComAlert', {
                message: msgTxt['MSG_00986'],
                options: {
                    header: '시스템메세지',
                    size: '500',
                    confirmLabel: 'OK',
                },
            })
            return
        }
        let sResult = ''
        for (let i = 0; i < nMsgLength; i++) {
            sResult += arrMsg[i] + (arrValue[i] == undefined ? '' : arrValue[i])
        }
        return sResult
    },
}
