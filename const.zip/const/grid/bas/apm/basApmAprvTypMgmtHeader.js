import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'pagingSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuGrpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuUrl1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqAuthNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuNm2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'menuUrl2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvAuthNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvApiUrl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqMenuNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqAuthCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvMenuNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvAuthCd',
            dataType: ValueType.TEXT,
        },
        { fieldName: 'aprvDtlInfo01', dataType: ValueType.TEXT }, // 추가정보01
        { fieldName: 'aprvDtlInfo02', dataType: ValueType.TEXT }, // 추가정보02
        { fieldName: 'aprvDtlInfo03', dataType: ValueType.TEXT }, // 추가정보03
        { fieldName: 'aprvDtlInfo04', dataType: ValueType.TEXT }, // 추가정보04
        { fieldName: 'aprvDtlInfo05', dataType: ValueType.TEXT }, // 추가정보05
        { fieldName: 'aprvDtlInfo06', dataType: ValueType.TEXT }, // 추가정보06
        { fieldName: 'aprvDtlInfo07', dataType: ValueType.TEXT }, // 추가정보07
        { fieldName: 'aprvDtlInfo08', dataType: ValueType.TEXT }, // 추가정보08
        { fieldName: 'aprvDtlInfo09', dataType: ValueType.TEXT }, // 추가정보09
        { fieldName: 'aprvDtlInfo10', dataType: ValueType.TEXT }, // 추가정보10
        { fieldName: 'aprvDtlInfo11', dataType: ValueType.TEXT }, // 추가정보11
        { fieldName: 'aprvDtlInfo12', dataType: ValueType.TEXT }, // 추가정보12
        { fieldName: 'aprvDtlInfo13', dataType: ValueType.TEXT }, // 추가정보13
        { fieldName: 'aprvDtlInfo14', dataType: ValueType.TEXT }, // 추가정보14
        { fieldName: 'aprvDtlInfo15', dataType: ValueType.TEXT }, // 추가정보15
        { fieldName: 'aprvDtlInfo16', dataType: ValueType.TEXT }, // 추가정보16
        { fieldName: 'aprvDtlInfo17', dataType: ValueType.TEXT }, // 추가정보17
        { fieldName: 'aprvDtlInfo18', dataType: ValueType.TEXT }, // 추가정보18
        { fieldName: 'aprvDtlInfo19', dataType: ValueType.TEXT }, // 추가정보19
        { fieldName: 'aprvDtlInfo20', dataType: ValueType.TEXT }, // 추가정보20
        { fieldName: 'aprvDtlInfo21', dataType: ValueType.TEXT }, // 추가정보21
        { fieldName: 'aprvDtlInfo22', dataType: ValueType.TEXT }, // 추가정보22
        { fieldName: 'aprvDtlInfo23', dataType: ValueType.TEXT }, // 추가정보23
        { fieldName: 'aprvDtlInfo24', dataType: ValueType.TEXT }, // 추가정보24
        { fieldName: 'aprvDtlInfo25', dataType: ValueType.TEXT }, // 추가정보25
        { fieldName: 'aprvDtlInfo26', dataType: ValueType.TEXT }, // 추가정보26
        { fieldName: 'aprvDtlInfo27', dataType: ValueType.TEXT }, // 추가정보27
        { fieldName: 'aprvDtlInfo28', dataType: ValueType.TEXT }, // 추가정보28
        { fieldName: 'aprvDtlInfo29', dataType: ValueType.TEXT }, // 추가정보29
        { fieldName: 'aprvDtlInfo30', dataType: ValueType.TEXT }, // 추가정보30
    ],
    columns: [
        {
            name: 'pagingSeq',
            fieldName: 'pagingSeq',
            header: {
                text: 'No.',
            },
            editable: false,
            width: 40,
        },
        {
            name: 'aprvTypCd',
            fieldName: 'aprvTypCd',
            header: {
                text: '승인유형코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'menuGrpNm',
            fieldName: 'menuGrpNm',
            header: {
                text: '업무구분',
            },
            editable: false,
        },
        {
            name: 'aprvTypNm',
            fieldName: 'aprvTypNm',
            header: {
                text: '승인유형명',
            },
            editable: false,
            width: 120,
        },
        {
            name: 'menuNm1',
            fieldName: 'menuNm1',
            header: {
                text: '요청화면',
            },
            editable: false,
            width: 160,
        },
        {
            name: 'menuUrl1',
            fieldName: 'menuUrl1',
            header: {
                text: '요청화면URL',
            },
            editable: false,
            width: 200,
            styleName: 'left-column',
        },
        {
            name: 'reqAuthNm',
            fieldName: 'reqAuthNm',
            header: {
                text: '요청화면속성',
            },
            editable: false,
            width: 120,
        },
        {
            name: 'menuNm2',
            fieldName: 'menuNm2',
            header: {
                text: '승인화면명',
            },
            editable: false,
            width: 160,
        },
        {
            name: 'menuUrl2',
            fieldName: 'menuUrl2',
            header: {
                text: '승인화면URL',
            },
            editable: false,
            width: 200,
            styleName: 'left-column',
        },
        {
            name: 'aprvAuthNm',
            fieldName: 'aprvAuthNm',
            header: {
                text: '승인화면속성',
            },
            editable: false,
            width: 120,
        },
        {
            name: 'aprvApiUrl',
            fieldName: 'aprvApiUrl',
            header: {
                text: '승인API',
            },
            editable: false,
            width: 300,
            styleName: 'left-column',
        },
        {
            name: 'reqMenuNo',
            fieldName: 'reqMenuNo',
            header: {
                text: '요청화면번호',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'reqAuthCd',
            fieldName: 'reqAuthCd',
            header: {
                text: '요청화면속성코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'aprvMenuNo',
            fieldName: 'aprvMenuNo',
            header: {
                text: '승인화면번호',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'aprvAuthCd',
            fieldName: 'aprvAuthCd',
            header: {
                text: '승인화면속성코드',
            },
            editable: false,
            visible: false,
        },
        {
            name: 'aprvDtlInfo01',
            fieldName: 'aprvDtlInfo01',
            header: { text: '추가정보01' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo02',
            fieldName: 'aprvDtlInfo02',
            header: { text: '추가정보02' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo03',
            fieldName: 'aprvDtlInfo03',
            header: { text: '추가정보03' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo04',
            fieldName: 'aprvDtlInfo04',
            header: { text: '추가정보04' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo05',
            fieldName: 'aprvDtlInfo05',
            header: { text: '추가정보05' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo06',
            fieldName: 'aprvDtlInfo06',
            header: { text: '추가정보06' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo07',
            fieldName: 'aprvDtlInfo07',
            header: { text: '추가정보07' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo08',
            fieldName: 'aprvDtlInfo08',
            header: { text: '추가정보08' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo09',
            fieldName: 'aprvDtlInfo09',
            header: { text: '추가정보09' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo10',
            fieldName: 'aprvDtlInfo10',
            header: { text: '추가정보10' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo11',
            fieldName: 'aprvDtlInfo11',
            header: { text: '추가정보11' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo12',
            fieldName: 'aprvDtlInfo12',
            header: { text: '추가정보12' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo13',
            fieldName: 'aprvDtlInfo13',
            header: { text: '추가정보13' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo14',
            fieldName: 'aprvDtlInfo14',
            header: { text: '추가정보14' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo15',
            fieldName: 'aprvDtlInfo15',
            header: { text: '추가정보15' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo16',
            fieldName: 'aprvDtlInfo16',
            header: { text: '추가정보16' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo17',
            fieldName: 'aprvDtlInfo17',
            header: { text: '추가정보17' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo18',
            fieldName: 'aprvDtlInfo18',
            header: { text: '추가정보18' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo19',
            fieldName: 'aprvDtlInfo19',
            header: { text: '추가정보19' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo20',
            fieldName: 'aprvDtlInfo20',
            header: { text: '추가정보20' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo21',
            fieldName: 'aprvDtlInfo21',
            header: { text: '추가정보21' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo22',
            fieldName: 'aprvDtlInfo22',
            header: { text: '추가정보22' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo23',
            fieldName: 'aprvDtlInfo23',
            header: { text: '추가정보23' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo24',
            fieldName: 'aprvDtlInfo24',
            header: { text: '추가정보24' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo25',
            fieldName: 'aprvDtlInfo25',
            header: { text: '추가정보25' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo26',
            fieldName: 'aprvDtlInfo26',
            header: { text: '추가정보26' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo27',
            fieldName: 'aprvDtlInfo27',
            header: { text: '추가정보27' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo28',
            fieldName: 'aprvDtlInfo28',
            header: { text: '추가정보28' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo29',
            fieldName: 'aprvDtlInfo29',
            header: { text: '추가정보29' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo30',
            fieldName: 'aprvDtlInfo30',
            header: { text: '추가정보30' },
            editable: false,
            visible: true,
        },
    ],
}
