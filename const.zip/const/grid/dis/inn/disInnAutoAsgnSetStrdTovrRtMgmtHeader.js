import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점명
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분명
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT, //입력사용자ID
        },
        {
            fieldName: 'effStaDt1',
            dataType: ValueType.TEXT, //1구간 유효시작일
        },
        {
            fieldName: 'effEndDt1',
            dataType: ValueType.TEXT, //1구간 유효종료일
        },
        {
            fieldName: 'tovrRng1',
            dataType: ValueType.TEXT, //1구간
        },
        {
            fieldName: 'tovrDt1',
            dataType: ValueType.TEXT, //1구간 기준회전일
        },
        {
            fieldName: 'tovrDayCnt1',
            dataType: ValueType.TEXT, //1구간 회전일
        },
        {
            fieldName: 'tovrSeq1',
            dataType: ValueType.TEXT, //1구간 시퀀스
        },
        {
            fieldName: 'tovrFlag1',
            dataType: ValueType.TEXT, //1구간 변경여부 확인 FLAG
        },
        {
            fieldName: 'effStaDt2',
            dataType: ValueType.TEXT, //2구간 유효시작일
        },
        {
            fieldName: 'effEndDt2',
            dataType: ValueType.TEXT, //2구간 유효종료일
        },
        {
            fieldName: 'tovrRng2',
            dataType: ValueType.TEXT, //2구간
        },
        {
            fieldName: 'tovrDt2',
            dataType: ValueType.TEXT, //2구간 기준회전일
        },
        {
            fieldName: 'tovrDayCnt2',
            dataType: ValueType.TEXT, //2구간 회전일
        },
        {
            fieldName: 'tovrSeq2',
            dataType: ValueType.TEXT, //2구간 시퀀스
        },
        {
            fieldName: 'tovrFlag2',
            dataType: ValueType.TEXT, //2구간 변경여부 확인 FLAG
        },
        {
            fieldName: 'effStaDt3',
            dataType: ValueType.TEXT, //3구간 유효시작일
        },
        {
            fieldName: 'effEndDt3',
            dataType: ValueType.TEXT, //3구간 유효종료일
        },
        {
            fieldName: 'tovrRng3',
            dataType: ValueType.TEXT, //3구간
        },
        {
            fieldName: 'tovrDt3',
            dataType: ValueType.TEXT, //3구간 기준회전일
        },
        {
            fieldName: 'tovrDayCnt3',
            dataType: ValueType.TEXT, //3구간 회전일
        },
        {
            fieldName: 'tovrSeq3',
            dataType: ValueType.TEXT, //3구간 시퀀스
        },
        {
            fieldName: 'tovrFlag3',
            dataType: ValueType.TEXT, //3구간 변경여부 확인 FLAG
        },
        {
            fieldName: 'effStaDt4',
            dataType: ValueType.TEXT, //4구간 유효시작일
        },
        {
            fieldName: 'effEndDt4',
            dataType: ValueType.TEXT, //4구간 유효종료일
        },
        {
            fieldName: 'tovrRng4',
            dataType: ValueType.TEXT, //4구간
        },
        {
            fieldName: 'tovrDt4',
            dataType: ValueType.TEXT, //4구간 기준회전일
        },
        {
            fieldName: 'tovrDayCnt4',
            dataType: ValueType.TEXT, //4구간 회전일
        },
        {
            fieldName: 'tovrSeq4',
            dataType: ValueType.TEXT, //4구간 시퀀스
        },
        {
            fieldName: 'tovrFlag4',
            dataType: ValueType.TEXT, //4구간 변경여부 확인 FLAG
        },
        {
            fieldName: 'effStaDt5',
            dataType: ValueType.TEXT, //5구간 유효시작일
        },
        {
            fieldName: 'effEndDt5',
            dataType: ValueType.TEXT, //5구간 유효종료일
        },
        {
            fieldName: 'tovrRng5',
            dataType: ValueType.TEXT, //5구간
        },
        {
            fieldName: 'tovrDt5',
            dataType: ValueType.TEXT, //5구간 기준회전일
        },
        {
            fieldName: 'tovrDayCnt5',
            dataType: ValueType.TEXT, //5구간 회전일
        },
        {
            fieldName: 'tovrSeq5',
            dataType: ValueType.TEXT, //5구간 시퀀스
        },
        {
            fieldName: 'tovrFlag5',
            dataType: ValueType.TEXT, //5구간 변경여부 확인 FLAG
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT, //요청자ID
        },
        {
            fieldName: 'tovrRng',
            dataType: ValueType.TEXT, //구간
        },
        {
            fieldName: 'tovrSeq',
            dataType: ValueType.TEXT, //시퀀스
        },
        {
            fieldName: 'tovrDayCnt',
            dataType: ValueType.TEXT, //회전일
        },
        {
            fieldName: 'effStaDt',
            dataType: ValueType.TEXT, //유효시작일
        },
        {
            fieldName: 'effEndDt',
            dataType: ValueType.TEXT, //유효종료일
        },
        {
            fieldName: 'tovrFlag',
            dataType: ValueType.TEXT, //변경여부 확인 FLAG
        },
    ],
    columns: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'D코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분명',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입력사용자ID',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'effStaDt1',
            fieldName: 'effStaDt1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '1구간 유효시작일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'effEndDt1',
            fieldName: 'effEndDt1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '1구간 유효종료일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrRng1',
            fieldName: 'tovrRng1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '1구간',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrDt1',
            fieldName: 'tovrDt1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '1구간',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'tovrDayCnt1',
            fieldName: 'tovrDayCnt1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '회전일',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
        },
        {
            name: 'tovrSeq1',
            fieldName: 'tovrSeq1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '1구간 시퀀스',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrFlag1',
            fieldName: 'tovrFlag1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '1구간 변경여부 확인 FLAG',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'effStaDt2',
            fieldName: 'effStaDt2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '2구간 유효시작일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'effEndDt2',
            fieldName: 'effEndDt2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '2구간 유효종료일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrRng2',
            fieldName: 'tovrRng2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '2구간',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrDt2',
            fieldName: 'tovrDt2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '2구간',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'tovrDayCnt2',
            fieldName: 'tovrDayCnt2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '회전일',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
        },
        {
            name: 'tovrSeq2',
            fieldName: 'tovrSeq2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '2구간 시퀀스',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrFlag2',
            fieldName: 'tovrFlag2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '2구간 변경여부 확인 FLAG',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'effStaDt3',
            fieldName: 'effStaDt3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '3구간 유효시작일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'effEndDt3',
            fieldName: 'effEndDt3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '3구간 유효종료일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrRng3',
            fieldName: 'tovrRng3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '3구간',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrDt3',
            fieldName: 'tovrDt3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '3구간',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'tovrDayCnt3',
            fieldName: 'tovrDayCnt3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '회전일',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
        },
        {
            name: 'tovrSeq3',
            fieldName: 'tovrSeq3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '3구간 시퀀스',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrFlag3',
            fieldName: 'tovrFlag3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '3구간 변경여부 확인 FLAG',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'effStaDt4',
            fieldName: 'effStaDt4',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '4구간 유효시작일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'effEndDt4',
            fieldName: 'effEndDt4',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '4구간 유효종료일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrRng4',
            fieldName: 'tovrRng4',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '4구간',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrDt4',
            fieldName: 'tovrDt4',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '4구간',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'tovrDayCnt4',
            fieldName: 'tovrDayCnt4',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '회전일',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
        },
        {
            name: 'tovrSeq4',
            fieldName: 'tovrSeq4',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '4구간 시퀀스',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrFlag4',
            fieldName: 'tovrFlag4',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '4구간 변경여부 확인 FLAG',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'effStaDt5',
            fieldName: 'effStaDt5',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '5구간 유효시작일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'effEndDt5',
            fieldName: 'effEndDt5',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '5구간 유효종료일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrRng5',
            fieldName: 'tovrRng5',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '5구간',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrDt5',
            fieldName: 'tovrDt5',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '5구간',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'tovrDayCnt5',
            fieldName: 'tovrDayCnt5',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '회전일',
                showTooltip: false,
            },
            editor: {
                type: 'number',
            },
        },
        {
            name: 'tovrSeq5',
            fieldName: 'tovrSeq5',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '5구간 시퀀스',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'tovrFlag5',
            fieldName: 'tovrFlag5',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '5구간 변경여부 확인 FLAG',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
    ],
    layout: [
        'NO',
        'agencyCd',
        'agencyNm',
        {
            name: 'standard',
            direction: 'horizontal',
            items: [
                'effStaDt1',
                'effEndDt1',
                'tovrRng1',
                'tovrDt1',
                'tovrDayCnt1',
                'tovrSeq1',
                'tovrFlag1',
                'effStaDt2',
                'effEndDt2',
                'tovrRng2',
                'tovrDt2',
                'tovrDayCnt2',
                'tovrSeq2',
                'tovrFlag2',
                'effStaDt3',
                'effEndDt3',
                'tovrRng3',
                'tovrDt3',
                'tovrDayCnt3',
                'tovrSeq3',
                'tovrFlag3',
                'effStaDt4',
                'effEndDt4',
                'tovrRng4',
                'tovrDt4',
                'tovrDayCnt4',
                'tovrSeq4',
                'tovrFlag4',
                'effStaDt5',
                'effEndDt5',
                'tovrRng5',
                'tovrDt5',
                'tovrDayCnt5',
                'tovrSeq5',
                'tovrFlag5',
            ],
            header: { text: '기준회전일' },
        },
    ],
}
