import _ from 'lodash'
import moment from 'moment'
import store from '@/store'
import attachedFileApi from '@/api/common/attachedFile'

import send from '@/api/axios-tdcs'

let gridObj = null

let headerObj = {
    '01B': 'prodNm',
    '01P': 'svcNm',
    '01V': 'svcNm',
    '01FA': 'prodNm',
    '01FB': 'prodNm',
    '02D': 'dealSktCd',
    '05P': 'prcNm',
    '05PF': 'prcNm',
    '06V1': 'suplSvcNm',
    '06V2': 'suplSvcNm',
    '06V3': 'suplSvcNm',
    '06V4': 'suplSvcNm',
}

let wireHeaderObj = {
    '01': ['itnProdNm', 'tvProdNm'],
    '02': 'dealSktCd',
    '03E': 'prodNm',
    '03P': 'priceNm',
}

export default {
    //상세조회시 날짜변환
    convertDate(val, flag) {
        if (!_.isEmpty(val)) {
            if (_.isEqual(flag, 'ymd')) {
                let date = []

                date[0] = moment(val[0].substr(0, 8), 'YYYYMMDD').format(
                    'YYYY-MM-DD'
                )
                date[1] = moment(val[1].substr(0, 8), 'YYYYMMDD').format(
                    'YYYY-MM-DD'
                )

                return date
            } else if (_.isEqual(flag, 'hh')) {
                return val.substr(8, 2)
            } else if (_.isEqual(flag, 'mm')) {
                return val.substr(10, 2)
            } else if (_.isEqual(flag, 'ss')) {
                return val.substr(12, 2)
            } else if (_.isEqual(flag, 'ym')) {
                return moment(val).format('YYYY-MM')
            }
        }
    },
    //양식다운로드
    tempExcelDown(val) {
        console.log('PolUtil tempExcelDown')
        attachedFileApi.downloadSampleFile(val)
    },
    //엑셀업로드
    excelUpload(that) {
        console.log('PolUtil excelUploadBtn')
        that.$refs.fileInput.fileInputClick()
    },
    //엑셀다운로드
    excelDownload(param, flag) {
        let url = ''

        if (!_.isEmpty(flag)) {
            url = `/api/v1/backend-max/resource/pol/${flag}/get-excel-down-list`
        } else {
            url = '/api/v1/backend-max/resource/pol/ict/get-excel-down-list'
        }

        console.log('PolUtil excelDownload')
        attachedFileApi.downLoadFile(url, param)
    },
    //엑셀파일 읽기
    excelUploadFile(that, flag, site, files, grade) {
        console.log('PolUtil excelUploadFile')
        const f = files
        if (!_.isUndefined(f) && !_.isNull(f)) {
            let extension = f.name.substr(f.name.lastIndexOf('.') + 1)
            if (
                !extension.toLowerCase().includes('xls') ||
                !extension.toLowerCase().includes('xlsx')
            ) {
                store.dispatch('showTcComAlert', {
                    message: '엑셀파일을 업로드해야 합니다.',
                    options: {
                        header: '알림',
                        size: '550',
                        confirmLabel: 'OK',
                    },
                })
                that.$refs.fileInput.clearFileInputValue()
                return
            }

            //엑셀 복호화
            this.parseExcelFile(flag, files, grade, site)
                .then((result) => {
                    this.getJsonData(that, flag, site, result, grade)
                })
                .catch(() => {
                    that.$refs.fileInput.clearFileInputValue()
                })
        }
    },
    parseExcelFile(flag, files, grade, site) {
        const formData = new FormData()
        formData.append('files', files)
        formData.append('excelType', flag)
        formData.append('gradeAplyCd', grade ? 'Y' : 'N')

        return send({
            method: 'post',
            url: `/api/v1/backend-max/pol/${site}/parse-excel-file`,
            data: formData,
        })
    },
    //엑셀파일을 그리드로 변환
    getJsonData(that, flag, site, data, grade) {
        if (!_.isEmpty(data)) {
            let jsonData = []

            if (_.isEqual(site, 'ict') || _.isEqual(site, 'cms')) {
                jsonData = data.filter((f) => f[headerObj[flag]])

                //업로드 건수 제한
                if (_.isEqual(flag, '01FA') || _.isEqual(flag, '01FB')) {
                    if (jsonData.length > 100) {
                        store.dispatch('showTcComAlert', {
                            message: '파일업로드 최대 건수는 100건입니다.',
                            options: {
                                header: '알림',
                                size: '550',
                                confirmLabel: 'OK',
                            },
                        })
                        that.$refs.fileInput.clearFileInputValue()
                        return
                    }
                }

                //무선정책 중복 확인
                if (!this.findDuplicates(that, flag, jsonData)) return
                //엑셀업로드 그리드 설정
                this.findGridObj(that, flag, grade)
            } else if (_.isEqual(site, 'icb') || _.isEqual(site, 'cmb')) {
                jsonData = data.filter((f) => f[wireHeaderObj[flag]])
                //유선정책 중복 확인
                if (!this.findDuplicatesWire(that, flag, jsonData)) return
                //엑셀업로드 그리드 설정
                this.findGridObjWire(that, flag, grade)
            }

            gridObj.dataProvider.fillJsonData(jsonData, {})
        }

        that.$refs.fileInput.clearFileInputValue()

        if (!_.isEmpty(data)) {
            that.onVerify()
        }
    },
    findDuplicates(that, flag, arr) {
        let check = arr
            .map((m) => m[headerObj[flag]])
            .filter((f) => !_.isEmpty(f))

        if (check.length === 0) {
            store.dispatch('showTcComAlert', {
                message: '업로드 파일을 확인하기 바랍니다. ',
                options: {
                    header: '알림',
                    size: '550',
                    confirmLabel: 'OK',
                },
            })

            that.$refs.fileInput.clearFileInputValue()

            return false
        }

        let data = arr.map((m) => m[headerObj[flag]].trim())

        let dupData = data.filter((s, i) => data.indexOf(s) != i)

        if (dupData.length > 0) {
            store.dispatch('showTcComAlert', {
                message:
                    '업로드 파일에 [ ' + dupData[0] + ' ] 중복 되었습니다. ',
                options: {
                    header: '알림',
                    size: '550',
                    confirmLabel: 'OK',
                },
            })

            that.$refs.fileInput.clearFileInputValue()

            return false
        } else {
            return true
        }
    },
    findDuplicatesWire(that, flag, arr) {
        let check = arr
            .map((m) => m[wireHeaderObj[flag]])
            .filter((f) => !_.isEmpty(f))

        if (check.length === 0) {
            store.dispatch('showTcComAlert', {
                message: '업로드 파일을 확인하기 바랍니다. ',
                options: {
                    header: '알림',
                    size: '550',
                    confirmLabel: 'OK',
                },
            })

            that.$refs.fileInput.clearFileInputValue()

            return false
        }

        let data = arr.map((m) => m[wireHeaderObj[flag]])

        let dupData = data.filter((s, i) => data.indexOf(s) != i)

        if (dupData.length > 0) {
            store.dispatch('showTcComAlert', {
                message:
                    '업로드 파일에 [ ' + dupData[0] + ' ] 중복 되었습니다. ',
                options: {
                    header: '알림',
                    size: '550',
                    confirmLabel: 'OK',
                },
            })

            that.$refs.fileInput.clearFileInputValue()

            return false
        } else {
            return true
        }
    },
    findGridObj(that, flag, grade) {
        switch (flag) {
            case '01P': //요금제정책
                gridObj = that.gridObjRight

                break
            case '01V': //부가서비스정책
                if (!grade) {
                    gridObj = that.gridObjRight
                } else {
                    gridObj = that.gridObjGradeLeft
                }

                break
            case '01FA': //파일업로드정책
                gridObj = that.gridObjA

                break
            case '01FB': //파일업로드정책
                gridObj = that.gridObjB

                break
            case '02D': //대상조직개별매장
                gridObj = that.gridObjRightDeal

                break
            case '05P': //요금제조건
                gridObj = that.gridObjRight

                break
            case '05PF': //요금제조건
                gridObj = that.gridObjRightFee

                break
            case '06V1': //부가조건 부가상품1
                gridObj = that.gridObj1

                break
            case '06V2': //부가조건 부가상품2
                gridObj = that.gridObj2

                break
            case '06V3': //부가조건 부가상품3
                gridObj = that.gridObj3

                break
            case '06V4': //부가조건 부가정책
                gridObj = that.gridObj4

                break
            default: //기본단가정책
                if (!grade) {
                    gridObj = that.gridObjRight
                } else {
                    gridObj = that.gridObjGradeLeft
                }

                break
        }
    },
    findGridObjWire(that, flag, grade) {
        switch (flag) {
            case '02': //대상조직
                gridObj = that.gridDealRight

                break
            case '03E': //무선조건 단말기
                gridObj = that.gridEqpDown

                break
            case '03P': //무선조건 요금제그룹(ID)
                gridObj = that.gridPriceDown

                break
            default: //메인정책
                if (!grade) {
                    gridObj = that.gridResult
                } else {
                    gridObj = that.gridProdGrade
                }
                break
        }
    },
}
