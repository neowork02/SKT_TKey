export default {
    //alert message
    alertShow: false,
    alertHeaderText: '',
    alertBodyText: '',
    loadingShow: false,
    snackbar: false,
    snackbarText: '',
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 100,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 100, //전체 조회
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    saveAction: false,
    saveDoneA: false,
    saveDoneB: false,
    moveStore: '',
    execListSave: '',

    commDropDown: {},

    commCdIds: [],
    resultList: [],
    resultListCopy: [],
    resultDetailList: [],
    resultDetailAllList: [],
    resultExecList: [],

    searchParams: {},
    selectedRow: {},
    checkRefresh: false,
    checkedRows: [],
}
