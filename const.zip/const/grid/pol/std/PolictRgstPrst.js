import { ValueType } from 'realgrid'

export let GRID_INFO_TAB01 = {
    fields: [
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ictBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ictFile',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsBase',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFee',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsVas',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsServ',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmsFile',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
            footer: {
                text: '합계',
            },
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            width: '100',
            header: {
                text: '정책등록일자',
                showTooltip: false,
            },
            styleName: 'left-column',
            datetimeFormat: 'yyyy-MM-dd',
            editable: false,
            footer: {
                text: '합계',
            },
        },
        {
            name: 'ictBase',
            fieldName: 'ictBase',
            type: 'data',
            header: {
                text: '기본단가정책_건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFee',
            fieldName: 'ictFee',
            type: 'data',
            header: {
                text: '요금제정책_건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictVas',
            fieldName: 'ictVas',
            type: 'data',
            header: {
                text: 'VAS정책_건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictServ',
            fieldName: 'ictServ',
            type: 'data',
            header: {
                text: '서비스별단가정책_건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'ictFile',
            fieldName: 'ictFile',
            type: 'data',
            header: {
                text: '파일업로드정책_건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsBase',
            fieldName: 'cmsBase',
            type: 'data',
            header: {
                text: '기본단가정책_건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFee',
            fieldName: 'cmsFee',
            type: 'data',
            header: {
                text: '요금제정책_건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsVas',
            fieldName: 'cmsVas',
            type: 'data',
            header: {
                text: 'VAS정책_건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsServ',
            fieldName: 'cmsServ',
            type: 'data',
            header: {
                text: '서비스별단가정책_건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'cmsFile',
            fieldName: 'cmsFile',
            type: 'data',
            header: {
                text: '파일업로드정책_건수',
                showTooltip: false,
            },
            editable: false,
            numberFormat: '#,##0',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
            },
        },
    ],
}
