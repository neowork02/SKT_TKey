import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'lvOrgCd', // 레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm', // 레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd1', // 레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1', // 레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd2', // 레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2', // 레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd3', // 레벨3조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm3', // 레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoShopCd', // 거래처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd', // 거래처구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm', // 거래처구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsDt', // 상태변경일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmCd', // 전송구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmNm', // 전송구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqYn', // 요청여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqDtm', // 요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsYn', // 확정여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsYnNm', // 확정여부명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsDtm', // 전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskAmt', // 사고금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rmks', // ERROR LOG
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyCd', // SKT대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId', // 요청사용자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserNm', // 요청사용자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chk', // 체크
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // UPD_CNT
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'dealcoShopCd',
            fieldName: 'dealcoShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매장코드',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처코드',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처명',
        },
        {
            name: 'dealcoClNm',
            fieldName: 'dealcoClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처구분',
        },
        {
            name: 'trmsDt',
            fieldName: 'trmsDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상태변경일',
        },
        {
            name: 'trmsItmNm',
            fieldName: 'trmsItmNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '전송구분',
        },
        {
            name: 'riskAmt',
            fieldName: 'riskAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '사고금액',
        },
        {
            name: 'trmsReqYn',
            fieldName: 'trmsReqYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청여부',
        },
        {
            name: 'trmsReqDtm',
            fieldName: 'trmsReqDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '요청일시',
        },
        {
            name: 'reqUserId',
            fieldName: 'reqUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청사용자ID',
        },
        {
            name: 'reqUserNm',
            fieldName: 'reqUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '요청사용자명',
        },
        {
            name: 'trmsYnNm',
            fieldName: 'trmsYnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '확정여부명',
        },
        {
            name: 'trmsDtm',
            fieldName: 'trmsDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: 'ERROR LOG',
        },
    ],
}
