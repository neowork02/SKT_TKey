import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('tkp.uki.nsokSalePrstStore', Object.keys(state)),
    ...mapGetters('tkp.uki.nsokSalePrstStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('tkp.uki.nsokSalePrstStore', Object.keys(actions)),
    ...mapMutations('tkp.uki.nsokSalePrstStore', Object.keys(mutations)),
}
