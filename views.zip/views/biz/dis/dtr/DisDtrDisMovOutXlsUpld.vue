<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 재고이동엑셀업로드[DISDTR01300]
 * 설명: 재고이동을 엑셀업로드한다.
 * 작성자: P179229
 * 작성일: 2022.06.27
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>재고이동출고 엑셀업로드</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="errCheck"
                    :objAuth="this.objAuth"
                    >오류검증</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="errClear"
                    :objAuth="this.objAuth"
                    >오류일괄제거</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="listBtn"
                    :objAuth="this.objAuth"
                >
                    목록
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="입력구분"
                        :itemList="this.excelClCdData"
                        :eRequired="true"
                        :objAuth="objAuth"
                        v-model="reqParam.excelClCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div3">
                    <TCComFileInput
                        v-model="files"
                        labelName="첨부파일"
                        @change="onFilesChange"
                    ></TCComFileInput>
                </div>
                <!-- <div class="formitem div4">
                    <TCComButton
                        :Vuetify="false"
                        eClass="btn_noline btn_ty04"
                        eAttr="ico_exeldown"
                        labelName="양식다운로드"
                        @click="excelTemplateDownBtn"
                    ></TCComButton>
                </div> -->
                <!-- item 1-3 :오른쪽 정렬 버튼 영역 -->
                <div class="formitem div3">
                    <div class="rightArea btn">
                        <span class="inner">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_s btn_ty03"
                                eAttr="ico_save"
                                labelName="양식다운로드"
                                @click="excelTemplateDownBtn"
                            />
                        </span>
                    </div>
                </div>
                <!-- //item 1-3 :오른쪽 정렬 버튼 영역 -->
            </div>
        </div>
        <!-- // Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="재고이동엑셀업로드"
                :gridObj="this.gridObj"
                :isDelRow="true"
                @chkDelRowBtn="gridchkDelRowBtn"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div>
        <!-- //gridWrap -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil, FileUtil } from '@/utils'
import { DisDtrDisMovOutXlsUpldGRID_HEADER } from '@/const/grid/dis/dtr/disDtrMovOutXlsUpldHeader'
import disDtrMovOutXlsUpldApi from '@/api/biz/dis/dtr/disDtrMovOutXlsUpld'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMixin from '@/mixins'
import _ from 'lodash'
import * as XLSX from 'xlsx'

export default {
    name: 'DisDtrDisMovOutXlsUpld',
    mixins: [CommonMixin],
    components: {},
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: DisDtrDisMovOutXlsUpldGRID_HEADER,
            files: null,
            errChk: false,
            reqParam: {
                excelClCd: '301', //입력구분
            },
            excelClCdData: [
                {
                    commCdVal: '301',
                    commCdValNm: '일괄재고이동',
                },
            ],
            listSearch: {},
        }
    },
    computed: {},
    created() {
        // 화면 default설정
        this.defaultSet()
    },
    mounted() {
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        // 리스트 검색조건
        this.listSearch = this.$route.params.search
    },
    methods: {
        defaultSet() {
            this.gridData = this.gridSetData()
        },
        gridSetData: function () {
            // CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(-1, 10, '', '')
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            this.gridObj.gridView.commit()
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
            this.deleleGridData = this.gridData.delRows
        },
        //양식다운로드
        excelTemplateDownBtn() {
            attachedFileApi.downloadSampleFile('106')
        },
        //첨부파일
        onFilesChange(files) {
            // this.excelUploadFile(files)
            this.gridObj.gridInit()
            this.errChk = false

            if (files == null) return

            const form = new FormData()
            form.append('files', files)

            disDtrMovOutXlsUpldApi.parseExcel(form).then((res) => {
                if (res.length == 0) {
                    this.showTcComAlert(
                        '업로드 문서에 처리 할 데이터가 없습니다.\n업로드 문서를 확인하시기 바랍니다.'
                    )
                } else if (res.length > 3000) {
                    this.showTcComAlert(
                        '1회당 업로드 데이터는 3000건까지 가능합니다.'
                    )
                } else {
                    let excelList = []
                    res.forEach((data) => {
                        if (_.isEmpty(data['outSchdDt'])) {
                            data['outSchdDt'] = CommonUtil.getToday()
                        } else {
                            CommonUtil.getDayFormat(
                                data['outSchdDt'],
                                'YYYYMMDD'
                            )
                        }
                        data['excelClCd'] = this.reqParam.excelClCd
                        data['inClCd'] = this.reqParam.inClCd
                        data['prchTypCd'] = this.reqParam.prchTypCd
                        excelList.push(data)
                    })
                    this.gridObj.setRows(excelList)
                }
            })
        },
        excelUploadFile(files) {
            const f = files
            if (!_.isUndefined(f) && !_.isNull(f)) {
                const reader = new FileReader()
                // const name = f.name

                reader.onload = (e) => {
                    const data = e.target.result

                    // Array Buffer인 경우 base64로 변환 처리
                    const arr = FileUtil.arrayBufferFixdata(data)
                    const workbook = XLSX.read(FileUtil.encodeBase64(arr), {
                        type: 'base64',
                        cellText: true,
                        cellDates: true,
                    })
                    // 워크북 처리(1줄 헤더 포함 처리)
                    this.processWorkbook(workbook)
                }
                // binary
                // reader.readAsBinaryString(f)
                // Array Buffer
                reader.readAsArrayBuffer(f)
            }
        },
        // 워크북 처리(1줄 헤더 포함 처리)
        processWorkbook(wb) {
            const output = FileUtil.excelTojson(wb, {
                raw: false,
            })
            const sheetNames = Object.keys(output)
            if (sheetNames.length) {
                const colsObj = output[sheetNames][0]
                if (colsObj) {
                    const data = output[sheetNames]
                    if (data.length > 3000) {
                        this.showTcComAlert(
                            '1회당 업로드 데이터는 3000건까지 가능합니다.'
                        )
                        return
                    }
                    const mappedData = data.map((item) => {
                        return {
                            outSchdDt: CommonUtil.getDayFormat(
                                item['일자'],
                                'YYYYMMDD'
                            ),
                            outDealcoCd: item['출고처 코드'],
                            outDealcoNm: item['출고처명'],
                            inDealcoCd: item['입고처 코드'],
                            inDealcoNm: item['입고처명'],
                            prodCd: item['상품코드'],
                            prodNm: item['상품명'],
                            colorCd: item['색상코드'],
                            colorNm: item['색상명'],
                            serNum: item['일련번호'],
                            amt: item['금액'],
                            inDealcoCrdtLmt: item['입고처여신잔액'],
                            excelClCd: this.reqParam.excelClCd,
                            inClCd: this.reqParam.inClCd,
                            prchTypCd: this.reqParam.prchTypCd,
                        }
                    })
                    this.gridObj.dataProvider.fillJsonData(mappedData, {})
                }
            } else {
                this.showTcComAlert(
                    '업로드 문서에 처리 할 데이터가 없습니다.\n업로드 문서를 확인하시기 바랍니다.'
                )
            }
        },
        //오류검증
        errCheck: function () {
            const rowData = this.gridObj.dataProvider.getOutputRows(
                { datetimeFormat: 'yyyyMMdd' },
                0,
                -1
            )
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
                return
            }
            disDtrMovOutXlsUpldApi
                .chkDisDtrMovOutXlsUpldError(rowData)
                .then((res) => {
                    this.gridObj.setRows(res)
                    this.gridObj.gridView.orderBy(
                        ['errDesc', 'serNum'],
                        ['descending', 'ascending']
                    )
                    this.errChk = true
                })
        },
        //오류일괄변경
        errClear: function () {
            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
                return
            }
            if (_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
            } else {
                this.gridObj.dataProvider.removeRows(this.getErrRow())
                this.gridObj.gridView.commit()
            }
        },
        //저장
        saveBtn: function () {
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('저장할 데이터가 없습니다.')
                return
            }
            if (!this.errChk) {
                this.showTcComAlert('오류검증을 하시기 바랍니다.')
                return
            }
            if (!_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('오류제거를 하시기 바랍니다.')
                return
            }
            this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    disDtrMovOutXlsUpldApi
                        .addDisDtrMovOutXlsUpldXlsUpld(rowData)
                        .then((res) => {
                            if (res === 1) {
                                this.listBtn()
                            }
                        })
                }
            })
        },
        //오류ROW 조회
        getErrRow() {
            let errRow = []
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            rowData.forEach((data, i) => {
                if (!_.isEmpty(_.get(data, 'errDesc'))) {
                    errRow.push(i)
                }
            })
            return errRow
        },
        //목록
        listBtn() {
            this.$router.push({
                name: '/dis/dtr/DisDtrDisMovOut',
                params: { search: this.listSearch },
            })
        },
    },
}
</script>
