<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 재고이동출고[DISDTR00100, DISDTR00400]
 * 설명: 재고이동출고를 조회한다.
 * 작성자: P179229
 * 작성일: 2022.05.23
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>재고이동출고</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="excelUpload"
                    :objAuth="this.objAuth"
                    >엑셀업로드</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="printReport('Y', '')"
                    >출고증</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="sendSms"
                    :objAuth="this.objAuth"
                    >SMS발송</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="dtlBtn"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="출고일"
                        calType="DP"
                        v-model="setDate"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.outOrgNm"
                        :codeVal.sync="reqParam.outOrgCd"
                        labelName="출고조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :eRequired="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        @enterKey="onOutAuthOrgTreeEnterKey"
                        @appendIconClick="onOutAuthOrgTreeIconClick"
                        @input="onOutAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showOutBcoAuthOrgTrees"
                        :parentParam="searchOutAuthOrgTreesForm"
                        :rows="resultOutAuthOrgTreeRows"
                        :dialogShow.sync="showOutBcoAuthOrgTrees"
                        @confirm="onOutAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.outDealcoNm"
                        :codeVal.sync="reqParam.outDealcoCd"
                        labelName="출고처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchDealcosForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        v-model="reqParam.prodClCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00040"
                        labelName="입고여부"
                        v-model="reqParam.inFix"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.inOrgNm"
                        :codeVal.sync="reqParam.inOrgCd"
                        labelName="입고조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onInAuthOrgTreeEnterKey"
                        @appendIconClick="onInAuthOrgTreeIconClick"
                        @input="onInAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showInBcoAuthOrgTrees"
                        :parentParam="searchInAuthOrgTreesForm"
                        :rows="resultInAuthOrgTreeRows"
                        :dialogShow.sync="showInBcoAuthOrgTrees"
                        @confirm="onInAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.inDealcoNm"
                        :codeVal.sync="reqParam.inDealcoCd"
                        placeholder="입력해주세요"
                        labelName="입고처"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onInrDealcosEnterKey"
                        @appendIconClick="onInrDealcosIconClick"
                        @input="onInrDealcosInput"
                    />
                    <BasBcoInrDealcosDissPopup
                        v-if="showbasBcoInrDealcos"
                        :parentParam="searchInrDealcosForm"
                        :rows="resultInInrDealcosRows"
                        :dialogShow.sync="showbasBcoInrDealcos"
                        @confirm="onInrDealcosReturnData"
                    />
                </div>
                <div class="formitem div4"></div>
            </div>
        </div>
        <!-- // Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="재고이동출고관리 내역"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            >
                <template #gridBtnArea>
                    <TCComButton
                        :Vuetify="false"
                        eClass="btn_noline btn_ty04"
                        eAttr="ico_exeldown"
                        labelName="상세다운로드"
                        :objAuth="objAuth"
                        @click="onClickDownloadDtl"
                    />
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisDtrDisMovOuts"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <!-- //gridWrap -->
        <!-- popup -->
        <RealReportPopup
            v-if="reportShow"
            :parentParam="viewParam"
            :dialogShow.sync="reportShow"
        />
        <MainSmsSendPopup
            v-if="showMainSmsSend"
            :parentParam="searchSmsParam"
            :dialogShow.sync="showMainSmsSend"
            @confirm="onSmsSendReturnData"
        />
        <!-- //popup -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { DisDtrDisMovOutGRID_HEADER } from '@/const/grid/dis/dtr/disDtrDisMovOutHeader'
import disDtrDisMovOutApi from '@/api/biz/dis/dtr/disDtrMovOut'
import attachedFileApi from '@/api/common/attachedFile'
import RealReportPopup from '@/components/common/RealReportPopup'
import MainSmsSendPopup from '@/components/common/MainSmsSendPopup'
//====================거래명세서 리포트====================
import dealDtlfReport from '@/views/biz/dis/dco/DisDcoDealDtlf.json'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-전체조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-전체조직==================
//====================내부조직팝업(권한)팝업====================
import BasBcoInrDealcosDissPopup from '@/components/common/BasBcoInrDealcosDissPopup'
import BasBcoInrDealcosDissApi from '@/api/biz/bas/bco/BasBcoInrDealcos'
//====================//내부조직팝업(권한)팝업====================
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'DisDtrDisMovOut',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
        BasBcoInrDealcosDissPopup,
        RealReportPopup,
        MainSmsSendPopup,
    },
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            indicatorOpt: { sort: 'ASC' },
            objAuth: {},
            view: DisDtrDisMovOutGRID_HEADER,
            reportShow: false,
            viewParam: {},
            showMainSmsSend: false,
            searchSmsParam: {
                type: Object,
                default: () => {},
                required: false,
            },
            orgDisabled: false,
            dealcoDisabled: false,
            //====================출고 내부조직팝업(권한)팝업관련====================
            showOutBcoAuthOrgTrees: false, // 출고 내부조직팝업(권한) 팝업 오픈 여부
            searchOutAuthOrgTreesForm: {
                orgCd: '', //출고조직id
                orgNm: '', //출고조직명
            },
            resultOutAuthOrgTreeRows: [], // 출고 내부조직팝업(권한) 팝업 오픈 여부
            //====================//출고 내부조직팝업(권한)팝업관련==================
            //====================입고 내부조직팝업(권한)팝업관련====================
            showInBcoAuthOrgTrees: false, // 입고 내부조직팝업(권한) 팝업 오픈 여부
            searchInAuthOrgTreesForm: {
                orgCd: '', //입고조직id
                orgNm: '', //입고조직명
            },
            resultInAuthOrgTreeRows: [], // 입고 내부조직팝업(권한) 팝업 오픈 여부
            //====================//입고 내부조직팝업(권한)팝업관련==================
            //====================내부거래처-전체조직====================
            showBasBcoDealcos: false,
            searchDealcosForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
            },
            resultDealcoRows: [],
            //====================//내부거래처-전체조직==================
            //====================입고 내부거래처-재고전용 팝업관련====================
            showbasBcoInrDealcos: false, // 입고 내부거래처-재고전용 팝업 오픈 여부
            searchInrDealcosForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
            },
            resultInInrDealcosRows: [], // 입고 내부거래처-재고전용 팝업 오픈 여부
            //====================//입고 내부거래처-재고전용 팝업관련==================
            reqParam: {
                fromDt: '', //from일자
                toDt: '', //to일자
                prodClCd: '', //상품구분
                outOrgCd: '', //출고조직id
                outOrgNm: '', //출고조직명
                outOrgLvl: '', //출고조직level
                outOrgCdLvl0: '', //출고레벨0조직코드
                outDealcoCd: '', // 출고처
                outDealcoNm: '', // 출고처명
                inFix: '', //입고여부
                inOrgCd: '', //입고조직id
                inOrgNm: '', //입고조직명
                inOrgLvl: '', //입고조직level
                inOrgCdLvl0: '', //입고레벨0조직코드
                inDealcoCd: '', // 입고처
                inDealcoNm: '', // 입고처명
            },
            serchParam: {},
            dtlParam: {},
            rowCnt: 15,
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.fromDt, this.reqParam.toDt]
            },
            set(val) {
                this.reqParam.fromDt = val[0]
                this.reqParam.toDt = val[1]
                this.searchDealcosForm.basDay = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMMDD'
                )
                this.searchInrDealcosForm.basDay = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMMDD'
                )
                this.searchOutAuthOrgTreesForm.basMth = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMM'
                )
                this.searchInAuthOrgTreesForm.basMth = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMM'
                )
                return val
            },
        },
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(true, false, false)
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked
        //출고증 버튼
        this.gridObj.gridView.onCellItemClicked = (grid, index, clickData) => {
            if (clickData.fieldName === 'outFixReport') {
                this.printReport('Y', '')
            } else if (clickData.fieldName === 'inFixReport') {
                this.printReport('', 'N')
            }
        }
        // 상세에서 받은 검색조건
        if (this.$route.params.search) {
            this.reqParam = this.$route.params.search
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
            if (!_.isEmpty(this.reqParam.outOrgCd)) {
                this.searchBtn()
            }
        } else {
            this.init()
        }
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.fromDt = moment(new Date()).format('YYYY-MM-01') // 입고일 from
            this.reqParam.toDt = moment(new Date()).format('YYYY-MM-DD') // 입고일 to
            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['outOrgCd'] = this.orgInfo['orgCd']
                this.reqParam['outOrgNm'] = this.orgInfo['orgNm']
                this.reqParam['outOrgLvl'] = this.orgInfo['orgLvl']
                this.reqParam['outOrgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.reqParam['outDealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['outDealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam')
            this.init()
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dtr/disDtrDisMovOutExcelList',
                this.searchForm
            )
        },
        //상세엑셀다운로드
        onClickDownloadDtl() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dtr/disDtrDisMovOutAllExcelList',
                this.searchForm
            )
        },
        // 거래명세서 - 리포트 출력
        printReport(outFixYn, inFixYn) {
            let current = this.gridObj.gridView.getCurrent()

            if (current.dataRow < 0) {
                this.showTcComAlert('선택된 내용이 존재하지 않습니다.')
                return
            }
            const rowData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow,
                true
            )

            const reportParam = {
                outMgmtNo: rowData['outMgmtNo'],
                inPlcId: rowData['inDealcoCd'],
                outPlcId: rowData['outDealcoCd'],
                outFixYn: outFixYn,
                inFixYn: inFixYn,
            }

            disDtrDisMovOutApi
                .getDisDtrDisMovOutReport(reportParam)
                .then((res) => {
                    const reportData = {
                        master: {
                            values: [
                                {
                                    mgmtNo: res.result.outMaster?.mgmtNo, // 관리번호
                                    splyrBizNo: res.result.outMaster?.bizNo, // 공급자등록번호
                                    splyrDealCoNm:
                                        res.result.outMaster?.dealcoNm, // 공급자상호
                                    splyrNm: res.result.outMaster?.repUserNm, // 공급자성명
                                    splyrAddr: res.result.outMaster?.addr, // 공급자사업장
                                    splyrBizConNm:
                                        res.result.outMaster?.bizConNm, // 공급자업태
                                    splyrTypOfBizNm:
                                        res.result.outMaster?.typOfBizNm, // 공급자종목
                                    splyedBizNo: res.result.inMaster?.bizNo, // 공급받는자등록번호
                                    splyedDealCoNm:
                                        res.result.inMaster?.dealcoNm, // 공급받는자상호
                                    splyedNm: res.result.inMaster?.repUserNm, // 공급받는자성명
                                    splyedAddr: res.result.inMaster?.addr, // 공급받는자사업장
                                    splyedBizConNm:
                                        res.result.inMaster?.bizConNm, // 공급받는자업태
                                    splyedTypOfBizNm:
                                        res.result.inMaster?.typOfBizNm, // 공급받는자종목
                                },
                            ],
                        },
                        detail: {
                            values: [...res.result.detail],
                        },
                    }

                    this.reportOpen(reportData)
                })
        },
        // 거래명세서 리포트 출력
        reportOpen(data) {
            this.viewParam.report = dealDtlfReport
            this.viewParam.data = data
            this.reportShow = true
        },
        // SMS전송대상 조회
        sendSms() {
            let current = this.gridObj.gridView.getCurrent()

            if (current.dataRow < 0) {
                this.showTcComAlert('선택된 내용이 존재하지 않습니다.')
                return
            }
            const rowData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow,
                true
            )

            const smsDataParam = {
                inDealcoCd: rowData['inDealcoCd'],
            }

            disDtrDisMovOutApi
                .getDisDtrDisMovOutPhon(smsDataParam)
                .then((res) => {
                    if (_.isEmpty(res.result)) {
                        this.showTcComAlert(
                            '선택하신 입고처 에 해당하는 실무담당자 전화번호가 없습니다. \n\nSMS 주소록을 이용하시거나 관리자에게 문의하여 등록 하신후 사용하세요.'
                        )
                    }
                    const smsParam = {
                        msgText:
                            rowData['inDealcoNm'] +
                            '점으로 단말기 출고가 되었습니다. 당일 입고 확정 부탁드립니다',
                        telNum: [...res.result],
                    }
                    this.smsOpen(smsParam)
                })
        },
        // SMS전송팝업
        smsOpen(data) {
            console.log('data ::: ' + JSON.stringify(data))
            this.showMainSmsSend = true
        },
        //SMS리턴
        onSmsSendReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
        },
        //리스트 조회
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            this.searchForm = { ...this.reqParam }
            this.searchForm.fromDt = CommonUtil.replaceDash(
                this.searchForm.fromDt
            )
            this.searchForm.toDt = CommonUtil.replaceDash(this.searchForm.toDt)
            //첫 조회시 표시할 행의 갯수
            this.searchForm.pageSize = this.rowCnt
            this.searchForm.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getDisDtrDisMovOuts(this.searchForm.pageNum)
        },
        getDisDtrDisMovOuts(page) {
            this.searchForm.pageNum = page
            disDtrDisMovOutApi
                .getDisDtrDisMovOut(this.searchForm)
                .then((res) => {
                    //Get Row Data
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator(
                        res.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(res.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                    this.setReportButton()
                })
        },
        setReportButton() {
            const rowCount = this.gridObj.dataProvider.getRowCount()
            for (var i = 0; i < rowCount; i++) {
                this.gridObj.gridView.setValue(i, 'outFixReport', '출력')
                this.gridObj.gridView.setValue(i, 'inFixReport', '출력')
            }
            this.gridObj.gridView.commit()
        },
        isValidChk() {
            let validFromDt = CommonUtil.replaceDash(this.reqParam.fromDt)
            let validToDt = CommonUtil.replaceDash(this.reqParam.toDt)
            if (_.isEmpty(validFromDt)) {
                this.showTcComAlert('출고일자의 시작일(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(validToDt)) {
                this.showTcComAlert('출고일자의 종료일(을)를 입력해 주십시오.')
                return false
            }
            if (validFromDt.substr(0, 6) !== validToDt.substr(0, 6)) {
                this.showTcComAlert(
                    '출고 시작일자와 종료일자를 동일한 월로 지정하세요.'
                )
                return false
            }
            if (validFromDt > validToDt) {
                this.showTcComAlert('출고일자의 시작일이 종료일보다 큽니다.')
                return false
            }
            if (_.isEmpty(this.reqParam.outOrgCd)) {
                this.showTcComAlert('출고조직을 입력해 주십시오.')
                return false
            }
            return true
        },
        dtlBtn: function () {
            this.$router.push({
                name: '/dis/dtr/DisDtrDisMovOutDtl',
                params: { search: this.reqParam },
            })
        },
        onCellDblClicked(grid, clickData) {
            if (clickData?.dataRow >= 0) {
                const cellData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                if (clickData.column != 'outMgmtNo') {
                    this.dtlParam = { ...cellData }
                    this.$router.push({
                        name: '/dis/dtr/DisDtrDisMovOutDtl',
                        params: { search: this.reqParam, datas: this.dtlParam },
                    })
                }
            }
        },
        excelUpload() {
            this.$router.push({
                name: '/dis/dtr/DisDtrDisMovOutXlsUpld',
                params: { search: this.reqParam },
            })
        },
        //===================== 출고 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getOutAuthOrgTreeList() {
            this.searchOutAuthOrgTreesForm.orgCd = this.reqParam.outOrgCd
            this.searchOutAuthOrgTreesForm.orgNm = this.reqParam.outOrgNm
            this.searchOutAuthOrgTreesForm.orgLvl = this.reqParam.outOrgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchOutAuthOrgTreesForm)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.outOrgCd = _.get(res[0], 'orgCd')
                        this.reqParam.outOrgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                        this.reqParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultOutAuthOrgTreeRows = res
                        this.showOutBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onOutAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.outOrgNm)) {
                this.getOutAuthOrgTreeList()
            } else {
                this.showOutBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onOutAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultOutAuthOrgTreeRows = []
            // 내부조직팝업(권한) 정보 조회
            this.getOutAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onOutAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.outOrgCd = ''
            this.reqParam.outOrgLvl = ''
            this.reqParam.outOrgCdLvl0 = ''
            this.reqParam.outDealcoCd = ''
            this.reqParam.outDealcoNm = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onOutAuthOrgTreeReturnData(retrunData) {
            this.reqParam.outOrgCd = _.get(retrunData, 'orgCd')
            this.reqParam.outOrgNm = _.get(retrunData, 'orgNm')
            this.reqParam.outOrgLvl = _.get(retrunData, 'orgLvl')
            this.reqParam.outOrgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
            this.reqParam.outDealcoCd = ''
            this.reqParam.outDealcoNm = ''
        },
        //===================== //출고 내부조직팝업(권한)팝업관련 methods ================================
        //===================== 입고 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getInAuthOrgTreeList() {
            this.searchInAuthOrgTreesForm.orgCd = this.reqParam.inOrgCd
            this.searchInAuthOrgTreesForm.orgNm = this.reqParam.inOrgNm
            this.searchInAuthOrgTreesForm.orgLvl = this.reqParam.inOrgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchInAuthOrgTreesForm)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.inOrgCd = _.get(res[0], 'orgCd')
                        this.reqParam.inOrgNm = _.get(res[0], 'orgNm')
                        this.reqParam.inOrgLvl = _.get(res[0], 'orgLvl')
                        this.reqParam.inOrgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultInAuthOrgTreeRows = res
                        this.showInBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onInAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultInAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.inOrgNm)) {
                this.getInAuthOrgTreeList()
            } else {
                this.showInBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onInAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultInAuthOrgTreeRows = []
            // 내부조직팝업(권한) 정보 조회
            this.getInAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onInAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.inOrgCd = ''
            this.reqParam.inOrgLvl = ''
            this.reqParam.inOrgCdLvl0 = ''
            this.reqParam.inDealcoCd = ''
            this.reqParam.inDealcoNm = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onInAuthOrgTreeReturnData(retrunData) {
            this.reqParam.inOrgCd = _.get(retrunData, 'orgCd')
            this.reqParam.inOrgNm = _.get(retrunData, 'orgNm')
            this.reqParam.inOrgLvl = _.get(retrunData, 'orgLvl')
            this.reqParam.inOrgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
            this.reqParam.inDealcoCd = ''
            this.reqParam.inDealcoNm = ''
        },
        //===================== //입고 내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcosForm)
                .then((res) => {
                    // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.outDealcoCd = _.get(res[0], 'dealcoCd')
                        this.reqParam.outDealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultDealcoRows = res
                        this.showBasBcoDealcos = true
                    }
                })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (_.isEmpty(this.reqParam.outOrgCd)) {
                this.showTcComAlert('출고조직을 선택하세요')
                return
            }
            this.searchDealcosForm.orgCd = this.reqParam.outOrgCd
            this.searchDealcosForm.orgNm = this.reqParam.outOrgNm
            this.searchDealcosForm.orgLvl = this.reqParam.outOrgLvl
            this.searchDealcosForm.dealcoCd = this.reqParam.outDealcoCd
            this.searchDealcosForm.dealcoNm = this.reqParam.outDealcoNm
            // 팝업오픈
            this.showBasBcoDealcos = true
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.outOrgCd)) {
                this.showTcComAlert('출고조직을 선택하세요')
                return
            }
            this.searchDealcosForm.orgCd = this.reqParam.outOrgCd
            this.searchDealcosForm.orgNm = this.reqParam.outOrgNm
            this.searchDealcosForm.orgLvl = this.reqParam.outOrgLvl
            this.searchDealcosForm.dealcoCd = this.reqParam.outDealcoCd
            this.searchDealcosForm.dealcoNm = this.reqParam.outDealcoNm
            if (_.isEmpty(this.reqParam.outDealcoNm)) {
                // 팝업오픈
                this.showBasBcoDealcos = true
            } else {
                // 내부거래처-전체조직 정보 조회
                this.getDealcosList()
            }
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.reqParam.outDealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            this.reqParam.outDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.outDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-전체조직팝업관련 methods ================================
        //===================== 입고 내부거래처-재고전용 팝업관련 methods ================================
        // 내부거래처-재고전용 팝업관련 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-재고전용 팝업 오픈
        getInInrDealcosList() {
            BasBcoInrDealcosDissApi.getList(this.searchInrDealcosForm).then(
                (res) => {
                    // 검색된 내부거래처-재고전용 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-재고전용 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-재고전용 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.inDealcoCd = _.get(res[0], 'dealcoCd')
                        this.reqParam.inDealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultInInrDealcoRows = res
                        this.showbasBcoInrDealcos = true
                    }
                }
            )
        },
        // 내부거래처 팝업 TextField 돋보기 Icon 이벤트 처리
        onInrDealcosIconClick() {
            // 내부거래처팝업 Row 설정 Prop 변수 초기화
            this.resultInInrDealcoRows = []
            // 검색조건 dealCoCd이 빈값이면 팝업오픈
            if (_.isEmpty(this.reqParam.inOrgCd)) {
                this.showTcComAlert('입고조직을 선택하세요')
                return
            }
            this.searchInrDealcosForm.orgCd = this.reqParam.inOrgCd
            this.searchInrDealcosForm.orgNm = this.reqParam.inOrgNm
            this.searchInrDealcosForm.orgLvl = this.reqParam.inOrgLvl
            this.searchInrDealcosForm.dealcoCd = this.reqParam.inDealcoCd
            this.searchInrDealcosForm.dealcoNm = this.reqParam.inDealcoNm
            // 팝업오픈
            this.showbasBcoInrDealcos = true
        },
        // 내부거래처-재고전용 TextField 엔터키 이벤트 처리
        onInrDealcosEnterKey() {
            // 내부거래처-재고전용 팝업 Row 설정 Prop 변수 초기화
            this.resultInInrDealcoRows = []
            // 검색조건 내부거래처-재고전용 명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.inOrgCd)) {
                this.showTcComAlert('입고조직을 선택하세요')
                return
            }
            this.searchInrDealcosForm.orgCd = this.reqParam.inOrgCd
            this.searchInrDealcosForm.orgNm = this.reqParam.inOrgNm
            this.searchInrDealcosForm.orgLvl = this.reqParam.inOrgLvl
            this.searchInrDealcosForm.dealcoCd = this.reqParam.inDealcoCd
            this.searchInrDealcosForm.dealcoNm = this.reqParam.inDealcoNm
            if (_.isEmpty(this.reqParam.inDealcoNm)) {
                // 팝업오픈
                this.showbasBcoInrDealcos = true
            } else {
                // 내부거래처-재고전용 정보 조회
                this.getInInrDealcosList()
            }
        },
        // 내부거래처-재고전용 TextField Input 이벤트 처리
        onInrDealcosInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.reqParam.inDealcoCd = ''
        },
        // 내부거래처-재고전용 팝업 리턴 이벤트 처리
        onInrDealcosReturnData(retrunData) {
            this.reqParam.inDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.inDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //입고 내부거래처-재고전용 팝업관련 methods ================================
    },
}
</script>
