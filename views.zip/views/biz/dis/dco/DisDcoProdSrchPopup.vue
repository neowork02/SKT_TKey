<!-----------------------------------------------
 * 업무그룹명: 상품검색팝업
 * 서브업무명: 상품검색팝업
 * 설명: 상품검색한다.
 * 작성자: P179234
 * 작성일: 2022.04.22
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">상품검색</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div4_1">
                                <TCComComboBox
                                    labelName="상품구분"
                                    codeId="ZBAS_C_00010"
                                    ref="prchTypComboBox"
                                    :objAuth="objAuth"
                                    :addBlankItem="true"
                                    v-model="reqParam.prodClCd"
                                />
                            </div>
                            <div class="formitem div4_1">
                                <TCComComboBox
                                    labelName="단말기구분"
                                    codeId="ZBAS_C_00500"
                                    ref="prchTypComboBox"
                                    :objAuth="objAuth"
                                    :addBlankItem="true"
                                    v-model="reqParam.eqpClCd"
                                />
                            </div>
                            <div class="formitem div4_1">
                                <TCComInput
                                    labelName="모델명"
                                    :objAuth="objAuth"
                                    v-model="reqParam.prodNm"
                                    @enterKey="searchDisDcoProdSrch"
                                />
                            </div>
                            <div class="formitem div4_1">
                                <TCComInput
                                    labelName="코드"
                                    :objAuth="objAuth"
                                    v-model="reqParam.prodCd"
                                    @enterKey="searchDisDcoProdSrch"
                                    @input="
                                        reqParam.prodCd =
                                            reqParam.prodCd.toUpperCase()
                                    "
                                />
                            </div>
                            <div class="formitem div5">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="searchDisDcoProdSrch()"
                                        />
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeaderProd"
                            ref="gridHeaderProd"
                            gridTitle="상품목록"
                            :gridObj="gridObj"
                            :isPageRows="true"
                            :isNextPage="true"
                            :isPageCnt="true"
                        />
                        <TCRealGrid
                            id="gridFieldProd"
                            ref="gridFieldProd"
                            :fields="gridSet.fields"
                            :columns="gridSet.columns"
                            :styles="gridStyle"
                            :editable="true"
                        />
                        <TCComPaging
                            :totalPage="gridData.totalPage"
                            :apiFunc="getDisDcoProdSrchs"
                            :gridObj="gridObj"
                            @input="chgRowCnt"
                        />
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { GRID_HEADER } from '@/const/grid/dis/dco/disDcoProdSrchPopupHeader.js'
import disDcoProdSrchApi from '@/api/biz/dis/dco/disDcoProdSrch.js'
import commonApi from '@/api/common/prototype'
import CommonMixin from '@/mixins'

export default {
    name: 'DisDcoProdSrchPop',
    components: {},
    mixins: [CommonMixin],
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        parentParam: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            objAuth: {},
            codeIDView: true,
            codeIDViewVal: '',
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '500px',
            },
            isCheck: true,
            gridSet: GRID_HEADER,
            rowCnt: 15,
            searchForms: {},
            reqParam: {
                applyDt: '',
                prodClCd: '',
                eqpClCd: '',
                prodNm: '',
                prodCd: '',
            },
        }
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.isCheck = value.hasCheck
                this.reqParam.prodNm =
                    value.prodNm === undefined ? '' : value.prodNm
                this.reqParam.prodCd =
                    value.prodCd === undefined ? '' : value.prodCd
                this.reqParam.prodClCd =
                    value.prodClCd === undefined ? '' : value.prodClCd
                this.reqParam.applyDt = value.applyDt
            },
            deep: true,
            immediate: true,
        },
    },
    created() {},
    mounted() {
        this.initGrid()
        this.setGrid()
        this.getCommCodeList('ZBAS_C_00010', 'prodClNm') // 상품구분
        this.getCommCodeList('ZBAS_C_00500', 'prodClNm') // 단말기구분코드
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
                this.$emit('update:Prod', value)
            },
        },
    },
    methods: {
        /* 공통코드 */
        getCommCodeList(codeId, columnId) {
            commonApi.getCommonCodeList(codeId).then((res) => {
                let columnValues = []
                let columnLabels = []
                if (res.length) {
                    res.forEach((data) => {
                        columnValues.push(data.commCdVal)
                        columnLabels.push(data.commCdValNm)
                    })
                }
                // 그리드 컬럼 콤보박스 데이터 설정
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'values',
                    columnValues
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'labels',
                    columnLabels
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'lookupDisplay',
                    true
                )
            })
        },
        /* 그리드 설정 */
        initGrid() {
            this.gridObj = this.$refs.gridFieldProd
            this.gridHeaderObj = this.$refs.gridHeaderProd
            this.gridObj.setGridState(false, false, this.isCheck)
            this.$refs.gridFieldProd.gridView.displayOptions.selectionStyle =
                'rows'
        },
        /* 그리드 설정 */
        gridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        /* 그리드 설정 -셀 더블클릭 시 부모로 값 이동 */
        setGrid() {
            this.gridObj.gridView.onCellDblClicked = () => {
                this.onConfirm()
            }
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        /* 상품검색 조회 - 최초 */
        searchDisDcoProdSrch() {
            this.gridData.totalPage = 0
            this.searchForms = { ...this.reqParam }
            this.searchForms.pageSize = this.rowCnt
            this.searchForms.pageNum = 1

            this.getDisDcoProdSrchs(this.searchForms.pageNum)
        },
        /* 상품검색 조회 - 페이징 */
        async getDisDcoProdSrchs(page) {
            // this.loading('start')
            this.searchForms.pageNum = page
            await disDcoProdSrchApi
                .getDisDcoProdSrch(this.searchForms)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator(res.pagingDto)
                        this.gridData = this.gridSetData()
                        this.gridData.totalPage = res.pagingDto.totalPageCnt
                        this.gridHeaderObj.setPageCount(res.pagingDto)
                        // this.loading()
                    }
                })
        },
        /* 조회 팝업 */
        btnClick() {
            console.log('cli ck')
        },
        /* 확인 */
        onConfirm() {
            this.gridObj.gridView.commit()
            const current = this.gridObj.gridView.getCurrent()
            const jsonData =
                current.dataRow === -1
                    ? jsonData
                    : this.gridObj.dataProvider.getJsonRow(current.dataRow)
            if (current.dataRow === -1) {
                this.showTcComAlert('상품을 선택해주세요.')
                return
            } else if (jsonData.unitPrc < 1) {
                this.showTcComAlert(
                    '상품단가표 실매입가 입력해주시기 바랍니다.'
                )
                return
            } else {
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        /* 팝업 창닫기 */
        onClose() {
            this.activeOpen = false
        },
        test(vale) {
            console.log('test value: ', vale)
        },
    },
}
</script>
