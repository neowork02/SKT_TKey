<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1600px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">중고단말기미반납 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeader1"
                                ref="gridHeader1"
                                gridTitle="중고단말기미반납"
                                :gridObj="gridObj"
                                :isExceldown="true"
                                @excelDownBtn="exportExcelDown"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid1"
                                ref="grid1"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
// import moment from 'moment'
import CommonMixin from '@/mixins'
import sacApi from '@/api/biz/acc/sac'
import { GRID_HEADER } from '@/const/grid/acc/sac/accSacWlessSaleCmmsAccMgmtOldPopupGrid'

export default {
    name: 'AccSacWlessSaleCmmsAccMgmtOldPopup',
    title: '중고단말기미반납 팝업',
    mixins: [CommonMixin],
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list: [],
            gridObj: {},
            searchParams: {
                searchPageType: 'OLD-POPUP',
                // searchOrgCd: this.popupParams.orgCd,
                // searchOrgLvl: this.popupParams.orgLvl,
                // searchLvOrgCd: this.popupParams.lvOrgCd,
                // searchAccYm: moment(this.popupParams.accYm).format('YYYYMM'),
                // searchAccDealcoCd: this.popupParams.accDealcoCd,
                searchPolId: this.popupParams.searchPolId, // AS-IS 소스에서도 실제로 넘어오는 값은 없음
                searchOrgCd: 'AA1412', // 테스트값 세팅
                searchOrgLvl: '3', // 테스트값 세팅
                searchLvOrgCd: 'O00000', // 테스트값 세팅
                searchAccYm: '202112', // 테스트값 세팅
                searchAccDealcoCd: '96603', // 테스트값 세팅
            },
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        this.gridObj = this.$refs.grid1
        this.gridObj.setGridState()

        //그리드 Header Layout 세팅하기
        this.gridObj.gridView.setColumnLayout(this.view.layout)

        // 넘어온 파라미터로 조회하기
        this.onSearch()
    },
    methods: {
        onSearch: function () {
            console.log('search')
            sacApi
                .getAccSacWlessSaleCmmsAccMgmtList(this.setParamJson('GET'))
                .then((resultData) => {
                    this.$refs.grid1.setRows(resultData)
                })
        },
        onClose: function () {
            this.activeOpenAgency = false
        },
        exportExcelDown: function () {
            if (this.list.length == 0) {
                this.showTcComAlert('출력할 데이터가 없습니다.')
                return
            }
            // this.$refs.gridHeader1.exportGrid('중고단말기미반납-팝업.xls')
            this.searchParams.excelFileName =
                '중고단말기미반납_팝업' +
                '_' +
                this.searchParams.searchAccYm +
                '_' +
                this.searchParams.searchOrgNm +
                '_' +
                this.searchParams.searchAccDealcoNm

            sacApi
                .downloadAccSacWlessSaleCmmsAccMgmtExcelDown(this.searchParams)
                .then(() => {
                    this.showTcComAlert('엑셀파일이 다운로드되었습니다.')
                })
        },
    },
}
</script>
