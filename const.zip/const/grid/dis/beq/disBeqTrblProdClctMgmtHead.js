import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'riskMgmtNo', // RISK 회수 관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskTranDt', // 등록일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgLvl', // 조직레벨
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNmShort', // 조직(명)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd', // 레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm', // 레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd1', // 레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1', // 레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd2', // 레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2', // 레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd3', // 레벨3조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm3', // 레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoShopCd', // 거래처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskMclCd', // RISK중분류
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskMclNm', // RISK중분류명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstAmt', // 채권회수금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dpstErpTrmsYn', // 채권회수ERP전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstTrmsDtm', // 채권회수전송일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'etcDpstAmt', // 채권회수금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'etcDpstErpTrmsYn', // 채권회수ERP전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'etcDpstTrmsDtm', // 채권회수전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'costOpAmt', // 비용금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'costErpTrmsYn', // 비용ERP전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'costTrmsDtm', // 비용전송일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'debtSetoffAmt', // 채권상계금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'debtSetoffErpYn', // 채권상계ERP전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'debtSetoffTrmsDtm', // 채권상계전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'riskAmt', // 사고단말기 금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'riskClctAmt', // 사고단말기 회수 금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // UPD_CNT
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'riskTranDt',
            fieldName: 'riskTranDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '처리일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처코드',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처',
        },
        {
            name: 'riskMclNm',
            fieldName: 'riskMclNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: 'RISK중분류',
        },
        {
            name: 'riskAmt',
            fieldName: 'riskAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '사고금액',
        },
        {
            name: 'riskClctAmt',
            fieldName: 'riskClctAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '처리금액합계',
        },
        {
            name: 'dpstAmt',
            fieldName: 'dpstAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '입금(거래처)',
        },
        {
            name: 'etcDpstAmt',
            fieldName: 'etcDpstAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '입금(타계좌)',
        },
        {
            name: 'costOpAmt',
            fieldName: 'costOpAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '비용처리',
        },
        {
            name: 'debtSetoffAmt',
            fieldName: 'debtSetoffAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '채무상계',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
    ],
}
