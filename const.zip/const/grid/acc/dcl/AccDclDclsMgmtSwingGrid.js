'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: 'orgNm',
        editable: false,
        header: { text: '사업담당' },
        type: 'data',
        styleName: 'left-column',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'agencyNm',
        editable: false,
        header: { text: '대리점' },
        type: 'data',
        styleName: 'left-column',
        dataType: ValueType.TEXT,
        footer: {
            text: '합계',
        },
    },

    {
        fieldName: 'ukeyCnt',
        editable: false,
        header: { text: '전송' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'procCnt',
        editable: false,
        header: { text: '처리' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'nonCnt',
        editable: false,
        header: { text: '미처리' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'exptCnt',
        editable: false,
        header: { text: '제외' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'tkpUkeyCnt',
        editable: false,
        header: { text: '전송' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'tkpProcCnt',
        editable: false,
        header: { text: '처리' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'tkpNonCnt',
        editable: false,
        header: { text: '미처리' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'tkpExptCnt',
        editable: false,
        header: { text: '제외' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'tdayBalAmt',
        editable: false,
        header: { text: '발생' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'tdayRfndAmt',
        editable: false,
        header: { text: '환불' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
    {
        fieldName: 'ukeyAmt',
        editable: false,
        header: { text: '합계' },
        type: 'data',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = [
    'orgNm',
    'agencyNm',
    {
        name: 'businessManagement',
        header: { text: '영업관리' },
        direction: 'horizontal',
        items: ['ukeyCnt', 'procCnt', 'nonCnt', 'exptCnt'],
    },
    {
        name: 'wireSales',
        header: { text: '유선판매' },
        direction: 'horizontal',
        items: ['tkpUkeyCnt', 'tkpProcCnt', 'tkpNonCnt', 'tkpExptCnt'],
    },
    {
        name: 'sktDeposit',
        header: { text: 'SKT예수금' },
        direction: 'horizontal',
        items: ['tdayBalAmt', 'tdayRfndAmt', 'ukeyAmt'],
    },
]
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {}

export { GRID_HEADER, MOCK_DATA }
