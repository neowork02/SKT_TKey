const exception = {
    namespaced: true,
    state: {
        info: {
            show: false,
            code: '',
            message: '',
            origin: {},
        },
        _mblInfo: {
            show: false,
            code: '',
            message: '',
            origin: {},
        },
    },
    mutations: {
        SET_EXCEPTION(state, info) {
            state.info = info
        },
        SET_MBL_EXCEPTION(state, info) {
            state._mblInfo = info
        },
    },
    actions: {
        setException({ commit }, origin) {
            commit('SET_EXCEPTION', origin)
        },
        resetException({ commit }) {
            const info = {
                show: false,
                code: '',
                message: '',
                origin: {},
            }
            commit('SET_EXCEPTION', info)
        },
        setMblException({ commit }, origin) {
            commit('SET_MBL_EXCEPTION', origin)
        },
        resetMblException({ commit }) {
            const info = {
                show: false,
                code: '',
                message: '',
                origin: {},
            }
            commit('SET_MBL_EXCEPTION', info)
        },
    },
    getters: {
        getException: (state) => state.info,
        getMblException: (state) => state._mblInfo,
    },
}

export default exception
