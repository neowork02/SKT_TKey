import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, // 레벨0조직코드
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT, // 부가서비스코드
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT, // 부가서비스명
        },
        {
            fieldName: 'suplSvcRmks',
            dataType: ValueType.TEXT, // 부가정책 설명
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT, // 사용여부
        },
        {
            fieldName: 'aplyStaDt',
            dataType: ValueType.TEXT, // 적용시작일자
        },
        {
            fieldName: 'aplyEndDt',
            dataType: ValueType.TEXT, // 적용종료일자
        },
        {
            fieldName: 'suplSvcClCd',
            dataType: ValueType.TEXT, // 부가서비스구분코드
        },
        {
            fieldName: 'wrcellClCd',
            dataType: ValueType.TEXT, // 유무선구분코드
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 수정사용자ID
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT, // 수정사용자명
        },
    ],
    columns: [
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '부가정책ID',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '부가정책명',
            },
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '사용여부',
            },
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '시작일자',
            },
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '종료일자',
            },
        },
        {
            name: 'suplSvcRmks',
            fieldName: 'suplSvcRmks',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '상세설명',
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '작성자',
            },
        },
    ],
}
