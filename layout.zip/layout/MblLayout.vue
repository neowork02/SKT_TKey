<!-----------------------------------------------
 * 업무그룹명: 레이아웃 컴포넌트
 * 서브업무명: 레이아웃 컴포넌트 
 * 설명: 레이아웃 처리
 * 작성자: 양현모
 * 작성일: 2022.11.21
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="wrap mo">
        <div class="mo">
            <MblHeader></MblHeader>
            <MblContent> </MblContent>
        </div>
    </div>
</template>

<script>
import MblHeader from '@/layout/MblHeader'
import MblContent from '@/layout/MblContent'

export default {
    components: {
        MblHeader,
        MblContent,
    },
}
</script>
<style></style>
