<template>
    <div class="content">
        <h1>유통단말기매핑관리</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="btn_add_OnClick"
                    :objAuth="objAuth"
                >
                    신규
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSaveValidation"
                    :objAuth="objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        v-model="div_search.edt_prodMapCd"
                        labelName="상품 매핑 코드"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="상품 매핑 목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isDelRow="true"
                :isExceldown="true"
                @chkDelRowBtn="btn_del_OnClick"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getProdMapList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>

        <div class="stitHead">
            <h4 class="subTit">상품 매핑 상세 정보</h4>
        </div>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5_1">
                    <TCComInput
                        v-model="div_btmParam.edt_prodMapCdIn"
                        labelName="상품매핑코드"
                        :objAuth="objAuth"
                        @change="edt_prodMapCdIn_OnChange"
                        :disabled="false"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div5_1">
                    <TCComInputSearchText
                        labelName="상품"
                        @enterKey="onProdsEnterKey"
                        @appendIconClick="onProdsIconClick"
                        @input="div_btmParam.prodCd = ''"
                        @change="prodCd_OnChange"
                        :objAuth="objAuth"
                        v-model="div_btmParam.prodCd"
                        :codeVal="div_btmParam.prodNm"
                        :disabledAfter="true"
                    >
                    </TCComInputSearchText>
                    <BasBcoProdsPopup
                        v-if="basBcoProdsShow === true"
                        :dialogShow.sync="basBcoProdsShow"
                        :parentParam="div_btmParam"
                        :rows="resultProdsRows"
                        @confirm="onProdsReturnData"
                    />
                </div>
                <div class="formitem div5_1">
                    <TCComComboBox
                        labelName="색상"
                        ref="colorList"
                        v-model="div_btmParam.cmb_color"
                        :objAuth="objAuth"
                        :itemList="colorCdList"
                        @change="cmb_color_OnChange"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div5_1">
                    <TCComComboBox
                        labelName="상품매핑구분"
                        v-model="div_btmParam.cmb_prodMapCl"
                        :objAuth="objAuth"
                        codeId="ZDIS_C_00370"
                        @change="cmb_prodMapCl_OnChange"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
import _ from 'lodash'
import attachedFileApi from '@/api/common/attachedFile'
import { HEADER } from '@/const/grid/bas/pdm/basPdmDstrbEqpMappMgmtHeader'
import API from '@/api/biz/bas/pdm/basPdmDstrbEqpMappMgmt'
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================
import CommonMixin from '@/mixins'
import { msgTxt } from '@/const/msg.Properties'

export default {
    name: 'BasPdmDstrbEqpMappMgmt',
    components: { BasBcoProdsPopup },
    mixins: [CommonMixin],

    data() {
        return {
            v_btn_del: { visible: false },
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            rowCnt: 15,
            //각각 엘리먼트 컴포넌트 v-model
            div_search: {
                edt_prodMapCd: '', //상품 매핑 코드
            },
            div_btmParam: {
                edt_prodMapCdIn: '', //상품매핑코드
                prodCd: '',
                prodNm: '',
                cmb_color: '', //색상
                cmb_prodMapCl: '', //상품매핑구분
            },
            objAuth: {},
            selectedJsonData: {},
            selectedRow: '',
            prod_bar_cd_mgmt: [],
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            //====================//상품팝업관련==================
            colorCdList: [],
            prodMapClCdList: [],
            ds_prodMapList: [], // 조회시 데이터셋
        }
    },

    created() {
        this.init()
        console.log('this.$route Detail: ', this.$route)
        // this.searchParam = this.$route.params.search
    },

    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        // 삭제버튼 보이기 (임시 기존: =='P13'으로 바꿔야함)
        if (this.userInfo.userGrpCd !== 'P13') {
            this.v_btn_del.visible = true
        }

        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState(true)

        // dropDown name 사용위해 set
        this.dropDownSetting()

        this.gridObj.gridView.onCellEdited = (
            grid,
            itemIndex,
            dataRow,
            field
        ) => {
            // var column = grid.columnByField('accDealcoNm')
            this.gridObj.gridView.commit()
            const getData = grid.getValue(itemIndex, field)
            console.log('getData', getData)

            this.selectedJsonData =
                this.gridObj.dataProvider.getJsonRow(dataRow)
            console.log('selectedJsonData', this.selectedJsonData)
        }

        // 싱글클릭 시 저장데이터 SET
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            this.selectedJsonData = this.gridObj.dataProvider.getJsonRow(
                clickData.dataRow
            )
            this.selectedRow = clickData.dataRow
            console.log('selectedJsonData', this.selectedJsonData)
            console.log('clickData.dataRow', clickData.dataRow)
            this.div_btmParam.edt_prodMapCdIn = this.selectedJsonData.prodMapCd
            this.div_btmParam.prodCd = this.selectedJsonData.prodCd
            this.div_btmParam.prodNm = this.selectedJsonData.prodNm
            this.div_btmParam.cmb_color = this.selectedJsonData.colorCd
            this.div_btmParam.cmb_prodMapCl = this.selectedJsonData.prodMapClCd

            this.getProdColor()
        }
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.gridSetData()
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        // 그리드에 그룹명 dropdown셋팅 공통코드 api
        async dropDownSetting() {
            console.log('dropDownSetting')
            // 색상 set
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00040',
                columnName: 'colorCd',
                option: '--선택--',
            })
            // 상품매핑구분 set
            await this.dropDownCmmonCodes({
                key: 'ZDIS_C_00370',
                columnName: 'prodMapClCd',
                option: '--선택--',
            })
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/pdm/prod-mapp-info-Excel',
                this.div_search
            )
        },

        async dropDownCmmonCodes({ key, columnName, option }) {
            console.log('key columnName option', key, columnName, option)
            let result = await API.dropDownCmmonCodes_(key)
            console.log('result', result)
            if (columnName == 'colorCd') {
                this.colorCdList = result
                this.colorCdList2 = result
            }
            if (columnName == 'prodMapClCd') {
                this.prodMapClCdList = result
            }

            let values = []
            let labels = []
            values = result.map((a) => a.commCdVal)
            console.log('values', values)
            labels = result.map((a) => a.commCdValNm)
            console.log('labels', labels)
        },

        //조회 버튼 이벤트
        onSearch: function () {
            this.onResetPage2()
            this.gridData.totalPage = 0
            this.getProdMapList(1)
            // this.getProdColor()
        },

        // 상품 매핑 정보 조회
        getProdMapList(pageNum) {
            let paramObj = {
                prodMapCd: this.div_search.edt_prodMapCd, // 상품매핑코드
                // prodMapClCd: this.div_search.cmb_prodMapCl, // 상품매핑구분코드
                // prodCd: this.div_search.prodCd, // 상품코드
                // prodNm: this.div_search.prodNm, // 상품명
                // colorCd: this.div_search.cmb_color, // 색상코드
            }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt
            API.getProdMapList(paramObj).then((result) => {
                console.log('result : ', result)
                if (result.gridList.length > 0) {
                    this.gridObj.setRows(result.gridList)
                    this.ds_prodMapList = result
                    this.div_btmParam.edt_prodMapCdIn =
                        result.gridList[0].prodMapCd
                    this.div_btmParam.prodCd = result.gridList[0].prodCd
                    this.div_btmParam.prodNm = result.gridList[0].prodNm
                    this.div_btmParam.cmb_prodMapCl =
                        result.gridList[0].prodMapClCd

                    // let current = this.gridObj.gridView.getCurrent()
                    // console.log('current', current)
                    let idx = 0
                    result.gridList.map((rowData) => {
                        this.colorCdList.map((color) => {
                            if (rowData.colorCd == color.commCdVal) {
                                // console.log('color.commCdVal : ', color.commCdVal)
                                this.gridObj.gridView.setValue(
                                    idx,
                                    'colorNm',
                                    color.commCdValNm
                                )
                                return
                            }
                        })
                        this.prodMapClCdList.map((prodMapClCd) => {
                            if (rowData.prodMapClCd == prodMapClCd.commCdVal) {
                                // console.log('color.commCdVal : ', color.commCdVal)
                                this.gridObj.gridView.setValue(
                                    idx,
                                    'prodMapClNm',
                                    prodMapClCd.commCdValNm
                                )
                                return
                            }
                        })
                        idx++
                    })
                    // 페이징 관련
                    this.gridObj.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
            })
        },

        // 상품코드별 색상 필터링
        // filterFunc(items) {
        //     console.log('items', items)
        //     console.log('this.ds_prodColor', this.ds_prodColor)
        //     this.ds_prodColor.map((prod) => {
        //         console.log('prod', prod)
        //         items.filter((item) => item['commCdVal'] === prod.colorCd)
        //     })
        //     console.log('items', items)
        //     return items
        // },

        filterFunc(items) {
            console.log('items', items)
            console.log('this.colorCdList2', this.colorCdList2)
            this.colorCdList = []
            items.map((item) => {
                this.colorCdList2.map((p) => {
                    if (p.commCdVal === item.colorCd) {
                        this.colorCdList.push(p)
                    }
                })
                // {
                //     if (p.commCdVal === item.colorCd) {
                //         this.colorCdList.push(p)
                //     }
                // })
            })
        },

        // 상품코드별 색상 리스트 조회
        getProdColor() {
            console.log('this.div_btmParam.prodCd : ', this.div_btmParam.prodCd)
            let paramObj = {
                prodCd: this.div_btmParam.prodCd, // 상품코드
            }

            API.getProdColor(paramObj).then((result) => {
                console.log('result : ', result)
                this.colorCdList = result
                // this.ds_prodColor = result
                this.filterFunc(result)
                // console.log('this.colorCdList', this.colorCdList)
            })
        },

        // 상품코드별 색상 필터링
        setProdColor() {
            console.log('this.ds_prodColor : ', this.ds_prodColor)
            // this.ds_prodColor
        },

        //저장 버튼 이벤트
        onSave: function () {
            this.gridObj.gridView.commit()

            let saveParam = []
            let gridCreatedIndexArr =
                this.gridObj.dataProvider.getStateRows('created')
            let gridUpdatedIndexArr =
                this.gridObj.dataProvider.getStateRows('updated')

            console.log('gridCreatedIndexArr', gridCreatedIndexArr)
            console.log('gridUpdatedIndexArr', gridUpdatedIndexArr)

            console.log('사용자 추가 정보 수정', this.gridData._delRows)
            // let userUpdateParam = {}
            // let addDealHisList = []
            // let addOrgHisList = []

            // 삭제정보저장
            if (this.gridData._delRows.length > 0) {
                for (let idx = 0; idx < this.gridData._delRows.length; idx++) {
                    this.gridData._delRows[idx].__rowState = 'deleted'
                    saveParam.push(this.gridData._delRows[idx])
                }
            }
            console.log('onSave 111111111111111111111')
            for (let idx = 0; idx < gridCreatedIndexArr.length; idx++) {
                let getJson = this.gridObj.dataProvider.getJsonRow(
                    gridCreatedIndexArr[idx]
                )
                getJson.prodMapCd = getJson.prodMapCd ? getJson.prodMapCd : ''
                getJson.prodMapClCd = getJson.prodMapClCd
                    ? getJson.prodMapClCd
                    : ''
                getJson.prodCd = getJson.prodCd ? getJson.prodCd : ''
                getJson.prodNm = getJson.prodNm ? getJson.prodNm : ''
                getJson.colorCd = getJson.colorCd ? getJson.colorCd : ''
                getJson.__rowState = 'created'
                saveParam.push(getJson)
            }
            console.log('onSave 2222222222222222222222')
            for (let idx = 0; idx < gridUpdatedIndexArr.length; idx++) {
                let getJson = this.gridObj.dataProvider.getJsonRow(
                    gridUpdatedIndexArr[idx]
                )
                getJson.prodMapCd = getJson.prodMapCd ? getJson.prodMapCd : ''
                getJson.prodMapClCd = getJson.prodMapClCd
                    ? getJson.prodMapClCd
                    : ''
                getJson.prodCd = getJson.prodCd ? getJson.prodCd : ''
                getJson.prodNm = getJson.prodNm ? getJson.prodNm : ''
                getJson.colorCd = getJson.colorCd ? getJson.colorCd : ''
                getJson.__rowState = 'updated'
                console.log('getJson', getJson)

                saveParam.push(getJson)
            }
            console.log('onSave 333333333333333333333333')
            // let jsonData = {}
            let savejsonData = []
            saveParam.forEach((item) => {
                // jsonData = this.gridObj.dataProvider.getJsonRow(item)
                console.log('getJson', item)
                if (item.__rowState !== 'deleted') {
                    if (item.prodMapCd.length < 1) {
                        // alert(cf_getMessage(MSG_00083, '상품매핑코드'))
                        this.showTcComAlert(
                            CommonUtil.replaceMsg(
                                msgTxt.MSG_00083,
                                '상품매핑코드'
                            )
                        )
                        // div_process.edt_prodMapCdIn.SetFocus()
                        return
                    }

                    if (item.prodCd.length < 1) {
                        this.showTcComAlert(
                            CommonUtil.replaceMsg(msgTxt.MSG_00083, '상품코드')
                        )
                        // div_process.edt_prodCd.SetFocus()
                        return
                    }

                    if (item.prodNm.length < 1) {
                        this.showTcComAlert(
                            CommonUtil.replaceMsg(msgTxt.MSG_00083, '상품명')
                        )
                        // div_process.edt_prodCd.SetFocus()
                        return
                    }

                    if (item.colorCd.length < 1) {
                        this.showTcComAlert(
                            CommonUtil.replaceMsg(msgTxt.MSG_00083, '색상코드')
                        )
                        // div_process.edt_colorCd.SetFocus()
                        return
                    }

                    if (item.prodMapClCd.length < 1) {
                        this.showTcComAlert(
                            CommonUtil.replaceMsg(
                                msgTxt.MSG_00083,
                                '상품매핑구분'
                            )
                        )
                        // div_process.edt_prodMapCl.SetFocus()
                        return
                    }
                    savejsonData.push(item)
                } else {
                    savejsonData.push(item)
                }
            })

            console.log('savejsonData', savejsonData)
            API.saveProdMapInfo(savejsonData).then((result) => {
                console.log('result : ', result)
                if (result !== null) {
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    // 매핑정보 재조회
                    this.onSearch()
                } else {
                    this.showTcComAlert(result.message)
                }
            })
        },

        // 저장시 유효성검사
        onSaveValidation() {
            //     let current = this.gridObj.gridView.getCurrent()
            //     console.log('current', current)
            //     let jsonRow = this.gridObj.dataProvider.getJsonRow(current.dataRow)
            //     // if (ds_prodMapList.GetUpdate() < 1) {
            //     //     alert(cf_getMessage(MSG_00084, '변경된 내용'))
            //     //     return
            //     // }
            //     console.log('jsonRow', jsonRow)
            //     if (jsonRow.prodMapCd.length < 1) {
            //         // alert(cf_getMessage(MSG_00083, '상품매핑코드'))
            //         this.showTcComAlert(
            //             CommonUtil.replaceMsg(msgTxt.MSG_00083, '상품매핑코드')
            //         )
            //         // div_process.edt_prodMapCdIn.SetFocus()
            //         return
            //     }

            //     if (jsonRow.prodCd.length < 1) {
            //         this.showTcComAlert(
            //             CommonUtil.replaceMsg(msgTxt.MSG_00083, '상품코드')
            //         )
            //         // div_process.edt_prodCd.SetFocus()
            //         return
            //     }

            //     if (jsonRow.prodNm.length < 1) {
            //         this.showTcComAlert(
            //             CommonUtil.replaceMsg(msgTxt.MSG_00083, '상품명')
            //         )
            //         // div_process.edt_prodCd.SetFocus()
            //         return
            //     }

            //     if (jsonRow.colorCd.length < 1) {
            //         this.showTcComAlert(
            //             CommonUtil.replaceMsg(msgTxt.MSG_00083, '색상코드')
            //         )
            //         // div_process.edt_colorCd.SetFocus()
            //         return
            //     }

            //     if (jsonRow.prodMapClCd.length < 1) {
            //         this.showTcComAlert(
            //             CommonUtil.replaceMsg(msgTxt.MSG_00083, '상품매핑구분')
            //         )
            //         // div_process.edt_prodMapCl.SetFocus()
            //         return
            //     }

            // if (
            //     ds_prodMapList.GetOrgColumn(
            //         ds_prodMapList.currow,
            //         'prodMapCd'
            //     ) != jsonRow.prodMapCd
            // ) {
            //     ds_prodMapList.UpdateControl = false
            //     ds_prodMapList.SetRowType(ds_prodMapList.currow, 'insert')
            // }

            this.onSave()
        },

        // 초기화
        onResetPage() {
            this.dropDownSetting()
            CommonUtil.clearPage(this, 'div_search', this.gridObj)
            CommonUtil.clearPage(this, 'div_btmParam', this.gridObj)
        },

        // 초기화
        onResetPage2() {
            this.dropDownSetting()
            CommonUtil.clearPage(this, 'div_btmParam', this.gridObj)
        },

        // 상품매핑코드 OnChange
        edt_prodMapCdIn_OnChange(value) {
            let current = this.gridObj.gridView.getCurrent()
            console.log('current', current)
            console.log('value', value)

            this.gridObj.gridView.setValue(current.dataRow, 'prodMapCd', value)
            // this.gridObj.gridView.setValue(current.dataRow, 'orgNm', orgNm)
        },

        // 상품 OnChange
        prodCd_OnChange(value) {
            this.div_btmParam.prodCd = ''
            this.div_btmParam.prodNm = ''
            let current = this.gridObj.gridView.getCurrent()
            console.log('current', current)
            console.log('value', value)

            this.gridObj.gridView.setValue(current.dataRow, 'prodCd', value)
            // this.gridObj.gridView.setValue(current.dataRow, 'prodNm', value)
        },

        // 색상 OnChange
        cmb_color_OnChange(value) {
            let current = this.gridObj.gridView.getCurrent()
            console.log('current', current)
            console.log('value', value)

            this.colorCdList.map((colorCd) => {
                if (colorCd.commCdVal == value) {
                    this.gridObj.gridView.setValue(
                        current.dataRow,
                        'colorNm',
                        colorCd.commCdValNm
                    )
                    return
                }
            })

            this.gridObj.gridView.setValue(current.dataRow, 'colorCd', value)
            // this.gridObj.gridView.setValue(current.dataRow, 'orgNm', orgNm)
        },

        // 상품매핑구분 OnChange
        cmb_prodMapCl_OnChange(value) {
            let current = this.gridObj.gridView.getCurrent()
            console.log('current', current)
            console.log('value', value)

            this.prodMapClCdList.map((prodMapCl) => {
                if (prodMapCl.commCdVal == value) {
                    this.gridObj.gridView.setValue(
                        current.dataRow,
                        'prodMapClNm',
                        prodMapCl.commCdValNm
                    )
                    return
                }
            })

            this.gridObj.gridView.setValue(
                current.dataRow,
                'prodMapClCd',
                value
            )
        },

        // 추가근무지 목록 - 행추가
        btn_add_OnClick() {
            this.gridObj.gridView.commit()
            let rowCount = this.gridObj.dataProvider.getRowCount()
            let rowData = {
                prodClCd: '--선택--',
                barCdTypCd: '--선택--',
                __rowState: 'created',
            }
            this.gridObj.dataProvider.insertRow(rowCount, rowData)
            CommonUtil.clearPage(this, 'div_btmParam')

            // this.div_search = {
            //     edt_prodMapCd: '', //상품 매핑 코드
            //     edt_prodMapCdIn: '', //상품매핑코드
            //     prodCd: '',
            //     prodNm: '',
            //     cmb_color: '', //색상
            //     cmb_prodMapCl: '', //상품매핑구분
            // }
        },

        //추가근무지 목록 - 행삭제
        btn_del_OnClick() {
            this.gridObj.gridView.commit()

            console.log(
                'this.gridObj.dataProvider.getStateRows()',
                this.gridObj.dataProvider.getStateRows()
            )

            // if (this.selectedJsonData.__rowState != 'created') {
            //     this.showTcComAlert('기등록된 데이터는 삭제할 수 없습니다.') //MSG_01005
            //     return
            // }

            // const row = this.gridObj.gridView.getCurrent()
            // this.gridObj.dataProvider.removeRow(row.dataRow)
            this.gridData = this.gridHeaderObj.focusDelRow(this.gridData)
        },

        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.div_btmParam).then((res) => {
                if (res.length === 1) {
                    this.div_btmParam.prodCd = _.get(res[0], 'prodCd')
                    this.div_btmParam.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.div_btmParam.prodCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.div_btmParam.prodCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },

        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            this.div_btmParam.prodCd = _.get(retrunData, 'prodCd')
            this.div_btmParam.prodNm = _.get(retrunData, 'prodNm')

            let current = this.gridObj.gridView.getCurrent()
            console.log('current', current)

            this.gridObj.gridView.setValue(
                current.dataRow,
                'prodCd',
                this.div_btmParam.prodCd
            )

            this.gridObj.gridView.setValue(
                current.dataRow,
                'prodNm',
                this.div_btmParam.prodNm
            )
            // this.dropDownSetting()
            this.getProdColor()
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
