import { ValueType } from 'realgrid'

//T신규상세 부가서비스 그리드
export const SVCGRIDHEARDER = {
    fields: [
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'suplSvcClCd',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'suplSvcClCdNm',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT, //부가서비스코드
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT, //부가서비명
        },
        {
            fieldName: 'scrbDt',
            dataType: ValueType.TEXT, //가입일자
        },
        {
            fieldName: 'svcStaDt',
            dataType: ValueType.TEXT, //가입일자
        },
        {
            fieldName: 'svcEndDt',
            dataType: ValueType.TEXT, //해지일자
        },
        {
            fieldName: 'endDurDt',
            dataType: ValueType.TEXT, //유지일
        },
        {
            fieldName: 'idmLmtCd',
            dataType: ValueType.TEXT, //유치기한코드
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, //변경일자
        },
    ],
    columns: [
        /*{
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            width: '100',
            header: {
                text: '구분',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },*/
        {
            name: 'suplSvcClCdNm',
            fieldName: 'suplSvcClCdNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '구분',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '서비스',
            },
        },
        {
            name: 'idmLmtCd',
            fieldName: 'idmLmtCd',
            type: 'data',
            width: '100',
            header: {
                text: '유치기한',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'svcStaDt',
            fieldName: 'svcStaDt',
            type: 'data',
            width: '100',
            header: {
                text: '가입일',
                showTooltip: false,
            },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'svcEndDt',
            fieldName: 'svcEndDt',
            type: 'data',
            width: '100',
            header: {
                text: '해지일',
                showTooltip: false,
            },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}

//T변경상세 부가서비스 그리드
export const CHGSVCGRIDHEARDER = {
    fields: [
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'suplSvcClCd',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'suplSvcClCdNm',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT, //부가서비스코드
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT, //부가서비명
        },
        {
            fieldName: 'scrbDt',
            dataType: ValueType.TEXT, //가입일자
        },
        {
            fieldName: 'svcStaDt',
            dataType: ValueType.TEXT, //가입일자
        },
        {
            fieldName: 'svcEndDt',
            dataType: ValueType.TEXT, //해지일자
        },
        {
            fieldName: 'endDurDt',
            dataType: ValueType.TEXT, //유지일
        },
        {
            fieldName: 'idmLmtCd',
            dataType: ValueType.TEXT, //유치기한코드
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, //변경일자
        },
    ],
    columns: [
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            width: '100',
            header: {
                text: '구분',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        /*{
            name: 'suplSvcClCdNm',
            fieldName: 'suplSvcClCdNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '구분',
            },
        },*/
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '서비스',
            },
        },
        {
            name: 'idmLmtCd',
            fieldName: 'idmLmtCd',
            type: 'data',
            width: '100',
            header: {
                text: '유치기한',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'scrbDt',
            fieldName: 'scrbDt',
            type: 'data',
            width: '100',
            header: {
                text: '가입일',
                showTooltip: false,
            },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'svcEndDt',
            fieldName: 'svcEndDt',
            type: 'data',
            width: '100',
            header: {
                text: '해지일',
                showTooltip: false,
            },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}
//T신규상세스마트디바이스 그리드
export const NEWDVCGRIDHEADER = {
    fields: [
        {
            fieldName: 'gearMfactCdNm',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'gearMdlNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'gearSerNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'gearDisClCdNm',
            dataType: ValueType.TEXT, //재고구분
        },
        {
            fieldName: 'gearSettlCondNm',
            dataType: ValueType.TEXT, //결제조건
        },
        {
            fieldName: 'gearUkeyAllotAmt',
            dataType: ValueType.TEXT, //고객부담금
        },
    ],
    columns: [
        {
            name: 'gearMfactCdNm',
            fieldName: 'gearMfactCdNm',
            type: 'data',
            width: '100',
            header: {
                text: '제조사',
            },
        },
        {
            name: 'gearMdlNm',
            fieldName: 'gearMdlNm',
            type: 'data',
            width: '100',
            header: {
                text: '모델',
            },
        },
        {
            name: 'gearSerNum',
            fieldName: 'gearSerNum',
            type: 'data',
            width: '100',
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'gearDisClCdNm',
            fieldName: 'gearDisClCdNm',
            type: 'data',
            width: '100',
            header: {
                text: '재고구분',
            },
        },
        {
            name: 'gearSettlCondNm',
            fieldName: 'gearSettlCondNm',
            type: 'data',
            width: '100',
            header: {
                text: '결제조건',
            },
        },
        {
            name: 'gearUkeyAllotAmt',
            fieldName: 'gearUkeyAllotAmt',
            type: 'data',
            width: '100',
            header: {
                text: '고객부담금',
            },
            styleName: 'right-column',
        },
    ],
}

//T변경상세스마트디바이스 그리드
export const CHGDVCGRIDHEADER = {
    fields: [
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'eqpMdlNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'disClNm',
            dataType: ValueType.TEXT, //재고구분
        },
        {
            fieldName: 'settlCondNm',
            dataType: ValueType.TEXT, //결제조건
        },
        {
            fieldName: 'custCmpAmt',
            dataType: ValueType.TEXT, //고객부담금
        },
    ],
    columns: [
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            width: '100',
            header: {
                text: '제조사',
            },
        },
        {
            name: 'eqpMdlNm',
            fieldName: 'eqpMdlNm',
            type: 'data',
            width: '100',
            header: {
                text: '모델',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'disClNm',
            fieldName: 'disClNm',
            type: 'data',
            width: '100',
            header: {
                text: '재고구분',
            },
        },
        {
            name: 'settlCondNm',
            fieldName: 'settlCondNm',
            type: 'data',
            width: '100',
            header: {
                text: '결제조건',
            },
        },
        {
            name: 'custCmpAmt',
            fieldName: 'custCmpAmt',
            type: 'data',
            width: '100',
            header: {
                text: '고객부담금',
            },
            styleName: 'right-column',
        },
    ],
}

//부가정책 그리드
export const POLGRIDHEADER = {
    fields: [
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //서비스분류코드
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT, //부가정책코드
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT, //부가정책
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT, //처리자
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT, //처리자
        },
        {
            fieldName: 'scrbDt',
            dataType: ValueType.TEXT, //처리일자
        },
    ],
    columns: [
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            type: 'data',
            width: '100',
            header: {
                text: '코드',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            width: '200',
            header: {
                text: '부가정책',
            },
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            width: '100',
            header: {
                text: '처리자',
            },
        },
        {
            name: 'scrbDt',
            fieldName: 'scrbDt',
            type: 'data',
            width: '130',
            header: {
                text: '처리일자',
            },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}
//번들상품 그리드
export const BDLGRIDHEADER = {
    fields: [
        {
            fieldName: 'freeProdSaleNo',
            dataType: ValueType.TEXT, // 상품판매번호
        },
        {
            fieldName: 'freeProdSaleChgSeq',
            dataType: ValueType.TEXT, // 일반상품판매변경번호
        },
        {
            fieldName: 'pkgProdSaleNo',
            dataType: ValueType.TEXT, // 일반상품주문번호
        },
        {
            fieldName: 'pkgProdSaleChgSeq',
            dataType: ValueType.TEXT, // 일반상품주문변경순번
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델(상품명)
        },
        {
            fieldName: 'prodDesc',
            dataType: ValueType.TEXT, // 상품설명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'disClCd',
            dataType: ValueType.TEXT, // 재고구분코드
        },
        {
            fieldName: 'giveMthdCd',
            dataType: ValueType.TEXT, // 인도방식코드
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'prodQty',
            dataType: ValueType.NUMBER, // 수량
        },
        {
            fieldName: 'saleUprc',
            dataType: ValueType.NUMBER, // 판매단가
        },
        {
            fieldName: 'fixStrdSalePrc',
            dataType: ValueType.NUMBER, // 확정기준판매가격
        },
        {
            fieldName: 'saleTypCd',
            dataType: ValueType.TEXT, // 판매유형코드
        },
        {
            fieldName: 'mfactCoCd',
            dataType: ValueType.TEXT, // 제조사코드
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, // 재고보유처
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT, // 입고처
        },
        {
            fieldName: 'dlvCoCd',
            dataType: ValueType.TEXT, // 배송처
        },
        {
            fieldName: 'dlvYn',
            dataType: ValueType.TEXT, // 배송여부
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT, // 삭제여부
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, // 수정횟수
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT, // 입력사용자ID
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT, // 입력일시
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 수정사용자ID
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 수정일시
        },
        {
            fieldName: 'ordProdSeq',
            dataType: ValueType.TEXT, // 주문상품순번
        },
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT, // 선택
        },
        {
            fieldName: 'pkgSaleNo',
            dataType: ValueType.TEXT, // 패키지판매번호
        },
    ],
    columns: [
        {
            name: 'saleTypCd',
            fieldName: 'saleTypCd',
            type: 'data',
            width: '100',
            header: {
                text: '판매유형',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'giveMthdCd',
            fieldName: 'giveMthdCd',
            type: 'data',
            width: '100',
            header: {
                text: '배송구분',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '400',
            styleName: 'left-column',
            header: {
                text: '모델명',
                showTooltip: true,
            },
            button: 'action',
            buttonVisibility: 'always',
            buttonVisibleCallback(grid, index) {
                return grid.getValue(index.itemIndex, 'saleTypCd') === 'ST02'
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            header: {
                text: '일련번호',
                showTooltip: false,
            },
            button: 'action',
            buttonVisibility: 'always',
            buttonVisibleCallback(grid, index) {
                return grid.getValue(index.itemIndex, 'saleTypCd') !== 'ST02'
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '70',
            header: {
                text: '모델코드',
                showTooltip: true,
            },
            visible: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            header: {
                text: '색상',
                showTooltip: true,
            },
            editable: true,
            lookupDisplay: true,
            values: ['99'],
            labels: ['공통색상'],
            editor: {
                type: 'dropdown',
            },
            lookupSourceId: 'prodColorList',
            lookupKeyFields: ['prodCd', 'colorCd'],
            styleCallback(grid, dataCell) {
                let ret = {}
                let saleTypCd = grid.getValue(
                    dataCell.index.itemIndex,
                    'saleTypCd'
                )
                if (saleTypCd === 'ST02') {
                    ret.editor = {
                        type: 'dropdown',
                    }
                    ret.editable = true
                } else {
                    ret.editor = {
                        type: 'text',
                    }
                    ret.editable = false
                }
                return ret
            },
        },
        {
            name: 'prodDesc',
            fieldName: 'prodDesc',
            type: 'data',
            width: '150',
            header: {
                text: '모델설명',
                showTooltip: true,
            },
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            header: {
                text: '상품구분',
                showTooltip: true,
            },
            lookupDisplay: true,
            values: [],
            labels: [],
            // editor: {
            //     type: 'dropdown',
            // },
            editable: false,
            styleCallback(grid, dataCell) {
                let ret = {}
                let saleTypCd = grid.getValue(
                    dataCell.index.itemIndex,
                    'saleTypCd'
                )
                if (saleTypCd === 'ST02') {
                    ret.editor = {
                        type: 'dropdown',
                    }
                    // ret.editable = true
                } else {
                    ret.editor = {
                        type: 'text',
                    }
                    //ret.editable = false
                }
                return ret
            },
        },
        {
            name: 'saleUprc',
            fieldName: 'saleUprc',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '판매단가',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
            },
            numberFormat: '#,##0',
            editable: true,
        },
    ],
}
