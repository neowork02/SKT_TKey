<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="650px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">상품색상검색</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="contBoth mgt-20">
                        <!-- left area -->
                        <div class="div5_5 cont1-1 left">
                            <TCRealGridHeader
                                id="colorsGridHeader"
                                ref="colorsGridHeader"
                                gridTitle="전체색상목록"
                                :gridObj="gridObj"
                            />
                            <TCRealGrid
                                id="colorsGrid"
                                ref="colorsGrid"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                        </div>
                        <!-- //left area -->
                        <!-- arrow area -->
                        <div class="div5_5 cont3">
                            <ul class="btnOrder">
                                <li>
                                    <TCComButton
                                        :Vuetify="false"
                                        eClass="btnOrderright"
                                        :objAuth="objAuth"
                                        @click="onRight"
                                    >
                                        right
                                    </TCComButton>
                                </li>
                                <li>
                                    <TCComButton
                                        :Vuetify="false"
                                        eClass="btnOrderleft"
                                        :objAuth="objAuth"
                                        @click="onLeft"
                                    >
                                        left
                                    </TCComButton>
                                </li>
                            </ul>
                        </div>
                        <!-- //arrow area -->
                        <!-- right area -->
                        <div class="div5_5 cont1-1 right pl0">
                            <TCRealGridHeader
                                id="colorsGridHeader2"
                                ref="colorsGridHeader2"
                                gridTitle="상품색상목록"
                                :gridObj="gridObj2"
                            />
                            <TCRealGrid
                                id="colorsGrid2"
                                ref="colorsGrid2"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                            <!-- //right area -->
                        </div>
                        <!-- Bottom BTN Group -->
                        <div class="btn_area_bottom">
                            <TCComButton
                                :eLarge="true"
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                @click="onConfirm"
                            >
                                확인
                            </TCComButton>
                            <TCComButton
                                :eLarge="true"
                                eClass="btn_ty02"
                                @click="onClose"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton>
                        </div>
                        <!-- // Bottom BTN Group -->
                    </div>
                </div>
                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
        </template>
    </TCComDialog>
</template>

<script>
import { basBcoProdColorsHeader } from '@/const/grid/bas/bco/basBcoProdColorsHeader'
import basBcoProdColorsApi from '@/api/biz/bas/bco/basBcoProdColors'
import _ from 'lodash'
export default {
    name: 'BasBcoProdColorsPopup',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            showAlertBool: false,
            headerText: '',
            alertBodyText: '',
            objAuth: {},
            view: basBcoProdColorsHeader,
            gridObj: {},
            gridHeaderObj: {},
            gridObj2: {},
            gridHeaderObj2: {},
            searchProdColorsParam: {
                prodCd: '', // 상품코드
            },
        }
    },

    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.colorsGrid
        this.gridHeaderObj = this.$refs.colorsGridHeader
        this.gridObj2 = this.$refs.colorsGrid2
        this.gridHeaderObj2 = this.$refs.colorsGridHeader2
        this.initGrid()

        this.gridObj.gridView.columnByName('prodCd').visible = false
        this.gridObj2.gridView.columnByName('prodCd').visible = false
        //더블클릭으로 이동
        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            //const getCurrentIdx = this.gridObj.gridView.getCurrent().dataRow

            let jsonData = this.gridObj.dataProvider.getJsonRow(
                clickData.dataRow
            )

            this.gridObj2.dataProvider.addRow(jsonData)
            var current = this.gridObj.gridView.getSelectedRows()
            this.gridObj.dataProvider.removeRows(current)
        }

        this.gridObj2.gridView.onCellDblClicked = (grid, clickData) => {
            let jsonData = this.gridObj2.dataProvider.getJsonRow(
                clickData.dataRow
            )
            //맨위로이동
            this.gridObj.dataProvider.insertRow(0, jsonData)
            var current = this.gridObj2.gridView.getSelectedRows()
            this.gridObj2.dataProvider.removeRows(current)
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchProdColorsParam.prodCd =
                    value['prodCd'] == undefined ? '' : value['prodCd']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, true)
            this.gridObj2.setGridState(false, false, true)
            if (!this.rows.length) {
                this.getProdColors()
            } else {
                this.setProdColors()
            }
        },
        //Color API
        getProdColors() {
            basBcoProdColorsApi
                .getProdColors(this.searchProdColorsParam)
                .then((res) => {
                    console.log('getProdColors : ', res)
                    this.gridObj.setRows(res.prodNonAplyColorPopDto)
                    console.log('이전등록된컬러:', res.prodAplyColorPopDto)
                    this.gridObj2.setRows(res.prodAplyColorPopDto)
                })
        },

        //기존에 상품색상이 있는경우
        setProdColors() {
            basBcoProdColorsApi
                .getProdColors(this.searchProdColorsParam)
                .then((res) => {
                    //부모선택색상이 그리드에표시
                    this.gridObj2.setRows(this.rows)
                    let addRow = res.prodNonAplyColorPopDto
                    for (var i = 0; i < addRow.length; i++) {
                        //등록된 값이 없으면 그리드에 추가
                        if (_.findIndex(this.rows, addRow[i]) == '-1') {
                            this.gridObj.dataProvider.addRow(addRow[i])
                        }
                    }
                })
        },
        //색상선택
        onRight() {
            let chkRow = this.gridObj.gridView.getCheckedRows(true)
            //체크된 행 이동
            for (var i = 0; i < chkRow.length; i++) {
                let row = this.gridObj.dataProvider.getJsonRow(chkRow[i])
                //그리드에 표시
                this.gridObj2.dataProvider.addRow(row)
            }
            this.gridObj.dataProvider.removeRows(chkRow)
        },
        //색상선택해제
        onLeft() {
            //체크된
            let chkRow = this.gridObj2.gridView.getCheckedRows(true)
            //체크된 행 이동
            for (var i = 0; i < chkRow.length; i++) {
                var row = this.gridObj2.dataProvider.getJsonRow(chkRow[i])
                //그리드에 표시
                this.gridObj.dataProvider.insertRow(0, row)
            }
            this.gridObj2.dataProvider.removeRows(chkRow)
        },
        onConfirm() {
            const jsonData = this.gridObj2.dataProvider.getJsonRows()
            if (jsonData.length == 0) {
                this.showAlertBool = true
                this.headerText = '색상'
                this.alertBodyText = '색상을 선택해주세요.'
                return
            }
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },
    },
}
</script>
