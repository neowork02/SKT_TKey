import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'orgCd', // 조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd1', // 사업담당
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd2', // 영업팀
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd3', // 영업파트
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1', // 사업담당
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2', // 영업팀
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm3', // 영업파트
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd', // 거래처코드 // 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoNm', // 거래처명 // 매장명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm1', // 거래처구분명1 // 매장유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bfBondBamt', //전월기말잔액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'frstChagAmt', // SKT수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dpstFrstAmt', // 1차 현금입금 // 1차요금현금수납금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'frstSaleAmt', // 1차 현금매출 // 1차현금매출금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pediFrstAmt', // 1차 카드매출 EDI // 카드매출EDI1차금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pcpgFrstAmt', // 1차 PG // PG1차금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'frstPrxpayAmt', // 1차 기타수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'frstSaleSumAmt', // 1차 매출상품소계 // 1차매출상품소계금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'scndChagAmt', // SKT수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dpstScndAmt', // 2차 현금입금 // 2차요금현금수납금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'scndSaleAmt', // 2차 현금매출 // 2차현금매출금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pediScndAmt', // 2차 카드매출 EDI // 카드매출EDI 2차금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pcpgScndAmt', // 2차 PG // PG2차금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'scndPrxpayAmt', // 2차 기타수납
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'scndSaleSumAmt', // 2차 매출상품소계 // 2차매출상품소계금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'etcSaleAmt', // 기타매출 현금
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'etcSaleCardAmt', // 기타매출 카드
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bondBamt', // 기말잔액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'delYn', // 삭제여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // 수정횟수
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            header: '조직명',
            styleName: 'left-column',
        },
        {
            name: 'lvOrgNm1',
            fieldName: 'lvOrgNm1',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '사업담당',
        },
        {
            name: 'lvOrgNm2',
            fieldName: 'lvOrgNm2',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '영업팀',
        },
        {
            name: 'lvOrgNm3',
            fieldName: 'lvOrgNm3',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '영업파트',
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            header: '매장코드',
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            header: '매장명',
        },
        {
            name: 'dealcoClNm1',
            fieldName: 'dealcoClNm1',
            type: 'data',
            header: '매장유형',
        },
        {
            name: 'bfBondBamt',
            fieldName: 'bfBondBamt',
            type: 'data',
            styleName: 'right-column',
            header: '전월기말잔액', // ***********
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'frstChagAmt',
            fieldName: 'frstChagAmt',
            type: 'data',
            styleName: 'right-column',
            header: 'SKT수납', // 1차 ***********
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'dpstFrstAmt',
            fieldName: 'dpstFrstAmt',
            type: 'data',
            styleName: 'right-column',
            header: '현금입금', // 1차
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'frstSaleAmt',
            fieldName: 'frstSaleAmt',
            type: 'data',
            styleName: 'right-column',
            header: '현금매출', // 1차
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'pediFrstAmt',
            fieldName: 'pediFrstAmt',
            type: 'data',
            styleName: 'right-column',
            header: '카드매출 EDI', // 1차
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'pcpgFrstAmt',
            fieldName: 'pcpgFrstAmt',
            type: 'data',
            styleName: 'right-column',
            header: 'PG', // 1차
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'frstPrxpayAmt',
            fieldName: 'frstPrxpayAmt',
            type: 'data',
            styleName: 'right-column',
            header: '기타수납', // 1차 **************
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'frstSaleSumAmt',
            fieldName: 'frstSaleSumAmt',
            type: 'data',
            styleName: 'right-column',
            header: '매출상품소계', // 1차
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'scndChagAmt',
            fieldName: 'scndChagAmt',
            type: 'data',
            styleName: 'right-column',
            header: 'SKT수납', // 2차
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'dpstScndAmt',
            fieldName: 'dpstScndAmt',
            type: 'data',
            styleName: 'right-column',
            header: '현금입금', // 2차 ***********
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'scndSaleAmt',
            fieldName: 'scndSaleAmt',
            type: 'data',
            styleName: 'right-column',
            header: '현금매출', // 2차
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'pediScndAmt',
            fieldName: 'pediScndAmt',
            type: 'data',
            styleName: 'right-column',
            header: '카드매출 EDI', // 2차
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'pcpgScndAmt',
            fieldName: 'pcpgScndAmt',
            type: 'data',
            styleName: 'right-column',
            header: 'PG', // 2차
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'scndPrxpayAmt',
            fieldName: 'scndPrxpayAmt',
            type: 'data',
            styleName: 'right-column',
            header: '기타수납', // 2차 **************
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'scndSaleSumAmt',
            fieldName: 'scndSaleSumAmt',
            type: 'data',
            styleName: 'right-column',
            header: '매출상품소계', // 2차
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'etcSaleAmt',
            fieldName: 'etcSaleAmt',
            type: 'data',
            styleName: 'right-column',
            header: '1일~말일 기타매출(현금)',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'etcSaleCardAmt',
            fieldName: 'etcSaleCardAmt',
            type: 'data',
            styleName: 'right-column',
            header: '1일~말일 기타매출(카드)',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'bondBamt',
            fieldName: 'bondBamt',
            type: 'data',
            styleName: 'right-column',
            header: '기말잔액',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],
    layout: [
        'orgCd',
        'orgNm',
        // 'lvOrgNm1',
        // 'lvOrgNm2',
        // 'lvOrgNm3',
        'saleDealcoCd',
        'saleDealcoNm',
        'dealcoClNm1',
        'bfBondBamt',
        {
            name: '전송유형',
            direction: 'horizontal',
            items: [
                {
                    name: '1차(1일~20일)',
                    direction: 'horizontal',
                    items: [
                        'frstChagAmt',
                        'dpstFrstAmt',
                        'frstSaleAmt',
                        'pediFrstAmt',
                        'pcpgFrstAmt',
                        'frstPrxpayAmt',
                        'frstSaleSumAmt',
                    ],
                },
                {
                    name: '2차(21일~말일)',
                    direction: 'horizontal',
                    items: [
                        'scndChagAmt',
                        'dpstScndAmt',
                        'scndSaleAmt',
                        'pediScndAmt',
                        'pcpgScndAmt',
                        'scndPrxpayAmt',
                        'scndSaleSumAmt',
                    ],
                },
                'etcSaleAmt',
                'etcSaleCardAmt',
            ],
        },
        'bondBamt',
    ],
}
