import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'barCdTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'allLenCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mdlStaLenCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mdlEndLenCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mdlLenCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorStaLenCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorEndLenCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorLenCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNumStaLenCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNumEndLenCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNumLenCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: '__rowState',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            header: {
                text: '상품구분코드',
            },
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            // styleCallback: function (grid, dataCell) {
            //     var gubun = grid.getValue(dataCell.index.itemIndex, 'allLenCnt')
            //     var ret = {}
            //     console.log('gubun', gubun)
            //     switch (gubun) {
            //         //구분값이 T이면 text에디터를 표시
            //         case undefined:
            //             ret.editor = {
            //                 type: 'dropdown',
            //                 dropDownCount: 10,
            //                 domainOnly: true,
            //                 textReadOnly: true,
            //                 values: [],
            //                 labels: [],
            //             }
            //             break
            //     }
            //     return ret
            // },
        },
        {
            name: 'barCdTypCd',
            fieldName: 'barCdTypCd',
            header: {
                text: '바코드유형코드',
            },
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            // styleCallback: function (grid, dataCell) {
            //     var gubun = grid.getValue(dataCell.index.itemIndex, 'allLenCnt')
            //     var ret = {}
            //     console.log('grid', grid)
            //     console.log('dataCell', dataCell)
            //     switch (gubun) {
            //         //구분값이 T이면 text에디터를 표시
            //         case undefined:
            //             ret.editor = {
            //                 type: 'dropdown',
            //                 dropDownCount: 10,
            //                 domainOnly: true,
            //                 textReadOnly: true,
            //                 values: [],
            //                 labels: [],
            //             }
            //             break
            //     }
            //     return ret
            // },
        },
        {
            name: 'allLenCnt',
            fieldName: 'allLenCnt',
            header: {
                text: '전체자리수',
            },
            numberFormat: '',
        },
        {
            name: 'mdlStaLenCnt',
            fieldName: 'mdlStaLenCnt',
            header: {
                text: '시작',
            },
        },
        {
            name: 'mdlEndLenCnt',
            fieldName: 'mdlEndLenCnt',
            header: {
                text: '끝',
            },
        },
        {
            name: 'mdlLenCnt',
            fieldName: 'mdlLenCnt',
            header: {
                text: '자리수',
            },
        },
        {
            name: 'colorStaLenCnt',
            fieldName: 'colorStaLenCnt',
            header: {
                text: '시작',
            },
        },
        {
            name: 'colorEndLenCnt',
            fieldName: 'colorEndLenCnt',
            header: {
                text: '끝',
            },
        },
        {
            name: 'colorLenCnt',
            fieldName: 'colorLenCnt',
            header: {
                text: '자리수',
            },
        },
        {
            name: 'serNumStaLenCnt',
            fieldName: 'serNumStaLenCnt',
            header: {
                text: '시작',
            },
        },
        {
            name: 'serNumEndLenCnt',
            fieldName: 'serNumEndLenCnt',
            header: {
                text: '끝',
            },
        },
        {
            name: 'serNumLenCnt',
            fieldName: 'serNumLenCnt',
            header: {
                text: '자리수',
            },
        },
    ],
}
