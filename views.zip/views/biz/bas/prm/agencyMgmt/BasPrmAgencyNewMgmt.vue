<!-----------------------------------------------
 * 업무그룹명: 기준정보>영업기준정보관리
 * 서브업무명: 대리점관리
 * 설명: 대리점관리 조회/입력/수정/삭제 한다.
 * 작성자: P143001
 * 작성일: 2022.11.28
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>대리점관리</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <!-- <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="agencyPopBtn"
                    :objAuth="this.objAuth"
                >
                    대리점등록
                </TCComButton> -->
            </li>
        </ul>
        <!-- searchLayer_wrap -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="ds_aplyYn"
                        labelName="등록여부"
                        v-model="formSearchParams.aplyYn"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="ds_unt"
                        labelName="대리점구분"
                        v-model="formSearchParams.untClCd"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.agencyCd"
                        labelName="대리점코드"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.agencyNm"
                        labelName="대리점명"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.repUserId"
                        labelName="대표자ID"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="formSearchParams.repUserNm"
                        labelName="대표자명"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="agencyMgmtGridHeader"
                ref="agencyMgmtGridHeader"
                gridTitle="대리점목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="false"
                :isPageCnt="false"
                :editable="true"
                @excelDownBtn="this.excelDownBtn"
            />
            <TCRealGrid
                id="agencyMgmtGrid"
                ref="agencyMgmtGrid"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="searchBtn"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <BasPrmAgencyNewMgmtPopUp
            v-if="showBasPrmAgencyNewMgmt"
            :parentParam="searchPopUpParam"
            :rows="resultBasPrmAgencyRows"
            :dialogShow.sync="showBasPrmAgencyNewMgmt"
        />
    </div>
</template>
<script>
import { CommonGrid } from '@/utils'
import CommonMixin from '@/mixins'
import _ from 'lodash'
import { M_HEADER } from '@/const/grid/bas/prm/basPrmAgencyNewMgmtHeader'
import API from '@/api/biz/bas/prm/basPrmAgencyNewMgmt'
//====================사용자등록팝업====================
import BasPrmAgencyNewMgmtPopUp from '@/views/biz/bas/prm/agencyMgmt/BasPrmAgencyNewMgmtPopUp'
//====================사용자등록팝업====================
export default {
    name: 'BasPrmAgencyNewMgmt',
    mixins: [CommonMixin],
    props: {},
    components: { BasPrmAgencyNewMgmtPopUp },
    data() {
        return {
            objAuth: {},
            formSearchParams: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
                repUserId: '', //  대표자ID
                repUserNm: '', // 대표자명
                aplyYn: '',
                untClCd: '',
                pageNum: '',
                pageSize: '',
            },
            gridObj: {},
            view: M_HEADER,
            gridData: this.gridSetData(),
            rowCnt: 15, // 표시할 행의 갯수
            pageNum: '',
            pageSize: '',
            ds_aplyYn: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: '등록',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '미등록',
                },
            ],
            ds_unt: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: '일반대리점',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '연합대리점',
                },
            ],
            layout: [
                'pagingSeq',
                'aplyYnNm',
                'untClNm',
                {
                    name: 'group',
                    direction: 'horizontal',
                    items: [
                        'mktOrgCd',
                        'mktSubCd',
                        'mktOrgNm',
                        'cntrOrgCd',
                        'cntrSubCd',
                        'cntrOrgNm',
                    ],
                    header: {
                        text: 'SKT 정보',
                    },
                },
                {
                    name: 'group',
                    direction: 'horizontal',
                    items: ['orgCd', 'orgNm', 'agencyCd', 'agencyNm'],
                    header: {
                        text: 'T.Key Taka 정보',
                    },
                    rowCnt: 15,
                },
                'endDt',
                'repUserId',
                'repUserNm',
            ],
            //====================팝업====================
            showBasPrmAgencyNewMgmt: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchPopUpParam: {
                searchPopUpParam: this.formSearchParams,
            },
            resultBasPrmAgencyRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
        }
    },
    async mounted() {
        let paramObj = {}

        paramObj.pageNum = ''
        paramObj.pageSize = this.gridData.totalPage
        this.gridObj = this.$refs.agencyMgmtGrid
        this.gridHeaderObj = this.$refs.agencyMgmtGridHeader
        this.gridObj.setGridState(false, false, false, false)
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            console.log('등록팝업오픈', clickData)
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                clickData.dataRow
            )
            console.log('등록팝업오픈 DATA ', jsonData)
            this.onGridClick(jsonData)
        }
    },
    methods: {
        async initBtn() {
            console.log('🚀 ~ file: BasPrmAgencyNewMgmt.vue initBtn')
        },
        onSearch() {
            this.searchBtn(1)
        },
        async searchBtn(pageNum) {
            console.log('🚀 ~ file: BasPrmAgencyNewMgmt.vue searchBtn')

            let paramObj = { ...this.formSearchParams }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt
            console.log('onSearch조회 파라미터 ', paramObj)
            // 페이징 조회
            API.getBasPrmAgencyMgmtList_(paramObj).then((resultData) => {
                if (_.isEmpty(resultData.gridList)) {
                    this.showTcComAlert('조회된 데이터가 없습니다')

                    this.gridData = this.gridSetData()
                    this.gridObj.dataProvider.clearRows()

                    return
                }
                console.log(resultData)

                this.gridObj.setRows(resultData.gridList) // 임시주석
                // 페이징 관련
                this.gridObj.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData() //초기화
                this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },
        async agencyPopBtn() {
            console.log('🚀 ~ file: BasPrmAgencyNewMgmt.vue agencyPopBtn')
        },
        async gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        async excelDownBtn() {
            console.log('🚀 ~ file: BasPrmAgencyNewMgmt.vue excelDownBtn')
        },
        chgRowCnt(val) {
            this.rowCnt = val
            // eslint-disable-next-line no-undef
            this.searchBtn()
        },
        //===================== //등록팝업수정 methods ================================
        onGridClick(jsonData) {
            this.resultBasPrmAgencyRows = []
            this.searchPopUpParam = jsonData

            this.showBasPrmAgencyNewMgmt = true
        },
    },
}
</script>
