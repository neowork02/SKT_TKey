import { ValueType } from 'realgrid'

export const GRID_INFO_PAY = {
    fields: [
        {
            fieldName: 'svcGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'svcGridCd',
            fieldName: 'svcGridCd',
            type: 'data',
            header: {
                text: '선후불유형코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'svcGridNm',
            fieldName: 'svcGridNm',
            type: 'data',
            header: {
                text: '선후불유형명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_CUST = {
    fields: [
        {
            fieldName: 'svcGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'svcGridCd',
            fieldName: 'svcGridCd',
            type: 'data',
            header: {
                text: '고객유형코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'svcGridNm',
            fieldName: 'svcGridNm',
            type: 'data',
            header: {
                text: '고객유형명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_SVC = {
    fields: [
        {
            fieldName: 'svcGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'svcGridCd',
            fieldName: 'svcGridCd',
            type: 'data',
            header: {
                text: '서비스구분코드',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'svcGridNm',
            fieldName: 'svcGridNm',
            type: 'data',
            header: {
                text: '서비스구분명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_SCRB = {
    fields: [
        {
            fieldName: 'svcGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        // {
        //     name: 'svcGridCd',
        //     fieldName: 'svcGridCd',
        //     type: 'data',
        //     header: {
        //         text: '가입유형코드',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     editable: false,
        // },
        {
            name: 'svcGridNm',
            fieldName: 'svcGridNm',
            type: 'data',
            header: {
                text: '가입유형명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_AGREE = {
    fields: [
        {
            fieldName: 'svcGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        // {
        //     name: 'svcGridCd',
        //     fieldName: 'svcGridCd',
        //     type: 'data',
        //     header: {
        //         text: '약정그룹코드',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     editable: false,
        // },
        {
            name: 'svcGridNm',
            fieldName: 'svcGridNm',
            type: 'data',
            header: {
                text: '약정그룹명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_POL = {
    fields: [
        {
            fieldName: 'svcGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcGridNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        // {
        //     name: 'svcGridCd',
        //     fieldName: 'svcGridCd',
        //     type: 'data',
        //     header: {
        //         text: '정책구분코드',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     editable: false,
        // },
        {
            name: 'svcGridNm',
            fieldName: 'svcGridNm',
            type: 'data',
            header: {
                text: '정책구분명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_AGE = {
    fields: [
        {
            fieldName: 'svcGridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ageStDt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ageEnDt',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'ageStDt',
            fieldName: 'ageStDt',
            type: 'number',
            header: {
                text: '적용시작년월',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: {
                type: 'text',
                maxLength: 6,
                editFormat: '([0-9]{4})([0-9]{2})$;$1$2',
            },
            numberFormat: '([0-9]{4})([0-9]{2})$;$1$2',
        },
        {
            name: 'ageEnDt',
            fieldName: 'ageEnDt',
            type: 'number',
            header: {
                text: '적용종료년월',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: {
                type: 'text',
                maxLength: 6,
                editFormat: '([0-9]{4})([0-9]{2})$;$1$2',
            },
            numberFormat: '([0-9]{4})([0-9]{2})$;$1$2',
        },
    ],
}
