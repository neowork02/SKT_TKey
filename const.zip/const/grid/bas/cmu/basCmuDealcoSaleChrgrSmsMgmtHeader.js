import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'pagingSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effUserYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dam',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'team',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'pt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sendYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'sendYn',
            fieldName: 'sendYn',
            header: {
                text: '전송여부',
            },
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: '0',
            },
            width: 50,
        },
        {
            name: 'pagingSeq',
            fieldName: 'pagingSeq',
            header: {
                text: 'No.',
            },
            editable: false,
            width: 40,
        },
        {
            name: 'userId',
            fieldName: 'userId',
            header: {
                text: '사용자ID',
            },
            editable: false,
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            header: {
                text: '사용자명',
            },
            editable: false,
        },
        {
            name: 'effUserYn',
            fieldName: 'effUserYn',
            header: {
                text: '유효사용자',
            },
            editable: false,
        },
        {
            name: 'userGrpCd',
            fieldName: 'userGrpCd',
            header: {
                text: '사용자그룹',
            },
            editable: false,
        },
        {
            name: 'dam',
            fieldName: 'dam',
            header: {
                text: '사업담당',
            },
            editable: false,
        },
        {
            name: 'team',
            fieldName: 'team',
            header: {
                text: '영업팀',
            },
            editable: false,
        },
        {
            name: 'pt',
            fieldName: 'pt',
            header: {
                text: '파트',
            },
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            header: {
                text: '처리자',
            },
            editable: false,
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            header: {
                text: '처리자ID',
            },
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '처리일시',
            },
            editable: false,
        },
    ],
}
