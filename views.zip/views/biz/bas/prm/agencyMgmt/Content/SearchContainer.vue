<template>
    <div>
        <ul class="btn_area top">
            <!-- <li class="left">
                <v-btn outlined class="btn_ty">삭제</v-btn>
            </li> -->
            <li class="right">
                <div class="rightBox">
                    <TCComButton
                        color="btn2"
                        eClass="btn_ty01"
                        @click="initBtn"
                        :objAuth="this.objAuth"
                    >
                        초기화
                    </TCComButton>
                    <TCComButton
                        color="btn2"
                        eClass="btn_ty01"
                        @click="searchBtn"
                        :objAuth="this.objAuth"
                    >
                        조회
                    </TCComButton>
                    <TCComButton
                        color="btn2"
                        eClass="btn_ty01"
                        @click="saveBtn"
                        :objAuth="this.objAuth"
                    >
                        저장
                    </TCComButton>
                </div>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComDatePicker
                        v-model="aplyStaDt"
                        :calType="calType5"
                        labelName="조회년월"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="대리점유형"
                        v-model="formSearchParams.agencyTypCd"
                        :objAuth="objAuth"
                        @change="selectChange"
                        codeId="AGENCY_TYP"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        labelName="대리점"
                        :appendIconClass="''"
                        @appendIconClick="searchCommon('agency')"
                        :objAuth="this.objAuth"
                        v-model="agencyNm"
                        :codeVal="formSearchParams.agencyCd"
                        :disabledAfter="true"
                        @input="onAgencyInput"
                    />
                </div>
            </div>
        </div>
        <BasBcoAgencysPopup
            v-if="showBcoAgencys"
            :parentParam="searchParam"
            :rows="resultAgencyRows"
            :dialogShow.sync="showBcoAgencys"
            @confirm="onAgencyReturnData"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/agencyMgmt/helpers'
import moment from 'moment'
//import CommonUtil from '@/utils/CommonUtil.js'
import { msgTxt } from '@/const/msg.Properties.js'
//====================대리점팝업====================
import BasBcoAgencysPopup from '@/components/common/BasBcoAgencysPopup'
//====================//대리점팝업====================
export default {
    components: {
        //TCComComboBox,
        BasBcoAgencysPopup,
    },
    async created() {
        await this.initControls()
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            calType5: 'M',
            aplyStaDt: '',
            agencyNm: '',
            formSearchParams: {
                aplyStaDt: '', //조회년월
                agencyTypCd: '', //대리점유형
                agencyCd: '', //대리점코드
            },
            //====================대리점팝업관련====================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            searchParam: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
        }
    },
    async mounted() {
        //화면초기 로딩시 바로 검색
        this.searchBtn()
    },
    computed: {
        ...serviceComputed,
        commCdIds1: {
            get() {
                return this.commCdIds
            },
            //set(value) {},
        },
        saveDone1: {
            get() {
                return this.saveDoneA && this.saveDoneB
            },
            //set(value) {},
        },
    },
    methods: {
        ...serviceMethods,
        async initControls() {
            //await this.commonCodes_({ option: '전체' })
            //this.defaultAssign_({ key: 'plantCd', value: this.user.plantCd }); //watch call searchList()
        },
        async initData() {
            let today = moment(new Date()).format('YYYY-MM')
            this.aplyStaDt = today
            this.agencyNm = '' //대리점명
            this.formSearchParams.agencyCd = '' //대리점코드
            this.formSearchParams.aplyStaDt = moment(new Date()).format(
                'YYYYMM'
            ) //조회년월
            this.formSearchParams.agencyTypCd = '' //대리점유형
            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
        },
        selectChange(val) {
            console.log('🚀 ~ file: selectChange ~ line 58 ~ selectChange', val)
        },
        searchCommon(flag) {
            // TODO 공통팝업 호출
            if (flag === 'mfact') {
                alert('제조사')
            } else if (flag === 'org') {
                alert('조직')
            } else if (flag === 'prod') {
                alert('모델')
            } else if (flag === 'outPlc') {
                alert('보유처')
            } else if (flag === 'agency') {
                this.resultAgencyRows = []
                this.showBcoAgencys = true
            }
        },
        async initBtn() {
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 122 ~ data ',
                this.$data
            )
            await this.initData()
            //CommonUtil.clearPage(this.$router)
        },
        async searchBtn() {
            // let fromDt = new Date(this.aplyStaDt[0])
            // let toDt = new Date(this.aplyStaDt[1])
            // if (fromDt > toDt) {
            //     this.showAlert_({
            //         title: '세금계산서일자 오류',
            //         message: '시작일자가 마지막일자 보다 큽니다.',
            //     })
            //     return
            // }
            // if (
            //     moment(fromDt).format('YYYY-MM') !=
            //     moment(toDt).format('YYYY-MM')
            // ) {
            //     this.showAlert_({
            //         title: '세금계산서일자 오류',
            //         message: '같은 월 검색만 됩니다.',
            //     })
            //     return
            // }
            await this.defaultAssign_({ key: 'paging', value: this.initPaging })
            this.formSearchParams.aplyStaDt = this.aplyStaDt.replace(/-/g, '')
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 197 ~ searchBtn ~ this.formSearchParams',
                this.formSearchParams
            )
            await this.defaultAssign_({
                key: 'searchParams',
                value: this.formSearchParams,
            })
            await this.searchData()
        },
        async searchData() {
            this.loading(true)
            let data1
            await this.getBasPrmAgencyMgmtList_()
                .then((data) => {
                    // console.log(
                    //     '🚀 ~ file: SearchContent.vue ~ line 51 ~ searchData ~ data',
                    //     data
                    // )
                    data1 = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    //this.$sf_toggleLoading(false);
                    console.log('🚀 ~ file: SearchContent.vue ~ finally')
                    this.loading(false)
                    if (data1 !== undefined && data1.gridList.length == 0) {
                        this.toasting_({
                            message: msgTxt.MSG_00039.replace(/%s/g, ''),
                        })
                    }
                })
        },
        async saveBtn() {
            this.formSearchParams.aplyStaDt = this.aplyStaDt.replace(/-/g, '')
            console.log('🚀 ~ file: saveBtn~ line 122 ~ data ', this.$data)
            await this.defaultAssign_({
                key: 'saveAction',
                value: true,
            })
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        // 대리점 TextField Input 이벤트 처리
        onAgencyInput() {
            // 입력되는 값이 있으면 대리점 코드 초기화
            this.searchParam.agencyCd = ''
            this.formSearchParams.agencyCd = ''
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.formSearchParams.agencyCd = retrunData.agencyCd
            this.agencyNm = retrunData.agencyNm
        },
    },
    watch: {
        async saveDone1(val, oldVal) {
            if (val == true) {
                console.log('saveDone1: ', val, oldVal)
                //saveAction 작업들이 모두 완료 되면 default 상태로 변환
                await this.defaultAssign_({
                    key: 'saveAction',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: false,
                })
            }
        },
    },
}
</script>
<style>
.rightBox {
    display: flex;
    flex-direction: row;
    gap: 0.5em;
    height: 35px;
}
.rightBox .iteminput {
    width: 150px !important;
    flex-direction: row;
    flex-grow: 1;
    flex-shrink: 1;
}
.rightBox .v-input__slot {
    width: 140px !important;
    flex-direction: row;
    flex-grow: 1;
    flex-shrink: 1;
}
</style>
