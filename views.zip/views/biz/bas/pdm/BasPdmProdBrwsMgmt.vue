<template>
    <div class="content">
        <!-- Tit -->
        <h1>상품관리</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="dialogExpClicked()"
                    :objAuth="this.objAuth"
                    >확장모델등록</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                    >조회</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="dialogClicked()"
                    :objAuth="this.objAuth"
                    >신규</TCComButton
                >
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        v-model="forms.prodClCd"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        @change="prodClCdChange"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInput
                        labelName="모델명/상품명"
                        :objAuth="this.objAuth"
                        v-model="forms.prodNm"
                        @enterKey="searchBtn"
                    >
                    </TCComInput>
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInput
                        labelName="모델코드"
                        v-model="forms.prodCd"
                        :objAuth="this.objAuth"
                        @enterKey="searchBtn"
                    >
                    </TCComInput>
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="forms.repProdCd"
                        :codeVal.sync="forms.repProdNm"
                        labelName="대표모델"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onProdsEnterKey"
                        @appendIconClick="onProdsIconClick"
                        @input="onProdsInput"
                    />
                    <BasBcoProdsPopup
                        v-if="basBcoProdsShow"
                        :parentParam="searchProdForm"
                        :rows="resultProdsRows"
                        :dialogShow.sync="basBcoProdsShow"
                        @confirm="onProdsReturnData"
                    />
                </div>
                <!-- //item 1-4 -->

                <!-- //item 1-5 -->

                <!--
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00020"
                        labelName="상품특성1"
                        v-model="forms.prodChrticCd1"
                        :disabled="basProdMgmtDis.prodChrticCd1"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                -->
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <!--
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00470"
                        labelName="상품특성4"
                        v-model="forms.prodChrticCd4"
                        :disabled="basProdMgmtDis.prodChrticCd4"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                 <div class="formitem div4">
                 
                    <TCComCheckBox
                        labelName="정책적용대상"
                        :objAuth="this.objAuth"
                        :itemList="this.chkData"
                        v-model="ckParam.appPol"
                    ></TCComCheckBox>
               
                     </div>
                -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="forms.mfactCd"
                        :codeVal.sync="forms.mfactNm"
                        labelName="제조사"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOutDealEnterKey"
                        @appendIconClick="onOutDealIconClick"
                        @input="onOutDealInput"
                    />
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onOutDealReturnData"
                    />
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="EQP_TYP_CL_CD"
                        labelName="NETWORK세대"
                        :objAuth="objAuth"
                        v-model="forms.eqpTypClCd"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="단종여부"
                        v-model="forms.endYn"
                        :objAuth="this.objAuth"
                        :itemList="this.Yn"
                        itemText="codeNm"
                        itemValue="codeId"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <!-- //item 2-3 -->
                <!-- item 2-4 -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="주문여부"
                        v-model="forms.ordYn"
                        :objAuth="this.objAuth"
                        :itemList="this.allYn"
                        itemText="codeNm"
                        itemValue="codeId"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-4 -->
                <!--
                <div class="formitem div5_2">
                    <TCComComboBox
                        codeId="ZBAS_C_00030"
                        labelName="상품특성2"
                        v-model="forms.prodChrticCd2"
                        :disabled="basProdMgmtDis.prodChrticCd2"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                -->
                <!--
                <div class="formitem div5_2">
                    <TCComComboBox
                        labelName="사용여부"
                        v-model="forms.useYn"
                        :objAuth="this.objAuth"
                        :itemList="this.Yn"
                        itemText="codeNm"
                        itemValue="codeId"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                -->
                <!--
                    <TCComComboBox
                        labelName="단말기구분"
                        codeId="ZBAS_C_00500"
                        v-model="forms.eqpClCd"
                        :objAuth="this.objAuth"
                        :disabled="basProdMgmtDis.eqpClCd"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                    -->
            </div>
            <!-- //Search_line 2 -->
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{ ' btn_ty_exp_active ': toggleActive }"
                        @click="toggleActive = !toggleActive"
                    >
                    </v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="toggleActive">
                    <div class="searchform">
                        <div class="formitem div4">
                            <TCComComboBox
                                labelName="ESIM모델여부"
                                v-model="forms.esimEqpYn"
                                :objAuth="this.objAuth"
                                :itemList="this.allYn"
                                itemText="codeNm"
                                itemValue="codeId"
                            ></TCComComboBox>
                        </div>
                        <div class="formitem div4">
                            <TCComComboBox
                                labelName="듀얼심단말여부"
                                v-model="forms.dualSimEqpYn"
                                :objAuth="this.objAuth"
                                :itemList="this.allYn"
                                itemText="codeNm"
                                itemValue="codeId"
                            ></TCComComboBox>
                        </div>
                        <div class="formitem div4">
                            <TCComComboBox
                                labelName="판매분매입여부"
                                v-model="forms.saleInYn"
                                :objAuth="this.objAuth"
                                :itemList="this.allYn"
                                itemText="codeNm"
                                itemValue="codeId"
                            ></TCComComboBox>
                        </div>
                        <div class="formitem div4">
                            <TCComComboBox
                                labelName="과세구분"
                                v-model="forms.taxTypCd"
                                :objAuth="this.objAuth"
                                :itemList="this.taxTypData"
                                itemText="codeNm"
                                itemValue="codeId"
                            ></TCComComboBox>
                        </div>
                    </div>
                    <!--
                    <div class="searchform">
               
                        <div class="formitem div5_1">
             
                            <TCComInputSearchText
                                labelName="대표모델"
                                :appendIconClass="''"
                                @appendIconClick="repProdCdPopup"
                                @enterKey="repProdCdPopup"
                                placeholder="입력해주세요"
                                :objAuth="this.objAuth"
                                v-model="forms.repProdCd"
                                :disabledAfter="true"
                            >
                            </TCComInputSearchText>
                   
                        </div>
                     
                        <div class="formitem div5_1">
                        
                            <TCComComboBox
                                labelName="SIS상종여부"
                                v-model="forms.sisYn"
                                :objAuth="this.objAuth"
                                :itemList="this.allYn"
                                itemText="codeNm"
                                itemValue="codeId"
                            ></TCComComboBox>
                       
                        </div>
                    
  
                        <div class="formitem div5_2">
                            <TCComComboBox
                                codeId="ZBAS_C_00440"
                                labelName="통신방식"
                                v-model="forms.comMthdCd"
                                :objAuth="this.objAuth"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                            ></TCComComboBox>
                
                        </div>
                      
         
                        <div class="formitem div5_2">
                            <TCComComboBox
                                codeId="ZBAS_C_00460"
                                labelName="상품특성3"
                                v-model="forms.prodChrticCd3"
                                :disabled="basProdMgmtDis.prodChrticCd3"
                                :objAuth="this.objAuth"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                            ></TCComComboBox>
                        </div>
                
                   
                        <div class="formitem div5_2">
            
                            <TCComInput
                                labelName="원모델코드"
                                v-model="forms.prodSetCd"
                                :objAuth="this.objAuth"
                            >
                            </TCComInput>
                 
                        </div>

                    </div>
                    -->
                </div>
            </v-expand-transition>
        </div>
        <!-- //Search_div -->

        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="상품 내역"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @excelDownBtn="this.exportGridBtn"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getPproductListList"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            />
        </div>
        <!-- //gridWrap -->
        <!-- Dialog -->
        <basPdmProdBrwsMgmtPopup
            v-if="localDialogShow === true"
            ref="popup"
            :dialogShow.sync="localDialogShow"
            :parentParam="searchPopParam"
            @confirm="onbasPdmProdBrwsMgmtPopupReturnData"
        />
    </div>
</template>

<style>
/* @import '@/node_modules/realgrid/dist/realgrid-style.css'; */
</style>

<script>
import { CommonGrid } from '@/utils'
import CommonMixin from '@/mixins'
import BasPdmProdBrwsMgmtPopup from '@/views/biz/bas/pdm/BasPdmProdBrwsMgmtPopup'
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================
import basPdmProdBrwsMgmtApi from '@/api/biz/bas/pdm/basPdmProdBrwsMgmtApi'
import {
    BasPdmProdBrwsMgmtParam,
    BasProdMgmtDis,
} from '@/api/biz/bas/pdm/basPdmProdBrwsMgmtParam'
//import { msgTxt } from '@/const/msg.Properties.js'
import { GRID_HEADER } from '@/const/grid/bas/pdm/BasPdmProdBrwsMgmtHeader'
import attachedFileApi from '@/api/common/attachedFile'
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
import _ from 'lodash'
export default {
    name: 'BasPdmProdBrwsMgmt',
    mixins: [CommonMixin],
    components: {
        BasPdmProdBrwsMgmtPopup,
        BasBcoProdsPopup,
        BasBcoOutDealsPopup,
    },

    data() {
        return {
            //Grid Class init
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            forms: {
                prodCd: '', // 상품코드
                mfactCd: '', // 제조사코드
                mfactId: '', // 제조사ID
                mfactNm: '', //제조사이름
                prodSetCd: '', // 모델원코드
                repProdCd: '', // 대표상품코드
                eqpClCd: '', // 단말기구분코드
                prodNm: '', // 상품명
                prodClCd: '', // 상품구분코드
                saleInYn: '', // 판매분매입여부
                comMthdCd: '', // 통신방식코드
                prodChrticCd1: '', // 상품특성코드1
                prodChrticCd2: '', // 상품특성코드2
                prodChrticCd3: '', // 상품특성코드3
                prodChrticCd4: '', // 상품특성코드4
                ordYn: '', // 주문여부
                taxTypCd: '', // 과세상품구분코드
                useYn: '', // 사용여부
                endYn: '', // 단종여부
                sisYn: '', // SIS상품여부
                esimEqpYn: '', // ESIM모델여부
                dualSimEqpYn: '', // DualSim단말여부
                appPol: '', // 정책적용대상
                eqpTypClCd: '', //NETWORK세대
            },
            basProdMgmtDis: new BasProdMgmtDis(),
            rowCnt: 15,
            activePage: 1, // 현재페이지
            localDialogShow: false,
            //basBcoProdsShow: false,
            view: GRID_HEADER,
            showSearchBool: false,
            alertBodyText: '',

            toggleActive: false,
            objAuth: {
                screenNo: this.$route.meta.breadcrumb,
            },
            taxTypData: [
                {
                    codeId: '',
                    codeNm: '전체',
                },
                {
                    codeId: '1',
                    codeNm: '과세',
                },
                {
                    codeId: '2',
                    codeNm: '비과세',
                },
                {
                    codeId: '3',
                    codeNm: '면세',
                },
            ],
            MdlClData: [
                {
                    codeId: '',
                    codeNm: '전체',
                },
                {
                    codeId: 'N',
                    codeNm: '일반형',
                },
                {
                    codeId: 'Y',
                    codeNm: '개방형',
                },
            ],
            Yn: [
                {
                    codeId: 'Y',
                    codeNm: 'Y',
                },
                {
                    codeId: 'N',
                    codeNm: 'N',
                },
            ],
            allYn: [
                {
                    codeId: '',
                    codeNm: '전체',
                },
                {
                    codeId: 'Y',
                    codeNm: 'Y',
                },
                {
                    codeId: 'N',
                    codeNm: 'N',
                },
            ],
            chkData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '',
                },
            ],

            searchForms: {},
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '2X', // 거래처그룹
                dealcoClCd1: '20', // 거래처구분
            },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            searchProdForm: {
                prodClCd: '1', //상품구분
                sktOperYn: 'Y', //skt운영여부
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
            },
            resultProdsRows: [],
            //====================//상품팝업관련==================

            searchPopParam: {
                prod_cd: '',
                cudFlag: '',
                rgst_cl: '',
                omd_cl: '',
                omd_rgst_cl: '',
            },
            //체크박스
            ckParam: {
                appPol: [],
            },
        }
    },
    mounted() {
        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        //Default false
        this.gridObj.setGridState(true)
        //그리드안보이기

        this.gridObj.gridView.columnByName('prodClCd').visible = false // 상품상세구분명
        this.gridObj.gridView.columnByName('eqpClCd').visible = false // 단말기구분명
        this.gridObj.gridView.columnByName('prodChrticCd1').visible = false // 상품특성1명
        this.gridObj.gridView.columnByName('prodChrticCd2').visible = false // 상품특성2명
        this.gridObj.gridView.columnByName('prodChrticCd3').visible = false // 상품특성3명
        this.gridObj.gridView.columnByName('prodChrticCd4').visible = false // 상품특성4명

        this.gridObj.gridView.columnByName('prodChrticNm1').visible = false // 상품특성1명
        this.gridObj.gridView.columnByName('prodChrticNm2').visible = false // 상품특성2명
        this.gridObj.gridView.columnByName('prodChrticNm3').visible = false // 상품특성3명
        this.gridObj.gridView.columnByName('prodChrticNm4').visible = false // 상품특성4명
        this.gridObj.gridView.columnByName('comMthdCd').visible = false // 통신방식명
        this.gridObj.gridView.columnByName('taxTypCd').visible = false // 과세구분명
        this.gridObj.gridView.columnByName('rgstClCd').visible = false //등록구분
        this.gridObj.gridView.columnByName('sktOperYn').visible = false //SKT운영여부
        this.gridObj.gridView.columnByName('endYn').visible = false // 단종여부
        this.gridObj.gridView.columnByName('useYn').visible = false // 사용여부
        this.gridObj.gridView.columnByName('comMthdNm').visible = false // 통신방식
        this.gridObj.gridView.columnByName('sisYn').visible = false // sis상품여부

        console.log('objAuth', this.objAuth)
        //원클릭(확장모델등록)
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            //원클릭은 값만셋팅->확장모델버튼클릭때 적용
            if (undefined == clickData.dataRow) {
                return
            }

            console.log('원클릭')
            console.log(clickData)
            console.log(clickData.fieldName)
            console.log(clickData.dataRow)
            console.log(clickData.fieldIndex)

            let prodCd = grid.getValue(clickData.dataRow, 'prodCd')

            this.searchPopParam.prod_cd = prodCd
            /*
            버튼클릭때적용
            this.searchPopParam.cudFlag = 'U'
            this.searchPopParam.rgst_cl = '2'
            this.searchPopParam.omd_cl = 'Y'
            */
        }

        //더블클릭
        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            if (undefined == clickData.dataRow) {
                return
            }
            console.log('더블클릭')
            console.log(clickData)
            console.log(clickData.fieldName)
            console.log(clickData.dataRow)
            console.log(clickData.fieldIndex)

            //rgstClCd eqpClCd
            let prodCd = grid.getValue(clickData.dataRow, 'prodCd')
            let rgstClCd = grid.getValue(clickData.dataRow, 'rgstClCd')
            let eqpClCd = grid.getValue(clickData.dataRow, 'eqpClCd')

            this.searchPopParam.prod_cd = prodCd
            this.searchPopParam.cudFlag = 'U'
            this.searchPopParam.rgst_cl = rgstClCd

            if ('03' == eqpClCd || '04' == eqpClCd) {
                this.searchPopParam.omd_cl = 'Y'
                this.searchPopParam.omd_rgst_cl = 'N'
            } else {
                this.searchPopParam.omd_cl = ''
                this.searchPopParam.omd_rgst_cl = ''
            }

            this.localDialogShow = true
        }

        //this.forms.prodClCd = '1'
    },
    computed: {},
    methods: {
        init: function () {
            this.gridData = this.gridSetData()
        },

        //초기화 버튼 이벤트
        clearBtn: function () {
            //시작시초기화(초기화버튼때도)

            //그리드초기화
            this.gridData = this.gridSetData()
            this.gridObj.dataProvider.clearRows()

            //CommonUtil.clearPage(this, 'forms')
            //매핑값초기화
            this.forms = new BasPdmProdBrwsMgmtParam()
            //disable 초기화
            this.basProdMgmtDis = new BasProdMgmtDis()
            //정책적용대상초기화
            this.ckParam.appPol = ''
        },

        gridSetData: function (rowCnt) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, rowCnt, '', '')
        },

        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        //Grid Paging Move(Append)
        /*
        gridAddPageBtn: function () {
            if (
                !this.searchForms.pageNum ||
                this.gridData.totalPage <= this.searchForms.pageNum
            ) {
                this.showSearchBool = true
                this.alertBodyText = msgTxt.MSG_01041
            } else {
                //Page Move
                this.searchForms.pageNum += 1

                // //정책적용대상체크박스String변경
                // this.forms.appPol = String(this.ckParam.appPol)
                // this.searchForms = this.forms

                basPdmProdBrwsMgmtApi
                    .getPproductListList(this.searchForms)
                    .then((res) => {
                        console.log(res)
                        this.gridData.gridRows = this.gridHeaderObj.setAddPage(
                            this.gridData.gridRows,
                            res
                        )
                        //Grid Row 가져올때 페이지정보 Setting
                        this.gridHeaderObj.setPageCount(res.pagingDto)
                    })
            }
        },
        */
        //Grid ExcelDown
        exportGridBtn: function () {
            //this.gridHeaderObj.exportGrid('basPdmProdBrwsMgmt.xls')

            /*
            basPdmProdBrwsMgmtApi.getProductExcelList(this.forms).then((resultData) => {
                this.searchForms = this.forms //검색조건 저장

                console.log('resultData ', resultData)

            })
            */
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            this.forms.appPol = String(this.ckParam.appPol)
            attachedFileApi.downLoadFile(
                '/api/v1/backend-max/resource/bas/pdm/prods-download-excel',
                this.forms
            )
            /*
                .then((res) => {
                    console.info({ res })
                    if (!res) this.showTcComAlert('다운로드에 실패하였습니다')
                })
                .finally(() => {
                    this.$emit('excelDownload', this.exportInfo)
                    this.$store.dispatch('setApiLoading', false)
                })
                */
        },
        //조회 버튼 이벤트
        searchBtn: function () {
            this.forms.pageSize = this.rowCnt
            this.forms.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getPproductListList(this.forms.pageNum)
        },

        // API 호출
        getPproductListList(page) {
            this.forms.pageNum = page //첫번째 페이지
            //정책적용대상체크박스String변경
            this.forms.appPol = String(this.ckParam.appPol)

            basPdmProdBrwsMgmtApi
                .getPproductListList(this.forms)
                .then((resultData) => {
                    this.searchForms = this.forms //검색조건 저장
                    console.log('resultData ', resultData)
                    this.gridObj.setRows(resultData.gridList)
                    this.gridObj.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    console.log('조회완료')
                })
        },

        //팝업열기
        dialogClicked: function () {
            this.localDialogShow = true
            this.searchPopParam.cudFlag = 'C'
            this.searchPopParam.rgst_cl = '2'
        },
        //확장모델등록버튼
        dialogExpClicked: function () {
            if ('' == this.searchPopParam.prod_cd) {
                this.showTcComAlert('모델을 선택하세요.', {
                    header: '모델선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            this.searchPopParam.cudFlag = 'U'
            this.searchPopParam.rgst_cl = '2'
            this.searchPopParam.omd_cl = 'Y'
            this.searchPopParam.omd_rgst_cl = 'Y'

            this.localDialogShow = true
        },

        //대표모델 팝업
        repProdCdPopup: function () {
            this.basBcoProdsShow = true
        },
        //상품구분변경시
        prodClCdChange: function () {
            let prodClCd = this.forms.prodClCd

            //바코드정보
            if ('1' == prodClCd || '' == prodClCd) {
                this.basProdMgmtDis.prodChrticCd1 = false
                this.basProdMgmtDis.prodChrticCd2 = false
                this.basProdMgmtDis.prodChrticCd3 = false
                this.basProdMgmtDis.prodChrticCd4 = false
                this.basProdMgmtDis.eqpClCd = false
            } else {
                //disable + 초기화
                this.basProdMgmtDis.prodChrticCd1 = true
                this.basProdMgmtDis.prodChrticCd2 = true
                this.basProdMgmtDis.prodChrticCd3 = true
                this.basProdMgmtDis.prodChrticCd4 = true
                this.basProdMgmtDis.eqpClCd = true
                //초기화
                this.forms.prodChrticCd1 = ''
                this.forms.prodChrticCd2 = ''
                this.forms.prodChrticCd3 = ''
                this.forms.prodChrticCd4 = ''
                this.forms.eqpClCd = ''
            }
        },
        /*
        btnClick() {},
        */
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                console.log('getProdsList : ', res)
                if (res === undefined) return
                if (res.length === 1) {
                    this.forms.repProdCd = _.get(res[0], 'prodCd')
                    this.forms.repProdNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.forms.repProdCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.forms.repProdCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.forms.prodNm = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.forms.repProdCd = _.get(retrunData, 'prodCd')
            this.forms.repProdNm = _.get(retrunData, 'prodNm')
        },
        //상품등록 수정 후 다시조회.
        onbasPdmProdBrwsMgmtPopupReturnData(retrunData) {
            console.log(retrunData)
            this.searchBtn()
        },
        //===================== //상품팝업관련 methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    console.log('getOutDealList then : ', res)
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.forms.mfactCd = _.get(res[0], 'dealcoCd')
                        this.forms.mfactNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            if (!_.isEmpty(this.forms.mfactCd)) {
                this.getOutDealList()
            } else {
                this.showBcoOutDeals = true
            }
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.forms.mfactCd)) {
                this.showTcComAlert('외부거래처명을 입력해주세요.')
                return
            }
            // 외부거래처 정보 조회
            this.getOutDealList()
        },
        // 외부거래처 TextField Input 이벤트 처리
        onOutDealInput() {
            // 입력되는 값이 있으면 외부거래처 코드 초기화
            this.forms.mfactNm = ''
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.forms.mfactCd = _.get(retrunData, 'dealcoCd')
            this.forms.mfactNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
    },
}
</script>
