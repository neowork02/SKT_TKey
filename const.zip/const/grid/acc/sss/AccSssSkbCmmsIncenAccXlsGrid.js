import { ValueType } from 'realgrid'

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'accYm',
            dataType: ValueType.DATE,
            datetimeFormat: 'yyyyMM',
        },
        {
            fieldName: 'wireAccClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'skbAgencyCd',
        //     dataType: ValueType.TEXT,
        //     visible: false,
        // },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'accYm',
            fieldName: 'accYm',
            type: 'data',
            header: { text: '정산월', excelName: '정산월' },
            width: '200',
            datetimeFormat: 'yyyy-MM',
        },
        {
            name: 'wireAccClCd',
            fieldName: 'wireAccClCd',
            type: 'data',
            header: {
                text: '유형',
                excelName: '유형',
            },
            width: '200',
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            header: { text: '상품', excelName: '상품' },
            width: '200',
        },
        // {
        //     name: 'skbAgencyCd',
        //     fieldName: 'skbAgencyCd',
        //     type: 'data',
        //     header: { text: 'skb대리점코드', excelName: 'skb대리점코드' },
        //     width: '200',
        //     visible: false,
        // },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점코드', excelName: '대리점코드' },
            width: '200',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: { text: '대리점명', excelName: '대리점명' },
            width: '200',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            header: { text: '수수료항목', excelName: '수수료항목' },
            width: '220',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            header: { text: '공급가', excelName: '공급가' },
            width: '200',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
    ],
}

export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'wireAccClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'errMsg',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'wireAccClCd',
            fieldName: 'wireAccClCd',
            type: 'data',
            header: {
                text: '유형',
                excelName: '유형',
            },
            width: '200',
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            header: { text: '상품', excelName: '상품' },
            width: '200',
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점코드', excelName: '대리점코드' },
            width: '200',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: { text: '대리점명', excelName: '대리점명' },
            width: '200',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            header: { text: '수수료항목', excelName: '수수료항목' },
            width: '220',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            header: { text: '공급가', excelName: '금액' },
            width: '200',
            groupFooter: {
                expression: 'sum',
                styleName: 'right-column',
            },
            footer: {
                expression: 'sum',
            },
        },
        {
            name: 'errMsg',
            fieldName: 'errMsg',
            type: 'data',
            header: { text: '오류내역', excelName: '오류내역' },
            width: '200',
        },
    ],
}

export const GRID_HEADER3 = {
    fields: [
        {
            fieldName: 'accYm',
            dataType: ValueType.DATE,
            datetimeFormat: 'yyyyMM',
        },
        {
            fieldName: 'wireAccClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'skbAgencyCd',
        //     dataType: ValueType.TEXT,
        //     visible: false,
        // },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'accYm',
            fieldName: 'accYm',
            type: 'data',
            header: { text: '정산월', excelName: '정산월' },
            width: '200',
            datetimeFormat: 'yyyy-MM',
        },
        {
            name: 'wireAccClCd',
            fieldName: 'wireAccClCd',
            type: 'data',
            header: {
                text: '유형',
                excelName: '유형',
            },
            width: '200',
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            header: { text: '상품', excelName: '상품' },
            width: '200',
        },
        // {
        //     name: 'skbAgencyCd',
        //     fieldName: 'skbAgencyCd',
        //     type: 'data',
        //     header: { text: 'skb대리점코드', excelName: 'skb대리점코드' },
        //     width: '200',
        //     visible: false,
        // },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점코드', excelName: '대리점코드' },
            width: '200',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: { text: '대리점명', excelName: '대리점명' },
            width: '200',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            header: { text: '수수료항목', excelName: '수수료항목' },
            width: '220',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            header: { text: '공급가', excelName: '공급가' },
            width: '200',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
    ],
}
