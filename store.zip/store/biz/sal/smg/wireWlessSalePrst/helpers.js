import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('sal.smg.wireWlessSalePrstStore', Object.keys(state)),
    ...mapGetters('sal.smg.wireWlessSalePrstStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('sal.smg.wireWlessSalePrstStore', Object.keys(actions)),
    ...mapMutations('sal.smg.wireWlessSalePrstStore', Object.keys(mutations)),
}
