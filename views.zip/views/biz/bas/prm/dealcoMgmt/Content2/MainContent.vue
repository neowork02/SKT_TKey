<template>
    <div>
        <search-container ref="searchContainer" />
        <table-container @Refresh="Refresh" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/tDealcoMgmt/helpers'

import SearchContainer from './SearchContainer.vue'
import TableContainer from './TableContainer.vue'

export default {
    components: {
        SearchContainer,
        TableContainer,
    },
    data() {
        return {
            objAuth: {},
        }
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        Refresh() {
            this.$refs.searchContainer.searchData()
        },
    },
}
</script>

<style scoped></style>
