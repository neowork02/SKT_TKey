import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        // {
        //     fieldName: 'pagingSeq',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgAgencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'jobCaseCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sendYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        // {
        //     name: 'pagingSeq',
        //     fieldName: 'pagingSeq',
        //     header: {
        //         text: 'No.',
        //     },
        // },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            header: {
                text: '대리점코드',
            },
            editable: false,
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            header: {
                text: '대리점명',
            },
            editable: false,
            width: 200,
        },
        {
            name: 'orgAgencyCd',
            fieldName: 'orgAgencyCd',
            header: {
                text: '조직/대리점코드',
            },
            visible: false,
        },
        {
            name: 'jobCaseCd',
            fieldName: 'jobCaseCd',
            header: {
                text: '작업유형코드',
            },
            visible: false,
        },
        {
            name: 'sendYn',
            fieldName: 'sendYn',
            header: {
                text: '발신여부',
            },
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'addInfo1',
            fieldName: 'addInfo1',
            header: {
                text: '판매',
            },
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'addInfo2',
            fieldName: 'addInfo2',
            header: {
                text: '할부추가',
            },
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'addInfo3',
            fieldName: 'addInfo3',
            header: {
                text: '할부취소',
            },
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            header: {
                text: '입력사용자ID',
            },
            visible: false,
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            header: {
                text: '수정사용자ID',
            },
            visible: false,
        },
    ],
}
