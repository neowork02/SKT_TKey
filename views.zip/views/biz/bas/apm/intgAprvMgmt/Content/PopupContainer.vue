<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="500px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">통합승인관리상세</p>
                <!--// Popup_tit -->
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="resultDtlList[0].menuGrpNm"
                                    labelName="업무구분"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="resultDtlList[0].aprvTypNm"
                                    labelName="승인유형명"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="resultDtlList[0].reqMenuNm"
                                    labelName="요청화면"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo01"
                                    v-model="resultDtlList[0].aprvDtlInfo01"
                                    :labelName="labelName01"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo02"
                                    v-model="resultDtlList[0].aprvDtlInfo02"
                                    :labelName="labelName02"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo03"
                                    v-model="resultDtlList[0].aprvDtlInfo03"
                                    :labelName="labelName03"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo04"
                                    v-model="resultDtlList[0].aprvDtlInfo04"
                                    :labelName="labelName04"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo05"
                                    v-model="resultDtlList[0].aprvDtlInfo05"
                                    :labelName="labelName05"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo06"
                                    v-model="resultDtlList[0].aprvDtlInfo06"
                                    :labelName="labelName06"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo07"
                                    v-model="resultDtlList[0].aprvDtlInfo07"
                                    :labelName="labelName07"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo08"
                                    v-model="resultDtlList[0].aprvDtlInfo08"
                                    :labelName="labelName08"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo09"
                                    v-model="resultDtlList[0].aprvDtlInfo09"
                                    :labelName="labelName09"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo10"
                                    v-model="resultDtlList[0].aprvDtlInfo10"
                                    :labelName="labelName10"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo11"
                                    v-model="resultDtlList[0].aprvDtlInfo11"
                                    :labelName="labelName11"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo12"
                                    v-model="resultDtlList[0].aprvDtlInfo12"
                                    :labelName="labelName12"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo13"
                                    v-model="resultDtlList[0].aprvDtlInfo13"
                                    :labelName="labelName13"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo14"
                                    v-model="resultDtlList[0].aprvDtlInfo14"
                                    :labelName="labelName14"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo15"
                                    v-model="resultDtlList[0].aprvDtlInfo15"
                                    :labelName="labelName15"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo16"
                                    v-model="resultDtlList[0].aprvDtlInfo16"
                                    :labelName="labelName16"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo17"
                                    v-model="resultDtlList[0].aprvDtlInfo17"
                                    :labelName="labelName17"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo18"
                                    v-model="resultDtlList[0].aprvDtlInfo18"
                                    :labelName="labelName18"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo19"
                                    v-model="resultDtlList[0].aprvDtlInfo19"
                                    :labelName="labelName19"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo20"
                                    v-model="resultDtlList[0].aprvDtlInfo20"
                                    :labelName="labelName20"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo21"
                                    v-model="resultDtlList[0].aprvDtlInfo21"
                                    :labelName="labelName21"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo22"
                                    v-model="resultDtlList[0].aprvDtlInfo22"
                                    :labelName="labelName22"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo23"
                                    v-model="resultDtlList[0].aprvDtlInfo23"
                                    :labelName="labelName23"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo24"
                                    v-model="resultDtlList[0].aprvDtlInfo24"
                                    :labelName="labelName24"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo25"
                                    v-model="resultDtlList[0].aprvDtlInfo25"
                                    :labelName="labelName25"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo26"
                                    v-model="resultDtlList[0].aprvDtlInfo26"
                                    :labelName="labelName26"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo27"
                                    v-model="resultDtlList[0].aprvDtlInfo27"
                                    :labelName="labelName27"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo28"
                                    v-model="resultDtlList[0].aprvDtlInfo28"
                                    :labelName="labelName28"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo29"
                                    v-model="resultDtlList[0].aprvDtlInfo29"
                                    :labelName="labelName29"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-if="showDtlInfo30"
                                    v-model="resultDtlList[0].aprvDtlInfo30"
                                    :labelName="labelName30"
                                    :objAuth="objAuth"
                                    :maxlength="200"
                                ></TCComInput>
                            </div>
                        </div>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/apm/intgAprvMgmt/helpers'
// import { M_HEADER2 } from '@/const/grid/bas/apm/basApmIntgAprvMgmtHeader'
import { CommonGrid } from '@/utils'
import { msgTxt } from '@/const/msg.Properties'
import _ from 'lodash'
export default {
    name: 'PopupContainer',
    mixins: [CommonMixin],
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: (data) => {
                return data
            },
            required: false,
        },
    },
    data() {
        return {
            // activePage: 1, // 현재페이지
            // rowCnt: 30,
            objAuth: {},
            // gridPopupObj: {},
            // gridPopupHeaderObj: {},
            // gridPopupData: this.GridSetData(),
            // view: M_HEADER2,
            // addTitles: [
            //     'aprvDtlInfo01', // 추가정보01
            //     'aprvDtlInfo02', // 추가정보02
            //     'aprvDtlInfo03', // 추가정보03
            //     'aprvDtlInfo04', // 추가정보04
            //     'aprvDtlInfo05', // 추가정보05
            //     'aprvDtlInfo06', // 추가정보06
            //     'aprvDtlInfo07', // 추가정보07
            //     'aprvDtlInfo08', // 추가정보08
            //     'aprvDtlInfo09', // 추가정보09
            //     'aprvDtlInfo10', // 추가정보10
            // ],
            // layout: [
            //     'menuGrpNm', // 업무구분
            //     'aprvTypNm', // 승인유형명
            //     'reqMenuNm', // 요청화면
            //     'aprvDtlInfo01', // 추가정보01
            //     'aprvDtlInfo02', // 추가정보02
            //     'aprvDtlInfo03', // 추가정보03
            //     'aprvDtlInfo04', // 추가정보04
            //     'aprvDtlInfo05', // 추가정보05
            //     'aprvDtlInfo06', // 추가정보06
            //     'aprvDtlInfo07', // 추가정보07
            //     'aprvDtlInfo08', // 추가정보08
            //     'aprvDtlInfo09', // 추가정보09
            //     'aprvDtlInfo10', // 추가정보10
            // ],
            labelName01: '',
            labelName02: '',
            labelName03: '',
            labelName04: '',
            labelName05: '',
            labelName06: '',
            labelName07: '',
            labelName08: '',
            labelName09: '',
            labelName10: '',

            labelName11: '',
            labelName12: '',
            labelName13: '',
            labelName14: '',
            labelName15: '',
            labelName16: '',
            labelName17: '',
            labelName18: '',
            labelName19: '',
            labelName20: '',

            labelName21: '',
            labelName22: '',
            labelName23: '',
            labelName24: '',
            labelName25: '',
            labelName26: '',
            labelName27: '',
            labelName28: '',
            labelName29: '',
            labelName30: '',

            showDtlInfo01: false,
            showDtlInfo02: false,
            showDtlInfo03: false,
            showDtlInfo04: false,
            showDtlInfo05: false,
            showDtlInfo06: false,
            showDtlInfo07: false,
            showDtlInfo08: false,
            showDtlInfo09: false,
            showDtlInfo10: false,

            showDtlInfo11: false,
            showDtlInfo12: false,
            showDtlInfo13: false,
            showDtlInfo14: false,
            showDtlInfo15: false,
            showDtlInfo16: false,
            showDtlInfo17: false,
            showDtlInfo18: false,
            showDtlInfo19: false,
            showDtlInfo20: false,

            showDtlInfo21: false,
            showDtlInfo22: false,
            showDtlInfo23: false,
            showDtlInfo24: false,
            showDtlInfo25: false,
            showDtlInfo26: false,
            showDtlInfo27: false,
            showDtlInfo28: false,
            showDtlInfo29: false,
            showDtlInfo30: false,
        }
    },
    created() {
        this.initPagingAssign_()
        let paramObj = {}
        paramObj.aprvSeq = this.dtlData.aprvSeq
        paramObj.pageNum = this.pagingDtl.pageNum
        paramObj.pageSize = this.initPagingDtl.pageSize

        this.defaultAssign_({
            key: 'searchParamsDtl',
            value: paramObj,
        })
        this.searchDtlApi()

        // this.labelNameChg()
    },
    async mounted() {
        // this.gridPopupObj = this.$refs.gridPopup
        // this.gridPopupHeaderObj = this.$refs.gridPopupHeader
        // this.gridPopupObj.gridView.setColumnLayout(this.layout)
        // this.gridPopupObj.setGridState(false)
        // this.gridPopupObj.gridView.displayOptions.selectionStyle = 'rows'
        // this.gridPopupObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
    },
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        resultDtlList1: {
            get() {
                return this.resultDtlList
            },
        },
        dltContent1: {
            get() {
                return this.dltContent
            },
        },
        pagingDtl1: {
            get() {
                return this.pagingDtl
            },
        },
        searchParamDtl: {
            get() {
                return this.searchParamsDtl
            },
        },
    },
    methods: {
        ...serviceMethods,
        open(param) {
            console.log('open-----', param)
        },
        close() {
            this.activeOpen = false
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        initPagingAssign_() {
            this.defaultAssign_({
                key: 'pagingDtl',
                value: this.initPaging,
            })
        },
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'pagingDtl',
                value: { ...this.pagingDtl1, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            await this.defaultAssign_({
                key: 'pagingDtl',
                value: { ...this.pagingDtl1, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPagingDtl',
                value: { ...this.pagingDtl1, pageSize: pageSize },
            })
            if (this.pagingDtl1.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        SetPaging() {
            this.gridPopupData = this.GridSetData() //초기화
            this.gridPopupData.totalPage = this.pagingDtl1.totalPageCnt // 총페이지수
            this.gridPopupHeaderObj.setPageCount(this.pagingDtl1)
        },
        async searchDtlApi() {
            let data1

            await this.getBasAprmIntgAprvDtlMgmt_()
                .then((data) => {
                    data1 = data
                    this.labelNameChg()
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    if (_.isEmpty(data1)) {
                        this.showTcComAlert(msgTxt.MSG_00039.replace(/%s/g, ''))
                        // this.labelNameChg()
                    }
                })
        },

        labelNameChg() {
            // 라벨네임을 서버로부터 동적으로 변화시킴
            this.labelName01 = this.dltContent['aprvDtlInfo01']
            this.labelName02 = this.dltContent['aprvDtlInfo02']
            this.labelName03 = this.dltContent['aprvDtlInfo03']
            this.labelName04 = this.dltContent['aprvDtlInfo04']
            this.labelName05 = this.dltContent['aprvDtlInfo05']
            this.labelName06 = this.dltContent['aprvDtlInfo06']
            this.labelName07 = this.dltContent['aprvDtlInfo07']
            this.labelName08 = this.dltContent['aprvDtlInfo08']
            this.labelName09 = this.dltContent['aprvDtlInfo09']
            this.labelName10 = this.dltContent['aprvDtlInfo10']

            this.labelName11 = this.dltContent['aprvDtlInfo11']
            this.labelName12 = this.dltContent['aprvDtlInfo12']
            this.labelName13 = this.dltContent['aprvDtlInfo13']
            this.labelName14 = this.dltContent['aprvDtlInfo14']
            this.labelName15 = this.dltContent['aprvDtlInfo15']
            this.labelName16 = this.dltContent['aprvDtlInfo16']
            this.labelName17 = this.dltContent['aprvDtlInfo17']
            this.labelName18 = this.dltContent['aprvDtlInfo18']
            this.labelName19 = this.dltContent['aprvDtlInfo19']
            this.labelName20 = this.dltContent['aprvDtlInfo20']

            this.labelName21 = this.dltContent['aprvDtlInfo21']
            this.labelName22 = this.dltContent['aprvDtlInfo22']
            this.labelName23 = this.dltContent['aprvDtlInfo23']
            this.labelName24 = this.dltContent['aprvDtlInfo24']
            this.labelName25 = this.dltContent['aprvDtlInfo25']
            this.labelName26 = this.dltContent['aprvDtlInfo26']
            this.labelName27 = this.dltContent['aprvDtlInfo27']
            this.labelName28 = this.dltContent['aprvDtlInfo28']
            this.labelName29 = this.dltContent['aprvDtlInfo29']
            this.labelName30 = this.dltContent['aprvDtlInfo30']

            console.log('this.dltContent', this.dltContent)
            // 라벨네임이 존재하지않는 컬럼명과 로우는 삭제
            if (!_.isEmpty(this.labelName01)) {
                this.showDtlInfo01 = true
            }
            if (!_.isEmpty(this.labelName02)) {
                this.showDtlInfo02 = true
            }
            if (!_.isEmpty(this.labelName03)) {
                this.showDtlInfo03 = true
            }
            if (!_.isEmpty(this.labelName04)) {
                this.showDtlInfo04 = true
            }
            if (!_.isEmpty(this.labelName05)) {
                this.showDtlInfo05 = true
            }
            if (!_.isEmpty(this.labelName06)) {
                this.showDtlInfo06 = true
            }
            if (!_.isEmpty(this.labelName07)) {
                this.showDtlInfo07 = true
            }
            if (!_.isEmpty(this.labelName08)) {
                this.showDtlInfo08 = true
            }
            if (!_.isEmpty(this.labelName09)) {
                this.showDtlInfo09 = true
            }
            if (!_.isEmpty(this.labelName10)) {
                this.showDtlInfo10 = true
            }
            if (!_.isEmpty(this.labelName11)) {
                this.showDtlInfo11 = true
            }
            if (!_.isEmpty(this.labelName12)) {
                this.showDtlInfo12 = true
            }
            if (!_.isEmpty(this.labelName13)) {
                this.showDtlInfo13 = true
            }
            if (!_.isEmpty(this.labelName14)) {
                this.showDtlInfo14 = true
            }
            if (!_.isEmpty(this.labelName15)) {
                this.showDtlInfo15 = true
            }
            if (!_.isEmpty(this.labelName16)) {
                this.showDtlInfo16 = true
            }
            if (!_.isEmpty(this.labelName17)) {
                this.showDtlInfo17 = true
            }
            if (!_.isEmpty(this.labelName18)) {
                this.showDtlInfo18 = true
            }
            if (!_.isEmpty(this.labelName19)) {
                this.showDtlInfo19 = true
            }
            if (!_.isEmpty(this.labelName20)) {
                this.showDtlInfo20 = true
            }
            if (!_.isEmpty(this.labelName21)) {
                this.showDtlInfo21 = true
            }
            if (!_.isEmpty(this.labelName22)) {
                this.showDtlInfo22 = true
            }
            if (!_.isEmpty(this.labelName23)) {
                this.showDtlInfo23 = true
            }
            if (!_.isEmpty(this.labelName24)) {
                this.showDtlInfo24 = true
            }
            if (!_.isEmpty(this.labelName25)) {
                this.showDtlInfo25 = true
            }
            if (!_.isEmpty(this.labelName26)) {
                this.showDtlInfo26 = true
            }
            if (!_.isEmpty(this.labelName27)) {
                this.showDtlInfo27 = true
            }
            if (!_.isEmpty(this.labelName28)) {
                this.showDtlInfo28 = true
            }
            if (!_.isEmpty(this.labelName29)) {
                this.showDtlInfo29 = true
            }
            if (!_.isEmpty(this.labelName30)) {
                this.showDtlInfo30 = true
            }
        },
    },

    watch: {
        // resultDtlList1() {
        //     // this.gridPopupObj.setRows(this.resultDtlList)
        //     _.forEach(this.addTitles, (item) => {
        //         this.gridPopupObj.gridView.columnByName(item).header.text =
        //             this.dltContent[item]
        //     })
        // },
        // pagingDtl1() {
        //     this.SetPaging()
        // },
    },
}
</script>

<style scoped></style>
