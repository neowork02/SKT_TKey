<!-----------------------------------------------
 * 업무그룹명: Button 컴포넌트
 * 서브업무명: Button 공통함수
 * 설명: Button 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.04.14
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <span>
        <v-btn
            v-if="Vuetify"
            :color="color"
            :outlined="eOutlined"
            :large="eLarge"
            :class="eClass"
            :disabled="cDisabled"
            @click="emitClick"
        >
            <span v-if="eAttr" :class="eAttr"><slot /></span>
            <slot v-if="!eAttr" />
        </v-btn>

        <button
            v-if="!Vuetify"
            type="button"
            :color="color"
            :outlined="eOutlined"
            :large="eLarge"
            :disabled="cDisabled"
            :class="eClass"
            @click="emitClick"
        >
            <span :class="eAttr">{{ labelName }}</span>
        </button>
    </span>
</template>

<style lang="scss" scoped>
// scss source
</style>

<script>
import { CommonUtil } from '@/utils'
import CommonMixin from '@/mixins'
export default {
    inheritAttrs: false,
    name: 'TCComButton',
    mixins: [CommonMixin],
    components: {},
    props: {
        value: { type: String, default: '', required: false },
        eClass: { type: String, default: '', required: false },
        color: { type: String, default: '', required: false },
        disabled: { type: Boolean, default: false, required: false },
        //Publisher
        eOutlined: { type: Boolean, default: false, required: false },
        eLarge: { type: Boolean, default: false, required: false },
        eAttr: { type: String, default: '', required: false },
        // auth
        objAuth: { type: Object, default: () => {}, required: false },
        Vuetify: { type: Boolean, default: true, required: false },
        labelName: { type: String, default: '', required: false },
    },

    data() {
        return {
            dValue: '',
        }
    },
    computed: {
        cDisabled() {
            //버튼명을 가져오기
            let btnName = ''
            if (this.Vuetify == true) {
                btnName = this.$slots.default[0].text.trim()
            } else {
                btnName = this.labelName.trim()
            }

            //속성권한 여부 확인
            let disabledBl = CommonUtil.setObjAuth(this.$route.path, btnName)

            //속성권한이 있지만 비활성화 적용할때
            if (disabledBl === false && this.disabled == true) {
                disabledBl = true
            }
            //속성권한 함수호출
            return disabledBl
        },
    },
    // props 동적 제어
    watch: {},
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.dValue = this.value
        },
        emitClick(ev) {
            this.$emit('click', ev)
        },
    },
}
</script>
