<!-----------------------------------------------
 * 업무그룹명: Input + SearchBtn + Input 컴포넌트
 * 서브업무명: Input + SearchBtn + Input 컴포넌트
 * 설명: Input + SearchBtn + Input 컴포넌트및 공통함수 
 * 작성자: 최고운
 * 작성일: 2022.04.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div>
        <span v-if="this.labelName" class="itemtit" :class="labelClass">
            <span v-if="this.eRequired" class="emph_txt">* </span>
            {{ this.labelName }}
        </span>
        <span class="iteminput" :class="eClass">
            <div class="btnjoinType">
                <div class="col3">
                    <TcComTextField
                        ref="tcComInputSearchText"
                        v-model="dValue"
                        :size="size"
                        :maxlength="maxlength"
                        :placeholder="placeholder"
                        :disabled="disabled"
                        :readonly="readonly"
                        :eRequired="eRequired"
                        :objAuth="objAuth"
                        :style="cSize"
                        :commaFormat="commaFormat"
                        :rateFormat="rateFormat"
                        :formatType="formatType"
                        @input="emitInput"
                        @change="emitChange"
                        @focus="emitFocus"
                        @blur="emitBlur"
                        @enterKey="emitEnterKey"
                        @key-down="emitKeyDown"
                        class="search-btn"
                    >
                        <template v-slot:append>
                            <slot name="append">
                                <v-btn
                                    plain
                                    :class="cAppendIconClass"
                                    :disabled="cSearchIconDisabled"
                                    @click="emitAppendIcon"
                                >
                                </v-btn>
                            </slot>
                        </template>
                    </TcComTextField>
                </div>
                <div class="col4">
                    <TcComTextField
                        v-model="syncCodeVal"
                        :readonly="readonlyAfter"
                        :disabled="disabledAfter"
                        :objAuth="objAuth"
                        @input="emitCodeInput"
                        @change="emitCodeChange"
                        @focus="emitCodeFocus"
                        @blur="emitCodeBlur"
                        @enterKey="emitCodeEnterKey"
                        @key-down="emitCodeKeyDown"
                    ></TcComTextField>
                </div>
            </div>
        </span>
    </div>
</template>
<style lang="scss" scoped>
// scss source
</style>
<script>
import TcComTextField from './TCComTextField'
import _ from 'lodash'
export default {
    inheritAttrs: false,
    name: 'TCComInputSearchText',
    components: { TcComTextField },
    props: {
        // 입력값,양방향 바인딩
        value: { type: [String, Number], default: '', required: false },
        //두번째 TextField value
        codeVal: { type: [String, Number], default: '', required: false },
        // 넓이
        size: { type: Number, default: null, required: false },
        // 입력값 허용 길이
        maxlength: { type: Number, default: null, required: false },
        // placeholder 제어
        placeholder: { type: String, default: '', required: false },
        //텍스트박스 명
        labelName: { type: String, default: '', required: false },
        //필수입력여부
        eRequired: { type: Boolean, default: false, required: false },
        //readonly
        readonly: { type: Boolean, default: false, required: false },
        //disabled
        disabled: { type: Boolean, default: false, required: false },
        //searchIcon Disabled
        searchIconDisabled: { type: Boolean, default: true, required: false },
        //두번째 TextField readonly
        readonlyAfter: { type: Boolean, default: false, required: false },
        //disabledAfter
        //두번째 TextField Disabled
        disabledAfter: { type: Boolean, default: false, required: false },
        // auth
        objAuth: { type: Object, default: () => {}, required: false },
        // 오른쪽 아이콘 제어
        appendIconClass: {
            type: String,
            default: 'btn_ty_search',
            required: false,
        },
        //CSS Class
        eClass: { type: String, default: '', required: false },
        //CSS Label Class
        labelClass: { type: String, default: '', required: false },
        // 콤마 포맷
        commaFormat: { type: Boolean, default: false, required: false },
        // Rate 포맷
        rateFormat: { type: Boolean, default: false, required: false },
        // 포맷설정 TEL / BIZ...
        formatType: { type: String, default: '', required: false },
    },
    data() {
        return {
            dValue: '',
            dCodeVal: '',
        }
    },
    computed: {
        cSize() {
            let res = 'width:auto;'
            if (!_.isEmpty(this.size)) {
                res = 'width:' + this.size + '%;'
            }
            return res
        },
        cAppendIconClass() {
            let res = 'btn_ty_search'
            if (!_.isEmpty(this.appendIconClass)) {
                res = this.appendIconClass
            }
            return res
        },
        syncCodeVal: {
            get() {
                return this.codeVal
            },
            set(value) {
                this.$emit('update:codeVal', value)
            },
        },
        cSearchIconDisabled() {
            let disabled = false
            if (this.disabled == true) {
                disabled = true
                if (this.searchIconDisabled == false) disabled = false
            }
            return disabled
        },
    },
    // props 동적 제어
    watch: {
        value: function () {
            this.dValue = this.value
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.dValue = this.value
            this.dCodeVal = this.codeVal
        },
        inputFocus() {
            this.$refs.tcComInputSearchText.inputFocus()
        },
        emitInput(value) {
            if (this.dValue != this.value) this.$emit('input', value)
        },
        emitChange(value) {
            this.emitInput(value)
            this.$emit('change', value)
        },
        emitFocus(ev) {
            this.$emit('focus', ev)
        },
        emitBlur(ev) {
            this.$emit('blur', ev)
        },
        emitEnterKey(ev) {
            this.$emit('enterKey', ev)
        },
        emitKeyDown(ev) {
            this.$emit('key-down', ev)
        },
        //두번째 TextField Event
        emitCodeInput(value) {
            this.$emit('codeInput', value)
        },
        emitCodeChange(value) {
            this.emitCodeInput(value)
            this.$emit('codeChange', value)
        },
        emitCodeFocus(ev) {
            this.$emit('codeFocus', ev)
        },
        emitCodeBlur(ev) {
            this.$emit('codeBlur', ev)
        },
        emitCodeEnterKey(ev) {
            this.$emit('codeEnterKey', ev)
        },
        emitCodeKeyDown(ev) {
            this.$emit('codeKeyDown', ev)
        },
        emitAppendIcon() {
            this.$emit('appendIconClick')
        },
    },
}
</script>
