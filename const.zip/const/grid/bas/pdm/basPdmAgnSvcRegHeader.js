import { ValueType } from 'realgrid'

export const LIST_HEADER = {
    fields: [
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            editable: false,
            header: {
                text: '부가서비스코드',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            editable: false,
            header: {
                text: '부가서비스명',
            },
        },
    ],
}
