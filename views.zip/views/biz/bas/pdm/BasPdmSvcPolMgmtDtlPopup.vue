<!-----------------------------------------------
 * 업무 그룹명 : 상품관리>사용자부가정책관리>신규/상세조회
 * 서브 업무명 : 부가정책상세조회
 * 설 명 : 부가정책을 신규등록/상세조회한다.
 * 작 성 자 : P180182
 * 작 성 일 : 2022.10.05
 * Copyright ⓒ SK TELECOM. All Right Reserved
 ------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">
                    {{ title }}
                </p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="부가정책ID"
                                    v-model="reqParam.suplSvcCd"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="부가정책명"
                                    v-model="reqParam.suplSvcNm"
                                    :objAuth="objAuth"
                                    :disabled="isEdit"
                                />
                            </div>
                            <!-- //item 1-2 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div2">
                                <TCComDatePicker
                                    calType="D"
                                    labelName="시작일자"
                                    v-model="reqParam.aplyStaDt"
                                    :objAuth="objAuth"
                                >
                                </TCComDatePicker>
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div2">
                                <TCComDatePicker
                                    calType="D"
                                    labelName="종료일자"
                                    v-model="reqParam.aplyEndDt"
                                    :objAuth="objAuth"
                                >
                                </TCComDatePicker>
                            </div>
                            <!-- //item 2-2 -->
                        </div>
                        <!-- //Search_line 2 -->
                        <!-- Search_line 3 -->
                        <div class="searchform">
                            <!-- item 3-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="상세설명"
                                    v-model="reqParam.suplSvcRmks"
                                    :objAuth="objAuth"
                                    :disabled="isEdit"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 3-1 -->
                        </div>
                        <!-- //Search_line 3 -->
                        <!-- Search_line 4 -->
                        <div class="searchform">
                            <!-- item 4-1 -->
                            <div class="formitem div2">
                                <TCComComboBox
                                    labelName="사용여부"
                                    v-model="reqParam.useYn"
                                    :objAuth="objAuth"
                                    :itemList="useYnList"
                                    @change="onUseYnChange"
                                ></TCComComboBox>
                            </div>
                            <!-- //item 4-1 -->
                            <!-- item 4-2 -->
                            <div class="formitem div2">
                                <TCComInput
                                    labelName="작성자"
                                    v-model="reqParam.modUserNm"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 4-2 -->
                        </div>
                        <!-- //Search_line 4 -->
                    </div>
                    <!-- //Search_div -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="saveBtn"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import restApi from '@/api/biz/bas/pdm/basPdmSvcPolMgmt.js'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'BasPdmSvcPolMgmtDtlPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
    },
    data() {
        return {
            objAuth: {},
            title: '',
            isEdit: true,
            reqParam: {
                // 요청파라미터
                suplSvcCd: '', // 부가서비스코드
                suplSvcNm: '', // 부가서비스명
                suplSvcRmks: '', // 부가정책 설명
                useYn: '', // 사용여부
                aplyStaDt: '', // 적용시작일자
                aplyEndDt: '', // 적용종료일자
                suplSvcClCd: '', // 부가서비스구분코드
                wrcellClCd: '', // 유무선구분코드
                modUserNm: '', // 수정사용자명
            },
            useYnList: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.reqParam.suplSvcCd = value['suplSvcCd']
                this.reqParam.suplSvcNm = value['suplSvcNm']
                this.reqParam.suplSvcRmks = value['suplSvcRmks']
                this.reqParam.useYn = value['useYn']
                this.reqParam.aplyStaDt = value['aplyStaDt']
                this.reqParam.aplyEndDt = value['aplyEndDt']
                this.reqParam.suplSvcClCd = value['suplSvcClCd']
                this.reqParam.wrcellClCd = value['wrcellClCd']
                this.reqParam.modUserNm = value['modUserNm']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {},
    mounted() {
        if (_.isEmpty(this.reqParam.suplSvcCd)) {
            this.title = '신규'

            this.reqParam.aplyStaDt = moment(new Date()).format('YYYY-MM-DD')
            this.reqParam.aplyEndDt = '9999-12-31'
            this.reqParam.modUserNm = this.userInfo['userNm']

            this.isEdit = false
        } else {
            this.title = '상세 조회'

            if (
                this.reqParam.suplSvcClCd === '6' &&
                this.reqParam.wrcellClCd === '3'
            ) {
                this.isEdit = false
            } else {
                this.isEdit = true
            }
        }
    },
    methods: {
        // 사용여부 변경 이벤트
        onUseYnChange(value) {
            if (value === 'N')
                this.reqParam.aplyEndDt = moment(new Date()).format(
                    'YYYY-MM-DD'
                )
        },
        // 저장 버튼 이벤트
        saveBtn() {
            this.reqParam.aplyStaDt = this.reqParam.aplyStaDt.replace(/-/gi, '')
            this.reqParam.aplyEndDt = this.reqParam.aplyEndDt.replace(/-/gi, '')

            if (_.isEmpty(this.reqParam.suplSvcCd)) {
                // 서비스정책관리 생성
                restApi.saveSvcPolMgmt(this.reqParam).then((res) => {
                    if (res > 0) {
                        this.$emit('close')
                        this.closeBtn()
                    }
                })
            } else {
                // 서비스정책관리 변경
                restApi.updateSvcPolMgmt(this.reqParam).then((res) => {
                    if (res > 0) {
                        this.$emit('close')
                        this.closeBtn()
                    }
                })
            }
        },
        //팝업닫기
        closeBtn() {
            this.activeOpen = false
        },
    },
}
</script>
