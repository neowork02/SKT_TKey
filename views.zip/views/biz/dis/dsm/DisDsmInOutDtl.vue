<!-----------------------------------------------
 * 업무그룹명: 재고관리현황>입출고세부내역
 * 서브업무명: 입출고세부내역
 * 설명: 입출고세부내역
 * 작성자: P179237
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>입출고세부내역</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearPage"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="cfSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="조회기간"
                        :eRequired="true"
                        calType="DP"
                        v-model="setDate"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="dsCondition.orgNm"
                        :eRequired="true"
                        :codeVal.sync="dsCondition.orgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        @enterKey="onOrgTreeEnterKey"
                        @appendIconClick="onOrgTreeIconClick"
                        @input="onOrgTreeInput"
                    />
                    <BasBcoOrgTreesPopup
                        v-if="showBcoOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultOrgTreeRows"
                        :dialogShow.sync="showBcoOrgTrees"
                        @confirm="onOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        v-model="dsCondition.prodClCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <!-- <div class="formitem div5">
                    <TCComComboBox
                        codeId="PRCH_TYP_CD"
                        labelName="구매유형"
                        v-model="dsCondition.prchTypCd"
                        :filterFunc="prchTypCdFilter"
                        :objAuth="this.objAuth"
                        :size="70"
                    ></TCComComboBox>
                </div> -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00440"
                        labelName="통신방식"
                        v-model="dsCondition.comMthdCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
            <!-- Search_line 2 -->
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00190"
                        labelName="입출고구분"
                        v-model="dsCondition.inOutClCd"
                        :filterFunc="inOutClCdFilter"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        @change="onChangeinOutClCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00050"
                        labelName="입출고상세구분"
                        v-model="dsCondition.inOutDtlClCd"
                        :filterFunc="inOutDtlClCdFilter"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :disabled="dsInoutDtlDisabled"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="dsCondition.inOutDealcoNm"
                        :codeVal.sync="dsCondition.inOutDealcoCd"
                        labelName="입출고처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="dsCondition.serNum"
                        labelName="일련번호"
                        @enterKey="cfSearch"
                    >
                    </TCComInput>
                </div>
            </div>
            <!-- //Search_line 2 -->
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{
                            ' btn_ty_exp_active ': active,
                        }"
                        @click="active = !active"
                    >
                    </v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="active">
                    <div class="searchform">
                        <div class="formitem div4">
                            <TCComInputSearchText
                                v-model="dsCondition.prodCd"
                                :codeVal.sync="dsCondition.prodNm"
                                labelName="모델"
                                :disabledAfter="true"
                                :objAuth="objAuth"
                                @enterKey="onProdsEnterKey"
                                @appendIconClick="onProdsIconClick"
                                @input="onProdsInput"
                            />
                            <BasBcoProdsPopup
                                v-if="basBcoProdsShow"
                                :parentParam="dsCondition"
                                :rows="resultProdsRows"
                                :dialogShow.sync="basBcoProdsShow"
                                @confirm="onProdsReturnData"
                            />
                        </div>
                        <div class="formitem div4">
                            <TCComInput
                                v-model="dsCondition.prodNm"
                                labelName="모델명"
                                @enterKey="cfSearch"
                            >
                            </TCComInput>
                        </div>
                        <div class="formitem div4">
                            <!-- 매입처만 나오게해야함 -->
                            <TCComInputSearchText
                                v-model="dsCondition.prchsDealcoNm"
                                :codeVal.sync="dsCondition.prchsDealcoCd"
                                labelName="매입처"
                                placeholder="입력해주세요"
                                :disabledAfter="true"
                                :objAuth="objAuth"
                                @enterKey="onOutDealEnterKey"
                                @appendIconClick="onOutDealIconClick"
                                @input="onOutDealInput"
                            />
                            <BasBcoOutDealsPopup
                                v-if="showBcoOutDeals"
                                :parentParam="dsCondition"
                                :rows="resultOutDealRows"
                                :dialogShow.sync="showBcoOutDeals"
                                @confirm="onOutDealReturnData"
                            />
                        </div>
                        <div class="formitem div4">
                            <!-- 제조사만 나오게해야함 -->
                            <TCComInputSearchText
                                v-model="dsCondition.mfactNm"
                                :codeVal.sync="dsCondition.mfactCd"
                                labelName="제조사"
                                placeholder="입력해주세요"
                                :disabledAfter="true"
                                :objAuth="objAuth"
                                @enterKey="onOutDealEnterKey2"
                                @appendIconClick="onOutDealIconClick2"
                                @input="onOutDealInput2"
                            />
                            <BasBcoOutDealsPopup2
                                v-if="showBcoOutDeals2"
                                :parentParam="dsConditionMfact"
                                :rows="resultOutDealRows2"
                                :dialogShow.sync="showBcoOutDeals2"
                                @confirm="onOutDealReturnData2"
                            />
                        </div>
                    </div>
                </div>
            </v-expand-transition>
        </div>
        <!-- //Search_div -->

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="입출고세부내역"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="this.onClickDownload"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getPagingData"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil, CommonGrid, CommonMsg } from '@/utils'
import _ from 'lodash'
import { SacCommon } from '@/views/biz/sac/js'

import { G_HEADER } from '@/const/grid/dis/dsm/disDsmInOutDtlHead'

import api from '@/api/biz/dis/dsm/disDsmInOutDtl'

import attachedFileApi from '@/api/common/attachedFile'

//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'

import BasBcoOutDealsPopup2 from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi2 from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
//====================내부조직팝업(전체)팝업====================
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
import basBcoOrgTreesApi from '@/api/biz/bas/bco/basBcoOrgTrees'
//====================//내부조직팝업(전체)팝업====================
//====================내부거래처-권한조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================

export default {
    name: 'DisDsmInOutDtl',
    mixins: [CommonMixin],
    components: {
        BasBcoOutDealsPopup,
        BasBcoOutDealsPopup2,
        BasBcoOrgTreesPopup,
        BasBcoDealcosPop,
        BasBcoProdsPopup,
    },
    data() {
        return {
            indicatorOpt: { sort: 'ASC' },
            // toggleWrap
            active: false,
            //
            dsCondition: {
                // 외부거래처 - 매입처
                prchsDealcoCd: '', // 거래처코드
                prchsDealcoNm: '', // 거래처명
                dealcoGrpCd: '3X', // 거래처그룹 2X - 제조사 / 3X - 매입처
                dealcoClCd1: '30', // 거래처구분 20 - 제조사 /30 - 매입처
                // 내부조직 전체
                orgCd: '',
                orgNm: '',
                basMth: '',
                orgLvl: '',
                // 내부거래처 권한조직 - 입출고처 << 조직넘겨줘야함 ***
                inOutDealcoCd: '',
                inOutDealcoNm: '',
                onlyAccDeaCoCd: 'Y',
                basDay: SacCommon.getTodayMonth(), //기준년월 << 수정해야함
                //
                prodCd: '',
                prodNm: '',
                // deafault data
                prodClCd: '',
                comMthdCd: '',
                inOutDtlClCd: '',
                inOutClCd: '',
                prchTypCd: 'PT01', // 구매유형
                searchFromDt: '',
                searchToDt: '',
                mfactNm: '',
                mfactCd: '',
                serNum: '',
            },
            //제조사팝업
            dsConditionMfact: {
                // prchsDealcoCd: '', // 거래처코드
                // prchsDealcoNm: '', // 거래처명
                dealcoGrpCd: '2X', // 거래처그룹 2X - 제조사 / 3X - 매입처
                dealcoClCd1: '20', // 거래처구분 20 - 제조사 /30 - 매입처
            },

            // 입출고 상세구분 콤보박스
            dsInoutDtlDisabled: true,

            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},
            view: G_HEADER,
            dsResult: [],
            gridStyle: {
                height: '400px',
            },

            objAuth: {}, // ?????

            deleteRows: [], // 삭제대상 rows

            //popup
            popupParams: {},
            showPopup: false,
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            // searchOutDealParam: {
            //     dealcoCd: '', // 거래처코드
            //     dealcoNm: '', // 거래처명
            //     dealcoGrpCd: '2X', // 거래처그룹
            //     dealcoClCd1: '20', // 거래처구분
            // },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals2: false, // 외부거래처 팝업 오픈 여부
            resultOutDealRows2: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            //====================내부조직팝업(전체)팝업관련====================
            orgDisabled: false,
            showBcoOrgTrees: false, // 내부조직팝업(전체) 팝업 오픈 여부
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultOrgTreeRows: [], // 내부조직팝업(전체) 팝업 오픈 여부
            //====================//내부조직팝업(전체)팝업관련==================
            //====================내부거래처-권한조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================

            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            //====================//상품팝업관련==================
            // paging
            rowCnt: 15, // 표시할 행의 갯수
            //조회 파라미터
            reqParams: {},
            //
            inOutClCdSelectedCode: '',
        }
    },
    created() {
        this.gridData = this.GridSetData()
    },
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 초기값 세팅
        this.fInit()
    },
    computed: {
        setDate: {
            get() {
                return [
                    this.dsCondition.searchFromDt,
                    this.dsCondition.searchToDt,
                ]
            },
            set(val) {
                this.dsCondition.searchFromDt = val[0]
                this.dsCondition.searchToDt = val[1]
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val[1])
                return val
            },
        },
    },
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObj = this.$refs.grid
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            this.gridObj.setGridState(true)
            this.gridData = this.GridSetData()

            this.gridObj.gridView.setColumnLayout(this.view.layout)
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 폼 초기화
        fInit: function () {
            this.dsCondition.searchFromDt = SacCommon.getFirstday()
            this.dsCondition.searchToDt = SacCommon.getToday()

            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.dsCondition['orgCd'] = this.orgInfo['orgCd']
                this.dsCondition['orgNm'] = this.orgInfo['orgNm']
                this.dsCondition['orgLvl'] = this.orgInfo['orgLvl']
                // this.dsCondition['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.dsCondition['inOutDealcoCd'] = this.userInfo['dealcoCd']
                this.dsCondition['inOutDealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true

                // this.searchForm.orgCd = this.dsCondition.orgCd
                // this.searchForm.orgNm = this.dsCondition.orgNm
                // this.searchForm.orgLvl = this.dsCondition.orgLvl
            }

            // this.dsCondition.calOrdDtm = [
            //     SacCommon.getFirstday(),
            //     SacCommon.getToday(),
            // ]
        },
        cfSearch: function () {
            if (this.fCheckCondition()) {
                this.dsResult = []
                this.gridObj.setRows([])

                this.dsCondition.pageSize = this.rowCnt
                this.gridData.totalPage = 0 // 이전페이지정보 초기화
                this.getPagingData(1)
            }
        },
        getPagingData: function (pageNum) {
            this.dsCondition.pageNum = pageNum
            const formData = this.getDsCondition()

            // 페이징 조회
            api.getInOutDtls(formData).then((resultData) => {
                if (resultData) {
                    this.dsResult = resultData.gridList
                    this.gridObj.setRows(this.dsResult)
                    // 페이징 관련
                    this.gridObj.setGridIndicator(
                        resultData.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.GridSetData() //초기화
                    this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
            })
        },

        // 조회조건 가져오기
        getDsCondition: function () {
            // testdata
            // this.dsCondition.searchFromDt = '20211201'
            // this.dsCondition.searchToDt = '20211231'
            // this.dsCondition.orgLvl = '3'
            // this.dsCondition.orgCd = 'AC1314'
            // this.dsCondition.inOutDealcoCd = '67558'
            // this.dsCondition.prodClCd = '1'
            //testdata

            this.dsCondition.rgnCd = _.toString(this.dsCondition.rgnCdList)

            const reqData = SacCommon.objectRemovedArray(this.dsCondition)

            // 엑셀다운로드
            this.reqParams = reqData

            const formData = {
                dsCondition: {
                    ...reqData,
                },
            }
            return formData
        },
        fCheckCondition: function () {
            // this.dsCondition.searchFromDt = this.dsCondition.calOrdDtm[0]
            // this.dsCondition.searchToDt = this.dsCondition.calOrdDtm[1]

            if (_.isEmpty(this.dsCondition.searchFromDt)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '시작 조회일자')
                )
                return false
            }
            if (_.isEmpty(this.dsCondition.searchToDt)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '종료 조회일자')
                )
                return false
            }

            const fromDtNumber = SacCommon.removeHyphen(
                this.dsCondition.searchFromDt
            )
            const toDtNumber = SacCommon.removeHyphen(
                this.dsCondition.searchToDt
            )

            if (fromDtNumber > toDtNumber) {
                this.showTcComAlert(
                    CommonMsg.getMessage(
                        'MSG_00096',
                        '시작 조회일자;종료 조회일자'
                    )
                )
                return false
            }

            if (fromDtNumber.substr(0, 6) != toDtNumber.substr(0, 6)) {
                this.showTcComAlert(
                    '시작일자와 종료일자를 동일한 월로 지정하세요'
                )
                return false
            }

            if (_.isEmpty(this.dsCondition.orgCd)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return false
            }

            return true
        },
        onChangeinOutClCd: function (val) {
            this.inOutClCdSelectedCode = val
            if (!_.isEmpty(val)) this.dsInoutDtlDisabled = false
            else this.dsInoutDtlDisabled = true
            this.dsCondition.inOutDtlClCd = ''
        },
        inOutClCdFilter: function (item) {
            return item.filter(
                (item) =>
                    item['commCdVal'] === '100' ||
                    item['commCdVal'] === '200' ||
                    item['commCdVal'] === '400' ||
                    item['commCdVal'] === '500'
            )
        },
        inOutDtlClCdFilter: function (item) {
            if ('100' == this.inOutClCdSelectedCode) {
                return item.filter(
                    (item) =>
                        item['commCdVal'] === '' ||
                        (item['commCdVal'] >= '100' &&
                            item['commCdVal'] < '200')
                )
            } else if ('200' == this.inOutClCdSelectedCode) {
                return item.filter(
                    (item) =>
                        item['commCdVal'] === '' ||
                        (item['commCdVal'] >= '200' &&
                            item['commCdVal'] < '300')
                )
            } else if ('400' == this.inOutClCdSelectedCode) {
                return item.filter(
                    (item) =>
                        item['commCdVal'] === '' ||
                        item['commCdVal'] === '405' ||
                        (item['commCdVal'] >= '411' &&
                            item['commCdVal'] <= '414')
                )
            } else if ('500' == this.inOutClCdSelectedCode) {
                return item.filter(
                    (item) =>
                        item['commCdVal'] === '' ||
                        item['commCdVal'] === '505' ||
                        (item['commCdVal'] >= '511' &&
                            item['commCdVal'] <= '514')
                )
            } else {
                return item
            }
        },
        prchTypCdFilter: function (item) {
            return item.filter((item) => item['commCdVal'] !== 'PT03')
        },

        // 초기화
        clearPage() {
            CommonUtil.clearPage(this, 'dsCondition')
            this.fInit()
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //Grid ExcelDown
        onClickDownload: function () {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-max/resource/dis/dsm/inOutDtlsExcelDown',
                this.reqParams
            )
        },
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi.getOutDealList(this.dsCondition).then((res) => {
                console.log('getOutDealList then : ', res)
                // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                if (res.length === 1) {
                    this.dsCondition.prchsDealcoCd = _.get(res[0], 'dealcoCd')
                    this.dsCondition.prchsDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultOutDealRows = res
                    this.showBcoOutDeals = true
                }
            })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            if (!_.isEmpty(this.dsCondition.prchsDealcoNm)) {
                this.getOutDealList()
            } else {
                this.showBcoOutDeals = true
            }
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이면 알림창 오픈
            // if (_.isEmpty(this.dsCondition.prchsDealcoNm)) {
            //     this.showTcComAlert('외부거래처명을 입력해주세요.')
            //     return
            // }
            // 외부거래처 정보 조회
            this.getOutDealList()
        },
        // 외부거래처 TextField Input 이벤트 처리
        onOutDealInput() {
            // 입력되는 값이 있으면 외부거래처 코드 초기화
            this.dsCondition.prchsDealcoCd = ''
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            console.log('onOutDealReturnData retrunData: ', retrunData)
            this.dsCondition.prchsDealcoCd = _.get(retrunData, 'dealcoCd')
            this.dsCondition.prchsDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================

        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList2() {
            console.log('getOutDealList2===========')
            this.dsConditionMfact.dealcoCd = this.dsCondition.mfactCd
            this.dsConditionMfact.dealcoNm = this.dsCondition.mfactNm
            basBcoOutDealsApi2
                .getOutDealList(this.dsConditionMfact)
                .then((res) => {
                    console.log('getOutDealList then : ', res)
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.dsCondition.mfactCd = _.get(res[0], 'dealcoCd')
                        this.dsCondition.mfactNm = _.get(res[0], 'dealcoNm')
                        console.log(
                            'this.dsCondition.mfactCd===',
                            this.dsCondition.mfactCd
                        )
                    } else {
                        this.resultOutDealRows2 = res
                        this.showBcoOutDeals2 = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick2() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows2 = []
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            if (!_.isEmpty(this.dsCondition.mfactNm)) {
                this.getOutDealList2()
            } else {
                this.showBcoOutDeals2 = true
            }
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey2() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows2 = []
            // 검색조건 외부거래처명이 빈값이면 알림창 오픈
            // if (_.isEmpty(this.dsCondition.mfactNm)) {
            //     this.showTcComAlert('외부거래처명을 입력해주세요.')
            //     return
            // }
            // 외부거래처 정보 조회
            this.getOutDealList2()
        },
        // 외부거래처 TextField Input 이벤트 처리
        onOutDealInput2() {
            // 입력되는 값이 있으면 외부거래처 코드 초기화
            this.dsCondition.mfactCd = ''
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData2(retrunData) {
            console.log('onOutDealReturnData2 retrunData: ', retrunData)
            this.dsCondition.mfactCd = _.get(retrunData, 'dealcoCd')
            this.dsCondition.mfactNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        //===================== 내부조직팝업(전체)팝업관련 methods ================================
        // 내부조직팝업(전체) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(전체) 팝업 오픈
        getOrgTreeList() {
            this.searchParam.orgCd = this.dsCondition.orgCd
            this.searchParam.orgNm = this.dsCondition.orgNm
            this.searchParam.orgLvl = this.dsCondition.orgLvl
            basBcoOrgTreesApi.getOrgTreeList(this.searchParam).then((res) => {
                console.log('getOrgTreeList then : ', res)
                // 검색된 내부조직팝업(전체) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(전체) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(전체) 팝업 오픈
                if (res.length === 1) {
                    this.dsCondition.orgCd = _.get(res[0], 'orgCd')
                    this.dsCondition.orgNm = _.get(res[0], 'orgNm')
                    this.dsCondition.orgLvl = _.get(res[0], 'orgLvl')
                } else {
                    this.resultOrgTreeRows = res
                    this.showBcoOrgTrees = true
                }
            })
        },
        // 내부조직팝업(전체) TextField 돋보기 Icon 이벤트 처리
        onOrgTreeIconClick() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이 아니면 내부조직팝업(전체) 정보 조회
            // 그 이외는 내부조직팝업(전체) 팝업 오픈
            if (!_.isEmpty(this.dsCondition.orgNm)) {
                this.getOrgTreeList()
            } else {
                this.showBcoOrgTrees = true
            }
        },
        // 내부조직팝업(전체) TextField 엔터키 이벤트 처리
        onOrgTreeEnterKey() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이면 알림창 오픈
            // if (_.isEmpty(this.dsCondition.orgNm)) {
            //     this.showAlertBool = true
            //     this.headerText = '검색조건 필수'
            //     this.alertBodyText = '내부조직팝업(전체)명을 입력해주세요.'
            //     return
            // }
            // 내부조직팝업(전체) 정보 조회
            this.getOrgTreeList()
        },
        // 내부조직팝업(전체) TextField Input 이벤트 처리
        onOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(전체) 코드 초기화
            this.dsCondition.orgCd = ''
            this.dsCondition.orgLvl = ''
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.orgCd = _.get(retrunData, 'orgCd')
            this.dsCondition.orgNm = _.get(retrunData, 'orgNm')
            this.dsCondition.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(전체)팝업관련 methods ================================
        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            this.searchForm.dealcoCd = this.dsCondition.inOutDealcoCd
            this.searchForm.dealcoNm = this.dsCondition.inOutDealcoNm
            this.searchForm.orgCd = this.dsCondition.orgCd
            this.searchForm.orgNm = this.dsCondition.orgNm
            this.searchForm.orgLvl = this.dsCondition.orgLvl
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.dsCondition.inOutDealcoCd = _.get(res[0], 'dealcoCd')
                    this.dsCondition.inOutDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.dsCondition.inOutDealcoNm)) {
                // this.getDealcosList()
                this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsCondition.orgCd)) {
                this.showTcComAlert('조직을 선택하세요.')
                return
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.dsCondition.inOutDealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.inOutDealcoCd = _.get(retrunData, 'dealcoCd')
            this.dsCondition.inOutDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.dsCondition).then((res) => {
                console.log('getProdsList : ', res)
                if (res === undefined) return
                if (res.length === 1) {
                    this.dsCondition.prodCd = _.get(res[0], 'prodCd')
                    this.dsCondition.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.dsCondition.prodCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsCondition.prodCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.dsCondition.prodNm = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsCondition.prodCd = _.get(retrunData, 'prodCd')
            this.dsCondition.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
