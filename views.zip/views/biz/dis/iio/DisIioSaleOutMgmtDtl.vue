<!-----------------------------------------------
 * 업무그룹명: 매출출고
 * 서브업무명: 매출출고관리상세
 * 설명: 매출출고 등록한다.
 * 작성자: P179890
 * 작성일: 2022.05.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>매출출고관리상세</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="addProdPop"
                    :disabled="isNotNew"
                    >상품입력</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    :disabled="isNotNew"
                    @click="addDisProdPop"
                    >재고상품입력</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="aprvBtn"
                    v-if="false"
                    :objAuth="this.objAuth"
                    >승인</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="delBtn"
                    v-if="false"
                    :objAuth="this.objAuth"
                    >삭제</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :disabled="isNotNew"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :disabled="isNotNew"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="listBtn"
                    :objAuth="this.objAuth"
                >
                    목록
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00430"
                        labelName="주문유형"
                        :eRequired="true"
                        :objAuth="this.objAuth"
                        v-model="reqParam.asgnCl"
                        :addBlankItem="false"
                        :filterFunc="filterAsgnFunc"
                        :disabled="isNotNew"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="출고조직"
                        @enterKey="onAuthOrgTreeIconClick('OUT')"
                        @appendIconClick="onAuthOrgTreeIconClick('OUT')"
                        @input="onAuthOrgTreeInput('OUT')"
                        :objAuth="this.objAuth"
                        :eRequired="true"
                        v-model="reqParam.outOrgNm"
                        :codeVal="reqParam.outOrgId"
                        :disabledAfter="true"
                        :disabled="isNotNew || searchDisable"
                        @focus="outOrgFocus"
                    >
                    </TCComInputSearchText>
                    <!-- 내부조직팝업(권한) -->
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="authOrgParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="출고처"
                        @appendIconClick="onDealcoIconClick('OUT')"
                        @enterKey="onDealcoIconClick('OUT')"
                        @input="onDealcoInput('OUT')"
                        :objAuth="this.objAuth"
                        :eRequired="true"
                        v-model="reqParam.outPlcNm"
                        :codeVal="reqParam.outPlcId"
                        :disabledAfter="true"
                        :disabled="isNotNew || searchDisable"
                        @focus="outPlcFocus"
                    >
                    </TCComInputSearchText>
                    <!-- 내부거래처팝업(권한조직) -->
                    <BasBcoDealcosPopup
                        v-if="basBcoDealcoShow"
                        :parentParam="searchDealcoParam"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="basBcoDealcoShow"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 1-3 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="조직구분"
                        :itemList="orgClComboItems"
                        :objAuth="this.objAuth"
                        v-model="reqParam.inCl"
                        :addBlankItem="false"
                        @change="inClChange"
                        :disabled="isNotNew"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="입고조직"
                        @enterKey="onAuthOrgTreeIconClick('IN')"
                        @appendIconClick="onAuthOrgTreeIconClick('IN')"
                        @input="onAuthOrgTreeInput('IN')"
                        :objAuth="this.objAuth"
                        v-model="reqParam.inOrgNm"
                        :codeVal="reqParam.inOrgId"
                        :disabledAfter="true"
                        :eRequired="true"
                        v-show="showInOrg"
                        :disabled="isNotNew"
                        @focus="inOrgFocus"
                    >
                    </TCComInputSearchText>
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="입고처"
                        @appendIconClick="onDealcoIconClick('IN')"
                        @enterKey="onDealcoIconClick('IN')"
                        @input="onDealcoInput('IN')"
                        :objAuth="this.objAuth"
                        :eRequired="true"
                        v-model="reqParam.inPlcNm"
                        :codeVal="reqParam.inPlcId"
                        :disabledAfter="true"
                        :disabled="isNotNew"
                        @focus="inPlcFocus"
                    >
                    </TCComInputSearchText>
                    <!-- 외부거래처팝업 -->
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <!-- //item 2-3 -->
            </div>
            <!-- //Search_line 2 -->
            <!-- Search_line 3 -->
            <div class="searchform">
                <!-- item 3-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="출고지시일"
                        :calType="calType"
                        v-model="setOutSchdDate"
                        :eRequired="true"
                        ref="outSchdDate"
                        :disabled="isNotNew"
                        @change="outSchdDtChange"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 3-1 -->
                <!-- item 3-2 -->
                <div class="formitem div4">
                    <span class="itemtit">주문일</span>
                    <TCComDatePicker
                        :eRequired="true"
                        :calType="calType"
                        v-model="setOrdDate"
                        :disabled="true"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 3-2 -->
                <!-- item 3-3 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="납기요청일"
                        :calType="calType"
                        v-model="setPrdpayReqDate"
                        :disabled="true"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 3-3 -->
                <!-- item 3-4 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="납기예정일"
                        :calType="calType"
                        v-model="setPrdpaySchdDate"
                        :disabled="true"
                    >
                    </TCComDatePicker>
                </div>
                <!-- //item 3-4 -->
            </div>
            <!-- //Search_line 3 -->
        </div>

        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="매출출고관리상세 내역"
                :gridObj="this.gridObj"
                :isExceldown="isNotNew"
                :isDelRow="true"
                @excelDownBtn="exportGridBtn"
                @chkDelRowBtn="gridchkDelRowBtn"
            >
                <template #gridElementArea>
                    <TCComInput
                        labelName="입고처여신잔액"
                        v-model="crdtLimit"
                        :disabled="true"
                        :commaFormat="true"
                    />
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
                :editable="true"
                @onRowUpdated="onRowUpdated"
            />
        </div>
        <!-- //gridWrap -->

        <!-- Text area -->
        <div class="textareaLayer_wrap">
            <TCComTextArea
                v-model="outMaster.rmks"
                labelName="출고사유"
                :rows="5"
                class="boxtype"
                :disabled="isNotNew"
            />
        </div>
        <!-- //Text area -->
        <!-- 상품입력POPUP -->
        <DisDcoProdInsOutPopup
            v-if="showAddProdPop === true"
            :dialogShow.sync="showAddProdPop"
            :addProdData.sync="addProdPopParam"
            @returnVal="returnProdList"
        />
        <!-- //상품입력POPUP -->
        <!-- 상품입력(재고검색)POPUP -->
        <DisDcoProdInsDisSrchPopup
            v-if="showDisProdPop === true"
            :dialogShow.sync="showDisProdPop"
            :params="disProdParam"
            :prodOrgList="prodOrgList"
            @addDisProdList="returnProdList"
        />
        <!-- //상품입력(재고검색)POPUP -->
        <TCComAlert
            :headerText="'매출출고관리상세'"
            v-model="saveBool"
            :bodyText="alertBodyTxt"
            :size="400"
            :btnOkShow="false"
            @ok-click="listBtn"
        ></TCComAlert>
    </div>
</template>

<script>
import { CommonGrid, CommonUtil, CommonMsg, CommonBizClosing } from '@/utils'
import { DisIioSaleOutMgmtDtl_HEADER } from '@/const/grid/dis/iio/disIioSaleOutMgmtDtlHeader'
import iioApi from '@/api/biz/dis/iio/disIioSaleOutMgmtDtl'
import attachedFileApi from '@/api/common/attachedFile'
import DisDcoProdInsOutPopup from '@/views/biz/dis/dco/DisDcoProdInsOutPopup'
import DisDcoProdInsDisSrchPopup from '@/views/biz/dis/dco/DisDcoProdInsDisSrchPopup'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처(권한조직)====================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처(권한조직)==================
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================

export default {
    name: 'DisIioSaleOutMgmtDtl',
    components: {
        DisDcoProdInsOutPopup,
        DisDcoProdInsDisSrchPopup,
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
        BasBcoOutDealsPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //====================내부조직팝업(권한)팝업관련====================
            authOrgParam: {},
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            curInOutOrgFocus: '', // 현재 포커스된 검색조직(출고:OUT/입고:IN) 영역
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처(권한 조직))====================
            basBcoDealcoShow: false,
            searchDealcoParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY',
                dealcoClCd1: '',
            },
            resultDealcoRows: [],
            curInOutPlcFocus: '', // 현재 포커스된 거래처(출고:OUT/입고:IN) 영역
            //====================//내부거래처(권한 조직)==================
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '3X,2X,8X', // 거래처그룹
                dealcoClCd1: '', // 거래처구분
            },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            showInOrg: true, // 입고조직 visible 여부
            searchDisable: false,
            isNotNew: false, // 신규화면여부
            isNotFixYn: false,
            saveBool: false,
            isDateChange: false,
            alertHeadTxt: '매출출고관리상세',
            alertBodyTxt: '',
            gridData: {},
            gridObj: {},
            fvUserTyp: '1', // 로그인 사용자 유형
            gridHeaderObj: {},
            objAuth: {},
            params: {},
            calType: 'D',
            fvInDealCoCl1: '',
            view: DisIioSaleOutMgmtDtl_HEADER,
            listSearch: {},
            outMaster: {},
            prodSerNumList: [],
            outDtlList: [],
            prodOrgList: [], // 그리드 리스트 배열
            disProdParam: {}, // 재고상품입력팝업 파라미터
            searchParam: {}, // 상세조회 파라미터
            crdtLimit: 0, // 여신잔액
            outDealGrp: '3X,2X,8X', // 외부 거래처 그룹
            gridStyle: {
                height: '200px', //그리드 높이 조절
            },
            reqParam: {
                outSchdDt: '', // 출고지시일
                ordDt: '', // 주문일
                prdpaySchdDt: '', // 납기예정일
                prdpayReqDt: '', // 납기요청일
                outOrgId: '', // 출고조직코드
                outOrgNm: '', // 출고조직명
                outOrgLevel: '', // 출고조직레벨
                inOrgId: '', // 입고조직코드
                inOrgNm: '', // 입고조직명
                inOrgLevel: '', // 입고조직레벨
                outPlcId: '', // 출고처코드
                outPlcNm: '', // 출고처명
                inPlcId: '', // 입고처코드
                inPlcNm: '', // 입고처명
                outCl: '', // 출고구분
                inCl: '', // 조직구분
                asgnCl: '', // 주문유형
            },
            showAddProdPop: false, // 상품입력팝업 호출 값
            showDisProdPop: false, // 재고상품입력팝업 호출 값
            addProdPopParam: {},
            orgClComboItems: [
                // 조직구분 comboBox값
                { commCdValNm: '내부', commCdVal: '1' },
                { commCdValNm: '외부', commCdVal: '2' },
            ],
        }
    },
    created() {
        // 화면 default설정
        this.gridData = this.gridSetData()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, true, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.onEditCommit = this.onEditCommit
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })

        //검색영역
        this.listSearch = this.$route.params.search
        this.params = this.$route.params

        // 출고등록된 경우
        if (!_.isEmpty(this.$route.params.outMgmtNo)) {
            // 버튼 및 컴포넌트 제어
            this.isNotNew = true
            this.getOutDtlList()
        } else {
            this.init()
        }
    },
    computed: {
        setOutSchdDate: {
            get() {
                return this.reqParam['outSchdDt']
            },
            set(val) {
                this.reqParam['outSchdDt'] = val
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.reqParam.basMth = CommonUtil.onlyNumber(val).substr(0, 6)
                // 내부거래처 기준년월 파라미터 set
                this.searchDealcoParam.basDay = CommonUtil.onlyNumber(
                    val
                ).substr(0, 8)
                return val
            },
        },
        setOrdDate: {
            get() {
                return this.reqParam['ordDt']
            },
            set(val) {
                this.reqParam['ordDt'] = val
                return val
            },
        },
        setPrdpaySchdDate: {
            get() {
                return this.reqParam['prdpaySchdDt']
            },
            set(val) {
                this.reqParam['prdpaySchdDt'] = val
                return val
            },
        },
        setPrdpayReqDate: {
            get() {
                return this.reqParam['prdpayReqDt']
            },
            set(val) {
                this.reqParam['prdpayReqDt'] = val
                return val
            },
        },
    },
    methods: {
        init() {
            this.reqParam['outSchdDt'] = moment(new Date()).format('YYYY-MM-DD')
            this.reqParam['ordDt'] = this.reqParam['outSchdDt'] // 주문일
            this.reqParam['prdpaySchdDt'] = this.reqParam['outSchdDt'] // 납기예정일
            this.reqParam['prdpayReqDt'] = this.reqParam['outSchdDt'] // 납기요청일

            // 세션정보 set
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                // 조직
                this.reqParam['outOrgId'] = this.orgInfo['orgCd']
                this.reqParam['outOrgNm'] = this.orgInfo['orgNm']
                this.reqParam['outOrgLevel'] = this.orgInfo['orgLvl']
                // 출고처
                this.reqParam['outPlcId'] = this.userInfo['dealcoCd']
                this.reqParam['outPlcNm'] = this.userInfo['dealcoNm']
                this.searchDisable = true
            } else {
                this.reqParam['outOrgId'] = this.listSearch['outOrgId']
                this.reqParam['outOrgNm'] = this.listSearch['outOrgNm']
                this.reqParam['outOrgLevel'] = this.listSearch['outOrgLevel']

                this.reqParam['outPlcId'] = this.listSearch['outPlcId']
                this.reqParam['outPlcNm'] = this.listSearch['outPlcNm']
                this.searchDisable = false
            }
            this.reqParam.asgnCl = '02'
            this.reqParam.inCl = '1'
            this.showInOrg = true
        },
        // 그리드 rowUpdate 이벤트
        onRowUpdated(provider, row) {
            const rowData = provider.getJsonRow(row)

            const unitPrc = rowData['unitPrc'] // 단가
            const amt = rowData['amt'] // 금액

            // GAP 값 설정(금액 - 단가)
            if (isNaN(amt)) {
                provider.setValue(row, 'amt', 0)
                provider.setValue(row, 'gap', 0 - unitPrc)
            } else {
                provider.setValue(row, 'gap', amt - unitPrc)
            }
        },
        // 그리드 editCommit 이벤트
        onEditCommit(grid) {
            grid.editOptions.commitByCell = true
        },
        gridSetData: function () {
            // CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(0, 10000, '', '')
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert(
                    CommonMsg.getMessage('MSG_00071', '엑셀다운로드')
                )
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/iio/disIioSaleOutMgmtDtlExcels',
                this.searchParam
            )
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            if (!_.isEmpty(this.outMaster.outMgmtNo)) {
                this.openAlert(
                    CommonMsg.getMessage(
                        'MSG_00022',
                        '이미 출고 등록된 데이터로'
                    )
                )
                return
            }
            const chkRows = this.gridObj.gridView.getCheckedRows(true)
            this.gridData.gridRows = this.gridData.gridRows + chkRows.length
            this.gridHeaderObj.chkDelRow(this.gridData)
        },
        // 초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj) // 초기화 함수
            this.init()
        },
        //목록
        listBtn() {
            this.$router.push({
                name: '/dis/iio/DisIioSaleOutMgmt',
                params: { search: this.listSearch },
            })
        },
        //승인 버튼 이벤트
        async aprvBtn() {
            //MSG_00070: ' %s 처리하시겠습니까?'
            const confirm = await this.showTcComConfirm(
                CommonMsg.getMessage('MSG_00070', '승인')
            )

            if (confirm) {
                // 승인처리
                this.outMaster.outSchdDt = CommonUtil.onlyNumber(
                    this.outMaster.outSchdDt
                )
                this.outMaster.progId = 'DisIioSaleOutMgmtDtl'

                const aprvData = {
                    outMaster: this.outMaster,
                    prodSerNumList: this.prodSerNumList,
                }
                iioApi.outAprvOp(aprvData).then((res) => {
                    // 정상등록
                    if (res === 1) {
                        this.alertBodyTxt = CommonMsg.getMessage('MSG_00990')
                        this.saveBool = true
                    }
                })
            }
        },
        async delBtn() {
            //MSG_00070: ' %s 처리하시겠습니까?'
            const confirm = await this.showTcComConfirm(
                CommonMsg.getMessage('MSG_00070', '삭제')
            )

            if (confirm) {
                // 삭제처리
                this.outMaster.outSchdDt = CommonUtil.onlyNumber(
                    this.outMaster.outSchdDt
                )
                this.outMaster.progId = 'DisIioSaleOutMgmtDtl'

                const delData = {
                    outMaster: this.outMaster,
                    prodSerNumList: this.prodSerNumList,
                }
                iioApi.outCnclOp(delData).then((res) => {
                    // 정상처리
                    if (res === 1) {
                        this.alertBodyTxt = CommonMsg.getMessage('MSG_00990')
                        this.saveBool = true
                    }
                })
            }
        },
        // 저장
        async saveBtn() {
            const createdRows =
                this.gridObj.dataProvider.getStateRows('created')

            // 최초 등록시에만
            if (_.isEmpty(this.outMaster.outMgmtNo)) {
                if (createdRows.length == 0) {
                    this.openAlert(CommonMsg.getMessage('MSG_00114'))
                    return
                }

                // 내부일경우 여신단가 체크
                if (this.reqParam.inCl == '1') {
                    // 단가합계
                    // const totalPrc = this.gridObj.gridView.getSummary(
                    //     'unitPrc',
                    //     'sum'
                    // )
                    // if (this.crdtLimit < totalPrc) {
                    //     this.openAlert(
                    //         CommonMsg.getMessage('MSG_00086', '총금액;여신잔액')
                    //     )
                    //     return
                    // }
                }
                // 금액이 음수인 상품 리스트 filter
                const minusAmtList = this.gridObj.dataProvider
                    .getJsonRows(0, -1)
                    .filter((item) => item['amt'] < 0)

                if (minusAmtList.length > 0) {
                    this.openAlert('음수는 저장이 불가능합니다.')
                    return
                }

                const sOutSchdDt = CommonUtil.onlyNumber(
                    this.reqParam.outSchdDt
                )
                // 마감일 체크
                const clsStatus = await CommonBizClosing.getClsStatus(
                    'D',
                    sOutSchdDt,
                    'STK'
                )
                if (clsStatus && 'CLS' == clsStatus.clsStCd) {
                    this.openAlert(CommonMsg.getMessage('MSG_00185', ''))
                    return
                }
                if (sOutSchdDt > moment().add(30, 'days').format('YYYYMMDD')) {
                    // MSG_00099: ' %s(은)는 현재일자보다 + 30일 이상 일자는 선택 할 수 없습니다.',
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00099', '출고지시일'),
                        '500'
                    )
                    return
                }

                if (
                    this.reqParam['asgnCl'] == '01' &&
                    CommonUtil.onlyNumber(this.reqParam['outSchdDt']) <
                        CommonUtil.onlyNumber(this.reqParam['ordDt'])
                ) {
                    this.openAlert(
                        '출고지시일은 주문일[' +
                            this.reqParam['ordDt'] +
                            ']보다 과거로 등록할 수 없습니다.',
                        '600'
                    )
                }

                if (_.isEmpty(this.reqParam['outOrgId'])) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00121', '출고조직;저장')
                    )
                    return
                }

                if (_.isEmpty(this.reqParam['outPlcId'])) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00121', '출고처;저장')
                    )
                    return
                }

                if (this.reqParam['inCl'] == '1') {
                    if (_.isEmpty(this.reqParam['inOrgId'])) {
                        this.openAlert(
                            CommonMsg.getMessage('MSG_00121', '입고조직;저장')
                        )
                        return
                    }
                }
                if (_.isEmpty(this.reqParam['inPlcId'])) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00121', '입고처;저장')
                    )
                    return
                }
                /* 20151027 박재현 - 입고처 팝업에서 직영매장-직영점/물류창고(A2/Z1)를 제외해 주셔야 합니다. */
                if (this.fvInDealCoCl1 == 'A2' || this.fvInDealCoCl1 == 'Z1') {
                    this.openAlert(
                        '직영매장-직영점/물류창고를 입고처로 선택 할 수 없습니다.',
                        '500'
                    )
                    return
                }

                // MSG_00063: ' %s 저장하시겠습니까?'
                const confirm = await this.showTcComConfirm(
                    CommonMsg.getMessage('MSG_00063', '전체')
                )
                if (confirm) {
                    // 로직처리
                    this.saveOutSchd(createdRows)
                }
            }
        },
        // 출고등록
        saveOutSchd(createdRows) {
            // MASTER파라미터 set
            this.outMaster['inCl'] = this.reqParam['inCl'] // 조직구분(내부/외부)
            this.outMaster['asgnCl'] = this.reqParam['asgnCl'] // 주문유형
            this.outMaster['outOrgId'] = this.reqParam['outOrgId'] // 출고조직코드
            this.outMaster['inOrgId'] = this.reqParam['inOrgId'] // 입고조직코드
            this.outMaster['outPlcId'] = this.reqParam['outPlcId'] // 출고처코드
            this.outMaster['outPlcNm'] = this.reqParam['outPlcNm'] // 출고처명
            this.outMaster['inPlcId'] = this.reqParam['inPlcId'] // 입고처코드
            this.outMaster['inPlcNm'] = this.reqParam['inPlcNm'] // 입고처코드
            // 출고지시일
            this.outMaster['outSchdDt'] = CommonUtil.onlyNumber(
                this.reqParam['outSchdDt']
            )
            // 주문일
            this.outMaster['ordDt'] = CommonUtil.onlyNumber(
                this.reqParam['ordDt']
            )
            // 납기예정일
            this.outMaster['prdpaySchdDt'] = CommonUtil.onlyNumber(
                this.reqParam['prdpaySchdDt']
            )
            // 납기요청일
            this.outMaster['prdpayReqDt'] = CommonUtil.onlyNumber(
                this.reqParam['prdpayReqDt']
            )
            this.outMaster['progId'] = 'DisIioSaleOutMgmtDtl'

            let prodSerNumList = []
            let saveData = {}

            createdRows.forEach((i) => {
                prodSerNumList.push(this.gridObj.dataProvider.getJsonRow(i))
            })

            saveData = {
                outMaster: this.outMaster,
                prodSerNumList: prodSerNumList,
            }

            iioApi.saveOutSchd(saveData).then((res) => {
                // 정상등록
                if (res === 1) {
                    this.alertBodyTxt = CommonMsg.getMessage('MSG_00990')
                    this.saveBool = true
                }
            })
        },
        //출고 마스터/상세 조회
        getOutDtlList: function () {
            this.searchParam = {
                outMgmtNo: this.params.outMgmtNo,
                outPlcId: this.params.outPlcId,
            }

            iioApi.getOutDtlList(this.searchParam).then((res) => {
                // 출고마스터
                this.outMaster = res.result.outMaster

                // 디테일 리스트
                this.prodSerNumList = res.result.prodSerNumList

                this.gridObj.setRows(this.prodSerNumList)

                // 검색영역 제어
                this.setDivOrgDs()
            })
        },
        // 검색영역 제어
        setDivOrgDs() {
            this.reqParam['outSchdDt'] = this.outMaster['outSchdDt']
            this.reqParam['ordDt'] = this.outMaster['ordDt']
            this.reqParam['prdpaySchdDt'] = this.outMaster['prdpaySchdDt']
            this.reqParam['prdpayReqDt'] = this.outMaster['prdpayReqDt']
            this.reqParam['outOrgId'] = this.outMaster['outOrgId']
            this.reqParam['outOrgNm'] = this.outMaster['outOrgNm']
            this.reqParam['outPlcId'] = this.outMaster['outPlcId']
            this.reqParam['outPlcNm'] = this.outMaster['outPlcNm']
            this.reqParam['asgnCl'] = this.outMaster['asgnCl']
            // TODO 임시 승인버튼 삭졔
            if (
                !_.isEmpty(this.outMaster['outFixYn']) &&
                _.isEmpty(this.outMaster['outFixDt']) &&
                this.outMaster['outFixYn'] == 'N'
            ) {
                // 출고예정상태일 경우 승인버튼 활성화
                this.isNotFixYn = true
            }

            // 금액컬럼 수정불가 처리
            this.gridObj.gridView.setColumnProperty('amt', 'editable', false)
            const sDealCoGrp = this.outMaster['inDealCoGrp']
            if (
                this.outDealGrp.indexOf(sDealCoGrp) == -1 &&
                !_.isEmpty(sDealCoGrp)
            ) {
                // 조직구분 - 내부
                this.reqParam['inCl'] = '1'
                this.reqParam['inOrgId'] = this.outMaster['inOrgId']
                this.reqParam['inOrgNm'] = this.outMaster['inOrgNm']
                this.reqParam['inPlcId'] = this.outMaster['inPlcId']
                this.reqParam['inPlcNm'] = this.outMaster['inPlcNm']
                // 입고조직 검색영역 visible true
                this.showInOrg = true
            } else {
                // 조직구분 - 외부
                this.reqParam['inCl'] = '2'
                this.reqParam['inPlcId'] = this.outMaster['inPlcId']
                this.reqParam['inPlcNm'] = this.outMaster['inPlcNm']
                // 입고조직 검색영역 visible false
                this.showInOrg = false
            }

            // 여신잔액조쇠
            this.getCrdtLimit()
        },
        // 여신잔액 조회
        getCrdtLimit(sDealId) {
            const param = {}
            if (!_.isEmpty(sDealId)) {
                param.dealCoCd = sDealId
            } else {
                param.orgId = this.reqParam['inOrgId']
                param.dealCoCd = this.reqParam['inPlcId']
            }

            iioApi.getCrdtLimit(param).then((res) => {
                this.crdtLimit = res.result.crdtLimit
            })
        },
        // 팝업 호출 validation 체크
        isPopValidChk() {
            // 상품입력 || Swing상품입력
            if (_.isEmpty(this.reqParam.outSchdDt)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '출고지시일'))
                return false
            }
            if (_.isEmpty(this.reqParam.asgnCl)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '주문유형'))
                return false
            }

            if (_.isEmpty(this.reqParam.outOrgId)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '출고조직'))
                return false
            }
            if (_.isEmpty(this.reqParam.outPlcId)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '출고처'))
                return false
            }

            if (this.reqParam.inCl == '1') {
                if (_.isEmpty(this.reqParam.inOrgId)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00121', '입고조직;진행')
                    )
                    return false
                }
                if (_.isEmpty(this.reqParam.inPlcId)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00121', '입고처;진행')
                    )
                    return false
                }
            } else {
                if (_.isEmpty(this.reqParam.inPlcId)) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00121', '입고처;진행')
                    )
                    return false
                }
            }
            return true
        },
        // 주문유형 comboBox 필터
        filterAsgnFunc(items) {
            return items.filter((item) => item['commCdVal'] === '02')
        },
        // 상품입력팝업 호출
        addProdPop() {
            // validation
            if (!this.isPopValidChk()) {
                return false
            }

            // 상품입력팝업 파라미터 set
            this.addProdPopParam = {
                aplyDt: this.reqParam.outSchdDt,
                outPlcId: this.reqParam.outPlcId,
                parentList: this.gridObj.dataProvider.getJsonRows(0, -1),
            }

            this.showAddProdPop = true
        },
        // 재고상품입력팝업 호출
        addDisProdPop() {
            if (!this.isPopValidChk()) {
                return false
            }

            // 재고상품입력 팝업 파라미터 set
            this.disProdParam = {
                outPlcId: this.reqParam.outPlcId, // 출고처ID
                outPlcNm: this.reqParam.outPlcNm, // 출고처명
                outSchdDt: this.reqParam.outSchdDt, // 출고예정일
            }
            this.prodOrgList = this.gridObj.dataProvider.getJsonRows(0, -1)
            this.showDisProdPop = true
        },
        // 상품입력/재고상품입력 팝업 리턴 데이터
        async returnProdList(returnVal) {
            // let saveAmt = 0
            if (returnVal.length > 0) {
                returnVal.forEach((data) => {
                    if (data['outQty'] == null) {
                        data['outQty'] = data['qty']
                    }
                    // 저장금액 신규검색하여 세팅
                    this.getSaveAmt(data)
                })
            }
        },
        // 저장금액 검색
        getSaveAmt(data) {
            const searchAmt = {
                prodCd: data['prodCd'],
                outSchdDt: CommonUtil.onlyNumber(this.reqParam.outSchdDt),
            }
            iioApi.getSaveAmt(searchAmt).then((res) => {
                data['unitPrc'] = res.result.saveAmt
                data['amt'] = res.result.saveAmt
                data['gap'] = data['amt'] - data['unitPrc']
                // 상품 append
                this.gridObj.dataProvider.insertRow(
                    this.gridObj.gridView.getItemCount(),
                    data
                )
            })
        },
        // 조직구분 ComboBox 변경이벤트
        inClChange(val) {
            if (val == '1') {
                // 내부
                // 입고조직 검색영역 visible true
                this.showInOrg = true
            } else {
                // 외부
                // 입고조직 검색영역 visible false
                this.showInOrg = false
            }
            this.gridObj.gridInit()
            // 입고조직 입고처 여신잔액 초기화
            this.reqParam['inOrgId'] = ''
            this.reqParam['inOrgNm'] = ''
            this.reqParam['inOrgLevel'] = ''
            this.reqParam['inPlcId'] = ''
            this.reqParam['inPlcNm'] = ''
            this.crdtLimit = 0
        },
        // 출고지시일 변경 이벤트
        async outSchdDtChange(val) {
            const curDate = moment(new Date()).format('YYYY-MM-DD').toString()
            if (!this.isNotNew && this.isDateChange && !_.isEmpty(val)) {
                if (
                    CommonUtil.onlyNumber(val.substr(0, 7)) <
                    CommonUtil.onlyNumber(moment(new Date()).format('YYYYMM'))
                ) {
                    this.openAlert('현재월 이전으로는 입력이 불가합니다.')
                    this.reqParam.outSchdDt = curDate
                    this.$refs.outSchdDate.dDate = curDate
                    this.$refs.outSchdDate.dDateP = curDate
                    return
                }

                // 마감일 체크
                const clsStatus = await CommonBizClosing.getClsStatus(
                    'D',
                    CommonUtil.onlyNumber(val),
                    'STK'
                )
                if (clsStatus && 'CLS' == clsStatus.clsStCd) {
                    this.openAlert(CommonMsg.getMessage('MSG_00185', ''))
                    this.reqParam.outSchdDt = ''
                    return
                }

                if (
                    CommonUtil.onlyNumber(val) > CommonUtil.onlyNumber(curDate)
                ) {
                    this.openAlert(
                        '출고지시일자[' +
                            val +
                            ']는 현재일보다 이후 날짜로 입력이 불가합니다.',
                        '600'
                    )
                    this.reqParam.outSchdDt = curDate
                    this.$refs.outSchdDate.dDate = curDate
                    this.$refs.outSchdDate.dDateP = curDate
                } else {
                    if (this.reqParam['asgnCl'] == '02') {
                        this.reqParam['ordDt'] = val
                        this.reqParam['prdpayReqDt'] = val
                        this.reqParam['prdpaySchdDt'] = val
                    }
                }
            }
            this.isDateChange = true
        },
        // alert창 호출
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        // 출고조직 Focus이벤트
        outOrgFocus() {
            // 현재 Focus 조직 flag
            this.curInOutOrgFocus = 'OUT'
        },
        // 입고조직 Focus이벤트
        inOrgFocus() {
            // 현재 Focus 조직 flag
            this.curInOutOrgFocus = 'IN'
        },
        // 출고처 Focus이벤트
        outPlcFocus() {
            // 현재 Focus 거래처 flag
            this.curInOutPlcFocus = 'OUT'
        },
        // 입고처 Focus이벤트
        inPlcFocus() {
            // 현재 Focus 거래처 flag
            this.curInOutPlcFocus = 'IN'
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList(flag) {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.authOrgParam)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        if (flag == 'OUT') {
                            this.reqParam.outOrgId = _.get(res[0], 'orgCd')
                            this.reqParam.outOrgNm = _.get(res[0], 'orgNm')
                            this.reqParam.outOrgLevel = _.get(res[0], 'orgLvl')
                        } else {
                            this.reqParam.inOrgId = _.get(res[0], 'orgCd')
                            this.reqParam.inOrgNm = _.get(res[0], 'orgNm')
                            this.reqParam.inOrgLevel = _.get(res[0], 'orgLvl')
                        }
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick(flag) {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []

            if (flag == 'OUT') {
                this.authOrgParam['orgNm'] = this.reqParam['outOrgNm']
                this.authOrgParam['orgCd'] = this.reqParam['outOrgId']
                this.authOrgParam['orgLvl'] = this.reqParam['outOrgLevel']
            } else {
                this.authOrgParam['orgNm'] = this.reqParam['inOrgNm']
                this.authOrgParam['orgCd'] = this.reqParam['inOrgId']
                this.authOrgParam['orgLvl'] = this.reqParam['inOrgLevel']
            }

            const inOutOrgNm =
                flag == 'OUT' ? this.reqParam.outOrgNm : this.reqParam.outInNm
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(inOutOrgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            if (this.curInOutOrgFocus == 'OUT') {
                if (
                    !_.isEmpty(this.reqParam.outOrgId) &&
                    this.reqParam.outOrgId != returnData.orgCd
                ) {
                    this.reqParam.outPlcId = ''
                    this.reqParam.outPlcNm = ''
                    this.gridObj.gridInit()
                }
                this.reqParam.outOrgId = _.get(returnData, 'orgCd')
                this.reqParam.outOrgNm = _.get(returnData, 'orgNm')
                this.reqParam.outOrgLevel = _.get(returnData, 'orgLvl')
            } else {
                if (
                    !_.isEmpty(this.reqParam.inOrgId) &&
                    this.reqParam.inOrgId != returnData.orgCd
                ) {
                    this.reqParam.inPlcId = ''
                    this.reqParam.inPlcNm = ''
                }
                this.reqParam.inOrgId = _.get(returnData, 'orgCd')
                this.reqParam.inOrgNm = _.get(returnData, 'orgNm')
                this.reqParam.inOrgLevel = _.get(returnData, 'orgLvl')
            }
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput(flag) {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            if (flag == 'OUT') {
                // 출고조직 검색영역 초기화
                this.reqParam.outOrgId = ''
                this.reqParam.outOrgLevel = ''
                // 출고처 검색영역 초기화
                this.reqParam.outPlcId = ''
                this.reqParam.outPlcNm = ''
                this.gridObj.gridInit()
            } else {
                // 입고조직 검색영역 초기화
                this.reqParam.inOrgId = ''
                this.reqParam.inOrgLevel = ''
                // 입고처 검색영역 초기화
                this.reqParam.inPlcId = ''
                this.reqParam.inPlcNm = ''
            }
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList(flag) {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcoParam)
                .then((res) => {
                    // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                    if (res.length === 1) {
                        if (flag == 'OUT') {
                            this.reqParam.outPlcId = _.get(res[0], 'dealcoCd')
                            this.reqParam.outPlcNm = _.get(res[0], 'dealcoNm')
                        } else {
                            this.reqParam.inPlcId = _.get(res[0], 'dealcoCd')
                            this.reqParam.inPlcNm = _.get(res[0], 'dealcoNm')
                            this.fvInDealCoCl1 = _.get(res[0], 'dealcoClCd1')
                            this.getCrdtLimit(this.reqParam.inPlcId)
                        }
                    } else {
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick(flag) {
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.resultOutDealRows = []
            if (flag == 'OUT') {
                // 출고처
                if (_.isEmpty(this.reqParam.outOrgId)) {
                    // MSG_00083
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00083', '출고조직')
                    )
                    return
                }
                this.searchDealcoParam['orgCd'] = this.reqParam['outOrgId']
                this.searchDealcoParam['orgNm'] = this.reqParam['outOrgNm']
                this.searchDealcoParam['orgLvl'] = this.reqParam['outOrgLevel']
                this.searchDealcoParam['dealcoCd'] = this.reqParam['outPlcId']
                this.searchDealcoParam['dealcoNm'] = this.reqParam['outPlcNm']
                this.searchDealcoParam['dealcoClCd1'] =
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2'
                if (!_.isEmpty(this.reqParam.outPlcNm)) {
                    // 내부거래처조회
                    this.getDealcosList(flag)
                } else {
                    // 팝업오픈
                    this.basBcoDealcoShow = true
                }
            } else {
                // 입고처
                if (this.reqParam.inCl == '1') {
                    // 내부
                    if (_.isEmpty(this.reqParam.inOrgId)) {
                        this.openAlert(
                            CommonMsg.getMessage('MSG_00083', '입고조직')
                        )
                        return
                    }
                    this.searchDealcoParam['orgCd'] = this.reqParam['inOrgId']
                    this.searchDealcoParam['orgNm'] = this.reqParam['inOrgNm']
                    this.searchDealcoParam['orgLvl'] =
                        this.reqParam['inOrgLevel']
                    this.searchDealcoParam['dealcoCd'] =
                        this.reqParam['inPlcId']
                    this.searchDealcoParam['dealcoNm'] =
                        this.reqParam['inPlcNm']
                    this.searchDealcoParam['dealcoClCd1'] =
                        'A6,A7,AF,B2,M1,A3,D1,C1,E1,AC'
                    if (!_.isEmpty(this.reqParam.inPlcNm)) {
                        // 내부거래처조회
                        this.getDealcosList(flag)
                    } else {
                        // 팝업오픈
                        this.basBcoDealcoShow = true
                    }
                } else {
                    // 외부
                    // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
                    // 그 이외는 외부거래처 팝업 오픈
                    this.resultOutDealRows = []
                    this.searchOutDealParam['dealcoCd'] = this.reqParam.inPlcId
                    this.searchOutDealParam['dealcoNm'] = this.reqParam.inPlcNm
                    // 외부거래처팝업오픈
                    if (!_.isEmpty(this.reqParam.inPlcNm)) {
                        this.getOutDealList()
                    } else {
                        this.showBcoOutDeals = true
                    }
                }
            }
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput(flag) {
            // 입력되는 값이 있으면 코드 초기화
            if (flag == 'OUT') {
                this.reqParam.outPlcId = ''
                this.gridObj.gridInit()
            } else {
                this.reqParam.inPlcId = ''
                this.crdtLimit = 0
            }
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            if (this.curInOutPlcFocus == 'OUT') {
                if (this.reqParam.outPlcId != returnData.dealcoCd) {
                    this.gridObj.gridInit()
                }
                this.reqParam.outPlcId = _.get(returnData, 'dealcoCd')
                this.reqParam.outPlcNm = _.get(returnData, 'dealcoNm')
            } else {
                this.reqParam.inPlcId = _.get(returnData, 'dealcoCd')
                this.reqParam.inPlcNm = _.get(returnData, 'dealcoNm')
                this.fvInDealCoCl1 = _.get(returnData, 'dealcoClCd1')
                // 여신잔액조회
                this.getCrdtLimit(this.reqParam.inPlcId)
            }
        },
        //===================== //내부거래처(권한조직) methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.inPlcId = _.get(res[0], 'dealcoCd')
                        this.reqParam.inPlcNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
    },
}
</script>
