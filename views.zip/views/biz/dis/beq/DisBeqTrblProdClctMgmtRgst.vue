<!-----------------------------------------------
DISBEQ01100
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">사고단말기 등록</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Top BTN -->
                    <ul class="btn_area top pop">
                        <li class="left">
                            <TCComButton
                                eClass="btn_ty"
                                :disabled="disabeldDetailView"
                                @click="btnProdOnclick"
                                >재고선택</TCComButton
                            >
                        </li>
                    </ul>
                    <!-- // Top BTN -->

                    <!-- Search_div -->
                    <div class="searchLayer_wrap mgb-10">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComDatePicker
                                    v-model="setDate"
                                    calType="D"
                                    labelName="처리일"
                                    :eRequired="true"
                                    eClass="single"
                                    :disabled="disabeldDetailView"
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="dsConditionPopup1.orgNm"
                                    :codeVal.sync="dsConditionPopup1.orgCd"
                                    labelName="조직"
                                    :eRequired="true"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :disabled="disabeldDetailView"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    ref="riskComboRef"
                                    codeId="ZDIS_C_00171"
                                    labelName="Risk 중분류"
                                    v-model="dsConditionPopup1.riskMclCd"
                                    :eRequired="true"
                                    :filterFunc="riskMclCdFilter"
                                    :disabled="disabeldDetailView"
                                />
                            </div>
                            <!-- //item 1-3 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="dsConditionPopup1.dealcoNm"
                                    :codeVal.sync="dsConditionPopup1.dealcoCd"
                                    labelName="거래처"
                                    :eRequired="true"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onDealcoEnterKey"
                                    @appendIconClick="onDealcoIconClick"
                                    @input="onDealcoInput"
                                    :disabled="disabeldDetailView"
                                />
                                <BasBcoInrDealcosPopup
                                    v-if="showBasBcoInrDealcos"
                                    :parentParam="searchForm"
                                    :rows="resultDealcoRows"
                                    :dialogShow.sync="showBasBcoInrDealcos"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                            <!-- //item 2-1 -->
                            <div class="formitem div3_3"></div>
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <!-- gridWrap -->
                    <TCRealGridHeader
                        id="popupGridHeader"
                        ref="popupGridHeader"
                        gridTitle="매출조정"
                        :gridObj="gridObj"
                        :isPageRows="true"
                        :isExceldown="true"
                        :isDelRow="true"
                        @chkDelRowBtn="gridchkDelRowBtn"
                        @excelDownBtn="onClickDownload"
                        :disExceldown="disabledExceldownload"
                        :disDelRow="disabledDelRow"
                    />
                    <TCRealGrid
                        id="popupGrid"
                        ref="popupGrid"
                        :fields="view.fields"
                        :columns="view.columns"
                        :styles="gridStyle"
                    />
                    <!-- Search_div -->
                    <div class="searchLayer_wrap mt30 mgb-10">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="비용처리"
                                    v-model="dsConditionPopup1.costOpAmt"
                                    :disabled="disabledBottom"
                                    inputRuleType="N"
                                    @input="fSetRiskClctAmt"
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="입금(거래처계좌)"
                                    v-model="dsConditionPopup1.dpstAmt"
                                    :disabled="disabledBottom"
                                    inputRuleType="N"
                                    @input="fSetRiskClctAmt"
                                />
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="입금(타계좌)"
                                    v-model="dsConditionPopup1.etcDpstAmt"
                                    :disabled="disabledBottom"
                                    inputRuleType="N"
                                    @input="fSetRiskClctAmt"
                                />
                            </div>
                            <!-- //item 1-3 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="채무상계"
                                    v-model="dsConditionPopup1.debtSetoffAmt"
                                    :disabled="disabledBottom"
                                    inputRuleType="N"
                                    @input="fSetRiskClctAmt"
                                />
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="회수금액 합계"
                                    v-model="dsConditionPopup1.fixCrdtAmt"
                                    :disabled="true"
                                />
                            </div>
                            <!-- //item 2-2 -->
                            <!-- item 2-3 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="Risk금액 합계"
                                    v-model="dsConditionPopup1.riskFixCrdtAmt"
                                    :disabled="true"
                                />
                            </div>
                            <!-- //item 2-3 -->
                        </div>
                        <!-- //Search_line 2 -->
                        <!-- Search_line 3 -->
                        <div class="searchform">
                            <!-- item 3-1 -->
                            <div class="formitem div1">
                                <TCComTextArea
                                    labelName="비고"
                                    :rows="3"
                                    class="boxtype"
                                    v-model="dsConditionPopup1.rmks"
                                    :disabled="disabledRmks"
                                />
                            </div>
                            <!-- //item 3-1 -->
                        </div>
                        <!-- //Search_line 3 -->
                    </div>
                    <!-- //Search_div -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            :disabled="disabledbtnSave"
                            @click="cfSave"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
                <DisBeqTrblProdClctMgmtObj
                    v-if="showPopup01200 === true"
                    ref="popup"
                    :dialogShow.sync="showPopup01200"
                    :popupParams.sync="popupParams01200"
                    @confirm="onReturnDisBeqTrblProdClctMgmtObj"
                />
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil, CommonGrid, CommonBizClosing } from '@/utils'
import _ from 'lodash'
import { SacCommon } from '@/views/biz/sac/js'
import { G_HEADER } from '@/const/grid/dis/beq/disBeqTrblProdClctMgmtRgstHead'
import api from '@/api/biz/dis/beq/disBeqTrblProdClctMgmt'
import attachedFileApi from '@/api/common/attachedFile'
import DisBeqTrblProdClctMgmtObj from '@/views/biz/dis/beq/DisBeqTrblProdClctMgmtObj.vue'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-전체조직====================
import BasBcoInrDealcos from '@/api/biz/bas/bco/BasBcoInrDealcos'
import BasBcoInrDealcosPopup from '@/components/common/BasBcoInrDealcosPopup'
//====================//내부거래처-전체조직==================

export default {
    name: 'DisBeqTrblProdClctMgmtRgst',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoInrDealcosPopup,
        DisBeqTrblProdClctMgmtObj,
    },
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            dsConditionPopup1: {
                costOpAmt: 0,
                dpstAmt: 0,
                etcDpstAmt: 0,
                debtSetoffAmt: 0,
                fixCrdtAmt: 0,
                riskFixCrdtAmt: 0,
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                dealcoCd: '',
                dealcoNm: '',
            },
            // main grid 영역
            gridObj: {},
            gridHeaderObj: {},
            gridData: this.GridSetData(),
            view: G_HEADER,
            gridStyle: {
                height: '200px', //그리드 높이 조절
            },
            objAuth: {},
            FV_NEW_INSERT_YN: '', // 신규여부
            // 활성화여부
            // - 상세 조회일 경우 비활성화 항목
            disabeldDetailView: false,
            // - 저장버튼
            disabledbtnSave: false,
            // - 하단 입력 영역
            disabledBottom: false,
            // - 비고 영역
            disabledRmks: false,
            // - 엑셀다운로드
            disabledExceldownload: true,
            // - 그리드 행삭제
            disabledDelRow: false,
            // popup
            popupParams01200: {},
            showPopup01200: false,
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처-전체====================
            showBasBcoInrDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: '', //거래처그룹코드
                dealcoClCd1: '', //거래처구분코드
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-전체==================
            // paging
            rowCnt: 15, // 표시할 행의 갯수
            //조회 파라미터
            reqParams: {},
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        setDate: {
            get() {
                return this.dsConditionPopup1.tranDt
            },
            set(val) {
                this.dsConditionPopup1.tranDt = val
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchParam.basMth = CommonUtil.onlyNumber(val).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val)
                return val
            },
        },
    },
    created() {},
    mounted() {
        // 그리드 초기화
        this.gridInit()
        // 초기값 세팅
        this.fInit()

        this.gridObj.dataProvider.onRowDeleted = (provider, row) => {
            console.log('dataProvider row deleted: ' + row)
            this.fSetRiskAmt()
        }
    },
    //
    methods: {
        gridInit: function () {
            // 그리드 헤더 세팅
            this.gridObj = this.$refs.popupGrid
            this.gridHeaderObj = this.$refs.popupGridHeader
            this.gridObj.setGridState(false, false, true)
            this.gridObj.gridView.setRowIndicator({ visible: true })
            this.gridObj.gridView.setDisplayOptions({
                fitStyle: 'even',
            })
        },
        GridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(-1, 10, '', '')
        },
        fInit: function () {
            this.dsConditionPopup1 = Object.assign(
                this.dsConditionPopup1,
                this.popupParams
            )
            this.searchForm.orgCd = this.popupParams.orgCd // 거래처팝업세팅
            this.searchForm.orgNm = this.popupParams.orgNm // 거래처팝업세팅
            this.searchForm.orgLvl = this.popupParams.orgLvl // 거래처팝업세팅

            this.dsConditionPopup1.riskMclCd = '03'
            this.dsConditionPopup1.tranDt = SacCommon.getToday()

            this.FV_NEW_INSERT_YN = this.popupParams.vNew

            // 내역조회일 경우
            if ('N' == this.FV_NEW_INSERT_YN) {
                this.disabledExceldownload = false
                this.disabledDelRow = true

                // 처리일자 세팅
                this.dsConditionPopup1.tranDt = this.popupParams.riskTranDt

                // 그리드 더블클릭 - 내역조회
                this.disabeldDetailView = true

                // ERP전송여부가 'Y'일 경우 저장 불가능
                if (
                    'Y' == this.popupParams.dpstErpTrmsYn ||
                    'Y' == this.popupParams.etcDpstErpTrmsYn ||
                    'Y' == this.popupParams.costErpTrmsYn ||
                    'Y' == this.popupParams.debtSetoffErpYn
                ) {
                    this.disabledbtnSave = true
                }

                // 당사과실일 경우 비활성화
                if ('02' == this.popupParams.riskMclCd) {
                    this.disabledbtnSave = true
                    this.disabledBottom = true
                }
                this.getPagingData()
            }
        },
        getPagingData: function () {
            const dsCondDatas = _.omit(this.dsConditionPopup1, ['calOrdDtm']) // 배열제거
            this.reqParams = dsCondDatas

            const formData = {
                dsCondition: {
                    ...dsCondDatas,
                },
            }

            api.getTrblProdClctRgsts(formData).then((resultData) => {
                this.gridObj.setRows(resultData)
                if (resultData.length > 0) {
                    if ('1' == resultData[0].clsYn) {
                        this.disabledbtnSave = true
                        this.disabledBottom = true
                        this.disabledRmks = true
                    }
                }

                this.fSetRiskAmt()
                this.fSetRiskClctAmt()
            })
        },
        // 사고단말기 금액세팅 - 사고단말기 금액을 세팅한다
        fSetRiskAmt: function () {
            this.gridObj.gridView.commit()

            const rowCount = this.gridObj.dataProvider.getRowCount()
            if (0 == rowCount) {
                this.dsConditionPopup1.riskFixCrdtAmt = 0 // risk금액 합계
            } else {
                // fixCrdtAmt // 회수금액 합계
                let riskAmt = 0
                let riskTotAmt = 0

                const rowsAll = this.gridObj.dataProvider.getJsonRows(0, -1)
                _.forEach(rowsAll, (item) => {
                    riskAmt = !item.riskAmt ? 0 : item.riskAmt
                    riskTotAmt = _.toNumber(riskTotAmt) + _.toNumber(riskAmt)
                })
                this.dsConditionPopup1.riskFixCrdtAmt = riskTotAmt
                // Risk 중분류가 당사과실인 경우
                // 비용처리금액 = 회수금액합계 = Risk 금액합계가 같다.
                const opMclCd = this.dsConditionPopup1.riskMclCd.value

                if ('02' == opMclCd) {
                    this.dsConditionPopup1.costOpAmt = riskTotAmt
                    this.dsConditionPopup1.fixCrdtAmt = riskTotAmt
                }
            }
        },
        // 회수금액합계 - 회수금액을 세팅한다
        fSetRiskClctAmt: function () {
            let costOpamt = this.dsConditionPopup1.costOpAmt // 비용상계
            let dpstAmt = this.dsConditionPopup1.dpstAmt // 입금(거래처)
            let etcDpstAmt = this.dsConditionPopup1.etcDpstAmt // 입금(기타)
            let debtSetoffAmt = this.dsConditionPopup1.debtSetoffAmt // 채무상계

            costOpamt = !costOpamt ? 0 : costOpamt
            dpstAmt = !dpstAmt ? 0 : dpstAmt
            etcDpstAmt = !etcDpstAmt ? 0 : etcDpstAmt
            debtSetoffAmt = !debtSetoffAmt ? 0 : debtSetoffAmt

            let clctTotAmt =
                _.toNumber(costOpamt) +
                _.toNumber(dpstAmt) +
                _.toNumber(etcDpstAmt) +
                _.toNumber(debtSetoffAmt)

            if (/^[0-9]*$/.test(clctTotAmt) == false) {
                return
            }

            this.dsConditionPopup1.fixCrdtAmt = clctTotAmt // 회수금액합계

            const riskFixCrdtAmt = this.dsConditionPopup1.riskFixCrdtAmt // risk 금액 합계

            if (_.toNumber(clctTotAmt) > _.toNumber(riskFixCrdtAmt)) {
                this.showTcComAlert('회수금액 합계가 Risk금액 합계보다 큽니다.')

                const COST_OP_AMT = this.gridObj.gridView.getSummary(
                    'costOpAmt',
                    'sum'
                )
                const IMAG_AMT = this.gridObj.gridView.getSummary(
                    'dpstAmt',
                    'sum'
                )
                const ETC_IMAG_AMT = this.gridObj.gridView.getSummary(
                    'etcDpstAmt',
                    'sum'
                )
                const DEBT_SETOFF_AMT = this.gridObj.gridView.getSummary(
                    'debtSetoffAmt',
                    'sum'
                )

                clctTotAmt =
                    _.toNumber(COST_OP_AMT) +
                    _.toNumber(IMAG_AMT) +
                    _.toNumber(ETC_IMAG_AMT) +
                    _.toNumber(DEBT_SETOFF_AMT)

                this.dsConditionPopup1.costOpAmt = COST_OP_AMT
                this.dsConditionPopup1.dpstAmt = IMAG_AMT
                this.dsConditionPopup1.etcDpstAmt = ETC_IMAG_AMT
                this.dsConditionPopup1.debtSetoffAmt = DEBT_SETOFF_AMT
                this.dsConditionPopup1.fixCrdtAmt = clctTotAmt
            }
        },
        // 재고선택 버튼
        btnProdOnclick: function () {
            if (_.isEmpty(this.dsConditionPopup1.orgCd)) {
                this.showTcComAlert('조직을 검색하신 후 조회 하시기 바랍니다.') //cf_getMessage(MSG_00083,'조직')
                return false
            }
            if (_.isEmpty(this.dsConditionPopup1.dealcoCd)) {
                this.showTcComAlert(
                    '거래처를 검색하신 후 조회 하시기 바랍니다.'
                ) //cf_getMessage(MSG_00083,'거래처')
                return false
            }
            if (_.isEmpty(this.dsConditionPopup1.riskMclCd)) {
                this.showTcComAlert(
                    'Risk 중분류를 검색하신 후 조회 하시기 바랍니다.'
                ) //cf_getMessage(MSG_00083,'Risk 중분류')
                return false
            }

            // 팝업 파라미터 전달
            const dsCondDatas = _.omit(this.dsConditionPopup1, ['calOrdDtm']) // 배열제거

            this.popupParams01200 = {
                dsCondition: {
                    ...dsCondDatas,
                    riskMclNm: this.$refs.riskComboRef.getValueText, // risk 중분류명
                },
                dsRiskClct: this.gridObj.dataProvider.getJsonRows(0, -1),
            }
            this.showPopup01200 = true
        },
        // 저장
        async cfSave() {
            console.log('저장시작--------------------')
            const clsStatus = await CommonBizClosing.getClsStatus(
                'D',
                SacCommon.removeHyphen(this.dsConditionPopup1.tranDt),
                'STK'
            )

            if (clsStatus && 'CLS' == clsStatus.clsStCd) {
                this.showTcComAlert('최종 마감일 이전 일자입니다.')
                return
            }
            if (_.isEmpty(this.dsConditionPopup1.orgCd)) {
                this.showTcComAlert('조직을 검색하신 후 저장 하시기 바랍니다.') //cf_getMessage(MSG_00121,'조직')
                return false
            }
            if (_.isEmpty(this.dsConditionPopup1.dealcoCd)) {
                this.showTcComAlert(
                    '거래처를 검색하신 후 저장 하시기 바랍니다.'
                ) //cf_getMessage(MSG_00121,'거래처')
                return false
            }
            if (_.isEmpty(this.dsConditionPopup1.riskMclCd)) {
                this.showTcComAlert(
                    'Risk 중분류를 검색하신 후 저장 하시기 바랍니다.'
                ) //cf_getMessage(MSG_00121,'Risk 중분류')
                return false
            }

            const rowCount = this.gridObj.dataProvider.getRowCount()
            if (0 == rowCount) {
                this.showTcComAlert('상품은 반드시 한개이상 등록해야 합니다.') //cf_getMessage(MSG_00121,'조직')
                return false
            }

            if (_.isEmpty(_.trim(this.dsConditionPopup1.costOpAmt))) {
                // 비용처리
                this.dsConditionPopup1.costOpAmt = 0
            }
            if (_.isEmpty(_.trim(this.dsConditionPopup1.dpstAmt))) {
                // 입금(거래처계좌)
                this.dsConditionPopup1.dpstAmt = 0
            }
            if (_.isEmpty(_.trim(this.dsConditionPopup1.etcDpstAmt))) {
                // 입금(타계좌)
                this.dsConditionPopup1.etcDpstAmt = 0
            }
            if (_.isEmpty(_.trim(this.dsConditionPopup1.debtSetoffAmt))) {
                // 채무상계
                this.dsConditionPopup1.debtSetoffAmt = 0
            }

            this.dsConditionPopup1.rmks = !this.dsConditionPopup1.rmks
                ? ''
                : this.dsConditionPopup1.rmks

            if (!CommonUtil.chkRmks(this.dsConditionPopup1.rmks)) {
                return
            }

            // 회수금액과 Risk 금액이 같은경우 완료처리
            const fixCrdtAmt = this.dsConditionPopup1.fixCrdtAmt // 회수금액
            const riskFixCrdtAmt = this.dsConditionPopup1.riskFixCrdtAmt // Risk 금액
            // 회수금액이 적을경우 진행안됨
            if (fixCrdtAmt !== riskFixCrdtAmt) {
                this.showTcComAlert(
                    '회수금액 합계와 Risk금액 합계가 틀립니다. 회수금액을 확인하십시요.'
                )
                return
            }

            if (fixCrdtAmt == riskFixCrdtAmt) {
                const confirm = await this.showTcComConfirm(
                    '완료처리 하시겠습니까?'
                )
                if (confirm) {
                    const dsCondDatas = _.omit(this.dsConditionPopup1, [
                        'calOrdDtm',
                    ]) // 배열제거

                    dsCondDatas.tranDt = SacCommon.removeHyphen(
                        dsCondDatas.tranDt
                    ) // 날짜에서 '-' 제거

                    var gridData = this.gridObj.dataProvider.getJsonRows(0, -1)

                    const formData = {
                        dsCondition: {
                            rowData: {
                                ...dsCondDatas,
                            },
                            rowDatas: gridData,
                        },
                    }

                    await api
                        .saveTrblProdClctRgsts(formData)
                        .then((resultData) => {
                            console.log(
                                'resultData ===================',
                                resultData
                            ) // <<== 무조건 undefined 인듯..
                            this.$emit('confirm', true)
                            this.activeOpen = false
                        })
                }
            }
        },
        // delete row
        gridchkDelRowBtn: function () {
            this.gridObj.gridView.commit()
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
            this.fSetRiskAmt()
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        riskMclCdFilter(item) {
            return item.filter((item) => item['commCdVal'] === '03')
        },
        // 팝업종료
        onReturnDisBeqTrblProdClctMgmtObj: function (retVal) {
            this.gridObj.gridView.commit()
            let passDataset = retVal.passDataset
            if (passDataset.length > 0) {
                passDataset.forEach((data) => {
                    this.gridObj.dataProvider.insertRow(
                        this.gridObj.gridView.getItemCount(),
                        data
                    )
                })
                this.fSetRiskAmt()
            }
        },
        //Grid ExcelDown
        onClickDownload: function () {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/beq/trblProdClctRgstsExcelDown',
                this.reqParams
            )
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.dsConditionPopup1.orgCd
            this.searchParam.orgNm = this.dsConditionPopup1.orgNm
            this.searchParam.orgLvl = this.dsConditionPopup1.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(
                    SacCommon.objectRemovedArray(this.searchParam)
                )
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.dsConditionPopup1.orgCd = _.get(res[0], 'orgCd')
                        this.dsConditionPopup1.orgNm = _.get(res[0], 'orgNm')
                        this.dsConditionPopup1.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            console.log(this.dsConditionPopup1)
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.dsConditionPopup1.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            // if (_.isEmpty(this.dsConditionPopup1.orgNm)) {
            //     // this.headerText = '검색조건 필수'
            //     this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
            //     return
            // }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.dsConditionPopup1.orgCd = ''
            this.dsConditionPopup1.orgLvl = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsConditionPopup1.orgCd = _.get(retrunData, 'orgCd')
            this.dsConditionPopup1.orgNm = _.get(retrunData, 'orgNm')
            this.dsConditionPopup1.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-전체팝업관련 methods ================================
        // 내부거래처-전체 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체 팝업 오픈
        getList() {
            this.searchForm.orgCd = this.dsConditionPopup1.orgCd
            this.searchForm.orgNm = this.dsConditionPopup1.orgNm
            this.searchForm.orgLvl = this.dsConditionPopup1.orgLvl
            this.searchForm.dealcoCd = this.dsConditionPopup1.dealcoCd
            this.searchForm.dealcoNm = this.dsConditionPopup1.dealcoNm
            console.log('this.searchForm>>>>>>>>>>>>> ', this.searchForm)
            BasBcoInrDealcos.getList(this.searchForm).then((res) => {
                console.log('getList then : ', res)
                // 검색된 내부거래처-전체 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체 팝업 오픈
                if (res.length === 1) {
                    this.dsConditionPopup1.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.dsConditionPopup1.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoInrDealcos = true
                }
            })
        },
        // 내부거래처-전체 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 검색조건 내부거래처-전체명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsConditionPopup1.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            // 내부거래처-전체 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 내부거래처-전체 정보 조회
            this.getList()
        },
        // 내부거래처-전체 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 검색조건 내부거래처-전체명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsConditionPopup1.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            // 내부거래처-전체 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 내부거래처-전체 정보 조회
            this.getList()
        },
        // 내부거래처-전체 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체 코드 초기화
            this.dsConditionPopup1.dealcoCd = ''
        },
        // 내부거래처-전체 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsConditionPopup1.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.dsConditionPopup1.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-전체팝업관련 methods ================================
    },
}
</script>
