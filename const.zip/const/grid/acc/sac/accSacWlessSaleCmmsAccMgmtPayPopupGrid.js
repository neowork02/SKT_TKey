import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = [
    {
        fieldName: 'orgTree',
        header: { text: '조직' },
        width: '300',
    },
    {
        fieldName: 'accDealcoCd',
        header: { text: '정산처', showTooltip: false },
        width: '100',
        button: 'action',
        buttonVisibility: 'always',
    },
    {
        fieldName: 'accDealcoNm',
        header: { text: '정산처명' },
        width: '150',
    },
    {
        fieldName: 'dealcoClNm1',
        header: { text: '거래처구분' },
        width: '150',
    },
    {
        fieldName: 'payDtm',
        header: { text: '수납일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'payTyp',
        header: { text: '수납유형' },
        width: '150',
    },
    {
        fieldName: 'payOpStNm',
        header: { text: '수납상태' },
        width: '150',
    },
    {
        fieldName: 'payClNm',
        header: { text: '수납구분' },
        width: '150',
    },
    {
        fieldName: 'saleMgmtNo',
        header: { text: '수납관리번호' },
        width: '150',
    },
    {
        fieldName: 'saleMgmtSeq',
        header: { text: '수납변경순번' },
        width: '150',
    },
    {
        fieldName: 'payMthdNm',
        header: { text: '수납방법' },
        width: '150',
    },
    {
        name: 'payAmt',
        fieldName: 'payAmt',
        type: 'data',
        header: { text: '수납금액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'ediYn',
        header: { text: 'EDI사용여부' },
        width: '150',
    },
    {
        fieldName: 'cardCoNm',
        header: { text: '카드사' },
        width: '150',
    },
    {
        fieldName: 'cardAprvNo',
        header: { text: '카드승인번호' },
        width: '150',
    },
    {
        fieldName: 'cardAprvDtm',
        header: { text: '카드승인일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'svcMgmtNums',
        header: { text: 'T서비스관리번호' },
        width: '150',
    },
    {
        fieldName: 'cntrctMgmtNos',
        header: { text: '계약관리번호' },
        width: '150',
    },
    {
        fieldName: 'freeProdSaleNos',
        header: { text: '일반상품판매번호' },
        width: '150',
    },
]

const GRID_HEADER = {}
GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)

export { GRID_HEADER }
