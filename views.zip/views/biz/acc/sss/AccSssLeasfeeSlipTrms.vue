<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 전대료전표전송
 * 설명:  조회,삭제,확정,전송요청 한다.
 * 작성자: P180190
 * 작성일: 2022.07.07
------------------------------------------------>
<template>
    <div class="content">
        <h1>전대료전표전송</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton eClass="btn_ty01" :objAuth="objAuth" @click="init"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSave"
                    :disabled="onSaveDis"
                    >확정</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onDele"
                    :disabled="onDelDis"
                    >삭제</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="청구년월"
                        calType="M"
                        :eRequired="true"
                        @change="onSrchAccYm"
                        v-model="srchAccYm_"
                    >
                    </TCComDatePicker>
                </div>
            </div>
        </div>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="증빙일자"
                        calType="D"
                        :eRequired="true"
                        @change="onTrmsDt"
                        v-model="fixFromSrch.trmsDt_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="전기일자"
                        calType="D"
                        :eRequired="true"
                        v-model="fixFromSrch.pstngDt_"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComRadioBox
                        labelName=""
                        v-model="fixFormData.trmsItmCd"
                        :itemList="trmsItmCds"
                        :objAuth="objAuth"
                    ></TCComRadioBox>
                </div>
                <div class="formitem div4">
                    <div class="rightArea btn">
                        <span class="inner">
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_s btn_ty03"
                                eAttr="ico_verification"
                                :objAuth="objAuth"
                                @click="onTrms"
                                labelName="전송요청"
                            />
                            <!-- <TCComButton
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="onTrms"
                                >전송요청</TCComButton
                            > -->
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="전대료전표전송"
                :isExceldown="true"
                :gridObj="gridObj"
                @excelDownBtn="downloadExcelAll"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
// import commonApi from '@/api/common/prototype'
import { CommonUtil, CommonGrid } from '@/utils'
import moment from 'moment'
import leaseFeeApi from '@/api/biz/acc/sss/AccSssLeasfeeSlipTrms'
import { GRID_HEADER } from '@/const/grid/acc/sss/AccSssLeasfeeSlipTrmsGrid'
import CommonMixin from '@/mixins'
export default {
    name: 'AccSssLeasfeeSlipTrms',
    components: {},
    mixins: [CommonMixin],
    data() {
        return {
            gridData: {},
            //Grid
            view: GRID_HEADER,

            //Grid
            objAuth: {},
            gridObj: {},
            gridHeaderObj: {},

            /*그리드 스타일*/
            gridStyle: {
                height: '430px', //그리드 높이 조절
            },
            // 버튼 비활성화
            onSaveDis: false,
            onDelDis: false,

            //요청 파라미터
            searchForms: {},
            srchAccYm_: moment(new Date()).format('YYYY-MM'),
            searchFormData: {
                srchAccYm: moment(new Date()).format('YYYY-MM'),
            },
            fixFromSrch: {
                trmsDt_: '',
                pstngDt_: '',
            },
            fixFormData: {
                trmsDt: '',
                pstngDt: '',
                trmsItmCd: 'T19',
                list: [],
            },

            //전표구분
            trmsItmCds: [
                {
                    commCdVal: 'S06',
                    commCdValNm: '추정전표',
                },
                {
                    commCdVal: 'T19',
                    commCdValNm: '확정전표',
                },
            ],
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, true, true, false)
        // console.log('menuInfo', this.menuInfo) //메뉴정보
        // console.log('authInfo', this.authInfo) // 권한정보(속성권한)
        // 승인권한이 있는경우에만 버튼 사용 가능
        // if('승인권한' == 'N'){
        //     onSaveDis = true
        //     onDelDis = true
        // }
    },
    created() {
        this.gridData = this.gridSetData()
    },
    methods: {
        // 초기화
        init: function () {
            this.srchAccYm_ = moment(new Date()).format('YYYY-MM')
            this.initDate()
            this.fixFormData.trmsItmCd = 'T19'
            this.$refs.grid.setRows([])
        },
        initDate: function () {
            this.fixFromSrch = {
                trmsDt_: moment(null),
                pstngDt_: moment(null),
            }
        },

        gridSetData: function () {
            return new CommonGrid(0, 10, '', '')
        },
        onSrchAccYm: function () {
            this.$refs.grid.setRows([])
            var trmsdtCom = this.fixFromSrch.trmsDt_
            var trmsdtCut = trmsdtCom.substring(0, 7)
            console.log('trmsdtCut', trmsdtCut)
            if (
                this.srchAccYm_.length == '7' &&
                trmsdtCom.length == '10' &&
                trmsdtCut != this.srchAccYm_
            ) {
                // this.showTcComAlert(
                //     this.sFromDt +
                //         '일 ~ ' +
                //         this.sToDt +
                //         '일 사이의 날짜로 입력하십시오'
                // )
                console.log('trmsdtCut::::', trmsdtCut)
                this.setTrmsDt(1)
            }
        },
        onTrmsDt: function () {
            // 입력한 청구년월의 첫일 구하기
            var sFromDt = moment(this.srchAccYm_)
                .startOf('month')
                .format('YYYY-MM-DD')
            // 입력한 청구년월의 마지막일 구하기
            var sToDt = moment(this.srchAccYm_)
                .endOf('month')
                .format('YYYY-MM-DD')
            if (
                this.fixFromSrch.trmsDt_.length == 10 &&
                this.fixFromSrch.trmsDt_ < sFromDt
            ) {
                this.showTcComAlert(
                    sFromDt + '일 ~ ' + sToDt + '일 사이의 날짜로 입력하십시오'
                )
                this.setTrmsDt(1)
            }

            if (
                this.fixFromSrch.trmsDt_.length == 10 &&
                this.fixFromSrch.trmsDt_ > sToDt
            ) {
                this.showTcComAlert(
                    sFromDt + '일 ~ ' + sToDt + '일 사이의 날짜로 입력하십시오'
                )
                this.setTrmsDt(2)
            }
        },

        // 전기일자 범위외 날짜 선택시 해당 청구년월의 1일 or 마지막일로 세팅
        setTrmsDt: function (val) {
            if (val == 1) {
                this.fixFromSrch.trmsDt_ = moment(this.srchAccYm_)
                    .startOf('month')
                    .format('YYYY-MM-DD')
            }
            if (val == 2) {
                this.fixFromSrch.trmsDt_ = moment(this.srchAccYm_)
                    .endOf('month')
                    .format('YYYY-MM-DD')
            }
        },
        //================================================
        // 전체 조회 :::: getLeaseFeeList
        //================================================
        onSearch: function () {
            const srchAccYm = this.srchAccYm_
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('청구년월을 입력하십시오.')
            } else {
                this.searchFormData.srchAccYm = CommonUtil.onlyNumber(
                    this.srchAccYm_
                )
                this.searchForms = { ...this.searchFormData }
                this.getLeaseFeeList(this.searchForms)
                console.log('전체리스트조회 ::::::: 시작')
            }
        },
        async getLeaseFeeList() {
            await leaseFeeApi.getLeaseFeeList(this.searchForms).then((res) => {
                if (res != undefined) {
                    console.log('전체리스트조회 ::::::: start', res)
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator()
                    console.log('전체리스트조회 ::::::: end')
                    this.searchForms = {}
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },
        //================================================
        // 선택한 row 확정 :::: fixLeaseFeeList
        //================================================
        onSave: function () {
            var checkedRows = this.$refs.grid.gridView.getCheckedItems(true)
            if (checkedRows == null || checkedRows.length == 0) {
                this.showTcComAlert('선택된 내용이 존재하지 않습니다.')
                return
            } else {
                this.searchForms.list = []
                this.showTcComConfirm('요청 하시겠습니까?').then((confirm) => {
                    if (confirm) {
                        for (var i = 0; i < checkedRows.length; i++) {
                            var row = this.$refs.grid.gridView.getValues(
                                checkedRows[i]
                            )
                            this.searchForms.list.push({
                                agencyCd: row.agencyCd,
                                shopCd: row.shopCd,
                                aplyYm: row.aplyYm,
                            })
                        }
                        console.log(this.searchForms.list)
                        console.log(
                            '선택리스트확정 ::::::: 시작' + this.searchForms
                        )
                        leaseFeeApi
                            .fixLeaseFeeList(this.searchForms)
                            .then((rs) => {
                                if (rs != undefined) {
                                    console.log(
                                        row + '선택리스트확정 ::::::: 종료'
                                    )
                                    this.showTcComAlert('확정 처리되었습니다.')
                                    this.onSearch()
                                } else {
                                    this.showTcComAlert(
                                        '확정 처리실패하였습니다.'
                                    )
                                    return
                                }
                            })
                    }
                })
            }
        },
        //================================================
        //  삭제 :::deleteSktCmms
        //================================================
        onDele: function () {
            var checkedRows = this.$refs.grid.gridView.getCheckedItems(true)
            if (checkedRows == null || checkedRows.length == 0) {
                this.showTcComAlert('선택한 내용이 존재하지 않습니다.')
                return
            }
            this.searchForms.list = []
            for (var i = 0; i < checkedRows.length; i++) {
                var row = this.$refs.grid.gridView.getValues(checkedRows[i])
                this.searchForms.list.push({
                    agencyCd: row.agencyCd,
                    shopCd: row.shopCd,
                    aplyYm: row.aplyYm,
                })
            }

            this.showTcComConfirm('선택한 데이터를 삭제하시겠습니까?').then(
                (confirm) => {
                    console.log('showTcComConfirm confirm: ', confirm)
                    if (confirm) {
                        leaseFeeApi
                            .deleteSktCmms(this.searchForms)
                            .then((resultData) => {
                                if (resultData != undefined) {
                                    console.log(
                                        '선택리스트삭제 ::::::: 시작',
                                        this.searchForms
                                    )
                                    this.showTcComAlert('삭제 처리되었습니다.')
                                    console.log('선택리스트삭제 ::::::: 끝')
                                    this.onSearch()
                                } else {
                                    this.showTcComAlert(
                                        '삭제 처리실패하였습니다.'
                                    )
                                }
                            })
                    }
                }
            )
        },
        //================================================
        // 선택한 row ERP 전송
        //================================================
        onTrms: function () {
            var sChkBudat = CommonUtil.onlyNumber(this.fixFromSrch.pstngDt_)
            var sPreBudatChk1 = '2'
            var sPreBudatChk2 = '4'
            var checkedRows = this.$refs.grid.gridView.getCheckedItems(true)
            if (checkedRows == null || checkedRows.length == 0) {
                this.showTcComAlert('변경된 데이터가 존재하지 않습니다.')
                return
            }
            // 증빙일자 체크
            var sChkBudatCut = sChkBudat.substring(0, 6)
            console.log('sChkBudatCut::::', sChkBudatCut)
            if (this.fixFromSrch.trmsDt_.length != 10) {
                this.showTcComAlert('증빙일자는 필수 입력사항입니다.')
                return
            }
            if (this.fixFromSrch.pstngDt_.length != 10) {
                this.showTcComAlert('전기일자는 필수 입력사항입니다.')
                return
            }
            this.searchForms.list = []
            for (var i = 0; i < checkedRows.length; i++) {
                var row = this.$refs.grid.gridView.getValues(checkedRows[i])
                console.log('checked row :::: ', row)
                // 기 확정거래처 체크
                if (row['fixYnNm'] == '미확정') {
                    this.showTcComAlert(row.orgNm + '은 미확정 거래처입니다.')
                    return
                }
                if (row['asmptPstngDt'] != null && row['asmptTrmsYn'] != null) {
                    //확정전표 전송 ::: T19
                    if (this.fixFormData.trmsItmCd == 'T19') {
                        console.log('확정전표', this.fixFormData.trmsItmCd)
                        if (
                            row['asmptPstngDt'].indexOf(sChkBudatCut) != -1 &&
                            (row['asmptTrmsYn'].indexOf(sPreBudatChk1) != -1 ||
                                row['asmptTrmsYn'].indexOf(sPreBudatChk2) != -1)
                        ) {
                            this.showTcComAlert(
                                row.orgNm +
                                    '은 전기일자가 추정전표의 전기월과 동일합니다.'
                            )
                            return
                        }
                    }
                }
                this.searchForms.trmsDt = CommonUtil.onlyNumber(
                    this.fixFromSrch.trmsDt_
                )
                this.searchForms.pstngDt = CommonUtil.onlyNumber(
                    this.fixFromSrch.pstngDt_
                )
                this.searchForms.trmsItmCd = this.fixFormData.trmsItmCd
                this.searchForms.list.push({
                    agencyCd: row.agencyCd,
                    shopCd: row.shopCd,
                    aplyYm: row.aplyYm,
                    prnRpaySchdAmt: row.prnRpaySchdAmt,
                    rpaySchdAmt: row.rpaySchdAmt,
                })
            }
            console.log('searchForms:::', this.searchForms)

            this.showTcComConfirm('전송 요청 하시겠습니까?').then((confirm) => {
                console.log('showTcComConfirm confirm: ', confirm)
                if (confirm) {
                    console.log('선택리스트전송요청 ::::::: 시작')
                    leaseFeeApi
                        .trmsLeaseFeeList(this.searchForms)
                        .then((res) => {
                            if (res != undefined) {
                                console.log(
                                    '선택리스트전송요청 ::::::: 끝',
                                    res
                                )
                                this.showTcComAlert('전송되었습니다.')
                                this.onSearch()
                            } else {
                                this.showTcComAlert('전성요청 실패하였습니다.')
                            }
                        })
                }
            })
        },
        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcelAll: function () {
            leaseFeeApi.downloadLeaseFeeListExcel(this.searchFormData)
        },
    },
}
</script>
