<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="600px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">신규등록/수정</p>
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap mt20">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="메뉴번호"
                                    v-model="forms.menuNo"
                                    :disabled="false"
                                    :eRequired="true"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="메뉴한글명"
                                    v-model="forms.menuNm"
                                    :disabled="false"
                                    :eRequired="false"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="메뉴레벨코드"
                                    v-model="forms.menuLvlCd"
                                    :disabled="false"
                                    :eRequired="false"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="메뉴URL"
                                    v-model="forms.menuUrl"
                                    :disabled="false"
                                    :eRequired="false"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="상위메뉴번호"
                                    v-model="forms.supMenuNo"
                                    :disabled="false"
                                    :eRequired="false"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="이전메뉴번호"
                                    v-model="forms.oldMenuNo"
                                    :disabled="false"
                                    :eRequired="false"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="프로그램화면ID"
                                    v-model="forms.screenId"
                                    :disabled="false"
                                    :eRequired="false"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="엑셀메뉴ID"
                                    v-model="forms.excelMenuId"
                                    :disabled="false"
                                    :eRequired="true"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="엑셀순번"
                                    v-model="forms.excelSeq"
                                    :disabled="false"
                                    :eRequired="true"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="엑셀URL"
                                    v-model="forms.url"
                                    :disabled="false"
                                    :eRequired="false"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="개인정보여부"
                                    v-model="forms.privacyYn"
                                    :disabled="false"
                                    :eRequired="false"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="엑셀컬럼인덱스"
                                    v-model="forms.excelColIdx"
                                    :disabled="false"
                                    :eRequired="false"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="JavaVo"
                                    v-model="forms.vo"
                                    :disabled="false"
                                    :eRequired="false"
                                    placeholder=""
                                ></TCComInput>
                            </div>
                        </div>
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <div class="right">
                            <!-- 등록버튼 -->
                            <TCComButton
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onSave"
                                >저장</TCComButton
                            >
                            <TCComButton
                                :eLarge="true"
                                eClass="btn_ty02"
                                @click="onClose"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton>
                        </div>
                    </div>

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >

                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
// import moment from 'moment'
//====================1차메뉴명====================
import api from '@/api/biz/bas/adm/basAdmTcIpAplyMenuMgmt'
//====================//1차메뉴명====================
import _ from 'lodash'
export default {
    name: 'BasAdmTcIpNewPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
    },
    data() {
        return {
            gridObj: {},
            gridData: {},
            gridHeaderObj: {},
            objAuth: {},
            forms: {
                menuNo: '',
                menuNm: '',
                menuLvlCd: '',
                menuUrl: '',
                supMenuNo: '',
                oldMenuNo: '',
                screenId: '',
                excelMenuId: '',
                excelSeq: '',
                url: '',
                privacyYn: '',
                excelColIdx: '',
                vo: '',
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.params.menuUrl =
                    value['menuUrl'] == undefined ? '' : value['menuUrl']
                this.excelSeq =
                    value['excelSeq'] == undefined ? '' : value['excelSeq']
                this.url = value['url'] == undefined ? '' : value['url']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {},
    mounted() {},
    methods: {
        onClose() {
            this.activeOpen = false
        },
        onConfirm() {},
        /*
        onClick() {
            console.log('forms', this.forms)
        },
        */

        // 신규등록/수정 이벤트
        onSave() {
            // if (!this.onValidate()) {
            //     return
            // }
            // this.params.psYn = this.ckParam.psYn
            // this.params.mblYn = this.ckParam.mblYn
            let params = {
                menuNo: this.forms.menuNo,
                menuNm: this.forms.menuNm,
                menuLvlCd: this.forms.menuLvlCd,
                menuUrl: this.forms.menuUrl,
                supMenuNo: this.forms.supMenuNo,
                oldMenuNo: Number(this.forms.oldMenuNo),
                screenId: this.forms.screenId,
                excelMenuId: Number(this.forms.excelMenuId),
                excelSeq: Number(this.forms.excelSeq),
                url: this.forms.url,
                privacyYn: this.forms.privacyYn,
                excelColIdx: Number(this.forms.excelColIdx),
                vo: this.forms.vo,
                __rowState: 'created',
            }

            // //부모 차수 저장.
            // //3차코드존재 -> 부모3차 ,2차코드존재 -> 부모2차 ,1차코드존재 -> 불가
            // if (this.forms.menuSupNo3) {
            //     this.forms.menuLvlCd = '3'
            //     this.forms.supMenuNo = this.forms.menuNo3
            // } else {
            //     this.forms.menuLvlCd = '2'
            //     this.forms.supMenuNo = this.forms.menuNo2
            // }
            // //저장되는 메뉴는 무조건 4차메뉴
            // this.forms.menuLvlCd = '4'
            // this.forms.__rowState = 'created'
            // let params = {}
            // params = this.forms
            // //console.log('=====>저장:', params)
            api.saveTcIp(params).then((resultData) => {
                console.log('resultData::', resultData)

                //     if ('Y' == resultData.menuNoSameYn) {
                //         this.showTcComAlert('동일한 4차메뉴NO가 존재합니다.', {
                //             header: '확인',
                //             size: '500',
                //             confirmLabel: 'OK',
                //         })
                //     } else if ('Y' == resultData.menuUrlSameYn) {
                //         this.showTcComAlert('동일한 4차메뉴URL이 존재합니다.', {
                //             header: '확인',
                //             size: '500',
                //             confirmLabel: 'OK',
                //         })
                //     } else {
                //         this.$emit('confirm', resultData)
                //         this.onClose()
                //     }

                //     //
            })
        },

        onValidate() {
            if (_.isEmpty(this.forms.menuNm)) {
                this.showTcComAlert('4차 메뉴명을 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.forms.menuNm)) {
                this.showTcComAlert('4차 메뉴NO를 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.forms.menuNm)) {
                this.showTcComAlert('4차 메뉴URL을 입력해주세요.')
                return false
            }

            if (_.isEmpty(this.forms.menuNm)) {
                this.showTcComAlert('SORT 을 입력해주세요.')
                return false
            }

            return true
        },
    },
}
</script>
