<!-----------------------------------------------
 * 업무그룹명: 분실,도난단말기 관리현황
 * 서브업무명: 분실,도난단말기 상태해제
 * 설명: 분실,도난단말기 상태해제 업데이트한다.
 * 작성자: P179234
 * 작성일: 2022.06.23
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">분실,도난단말기 상태해제</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="처리일"
                                    calType="D"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.opDt"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :codeVal.sync="reqParam.orgCd"
                                    :disabledAfter="true"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.orgNm"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="reqParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="reqParam.dealcoNm"
                                    :codeVal.sync="reqParam.dealcoCd"
                                    labelName="보유처"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onDealcoEnterKey"
                                    @appendIconClick="onDealcoIconClick"
                                    @input="onDealcoInput"
                                />
                                <BasBcoDealcosPop
                                    v-if="showBasBcoDealcos"
                                    :parentParam="searchForm"
                                    :rows="resultDealcoRows"
                                    :dialogShow.sync="showBasBcoDealcos"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                        </div>
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridLossRobberyProdMgmtRlseHeader"
                                ref="gridLossRobberyProdMgmtRlseHeader"
                                gridTitle="분실,도난단말기 목록"
                                :gridObj="gridObj"
                                :isPageRows="true"
                                :isExceldown="true"
                                :isNextPage="false"
                                :isPageCnt="true"
                                @excelDownBtn="onClickDownload"
                            />
                            <TCRealGrid
                                id="gridLossRobberyProdMgmtRlse"
                                ref="gridLossRobberyProdMgmtRlse"
                                :fields="gridSet.fields"
                                :columns="gridSet.columns"
                                :styles="gridStyle"
                            />
                            <TCComPaging
                                :totalPage="gridData.totalPage"
                                :apiFunc="getDisBeqLossRobberyProdCancel"
                                :gridObj="gridObj"
                            />
                        </div>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="disBeqLossRobberyProdCanceling"
                            >상태해제</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 제어
 * 2 콜백 서비스 아이디
 * 2 리스크기기 해제정보 체크
------------------------------------------------>
<script>
import { CommonGrid, CommonUtil } from '@/utils'
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
import disBeqLossRobberyProdApi from '@/api/biz/dis/beq/disBeqLossRobberyProdMgmt.js'
import { GRID_HEADER } from '@/const/grid/dis/beq/disBeqLossRobberyProdMgmtHeader.js'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

import { SacCommon } from '@/views/biz/sac/js'
import attachedFileApi from '@/api/common/attachedFile'

//====================내부거래처-권한조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================

export default {
    name: 'DisBeqLossRobberyProdMgmtRlse',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
    },
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        lossRobberyProd: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
                this.$emit('update:addBadProd', value)
            },
        },
    },
    data() {
        return {
            objAuth: {},
            indicatorOpt: { sort: 'ASC' },
            gridObj: {},
            gridHeaderObj: {},
            gridData: this.gridSetData(),
            gridSet: GRID_HEADER,
            gridStyle: {
                height: '300px',
            },
            rowCnt: 15,
            searchForms: {},
            reqParam: this.lossRobberyProd,
            showBcoOrgAgencys: false,
            showBcoAuthOrgTrees: false,
            //====================내부거래처-권한조직====================
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: '', //거래처그룹코드
                dealcoClCd1: '', //거래처구분코드
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================
        }
    },
    mounted() {
        this.setGrid()
        this.search()
    },
    methods: {
        /* 그리드 설정 */
        setGrid() {
            console.log('popup params===========', this.lossRobberyProd)
            this.gridObj = this.$refs.gridLossRobberyProdMgmtRlse
            this.gridHeaderObj = this.$refs.gridLossRobberyProdMgmtRlseHeader
            this.gridObj.setGridState(true, false, true)
            this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
            this.gridObj.setRows({})

            this.reqParam.opDt = SacCommon.getToday()
        },
        gridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        gridAddPageBtn() {
            this.gridData = this.gridHeaderObj.setAddPage(this.gridData)
        },
        btnClick() {
            console.log('click')
        },
        /* 분실,도난단말기 상태해제 대상 일괄목록 검색 */
        async search() {
            this.gridData.totalPage = 0
            this.searchForms = { ...this.reqParam }
            this.searchForms.pageSize = this.rowCnt
            this.searchForms.pageNum = 1
            this.getDisBeqLossRobberyProdCancel(this.searchForms.pageNum)
        },
        /* 분실,도난단말기 상태해제 대상 일괄목록 조회 - 페이징호출 */
        async getDisBeqLossRobberyProdCancel(page) {
            this.searchForms.pageNum = page
            await disBeqLossRobberyProdApi
                .getDisBeqLossRobberyProdCancel(this.searchForms)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator(
                            res.pagingDto,
                            this.indicatorOpt
                        )
                        this.gridData = this.gridSetData()
                        this.gridData.totalPage = res.pagingDto.totalPageCnt
                        this.gridHeaderObj.setPageCount(res.pagingDto)
                    }
                    // else {
                    //     this.showTcComAlert(
                    //         '상태해제 대상 일괄목록 정보를 불러오지 못했습니다.'
                    //     )
                    // }
                })
        },
        /* 상태해제 */
        async disBeqLossRobberyProdCanceling() {
            console.log('상태해제버튼')
            let list = []
            list = await Promise.all(this.getRows(this.gridObj))

            // const checked = this.check(list)
            // if (!checked) return
            const formData = { rowDatas: list }
            if (list.length === 0) {
                setTimeout(() => {
                    this.showTcComAlert('상태해제 대상이 없습니다.')
                }, 2000)
            } else {
                this.showTcComConfirm('해제하시겠습니까?').then(
                    async (confirm) => {
                        if (confirm) {
                            await disBeqLossRobberyProdApi
                                .disBeqLossRobberyProdIniting(formData)
                                .then(() => {
                                    this.$emit('confirm', true)
                                    this.activeOpen = false
                                })
                        }
                    }
                )
            }
        },
        /* 상태해제 - 수정한 열 정보 가져오기 */
        getRows(grid) {
            let jsonData = []
            grid.gridView.commit()
            const checkRows = grid.gridView.getCheckedRows(true)
            checkRows.forEach((row) => {
                const data = grid.dataProvider.getJsonRow(row)
                jsonData.push(data)
            })
            return [...jsonData] // 테스트용
        },
        trans(inputData) {
            let datas = []
            inputData.forEach((data) => {
                data.clsDt = this.reqParam.opDt
                data.rmks = this.reqParam.rmks
                datas.push(data)
            })
        },
        /* 상태해제 - 조건 체크 */
        check(data) {
            // 처리일;저장

            // 마감월 체크

            const returnData =
                data.rmks === ''
                    ? this.showTcComAlert('해제사유 정보가 없습니다.')
                    : data

            if (_.isEmpty(returnData)) return false

            if (returnData.opDt < this.prod.opDt) {
                this.showTcComAlert(
                    '불량기기 해제 등록일자는 불량기기 해제 등록일자 ' +
                        this.prod.opDt +
                        ' 보다 과거로 과거로 등록할 수 없습니다.'
                )
            } else {
                return returnData
            }
        },
        /* 내부조직팝업 */
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.reqParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        /* 내부조직팝업 - Icon 이벤트 처리 */
        onAuthOrgTreeIconClick() {
            this.resultAuthOrgTreeRows = []
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        /* 내부조직팝업 - TextField 엔터키 이벤트 처리 */
        onAuthOrgTreeEnterKey() {
            this.resultAuthOrgTreeRows = []
            // if (_.isEmpty(this.reqParam.orgNm)) {
            //     this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
            //     return
            // }
            this.getAuthOrgTreeList()
        },
        /* 내부조직팝업 - TextField Input 이벤트 이벤트 처리 */
        onAuthOrgTreeInput() {
            this.reqParam.orgCd = ''
        },
        /* 내부조직팝업 - 팝업 리턴 이벤트 이벤트 처리 */
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
        },
        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            this.searchForm.dealcoCd = this.reqParam.dealcoCd
            this.searchForm.dealcoNm = this.reqParam.dealcoNm
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.dealcoNm)) {
                this.searchForm.basDay = CommonUtil.replaceDash(
                    this.reqParam.opDt
                )
                this.getDealcosList()
                // this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-권한조직명 입력해주세요.'
                return
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.reqParam.dealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.reqParam.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================
        /* 엑셀다운로드 */
        onClickDownload() {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/beq/disBeqLossRobberyProdCanceledExcelDown',
                this.searchForms
            )
        },
        closeBtn() {
            this.activeOpen = false
        },
        /* 현재일자 확인(yyyy-mm-dd)*/
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
    },
}
</script>
