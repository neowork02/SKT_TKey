import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'accDealcoCd', // 정산처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accMtch', // 정산상계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'addsCmmsAmt', // 판매수수료_추가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'adjtCmmsAmt', //판매수수료_조정
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'agencyCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm', // 대리점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agrmtPrd', // 약정기간
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asmptPrfitLs', // 추정손익_총액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'asmptPrfitUamt', // 추정손익_객단가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cellProcDt ', // T개통일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cellProdNm', // T단말기모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cellSaleTypNm', // T판매유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cmmsAddSub', // 수수료가감
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cmmsTotAmt', // 판매수수료_소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'custNm', // 고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNo', // 고객번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClNm', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eventAmt', // 기타_스마트팩
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gnrlCmmsAmt', // 판매수수료_일반
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gnrlPhoneSaleQty', // 판매수량_일반전화
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gnrlSaleChgSeq ', // 판매변경순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleNo', // 판매관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'intPhoneSaleQty', // 판매수량_인터넷전화
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'iptvSaleQty', // 판매수량_IPTV
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ldntwCmmsAmt', // 대형유통망수수료
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mktChrgrUserId', // 마케터
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktChrgrUserNm', // 마케터
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mnpYn', // 번호이동여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'motiPrMnyAmt', // 모티인센티브
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'opUserId', // 처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opUserNm', // 처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd2', // 사업담당코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd3', // 영업팀코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd4', // 영업파트코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm2', // 사업담당명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm3', // 영업팀명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm4', // 영업센터명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prAmt', // 기타_판촉물
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'procStCd', // 개통상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procStNm', // 개통상태명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm', // 사업상세
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'psnmPrMnyAmt', // PS&M인센티브_소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmt1', // PS&M인센티브_본사
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmt2', // PS&M인센티브_본부
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'psnmPrMnyAmt3', // PS&M인센티브_팀
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rewardAmt1', // 성과보상A
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rewardAmt2', // 성과보상B
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleChgDtm', // 매출일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgHstClNm', // 판매이력구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgrUserId', // 판매자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChrgrUserNm', // 판매자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd', // 판매처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoNm', // 판매처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtm', // 개통일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleStCd', // 판매상태코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleStNm', // 판매상태명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleTypNm', //판매유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'skbPrMnyAmt', // 인센티브_SKB
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktChnlCd', // 채널코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktPrMnyAmt', // 인센티브_SKT
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktSubCd', // 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubNm', // 매장명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sumPrMnyAmt', // 인센티브_소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'suplCmmsAmt', // 판매수수료_부가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'suplPolSvcs', // 부가상품
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm', // 요금제
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcs', // 부가서비스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcDtm', // 최초접수일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', // 결합서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tbFamilyNm', // TB결합형태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'totPrMnyAmt', // 인센티브_소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totSaleQty', // 판매수량_소계
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'trgtSaleCmmsAmt', // 판매수수료_추정
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'wireFastSaleQty', // 판매수량_초고속
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'wireSvcMgmtNum', // 유선서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgLvl', // 조직레벨
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgNm2',
            fieldName: 'orgNm2',
            type: 'data',
            width: '150',
            header: '사업담당',
        },
        {
            name: 'orgNm3',
            fieldName: 'orgNm3',
            type: 'data',
            width: '150',
            header: '영업팀',
        },
        {
            name: 'orgNm4',
            fieldName: 'orgNm4',
            type: 'data',
            width: '150',
            header: '영업파트',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            width: '100',
            header: '정산처',
            visible: false,
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            width: '100',
            header: '정산처명',
            visible: false,
        },
        {
            name: 'dealcoClNm',
            fieldName: 'dealcoClNm',
            type: 'data',
            width: '100',
            header: '거래처구분',
            visible: false,
        },

        // 판매수량 - 초고속, 인터넷전화, 일반전화, IPTV, 소계
        {
            name: 'wireFastSaleQty',
            fieldName: 'wireFastSaleQty',
            type: 'data',
            width: '150',
            header: '초고속',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'intPhoneSaleQty',
            fieldName: 'intPhoneSaleQty',
            type: 'data',
            width: '150',
            header: '인터넷전화',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'gnrlPhoneSaleQty',
            fieldName: 'gnrlPhoneSaleQty',
            type: 'data',
            width: '150',
            header: '일반전화',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'iptvSaleQty',
            fieldName: 'iptvSaleQty',
            type: 'data',
            width: '150',
            header: 'IPTV',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'totSaleQty',
            fieldName: 'totSaleQty',
            type: 'data',
            width: '150',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 인센티브 - SKT, SKB, 소계
        {
            name: 'sktPrMnyAmt',
            fieldName: 'sktPrMnyAmt',
            type: 'data',
            width: '150',
            header: 'SKT',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'skbPrMnyAmt',
            fieldName: 'skbPrMnyAmt',
            type: 'data',
            width: '150',
            header: 'SKB',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'sumPrMnyAmt',
            fieldName: 'sumPrMnyAmt',
            type: 'data',
            width: '150',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // PS&M인센티브 - 본사, 본부, 팀, 소계
        {
            name: 'psnmPrMnyAmt1',
            fieldName: 'psnmPrMnyAmt1',
            type: 'data',
            width: '150',
            header: '본사',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt2',
            fieldName: 'psnmPrMnyAmt2',
            type: 'data',
            width: '150',
            header: '본부',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt3',
            fieldName: 'psnmPrMnyAmt3',
            type: 'data',
            width: '150',
            header: '팀',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'psnmPrMnyAmt',
            fieldName: 'psnmPrMnyAmt',
            type: 'data',
            width: '150',
            header: '소계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 판매수수료 - 일반, 추가, 부가, 조정, 추정, 소계
        {
            name: 'gnrlCmmsAmt',
            fieldName: 'gnrlCmmsAmt',
            type: 'data',
            width: '150',
            header: '일반',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'addsCmmsAmt',
            fieldName: 'addsCmmsAmt',
            type: 'data',
            width: '150',
            header: '추가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'suplCmmsAmt',
            fieldName: 'suplCmmsAmt',
            type: 'data',
            width: '150',
            header: '부가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'adjtCmmsAmt',
            fieldName: 'adjtCmmsAmt',
            type: 'data',
            width: '150',
            header: '조정',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'trgtSaleCmmsAmt',
            fieldName: 'trgtSaleCmmsAmt',
            type: 'data',
            width: '150',
            header: '추정',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'cmmsTotAmt',
            fieldName: 'cmmsTotAmt',
            type: 'data',
            width: '150',
            header: '소계',
            numberFormat: '#,##0',
        },
        {
            name: 'cmmsAddSub',
            fieldName: 'cmmsAddSub',
            type: 'data',
            width: '150',
            header: '수수료가감',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'accMtch',
            fieldName: 'accMtch',
            type: 'data',
            width: '150',
            header: '정산상계',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'ldntwCmmsAmt',
            fieldName: 'ldntwCmmsAmt',
            type: 'data',
            width: '150',
            header: '대형유통망수수료',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 기타 - 스마트팩, 성과보상A, 성과보상B, 모티인센티브, 판촉물
        {
            name: 'eventAmt',
            fieldName: 'eventAmt',
            type: 'data',
            width: '150',
            header: '스마트팩',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'rewardAmt1',
            fieldName: 'rewardAmt1',
            type: 'data',
            width: '150',
            header: '성과보상A',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'rewardAmt2',
            fieldName: 'rewardAmt2',
            type: 'data',
            width: '150',
            header: '성과보상B',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'motiPrMnyAmt',
            fieldName: 'motiPrMnyAmt',
            type: 'data',
            width: '150',
            header: '모티인센티브',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'prAmt',
            fieldName: 'prAmt',
            type: 'data',
            width: '150',
            header: '판촉물',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        // 추정손익 - 총액, 객단가
        {
            name: 'asmptPrfitLs',
            fieldName: 'asmptPrfitLs',
            type: 'data',
            width: '150',
            header: '총액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'asmptPrfitUamt',
            fieldName: 'asmptPrfitUamt',
            type: 'data',
            width: '150',
            header: '객단가',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
    ],
    layout: [
        'orgNm2',
        'orgNm3',
        'orgNm4',
        'accDealcoCd',
        'accDealcoNm',
        'dealcoClNm',
        {
            name: '판매수량',
            direction: 'horizontal',
            items: [
                'wireFastSaleQty',
                'intPhoneSaleQty',
                'gnrlPhoneSaleQty',
                'iptvSaleQty',
                'totSaleQty',
            ],
        },
        {
            name: '인센티브',
            direction: 'horizontal',
            items: ['sktPrMnyAmt', 'skbPrMnyAmt', 'sumPrMnyAmt'],
        },
        {
            name: 'PS&M인센티브',
            direction: 'horizontal',
            items: [
                'psnmPrMnyAmt1',
                'psnmPrMnyAmt2',
                'psnmPrMnyAmt3',
                'psnmPrMnyAmt',
            ],
        },
        {
            name: '판매수수료',
            direction: 'horizontal',
            items: [
                'gnrlCmmsAmt',
                'addsCmmsAmt',
                'suplCmmsAmt',
                'adjtCmmsAmt',
                'trgtSaleCmmsAmt',
                'cmmsTotAmt',
            ],
        },
        'cmmsAddSub',
        'accMtch',
        'ldntwCmmsAmt',
        {
            name: '기타',
            direction: 'horizontal',
            items: [
                'eventAmt',
                'rewardAmt1',
                'rewardAmt2',
                'motiPrMnyAmt',
                'prAmt',
            ],
        },
        {
            name: '추정손익',
            direction: 'horizontal',
            items: ['asmptPrfitLs', 'asmptPrfitUamt'],
        },
    ],
}
