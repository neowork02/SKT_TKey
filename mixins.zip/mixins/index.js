import { mapGetters } from 'vuex'

export default {
    name: 'CommonMixin',
    data() {
        return {}
    },
    computed: {
        ...mapGetters(['CONSTANTS']),
        // Get MenuInfo
        ...mapGetters('menu', ['menuInfo', 'currentMenuInfo']),
        // Get LoginInfo
        ...mapGetters('login', ['userInfo', 'orgInfo', 'authInfo']),
        // Get objAuthList
        ...mapGetters('auth', ['objAuthList']),
        // Get RMKS
        ...mapGetters('rmks', ['customerInfoWord', 'forbiddenWord']),
    },
    methods: {
        showTcComAlert(message, options) {
            this.$store.dispatch('showTcComAlert', { message, options })
        },
        async showTcComConfirm(message, options) {
            this.$store.dispatch('showTcComConfirm', { message, options })
            return new Promise((resolve) => {
                this.$store.dispatch('setTcComConfirmResolve', resolve)
            })
        },
        showTcComSnackbar(message, options) {
            this.$store.dispatch('showTcComSnackbar', { message, options })
        },
        //=========================================================
        // 로그인 관련
        // 권한정보
        setAuthInfo(authInfo) {
            this.$store.dispatch('login/setAuthInfo', authInfo)
        },
        // 메뉴정보
        setMenuInfo(menuInfo) {
            this.$store.dispatch('menu/setMenuInfo', menuInfo)
        },
        // 조직정보
        setOrgInfo(orgInfo) {
            this.$store.dispatch('login/setOrgInfo', orgInfo)
        },
        // 사용자정보
        setUserInfo(userInfo) {
            this.$store.dispatch('login/setUserInfo', userInfo)
        },
        // 속성권한목록
        setObjAuthList(objAuthList) {
            this.$store.dispatch('auth/setObjAuthList', objAuthList)
        },
        // 고객정보단어
        setCustomerInfoWord(customerInfoWord) {
            this.$store.dispatch('rmks/setCustomerInfoWord', customerInfoWord)
        },
        // 금지단어
        setForbiddenWord(forbiddenWord) {
            this.$store.dispatch('rmks/setForbiddenWord', forbiddenWord)
        },
        // 현재 메뉴정보
        setCurrentMenuInfo(currentMenuInfo) {
            this.$store.dispatch('menu/setCurrentMenuInfo', currentMenuInfo)
        },
        //로그인정보, 메뉴정보 초기화
        initLoginInfo(typ = 'all') {
            this.setAuthInfo('')
            this.setMenuInfo('')
            this.setOrgInfo('')
            this.setUserInfo('')
            this.setCurrentMenuInfo('')
            if (typ === 'all') {
                this.setObjAuthList('')
                this.setCustomerInfoWord('')
                this.setForbiddenWord('')
            }
        },

        //=========================================================
    },
}
