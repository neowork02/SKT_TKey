<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">게시판 등록</p>
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap mt20">
                        <div class="searchform">
                            <div class="formitem div3_3">
                                <div class="arrayType">
                                    <div class="formitem div3">
                                        <TCComInput
                                            v-model="regPopUp.bbsTypeNm"
                                            labelName="게시판구분"
                                            :disabled="disableEl"
                                            v-show="showPol"
                                        />

                                        <TCComComboBox
                                            v-model="regPopUp.bbsTypeCd"
                                            blankItemText="선택해주세요"
                                            blankItemValue=""
                                            labelName="게시판구분"
                                            :itemList="itemList1"
                                            v-show="showPolchang"
                                            :eRequired="true"
                                        ></TCComComboBox>
                                    </div>

                                    <div class="col0">
                                        <TCComCheckBox
                                            v-model="ckParam.noticeYn"
                                            @click="onclick"
                                            :itemList="[
                                                {
                                                    commCdVal: 'Y',
                                                    commCdValNm: '',
                                                },
                                            ]"
                                        />
                                    </div>

                                    <div class="formitem div3">
                                        <div class="col0">
                                            <span class="basicTxt mgl-5">
                                                <span class="color-red"
                                                    >공지글</span
                                                >
                                                (체크하면 리스트 최상단에 나오게
                                                됩니다.)</span
                                            >
                                        </div>
                                    </div>

                                    <div class="col0">
                                        <TCComCheckBox
                                            :objAuth="objAuth"
                                            v-model="ckParam.smsSendYn"
                                            :itemList="[
                                                {
                                                    commCdVal: 'Y',
                                                    commCdValNm: '',
                                                },
                                            ]"
                                        />
                                    </div>
                                    <div class="formitem div3">
                                        <div class="col0">
                                            <span class="basicTxt mgl-5">
                                                <span class="color-red"
                                                    >문자전송</span
                                                >
                                                (체크시 대상아이디
                                                문자전송)</span
                                            >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div1">
                                <div class="arrayType">
                                    <div class="formitem div3">
                                        <TCComInputSearchText
                                            v-model="regPopUp.orgNm"
                                            :codeVal.sync="regPopUp.orgCd"
                                            labelName=" 대상조직"
                                            placeholder="선택해주세요"
                                            :disabledAfter="true"
                                            :objAuth="objAuth"
                                            @enterKey="onAuthOrgTreeEnterKey"
                                            @appendIconClick="
                                                onAuthOrgTreeIconClick
                                            "
                                            @input="onAuthOrgTreeInput"
                                            :eRequired="true"
                                        />
                                        <BasBcoAuthOrgTreesPopup
                                            v-if="showBcoAuthOrgTrees"
                                            :parentParam="regPopUp"
                                            :rows="resultAuthOrgTreeRows"
                                            :dialogShow.sync="
                                                showBcoAuthOrgTrees
                                            "
                                            @confirm="onAuthOrgTreeReturnData"
                                        />
                                    </div>
                                    <div class="formitem div4">
                                        <TCComMultiComboBox
                                            labelName="권한그룹"
                                            v-model="ckParam.userGrpNm"
                                            :codeVal.sync="ckParam.userGrpCd"
                                            :itemList="userGrpNmList"
                                            :objAuth="objAuth"
                                            itemText="userGrpNm"
                                            itemValue="userGrpCd"
                                            label="미선택시 전체"
                                            @input="onIdClear"
                                        ></TCComMultiComboBox>
                                    </div>
                                    <div class="formitem div4">
                                        <TCComMultiComboBox
                                            labelName="정책그룹"
                                            v-model="ckParam.grpNm"
                                            :codeVal.sync="ckParam.grpNo"
                                            :objAuth="objAuth"
                                            :itemList="grpCdList"
                                            itemText="grpNm"
                                            itemValue="grpNo"
                                            label="미선택시 전체"
                                            @input="onIdClear"
                                        ></TCComMultiComboBox>
                                    </div>

                                    <!-- <div class="colTxtarea">
                                        <TCComTextArea
                                            v-model="ckParam.dealcoNm"
                                            labelName="대상조직"
                                            class="boxtype"
                                            v-show="showStore"
                                            :rows="5"
                                            :disabled="disableEl"
                                        />
                                    </div>
                                    <div class="col0 colbtn">
                                        <em>
                                            <TCComButton
                                                :Vuetify="false"
                                                eClass="btn_xs btn_ty05"
                                                v-show="showStorebtn"
                                                labelName="선택"
                                                @click="newBoard"
                                            />
                                        </em>
                                    </div>
                                    <StorePopup
                                        v-if="showBbsStoreMgmt === true"
                                        :parentParam="regPopUp"
                                        ref="popup"
                                        :dialogShow.sync="showBbsStoreMgmt"
                                        @confirm="onStroeReturnData"
                                    /> -->
                                </div>
                            </div>
                            <!-- </div> -->
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <div class="arrayType">
                                    <div class="colTxtarea">
                                        <TCComTextArea
                                            v-model="ckParam.userNm"
                                            labelName="대상아이디"
                                            class="boxtype"
                                            v-show="showUser"
                                            :rows="4"
                                            :disabled="disableEl"
                                        />
                                    </div>
                                    <div class="col0 colbtn">
                                        <em>
                                            <TCComButton
                                                :Vuetify="false"
                                                @click="userNewBoard"
                                                v-show="showUserbtn"
                                                eClass="btn_xs btn_ty05"
                                                labelName="선택"
                                            />
                                        </em>
                                        <em>
                                            <TCComButton
                                                :Vuetify="false"
                                                eClass="btn_xs btn_ty05"
                                                @click="allCheck"
                                                v-show="showAllUserbtn"
                                                labelName="전체"
                                            />
                                        </em>
                                    </div>
                                    <UserPopup
                                        v-if="showBbsUserMgmt === true"
                                        :parentParam="regPopUp"
                                        ref="popup"
                                        :dialogShow.sync="showBbsUserMgmt"
                                        @confirm="onUserReturnData"
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="regPopUp.textTitle"
                                    labelName="제목"
                                    :eRequired="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="regPopUp.bbsDtl"
                                    labelName="내용"
                                    class="boxtype"
                                    :rows="13"
                                    :eRequired="true"
                                />
                            </div>
                        </div>
                    </div>
                    <AttachedBoardFileAdd
                        ref="attachedFileAdd"
                        :fileList="fileSearchList"
                        @file-change="onFileAddChange"
                        gridHeight="40px"
                    ></AttachedBoardFileAdd>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <div class="right">
                            <TCComButton
                                eClass="btn_ty02_point"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onConfirm"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :objAuth="objAuth"
                                :eLarge="true"
                                @click="onClose"
                                >닫기</TCComButton
                            >
                        </div>
                    </div>

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<style lang="scss" scoped>
// .btn_area_bottom::v-deep {
//     display: block;
//     float: none;
//     overflow: hidden;

//     .left {
//         float: left;
//     }

//     .right {
//         float: right;
//     }
// }
// .btn_dschk {
//     position: absolute;
//     top: 30px;
// }
// .btn_dschk p {
//     display: inline-block;
// }
</style>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import AttachedBoardFileAdd from '@/components/common/AttachedBoardFileAdd'
import { BAS_BBS_REG_HEADER } from '@/const/grid/bas/bbs/basBbsMgmtHeader'
import basBbsRegMgmtApi from '@/api/biz/bas/bbs/basBbsMgmt'
// import StorePopup from '@/views/biz/bas/bbs/BasBbsStorePopMgmt'
import UserPopup from '@/views/biz/bas/bbs/BasBbsUserPopMgmt'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'

//====================//내부조직팝업(권한)팝업====================
//====================정책그룹====================
import polIctApi from '@/api/biz/bas/bbs/basBbsMgmt'
//====================//정책그룹====================
//====================권한그룹====================
import userGrpApi from '@/api/biz/bas/bbs/basBbsMgmt'
//====================//권한그룹====================

import _ from 'lodash'

export default {
    name: 'BasBbsRegMgmt',
    mixins: [CommonMixin],
    components: { UserPopup, AttachedBoardFileAdd, BasBcoAuthOrgTreesPopup },
    props: {
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: BAS_BBS_REG_HEADER,
            gridStyle: {
                height: '100px', //그리드 높이 조절
            },
            gridObj: {},
            gridHeaderbj: {},
            checkbox: true,
            objAuth: {},
            //  파일첨부
            userGrpNmList: [],
            grpCdList: [],
            admAppendFileList: [],
            formData: new FormData(),
            fileSearchList: [],
            disableEl: true,
            bbsTypeCd: '',
            inputValue2: '20',
            regPopUp: {
                noticeYn: '',
                smsSendYn: '',
                bbsTypeCd: '',
                bbsTypeNm: '',
                textTitle: '',
                bbsDtl: '',
                dealcoNm: '', // 매장명
                dealcoCd: '', // 매장코드
                userNm: '', // 대상사용자ID
                userId: '', // 사용자ID
                docId: '',
                insUserNm: '',
                screenId: 'BASBBS00001',
                grpNm: '', //정책그룹명
                grpNo: '', //정책그룹번호
                userGrpNm: '', //권한그룹
                userGrpCd: '', //권한코드
                orgCd: '',
                orgNm: '',
                orgLvl: '',
            },
            ckParam: {
                noticeYn: [],
                smsSendYn: [],
                userNm: '',
            },
            showNext: false,
            showBbsStoreMgmt: false,
            showBbsUserMgmt: false,
            showAllUserbtn: true,
            showStorebtn: false,
            showUserbtn: true,
            showStore: false,
            showUser: true,
            showPol: true,
            showPolchang: false,
            searchParam: {
                deal_status_list: '', // 거래상태리스트
                sknDlvDealCoCd: '',
                dealcoGrpCd: '',
                acntNo: '',
                dealcoClCd1: '',
                dealcoClCd2: '',
                dealcoNm: '',
                dealcoCd: '',
                bizNo: '',
                sktChnlCd: '',
                accDealcoCd: '',
                repUserNm: '',
                searchGb: '',
                dtmFrom: '',
                dtmTo: '',
                catId: '',
                dealStatus: [],
                dealEndYn: '',
                lastMrtg: [],
                searchTarget: '',
                spClsBizClCd: '',
                maDirectYn: '',
                orgCd: '',
                orgLvl: '',
                srchValue: '',
            },
            //====================//공통기능==================
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부

            headerText: '',
            //====================//내부조직팝업(권한)팝업관련==================
        }
    },
    mounted() {
        /*
        if (this.$parent.guideTab == '0') {
            this.regPopUp.bbsTypeCd = '대리점공지사항'
        } else if (this.$parent.guideTab == '1') {
            */

        /*
        } else if (this.$parent.guideTab == '2') {
            this.regPopUp.bbsTypeCd = '시스템공지사항'
        } else if (this.$parent.guideTab == '3') {
            this.regPopUp.bbsTypeCd = '기능개선요청게시판'
        }
        */

        if (this.$parent.guideTab == 0) {
            this.regPopUp.bbsTypeNm = '대리점공지사항'
            this.regPopUp.bbsTypeCd = 'N'
        }
        if (this.$parent.guideTab == 1) {
            this.regPopUp.bbsTypeNm = '정책게시판'
        }
        if (this.$parent.guideTab == 2) {
            this.regPopUp.bbsTypeNm = '시스템공지사항'
            this.regPopUp.bbsTypeCd = 'A'
        }
        if (this.$parent.guideTab == 3) {
            this.regPopUp.bbsTypeNm = '기능개선요청게시판'
            this.regPopUp.bbsTypeCd = 'I'
        }

        this.showPol = false
        this.showPolchang = true

        this.ckParam.userNm = '전체'
        // if (this.regPopUp.bbsTypeCd == '대리점공지사항') {
        //     // this.showAllUserbtn = false
        //     this.showStorebtn = false
        //     this.showUserbtn = false
        //     this.showStore = false
        //     this.showUser = false
        // } else {
        //     this.showAllUserbtn = true
        //     this.showStorebtn = true
        //     this.showUserbtn = true
        //     this.showStore = true
        //     this.showUser = true
        // }
        // 정책그룹 호출
        polIctApi.getCommCodeList(this.regPopUp).then((resultData) => {
            let groupArr = [
                /*{ grpNo: '', grpNm: '전체' }*/
            ] //정책그룹
            resultData.forEach((v) => {
                groupArr.push(v)
            })
            this.grpCdList = groupArr
        })

        // 권한그룹 호출
        userGrpApi.getUserGrpList(this.regPopUp).then((result) => {
            let userGrpArr = [
                /*{ userGrpCd: '', userGrpNm: '전체' } */
            ] //권한그룹
            result.forEach((v) => {
                userGrpArr.push(v)
            })
            this.userGrpNmList = userGrpArr
            if (_.isEmpty(this.userGrpNmList)) {
                this.regPopUp.userGrpCd = _.get(result[0], 'userGrpCd')
                this.regPopUp.userGrpNm = _.get(result[0], 'userGrpNm')
            }
        })

        if (!_.isEmpty(this.userInfo['dealcoCd'])) {
            this.regPopUp['orgCd'] = this.orgInfo['orgCd']
            this.regPopUp['orgNm'] = this.orgInfo['orgNm']
            this.regPopUp['orgLvl'] = this.orgInfo['orgLvl']
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        itemList1() {
            return [
                { commCdVal: '', commCdValNm: '선택해주세요' },
                { commCdVal: 'D', commCdValNm: '도매' },
                { commCdVal: 'S', commCdValNm: '소매' },
                { commCdVal: 'B', commCdValNm: '대형' },
            ]
        },
    },
    methods: {
        onclick: function () {
            //console.log(this.ckParam.noticeYn)
        },
        onClose: function () {
            this.activeOpen = false
        },
        allCheck() {
            this.ckParam.userNm = '전체'
            console.log('전체', this.ckParam.userNm)
        },
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            let stLvl = this.orgInfo.orgLvl
            let lvlCd = ''
            for (let i = stLvl; i <= 3; i++) {
                if (i == 3) {
                    lvlCd += i + ''
                } else {
                    lvlCd += i + ','
                }
            }
            this.regPopUp.sLvlList = lvlCd
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.regPopUp)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.regPopUp.orgCd = _.get(res[0], 'orgCd')
                        this.regPopUp.orgNm = _.get(res[0], 'orgNm')
                        this.regPopUp.orgLevel = _.get(res[0], 'vLevel')
                        this.regPopUp.searchCoClOrgCd = _.get(
                            res[0],
                            'orgCdLvl0'
                        )
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            this.onIdClear()
            let stLvl = this.orgInfo.orgLvl

            let lvlCd = ''
            for (let i = stLvl; i <= 3; i++) {
                if (i == 3) {
                    lvlCd += i + ''
                } else {
                    lvlCd += i + ','
                }
            }

            this.regPopUp.sLvlList = lvlCd
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.regPopUp.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        onAuthOrgTreeEnterKey() {
            this.onIdClear()
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.regPopUp.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return
            }

            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.regPopUp.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            this.regPopUp.orgCd = _.get(returnData, 'orgCd')
            this.regPopUp.orgNm = _.get(returnData, 'orgNm')
            this.regPopUp.orgLvl = _.get(returnData, 'orgLvl')

            console.log('orgCd', this.regPopUp.orgCd)
            console.log('orgNm', this.regPopUp.orgNm)
            console.log('orgLvl', this.regPopUp.orgLvl)
        },
        selectChange(val) {
            if (val == '대리점공지사항') {
                // this.showAllUserbtn = false
                //this.showStorebtn = false
                this.showUserbtn = false
                //this.showStore = false
                this.showUser = false
            } else {
                this.showAllUserbtn = true
                //this.showStorebtn = true
                this.showUserbtn = true
                //this.showStore = true
                this.showUser = true
            }
        },
        async saveBasBbsMgmt() {
            if (this.ckParam.userNm == '전체') {
                this.ckParam.userId = '-1'
            }
            this.regPopUp.noticeYn = String(this.ckParam.noticeYn)
            this.regPopUp.smsSendYn = String(this.ckParam.smsSendYn)
            this.regPopUp.dealcoNm = String(this.ckParam.dealcoNm)
            this.regPopUp.dealcoCd = String(this.ckParam.dealcoCd)
            this.regPopUp.userId = String(this.ckParam.userId)
            this.regPopUp.userNm = String(this.ckParam.userNm)

            //##권한, 정책 셋팅
            let userGrpNm = String(this.ckParam.userGrpNm)
            if (!userGrpNm) {
                userGrpNm = ''
            } else {
                if (',' == userGrpNm.substring(0, 1)) {
                    userGrpNm = userGrpNm.substring(1, userGrpNm.length)
                }

                let spUserGrpNm = userGrpNm.split(',')

                if (5 < spUserGrpNm.length) {
                    this.showTcComAlert(
                        '권한그룹은 최대 5개까지 선택가능합니다. 현재:' +
                            spUserGrpNm.length
                    )
                    return
                }
            }

            let grpNm = String(this.ckParam.grpNm)
            if (!grpNm) {
                grpNm = ''
            } else {
                if (',' == grpNm.substring(0, 1)) {
                    grpNm = grpNm.substring(1, grpNm.length)
                }

                let spGrpNm = grpNm.split(',')

                if (5 < spGrpNm.length) {
                    this.showTcComAlert(
                        '정책그룹은 최대 5개까지 선택가능합니다. 현재:' +
                            spGrpNm.length
                    )
                    return
                }
            }

            if ('undefined' == userGrpNm) {
                userGrpNm = ''
            }
            if ('undefined' == grpNm) {
                grpNm = ''
            }

            this.regPopUp.userGrpNm = userGrpNm
            this.regPopUp.grpNm = grpNm

            this.regPopUp.__rowState = 'created'
            await basBbsRegMgmtApi
                .postBasBbsMgmt(this.regPopUp)
                .then((resultData) => {
                    console.log('resultData', resultData)
                    this.showTcComAlert('저장되었습니다.')
                    this.onClose()
                    this.$emit('confirm', true)
                })
        },
        async newBoard() {
            this.showBbsStoreMgmt = true
        },
        async userNewBoard() {
            if (_.isEmpty(this.regPopUp.bbsTypeCd)) {
                this.showTcComAlert('게시판구분을 선택해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            if (_.isEmpty(this.regPopUp.orgNm)) {
                this.showTcComAlert(' 대상조직을 입력해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            //##권한, 정책 셋팅
            let userGrpNm = String(this.ckParam.userGrpNm)
            if (!userGrpNm) {
                userGrpNm = ''
            } else {
                if (',' == userGrpNm.substring(0, 1)) {
                    userGrpNm = userGrpNm.substring(1, userGrpNm.length)
                }

                let spUserGrpNm = userGrpNm.split(',')

                if (5 < spUserGrpNm.length) {
                    this.showTcComAlert(
                        '권한그룹은 최대 5개까지 선택가능합니다. 현재:' +
                            spUserGrpNm.length
                    )
                    return
                }
            }

            let grpNm = String(this.ckParam.grpNm)
            if (!grpNm) {
                grpNm = ''
            } else {
                if (',' == grpNm.substring(0, 1)) {
                    grpNm = grpNm.substring(1, grpNm.length)
                }

                let spGrpNm = grpNm.split(',')

                if (5 < spGrpNm.length) {
                    this.showTcComAlert(
                        '정책그룹은 최대 5개까지 선택가능합니다. 현재:' +
                            spGrpNm.length
                    )
                    return
                }
            }

            // if (_.isEmpty(this.regPopUp.userGrpNm)) {
            //     this.showTcComAlert('권한그룹을 입력해주세요', {
            //         header: '필수 입력',
            //         size: '500',
            //         confirmLabel: 'OK',
            //     })
            //     return
            // }
            console.log('userNm', this.ckParam.userNm)
            console.log('userId', this.ckParam.userId)

            if ('undefined' == userGrpNm) {
                userGrpNm = ''
            }
            if ('undefined' == grpNm) {
                grpNm = ''
            }

            this.regPopUp.userGrpNm = userGrpNm
            this.regPopUp.grpNm = grpNm

            this.showBbsUserMgmt = true
        },
        async onConfirm() {
            if (_.isEmpty(this.regPopUp.bbsTypeCd)) {
                this.showTcComAlert('게시판구분을 선택해주세요', {
                    header: '검색조건 필수',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            if (_.isEmpty(this.regPopUp.orgNm)) {
                this.showTcComAlert(' 대상조직을 입력해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            if (_.isEmpty(this.regPopUp.textTitle)) {
                this.showTcComAlert('제목을 입력해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            if (_.isEmpty(this.regPopUp.bbsDtl)) {
                this.showTcComAlert('내용을 입력해주세요', {
                    header: '필수 입력',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            let smsMsg = ''
            if (
                '전체' == String(this.ckParam.userNm) &&
                'Y' == String(this.ckParam.smsSendYn)
            ) {
                smsMsg =
                    '대상아이디가 전체일때는  \n 문자전송이 되지 않습니다. \n'
            }

            await this.showTcComConfirm(smsMsg + '저장하시겠습니까?').then(
                (confirm) => {
                    if (confirm) {
                        //  첨부파일 저장
                        // console.log('!!!!!!!', this.regPopUp)
                        basBbsRegMgmtApi
                            .saveAttachFile(this.formData)
                            .then((resultData) => {
                                if (resultData != null) {
                                    this.regPopUp.docId = resultData[0].docId
                                }
                                //  문의상세내용 저장
                                this.saveBasBbsMgmt()
                            })
                    }
                }
            )
        },
        onStroeReturnData(retrunData) {
            var rowData = []
            var rowData1 = []
            if (retrunData.length) {
                for (let i = 0; i < retrunData.length; i++) {
                    rowData[i] = retrunData[i].dealcoNm
                    rowData1[i] = retrunData[i].dealcoCd
                    this.ckParam.dealcoNm = rowData
                    this.ckParam.dealcoCd = rowData1
                }
            }
        },
        onUserReturnData(retrunData) {
            var rowData = []
            var rowData1 = []
            if (retrunData.length) {
                for (let i = 0; i < retrunData.length; i++) {
                    rowData[i] = retrunData[i].userNm
                    rowData1[i] = retrunData[i].userId
                    //console.log('::::::::::', rowData)
                    this.ckParam.userNm = rowData
                    this.ckParam.userId = rowData1
                    console.log('userNm', this.ckParam.userNm)
                    console.log('userId', this.ckParam.userId)
                }
            }
        },
        onFileAddChange(files) {
            this.formData = new FormData()
            const addFileLength = files.addFile.length

            _.forEach(files.addFile, (item, index) => {
                this.formData.append('files', item.file)
                this.formData.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].screenId`,
                    'BASBBS00001'
                )
                this.formData.append(
                    `admAppendFileList[${index}].docId`,
                    this.regPopUp.docId === undefined ? '' : this.regPopUp.docId
                )
                this.formData.append(
                    `admAppendFileList[${index}].__rowState`,
                    'created'
                )
            })
            _.forEach(files.delFile, (item, index) => {
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].filePathNm`,
                    item.filePathNm
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].fileType`,
                    item.fileType
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].screenId`,
                    item.screenId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].docId`,
                    item.docId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].__rowState`,
                    'deleted'
                )
            })
        },
        onIdClear() {
            let eType = event.type ?? ''
            if ('click' == eType) {
                this.ckParam.userNm = ['전체']
                this.ckParam.userId = ['-1']
            }
        },
    },
}
</script>
