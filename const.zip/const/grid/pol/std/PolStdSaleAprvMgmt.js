import { ValueType } from 'realgrid'

export let GRID_INFO_LIST = {
    fields: [
        {
            fieldName: 'grpMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'grpMgmtNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'grpMgmtNo',
            fieldName: 'grpMgmtNo',
            type: 'data',
            width: '60',
            header: {
                text: '그룹번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'grpMgmtNm',
            fieldName: 'grpMgmtNm',
            type: 'data',
            width: '160',
            header: {
                text: '그룹명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            width: '60',
            header: {
                text: '사용여부',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                textReadOnly: true,
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '80',
            header: {
                text: '처리자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '110',
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
}

export let GRID_INFO_SEARCH = {
    fields: [
        {
            fieldName: 'saleAprvNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcEndDt',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'saleAprvNo',
            fieldName: 'saleAprvNo',
            type: 'data',
            width: '100',
            header: {
                text: '영업승인번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },

        {
            name: 'saleAprvNm',
            fieldName: 'saleAprvNm',
            type: 'data',
            width: '300',
            header: {
                text: '영업승인명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'svcStaDt',
            fieldName: 'svcStaDt',
            type: 'data',
            width: '100',
            header: {
                text: '개통시작일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'svcEndDt',
            fieldName: 'svcEndDt',
            type: 'data',
            width: '100',
            header: {
                text: '개통종료일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}

export let GRID_INFO_RGST = {
    fields: [
        {
            fieldName: 'saleAprvNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleAprvNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcEndDt',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'saleAprvNo',
            fieldName: 'saleAprvNo',
            type: 'data',
            width: '100',
            header: {
                text: '영업승인번호',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },

        {
            name: 'saleAprvNm',
            fieldName: 'saleAprvNm',
            type: 'data',
            width: '300',
            header: {
                text: '영업승인명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'svcStaDt',
            fieldName: 'svcStaDt',
            type: 'data',
            width: '100',
            header: {
                text: '개통시작일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'svcEndDt',
            fieldName: 'svcEndDt',
            type: 'data',
            width: '100',
            header: {
                text: '개통종료일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}
