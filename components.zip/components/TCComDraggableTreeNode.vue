<!-----------------------------------------------
 * 업무그룹명: Draggable Tree Node 컴포넌트
 * 서브업무명: Draggable Tree Node 공통함수
 * 설명: Draggable Tree Node 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.05.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <draggable
        class="dragArea"
        tag="ul"
        :list="items"
        :group="{ name: groupName }"
    >
        <li v-for="item in items" :key="getKey(item)">
            <v-list-item ripple @click="selectTreeNode(item)">
                <v-btn
                    icon
                    small
                    v-if="hasChild(item)"
                    @click.prevent="setShowChild(item)"
                >
                    <v-icon v-if="showChild[getKey(item)]"
                        >mdi-menu-down</v-icon
                    >
                    <v-icon v-else>mdi-menu-right</v-icon>
                </v-btn>
                <v-btn v-else icon small></v-btn>

                <v-icon v-if="hasChild(item)"> mdi-folder</v-icon>
                <v-icon v-else> mdi-file-document-outline</v-icon>
                <div class="ml-3">
                    {{ getText(item) }}
                </div>
                <v-spacer></v-spacer>
                <v-icon v-if="options.add" @click="addTreeNode(item)">
                    mdi-plus-thick
                </v-icon>
                <v-icon v-if="options.delete" @click="deleteTreeNode(item)">
                    mdi-delete
                </v-icon>
            </v-list-item>
            <treeNode
                v-show="showChild[getKey(item)]"
                v-if="hasChild(item)"
                :items="getChild(item)"
                :itemKey="itemKey"
                :itemChild="itemChild"
                :itemText="itemText"
                :options="options"
                :groupName="getGroupName(item)"
                @selectTreeNode="selectTreeNode"
                @addTreeNode="addTreeNode"
                @deleteTreeNode="deleteTreeNode"
            />
        </li>
    </draggable>
</template>

<script>
import draggable from 'vuedraggable'
import _ from 'lodash'

export default {
    inheritAttrs: false,
    name: 'treeNode',
    components: { draggable },
    props: {
        items: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        }, // 노드 정보
        itemKey: { type: String, default: 'id', required: false }, // 노드 키
        itemText: { type: String, default: 'name', required: false }, // 노드 Text
        itemChild: { type: String, default: 'children', required: false }, // 자식 노드
        groupName: { type: String, default: '', required: false }, // 그룹명
        options: {
            type: Object,
            default: () => {},
            required: false,
        }, // 옵션
        objAuth: { type: Object, default: () => {}, required: false }, // auth
    },

    data() {
        return {
            showChild: {},
        }
    },
    computed: {},
    watch: {},
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.items.forEach((item) => {
                this.$set(
                    this.showChild,
                    this.getKey(item),
                    this.options.openAll
                )
            })
        },
        hasChild(item) {
            return _.get(item, this.itemChild)
                ? _.get(item, this.itemChild).length > 0
                : _.get(item, this.itemChild)
        },
        setShowChild(item) {
            this.$set(
                this.showChild,
                this.getKey(item),
                !this.showChild[this.getKey(item)]
            )
        },
        getGroupName(item) {
            if (this.options.group) {
                const groupName = this.groupName
                    ? this.groupName
                    : this.getKey(item)
                return _.toString(groupName)
            }
        },
        getKey(item) {
            return _.get(item, this.itemKey)
        },
        getText(item) {
            return _.get(item, this.itemText)
        },
        getChild(item) {
            return _.get(item, this.itemChild)
        },
        selectTreeNode(item) {
            this.$emit('selectTreeNode', item)
        },
        addTreeNode(item) {
            this.$emit('addTreeNode', item)
        },
        deleteTreeNode(item) {
            this.$emit('deleteTreeNode', item)
        },
    },
}
</script>

<style scoped>
ul {
    list-style: none;
    padding-left: 10px;
}
</style>
