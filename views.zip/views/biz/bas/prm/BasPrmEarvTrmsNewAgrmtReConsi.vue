<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <!-- 거래처등록 팝업 사이즈 1300이상으로 유지 size="1300px" -->
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">전자결재 전송 신규계약 재품의</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Top BTN + form -->
                    <ul class="btn_area top pop">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="btn_earvSnd_OnClick"
                                >결재전송</TCComButton
                            >
                            <!--
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                disabled
                                >기안취소</TCComButton
                            >
                            -->
                        </li>
                        <li class="right">
                            <div class="multiForm text">
                                <div class="col0">
                                    <TCComCheckBox
                                        labelName=""
                                        v-model="ds_detail.BASIC_0"
                                        :itemList="Checkbox4"
                                        cols="12"
                                    />
                                </div>
                            </div>
                            <div class="multiForm ml10">
                                <TCComInput labelName="서류전송이력" />
                            </div>
                        </li>
                    </ul>
                    <!-- // Top BTN + form -->

                    <!-- SubTit  -->
                    <div class="stitHead pop">
                        <h4 class="subTit">작성정보</h4>
                    </div>
                    <!-- //SubTit -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="제목"
                                    v-model="ds_detail.earvTitl"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-1 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="문서번호"
                                    v-model="ds_detail.keyCode"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="D"
                                    v-model="ds_detail.makeDt"
                                    labelName="작성일"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-2 -->
                            <!-- item 2-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="작성자명"
                                    v-model="userInfo.userNm"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-3 -->
                            <!-- item 2-4 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="작성자사번"
                                    v-model="userInfo.userCd"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->

                    <!-- SubTit  -->
                    <div class="stitHead pop">
                        <h4 class="subTit">기본정보</h4>
                    </div>
                    <!-- //SubTit -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="사업자명(상호)"
                                    v-model="parentData.tradeName"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="거래처구분"
                                    codeId="ZBAS_C_00240"
                                    v-model="parentData.dealCoCl1"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="거래처코드"
                                    v-model="parentData.dealCoCd"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-3 -->
                            <!-- item 1-4 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="사업자구분"
                                    codeId="ZBAS_C_00400"
                                    v-model="parentData.perBizCl"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-4 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="사업자번호"
                                    v-model="parentData.bizNum"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="주민번호"
                                    v-model="parentData.regNum"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-2 -->
                            <!-- item 2-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="업태"
                                    v-model="parentData.bizCon"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-3 -->
                            <!-- item 2-4 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="종목"
                                    v-model="parentData.typOfBiz"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- //Search_line 2 -->
                        <!-- Search_line 3 -->
                        <div class="searchform">
                            <!-- item 3-1 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="과세구분"
                                    codeId="ZBAS_C_00230"
                                    v-model="parentData.taxStrd"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 3-1 -->
                            <!-- item 3-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="대표자명"
                                    v-model="parentData.repUserNm"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 3-2 -->
                            <!-- item 3-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="대표자생년월일"
                                    v-model="parentData.basic3"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 3-3 -->
                            <!-- item 3-4 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="대표자이동전화"
                                    v-model="parentData.repMblPhon"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 3-4 -->
                        </div>
                        <!-- //Search_line 3 -->
                        <!-- Search_line 4 -->
                        <div class="searchform">
                            <!-- item 4-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="사업장주소"
                                    v-model="parentData.infoAdd"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 4-1 -->
                        </div>
                        <!-- //Search_line 4 -->
                        <!-- Search_line 5 -->
                        <div class="searchform">
                            <!-- item 5-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="인감주소"
                                    v-model="parentData.signDealAdd"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 5-1 -->
                        </div>
                        <!-- //Search_line 5 -->
                        <!-- Search_line 6 -->
                        <div class="searchform">
                            <!-- item 6-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="사업장연락처"
                                    v-model="parentData.telNo"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 6-1 -->
                            <!-- item 6-2 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="은행"
                                    codeId="ZBAS_C_00420"
                                    v-model="parentData.slcmDfryBankCd"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 6-2 -->
                            <!-- item 6-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="출금계좌"
                                    v-model="parentData.slcmDfryAccNo"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 6-3 -->
                            <!-- item 6-4 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="예금주"
                                    v-model="parentData.slcmDfryDepo"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 6-4 -->
                        </div>
                        <!-- //Search_line 6 -->
                        <!-- Search_line 7 -->
                        <div class="searchform">
                            <!-- item 7-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="일치여부"
                                    v-model="parentData.slcmChk"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 7-1 -->
                            <!-- item 7-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="실경영자명(실제매장운영자)"
                                    labelClass="line2"
                                    v-model="parentData.basic2"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 7-2 -->
                            <!-- item 7-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="실경영자 생년월일"
                                    labelClass="line2"
                                    v-model="parentData.basic3"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 7-3 -->
                            <!-- item 7-4 -->
                            <div class="formitem div4"></div>
                            <!-- //item 7-4 -->
                        </div>
                        <!-- //Search_line 7 -->
                    </div>
                    <!-- //Search_div -->
                    <p class="infoTxt">
                        <span class="color-red"
                            >아래 실경영자가 대표자와 동일한 경우라도 기재할것
                        </span>
                    </p>

                    <!-- SubTit  -->
                    <div class="stitHead pop">
                        <h4 class="subTit">거래처 세부정보 입력</h4>
                    </div>
                    <!-- //SubTit -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="거래처명"
                                    v-model="parentData.dealCoNm"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="거래처코드(P,R)"
                                    v-model="parentData.sktChannelCd"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="매장영업형태"
                                    :itemList="dealcoCl2List"
                                    v-model="parentData.dealCoCl2"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-3 -->
                            <!-- item 1-4 -->
                            <!--
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="딜러여부"
                                    v-model="parentData.dtl1"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>-->
                            <!-- //item 1-4 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-4 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="거래처주소"
                                    v-model="parentData.dealAdd"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- //Search_line 2 -->
                        <!-- Search_line 3 -->
                        <div class="searchform">
                            <!-- item 3-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="딜러여부"
                                    v-model="parentData.dtl1"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 3-1 -->
                            <!-- item 3-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="본점명"
                                    v-model="parentData.dtl3"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 3-2 -->
                            <!-- item 3-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="본직영점구분"
                                    v-model="parentData.dtl2"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 3-3 -->
                            <!-- item 3-4 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="SKT 관할 마케팅팀"
                                    labelClass="line2"
                                    v-model="parentData.dtl4"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 3-4 -->
                        </div>
                        <!-- //Search_line 3 -->
                        <!-- Search_line 3 -->
                        <div class="searchform">
                            <!-- item 3-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="U.FAX 번호1"
                                    v-model="parentData.dtl5"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 3-1 -->
                            <!-- item 3-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="U.FAX 번호2"
                                    v-model="parentData.dtl6"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 3-2 -->
                            <!-- item 3-3 -->
                            <div class="formitem div2"></div>
                            <!-- //item 3-3 -->
                        </div>
                        <!-- //Search_line 3 -->
                        <!-- Search_line 4 -->
                        <div class="searchform vline">
                            <p class="formTit">센터담당매니저</p>
                            <!-- item 4-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="성명"
                                    v-model="parentData.dtl7"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 4-1 -->
                            <!-- item 4-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="휴대폰"
                                    v-model="parentData.dtl8"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 4-2 -->
                            <!-- item 4-3-->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="소속"
                                    v-model="parentData.dtl9"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 4-3 -->
                        </div>
                        <!-- //Search_line 4 -->
                        <!-- Search_line 5 -->
                        <div class="searchform vline">
                            <p class="formTit">
                                판매점실무자(실경영자와 구분됨)
                            </p>
                            <!-- item 5-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="성명"
                                    v-model="parentData.dtl10"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 5-1 -->
                            <!-- item 5-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="휴대폰"
                                    v-model="parentData.dtl11"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 5-2 -->
                            <!-- item 5-3-->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="e-mail"
                                    v-model="parentData.dtl12"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 5-3 -->
                        </div>
                        <!-- //Search_line 5 -->
                        <!-- Search_line 6 -->
                        <div class="searchform">
                            <!-- item 6-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="성명"
                                    v-model="parentData.dtl13"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 6-1 -->
                            <!-- item 6-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="휴대폰"
                                    v-model="parentData.dtl14"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 6-2 -->
                            <!-- item 6-3-->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="e-mail"
                                    v-model="parentData.dtl15"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 6-3 -->
                        </div>
                        <!-- //Search_line 6 -->
                        <!-- Search_line 7 -->
                        <div class="searchform">
                            <!-- item 7-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="성명"
                                    v-model="parentData.dtl16"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 7-1 -->
                            <!-- item 7-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="휴대폰"
                                    v-model="parentData.dtl17"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 7-2 -->
                            <!-- item 7-3-->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="e-mail"
                                    v-model="parentData.dtl18"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 7-3 -->
                        </div>
                        <!-- //Search_line 7 -->
                        <!-- Search_line 8 -->
                        <div class="searchform">
                            <!-- item 8-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="구술약도"
                                    v-model="parentData.dtl19"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 8-1 -->
                        </div>
                        <!-- //Search_line 8 -->
                    </div>
                    <!-- //Search_div -->

                    <!-- SubTit  -->
                    <div class="stitHead">
                        <h4 class="subTit">거래처 기타정보 입력</h4>
                    </div>
                    <!-- //SubTit -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="신용등급(개인사업자)"
                                    labelClass="line2"
                                    v-model="parentData.etc1"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="신용등급(법인사업자)"
                                    labelClass="line2"
                                    v-model="parentData.etc2"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div2"></div>
                            <!-- //item 1-3 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="거래불가 등급 거래시 RISK 관리방안"
                                    labelClass="line2"
                                    v-model="parentData.etc3"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 2-1 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <p class="infoTxt">
                        <span class="color-red"
                            >신용등급 7,8,9,10 등급 개설결재시 품의 작성자 위
                            사유 기재
                        </span>
                    </p>
                    <!-- Search_div -->
                    <div class="searchLayer_wrap mt20">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="매장경력(총경력)"
                                    v-model="parentData.etc4"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="매장경력(법인사업자)"
                                    labelClass="line2"
                                    v-model="parentData.etc5"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div2"></div>
                            <!-- //item 1-3 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="주위평판"
                                    v-model="parentData.etc6"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 2-1 -->
                        </div>
                        <!-- //Search_line 2 -->
                        <!-- Search_line 3 -->
                        <div class="searchform vline">
                            <p class="formTit">판매현황(신규+기변)</p>
                            <!-- item 3-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="SKT(건수)"
                                    v-model="parentData.etc7"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 3-1 -->
                            <!-- item 3-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="SKT(%)"
                                    v-model="parentData.etc8"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 3-2 -->
                            <!-- item 3-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="KT(건수)"
                                    v-model="parentData.etc9"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 3-3 -->
                            <!-- item 4-4 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="KT(%)"
                                    v-model="parentData.etc10"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 4-4 -->
                        </div>
                        <!-- //Search_line 3 -->
                        <!-- Search_line 4 -->
                        <div class="searchform">
                            <!-- item 4-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="LG(건수)"
                                    v-model="parentData.etc11"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 4-1 -->
                            <!-- item 4-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="LG(%)"
                                    v-model="parentData.etc12"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 4-2 -->
                            <!-- item 4-3 -->
                            <div class="formitem div2"></div>
                            <!-- //item 4-3 -->
                        </div>
                        <!-- //Search_line 4 -->
                        <!-- Search_line 5 -->
                        <div class="searchform vline">
                            <p class="formTit">SKT 주요거래점</p>
                            <!-- item 5-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="거래점1(건수)"
                                    v-model="parentData.etc13"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 5-1 -->
                            <!-- item 5-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="거래점1(%)"
                                    v-model="parentData.etc14"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 5-2 -->
                            <!-- item 5-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="거래점2(건수)"
                                    v-model="parentData.etc15"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 5-3 -->
                            <!-- item 5-4 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="거래점2(%)"
                                    v-model="parentData.etc16"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 5-4 -->
                        </div>
                        <!-- //Search_line 5 -->
                        <!-- Search_line 6 -->
                        <div class="searchform">
                            <!-- item 6-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="거래점3(건수)"
                                    v-model="parentData.etc17"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 6-1 -->
                            <!-- item 6-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="거래점3(%)"
                                    v-model="parentData.etc18"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 6-2 -->
                            <!-- item 6-3 -->
                            <div class="formitem div2"></div>
                            <!-- //item 6-3 -->
                        </div>
                        <!-- //Search_line 6 -->
                        <!-- Search_line 7 -->
                        <div class="searchform pt-3 vline">
                            <!-- item 7-1 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="판매목표(월)"
                                    v-model="parentData.etc19"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 7-1 -->
                            <!-- item 7-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="상권"
                                    v-model="parentData.etc20"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 7-2 -->
                            <!-- item 7-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="동일지역내판매점
                                월평균판매건"
                                    labelClass="line2"
                                    v-model="parentData.etc21"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 7-3 -->
                        </div>
                        <!-- //Search_line 7 -->
                        <!-- Search_line 8 -->
                        <div class="searchform vline">
                            <p class="formTit">담보1</p>
                            <!-- item 8-1 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="여신유형"
                                    codeId="CRD_TYP"
                                    v-model="parentData.crdTypNm1"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 8-1 -->
                            <!-- item 8-2 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="보증(금융)기관"
                                    codeId="ZBAS_C_00200"
                                    v-model="parentData.grtInstNm1"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 8-2 -->
                            <!-- item 8-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="설정근거"
                                    v-model="parentData.setBasis1"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 8-3 -->
                            <!-- item 8-4 -->
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="D"
                                    v-model="parentData.setDt1"
                                    labelName="설정일"
                                    disabled
                                />
                            </div>
                            <!-- //item 8-4 -->
                        </div>
                        <!-- //Search_line 8 -->
                        <!-- Search_line 9 -->
                        <div class="searchform">
                            <!-- item 9-1 -->
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="D"
                                    v-model="parentData.expirDt1"
                                    labelName="만료일"
                                    disabled
                                />
                            </div>
                            <!-- //item 9-1 -->
                            <!-- item 9-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="담보금액"
                                    v-model="parentData.mrtgAmt1"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 9-2 -->
                            <!-- item 9-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="담보(설정)금액"
                                    v-model="parentData.mrtgSetAmt1"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 9-3 -->
                            <!-- item 9-4 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="수수료"
                                    v-model="parentData.cmms1"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 9-4 -->
                        </div>
                        <!-- //Search_line 9 -->
                        <!-- Search_line 10 -->
                        <div class="searchform">
                            <!-- item 10-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="비고"
                                    v-model="parentData.etc22"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 10-1 -->
                        </div>
                        <!-- //Search_line 10 -->
                        <!-- Search_line 11 -->
                        <div class="searchform vline">
                            <p class="formTit">담보2</p>
                            <!-- item 11-1 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="여신유형"
                                    codeId="CRD_TYP"
                                    v-model="parentData.crdTypNm2"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 11-1 -->
                            <!-- item 11-2 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="보증(금융)기관"
                                    codeId="ZBAS_C_00200"
                                    v-model="parentData.grtInstNm2"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 11-2 -->
                            <!-- item 11-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="설정근거"
                                    v-model="parentData.setBasis2"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 11-3 -->
                            <!-- item 11-4 -->
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="D"
                                    v-model="parentData.setDt2"
                                    labelName="설정일"
                                    disabled
                                />
                            </div>
                            <!-- //item 11-4 -->
                        </div>
                        <!-- //Search_line 11 -->
                        <!-- Search_line 12 -->
                        <div class="searchform">
                            <!-- item 12-1 -->
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="D"
                                    v-model="parentData.expirDt2"
                                    labelName="만료일"
                                    disabled
                                />
                            </div>
                            <!-- //item 12-1 -->
                            <!-- item 12-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="담보금액"
                                    v-model="parentData.mrtgAmt2"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 12-2 -->
                            <!-- item 12-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="담보(설정)금액"
                                    v-model="parentData.mrtgSetAmt2"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 12-3 -->
                            <!-- item 12-4 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="수수료"
                                    v-model="parentData.cmms2"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 12-4 -->
                        </div>
                        <!-- //Search_line 12 -->
                        <!-- Search_line 13 -->
                        <div class="searchform">
                            <!-- item 13-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="비고"
                                    v-model="parentData.etc23"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 13-1 -->
                        </div>
                        <!-- //Search_line 13 -->
                        <!-- Search_line 14 -->
                        <div class="searchform vline">
                            <p class="formTit">담보3</p>
                            <!-- item 14-1 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="여신유형"
                                    codeId="CRD_TYP"
                                    v-model="parentData.crdTypNm3"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 14-1 -->
                            <!-- item 14-2 -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    labelName="보증(금융)기관"
                                    codeId="ZBAS_C_00200"
                                    v-model="parentData.grtInstNm3"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 14-2 -->
                            <!-- item 14-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="설정근거"
                                    v-model="parentData.setBasis3"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 14-3 -->
                            <!-- item 14-4 -->
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="D"
                                    v-model="parentData.setDt3"
                                    labelName="설정일"
                                    disabled
                                />
                            </div>
                            <!-- //item 14-4 -->
                        </div>
                        <!-- //Search_line 14 -->
                        <!-- Search_line 15 -->
                        <div class="searchform">
                            <!-- item 15-1 -->
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="D"
                                    v-model="parentData.expirDt3"
                                    labelName="만료일"
                                    disabled
                                />
                            </div>
                            <!-- //item 15-1 -->
                            <!-- item 15-2 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="담보금액"
                                    v-model="parentData.mrtgAmt3"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 15-2 -->
                            <!-- item 15-3 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="담보(설정)금액"
                                    v-model="parentData.mrtgSetAmt3"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 15-3 -->
                            <!-- item 15-4 -->
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="수수료"
                                    v-model="parentData.cmms3"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 15-4 -->
                        </div>
                        <!-- //Search_line 15 -->
                        <!-- Search_line 16 -->
                        <div class="searchform">
                            <!-- item 16-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="비고"
                                    v-model="parentData.etc24"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 16-1 -->
                        </div>
                        <!-- //Search_line 16 -->
                    </div>
                    <!-- //Search_div -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <!-- <TCComButton eClass="btn_ty02_point" :eLarge="true"
                            >확인</TCComButton
                        > -->
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="onClose"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { GRID_D_HEADER } from '@/const/grid/sample/sampleGrid'
// import { SAMPLE_D_DATA, SAMPLE_DATA } from '@/const/grid/sample/sampleGridData'
import api from '@/api/biz/bas/prm/basPrmDealcoMgmt'

// import moment from 'moment'
import CommonMixin from '@/mixins'
// import CommonUtil from '@/utils/CommonUtil.js'
import { SacCommon } from '@/views/biz/sac/js'
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dealcoMgmt/helpers'
import _ from 'lodash'

export default {
    name: 'BasPrmEarvTrmsChgCltRenewalPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            calType7: 'DHMP',
            inputValue: '2021-01-01',
            inputValue7: ['2022-03-20', '2022-03-25'],
            sHourVal7: '11',
            eHourVal7: '23',
            sMinuVal7: '50',
            eMinuVal7: '59',
            inputValue2: '2021-02',
            inputValue5: '2022-03-15',
            calType5: 'M',
            endDateVal5: '2022-03-16',
            calType4: 'DHM',
            inputValue4: '2022-03-11',
            inputValue41: '01',
            inputValue42: '59',
            //Paging Class init
            guideTab: 0,
            guideTab2: 0,
            tabItems: ['가상배정', '위탁배정'],
            gridData: this.gridSetData(),
            objAuth: {},
            gridObj: {},
            gridHeaderObj: {},
            gridObj2: {},
            gridHeaderObj2: {},
            codeIDView: true,
            codeIDViewVal: '',
            value1: '',
            value2: '',
            list01: [],
            list02: [],
            view: GRID_D_HEADER,
            radio1: '1',
            radio2: '2',
            checked1: true,
            checked2: false,
            input: '',
            input11: '',
            input12: '',
            input13: '',
            input14: '',
            input15: '',
            input21: '',
            input22: '',
            input23: '',
            input24: '',
            input25: '',
            input26: '',
            input27: '',
            checkbox: true,
            radios: null,
            tab: null,
            itemName: ['판매상세', '수납', '비고'],
            MdlClData: [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'Option 1',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Option 2',
                },
            ],
            MdlClData2: [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'Option 1',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Option 2',
                },
            ],
            items: [
                {
                    commCdVal: '',
                    commCdValNm: '선택',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'Option 1',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Option 2',
                },
            ],
            itemList1: [
                {
                    commCdVal: '10',
                    commCdValNm: 'T/B연계판매',
                },
            ],
            itemList2: [
                {
                    commCdVal: '10',
                    commCdValNm: '서류미비 선등록(지급보류 및 해제)',
                },
            ],
            itemList3: [
                {
                    commCdVal: '10',
                    commCdValNm: '정상',
                },
                {
                    commCdVal: '20',
                    commCdValNm: '수납정지',
                },
                {
                    commCdVal: '30',
                    commCdValNm: '출고정지',
                },
                {
                    commCdVal: '40',
                    commCdValNm: '판매정지',
                },
                {
                    commCdVal: '50',
                    commCdValNm: '출금정지',
                },
                {
                    commCdVal: '60',
                    commCdValNm: '거래종료',
                },
            ],
            itemList4: [
                {
                    commCdVal: '10',
                    commCdValNm: '월별발행',
                },
                {
                    commCdVal: '20',
                    commCdValNm: '건별발행',
                },
            ],
            itemList5: [
                {
                    commCdVal: '10',
                    commCdValNm: '사업자주소와동일',
                },
            ],
            itemList6: [
                {
                    commCdVal: '10',
                    commCdValNm: 'SKIN직배송여부',
                },
                {
                    commCdVal: '20',
                    commCdValNm: '전속점여부',
                },
            ],
            itemList7: [
                {
                    commCdVal: '10',
                    commCdValNm: '',
                },
            ],
            dealcoCl2List: [],
            dealcoCl2_1List: [],
            dealcoCl2_2List: [],
            gridStyle: {
                height: '170px', //그리드 높이 조절
            },
            parentData: {},
            ds_detail: {
                earvTitl: '신규거래처 계약품의서(재품의)_',
                BASIC_0: [],
                makeDt: SacCommon.getToday(),
            },
            Checkbox4: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '서류미비 선등록(지급보류 및 해제)',
                },
            ],
        }
    },
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        basPrmDealcoDtlEarvCntVo: {
            get() {
                return this.basPrmDealcoDtlEarvCntListVo // 전자결재 진행여부
            },
        },
    },
    mounted() {
        this.init()
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentData', value)
                this.parentData = value
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        ...serviceMethods,
        setData() {
            let params = { ...this.newInfo }
            this.storeSet(this.storeKey, params)
        },

        async storeSet(key, value) {
            await this.defaultAssign_({
                key: key,
                value: value,
            })
        },
        async init() {
            console.log('init')
            console.log('this.ds_detail', this.ds_detail)
            console.log('this.parentData', this.parentData)
            await this.setTitle()
            await this.dropDownSetting()
            await this.gubunDealcoCl()
        },
        gridSetData: function () {
            return new CommonGrid(0, 10, '', '')
        },

        async setTitle() {
            this.ds_detail.earvTitl =
                this.ds_detail.earvTitl +
                this.parentData.dealCoNm +
                '_' +
                this.parentData.dealCoCd
        },

        async gubunDealcoCl() {
            if (this.parentData.dealCoCl1 == 'A2') {
                this.dealcoCl2List = this.dealcoCl2_1List
            } else if (this.parentData.dealCoCl1 == 'A3') {
                this.dealcoCl2List = this.dealcoCl2_2List
            }
        },

        // 그리드에 dropdown셋팅 공통코드 api
        async dropDownSetting() {
            console.log('dropDownSetting')

            // 소속유형
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00110',
                columnName: 'dealCoCl2_1',
                option: '전체',
            })
            // 소속유형
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00570',
                columnName: 'dealCoCl2_2',
                option: '전체',
            })
        },

        async dropDownCmmonCodes({ key, columnName, option }) {
            console.log('key columnName option', key, columnName, option)
            let result = await api.dropDownCmmonCodes_(key)
            console.log('result', result)

            if (columnName == 'dealCoCl2_1') {
                this.dealcoCl2_1List = result
            } else {
                this.dealcoCl2_2List = result
            }
        },

        // 결재전송
        async btn_earvSnd_OnClick() {
            console.log('ds_detail', this.ds_detail)
            // 전자결재 중복 체크
            if (!_.isEmpty(this.basPrmDealcoDtlEarvCntVo)) {
                if (
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.deal, '0') ||
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.dlv, '0') ||
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.crd, '0') ||
                    !_.isEqual(this.basPrmDealcoDtlEarvCntVo.cust, '0')
                ) {
                    this.showTcComAlert('전자결재 승인 대기중입니다.')
                    return false
                }
            }
            //if (this.Checkbox4[0].commCdVal == 'Y') {
            if (_.isEqual(this.ds_detail.BASIC_0[0], 'Y')) {
                let confirm = await this.showTcComConfirm(
                    '해당 거래처에 지급보류(W)가 설정됩니다.'
                )
                if (!confirm) {
                    return false
                }
            }
            console.log('dealCoCd : ', this.parentData.dealCoCd)

            this.ds_mibiYn = this.ds_detail.BASIC_0[0]

            let params = {
                basPrmDealcoElecAprvLnkgDetailDto: [
                    {
                        keyCode: this.parentData.keyCode
                            ? this.parentData.keyCode
                            : '',
                        earvTitl: this.ds_detail.earvTitl,
                        userCd: this.userInfo.userCd
                            ? this.userInfo.userCd
                            : '',
                        earvDoc: this.parentData.earvDoc
                            ? this.parentData.earvDoc
                            : '',
                        mibiYn: this.ds_mibiYn ? this.ds_mibiYn : 'N',
                        rmks: '임시 고객정보', // 고객정보의 비고
                        insUserId: this.parentData.insUserId
                            ? this.parentData.insUserId
                            : '',
                        modUserId: this.parentData.insUserId
                            ? this.parentData.insUserId
                            : '',

                        newOrgCd: this.parentData.newOrgCd
                            ? this.parentData.newOrgCd
                            : '',
                        orgCd3: this.parentData.orgCd3
                            ? this.parentData.orgCd3
                            : '',
                        orgCd2: this.parentData.orgCd2
                            ? this.parentData.orgCd2
                            : '',
                        makeDt: this.ds_detail.makeDt
                            ? this.ds_detail.makeDt
                            : this.ds_detail.makeDt,
                        userNm: this.userInfo.userNm
                            ? this.userInfo.userNm
                            : '',
                        basic0:
                            this.ds_detail.BASIC_0.length !== 0
                                ? this.ds_detail.BASIC_0[0]
                                : 'N',
                        tradeName: this.parentData.tradeName
                            ? this.parentData.tradeName
                            : '',
                        dealCoCl1: this.parentData.dealCoClNm1
                            ? this.parentData.dealCoClNm1
                            : '',
                        dealcoCd: this.parentData.dealCoCd
                            ? this.parentData.dealCoCd
                            : '',
                        perBizCl: this.parentData.perBizClNm
                            ? this.parentData.perBizClNm
                            : '',
                        bizNum: this.parentData.bizNum
                            ? this.parentData.bizNum
                            : '',
                        regNum: this.parentData.regNum
                            ? this.parentData.regNum
                            : '',
                        bizCon: this.parentData.bizCon
                            ? this.parentData.bizCon
                            : '',
                        typOfBiz: this.parentData.typOfBiz
                            ? this.parentData.typOfBiz
                            : '',
                        taxStrd: this.parentData.taxStrdNm
                            ? this.parentData.taxStrdNm
                            : '',
                        infoAdd: this.parentData.infoAdd
                            ? this.parentData.infoAdd
                            : '',
                        signDealAdd: this.parentData.signDealAdd
                            ? this.parentData.signDealAdd
                            : '',
                        repUserNm: this.parentData.repUserNm
                            ? this.parentData.repUserNm
                            : '',
                        basic1: this.parentData.basic1
                            ? this.parentData.basic1
                            : '',
                        repMblPhon: this.parentData.repMblPhon
                            ? this.parentData.repMblPhon
                            : '',
                        telNo: this.parentData.telNo
                            ? this.parentData.telNo
                            : '',
                        slcmDfryCmsCd: this.parentData.slcmDfryCmsCd
                            ? this.parentData.slcmDfryCmsCd
                            : '',
                        slcmDfryAccNo: this.parentData.slcmDfryAccNo
                            ? this.parentData.slcmDfryAccNo +
                              '(' +
                              this.parentData.slcmDfryBankCdNm +
                              ')'
                            : '',

                        slcmDfryDepo: this.parentData.slcmDfryDepo
                            ? this.parentData.slcmDfryDepo
                            : '',
                        slcmChk: this.parentData.slcmChk
                            ? this.parentData.slcmChk
                            : '',
                        slcmDfryDepoCheck: this.params.vrfDpstrNm
                            ? this.params.vrfDpstrNm
                            : '',
                        basic2: this.parentData.basic2
                            ? this.parentData.basic2
                            : '',
                        basic3: this.parentData.basic3
                            ? this.parentData.basic3
                            : '',
                        basic4: this.parentData.basic4
                            ? this.parentData.basic4
                            : '',
                        basic5: this.parentData.basic5
                            ? this.parentData.basic5
                            : '',
                        basic6: this.parentData.basic6
                            ? this.parentData.basic6
                            : '',
                        basic7: this.parentData.basic7
                            ? this.parentData.basic7
                            : '',
                        basic8: this.parentData.basic8
                            ? this.parentData.basic8
                            : '',
                        dealCoNm: this.parentData.dealCoNm
                            ? this.parentData.dealCoNm
                            : '',
                        ukeyChannelCd: this.parentData.ukeyChannelCd
                            ? this.parentData.ukeyChannelCd
                            : '',
                        dealAdd: this.parentData.dealAdd
                            ? this.parentData.dealAdd
                            : '',
                        dealCoCl2: this.parentData.dealCoClNm2
                            ? this.parentData.dealCoClNm2
                            : '',
                        dealCoCl3: this.parentData.dealCoClNm3
                            ? this.parentData.dealCoClNm3
                            : '',
                        dtl1: this.parentData.dtl1 ? this.parentData.dtl1 : '',
                        dtl2: this.parentData.dtl2 ? this.parentData.dtl2 : '',
                        dtl3: this.parentData.dtl3 ? this.parentData.dtl3 : '',
                        dtl4: this.parentData.dtl4 ? this.parentData.dtl4 : '',
                        dtl5: this.parentData.dtl5 ? this.parentData.dtl5 : '',
                        dtl6: this.parentData.dtl6 ? this.parentData.dtl6 : '',
                        dtl7: this.parentData.dtl7 ? this.parentData.dtl7 : '',
                        dtl8: this.parentData.dtl8 ? this.parentData.dtl8 : '',
                        dtl9: this.parentData.dtl9 ? this.parentData.dtl9 : '',
                        dtl10: this.parentData.dtl10
                            ? this.parentData.dtl10
                            : '',
                        dtl11: this.parentData.dtl11
                            ? this.parentData.dtl11
                            : '',
                        dtl12: this.parentData.dtl12
                            ? this.parentData.dtl12
                            : '',
                        dtl13: this.parentData.dtl13
                            ? this.parentData.dtl13
                            : '',
                        dtl14: this.parentData.dtl14
                            ? this.parentData.dtl14
                            : '',
                        dtl15: this.parentData.dtl15
                            ? this.parentData.dtl15
                            : '',
                        dtl16: this.parentData.dtl16
                            ? this.parentData.dtl16
                            : '',
                        dtl17: this.parentData.dtl17
                            ? this.parentData.dtl17
                            : '',
                        dtl18: this.parentData.dtl18
                            ? this.parentData.dtl18
                            : '',
                        dtl19: this.parentData.dtl19
                            ? this.parentData.dtl19
                            : '',
                        etc1: this.parentData.etc1 ? this.parentData.etc1 : '',
                        etc2: this.parentData.etc2 ? this.parentData.etc2 : '',
                        etc3: this.parentData.etc3 ? this.parentData.etc3 : '',
                        etc4: this.parentData.etc4 ? this.parentData.etc4 : '',
                        etc5: this.parentData.etc5 ? this.parentData.etc5 : '',
                        etc6: this.parentData.etc6 ? this.parentData.etc6 : '',
                        etc7: this.parentData.etc7 ? this.parentData.etc7 : '',
                        etc8: this.parentData.etc8 ? this.parentData.etc8 : '',
                        etc9: this.parentData.etc9 ? this.parentData.etc9 : '',
                        etc10: this.parentData.etc10
                            ? this.parentData.etc10
                            : '',
                        etc11: this.parentData.etc11
                            ? this.parentData.etc11
                            : '',
                        etc12: this.parentData.etc12
                            ? this.parentData.etc12
                            : '',
                        etc13: this.parentData.etc13
                            ? this.parentData.etc13
                            : '',
                        etc14: this.parentData.etc14
                            ? this.parentData.etc14
                            : '',
                        etc15: this.parentData.etc15
                            ? this.parentData.etc15
                            : '',
                        etc16: this.parentData.etc16
                            ? this.parentData.etc16
                            : '',
                        etc17: this.parentData.etc17
                            ? this.parentData.etc17
                            : '',
                        etc18: this.parentData.etc18
                            ? this.parentData.etc18
                            : '',
                        etc19: this.parentData.etc19
                            ? this.parentData.etc19
                            : '',
                        etc20: this.parentData.etc20
                            ? this.parentData.etc20
                            : '',
                        etc21: this.parentData.etc21
                            ? this.parentData.etc21
                            : '',
                        rsn1: this.parentData.rsn1 ? this.parentData.rsn1 : '',
                        rsn2: this.parentData.rsn2 ? this.parentData.rsn2 : '',
                        rsn3: this.parentData.rsn3 ? this.parentData.rsn3 : '',
                        rsn4: this.parentData.rsn4 ? this.parentData.rsn4 : '',
                        rsn5: this.parentData.rsn5 ? this.parentData.rsn5 : '',
                        crdTypNm1: this.parentData.crdTypNmNm1
                            ? this.parentData.crdTypNmNm1
                            : '',
                        grtInstNm1: this.parentData.grtInstNmNm1
                            ? this.parentData.grtInstNmNm1
                            : '',
                        mrtgAmt1: this.parentData.mrtgAmt1
                            ? this.parentData.mrtgAmt1
                            : '',
                        cmms1: this.parentData.cmms1
                            ? this.parentData.cmms1
                            : '',
                        setDt1: this.parentData.setDt1
                            ? this.parentData.setDt1
                            : '',
                        expirDt1: this.parentData.expirDt1
                            ? this.parentData.expirDt1
                            : '',
                        setBasis1: this.parentData.setBasis1
                            ? this.parentData.setBasis1
                            : '',
                        etc22: this.parentData.etc22
                            ? this.parentData.etc22
                            : '',
                        crdTypNm2: this.parentData.crdTypNmNm2
                            ? this.parentData.crdTypNmNm2
                            : '',
                        grtInstNm2: this.parentData.grtInstNmNm2
                            ? this.parentData.grtInstNmNm2
                            : '',
                        mrtgAmt2: this.parentData.mrtgAmt2
                            ? this.parentData.mrtgAmt2
                            : '',
                        cmms2: this.parentData.cmms2
                            ? this.parentData.cmms2
                            : '',
                        setDt2: this.parentData.setDt2
                            ? this.parentData.setDt2
                            : '',
                        expirDt2: this.parentData.expirDt2
                            ? this.parentData.expirDt2
                            : '',
                        setBasis2: this.parentData.setBasis2
                            ? this.parentData.setBasis2
                            : '',
                        etc23: this.parentData.etc23
                            ? this.parentData.etc23
                            : '',
                        crdTypNm3: this.parentData.crdTypNmNm3
                            ? this.parentData.crdTypNmNm3
                            : '',
                        grtInstNm3: this.parentData.grtInstNmNm3
                            ? this.parentData.grtInstNmNm3
                            : '',
                        mrtgAmt3: this.parentData.mrtgAmt3
                            ? this.parentData.mrtgAmt3
                            : '',
                        cmms3: this.parentData.cmms3
                            ? this.parentData.cmms3
                            : '',
                        setDt3: this.parentData.setDt3
                            ? this.parentData.setDt3
                            : '',
                        expirDt3: this.parentData.expirDt3
                            ? this.parentData.expirDt3
                            : '',
                        setBasis3: this.parentData.setBasis3
                            ? this.parentData.setBasis3
                            : '',
                        etc24: this.parentData.etc24
                            ? this.parentData.etc24
                            : '',
                        mrtgSetAmt1: this.parentData.mrtgSetAmt1
                            ? this.parentData.mrtgSetAmt1
                            : '',
                        mrtgSetAmt2: this.parentData.mrtgSetAmt2
                            ? this.parentData.mrtgSetAmt2
                            : '',
                        mrtgSetAmt3: this.parentData.mrtgSetAmt3
                            ? this.parentData.mrtgSetAmt3
                            : '',
                    },
                ],
            }
            // console.log('params->', params)
            // this.defaultAssign_({
            //     key: 'earvImsi3',
            //     value: true,
            // })
            // this.onClose()
            api.requestCrdAdd7_(params).then(() => {
                this.gridData = this.gridSetData() //초기화
                // this.$parent.imsiSave3()
                // console.log('this.$parent', this.$parent)
                this.defaultAssign_({
                    key: 'earvImsi3',
                    value: !_.isEmpty(this.ds_mibiYn) ? this.ds_mibiYn : 'N',
                })
                this.onClose()
            })
        },

        onClose() {
            console.log('this.$parent', this.$parent)
            // this.$parent.onSearch()
            // this.$parent.onSearch()
            this.activeOpen = false
            // this.$parent.onSearch()
            // this.$refs.$parent.imsiSave3()
        },
    },
}
</script>
