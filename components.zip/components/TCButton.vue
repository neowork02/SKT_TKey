<template>
    <button :class="cls" type="button" @click="clickButton($event)">
        <i v-if="isIcon == 'Y'" :class="iCls" :style="iStyle"></i>{{ title }}
        <slot />
    </button>
</template>

<script>
export default {
    name: 'IssButton',

    props: {
        cls: {
            type: String,
            required: true,
        },
        isIcon: {
            type: String,
            default: 'N',
        },
        iCls: {
            type: String,
            default: '',
        },
        iStyle: {
            type: String,
            default: '',
        },
        title: {
            default: '',
        },
    },

    methods: {
        clickButton: function (e) {
            this.$emit('click', e)
        },
    },
}
</script>
