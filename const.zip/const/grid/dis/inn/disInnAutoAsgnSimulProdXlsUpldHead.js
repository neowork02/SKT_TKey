import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'asgnQty',
            dataType: ValueType.NUMBER, //배정수량
        },
        {
            fieldName: 'lmtQty',
            dataType: ValueType.NUMBER, //최대배정수량
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //오류사항
        },
    ],
    columns: [
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'asgnQty',
            fieldName: 'asgnQty', //sknAsgnQty
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'lmtQty',
            fieldName: 'lmtQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '최대배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '250',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '오류사항',
                showTooltip: false,
            },
            editable: false,
        },
    ],
}
