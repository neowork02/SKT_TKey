<template>
    <div class="content">
        <!-- Tit -->
        <h1>단가표관리</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="onProdClick"
                    :objAuth="this.objAuth"
                    >상품관리</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch(type)"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onNewClick"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="M"
                        v-model="div_search.cal_polYm"
                        labelName="적용년월"
                        :eRequired="true"
                    />
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCComTab
                :tab.sync="guideTab2"
                :items="items"
                :itemName="itemName"
                :tabColor="tabColor"
                :textColor="textColor"
                :centered="centered"
                :grow="grow"
                :height="height"
                :hideSlider="hideSlider"
                :sliderColor="sliderColor"
                :vertical="vertical"
                :objAuth="objAuth"
                sliderSize="8"
                @change="onActiveTabChange"
                @click="onActiveTabClick"
                :cKey="0"
            >
                <template #Template1>
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="운영모델단가표목록"
                        :gridObj="gridObj1"
                        :isPageRows="true"
                        :isPageCnt="true"
                    />
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :fields="view1.fields"
                        :columns="view1.columns"
                        :editable="true"
                        :updatable="true"
                        :isGridReSize="true"
                    />
                    <TCComPaging
                        :totalPage="gridData1.totalPage"
                        :apiFunc="getPolUpLstListByPolYmList"
                        :rowCnt="rowCnt"
                        :gridObj="gridObj1"
                        @input="chgRowCnt1"
                    />
                    <BasPdmOperMdlUprcTbltnChgMgmtPopup
                        v-if="showOperMdl"
                        :parentParam="operMdlParam"
                        :rows="resultOperMdlRows"
                        :dialogShow.sync="showOperMdl"
                    />
                </template>
                <template #Template2>
                    <TCRealGridHeader
                        id="gridHeader2"
                        ref="gridHeader2"
                        gridTitle="일반상품단가표목록"
                        :gridObj="gridObj2"
                        :isPageRows="true"
                        :isPageCnt="true"
                    />
                    <TCRealGrid
                        id="grid2"
                        ref="grid2"
                        :fields="view2.fields"
                        :columns="view2.columns"
                        :editable="true"
                        :updatable="true"
                        @hook:mounted="tabGridMounted"
                        :isGridReSize="true"
                    />
                    <TCComPaging
                        :totalPage="gridData2.totalPage"
                        :apiFunc="getGnrlProdPolUpLstByPolYmList"
                        :rowCnt="rowCnt"
                        :gridObj="gridObj2"
                        @input="chgRowCnt2"
                    />
                    <BasPdmGnrlMdlUprcTbltnChgMgmtPopup
                        v-if="showGnrlMdl"
                        :parentParam="gnrlMdlParam"
                        :rows="resultGnrlMdlRows"
                        :dialogShow.sync="showGnrlMdl"
                    />
                </template>

                <br />
            </TCComTab>
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
// import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
import moment from 'moment'
import _ from 'lodash'
import {
    UPRC_HEADER,
    // OPER_HEADER,
    // GNRL_HEADER,
} from '@/const/grid/bas/pdm/basPdmUprcTbltnMgmtHeader'
import API from '@/api/biz/bas/pdm/basPdmUprcTbltnMgmt'
//====================운영모델단가표 상품 변경관리 팝업====================
import BasPdmOperMdlUprcTbltnChgMgmtPopup from '@/views/biz/bas/pdm/BasPdmOperMdlUprcTbltnChgMgmtPopup'
//=====================================================
//====================일반모델단가표 상품 변경관리 팝업====================
import BasPdmGnrlMdlUprcTbltnChgMgmtPopup from '@/views/biz/bas/pdm/BasPdmGnrlMdlUprcTbltnChgMgmtPopup'
//====================사용자등록팝업====================
// import API from '@/api/biz/bas/usm/basUsmSaleChrgrMgmt'
import CommonMixin from '@/mixins'

export default {
    name: 'BasPdmUprcTbltnMgmt',
    mixins: [CommonMixin],
    props: {},
    components: {
        BasPdmOperMdlUprcTbltnChgMgmtPopup,
        BasPdmGnrlMdlUprcTbltnChgMgmtPopup,
    },
    data() {
        return {
            guideTab: 0,
            guideTab2: 0,
            items: ['Template1', 'Template2'],
            itemName: ['운영모델', '일반상품'],
            gridData1: this.gridSetData(),
            gridData2: this.gridSetData(),
            gridObj1: {},
            gridHeaderObj1: {},
            gridObj2: {},
            gridHeaderObj2: {},
            view1: UPRC_HEADER,
            view2: UPRC_HEADER,
            type: 0,
            tabColor: '',
            textColor: '',
            height: '',
            sliderColor: '',
            centered: false,
            grow: false,
            hideSlider: false,
            vertical: false,
            objAuth: {},
            rowCnt: 15, // 표시할 행의 갯수
            div_search: {
                cal_polYm: this.getToday(),
            },
            showBool: false,
            pageNum: 1,
            pageSize: 10,
            showNext: false,
            showNext2: false,
            //====================운영모델단가표 상품 변경관리팝업====================
            showOperMdl: false,
            operMdlParam: {},
            resultOperMdlRows: [],
            operCountForPolYm: '', //정책연월 단가표 수
            //====================일반모델단가표 상품 변경관리팝업====================
            showGnrlMdl: false,
            gnrlMdlParam: {},
            resultGnrlMdlRows: [],
            gnrlCountForPolYm: '', //정책연월 단가표 수
            //======================================================================
        }
    },
    beforeCreated() {
        console.log('------단가표관리 beforeCreated------')
    },
    beforeUpdate() {
        console.log('------단가표관리 beforeUpdate------')
        this.getPolYmCnt()
    },
    mounted() {
        console.log('------단가표관리 mounted------')
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        this.gridObj1 = this.$refs.grid1
        this.gridHeaderObj1 = this.$refs.gridHeader1
        this.gridObj1.setGridState(true)
        this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

        this.init()

        // 그리드셀 키다운(enter)이벤트
        // this.gridObj1.gridView.onKeyDown = this.onKeyDown

        //페이지 정보
        let pageInfo = {}
        // pageInfo.type = 'noPaging' //페이징이 없는경우
        pageInfo.totalDataCnt = this.gridObj1.dataProvider.getRowCount() // 총건수
        this.gridObj1.setGridIndicator(pageInfo) //순번 셋팅

        let paramObj = {}
        paramObj.pageNum = 1
        paramObj.pageSize = 10

        // 더블클릭 시 등록팝업오픈
        this.gridObj1.gridView.onCellDblClicked = (grid, clickData) => {
            console.log('등록팝업오픈', clickData)
            clearTimeout(this.clickState)
            const jsonData = this.gridObj1.dataProvider.getJsonRow(
                clickData.dataRow
            )
            this.grd_OperList_OnCellDblClick(jsonData)
        }
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt1(val) {
            this.rowCnt = val
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt2(val) {
            this.rowCnt = val
        },
        onActiveTabClick() {},
        tabGridMounted() {
            this.gridObj2 = this.$refs.grid2
            this.gridHeaderObj2 = this.$refs.gridHeader2
            this.gridObj2.setGridState(true)
            // this.gridObj2.gridView.setRowIndicator({ visible: true })
            this.gridObj2.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

            // 그리드셀 키다운이벤트
            // this.gridObj2.gridView.onKeyDown = this.onKeyDown

            // 더블클릭 시 등록팝업오픈
            this.gridObj2.gridView.onCellDblClicked = (grid, clickData) => {
                console.log('등록팝업오픈', clickData)
                clearTimeout(this.clickState)
                const jsonData = this.gridObj2.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                console.log('clicked jsonData : ', jsonData)
                this.grd_GnrlList_OnCellDblClick(jsonData)
            }
        },

        onClick() {
            this.showBool = true
        },

        onSearch(type) {
            console.log('onSearch조회', type)
            this.delIdxs = []
            if (type === 0) {
                this.gridData1.totalPage = 0
                this.getPolUpLstListByPolYmList(1)
                // 0 : 운영모델
            } else if (type === 1) {
                this.gridData2.totalPage = 0
                this.getGnrlProdPolUpLstByPolYmList(1)
                // 1 : 일반상품
            }
        },

        // 운영모델 단가표 조회
        getPolUpLstListByPolYmList(pageNum) {
            let paramObj = {
                prodGrpClCd: '1', // 모델 단가표 구분 - 운영
                polYm: this.div_search.cal_polYm.replaceAll('-', ''),
            }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt

            // 페이징 조회
            API.getPolUpLstListByPolYmList(paramObj).then((result) => {
                console.log('운영모델 단가표 리스트 조회 result : ', result)
                result.gridList.forEach((data) => {
                    if (data.prdMdYn == 'U') {
                        data.prdMdYn = '변경발생'
                    }
                })
                this.gridObj1.setRows(result.gridList)
                // 페이징 관련
                this.gridObj1.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData1 = this.gridSetData() //초기화
                this.gridData1.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj1.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },
        // 일반모델 단가표 조회
        getGnrlProdPolUpLstByPolYmList(pageNum) {
            let paramObj = {
                prodGrpClCd: '2', // 모델 단가표 구분 - 일반
                polYm: this.div_search.cal_polYm.replaceAll('-', ''),
            }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt
            // 페이징 조회
            API.getGnrlProdPolUpLstByPolYmList(paramObj).then((result) => {
                console.log('일반모델 단가표 리스트 조회 result : ', result)
                if (result != undefined) {
                    result.gridList.forEach((data) => {
                        if (data.prdMdYn == 'U') {
                            data.prdMdYn = '변경발생'
                        }
                    })
                    this.gridObj2.setRows(result.gridList)
                    // 페이징 관련
                    this.gridObj2.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData2 = this.gridSetData() //초기화
                    this.gridData2.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj2.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
            })
        },

        onActiveTabChange(tabIdx) {
            console.log('onActiveTabChange: ', tabIdx)
            this.type = tabIdx
            // this.isSms = false
            if (tabIdx === 1) {
                // this.tabGrid()
                // this.isSms = true
                // this.showBool = false
                // this.onSmsSearch()
            } else {
                // this.isSms = true
                // this.showBool = false
                // this.onSearch(tabIdx)
            }
            // this.onSearch(tabIdx)
        },

        // 신규버튼 - 단가표상세 화면 이동
        onNewClick() {
            // 운영상세
            if (this.type == 0) {
                console.log('운영모델')
                // 해당 정책연월의 단가표가 이미 존재하면 신규 생성 불가
                if (this.operCountForPolYm > 0) {
                    this.showTcComAlert(
                        '이미 등록된 운영 모델 단가표가 있습니다.'
                    )
                    return
                }

                let reqParam = {
                    uplstId: '',
                    polYm: this.div_search.cal_polYm.replace('-', ''),
                    hstFlag: 'Y',
                    crudFlag: 'N',
                    popFlag: 'N',
                    rmks: '',
                    disCmpFnshYn: 'N',
                }

                console.log('운영 신규 reqParam : ', reqParam)

                this.$router.push({
                    name: '/bas/pdm/BasPdmOperMdlUprcTbltnDtl',
                    params: { search: reqParam },
                })
            } else {
                //일반상세
                console.log('일반모델')
                // 해당 정책연월의 단가표가 이미 존재하면 신규 생성 불가
                if (this.gnrlCountForPolYm > 0) {
                    this.showTcComAlert(
                        '이미 등록된 일반 모델 단가표가 있습니다.'
                    )
                    return
                }

                let reqParam = {
                    uplstId: '',
                    polYm: this.div_search.cal_polYm.replace('-', ''),
                    hstFlag: 'Y',
                    crudFlag: 'N',
                    popFlag: 'N',
                    rmks: '',
                    disCmpFnshYn: 'N',
                }

                console.log('일반 신규 reqParam : ', reqParam)

                this.$router.push({
                    name: '/bas/pdm/BasPdmGnrlMdlUprcTbltnDtl',
                    params: { search: reqParam },
                })
            }
        },
        /** 특정 정책연월의 단가표 수 조회 */
        getPolYmCnt() {
            let paramObj = {
                prodGrpClCd: '', // 모델 단가표 구분
                polYm: this.div_search.cal_polYm.replaceAll('-', ''),
            }
            if (this.type == 0) {
                console.log('운영모델 - 해당정책연월 단가표 수 카운트')
                paramObj.prodGrpClCd = '1'
                console.log('운영 paramObj : ', paramObj)
                API.getOperUplstIdCntByPolYm(paramObj).then((result) => {
                    console.log('운영 단가표 수 : ', result)
                    this.operCountForPolYm = result
                    return result
                })
            } else {
                console.log('일반모델 - 해당정책연월 단가표 수 카운트')
                paramObj.prodGrpClCd = '2'
                console.log('일반 paramObj : ', paramObj)
                API.getGnrlUplstIdCntByPolYm(paramObj).then((result) => {
                    console.log('일반 단가표 수 : ', result)
                    this.gnrlCountForPolYm = result
                    return result
                })
            }
        },

        // 상품관리 화면 이동
        onProdClick() {
            this.$router.push({
                name: '/bas/pdm/BasPdmProdBrwsMgmt',
                params: { search: this.reqParam },
            })
        },

        // 운영모델단가표 상품변경 관리팝업 오픈
        grd_OperList_OnCellDblClick(jsonData) {
            jsonData.popFlag = 'N'
            this.operMdlParam = jsonData
            console.log('this.operMdlParam', this.operMdlParam)
            this.resultOperMdlRows = []
            const prdMdYn = this.operMdlParam.prdMdYn ?? ''
            console.log('prdMdYn : ', prdMdYn)
            // 상위차수가 존재하는 경우 목록으로 이동
            if (_.isEqual(this.operMdlParam.hstFlag, 'N')) {
                this.$router.push({
                    name: '/bas/pdm/BasPdmOperMdlUprcTbltnDtl',
                    params: { search: this.operMdlParam },
                })
            } else {
                this.showOperMdl = true
            }
        },

        // 운영모델단가표 상품변경 관리팝업 오픈
        grd_OperList_OnCellDblClickOld(jsonData) {
            jsonData.popFlag = 'N'
            this.operMdlParam = jsonData
            console.log('this.operMdlParam', this.operMdlParam)
            this.resultOperMdlRows = []
            const prdMdYn = this.operMdlParam.prdMdYn ?? ''
            console.log('prdMdYn : ', prdMdYn)
            if (prdMdYn == undefined || prdMdYn == '') {
                console.log('go to dtl page')
                this.$router.push({
                    name: '/bas/pdm/BasPdmOperMdlUprcTbltnDtl',
                    params: { search: this.operMdlParam },
                })
            } else if (prdMdYn === '변경발생') {
                console.log('go to popup')
                this.showOperMdl = true
            }
        },

        // 일반모델단가표 상품변경 관리팝업 오픈
        grd_GnrlList_OnCellDblClick(jsonData) {
            jsonData.popFlag = 'N'
            this.gnrlMdlParam = jsonData
            console.log('gnrlMdlParam : ', this.gnrlMdlParam)
            this.resultGnrlMdlRows = []
            const prdMdYn = this.gnrlMdlParam.prdMdYn ?? ''
            console.log('prdMdYn : ', prdMdYn)
            // 상위차수가 존재하는 경우 목록으로 이동
            if (_.isEqual(this.gnrlMdlParam.hstFlag, 'N')) {
                this.$router.push({
                    name: '/bas/pdm/BasPdmGnrlMdlUprcTbltnDtl',
                    params: { search: this.gnrlMdlParam },
                })
            } else {
                this.showGnrlMdl = true
            }
        },

        // 일반모델단가표 상품변경 관리팝업 오픈
        grd_GnrlList_OnCellDblClickOld(jsonData) {
            jsonData.popFlag = 'N'
            this.gnrlMdlParam = jsonData
            console.log('gnrlMdlParam : ', this.gnrlMdlParam)
            this.resultGnrlMdlRows = []
            const prdMdYn = this.gnrlMdlParam.prdMdYn ?? ''
            console.log('prdMdYn : ', prdMdYn)
            if (prdMdYn == undefined || prdMdYn == '') {
                console.log('go to dtl page')
                this.$router.push({
                    name: '/bas/pdm/BasPdmGnrlMdlUprcTbltnDtl',
                    params: { search: this.gnrlMdlParam },
                })
            } else if (prdMdYn === '변경발생') {
                console.log('go to popup')
                this.showGnrlMdl = true
            }
        },

        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },

        // 초기화
        onResetPage() {
            // CommonUtil.clearPage(this.$router)
            let clearDivSearch = {
                cal_polYm: moment().format('YYYY-MM') ?? '',
            }
            if (this.type == 0) {
                // 그리드 초기화
                this.gridData1 = this.gridSetData()
                this.gridObj1.dataProvider.clearRows()
                // 검색조건 초기화
                this.div_search = clearDivSearch
            } else {
                // 그리드 초기화
                this.gridData2 = this.gridSetData()
                this.gridObj2.dataProvider.clearRows()
                // 검색조건 초기화
                this.div_search = clearDivSearch
            }
        },

        // 엔터 키로 조회
        onKeyDown(grid, event) {
            const type = this.type
            const gridObj = type == 0 ? this.gridObj1 : this.gridObj2
            if (event.key == 'Enter') {
                gridObj.gridView.commit()
                this.onSearch(type)
            }
        },
    },
}
</script>
