<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">사용자 정보 업데이트</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <p class="infoTxt">
                        <span class="color-red"
                            >반드시 매월 1회 사용자 정보가 변경된 사항이 없는지
                            검토 후 저장 바랍니다.
                        </span>
                    </p>
                    <!-- SubTit  -->
                    <div class="stitHead pop">
                        <h4 class="subTit">기본정보</h4>
                    </div>
                    <!-- //SubTit -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="사용자명"
                                    v-model="rs_user.userNm"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComDatePicker
                                    calType="D"
                                    v-model="rs_user.modDtm"
                                    labelName="저장일시"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="통합 LoginID"
                                    v-model="rs_user.portalUserId"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-3 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="사용자ID"
                                    v-model="rs_user.userId"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="Swing 무선전화"
                                    v-model="rs_user.repMblPhonNo"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-2 -->
                            <!-- item 2-3 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="사용자 무선전화"
                                    v-model="rs_user.mblPhonNo"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 2-3 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <!--
                    
                    <div class="stitHead pop">
                        <h4 class="subTit">SMS 수신 전화번호 정보</h4>
                    </div>
                    
                    <div class="searchLayer_wrap">
                        
                        <div class="searchform mgt-20">
                            <p class="formTit">공통/정책/재고</p>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 1"
                                    placeholder="01012345678"
                                />
                            </div>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 2"
                                    placeholder="01012345678"
                                />
                            </div>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 3"
                                    placeholder="01012345678"
                                />
                            </div>
                            
                        </div>
                        
                        <div class="searchform vline">
                            <p class="formTit">영업/Happy</p>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 1"
                                    placeholder="01012345678"
                                    disabled
                                />
                            </div>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 2"
                                    placeholder="01012345678"
                                    disabled
                                />
                            </div>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 3"
                                    placeholder="01012345678"
                                    disabled
                                />
                            </div>
                            
                        </div>
                        
                        <div class="searchform vline">
                            <p class="formTit">요금/정산</p>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 1"
                                    placeholder="01012345678"
                                    disabled
                                />
                            </div>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 2"
                                    placeholder="01012345678"
                                    disabled
                                />
                            </div>
                            
                            <div class="formitem div3"></div>
                            
                        </div>
                        
                    </div>
                    
-->
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="onSave"
                            >확인/저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="onClose"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import API from '@/api/biz/bas/usm/basUsmInfoUpdatePopup'
import CommonMixin from '@/mixins'

export default {
    name: 'BasUsmInfoUpdatePopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            calType7: 'DHMP',
            inputValue: '2021-01-01',
            inputValue7: ['2022-03-20', '2022-03-25'],
            sHourVal7: '11',
            eHourVal7: '23',
            sMinuVal7: '50',
            eMinuVal7: '59',
            inputValue2: '2021-02',
            inputValue5: '2022-03-15',
            calType5: 'M',
            endDateVal5: '2022-03-16',
            calType4: 'DHM',
            inputValue4: '2022-03-11',
            inputValue41: '01',
            inputValue42: '59',
            guideTab: 0,
            guideTab2: 0,
            tabItems: ['가상배정', '위탁배정'],
            // gridData: this.gridSetData(),
            objAuth: {},
            // gridObj: {},
            // gridHeaderObj: {},
            // gridObj2: {},
            // gridHeaderObj2: {},
            codeIDView: true,
            codeIDViewVal: '',
            value1: '',

            // view: GRID_D_HEADER,
            radio1: '1',
            radio2: '2',
            checked1: true,
            checked2: false,
            input: '',
            checkbox: true,
            radios: null,
            tab: null,
            itemName: ['판매상세', '수납', '비고'],

            gridStyle: {
                height: '170px', //그리드 높이 조절
            },
            rs_user: {},
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        // this.init()
        this.onSearch()
        // this.gridObj = this.$refs.grid1
        // this.gridHeaderObj = this.$refs.gridHeader1
        // this.gridObj.setRows(SAMPLE_D_DATA)
        // this.gridObj.gridView.onCellClicked = (grid, clickData) => {
        //     alert(clickData.fieldName)
        // }
        // this.gridObj3 = this.$refs.grid3
        // this.gridHeaderObj3 = this.$refs.gridHeader3
        // this.gridObj3.setRows(SAMPLE_DATA)
        // this.gridObj3.gridView.onCellClicked = (grid, clickData) => {
        //     alert(clickData.fieldName)
        // }
    },
    methods: {
        init() {
            // this.gridObj1 = this.$refs.gridPopup1
            // this.gridHeaderObj1 = this.$refs.gridHeaderPopup1
            // this.gridObj2 = this.$refs.gridPopup2
            // this.gridHeaderObj2 = this.$refs.gridHeaderPopup2
            // this.gridData = this.gridSetData()
            // this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            // this.gridObj2.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            // this.gridObj1.setGridState()
            // this.gridObj2.setGridState()
        },
        gridSetData: function () {
            return new CommonGrid(0, 10, '', '')
        },
        //팝업닫기
        onClose: function () {
            this.activeOpen = false
        },

        //조회 버튼
        onSearch() {
            //첫 조회시 표시할 행의 갯수
            // this.ds_condition.pageSize = this.rowCnt
            // this.ds_condition.pageNum = 1 //첫번째 페이지
            // this.gridData1.totalPage = 0 // 이전페이지정보 초기화
            // this.gridData2.totalPage = 0 // 이전페이지정보 초기화
            //API호출
            // this.setAxiosLoadingBar(true) //로딩바 작동
            this.getUserSmsInfo()
        },

        //API 호출
        getUserSmsInfo: function () {
            // console.log('orgLvlCd : ', this.searchAuthOrgTreeParam.orgLvl)
            // console.log('serachGubnCd : ', this.div_search.cmbSchCon)
            // this.gridObj1.setRows()
            // this.gridObj2.setRows()

            let params = {
                userId: this.userInfo.userId,
            }
            // params.pageNum = pageNum
            // params.pageSize = this.rowCnt

            console.log('this.params : ', params)
            API.getUserSmsInfo(params).then((resultData) => {
                this.rs_user = resultData[0]
                // this.indirInfoPraAgreeYn = [
                //     resultData.basUsmCurntUserInfoVo[0].indirInfoPraAgreeYn,
                // ]
                // console.log(
                //     'this.indirInfoPraAgreeYn',
                //     this.indirInfoPraAgreeYn
                // )
                // this.ds_ukey_lst = resultData.basUsmUserUKeyIdVo
                // this.gridObj1.setRows(this.ds_ukey_lst)
                // this.setInitGrid()

                // if (this.ds_user.indirInfoPraAgreeYn == 'Y') {
                //     this.chk_ageeYn.enable = false
                // }

                // if (this.ds_user.userGrpCd == 'D13') {
                //     this.getSaleChrgrDealCoList(1)
                // }
            })
        },

        // 저장이벤트
        async onSave() {
            var sMsg =
                '위 내용과 실제 사용자와의 정보는 일치하며,' +
                '\n불일치로 인한 책임은 사용자에게 있습니다.\n저장하시겠습니까?'

            if (await this.showTcComConfirm(sMsg)) {
                await this.updateUserSmsInfo()
            }
        },

        updateUserSmsInfo() {
            let saveParam = {
                userId: this.rs_user.userId ? this.rs_user.userId : '',
                repMblPhonNo: this.rs_user.repMblPhonNo
                    ? this.rs_user.repMblPhonNo
                    : '',
                mblPhonNo: this.rs_user.mblPhonNo ? this.rs_user.mblPhonNo : '',
            }

            API.updateUserSmsInfo(saveParam)
                .then((result) => {
                    console.log('result : ', result)
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    // 매핑정보 재조회
                    this.onClose()
                })
                .catch((error) => {
                    this.showTcComAlert('저장에 실패했습니다.')
                    throw error
                    // 매핑정보 재조회
                    // this.onSearch()
                })
        },
    },
}
</script>
