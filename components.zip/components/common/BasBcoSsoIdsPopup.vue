<!-----------------------------------------------
 * 업무그룹명: 기준정보>통합 SSO ID
 * 서브업무명: 통합 SSO ID
 * 설명: 통합 SSO ID Popup 컴포넌트
 * 작성자: 양현모
 * 작성일: 2022.05.02
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpenSsoIds" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">통합 SSO ID 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParam.loginUserId"
                                    labelName="통합 ID"
                                    :objAuth="objAuth"
                                    :disabled="isDisabledLoginUserId"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="searchParam.userId"
                                    labelName="사용자 ID"
                                    :objAuth="objAuth"
                                    :disabled="isDisabledUserId"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4"></div>
                            <!-- // input -->
                            <!-- item 2-4 -->
                            <div class="formitem div4">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">검색 결과</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="ssoIdsGrid"
                                ref="ssoIdsGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                                @hook:mounted="gridMounted"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { BAS_BCO_SSO_IDS_HEADER } from '@/const/grid/bas/bco/basBcoSsoIdsHeader'
import basBcoSsoIdsApi from '@/api/biz/bas/bco/basBcoSsoIds'
import commonApi from '@/api/common/commonCode'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'BasBcoSsoIdsPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: BAS_BCO_SSO_IDS_HEADER,
            //showAlertBool: false,
            //alertBodyText: '',
            headerText: '',
            searchParam: {
                userId: '', // 사용자 ID
                userNm: '', // 사용자 명
                loginUserId: '', // 통합 ID
            },
            isDisabledLoginUserId: false,
            isDisabledUserId: false,
        }
    },
    computed: {
        activeOpenSsoIds: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchParam.loginUserId =
                    value['loginUserId'] == undefined
                        ? ''
                        : value['loginUserId']
                this.searchParam.userNm =
                    value['userNm'] == undefined ? '' : value['userNm']
                this.searchParam.userId =
                    value['userId'] == undefined ? '' : value['userId']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },
    mounted() {
        this.gridObj = this.$refs.ssoIdsGrid // Grid Object 설정
        this.initGrid()
        //컬럼전체채우기
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
    },
    methods: {
        init() {
            this.gridData = this.gridSetData()
            if (!_.isEmpty(this.searchParam.loginUserId)) {
                this.isDisabledLoginUserId = true
            }

            if (!_.isEmpty(this.searchParam.userId)) {
                this.isDisabledUserId = true
            }
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false)
            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },

        gridMounted() {
            console.log('gridMounted')
        },

        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        getSsoIdsList() {
            basBcoSsoIdsApi.getSsoIdsList(this.searchParam).then((res) => {
                console.log('getSsoIdsList then : ', res)
                this.gridObj.setRows(res)
            })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('통합 SSO ID를 선택해주세요.', {
                    header: '통합 SSO ID 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenSsoIds = false
        },

        onSearch() {
            if (
                _.isEmpty(this.searchParam.loginUserId) &&
                _.isEmpty(this.searchParam.userId)
            ) {
                this.showTcComAlert('통합 ID 또는 사용자 ID를 입력해주세요.', {
                    header: '검색조건 필수',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            this.getSsoIdsList()
        },

        onEnterKey() {
            this.onSearch()
        },
    },
}
</script>
