<template>
    <div class="searchLayer_wrap mt20 heightFix">
        <!-- gridWrap -->
        <div class="searchform">
            <div class="formitem div1">
                <TCComTextArea
                    v-model="selectedRow1.execCondDesc"
                    labelName="조회조건"
                    class="boxtype"
                    :readonly="true"
                    :rows="5"
                ></TCComTextArea>
            </div>
        </div>
        <div class="searchform">
            <div class="formitem div1">
                <!-- arrayType -->
                <div class="arrayType">
                    <div class="colTxtarea">
                        <TCComInput
                            v-model="selectedRow1.fileNm"
                            labelName="파일정보"
                            :objAuth="objAuth"
                            :disabled="true"
                        />
                    </div>
                    <div class="col0 colbtn">
                        <em>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_xs btn_ty05"
                                labelName="다운로드"
                                @click="clickDownload"
                            />
                        </em>
                    </div>
                </div>
                <!-- //arrayType -->
                <!-- <div class="content80">
                        <TCComInput
                            v-model="selectedRow1.fileNm"
                            labelName="파일정보"
                            :objAuth="objAuth"
                            :disabled="true"
                        ></TCComInput>
                    </div> -->
            </div>
            <!-- <div class="contentdownbutton">
                    <div class="formitem div5">
                        <div class="btn_area_bottom">
                            <TCComButton
                                :eLarge="true"
                                eClass="btn_ty02"
                                @click="clickDownload"
                            >
                                다운로드
                            </TCComButton>
                        </div>
                    </div>
                </div> -->
        </div>
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/odm/ondemandMt/ondemandOperBrws/helpers'
import CommonMixin from '@/mixins'
// eslint-disable-next-line no-unused-vars
import * as xlsx from 'xlsx'
import attachedFileApi from '@/api/common/attachedFile'
// import axios from 'axios'
export default {
    mixins: [CommonMixin],
    components: {},
    data() {
        return {
            objAuth: {},
            context: '',
            reservedDtm: '',
            data1: [
                {
                    test1: 'test1',
                    test2: 'test1',
                    test3: 'test1',
                    test4: '현재 테스트 파일입니다.',
                },
            ],
        }
    },
    computed: {
        ...serviceComputed,
        selectedRow1: {
            get() {
                return this.selectedRow
            },
        },
    },
    methods: {
        ...serviceMethods,
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        async saveDownloadDone() {
            //api update
            let saveRows = []
            saveRows.push({ ...this.selectedRow1, rowState: 'updated' })
            let res1 = await this.saveOndemandOperBrws_({ saveRows })
            this.loading(false)
            if (res1 == 1) {
                this.toasting_({
                    message: '정상처리 되었습니다.',
                })
                //저장후 다시 조회 하는 경우
                this.$emit('Refresh', '')
            }
        },
        async clickDownload() {
            console.log('url', this.selectedRow1.url)
            console.log('selectedRow1', this.selectedRow1)

            if (
                this.selectedRow1.execStCd === '02' ||
                this.selectedRow1.execStCd === '03'
            ) {
                var downloadFileParam = {
                    screenId: this.selectedRow1.screenId,
                    docId: this.selectedRow1.docId,
                    filePathNm: this.selectedRow1.url,
                    fileNm: this.selectedRow1.fileNm,
                    fileType: this.selectedRow1.fileType,
                }
                console.log('downloadFileParam', downloadFileParam)
                this.downloadFile(downloadFileParam)
            } else {
                this.showTcComAlert(
                    '처리완료건, 다운로드완료건만 다운로드 가능합나디.'
                )
            }

            return false
            // this.downloadFile(downloadFileParam)
            // return false
            // const workBook = xlsx.utils.book_new()
            // const workSheet = xlsx.utils.json_to_sheet(this.data1)
            // xlsx.utils.book_append_sheet(workBook, workSheet, 'example')
            //xlsx.writeFile(workBook, `${this.selectedRow1.fileNm}.xlsx`)
            //  attachedFileApi.downloadSampleFile('500')
            // const url1 = `/api/v1/backend-max/resource/bas/odm/download/BASODM00100/${this.selectedRow1.fileNm}_${this.selectedRow1.docId}.csv` //real file:AS-IS
            //const url1 = `/api/v1/backend-max/resource/bas/odm/download/BASODM00100/${'ACCODM08201_AE1100_20220201080102'}.xlsx` //test file
            // axios({
            //     url: url1,
            //     method: 'get',
            //     responseType: 'blob',
            // })
            //     .then((res) => {
            //         console.log('res: ', res)
            //         attachedFileApi.downloadLink(res)
            //         this.saveDownloadDone()
            //     })
            //     .catch((err) => {
            //         console.log('err: ', err)
            //         this.showTcComAlert(
            //             '다운로드 파일이 없거나 오류가 발생하였습니다.'
            //         )
            //     })
        },
        downloadFile(downloadFileParam) {
            attachedFileApi
                .downLoadFile(
                    '/api/v1/backend/resource/common/file-download',
                    downloadFileParam
                )
                .then((res) => {
                    console.log('res: ', res)
                    // attachedFileApi.downloadLink(res)
                    //에러발생시 update되면 안댐
                    if (res !== false) {
                        // this.saveDownloadDone()
                        // this.showTcComAlert('에러발생 ')
                        this.saveDownloadDone()
                    }
                })
                .catch((err) => {
                    console.log('err: ', err)
                    this.showTcComAlert(
                        '다운로드 파일이 없거나 오류가 발생하였습니다.'
                    )
                })
        },
    },
}
</script>

<style>
/* .content80 {
    width: 90%;
    display: inline-block;
}
.contentdownbutton {
    margin-left: -15px;
} */
</style>
