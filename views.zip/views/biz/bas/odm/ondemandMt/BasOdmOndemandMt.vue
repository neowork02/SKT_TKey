<!-----------------------------------------------
 * 업무그룹명: 기준정보>기타
 * 서브업무명: 대용량자료요청
 * 설명: 대용량자료요청 조회/입력/수정/삭제 한다.
 * 작성자: P180392
 * 작성일: 2022.06.28
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>대용량자료요청</h1>
        <!-- // Tit -->
        <TCComTab
            :tab.sync="guideTab"
            :items="items"
            :itemName="itemName"
            :tabColor="tabColor"
            :textColor="textColor"
            :centered="centered"
            :grow="grow"
            :height="height"
            :hideSlider="hideSlider"
            :sliderColor="sliderColor"
            :vertical="vertical"
            @change="onActiveTabChange"
            sliderSize="8"
        >
            <template #Template1><main-content0 /></template>
            <template #Template2><main-content1 /></template>
        </TCComTab>
    </div>
</template>

<script>
import MainContent0 from './ondemandOperBrws/BasOdmOndemandOperBrws.vue'
import MainContent1 from './ondemandMgmt/BasOdmOndemandMgmt.vue'

export default {
    name: 'BasOdmOndemandMt',
    created() {},
    beforeDestroy() {},
    components: {
        MainContent0,
        MainContent1,
    },
    data() {
        return {
            guideTab: 0,
            items: ['Template1', 'Template2'],
            itemName: ['OnDemand작업조회', 'OnDemand관리'],
            tabColor: '',
            textColor: '',
            height: '',
            sliderColor: '',
            centered: false,
            grow: false,
            hideSlider: false,
            vertical: false,
        }
    },
    computed: {},
    methods: {
        // eslint-disable-next-line no-unused-vars
        onActiveTabChange(tabIdx) {},
    },
}
</script>

<style>
.content1 {
    display: flex;
    height: 800px;
    gap: 1em;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
}
</style>
