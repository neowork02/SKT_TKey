import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields0: [
        {
            fieldName: 'saleYm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'policyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'policyType',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'accAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'payYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns0: [
        {
            name: 'saleYm',
            fieldName: 'saleYm',
            type: 'data',
            header: { text: '영업월' },
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'policyNm',
            fieldName: 'policyNm',
            type: 'data',
            header: { text: '정책명' },
            width: '300',
        },
        {
            name: 'policyType',
            fieldName: 'policyType',
            type: 'data',
            header: { text: '정책유형' },
            width: '150',
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점코드' },
            width: '200',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: {
                text: '대리점명',
                excelName: '대리점명',
            },
            width: '150',
        },
        {
            name: 'cnt',
            fieldName: 'cnt',
            type: 'data',
            header: { text: '처리건수' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'accAmt',
            fieldName: 'accAmt',
            type: 'data',
            header: { text: '정산금액' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'payYn',
            fieldName: 'payYn',
            type: 'data',
            header: { text: '지급여부' },
            width: '150',
        },
    ],

    fields1: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payItmId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payItmNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleYm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'totAccAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prMnyChainCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prMnyChainNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prMnyExtrtMthdCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prMnyExtrtMthdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prMnyGrpNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns1: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점코드' },
            width: '150',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: { text: '대리점명' },
            width: '200',
        },
        {
            name: 'payItmId',
            fieldName: 'payItmId',
            type: 'data',
            header: { text: '정산항목ID' },
            width: '150',
        },

        {
            name: 'payItmNm',
            fieldName: 'payItmNm',
            type: 'data',
            header: {
                text: '정산항목명',
                excelName: '정산항목명',
            },
            width: '150',
        },
        {
            name: 'saleYm',
            fieldName: 'saleYm',
            type: 'data',
            header: { text: '영업년월' },
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'payYn',
            fieldName: 'payYn',
            type: 'data',
            header: { text: '지급여부' },
            width: '150',
        },
        {
            name: 'totAccAmt',
            fieldName: 'totAccAmt',
            type: 'data',
            header: { text: '인센티브' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        // {
        //     name: 'prMnyChainCd',
        //     fieldName: 'prMnyChainCd',
        //     type: 'data',
        //     header: { text: '정책계열' },
        //     width: '150',
        //     footer: {
        //         text: '합계',
        //     },
        // },
        // {
        //     name: 'prMnyChainNm',
        //     fieldName: 'prMnyChainNm',
        //     type: 'data',
        //     header: { text: '정책계열명' },
        //     width: '150',
        //     footer: {
        //         text: '합계',
        //     },
        // },
        // {
        //     name: 'prMnyExtrtMthdCd',
        //     fieldName: 'prMnyExtrtMthdCd',
        //     type: 'data',
        //     header: { text: '추출방법' },
        //     width: '150',
        //     footer: {
        //         text: '합계',
        //     },
        // },
        // {
        //     name: 'prMnyExtrtMthdNm',
        //     fieldName: 'prMnyExtrtMthdNm',
        //     type: 'data',
        //     header: { text: '추출방법명' },
        //     width: '150',
        //     footer: {
        //         text: '합계',
        //     },
        // },
        {
            name: 'prMnyGrpNm',
            fieldName: 'prMnyGrpNm',
            type: 'data',
            header: { text: '정산항목그룹명' },
            width: '150',
            footer: {
                text: '합계',
            },
        },
    ],
    fields2: [
        {
            fieldName: 'accYm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlOperNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlPayItmCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlPayItmNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'psErpGrpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'psErpCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'psErpNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'psSettlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dcd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'subCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'taxInvoiceDt',
            dataType: ValueType.TEXT,
        },
    ],
    columns2: [
        {
            name: 'accYm',
            fieldName: 'accYm',
            type: 'data',
            header: { text: '정산월' },
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'settlOperNm',
            fieldName: 'settlOperNm',
            type: 'data',
            header: { text: '정산작업구분' },
            width: '150',
        },
        {
            name: 'settlPayItmCd',
            fieldName: 'settlPayItmCd',
            type: 'data',
            header: { text: '정산항목ID' },
            width: '100',
        },
        {
            name: 'settlPayItmNm',
            fieldName: 'settlPayItmNm',
            type: 'data',
            header: { text: '정산항목명' },
            width: '200',
        },
        //  정산작업구분과 중복되어 주석처리함.
        // {
        //     name: 'psErpGrpCd',
        //     fieldName: 'psErpGrpCd',
        //     type: 'data',
        //     header: {
        //         text: '구분코드',
        //     },
        //     width: '100',
        // },
        {
            name: 'psSettlNm',
            fieldName: 'psSettlNm',
            type: 'data',
            header: { text: '정산항목구분명' },
            width: '120',
        },
        //  정산항목명과 중복되어 주석처리함.
        // {
        //     name: 'psErpCd',
        //     fieldName: 'psErpCd',
        //     type: 'data',
        //     header: { text: '정산항목구분세부코드' },
        //     width: '100',
        //     visible: false,
        // },
        // {
        //     name: 'psErpNm',
        //     fieldName: 'psErpNm',
        //     type: 'data',
        //     header: { text: '정산항목구분세부명' },
        //     width: '150',
        // },
        {
            name: 'dcd',
            fieldName: 'dcd',
            type: 'data',
            header: { text: 'D코드' },
            width: '100',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'subCd',
            fieldName: 'subCd',
            type: 'data',
            header: { text: '서브점' },
            width: '100',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            header: { text: '공급가' },
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            header: { text: '부가세' },
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'taxInvoiceDt',
            fieldName: 'taxInvoiceDt',
            type: 'data',
            header: { text: '세금계산서발행일자' },
            width: '100',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
    fields3: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'deductCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'deductNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'deductAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'fixDeductAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns3: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점' },
            width: '150',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: { text: '대리점명' },
            width: '150',
        },
        {
            name: 'deductCd',
            fieldName: 'deductCd',
            type: 'data',
            header: { text: '공제항목코드' },
            width: '150',
        },
        {
            name: 'deductNm',
            fieldName: 'deductNm',
            type: 'data',
            header: { text: '공제항목명' },
            width: '200',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'deductAmt',
            fieldName: 'deductAmt',
            type: 'data',
            header: {
                text: '공제대상금액',
            },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'fixDeductAmt',
            fieldName: 'fixDeductAmt',
            type: 'data',
            header: { text: '공제확정금액' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
    ],
}
