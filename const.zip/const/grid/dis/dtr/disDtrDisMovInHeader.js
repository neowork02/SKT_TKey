import { ValueType } from 'realgrid'

export const DisDtrDisMovInGRID_HEADER = {
    fields: [
        {
            fieldName: 'outOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outFixDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'outFixQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'inFixQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inFixYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inOrgCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'inOrgNm',
            fieldName: 'inOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고조직',
                showTooltip: false,
            },
            width: '400',
        },
        {
            name: 'inDealSktCd',
            fieldName: 'inDealSktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'inFixDt',
            fieldName: 'inFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
            width: '100',
        },
        {
            name: 'inFixQty',
            fieldName: 'inFixQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고수량',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'inFixYn',
            fieldName: 'inFixYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고완료',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outOrgNm',
            fieldName: 'outOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고조직',
                showTooltip: false,
            },
            width: '400',
        },
        {
            name: 'outDealcoCd',
            fieldName: 'outDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처',
                showTooltip: false,
            },
            width: '150',
        },
        {
            name: 'outFixDt',
            fieldName: 'outFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
            width: '100',
        },
        {
            name: 'outFixQty',
            fieldName: 'outFixQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고수량',
                showTooltip: false,
            },
            width: '100',
        },
        {
            name: 'outMgmtNo',
            fieldName: 'outMgmtNo',
            visible: false,
            type: 'data',
        },
        {
            name: 'outOrgCd',
            fieldName: 'outOrgCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'inOrgCd',
            fieldName: 'inOrgCd',
            visible: false,
            type: 'data',
        },
    ],
}
