<template>
    <TCComDialog :dialogShow.sync="SearchUserPop" size="1000px">
        <template #content>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
            <div class="layerPop overflow-y-auto">
                <div class="layerCont">
                    <div class="contBoth mgt-20">
                        <TCRealGridHeader
                            id="gridHeader"
                            ref="gridHeader"
                            gridTitle="지정대상자 읽음 여부"
                            :gridObj="gridObj"
                        />
                        <TCRealGrid
                            id="grid"
                            ref="grid"
                            :editable="true"
                            :movable="false"
                            :columnMovable="false"
                            :fields="view.fields"
                            :columns="view.columns"
                            :isGridReSize="true"
                        />
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            :objAuth="objAuth"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import { USER_SEARCH_HEADER } from '@/const/grid/bas/bbs/basBbsMgmtHeader'
import searchUserApi from '@/api/biz/bas/bbs/basBbsMgmt'
export default {
    name: 'SearchUserPop',
    mixins: [CommonMixin],
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },

        popupParams: { type: Object, default: () => [], required: false },
    },
    data() {
        return {
            gridObj: {},
            gridData: {},
            gridHeaderObj: {},
            gridObj1: {},
            gridData1: {},
            gridHeaderObj1: {},
            objAuth: {},
            forms: {
                bbsNo: '',
                bbsTypeCd: '',
                bbsTargetUser: '',
                viewYn: '',
                viewDtm: '',
            },
            gridList: [],
            showAlertBool: false,
            headerText: '',
            alertBodyText: '',
            view: USER_SEARCH_HEADER,
            showBool: false,
        }
    },
    computed: {
        SearchUserPop: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },

    created() {},
    mounted() {
        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, false, false, false)

        this.getSearchUserList()

        console.log('bbsTypeCd', this.forms.bbsTypeCd)
    },
    methods: {
        init: function () {
            this.gridData = this.gridSetData()
        },
        getSearchUserList() {
            searchUserApi
                .getSearchUserList(this.popupParams)
                .then((resultData) => {
                    this.gridList = resultData
                    if (this.gridList.length) {
                        for (let i = 0; i < this.gridList.length; i++) {
                            if (this.gridList[i].bbsTypeCd == 'S') {
                                //console.log('::::::::::', rowData)
                                this.gridList[i].bbsTypeCd = '소매'
                            } else if (this.gridList[i].bbsTypeCd == 'D') {
                                this.gridList[i].bbsTypeCd = '도매'
                            } else if (this.gridList[i].bbsTypeCd == 'B') {
                                this.gridList[i].bbsTypeCd = '대형'
                            }
                        }
                    }
                    if (this.gridList.length) {
                        for (let i = 0; i < this.gridList.length; i++) {
                            if (
                                this.gridList[i].viewDtm ==
                                '0000-00-00 00:00:00'
                            ) {
                                //console.log('::::::::::', rowData)
                                this.gridList[i].viewDtm = ''
                            }
                        }
                    }
                    this.gridObj.setRows(this.gridList)
                    console.log('resultData', this.gridObj)
                })
        },
        onClose() {
            this.SearchUserPop = false
        },
    },
}
</script>
