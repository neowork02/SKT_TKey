import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('tkp.uki.nsokRcvLstStore', Object.keys(state)),
    ...mapGetters('tkp.uki.nsokRcvLstStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('tkp.uki.nsokRcvLstStore', Object.keys(actions)),
    ...mapMutations('tkp.uki.nsokRcvLstStore', Object.keys(mutations)),
}
