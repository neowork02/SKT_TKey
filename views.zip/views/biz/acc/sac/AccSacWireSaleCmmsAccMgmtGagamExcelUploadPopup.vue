<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1600px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">수수료 가감 엑셀업로드</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="searchParams.searchOrgCd"
                                    :codeVal.sync="searchParams.searchOrgNm"
                                    :disabled="true"
                                    :disabledAfter="true"
                                    labelName="조직"
                                >
                                </TCComInputSearchText>
                            </div>
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="M"
                                    v-model="searchParams.searchAccYm_"
                                    labelName="정산월"
                                    disabled="disabled"
                                >
                                </TCComDatePicker>
                            </div>
                            <div class="formitem div4">
                                <TCComButton
                                    :Vuetify="false"
                                    eClass="btn_noline btn_ty04"
                                    eAttr="ico_exeldown"
                                    labelName="양식다운로드"
                                    @click="onDownExcelUpTemplate"
                                ></TCComButton>
                                <v-file-input
                                    id="excelFileGagam"
                                    ref="excelFileGagam"
                                    label="엑셀업로드 파일선택(숨김)"
                                    style="display: none"
                                    @change="onChangeExcelFileGagam"
                                ></v-file-input>
                            </div>
                            <!-- // input -->
                            <!-- item 2-4 -->
                            <div class="formitem div4">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="초기화"
                                            :objAuth="objAuth"
                                            @click="onReset"
                                        >
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridGagamHeader1"
                                ref="gridGagamHeader1"
                                gridTitle="수수료 가감"
                                :gridObj="gridObj1"
                                :isExcelup="true"
                                @excelUploadBtn="onSelectExcelFileGagam"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="gridGagam1"
                                ref="gridGagam1"
                                :editable="false"
                                :fields="view.fields1"
                                :columns="view.columns1"
                                :styles="gridStyle"
                            />
                            <p class="infoTxt">
                                <span class="color-red"
                                    >수수료가감항목코드 :
                                    A01(Grade),A02(불편법영업환수),A04(명의도용환수),A05(파파라치환수),A06(CIA환수),A07(기타)<br />
                                    <span style="padding-left: 105px"></span
                                    >A08(Infra정책),A09(정산오류보정),A10(자동이체미유치)</span
                                >
                            </p>
                        </div>
                        <!-- //gridWrap -->
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridGagamHeader2"
                                ref="gridGagamHeader2"
                                gridTitle="오류데이터"
                                :gridObj="gridObj2"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="gridGagam2"
                                ref="gridGagam2"
                                :gridObj="gridObj2"
                                :editable="false"
                                :fields="view.fields2"
                                :columns="view.columns2"
                                :styles="gridStyle"
                            />
                            <TCRealGridHeader
                                v-show="false"
                                id="gridGagamHeader3"
                                ref="gridGagamHeader3"
                                gridTitle="엑셀업로드 양식다운로드(숨김)"
                                :gridObj="gridObj3"
                            />
                            <TCRealGrid
                                v-show="false"
                                id="gridGagam3"
                                ref="gridGagam3"
                                :gridObj="gridObj3"
                                :fields="view.fields3"
                                :columns="view.columns3"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onSave"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
import CommonMixin from '@/mixins'
import sacApi from '@/api/biz/acc/sac'
import commonApi from '@/api/common/prototype'
import attachApi from '@/api/common/attachedFile'
import { AccUtil } from '@/views/biz/acc'
import { AccExcelUpload } from '@/views/biz/acc'
// import sacApi from '@/api/biz/acc/sac'
import { GRID_HEADER } from '@/const/grid/acc/sac/accSacWireSaleCmmsAccMgmtGagamExcelUploadPopupGrid'

export default {
    name: 'AccSacWireSaleCmmsAccMgmtGagamExcelUploadPopup',
    title: '수수료 가감 엑셀업로드',
    mixins: [CommonMixin],
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list1: [], // 엑셀업로드 그리드 목록
            list2: [], // 오류데이터 그리드 목록
            list3: [
                {
                    accDealcoCd: '100240',
                    accDealcoNm: '블루',
                    saleDealcoCd: '',
                    saleDealcoNm: '',
                    addSubItmNm: 'A01',
                    cmmsAddSubRsn: '21.12월 후불차이금액',
                    addSubAmt: '5000',
                    saleMthClNm: '1',
                    saleDt: '20220201',
                    custNm: '홍길동',
                    svcNum: '010-3333-4444',
                    svcMgmtNum: '232',
                    prodNm: 'T-1000',
                    serNum: '12345',
                    rmks: '이관중',
                },
                {
                    accDealcoCd: '100254',
                    accDealcoNm: '준텔레콤',
                    saleDealcoCd: 'A220998',
                    saleDealcoNm: 'HJ네트웍스',
                    addSubItmNm: 'A02',
                    cmmsAddSubRsn: '21.11월 후불차이금액',
                    addSubAmt: '900',
                    saleMthClNm: '2',
                    saleDt: '20220303',
                    custNm: '홍길동',
                    svcNum: '010-2222-4444',
                    svcMgmtNum: '2322',
                    prodNm: 'T-2000',
                    serNum: '1234556',
                    rmks: '테스트중',
                },
                {
                    accDealcoCd: '100289',
                    accDealcoNm: '나은',
                    saleDealcoCd: 'A220998',
                    saleDealcoNm: 'HJ네트웍스',
                    addSubItmNm: 'A03',
                    cmmsAddSubRsn: '21.10월 후불차이금액',
                    addSubAmt: '1100',
                    saleMthClNm: '2',
                    saleDt: '',
                    custNm: '이순신',
                    svcNum: '010-2222-1111',
                    svcMgmtNum: '2322',
                    prodNm: 'T-2000',
                    serNum: '123456789a123456789a123456789a123456789a123456789a',
                    rmks: '테스트중2',
                },
            ], // 엑셀업로드양식다운로드 그리드 목록(테스트용)
            listAccDealco: [],
            gridObj1: {},
            gridObj2: {},
            gridObj3: {},
            gridHeaderObj1: {},
            gridHeaderObj2: {},
            gridHeaderObj3: {},
            gridStyle: { height: '180px' },
            code: {
                // 수수료구분
                addSubItmCd: {
                    id: 'WIRE_CMMS_ADD_SUB_ITM_CD',
                    list: [],
                },
                saleMthClCd: {
                    1: '이전월',
                    2: '당월',
                },
            },
            paramJson: {},
            searchParams: {
                searchPageType: 'GAGAM-POPUP',
                searchQueryMode: 'EXCEL_UPLOAD',
                searchOrgCd: this.popupParams.searchOrgCd,
                searchOrgNm: this.popupParams.searchOrgNm,
                searchOrgLvl: this.popupParams.searchOrgLvl,
                searchLvOrgCd: this.popupParams.searchLvOrgCd,
                searchAccYm_: this.popupParams.searchAccYm_,
                searchAccYm: this.popupParams.searchAccYm,
                checkedRows: [],
            },
            requiredExcelGrid: {
                accDealcoCd: '정산처코드',
                addSubItmCd: '수수료구분',
                addSubAmt: '금액',
                saleMthClCd: '영업월',
            },
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        console.log('mounted')

        // 수수료구분 combo 목록 세팅하기
        this.setComboAddSubItmCd()

        // 엑셀업로드 Grid 기본세팅
        this.gridObj1 = this.$refs.gridGagam1
        this.gridHeaderObj1 = this.$refs.gridGagamHeader1
        this.gridObj1.setGridState(false, false, false)

        // 오류데이터 Grid 기본세팅
        this.gridObj2 = this.$refs.gridGagam2
        this.gridHeaderObj2 = this.$refs.gridGagamHeader2
        this.gridObj2.setGridState(false, false, false)

        // 엑셀양식다운로드 Grid 기본세팅(Hiddend)
        this.gridObj3 = this.$refs.gridGagam3
        this.gridHeaderObj3 = this.$refs.gridGagamHeader3
        this.gridObj3.setGridState(false, false, false)
        this.gridObj3.setRows(this.list3)
    },
    methods: {
        setGetParamJson: function () {
            this.paramJson = _.cloneDeep(this.searchParams)

            // get방식으로 파라미터 넘길 때 오류로 인해 아래 제거함
            delete this.paramJson['checkedRows']

            return this.paramJson
        },
        /* DB에서 처리할 수 있게 row데이터를 가공해서 return */
        getChangeRowData: function (rowData) {
            // 목록에 정산월 추가
            rowData.accYm = this.searchParams.searchAccYm

            // 판매일 날짜를 String으로 변경한다.
            if (!AccUtil.isEmpty(rowData.saleDt)) {
                rowData.saleDt = rowData.saleDt.replace(/-/g, '')
            }

            return rowData
        },
        onReset: function () {
            this.list1 = []
            this.list2 = []
            this.gridObj1.setRows(this.list1)
            this.gridObj2.setRows(this.list2)
        },
        onClose: function () {
            this.$parent.onSearch()
            this.activeOpenAgency = false
        },
        onSave: function () {
            if (this.onSaveValidate() == false) {
                return
            }

            // 엑셀업로드 그리드의 목록 세팅
            this.searchParams.checkedRows = _.cloneDeep(this.list1)

            // 저장할 데이터 가공하기
            this.searchParams.checkedRows.map((json) => {
                return this.getChangeRowData(json)
            })

            sacApi
                .saveAccSacWireSaleCmmsAccMgmtList(this.searchParams)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        this.showTcComAlert('저장되었습니다.')
                        this.onReset()
                    }
                })
        },
        onSaveValidate: function () {
            if (_.isEmpty(this.list1) || this.list1.length == 0) {
                this.showTcComAlert('저장할 목록이 없습니다.')
                return false
            }

            return true
        },
        onDownExcelUpTemplate: function () {
            attachApi.downloadSampleFile('422') //  수수료가감엑셀업로드양식
            // this.gridHeaderObj3.exportGrid('수수료가감엑셀업로드양식.xlsx')
        },
        onSelectExcelFileGagam: function () {
            document.getElementById('excelFileGagam').click()
        },
        onChangeExcelFileGagam: function (f) {
            var tabNum = 2
            var pageType = 'wire'
            AccExcelUpload.onChange(
                pageType,
                tabNum,
                f,
                this.view.columns3,
                this.onReset,
                this.callbackExcelUploadGagam
            )
        },
        /**
         * 엑셀업로드 파일을 선택한 이후에 실행되는 callback 함수
         */
        callbackExcelUploadGagam: function (list) {
            // validate체크하여 정상인 경우 list에 push, 아닌 경우 list2에 push한다.
            if (list) {
                // 정산처/ERP확정여부 목록 조회
                this.listAccDealco = []
                this.searchParams.checkedRows = list
                this.gridObj1.gridView.commit()
                sacApi
                    .getAccSacWireSaleCmmsAccMgmtAccDealcoList(
                        this.searchParams
                    )
                    .then((resultData) => {
                        this.listAccDealco = resultData
                        this.callbackExcelUploadValidateGagam(list)
                    })
            }

            document.getElementById('excelFileGagam').value = ''
        },
        /**
         * 엑셀업로드 파일을 선택한 이후에 validation 체크
         */
        callbackExcelUploadValidateGagam: function (list) {
            // validate체크하여 정상인 경우 list에 push, 아닌 경우 list2에 push한다.
            this.list1 = []
            this.list2 = []

            for (var i = 0; i < list.length; i++) {
                list[i].amt = list[i].addSubAmt

                // 수수료구분 컬럼에 코드값을 코드명으로 변경한다.
                list[i].addSubItmCd = list[i].addSubItmNm
                var tCodeList = this.code.addSubItmCd.list
                if (!AccUtil.isEmpty(tCodeList)) {
                    var addSubItmNm = ''
                    var isExistsAddSubItmCd = tCodeList.some((data) => {
                        addSubItmNm = data.commCdValNm
                        return data.commCdVal == list[i].addSubItmCd
                    })
                    if (isExistsAddSubItmCd) {
                        list[i].addSubItmNm = addSubItmNm
                    }
                }

                // 영업월(1:이전월, 2:당월) 컬럼의 코드값을 코드명으로 변경한다.
                list[i].saleMthClCd = list[i].saleMthClNm
                list[i].saleMthClNm = this.code.saleMthClCd[list[i].saleMthClCd]

                // 필수항목 체크
                var checkRequired = AccExcelUpload.getCheckRequired(
                    list[i],
                    this.requiredExcelGrid
                )
                if (checkRequired.isPass == false) {
                    this.list2.push(
                        AccExcelUpload.getGagamErrGridJson(
                            list[i],
                            checkRequired.errMsg
                        )
                    )

                    continue
                }
                // 정산처 존재여부 체크
                if (
                    AccExcelUpload.isExistsAccDealcoCd(
                        list[i].accDealcoCd,
                        this.listAccDealco
                    ) == false
                ) {
                    this.list2.push(
                        AccExcelUpload.getGagamErrGridJson(
                            list[i],
                            '존재하지 않는 정산처코드입니다'
                        )
                    )
                    continue
                }
                // 직영점 여부 체크
                if (
                    AccExcelUpload.isDirectDealco(
                        list[i].accDealcoCd,
                        this.listAccDealco
                    )
                ) {
                    this.list2.push(
                        AccExcelUpload.getGagamErrGridJson(
                            list[i],
                            '직영점은 정산처가 될 수 없습니다.'
                        )
                    )
                    continue
                }
                // 수수료가감항목이 존재하는지 체크
                if (
                    AccExcelUpload.checkExistsCode(
                        list[i].addSubItmCd,
                        this.code.addSubItmCd.list
                    ) == false
                ) {
                    this.list2.push(
                        AccExcelUpload.getGagamErrGridJson(
                            list[i],
                            '수수료가감항목코드가 오류입니다.'
                        )
                    )
                    continue
                }
                // 금액이 숫자인지 체크
                if (isNaN(list[i].addSubAmt)) {
                    this.list2.push(
                        AccExcelUpload.getGagamErrGridJson(
                            list[i],
                            '금액은 숫자만 입력해 주세요.'
                        )
                    )
                    continue
                }
                // 금액이 0보다 큰지 체크
                if (Number(list[i].addSubAmt) == 0) {
                    this.list2.push(
                        AccExcelUpload.getGagamErrGridJson(
                            list[i],
                            '금액은 0입니다.'
                        )
                    )
                    continue
                }
                // 영업월의 값 체크
                if (list[i].saleMthClCd != '1' && list[i].saleMthClCd != '2') {
                    this.list2.push(
                        AccExcelUpload.getGagamErrGridJson(
                            list[i],
                            '영업월 항목의 값은 1 또는 2만 가능합니다.'
                        )
                    )
                    continue
                }

                // 입력값이 정상인 경우는 list에 push한다.
                this.list1.push(list[i])
            }

            this.gridObj1.dataProvider.fillJsonData(this.list1, {})
            this.gridObj2.dataProvider.fillJsonData(this.list2, {})
        },
        // 수수료구분 combo 목록 가져와 세팅하기
        setComboAddSubItmCd: function () {
            commonApi
                .getCommonCodeList(this.code.addSubItmCd.id)
                .then((list) => {
                    this.code.addSubItmCd.list = list
                })
        },
    },
}
</script>
