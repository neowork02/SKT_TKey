<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">상품등록</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Top BTN -->
                    <ul class="btn_area pop">
                        <li class="right">
                            <TCComButton
                                v-if="!basProdMgmtDis.clearBtn"
                                color="btn2"
                                eClass="btn_ty01"
                                @click="clearBtn"
                                :objAuth="objAuth"
                                :disabled="basProdMgmtDis.clearBtn"
                            >
                                초기화
                            </TCComButton>
                        </li>
                    </ul>
                    <!-- // Top BTN -->
                    <div class="contBoth">
                        <div class="div7_3 cont1 left mgt-20">
                            <!-- SubTit -->
                            <div class="stitHead">
                                <h4 class="subTit">상품 기본 정보</h4>
                                <span class="stitBtnRef2">
                                    <TCComButton
                                        v-if="!basProdMgmtDis.ProdColorsBtn"
                                        eClass="btn_ty01"
                                        :objAuth="objAuth"
                                        @click="onProdColorsBtnClick"
                                        :disabled="basProdMgmtDis.ProdColorsBtn"
                                        >색상
                                    </TCComButton>
                                </span>
                            </div>
                            <!-- // SubTit -->
                            <!-- Search_div -->
                            <div class="searchLayer_wrap">
                                <div class="searchform">
                                    <!-- item 1-1 -->
                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="ZBAS_C_00010"
                                            labelName="상품구분"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.prodClCd"
                                            v-model="basProdMgmt.prodClCd"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                            @change="prodClCdChange"
                                        ></TCComComboBox>
                                    </div>
                                    <!-- //item 1-1 -->
                                    <!-- item 4-2 -->
                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="ZBAS_C_00170"
                                            labelName="등록구분"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.rgstClCd"
                                            v-model="basProdMgmt.rgstClCd"
                                        ></TCComComboBox>
                                    </div>
                                    <!-- //item 4-2 -->
                                </div>

                                <!-- Search_line 1 -->
                                <div class="searchform">
                                    <!-- item 1-1 모델코드 -->
                                    <div class="formitem div2">
                                        <TCComInput
                                            v-model="basProdMgmt.prodCd"
                                            :eRequired="true"
                                            :labelName="prodCdColNm"
                                            :disabled="basProdMgmtDis.prodCd"
                                            :objAuth="objAuth"
                                            @input="prodCdChange"
                                            :inputRuleType="'EN'"
                                        >
                                        </TCComInput>
                                    </div>
                                    <!-- //item 1-1 -->

                                    <!-- item 5-1 -->
                                    <div class="formitem div2">
                                        <TCComInput
                                            v-model="basProdMgmt.prodNm"
                                            :eRequired="true"
                                            :labelName="prodNmColNm"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.prodNm"
                                            @input="prodCdChange"
                                        >
                                        </TCComInput>
                                    </div>
                                    <!-- //item 5-1 -->
                                </div>

                                <div class="searchform">
                                    <!-- item 11-1 -->
                                    <div class="formitem div2">
                                        <TCComInputSearchText
                                            v-model="basProdMgmt.mfactCd"
                                            :codeVal.sync="basProdMgmt.mfactNm"
                                            labelName="제조사"
                                            :eRequired="true"
                                            placeholder="입력해주세요"
                                            :disabledAfter="true"
                                            :objAuth="objAuth"
                                            @enterKey="onOutDealEnterKey"
                                            @appendIconClick="
                                                onOutDealIconClick
                                            "
                                            :disabled="basProdMgmtDis.mfactCd"
                                            @input="onOutDealInput"
                                        />
                                        <BasBcoOutDealsPopup
                                            v-if="showBcoOutDeals"
                                            :parentParam="searchOutDealParam"
                                            :rows="resultOutDealRows"
                                            :dialogShow.sync="showBcoOutDeals"
                                            @confirm="onOutDealReturnData"
                                        />
                                    </div>
                                    <!-- //item 11-1 -->

                                    <!-- item 2-2 -->
                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="ZBAS_C_00090"
                                            labelName="바코드유형"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.barCdTypCd
                                            "
                                            v-model="basProdMgmt.barCdTypCd"
                                            :eRequired="true"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                        ></TCComComboBox>
                                    </div>
                                    <!-- //item 2-2 -->
                                </div>

                                <!-- 상품구분 : 단말기 / USIM /스마트디바이스 일때 START -->
                                <div v-if="!prodClCdAZone" class="searchform">
                                    <!-- item 2-1 -->
                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="ZBAS_C_00500"
                                            labelName="단말기구분"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.eqpClCd"
                                            v-model="basProdMgmt.eqpClCd"
                                            :addBlankItem="true"
                                            blankItemText="전체"
                                            blankItemValue=""
                                            @change="eqpClCdChange"
                                        ></TCComComboBox>
                                    </div>
                                    <!-- //item 2-1 -->
                                    <!-- item 3-2 -->
                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="EQP_TYP_DTL_CD"
                                            labelName="단말기상세유형"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.eqpTypDtlCd
                                            "
                                            v-model="basProdMgmt.eqpTypDtlCd"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                        ></TCComComboBox>
                                    </div>
                                    <!-- //item 3-2 -->
                                </div>
                                <div class="searchform" v-if="!prodClCdAZone">
                                    <!-- item 11-1 -->
                                    <div class="formitem div2">
                                        <TCComCheckBox
                                            labelName="대표모델여부"
                                            :objAuth="objAuth"
                                            :itemList="chkData"
                                            @click="fnRepProdCdYn()"
                                            v-model="basProdMgmt.repProdCdYn"
                                            :disabled="
                                                basProdMgmtDis.repProdCdYn
                                            "
                                        ></TCComCheckBox>
                                    </div>
                                    <!-- //item 11-1 -->
                                    <div class="formitem div2">
                                        <TCComInputSearchText
                                            v-model="basProdMgmt.repProdCd"
                                            :codeVal.sync="
                                                basProdMgmt.repProdNm
                                            "
                                            labelName="대표모델"
                                            :eRequired="true"
                                            placeholder="입력해주세요"
                                            :disabledAfter="true"
                                            :objAuth="objAuth"
                                            @enterKey="onProdsEnterKey"
                                            @appendIconClick="onProdsIconClick"
                                            @input="onProdsInput"
                                            :disabled="basProdMgmtDis.repProdCd"
                                        />
                                        <BasBcoProdsPopup
                                            v-if="basBcoProdsShow"
                                            :parentParam="searchProdForm"
                                            :rows="resultProdsRows"
                                            :dialogShow.sync="basBcoProdsShow"
                                            @confirm="onProdsReturnData"
                                        />
                                    </div>
                                </div>
                                <div class="searchform" v-if="!prodClCdAZone">
                                    <!-- item 11-1 -->
                                    <div class="formitem div2">
                                        <TCComInput
                                            labelName="일련번호길이"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.serLen"
                                            v-model="basProdMgmt.serLen"
                                        >
                                        </TCComInput>
                                    </div>
                                    <!-- //item 11-1 -->
                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="EQP_TYP_CL_CD"
                                            labelName="NETWORK세대"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.eqpTypClCd
                                            "
                                            v-model="basProdMgmt.eqpTypClCd"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                        ></TCComComboBox>
                                    </div>
                                </div>
                                <div class="searchform" v-if="!prodClCdAZone">
                                    <div class="formitem div2">
                                        <TCComDatePicker
                                            v-model="basProdMgmt.mktgDt"
                                            labelName="출시일"
                                            calType="D"
                                            :eRequired="true"
                                            :disabled="basProdMgmtDis.mktgDt"
                                        >
                                        </TCComDatePicker>
                                    </div>

                                    <div class="formitem div2">
                                        <TCComDatePicker
                                            labelName="단종일"
                                            calType="D"
                                            eClass="div2"
                                            :disabled="basProdMgmtDis.endDt"
                                            v-model="basProdMgmt.endDt"
                                        >
                                        </TCComDatePicker>
                                    </div>
                                </div>
                                <div class="searchform" v-if="!prodClCdAZone">
                                    <!-- item 3-1 -->
                                    <div class="formitem div2">
                                        <TCComInput
                                            labelName="펫네임"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.petNm"
                                            v-model="basProdMgmt.petNm"
                                        >
                                        </TCComInput>
                                    </div>
                                    <!-- //item 3-1 -->

                                    <!-- item 8-1 -->
                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="ZBAS_C00570"
                                            labelName="유통단말기구분"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.dstrbEqpClCd
                                            "
                                            v-model="basProdMgmt.dstrbEqpClCd"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                        ></TCComComboBox>
                                    </div>
                                    <!-- //item 8-1 -->
                                </div>
                                <div class="searchform" v-if="!prodClCdAZone">
                                    <div
                                        v-if="!basProdMgmtDis.esimEqpYn"
                                        class="formitem div2"
                                    >
                                        <TCComRadioBox
                                            :itemList="codeYn"
                                            itemText="codeId"
                                            itemValue="codeVal"
                                            labelName="ESIM모델여부"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.esimEqpYn"
                                            v-model="basProdMgmt.esimEqpYn"
                                        ></TCComRadioBox>
                                    </div>

                                    <div
                                        v-if="!basProdMgmtDis.codeYn"
                                        class="formitem div2"
                                    >
                                        <TCComRadioBox
                                            :itemList="codeYn"
                                            itemText="codeId"
                                            itemValue="codeVal"
                                            labelName="듀얼심단말여부"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.dualSimEqpYn
                                            "
                                            v-model="basProdMgmt.dualSimEqpYn"
                                        ></TCComRadioBox>
                                    </div>

                                    <!-- //item 10-2 -->
                                </div>

                                <!-- 상품구분 : 단말기 / USIM /스마트디바이스 일때 END -->

                                <!-- * 상품구분 : 단말기 / USIM /스마트디바이스 가 아닐때 START -->
                                <div class="searchform" v-if="!prodClCdBZone">
                                    <!-- item 9-1 -->
                                    <div class="formitem div2">
                                        <TCComInput
                                            labelName="바코드정보"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.lifeBarCd"
                                            v-model="basProdMgmt.lifeBarCd"
                                        >
                                        </TCComInput>
                                    </div>
                                    <!-- //item 9-1 -->
                                    <!-- item 10-1 -->
                                    <div class="formitem div2">
                                        <TCComRadioBox
                                            labelName="과세상품구분"
                                            :itemList="taxTypData"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.taxTypCd"
                                            v-model="basProdMgmt.taxTypCd"
                                            @change="taxTypCdChange"
                                        ></TCComRadioBox>
                                    </div>
                                    <!-- //item 10-1 -->
                                </div>

                                <div class="searchform" v-if="!prodClCdBZone">
                                    <div class="formitem div2">
                                        <TCComComboBox
                                            :itemList="codeYn"
                                            itemText="codeId"
                                            itemValue="codeVal"
                                            labelName="판매분매입여부"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.saleInYn"
                                            v-model="basProdMgmt.saleInYn"
                                        ></TCComComboBox>
                                    </div>
                                    <!--
                                        <div class="formitem div2">
                                            <TCComComboBox
                                                :itemList="codeYn"
                                                itemText="codeId"
                                                itemValue="codeVal"
                                                labelName="SIS상품여부"
                                                :eRequired="true"
                                                :objAuth="objAuth"
                                                :disabled="basProdMgmtDis.sisYn"
                                                v-model="basProdMgmt.sisYn"
                                            ></TCComComboBox>
                                        </div>
                                        -->
                                </div>
                                <!-- * 상품구분 : 단말기 / USIM /스마트디바이스 가 아닐때 END -->

                                <div class="searchform">
                                    <div class="formitem div2">
                                        <TCComRadioBox
                                            :itemList="codeYn"
                                            itemText="codeId"
                                            itemValue="codeVal"
                                            labelName="주문여부"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.ordYn"
                                            v-model="basProdMgmt.ordYn"
                                        ></TCComRadioBox>
                                    </div>
                                </div>
                                <div class="searchform">
                                    <!-- item 7-2 -->
                                    <div class="formitem div1">
                                        <TCComInput
                                            labelName="비고"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.rmks"
                                            v-model="basProdMgmt.rmks"
                                        >
                                        </TCComInput>
                                    </div>
                                    <!-- //item 7-2 -->
                                </div>
                                <div class="searchform">
                                    <!-- item 11-2 -->
                                    <div
                                        class="formitem div2"
                                        v-if="!basProdMgmtDis.ecoEqpGrCdDiv"
                                    >
                                        <TCComComboBox
                                            codeId="ZDIS_C_00380"
                                            labelName="단말기등급"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.ecoEqpGrCd
                                            "
                                            v-model="basProdMgmt.ecoEqpGrCd"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                            @change="ecoEqpGrCdCdChange"
                                        ></TCComComboBox>
                                    </div>
                                    <div
                                        v-if="!basProdMgmtDis.cashPrchsPrcDiv"
                                        class="formitem div2"
                                    >
                                        <TCComInput
                                            labelName="출고가"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.cashPrchsPrc
                                            "
                                            v-model="basProdMgmt.cashPrchsPrc"
                                        >
                                        </TCComInput>
                                    </div>

                                    <!-- //item 11-2 -->
                                </div>
                            </div>
                        </div>
                        <div class="div7_3 cont2 right mgt-20">
                            <!-- gridWrap -->
                            <div class="gridWrap">
                                <!-- SubTit -->
                                <TCRealGridHeader
                                    id="popupGridHeader"
                                    ref="popupGridHeader"
                                    gridTitle="상품색상목록"
                                    :gridObj="gridObj"
                                />
                                <!-- // SubTit -->
                                <TCRealGrid
                                    id="popupGrid"
                                    ref="popupGrid"
                                    :editable="true"
                                    :fields="view.fields"
                                    :columns="view.columns"
                                    :style="gridStyle"
                                />
                            </div>
                            <!-- //gridWrap -->
                        </div>
                    </div>

                    <!--
                                 <div class="div7_3 cont1 left">
                            <div class="stitHead">
                                <h4 class="subTit">기존삭제정보이나 복원할것을 대비 삭제하지 않음</h4>
                            </div>

                            <div class="searchLayer_wrap">
                                <div class="formitem div2">
                                            <TCComComboBox
                                                codeId="ZBAS_C_00011"
                                                labelName="상품상세구분"
                                                :objAuth="objAuth"
                                                :disabled="
                                                    basProdMgmtDis.prodDtlClCd
                                                "
                                                v-model="
                                                    basProdMgmt.prodDtlClCd
                                                "
                                                :addBlankItem="true"
                                                blankItemText="선택"
                                                blankItemValue=""
                                            ></TCComComboBox>
                                </div>
                                <div class="searchform">
                                    <div class="formitem div2">
                                        <TCComInput
                                            labelName="모델원코드"
                                            v-model="basProdMgmt.prodSetCd"
                                            :disabled="basProdMgmtDis.prodSetCd"
                                            :objAuth="objAuth"
                                        >
                                        </TCComInput>
                                    </div>

                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="ZBAS_C_00020"
                                            labelName="상품특성1"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.prodChrticCd1
                                            "
                                            v-model="basProdMgmt.prodChrticCd1"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                        ></TCComComboBox>
                                    </div>
                                </div>

                                <div class="searchform">
                                    <div class="formitem div2">
                                        <TCComRadioBox
                                            :itemList="codeYn"
                                            itemText="codeId"
                                            itemValue="codeVal"
                                            labelName="SKT 운영여부"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.sktOperYn"
                                            v-model="basProdMgmt.sktOperYn"
                                        ></TCComRadioBox>
                                    </div>

                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="ZBAS_C_00030"
                                            labelName="상품특성2"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.prodChrticCd2
                                            "
                                            v-model="basProdMgmt.prodChrticCd2"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                        ></TCComComboBox>
                                    </div>
                                </div>

                                <div class="searchform">
                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="ZBAS_C_00490"
                                            labelName="예약판매여부"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.reservSaleYn
                                            "
                                            v-model="basProdMgmt.reservSaleYn"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                        ></TCComComboBox>
                                    </div>

                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="ZBAS_C_00460"
                                            labelName="상품특성3"
                                            eClass="div2"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.prodChrticCd3
                                            "
                                            v-model="basProdMgmt.prodChrticCd3"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                        ></TCComComboBox>
                                    </div>
                                </div>

                                <div class="searchform">
                                    <div class="formitem div2">
                                        <TCComRadioBox
                                            :itemList="codeYn"
                                            itemText="codeId"
                                            itemValue="codeVal"
                                            labelName="단종여부"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.endYn"
                                            v-model="basProdMgmt.endYn"
                                        ></TCComRadioBox>
                                    </div>

                                    <div class="formitem div2">
                                        <TCComComboBox
                                            codeId="ZBAS_C_00470"
                                            labelName="상품특성4"
                                            :objAuth="objAuth"
                                            :disabled="
                                                basProdMgmtDis.prodChrticCd4
                                            "
                                            v-model="basProdMgmt.prodChrticCd4"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                        ></TCComComboBox>
                                    </div>
                                </div>

                                <div class="searchform">
                                  
                                    <div class="formitem div2">
                                        <TCComRadioBox
                                            :itemList="codeYn"
                                            itemText="codeId"
                                            itemValue="codeVal"
                                            labelName="사용여부"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="basProdMgmtDis.useYn"
                                            v-model="basProdMgmt.useYn"
                                            @change="useYnChange"
                                        ></TCComRadioBox>
                                    </div>
                                </div>

                                <div class="searchform">
                                    <div
                                        v-if="!basProdMgmtDis.useStopDt"
                                        class="formitem div2"
                                    >
                                        <TCComDatePicker
                                            labelName="사용중지일"
                                            calType="D"
                                            eClass="div2"
                                            :disabled="basProdMgmtDis.useStopDt"
                                            v-model="basProdMgmt.useStopDt"
                                        >
                                        </TCComDatePicker>
                                    </div>
                                    <div class="formitem div2">
                                       
                                    </div>

                                    <div class="searchform">
                                  
                                    <div class="formitem div2">
                                            <TCComComboBox
                                                codeId="ZBAS_C_00440"
                                                labelName="통신방식"
                                                :objAuth="objAuth"
                                                :disabled="
                                                    basProdMgmtDis.comMthdCd
                                                "
                                                v-model="basProdMgmt.comMthdCd"
                                                :addBlankItem="true"
                                                blankItemText="선택"
                                                blankItemValue=""
                                            ></TCComComboBox>
                                    </div>
                                    <div class="formitem div2"></div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            -->
                </div>
                <!-- Bottom BTN Group -->
                <div class="btn_area_bottom">
                    <TCComButton
                        v-if="!basProdMgmtDis.dfDeleteBtn"
                        :eLarge="true"
                        eClass="btn_ty02_point"
                        :objAuth="objAuth"
                        @click="df_delete"
                        :disabled="basProdMgmtDis.dfDeleteBtn"
                    >
                        삭제
                    </TCComButton>
                    <TCComButton
                        v-if="!basProdMgmtDis.dfSaveBtn"
                        :eLarge="true"
                        eClass="btn_ty02_point"
                        :objAuth="objAuth"
                        @click="df_save"
                        :disabled="basProdMgmtDis.dfSaveBtn"
                    >
                        저장
                    </TCComButton>
                    <TCComButton
                        :eLarge="true"
                        eClass="btn_ty01"
                        @click="closeBtn"
                        :objAuth="objAuth"
                    >
                        닫기
                    </TCComButton>
                </div>
                <!-- // Bottom BTN Group -->
                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="closeBtn()"
                    >닫기</a
                >
                <!--//Close BTN-->
            </div>
            <!-- //Popup_Cont -->

            <BasBcoProdColorsPopup
                v-if="showBcoProdColors"
                :parentParam="searchProdColorsParam"
                :rows="resultProdColorsRows"
                :dialogShow.sync="showBcoProdColors"
                @confirm="onProdColorsReturnData"
            />
        </template>
    </TCComDialog>
</template>

<script>
import BasBcoProdColorsPopup from '@/components/common/BasBcoProdColorsPopup'
import { basBcoProdColorsHeader } from '@/const/grid/bas/bco/basBcoProdColorsHeader'
// import testJson from '@/views/prototype/json/test.json'
import basPdmProdBrwsMgmtPopupApi from '@/api/biz/bas/pdm/basPdmProdBrwsMgmtPopupApi'
//리스트api
import basPdmProdBrwsMgmtApi from '@/api/biz/bas/pdm/basPdmProdBrwsMgmtApi'
import {
    BasProdMgmtDis,
    BasProdMgmt,
    BasProdColor,
    BasEqpMdlIf,
} from '@/api/biz/bas/pdm//basPdmProdBrwsMgmtPopupParam'
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
import _ from 'lodash'
import { CommonGrid, CommonUtil } from '@/utils'
import { NewLib } from '@/views/newlib'
import CommonMixin from '@/mixins'
export default {
    name: 'BasPdmProdBrwsMgmtPopup',
    mixins: [CommonMixin],
    components: {
        BasBcoProdColorsPopup,
        BasBcoProdsPopup,
        BasBcoOutDealsPopup,
    },
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchParam.cudFlag = value['cudFlag'] //신규수정여부
                this.searchParam.ifYn = value['ifYn']
                this.searchParam.rgst_cl = value['rgst_cl'] //사용자/유키여부
                this.searchParam.prod_cd = value['prod_cd'] //상품코드
                this.searchParam.prodCd = value['prod_cd'] //상품코드
                //this.searchParam.prodClCd = value['prod_cd'] //상품코드
                this.searchParam.open_eqp_yn = value['open_eqp_yn']

                this.searchParam.FV_RGST_CL = value['rgst_cl'] //사용자/유키여부
                this.searchParam.FV_OMD_CL = value['omd_cl']
                this.searchParam.FV_OMD_RGST_CL = value['omd_rgst_cl']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            addData: ['', '99', '공통색상'],
            objAuth: {},
            view: basBcoProdColorsHeader,
            //생활바코드  중복체크
            lifeBarCdDuplicationCheckCond: {
                lifeBarCd: '',
                sisYn: '',
            },
            //상품중복체크
            prodCdDuplicationCheckCond: {
                prodCd: '',
            },
            //개방형목록조회
            dsCon: {
                prodSetCd: '',
                pageNum: '',
            },
            //수정시 중복체크
            duplication: {
                prodCd: '',
                prodNm: '',
                lifeBarCd: '',
                sisYn: '',
            },
            chkData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '',
                },
            ],
            taxTypData: [
                {
                    commCdVal: '1',
                    commCdValNm: '과세',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '비과세',
                },
                {
                    commCdVal: '3',
                    commCdValNm: '면세',
                },
            ],
            codeYn: [
                {
                    codeId: 'Y',
                    codeVal: 'Y',
                },
                {
                    codeId: 'N',
                    codeVal: 'N',
                },
            ],
            content: '',
            //disabled 여부
            basProdMgmtDis: new BasProdMgmtDis(),
            basProdMgmt: new BasProdMgmt(),
            basProdMgmtList: [],
            basProdColor: new BasProdColor(),
            basProdColorList: [],
            basEqpMdlIf: new BasEqpMdlIf(),
            basEqpMdlIfList: [],
            param: {},
            gridStyle: {
                height: '480px', //그리드 높이 조절
            },
            //부모셋팅값
            searchParam: {
                FV_INT_IF: '0',
                FV_RGST_CL: '',
                FV_OMD_CL: '',
                FV_OMD_RGST_CL: '',
                FV_OMD_MFACT: '',

                cudFlag: '',
                ifYn: '',
                rgst_cl: '',
                prod_cd: '',
                open_eqp_yn: '',
                prodCd: '',
                prodClCd: '',
            },
            dsProdList: [],
            prodCdColNm: '모델코드',
            prodNmColNm: '모델명',

            //====================상품색상팝업관련====================
            showBcoProdColors: false,
            searchProdColorsParam: {
                prodCd: '', // 상품코드
            },
            resultProdColorsRows: [],
            //====================//상품색상팝업관련==================
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            searchProdForm: {
                prodClCd: '1', //상품구분
                sktOperYn: 'Y', //skt운영여부
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
            },
            resultProdsRows: [],
            //====================//상품팝업관련==================
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '2X', // 거래처그룹
                dealcoClCd1: '20', // 거래처구분
            },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================

            prodClCdAZone: false, //false일경우 노출
            prodClCdBZone: true, //false일경우 노출
            saveType: '',
        }
    },

    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.popupGridHeader

        this.gridObj.setGridState(false, false, false, false)

        this.gridObj.gridView.columnByName('prodCd').visible = false

        //편집불가, 수정불가
        this.gridObj.gridView.setEditOptions({
            editable: false,
            updatable: false,
            editWhenFocused: false,
            enterToTab: false,
        })

        //컬럼전체채우기
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })

        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        //Default false
        //this.gridObj.setGridState()

        this.init()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        //Grid Init
        GridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(-1, 1000, '', '')
        },
        async init() {
            console.log('init')

            /*
            if ('' != this.searchParam.ifYn) {
                this.searchParam.FV_INT_IF = '1'
                //버튼안보임
                //cf_visibleCommonBtn(div_commonButton)
            }
*/
            //총4곳에서 팝업을 띄움.(신규, 확장모델등록, 리스트클릭, UKEY)
            //신규
            if ('C' == this.searchParam.cudFlag) {
                //시작시초기화(초기화버튼때도)
                this.gridData = this.GridSetData()
                this.gridObj.dataProvider.clearRows()
                this.basProdMgmt = new BasProdMgmt()

                //disabled처리
                this.cInitDis()
            } else if ('U' == this.searchParam.cudFlag) {
                //상세가져오기
                await this.svcSearchDetail(this.searchParam)

                //확장모델전부/리스트더블클릭시(eqpClCd:03,04) 일경우 OMD_CL 이 Y로 가져옴
                //리스트더블클릭 시 (eqpClCd:03,04) FV_OMD_RGST_CL => N
                //Y=> 확장모델버튼클릭이라보면됨. 리스트클릭시  eqpClCd:03,04 인경우 없는듯.
                //확장모델버튼

                if ('Y' == this.searchParam.FV_OMD_CL) {
                    this.uInitOemDis()

                    // 개방형 목록조회
                    await this.svcSearchList()
                    //셋팅
                    this.f_omdMdlNm_set()

                    //console.log('==============>', this.dsProdList.gridList[0])
                } else {
                    //일반수정건
                    this.uInitDis()
                }

                //상세보기(업데이트시) 공통
            } else {
                //상품관리-대리점별운영상품관리
                //수정없이 팝업으로 상세내용확인.
                //상세가져오기
                await this.svcSearchDetail(this.searchParam)
                this.fnOnlyRead()
            }

            //모델과 대표모델동일시 체크
            this.fnRepPordSame()
        },

        fnOnlyRead() {
            //----------------------------------------
            let basProdMgmtDis = this.basProdMgmtDis

            for (var key in basProdMgmtDis) {
                console.log('attr: ' + key + ', value: ' + basProdMgmtDis[key])

                //if (null == basProdMgmtDis[key]) {
                this.basProdMgmtDis[key] = true
                //}
            }
            //--------------------------------------
        },

        f_omdMdlNm_set() {
            if ('N' == this.searchParam.FV_OMD_RGST_CL) {
                return
            }

            if (
                '01' == this.basProdMgmt.eqpClCd ||
                '02' == this.basProdMgmt.eqpClCd
            ) {
                console.log('omd작업없음')
            } else if ('03' == this.basProdMgmt.eqpClCd) {
                let iCnt = '1'
                let sPCnt = ''
                let oNm = this.basProdMgmt.prodSetCd + 'Z'
                let sNm = ''
                //alert(this.dsProdList.gridList.length)
                for (let i = 0; i < this.dsProdList.gridList.length; i++) {
                    sNm = this.dsProdList.gridList[i].prodSetCd.substr(
                        0,
                        oNm.length
                    )

                    //alert(oNm + '===' + sNm)

                    if (oNm == sNm) {
                        iCnt = this.dsProdList.gridList[i].prodCd.substr(
                            oNm.length,
                            this.dsProdList.gridList[i].prodCd.length
                        )
                    }
                }

                //alert('0' + iCnt)
                sPCnt = ('0' + iCnt).length
                if (sPCnt < 3) {
                    sPCnt = '0' + iCnt
                } else {
                    sPCnt = iCnt
                }

                this.basProdMgmt.prodCd =
                    this.basProdMgmt.prodSetCd + 'Z' + sPCnt
                this.basProdMgmt.prodNm =
                    this.basProdMgmt.prodSetNm + '_Z' + sPCnt
            } else if ('04' == this.basProdMgmt.eqpClCd) {
                let iCnt = '1'
                let sPCnt = ''
                let oNm =
                    this.basProdMgmt.prodSetCd + this.basProdMgmt.ecoEqpGrCd
                let sNm = ''

                for (let i = 0; i < this.dsProdList.gridList.length; i++) {
                    sNm = this.dsProdList.gridList[i].prodSetCd.substr(
                        0,
                        oNm.length
                    )

                    //alert(oNm + '===' + sNm)

                    if (oNm == sNm) {
                        iCnt = this.dsProdList.gridList[i].prodCd.substr(
                            oNm.length,
                            this.dsProdList.gridList[i].prodCd.length
                        )
                    }
                }

                //alert('0' + iCnt)
                sPCnt = ('0' + iCnt).length
                if (sPCnt < 3) {
                    sPCnt = '0' + iCnt
                } else {
                    sPCnt = iCnt
                }

                this.basProdMgmt.prodCd =
                    this.basProdMgmt.prodSetCd +
                    this.basProdMgmt.ecoEqpGrCd +
                    sPCnt
                this.basProdMgmt.prodNm =
                    this.basProdMgmt.prodSetNm +
                    '_' +
                    this.basProdMgmt.ecoEqpGrCd +
                    sPCnt
            }
            //에코형인경우에 단말기등급이 없으면 최초담아놓은 모델코드, 명 적용
            if ('04' == this.basProdMgmt.eqpClCd) {
                if ('' == this.basProdMgmt.ecoEqpGrCd) {
                    this.basProdMgmt.prodCd = this.basProdMgmt.befProdCd
                    this.basProdMgmt.prodNm = this.basProdMgmt.befProdNm
                }
            }
        },
        cInitDis() {
            console.log('C_dis')

            //신규 기본셋팅
            this.basProdMgmt.prodClCd = '1'
            this.basProdMgmt.saleInYn = 'N'
            //this.basProdMgmt.rgstClCd = 'N'
            this.basProdMgmt.ordYn = 'Y'
            this.basProdMgmt.taxTypCd = '1'

            //등록구분
            this.basProdMgmt.rgstClCd = '2'

            //ESIM모델여부
            this.basProdMgmt.esimEqpYn = 'N'
            //듀얼심단말여부
            this.basProdMgmt.dualSimEqpYn = 'N'

            this.basProdMgmt.endDt = '9999-12-31'

            //삭제버튼
            this.basProdMgmtDis.dfDeleteBtn = true

            /*
            //모델원코드
            this.basProdMgmtDis.prodSetCd = true
            //바코드정보
            this.basProdMgmtDis.lifeBarCd = true
            //단말기구분
            this.basProdMgmtDis.eqpClCd = true
            //단말기등급
            //this.basProdMgmtDis.ecoEqpGrCd = true
            //this.basProdMgmtDis.ecoEqpGrCdDiv = true
            //출고가
            //this.basProdMgmtDis.cashPrchsPrcDiv = true
            //this.basProdMgmtDis.cashPrchsPrc = true
            //단종일
            this.basProdMgmtDis.endDt = true


            */
            this.fnProdClCdAZoneShow()
        },
        //유키수정
        uInitUkeyDis() {
            //부모값
            // let FV_RGST_CL = this.searchParam.FV_RGST_CL
            /*
            //UKEY 연동
            if ('1' == FV_RGST_CL) {
                this.basProdMgmtDis.endDt = true
                this.basProdMgmtDis.prodClCd = true
                //출고가
                this.basProdMgmtDis.cashPrchsPrc = true
                this.basProdMgmtDis.cashPrchsPrcDiv = true
            } else {
                this.basProdMgmtDis.endDt = false
                this.basProdMgmtDis.prodClCd = false
                //출고가
                this.basProdMgmtDis.cashPrchsPrc = false
                this.basProdMgmtDis.cashPrchsPrcDiv = false
            }
            */
        },

        //oem확장버튼
        uInitOemDis() {
            if ('N' == this.searchParam.FV_OMD_RGST_CL) {
                //단말기구분(수정불가)
                this.basProdMgmtDis.eqpClCd = true
                //출고가
                this.basProdMgmtDis.cashPrchsPrc = true //출고가가 disable처리되나 화면에 출고가가 얼마인지 확인은 가능한경우(등록된 확장모델을 더블클릭하였을때)
                this.basProdMgmtDis.cashPrchsPrcDiv = false
            } else {
                this.saveType = 'H'
                //alert(this.searchParam.FV_OMD_RGST_CL)
                //단말기구분
                this.basProdMgmtDis.eqpClCd = false
                this.basProdMgmt.eqpClCd = '03'
                //출시일
                this.basProdMgmt.mktgDt = NewLib.cf_today()
                //공통컬러추가
                this.gridAddRowBtn()
            }

            //모델코드
            this.basProdMgmtDis.prodCd = true
            //모델원코드
            this.basProdMgmtDis.prodSetCd = true
            //모델명
            this.basProdMgmtDis.prodNm = true
            //대표모델
            this.basProdMgmtDis.repProdCd = true
            //대표모델여부
            this.basProdMgmtDis.repProdCdYn = true
            //등록구분
            this.basProdMgmtDis.rgstClCd = true
            //색상선택버튼
            this.basProdMgmtDis.ProdColorsBtn = true
            //상품구분
            this.basProdMgmtDis.prodClCd = true
            //SKT운영여부
            this.basProdMgmtDis.sktOperYn = true
            //사용여부
            this.basProdMgmtDis.useYn = true
            //단종여부
            this.basProdMgmtDis.endYn = true
            //상품상세구분
            this.basProdMgmtDis.prodDtlClCd = true
            //일련번호길이
            this.basProdMgmtDis.serLen = true
            //예약판매여부
            this.basProdMgmtDis.reservSaleYn = true
            //바코드정보
            this.basProdMgmtDis.lifeBarCd = true
            //단말기등급
            //this.basProdMgmtDis.ecoEqpGrCd = true
            //this.basProdMgmtDis.ecoEqpGrCdDiv = true
            //상품특성1
            this.basProdMgmtDis.prodChrticCd1 = true
            //상품특성2
            this.basProdMgmtDis.prodChrticCd2 = true
            //상품특성3
            this.basProdMgmtDis.prodChrticCd3 = true
            //상품특성4
            this.basProdMgmtDis.prodChrticCd4 = true
            //바코드유형
            this.basProdMgmtDis.barCdTypCd = true
            //통신방식
            this.basProdMgmtDis.comMthdCd = true
            //비고
            this.basProdMgmtDis.rmks = true
            //사용중지일
            // this.basProdMgmt.useStopDt = ''
            //show, disabled 같이씀
            this.basProdMgmtDis.useStopDt = true

            //ESIM모델여부
            //this.basProdMgmtDis.esimEqpYn = true
            //듀얼심단말여부
            //this.basProdMgmtDis.dualSimEqpYn = true

            //상품구분변경시
            this.prodClCdChange()
        },
        //일반수정(SWING, 상품관리row클릭)
        uInitDis() {
            console.log('U_dis')
            let rgstClCd = this.basProdMgmt.rgstClCd

            //스윙연동일경우
            if ('1' == rgstClCd) {
                this.basProdMgmtDis.prodClCd = true //상품구분
                this.basProdMgmtDis.rgstClCd = true //등록구분

                this.basProdMgmtDis.prodCd = true //모델코드
                this.basProdMgmtDis.prodNm = true //모델명
                this.basProdMgmtDis.mfactCd = true //제조사
                this.basProdMgmtDis.mfactNm = true //제조사
                this.basProdMgmtDis.eqpClCd = true //단말기구분
                this.basProdMgmtDis.eqpTypDtlCd = true //단말기상세유형
                this.basProdMgmtDis.repProdCdYn = true //대표모델여부
                this.basProdMgmtDis.repProdCd = true //대표모델
                this.basProdMgmtDis.eqpTypClCd = true //NETWORK세대
                this.basProdMgmtDis.mktgDt = true //출시일
                this.basProdMgmtDis.endDt = true //단종일
                this.basProdMgmtDis.dstrbEqpClCd = true //유통단말기구분
                this.basProdMgmtDis.esimEqpYn = true //ESIM모델여부
                this.basProdMgmtDis.dualSimEqpYn = true //듀얼심단말여부

                //this.basProdMgmtDis.ecoEqpGrCd = true //단말기등급
                //this.basProdMgmtDis.ecoEqpGrCdDiv = true
                //this.basProdMgmtDis.cashPrchsPrc = true //출고가
                //this.basProdMgmtDis.cashPrchsPrcDiv = true //출고가DIV
                this.basProdMgmtDis.petNm = true //펫네임
            } else {
                this.basProdMgmtDis.prodClCd = true //상품구분
                this.basProdMgmtDis.rgstClCd = true //등록구분

                this.basProdMgmtDis.prodCd = true //모델코드
                this.basProdMgmtDis.prodSetCd = true //모델원코드
                this.basProdMgmtDis.eqpClCd = true //단말기구분
                //this.basProdMgmtDis.ecoEqpGrCd = true //단말기등급
                //this.basProdMgmtDis.ecoEqpGrCdDiv = true
                // this.basProdMgmtDis.cashPrchsPrc = true //출고가
                //this.basProdMgmtDis.cashPrchsPrcDiv = true //출고가DIV
            }

            //사용여부에따른 사용중지일 변경
            this.useYnChange()

            //상품구분변경시
            this.prodClCdChange()
        },
        //단말기등급변경시
        ecoEqpGrCdCdChange() {
            this.f_omdMdlNm_set()
        },
        //단말기구분변경시
        async eqpClCdChange() {
            /* 여기 */
            if ('H' != this.saveType) {
                return
            }

            if ('03' == this.basProdMgmt.eqpClCd) {
                this.basProdMgmt.ecoEqpGrCd = ''
                this.basProdMgmtDis.ecoEqpGrCd = true
                this.basProdMgmtDis.ecoEqpGrCdDiv = true
                this.basProdMgmtDis.cashPrchsPrc = true //출고가
                this.basProdMgmtDis.cashPrchsPrcDiv = true //출고가DIV
                this.basProdMgmt.cashPrchsPrc = 0
            } else if ('04' == this.basProdMgmt.eqpClCd) {
                this.showTcComAlert('단말기등급을 반드시 입력하여야합니다', {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })

                this.basProdMgmtDis.ecoEqpGrCdDiv = false
                this.basProdMgmtDis.ecoEqpGrCd = false
                this.basProdMgmt.ecoEqpGrCd = ''
                this.basProdMgmtDis.cashPrchsPrc = false //출고가
                this.basProdMgmtDis.cashPrchsPrcDiv = false //출고가DIV
            } else {
                await this.showTcComAlert('선택할 수 없습니다.', {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })

                this.basProdMgmtDis.ecoEqpGrCd = true
                this.basProdMgmtDis.ecoEqpGrCdDiv = true
                this.basProdMgmt.eqpClCd = '03'
                this.basProdMgmt.ecoEqpGrCd = ''

                this.basProdMgmtDis.cashPrchsPrc = true //출고가
                this.basProdMgmtDis.cashPrchsPrcDiv = true //출고가DIV
                this.basProdMgmt.cashPrchsPrc = 0
            }

            this.f_omdMdlNm_set()
        },
        //상품구분변경시
        prodClCdChange() {
            let prodClCd = this.basProdMgmt.prodClCd

            if ('1' == prodClCd || '2' == prodClCd || '3' == prodClCd) {
                this.fnProdClCdAZoneShow()
            } else {
                this.fnProdClCdBZoneShow()
            }

            if ('2' == prodClCd || '9' == prodClCd) {
                //기본색상값추가
                this.gridAddRowBtn()
            }

            //바코드정보
            if ('4' == prodClCd || '5' == prodClCd || '6' == prodClCd) {
                //disabled == true
                this.basProdMgmtDis.lifeBarCd = false
            } else {
                this.basProdMgmtDis.lifeBarCd = true
            }
        },
        //사용여부변경시
        useYnChange() {
            let useYn = this.basProdMgmt.useYn
            if ('Y' == useYn) {
                this.basProdMgmt.useStopDt = ''
                //show, disabled 같이씀
                this.basProdMgmtDis.useStopDt = true
            } else {
                this.basProdMgmt.useStopDt = NewLib.cf_today()
                //show, disabled 같이씀
                this.basProdMgmtDis.useStopDt = false
            }

            //basProdMgmt.useStopDt
        },
        //과세상품구분
        taxTypCdChange() {
            let taxTypCd = this.basProdMgmt.taxTypCd
            if ('2' == taxTypCd || '3' == taxTypCd) {
                this.showTcComAlert(
                    '* 면세상품 유형 : 현재판매상품없음 \n * 비과세상품 유형 : 데이터쿠폰, 선불유심 \n\n이 외는 면세, 비과세 상품에 해당되지 않으며, 자세한 문의는 경영관리담당 정혁진M과 협의 후 진행 부탁드립니다.',
                    {
                        header: '',
                        size: '500',
                        confirmLabel: 'OK',
                    }
                )
            }
        },
        gridAddRowBtn: function () {
            let rowCnt = this.gridObj.dataProvider.getRowCount()
            if (0 == rowCnt) {
                this.gridObj.dataProvider.addRow(this.addData)
            }
        },

        //초기화 버튼 이벤트
        clearBtn: function () {
            //this.basProdMgmt = null
            this.init()
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        async paramSet() {
            //this.basProdMgmtList = [...this.basProdMgmtList, this.basProdMgmt]

            //this.f_pre_save()

            //그리드 Commit
            this.gridObj.gridView.commit()

            console.log(
                'df_save0 ',
                this.gridObj.dataProvider.getJsonRows(0, -1)
            )

            this.basProdMgmtList = [this.basProdMgmt]
            ;(this.basProdColorList = this.gridObj.dataProvider.getJsonRows(
                0,
                -1
            )),
                (this.basEqpMdlIfList = [this.basProdMgmt])

            //그리드코드값 모델코드값을 넣는다. 신규저장시에 생성시 비어있음. 저장버튼 누를때 배열에 담는다
            for (let i = 0; i < this.basProdColorList.length; i++) {
                this.basProdColorList[i].prodCd = this.basProdMgmt.prodCd
            }

            /*
            for (let i = 0; i < this.basProdColorList.length; i++) {
                alert(this.basProdColorList[i].prodCd)
            }
            */

            this.param = {
                basProdMgmtList: this.basProdMgmtList,
                basProdColorList: this.basProdColorList,
                basEqpMdlIfList: this.basEqpMdlIfList,
            }

            console.log('df_save1 ', this.basProdMgmt)
            console.log('df_save2 ', this.basProdMgmtList)
            console.log('df_save3 ', this.basProdColorList)
            console.log('df_save4 ', this.param.basProdColorList)

            this.lifeBarCdDuplicationCheckCond.lifeBarCd =
                this.basProdMgmt.lifeBarCd
            this.lifeBarCdDuplicationCheckCond.sisYn = this.basProdMgmt.sisYn

            this.prodCdDuplicationCheckCond.prodCd = this.basProdMgmt.prodCd

            this.duplication.prodCd = this.basProdMgmt.prodCd
            this.duplication.prodNm = this.basProdMgmt.prodNm
            this.duplication.lifeBarCd = this.basProdMgmt.lifeBarCd
            this.duplication.sisYn = this.basProdMgmt.sisYn
        },
        async df_save() {
            let closeYn = 'Y'
            let nextConfirm = false
            //파라미터셋팅
            await this.paramSet()

            if ('Y' == this.searchParam.FV_OMD_CL) {
                this.searchParam.cudFlag = 'C'
            }

            //console.log(this.param)

            //저장전 validation 체크
            if (!this.f_pre_validation()) {
                return
            }

            await this.showTcComConfirm('저장 하시겠습니까?').then(
                (confirm) => {
                    if (confirm) {
                        nextConfirm = true
                    }
                }
            )

            if (!nextConfirm) return

            //수정인경우
            if ('U' == this.searchParam.cudFlag) {
                let cnt3 = await this.svcLifeBarCdDuplication()
                //중복이아닐경우
                //수정
                //alert('수정')
                if (0 == cnt3) {
                    await this.svcUpdate(this.param)
                }

                //저장인경우
            } else {
                //밸리데이션체크 후
                //중복상품체크
                let cnt = await this.svcDuplication()
                //중복이 아닐경우 저장한다.
                //저장
                if (0 == cnt) {
                    await this.svcInsert(this.param)
                } else {
                    closeYn = 'N'
                }
            }

            if ('Y' == closeYn) {
                //닫기
                let jsonData = 0
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        async df_delete() {
            let closeYn = 'Y'
            const confirm = await this.showTcComConfirm('삭제 하시겠습니까?')
            console.log('showTcComConfirm res: ', confirm)
            if (confirm) {
                //파라미터셋팅
                await this.paramSet()

                //삭제
                await this.svcDelete(this.param)

                if ('Y' == closeYn) {
                    //닫기
                    let jsonData = 0
                    this.$emit('confirm', jsonData)
                    this.onClose()
                }
            }
        },
        //모델코드변경시
        prodCdChange() {
            this.basProdMgmt.prodSetCd = this.basProdMgmt.prodCd

            if ('Y' == this.basProdMgmt.repProdCdYn) {
                if (
                    '1' == this.basProdMgmt.prodClCd ||
                    '2' == this.basProdMgmt.prodClCd ||
                    '3' == this.basProdMgmt.prodClCd
                ) {
                    this.basProdMgmt.repProdCd = this.basProdMgmt.prodCd
                    this.basProdMgmt.repProdNm = this.basProdMgmt.prodNm
                }
            }
        },
        btnClick: function () {},

        // 색상 Btn Click Event
        onProdColorsBtnClick() {
            // 색상 팝업 Row 설정 Prop 변수 초기화
            this.searchProdColorsParam.prodCd = this.basProdMgmt.prodCd
            const jsonData = this.gridObj.dataProvider.getJsonRows()
            this.resultProdColorsRows = jsonData
            this.showBcoProdColors = true
        },
        // 색상 Btn 리턴 이벤트 처리
        onProdColorsReturnData(retrunData) {
            //리턴된 값 Grid에 셋팅
            this.gridObj.dataProvider.fillJsonData(retrunData, {
                fillMode: 'set',
            })
            let index = []
            //리턴된 값 상태변경을 위한 index 저장
            for (let i = 0; i < retrunData.length; i++) {
                index.push(i)
            }

            //상태 변경
            this.gridObj.dataProvider.setRowStates(index, 'none')
            this.gridObj.gridView.commit()
        },
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                console.log('getProdsList : ', res)
                if (res === undefined) return
                if (res.length === 1) {
                    this.basProdMgmt.repProdCd = _.get(res[0], 'prodCd')
                    this.basProdMgmt.repProdNm = _.get(res[0], 'prodNm')
                } else {
                    this.searchProdForm.prodClCd = this.basProdMgmt.prodClCd
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            this.searchProdForm.prodClCd = this.basProdMgmt.prodClCd

            if (this.basProdMgmt.repProdCd) {
                return
            }

            if (this.basProdMgmtDis.repProdCd) {
                return
            }

            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.basProdMgmt.repProdCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.basProdMgmt.repProdCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.basProdMgmt.repProdNm = ''
            //대표모델 동일시 체크
            this.fnRepPordSame()
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.basProdMgmt.repProdCd = _.get(retrunData, 'prodCd')
            this.basProdMgmt.repProdNm = _.get(retrunData, 'prodNm')
            //대표모델 동일시 체크
            this.fnRepPordSame()
        },
        //===================== //상품팝업관련 methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    console.log('getOutDealList then : ', res)
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.basProdMgmt.mfactCd = _.get(res[0], 'dealcoCd')
                        this.basProdMgmt.mfactNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            if (this.basProdMgmtDis.mfactCd) {
                return
            }

            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            if (!_.isEmpty(this.basProdMgmt.mfactNm)) {
                this.getOutDealList()
            } else {
                this.showBcoOutDeals = true
            }
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.basProdMgmt.mfactNm)) {
                this.showTcComAlert('외부거래처명을 입력해주세요.')
                return
            }
            // 외부거래처 정보 조회
            this.getOutDealList()
        },
        // 외부거래처 TextField Input 이벤트 처리
        onOutDealInput() {
            // 입력되는 값이 있으면 외부거래처 코드 초기화
            this.basProdMgmt.mfactCd = ''
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.basProdMgmt.mfactCd = _.get(retrunData, 'dealcoCd')
            this.basProdMgmt.mfactNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        onClose() {
            this.activeOpen = false
        },
        //저장
        async svcInsert(formData) {
            console.log('svcInsert')
            //그리드 validation
            await basPdmProdBrwsMgmtPopupApi.svcInsert(formData).then((res) => {
                if (res) {
                    this.showTcComAlert('저장 완료하였습니다.', {
                        header: '저장',
                        size: '500',
                        confirmLabel: 'OK',
                    })

                    console.log('저장완료')
                }
            })
        },

        //업데이트
        async svcUpdate(formData) {
            console.log('svcUpdate')
            //그리드 validation
            await basPdmProdBrwsMgmtPopupApi.svcUpdate(formData).then((res) => {
                if (res) {
                    this.showTcComAlert('수정 완료하였습니다.', {
                        header: '수정',
                        size: '500',
                        confirmLabel: 'OK',
                    })

                    console.log('저장완료')
                }
            })
        },

        //삭제
        async svcDelete(formData) {
            console.log('svcUpdate')
            //그리드 validation
            await basPdmProdBrwsMgmtPopupApi.svcDelete(formData).then((res) => {
                if (res) {
                    this.showTcComAlert('수정 완료하였습니다.', {
                        header: '수정',
                        size: '500',
                        confirmLabel: 'OK',
                    })

                    console.log('저장완료')
                }
            })
        },

        async svcSearchDetail(formData) {
            console.log('svcSearchDetail')

            await basPdmProdBrwsMgmtPopupApi
                .svcSearchDetail(formData)
                .then((resultData) => {
                    //Get Row Data
                    console.log(
                        '===========================================>' +
                            resultData.productListDtoList[0]
                    )
                    //디비에서 가져온값
                    if (undefined != resultData.productListDtoList[0]) {
                        this.basProdMgmt = resultData.productListDtoList[0]
                    } else {
                        this.showTcComAlert('존재하지않는모델코드.', {
                            header: '오류',
                            size: '500',
                            confirmLabel: 'OK',
                        })
                    }

                    //detail값 null 인경우 '' 로 변경처리
                    //----------------------------------------
                    let basProdMgmt = this.basProdMgmt

                    for (var key in basProdMgmt) {
                        console.log(
                            'attr: ' + key + ', value: ' + basProdMgmt[key]
                        )

                        if (null == basProdMgmt[key]) {
                            this.basProdMgmt[key] = ''
                        }
                    }
                    //--------------------------------------
                    //시작시 모델코드 담아놓음.
                    this.basProdMgmt.befProdCd = this.basProdMgmt.prodCd
                    this.basProdMgmt.befProdNm = this.basProdMgmt.prodNm

                    this.gridObj.setRows(resultData.basProdColorDtoList)
                })
        },

        async svcDuplication() {
            let resultCnt = 0

            console.log('svcDuplication===>', this.duplication)

            await basPdmProdBrwsMgmtPopupApi
                .svcDuplication(this.duplication)
                .then((resultData) => {
                    //Get Row Data
                    console.log(resultData)
                    if (0 < resultData.cnt1) {
                        this.showTcComAlert('상품코드 중복 입니다.', {
                            header: 'Grid Data 저장',
                            size: '500',
                            confirmLabel: 'OK',
                        })
                    } else if (0 < resultData.cnt2) {
                        this.showTcComAlert('상품명 중복 입니다.', {
                            header: 'Grid Data 저장',
                            size: '500',
                            confirmLabel: 'OK',
                        })
                    } else if (0 < resultData.cnt3) {
                        this.showTcComAlert('생활상품바코드 중복 입니다.', {
                            header: 'Grid Data 저장',
                            size: '500',
                            confirmLabel: 'OK',
                        })
                    }

                    resultCnt += Number(resultData.cnt1)
                    resultCnt += Number(resultData.cnt2)
                    resultCnt += Number(resultData.cnt3)
                })

            return resultCnt
        },

        async svcLifeBarCdDuplication() {
            let resultCnt3 = 1

            await basPdmProdBrwsMgmtPopupApi
                .lifeBarCdDuplicationCheck(this.lifeBarCdDuplicationCheckCond)
                .then((resultData) => {
                    //Get Row Data
                    resultCnt3 = resultData.cnt3
                })

            return resultCnt3
        },

        //개방형목록조회
        async svcSearchList() {
            this.dsCon.pageSize = 1
            this.dsCon.prodSetCd = this.basProdMgmt.prodSetCd
            this.dsCon.pageNum = 1
            await basPdmProdBrwsMgmtApi
                .getPproductListList(this.dsCon)
                .then((resultData) => {
                    console.log('개방형목록조회resultData ', resultData)
                    console.log('조회완료')
                    this.dsProdList = resultData
                })
        },

        f_pre_validation() {
            /*
            let requiredCol = ['', '', '']
            //그리드 Commit
            //this.gridObj.gridView.commit()

            // Grid Validation 체크
            // valiGrid.error 값이 없으면 정상
            // valiGrid.error 값이 있으면 에러
            // valiGrid.error = 'index' - 변경된 행이 없는경우
            // valiGrid.error = 'require' - 필수입력항목 입력누락
            let valiGrid = this.gridObj.validationGrid(
                this.gridData,
                requiredCol
            )

            if (valiGrid.error == 'index') {
                this.showTcComAlert('대상이 존재하지 않습니다.', {
                    header: 'Grid Data 저장',
                    size: '500',
                    confirmLabel: 'OK',
                })

                return false
            } else {
                return true
            }
            */

            let prodAlerMsg = ''
            let prodNmAlerMsg = ''
            let ProdClCdAZone = false
            //let ProdClCdBZone = false
            if (
                '1' == this.basProdMgmt.prodClCd ||
                '2' == this.basProdMgmt.prodClCd ||
                '3' == this.basProdMgmt.prodClCd
            ) {
                prodAlerMsg = '모델코드'
                prodNmAlerMsg = '모델명'
                ProdClCdAZone = true //A 타입일경우 실행
            } else {
                prodAlerMsg = '바코드정보'
                prodNmAlerMsg = '상품명'
                //ProdClCdBZone = true //B 타입일경우 실행
            }
            if ('' == this.basProdMgmt.prodCd) {
                this.showTcComAlert(`${prodAlerMsg}를 입력하세요`, {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }

            /*
            if (
                '' == this.basProdMgmt.lifeBarCd &&
                ('5' == this.basProdMgmt.prodClCd ||
                    '6' == this.basProdMgmt.prodClCd)
            ) {
                this.showTcComAlert('바코드 번호를 입력하세요', {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }
            */

            if ('' == this.basProdMgmt.prodNm) {
                this.showTcComAlert(`${prodNmAlerMsg}를 입력하세요`, {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }

            if ('' == this.basProdMgmt.mfactCd) {
                this.showTcComAlert('제조사를 입력하세요', {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }

            /*
            if ('' == this.basProdMgmt.eqpTypDtlCd) {
                this.showTcComAlert('단말기상세유형을 입력하세요', {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }

            if ('' == this.basProdMgmt.eqpTypClCd) {
                this.showTcComAlert('NETWORK세대를 입력하세요', {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }
*/
            if (ProdClCdAZone) {
                if ('' == this.basProdMgmt.mktgDt) {
                    this.showTcComAlert('출시일을 입력하세요', {
                        header: '',
                        size: '500',
                        confirmLabel: 'OK',
                    })
                    return false
                }
            }

            if ('' == this.basProdMgmt.rgstClCd) {
                this.showTcComAlert('등록구분을 입력하세요', {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }

            let rowCnt = this.gridObj.dataProvider.getRowCount()
            if (1 > rowCnt) {
                this.showTcComAlert('상품색상을 추가하세요.', {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }

            let mktgDt = CommonUtil.replaceDash(this.basProdMgmt.mktgDt)
            let useStopDt = CommonUtil.replaceDash(this.basProdMgmt.useStopDt)

            if ('N' == this.basProdMgmt.useYn && mktgDt > useStopDt) {
                this.showTcComAlert('사용중지일은 출시일이후만 가능합니다', {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }

            // 상품구분이 단말기인 경우만 대표모델이 필요함

            //스윙연동일경우
            if ('1' != this.basProdMgmt.rgstClCd) {
                if (
                    '1' == this.basProdMgmt.prodClCd &&
                    '' == this.basProdMgmt.repProdNm
                ) {
                    this.showTcComAlert('대표모델을 입력하세요', {
                        header: '',
                        size: '500',
                        confirmLabel: 'OK',
                    })
                    return false
                }
            }

            if ('H' == this.saveType) {
                //에코폰 등록시 단말기 등급이 필요함.
                if ('04' == this.basProdMgmt.eqpClCd) {
                    if ('' == this.basProdMgmt.ecoEqpGrCd) {
                        this.showTcComAlert('단말기등급을 입력하세요', {
                            header: '',
                            size: '500',
                            confirmLabel: 'OK',
                        })
                        return false
                    }
                }

                if ('Y' == this.searchParam.FV_OMD_RGST_CL) {
                    if ('04' == this.basProdMgmt.eqpClCd) {
                        if ('1' > this.basProdMgmt.cashPrchsPrc) {
                            this.showTcComAlert('출고가를 확인하세요', {
                                header: '',
                                size: '500',
                                confirmLabel: 'OK',
                            })
                            return false
                        }
                    }
                }
            }

            if ('' == this.basProdMgmt.barCdTypCd) {
                this.showTcComAlert('바코드유형을 입력하세요', {
                    header: '',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }

            if (ProdClCdAZone) {
                if ('' == this.basProdMgmt.dstrbEqpClCd) {
                    this.showTcComAlert('유통단말기구분을 입력하세요', {
                        header: '',
                        size: '500',
                        confirmLabel: 'OK',
                    })
                    return false
                }
            }

            //색상중복체크...

            return true
        },
        //단말기 1 / USIM 2 /스마트디바이스 3 경우
        fnProdClCdAZoneShow() {
            //false일경우 노출
            this.prodClCdAZone = false
            this.prodClCdBZone = true
            this.basProdMgmtDis.ecoEqpGrCdDiv = true
            this.basProdMgmtDis.cashPrchsPrcDiv = true
            this.basProdMgmtDis.cashPrchsPrcDiv = true
            this.basProdMgmtDis.cashPrchsPrc = true
            if (!this.prodClCdAZone) {
                this.prodCdColNm = '모델코드'
                this.prodNmColNm = '모델명'
            }
        },
        //단말기 1 / USIM 2 /스마트디바이스 3 아닐경우
        fnProdClCdBZoneShow() {
            this.prodClCdAZone = true
            this.prodClCdBZone = false
            this.basProdMgmtDis.ecoEqpGrCdDiv = true
            this.basProdMgmtDis.cashPrchsPrcDiv = true
            this.basProdMgmtDis.cashPrchsPrcDiv = true
            this.basProdMgmtDis.cashPrchsPrc = true
            if (!this.prodClCdBZone) {
                this.prodCdColNm = '바코드정보'
                this.prodNmColNm = '상품명'
            }
        },
        //대표모델여부
        fnRepProdCdYn() {
            if ('Y' == this.basProdMgmt.repProdCdYn) {
                console.log('대표모델여부')

                this.basProdMgmt.repProdCd = this.basProdMgmt.prodCd
                this.basProdMgmt.repProdNm = this.basProdMgmt.prodNm
            } else {
                this.basProdMgmt.repProdCd = ''
                this.basProdMgmt.repProdNm = ''
            }
        },
        fnRepPordSame() {
            if (
                this.basProdMgmt.repProdCd == this.basProdMgmt.prodCd &&
                this.basProdMgmt.repProdNm == this.basProdMgmt.prodNm
            ) {
                this.basProdMgmt.repProdCdYn = ['Y']
            } else {
                this.basProdMgmt.repProdCdYn = []
            }
        },
    },
}
</script>
