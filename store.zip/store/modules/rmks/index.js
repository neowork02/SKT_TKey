export default {
    namespaced: true,
    state: {
        _customerInfoWord: [], //고객정보단어
        _forbiddenWord: [], //금지단어
    },
    actions: {
        setCustomerInfoWord({ commit }, customerInfoWord) {
            commit('SET_CUSTOMER_INFO_WORD', customerInfoWord)
        },
        setForbiddenWord({ commit }, forbiddenWord) {
            commit('SET_FORBIDDEN_WORD', forbiddenWord)
        },
    },
    getters: {
        customerInfoWord: (state) => {
            return state._customerInfoWord
        },
        forbiddenWord: (state) => {
            return state._forbiddenWord
        },
    },
    mutations: {
        SET_CUSTOMER_INFO_WORD: (state, payload) => {
            state._customerInfoWord = payload
        },
        SET_FORBIDDEN_WORD: (state, payload) => {
            state._forbiddenWord = payload
        },
    },
}
