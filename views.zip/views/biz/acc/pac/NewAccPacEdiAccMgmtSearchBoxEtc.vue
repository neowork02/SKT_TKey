<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : NewAccPacEdiAccMgmtSearchBoxEtc.vue
 * 설명: 카드입금정산내역/카드입금정산상세/수기입금정산 조회조건 SearchBox
 * 작성자: 최우진
 * 작성일: 2022.09.23
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="searchLayer_wrap" v-if="tabIndex == nowTabIndex">
        <div class="searchform">
            <div class="formitem div2">
                <!-- label + input multi 폼 -->
                <div class="arrayType">
                    <div class="col35">
                        <TCComComboBox
                            labelName="조회일자"
                            itemText="label"
                            itemValue="value"
                            :eRequired="true"
                            :disabled="false"
                            :itemList="[
                                { value: 'patmentDt', label: '승인일' },
                                { value: 'payDt', label: '입금일' },
                            ]"
                            v-model="searchParams.gubun"
                        />
                    </div>
                    <div class="col60 mgl">
                        <TCComDatePicker
                            calType="DP"
                            class="datePicker"
                            :disabled="false"
                            v-model="searchParams.payDt"
                            @change="changePayDt"
                        />
                    </div>
                    <!--// label + input multi 폼 -->
                </div>
            </div>
            <div class="formitem div2"></div>
        </div>
        <div class="searchform">
            <div class="formitem div3">
                <TCComInputSearchText
                    v-model="searchParams.orgNm"
                    :codeVal.sync="searchParams.orgId"
                    labelName="조직"
                    placeholder="입력해주세요"
                    :disabled="false"
                    :disabledAfter="true"
                    :objAuth="objAuth"
                    :eRequired="true"
                    @enterKey="onAuthOrgTreeEnterKey"
                    @appendIconClick="onAuthOrgTreeIconClick"
                    @input="onAuthOrgTreeInput"
                />
                <BasBcoAuthOrgTreesPopup
                    v-if="showBcoAuthOrgTrees"
                    :parentParam="searchParams"
                    :rows="resultAuthOrgTreeRows"
                    :dialogShow.sync="showBcoAuthOrgTrees"
                    @confirm="onAuthOrgTreeReturnData"
                />
            </div>
            <div class="formitem div3">
                <TCComInputSearchText
                    v-model="searchParams.salePlcNm"
                    :codeVal.sync="searchParams.salePlc"
                    labelName="정산처"
                    :disabledAfter="true"
                    :objAuth="objAuth"
                    @appendIconClick="onDealcoIconClick"
                    @input="onDealcoInput"
                />
                <BasBcoDealcosPopup
                    v-if="showBasBcoDealco"
                    :parentParam="searchAccDealcoParams"
                    :dialogShow.sync="showBasBcoDealco"
                    @confirm="onDealcoReturnData"
                />
            </div>
            <div class="formitem div3">
                <TCComInputSearchText
                    v-model="searchParams.cardCoNm"
                    :codeVal.sync="searchParams.cardCoCd"
                    labelName="매입사"
                    placeholder="입력해주세요"
                    :disabledAfter="true"
                    :eRequired="false"
                    :disabled="false"
                    @enterKey="onCommCdDtlEnterKey"
                    @appendIconClick="onCommCdDtlIconClick"
                    @input="onCommCdDtlInput"
                />
                <!-- 매입사팝업(조회조건에서 사용) -->
                <BasBcoCommCdDtlPopup
                    v-if="showBcoCommCdDtl"
                    :parentParam="searchCardCoCdParams"
                    :rows="resultCommCdDtlRows"
                    :dialogShow.sync="showBcoCommCdDtl"
                    @confirm="onCommCdDtlReturnData"
                />
            </div>
        </div>
    </div>
</template>

<script>
import _ from 'lodash'
import moment from 'moment'
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup' // 내부조직팝업(권한)
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees' // 내부조직팝업(권한)
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup' // 내부거래처(권한조직) 팝업
import BasBcoCommCdDtlPopup from '@/components/common/BasBcoCommCdDtlPopup' // 매입사(공통)팝업
import basBcoCommCdDtlApi from '@/api/biz/bas/bco/basBcoCommCdDtl' // 매입사(공통)팝업

export default {
    name: 'NewAccPacEdiAccMgmtSearchBoxEdi',
    components: {
        BasBcoAuthOrgTreesPopup, //  내부조직팝업(권한)
        BasBcoDealcosPopup, // 내부거래처(권한조직)
        BasBcoCommCdDtlPopup, // 매입사
    },
    props: {
        tabIndex: {
            default: 0,
        },
        nowTabIndex: {
            default: 0,
        },
        objAuth: {
            default: {},
        },
        parentParams: {
            default: {},
        },
    },
    data() {
        return {
            showAlertBool: false,

            // 내부조직팝업(권한)
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [],
            // 내부거래처(권한조직)
            showBasBcoDealco: false,
            resultDealcoRows: [],
            searchAccDealcoParams: {
                basDay: '',
                orgCd: '',
                orgNm: '',
                dealcoCd: '',
                dealcoNm: '',
            },
            // 매입사(공통)
            showBcoCommCdDtl: false, // 매입사(공통) 팝업 오픈 여부
            resultCommCdDtlRows: [],
            searchCardCoCdParams: {
                commCdId: 'ZBAS_C_00050', //
                commCdVal: '',
                commCdValNm: '',
            },

            // 조회조건(초기값)
            searchParams: {
                gubun: 'patmentDt',
                payDt: ['', ''],
                payStaDtm: '',
                payEndDtm: '',
                orgId: '',
                orgNm: '',
                orgLevel: '',
                searchCoClOrgCd: '',
                salePlc: '',
                salePlcNm: '',
                cardCoCd: '',
                cardCoNm: '',
            },
        }
    },
    watch: {
        // parentParams의 값을 searchParams에 세팅한다.
        parentParams: {
            handler: function (json) {
                if (!_.isEmpty(json)) {
                    let keys = Object.keys(json)
                    for (let i = 0; i < keys.length; i++) {
                        this.searchParams[keys[i]] = json[keys[i]]
                    }
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        searchParams: {
            handler: function (newJson) {
                this.$emit('setSearchParams', newJson)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        'searchParams.payDt'(newYmd) {
            let _newYmd = newYmd.map((d) => d.replace(/-/g, ''))
            this.searchParams.payStaDtm = _newYmd[0]
            this.searchParams.payEndDtm = _newYmd[1]
        },
    },
    mounted() {
        // tab에 따른 초기값 세팅
        this.initSearchParams()

        // 부모에 변경된 값 전달
        this.$emit('setSearchParams', this.searchParams)
    },
    methods: {
        initSearchParams() {
            let payStaDtm = ''
            let payEndDtm = ''
            if (this.tabIndex == 4) {
                payStaDtm = moment().add(-8, 'days').format('YYYY-MM-DD')
                payEndDtm = moment().format('YYYY-MM-DD')
            } else {
                payStaDtm = moment().format('YYYY-MM-DD')
                payEndDtm = moment().add(2, 'days').format('YYYY-MM-DD')
            }

            this.searchParams.payDt = [payStaDtm, payEndDtm]
            this.searchParams.payStaDtm = payStaDtm.replace(/-/g, '')
            this.searchParams.payEndDtm = payEndDtm.replace(/-/g, '')
        },
        setParamJson(_method) {
            // 현재 tab의 조회조건을 this.searchParams 변수에 세팅한다.
            let _searchParams = _.cloneDeep(this.searchParams)

            // get방식으로 파라미터 넘길 때 오류로 인해 아래 제거함
            if (_method == 'GET') {
                delete _searchParams['payDt']
            }

            return _searchParams
        },
        changePayDt(ymd) {
            ymd.map((d) => d.replace(/-/g, ''))
            this.searchParams.payStaDtm = ymd[0]
            this.searchParams.payEndDtm = ymd[1]
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            let orgParams = {
                orgCd: this.searchParams.orgId,
                orgNm: this.searchParams.orgNm,
            }
            basBcoAuthOrgTreesApi.getAuthOrgTreeList(orgParams).then((res) => {
                console.log('getAuthOrgTreeList then : ', res)
                // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                if (res.length === 1) {
                    this.searchParams.orgId = _.get(res[0], 'orgCd')
                    this.searchParams.orgNm = _.get(res[0], 'orgNm')
                    this.searchParams.orgLevel = _.get(res[0], 'vLevel')
                    this.searchParams.searchCoClOrgCd = _.get(
                        res[0],
                        'orgCdLvl0'
                    )
                } else {
                    this.resultAuthOrgTreeRows = res
                    this.showBcoAuthOrgTrees = true
                }
            })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchParams.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParams.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchParams[this.getSearchOrgName()].orgId = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchParams.orgId = _.get(returnData, 'orgCd')
            this.searchParams.orgNm = _.get(returnData, 'orgNm')
            this.searchParams.orgLevel = _.get(returnData, 'orgLvl')
            this.searchParams.searchCoClOrgCd = _.get(returnData, 'orgCdLvl0')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)) methods ================================
        onDealcoIconClick() {
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []

            let basDay = moment().format('YYYYMM')
            if (!_.isEmpty(this.searchParams.payStaDtm)) {
                basDay = this.searchParams.payStaDtm.substring(0, 6)
            }
            this.searchAccDealcoParams.basDay = basDay
            this.searchAccDealcoParams.orgCd = this.searchParams.orgId
            this.searchAccDealcoParams.orgNm = this.searchParams.orgNm
            this.searchAccDealcoParams.dealcoCd = this.searchParams.salePlc
            this.searchAccDealcoParams.dealcoNm = this.searchParams.salePlcNm

            // 팝업오픈
            this.showBasBcoDealco = true
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchParams.salePlc = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchParams.salePlc = _.get(returnData, 'dealcoCd')
            this.searchParams.salePlcNm = _.get(returnData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직) methods ================================

        //===================== 매입사용도: 공통팝업상세팝업관련 methods ================================
        // 공통팝업상세 조회 후 1건이면 TextField에 바로 설정하고 아니면 공통팝업상세 팝업 오픈
        getCommCdDtlList() {
            var params = {
                ...this.searchCardCoCdParams,
                cd: '',
                nm: this.searchParams.cardCoNm,
            }

            basBcoCommCdDtlApi.getCommCdDtlList(params).then((res) => {
                console.log('getCommCdDtlList then : ', res)

                // 검색된 공통팝업상세 정보가 1건이면 TextField에 바로 설정
                // 검색된 공통팝업상세 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 공통팝업상세 팝업 오픈
                if (res.length === 1) {
                    this.searchCardCoCdParams.cd = _.get(res[0], 'commCdVal')
                    this.searchCardCoCdParams.nm = _.get(res[0], 'commCdValNm')

                    this.searchParams.cardCoCd = _.get(res[0], 'commCdVal')
                    this.searchParams.cardCoNm = _.get(res[0], 'commCdValNm')
                } else {
                    this.resultCommCdDtlRows = res
                    this.showBcoCommCdDtl = true
                }
            })
        },
        // 공통팝업상세 TextField 돋보기 Icon 이벤트 처리
        onCommCdDtlIconClick() {
            // 공통팝업상세 팝업 Row 설정 Prop 변수 초기화
            this.resultCommCdDtlRows = []

            // 검색조건 공통팝업상세명이 빈값이 아니면 공통팝업상세 조회
            // 그 이외는 공통팝업상세 팝업 오픈
            if (!_.isEmpty(this.searchParams.cardCoNm)) {
                this.getCommCdDtlList()
            } else {
                this.showBcoCommCdDtl = true
            }
        },

        // 공통팝업상세 TextField 엔터키 이벤트 처리
        onCommCdDtlEnterKey() {
            // 공통팝업상세 팝업 Row 설정 Prop 변수 초기화
            this.resultCommCdDtlRows = []
            // 검색조건 공통팝업상세명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParams.cardCoNm)) {
                this.showTcComAlert('매입사명을 입력해주세요.')
                return
            }
            // 공통팝업상세 정보 조회
            this.getCommCdDtlList()
        },

        // 공통팝업상세 TextField Input 이벤트 처리
        onCommCdDtlInput() {
            // 입력되는 값이 있으면 공통팝업상세 코드 초기화
            this.popupParamCardCoCd.cd = ''
            this.popupParamCardCoCd.nm = ''
            this.searchParams.cardCoCd = ''
        },

        // 공통팝업상세 팝업 리턴 이벤트 처리
        onCommCdDtlReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParams.cardCoCd = _.get(retrunData, 'commCdVal')
            this.searchParams.cardCoNm = _.get(retrunData, 'commCdValNm')
        },
        //===================== //공통팝업상세팝업관련 methods ================================
    },
}
</script>
