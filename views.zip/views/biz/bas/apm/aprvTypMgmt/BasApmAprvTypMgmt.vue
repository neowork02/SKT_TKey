<!-----------------------------------------------
 * 업무그룹명: 기준정보>기타
 * 서브업무명: 승인유형관리
 * 설명: 승인유형관리 조회/입력/수정/삭제 한다.
 * 작성자: P180392
 * 작성일: 2022.08.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>승인유형관리</h1>
        <!-- // Tit -->
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/apm/aprvTypMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/apm/aprvTypMgmt'

export default {
    name: 'BasApmAprvTypMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (this.$store.hasModule('bas.apm.aprvTypMgmtStore') != true) {
            this.$store.registerModule('bas.apm.aprvTypMgmtStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.apm.aprvTypMgmtStore') == true) {
            this.$store.unregisterModule('bas.apm.aprvTypMgmtStore')
        }
    },

    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>
