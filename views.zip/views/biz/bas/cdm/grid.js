import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wireClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcProdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'scrbStopDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wdrlDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'combProdYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'exist',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'basFeeAmt',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'opDt',
            fieldName: 'opDt',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
            },
        },
        {
            name: 'prodId',
            fieldName: 'prodId',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품ID',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            header: {
                text: '상품명',
            },
        },
        {
            name: 'wireClCd',
            fieldName: 'wireClCd',
            header: {
                text: '유무선구분',
            },
        },
        {
            name: 'svcProdNm',
            fieldName: 'svcProdNm',
            header: {
                text: '상품구분코드',
            },
        },
        {
            name: 'prodStCd',
            fieldName: 'prodStCd',
            header: {
                text: '상품상태',
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            header: {
                text: '출시일',
            },
        },
        {
            name: 'scrbStopDt',
            fieldName: 'scrbStopDt',
            header: {
                text: '가입중단일',
            },
        },
        {
            name: 'wdrlDt',
            fieldName: 'wdrlDt',
            header: {
                text: '퇴출일',
            },
        },
        {
            name: 'combProdYn',
            fieldName: 'combProdYn',
            header: {
                text: '결합상품',
            },
        },
        {
            name: 'aplyYn',
            fieldName: 'aplyYn',
            header: {
                text: '반영여부',
            },
        },
        {
            name: 'exist',
            fieldName: 'exist',
            header: {
                text: '구분',
            },
        },
        {
            name: 'basFeeAmt',
            fieldName: 'basFeeAmt',
            header: {
                text: '기본료',
            },
        },
    ],
}
