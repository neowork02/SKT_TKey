import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직명
        },
        {
            fieldName: 'lvOrgCd',
            dataType: ValueType.TEXT, //레벨0조직코드
        },
        {
            fieldName: 'lvOrgNm',
            dataType: ValueType.TEXT, //레벨0조직명
        },
        {
            fieldName: 'lvOrgNm1',
            dataType: ValueType.TEXT, //레벨1조직명
        },
        {
            fieldName: 'lvOrgNm2',
            dataType: ValueType.TEXT, //레벨2조직명
        },
        {
            fieldName: 'lvOrgNm3',
            dataType: ValueType.TEXT, //레벨3조직명
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, //보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, //보유처명
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT, //제조사코드
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'opLclCd',
            dataType: ValueType.TEXT, //불량사유코드
        },
        {
            fieldName: 'opLclNm',
            dataType: ValueType.TEXT, //불량사유명
        },
        {
            fieldName: 'opMclCd',
            dataType: ValueType.TEXT, //불량사유 상세코드
        },
        {
            fieldName: 'opMclNm',
            dataType: ValueType.TEXT, //불량사유 상세명
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT, //오류사항
        },
        {
            fieldName: 'barCdTypCd',
            dataType: ValueType.TEXT, //바코드종류코드
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'disStCd',
            dataType: ValueType.TEXT, //재고상태코드
        },
        {
            fieldName: 'badDisYn',
            dataType: ValueType.TEXT, //불량재고여부
        },
        {
            fieldName: 'commCdId',
            dataType: ValueType.TEXT, //공통코드ID
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT, //처리자ID
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '조직',
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처코드',
            },
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처명',
            },
        },
        {
            name: 'mfactCd',
            fieldName: 'mfactCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사코드',
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사명',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'opLclNm',
            fieldName: 'opLclNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량사유',
            },
        },
        {
            name: 'opMclNm',
            fieldName: 'opMclNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량사유 상세',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '오류사항',
            },
        },
    ],
}
