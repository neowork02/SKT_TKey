<!-----------------------------------------------
 * 업무그룹명: 기준정보>거래처관리
 * 서브업무명: 거래처관리
 * 설명: 거래처관리 조회/입력/수정/삭제 한다.
 * 작성자: P180291
 * 작성일: 2022.05.09
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>거래처관리</h1>
        <!-- // Tit -->
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dealcoMgmt/helpers'

import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/prm/dealcoMgmt'

export default {
    name: 'BasPrmDealcoMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (!this.$store.hasModule('bas.prm.dealcoMgmtStore')) {
            this.$store.registerModule('bas.prm.dealcoMgmtStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.prm.dealcoMgmtStore')) {
            this.$store.unregisterModule('bas.prm.dealcoMgmtStore')
        }
    },
    components: { MainContent },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>

<style scoped></style>
