import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('bas.adm.batchOperRgstMgmtStore', Object.keys(state)),
    ...mapGetters('bas.adm.batchOperRgstMgmtStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('bas.adm.batchOperRgstMgmtStore', Object.keys(actions)),
    ...mapMutations('bas.adm.batchOperRgstMgmtStore', Object.keys(mutations)),
}
