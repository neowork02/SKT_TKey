<template>
    <div class="content">
        <!-- Tit -->
        <h1>상품관리</h1>
        <!-- // Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    >확장모델등록</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                    >조회</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="dialogClicked()"
                    :objAuth="this.objAuth"
                    >신규</TCComButton
                >
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div5_1">
                    <TCComInputSearchText
                        v-model="searchOutDealParam.dealcoNm"
                        :codeVal.sync="searchOutDealParam.dealcoCd"
                        labelName="제조사"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOutDealEnterKey"
                        @appendIconClick="onOutDealIconClick"
                        @input="onOutDealInput"
                    />
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onOutDealReturnData"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div5_1">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        :autocomplete="true"
                        :objAuth="this.objAuth"
                        v-model="forms.prodCd"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div5_2">
                    <TCComComboBox
                        codeId="ZBAS_C_00020"
                        labelName="상품특성1"
                        v-model="forms.prodChrticCd1"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div5_2">
                    <TCComComboBox
                        codeId="ZBAS_C_00470"
                        labelName="상품특성4"
                        v-model="forms.prodChrticCd4"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <!-- //item 1-4 -->
                <!-- item 1-5 -->
                <div class="formitem div5_2">
                    <TCComCheckBox
                        labelName="정책적용대상"
                        :objAuth="this.objAuth"
                        :itemList="this.chkData"
                    ></TCComCheckBox>
                </div>
                <!-- //item 1-5 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div5_1">
                    <TCComInput
                        labelName="모델명"
                        :objAuth="this.objAuth"
                        v-model="forms.prodNm"
                    >
                    </TCComInput>
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div5_1">
                    <TCComComboBox
                        labelName="단말기구분"
                        v-model="forms.mdlClCd"
                        :objAuth="this.objAuth"
                        :itemList="this.MdlClData"
                        itemText="codeNm"
                        itemValue="codeId"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-2 -->
                <!-- item 2-3 -->
                <div class="formitem div5_2">
                    <TCComComboBox
                        codeId="ZBAS_C_00030"
                        labelName="상품특성2"
                        v-model="forms.prodChrticCd2"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <!-- //item 2-3 -->
                <!-- item 2-4 -->
                <div class="formitem div5_2">
                    <TCComComboBox
                        labelName="사용여부"
                        v-model="forms.useYn"
                        :objAuth="this.objAuth"
                        :itemList="this.Yn"
                        itemText="codeNm"
                        itemValue="codeId"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <!-- //item 2-4 -->
                <!-- item 2-5 -->
                <div class="formitem div5_2">
                    <TCComComboBox
                        labelName="T.Key+주문여부"
                        v-model="forms.ordYn"
                        :objAuth="this.objAuth"
                        :itemList="this.allYn"
                        itemText="codeNm"
                        itemValue="codeId"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-5 -->
            </div>
            <!-- //Search_line 2 -->
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{ ' btn_ty_exp_active ': toggleActive }"
                        @click="toggleActive = !toggleActive"
                    >
                    </v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="toggleActive">
                    <!-- Search_line 3 -->
                    <div class="searchform">
                        <!-- item 3-1 -->
                        <div class="formitem div5_1">
                            <TCComInput
                                labelName="모델코드"
                                v-model="forms.prodCd"
                                :objAuth="this.objAuth"
                            >
                            </TCComInput>
                        </div>
                        <!-- //item 3-1 -->
                        <!-- item 3-2 -->
                        <div class="formitem div5_1">
                            <TCComInput
                                labelName="원모델코드"
                                v-model="forms.prodSetCd"
                                :objAuth="this.objAuth"
                            >
                            </TCComInput>
                        </div>
                        <!-- //item 3-2 -->
                        <!-- item 3-3 -->
                        <div class="formitem div5_2">
                            <TCComComboBox
                                codeId="ZBAS_C_00460"
                                labelName="상품특성3"
                                v-model="forms.prodChrticCd3"
                                :objAuth="this.objAuth"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                            ></TCComComboBox>
                        </div>
                        <!-- //item 3-3 -->
                        <!-- item 3-4 -->
                        <div class="formitem div5_2">
                            <TCComComboBox
                                codeId="ZBAS_C_00440"
                                labelName="통신방식"
                                v-model="forms.comMthdCd"
                                :objAuth="this.objAuth"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                            ></TCComComboBox>
                        </div>
                        <!-- //item 3-4 -->
                        <!-- item 3-5 -->
                        <div class="formitem div5_2">
                            <TCComComboBox
                                labelName="판매분매입여부"
                                v-model="forms.saleInYn"
                                :objAuth="this.objAuth"
                                :itemList="this.allYn"
                                itemText="codeNm"
                                itemValue="codeId"
                            ></TCComComboBox>
                        </div>
                        <!-- //item 3-5 -->
                    </div>
                    <!-- //Search_line 3 -->
                    <!-- Search_line 4 -->
                    <div class="searchform">
                        <!-- item 4-1 -->
                        <div class="formitem div5_1">
                            <!--
                            <TCComInputSearchText
                                labelName="대표모델"
                                :appendIconClass="''"
                                @appendIconClick="repProdCdPopup"
                                @enterKey="repProdCdPopup"
                                placeholder="입력해주세요"
                                :objAuth="this.objAuth"
                                v-model="forms.repProdCd"
                                :disabledAfter="true"
                            >
                            </TCComInputSearchText>
                            -->
                            <TCComInputSearchText
                                v-model="searchProdForm.prodCd"
                                :codeVal.sync="searchProdForm.prodNm"
                                labelName="대표모델"
                                :disabledAfter="true"
                                :objAuth="objAuth"
                                @enterKey="onProdsEnterKey"
                                @appendIconClick="onProdsIconClick"
                                @input="onProdsInput"
                            />
                            <BasBcoProdsPopup
                                v-if="basBcoProdsShow"
                                :parentParam="searchProdForm"
                                :rows="resultProdsRows"
                                :dialogShow.sync="basBcoProdsShow"
                                @confirm="onProdsReturnData"
                            />
                        </div>
                        <!-- //item 4-1 -->
                        <!-- item 4-2 -->
                        <div class="formitem div5_1"></div>
                        <!-- //item 4-2 -->
                        <!-- item 4-3 -->
                        <div class="formitem div5_2">
                            <TCComComboBox
                                labelName="과세구분"
                                v-model="forms.taxTypCd"
                                :objAuth="this.objAuth"
                                :itemList="this.taxTypData"
                                itemText="codeNm"
                                itemValue="codeId"
                            ></TCComComboBox>
                        </div>
                        <!-- //item 4-3 -->
                        <!-- item 4-4 -->
                        <div class="formitem div5_2">
                            <TCComComboBox
                                labelName="단종여부"
                                v-model="forms.endYn"
                                :objAuth="this.objAuth"
                                :itemList="this.Yn"
                                itemText="codeNm"
                                itemValue="codeId"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                            ></TCComComboBox>
                        </div>
                        <!-- //item 4-4 -->
                        <!-- item 4-5 -->
                        <div class="formitem div5_2">
                            <TCComComboBox
                                labelName="SIS상종여부"
                                v-model="forms.sisYn"
                                :objAuth="this.objAuth"
                                :itemList="this.allYn"
                                itemText="codeNm"
                                itemValue="codeId"
                            ></TCComComboBox>
                        </div>
                        <!-- //item 4-5 -->
                    </div>
                    <!-- //Search_line 4 -->
                </div>
            </v-expand-transition>
        </div>
        <!-- //Search_div -->

        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="상품 내역"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @addPageBtn="this.gridAddPageBtn"
                @excelDownBtn="this.exportGridBtn"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div>
        <!-- //gridWrap -->
        <!-- Dialog -->
        <prototype1Popup
            v-if="localDialogShow === true"
            ref="popup"
            :dialogShow.sync="localDialogShow"
        />
    </div>
</template>

<style>
/* @import '@/node_modules/realgrid/dist/realgrid-style.css'; */
</style>

<script>
import { CommonGrid } from '@/utils'

import Prototype1Popup from '@/views/prototype/prototype1Popup'
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================
import protoApi from '@/api/common/prototype'
import { prototype } from '@/views/prototype/js/prototype'

import { msgTxt } from '@/const/msg.Properties.js'

import { GRID_HEADER } from '@/const/grid/sample/sampleGrid'
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
import _ from 'lodash'
export default {
    name: 'Prototype1',
    components: {
        Prototype1Popup,
        BasBcoProdsPopup,
        BasBcoOutDealsPopup,
    },

    data() {
        return {
            //Grid Class init
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            localDialogShow: false,
            //basBcoProdsShow: false,
            view: GRID_HEADER,
            showSearchBool: false,
            alertBodyText: '',

            toggleActive: false,
            objAuth: {
                screenNo: this.$route.meta.breadcrumb,
            },
            taxTypData: [
                {
                    codeId: '',
                    codeNm: '전체',
                },
                {
                    codeId: '1',
                    codeNm: '과세',
                },
                {
                    codeId: '2',
                    codeNm: '비과세',
                },
                {
                    codeId: '3',
                    codeNm: '면세',
                },
            ],
            MdlClData: [
                {
                    codeId: '',
                    codeNm: '전체',
                },
                {
                    codeId: 'N',
                    codeNm: '일반형',
                },
                {
                    codeId: 'Y',
                    codeNm: '개방형',
                },
            ],
            Yn: [
                {
                    codeId: 'Y',
                    codeNm: 'Y',
                },
                {
                    codeId: 'N',
                    codeNm: 'N',
                },
            ],
            allYn: [
                {
                    codeId: '',
                    codeNm: '전체',
                },
                {
                    codeId: 'Y',
                    codeNm: 'Y',
                },
                {
                    codeId: 'N',
                    codeNm: 'N',
                },
            ],
            chkData: [
                {
                    codeId: '1',
                    codeNm: '',
                },
            ],
            //각각 엘리먼트 컴포넌트 v-model
            forms: new prototype(),
            searchForms: {},
            rowCnt: 4,
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '2X', // 거래처그룹
                dealcoClCd1: '20', // 거래처구분
            },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            searchProdForm: {
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
            },
            resultProdsRows: [],
            //====================//상품팝업관련==================
        }
    },
    mounted() {
        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        //Default false
        this.gridObj.setGridState(true)

        console.log('objAuth', this.objAuth)
    },
    computed: {},
    methods: {
        init: function () {
            this.gridData = this.GridSetData()
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            console.log('초기화 함수호출')
            //CommonUtil.clearPage(this.$router) // 초기화 함수
        },
        //Grid Init
        GridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        //Grid Paging Move(Append)
        gridAddPageBtn: function () {
            if (
                !this.searchForms.pageNum ||
                this.gridData.totalPage <= this.searchForms.pageNum
            ) {
                this.showSearchBool = true
                this.alertBodyText = msgTxt.MSG_01041
            } else {
                //Page Move
                this.searchForms.pageNum += 1
                protoApi.getPproductListList(this.searchForms).then((res) => {
                    console.log(res)
                    this.gridData.gridRows = this.gridHeaderObj.setAddPage(
                        this.gridData.gridRows,
                        res
                    )
                    //Grid Row 가져올때 페이지정보 Setting
                    this.gridHeaderObj.setPageCount(res.pagingDto)
                })
            }
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            this.gridHeaderObj.exportGrid('prototype.xls')
        },
        //조회 버튼 이벤트
        searchBtn: function () {
            //첫 조회시 표시할 행의 갯수
            this.forms.pageSize = this.rowCnt
            this.forms.pageNum = 1 //첫번째 페이지
            protoApi.getPproductListList(this.forms).then((res) => {
                this.searchForms = this.forms
                console.log(res)
                //Get Row Data
                this.gridObj.setRows(res.gridList)

                this.gridData = this.GridSetData() //초기화
                this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수

                //Grid Row 가져올때 페이지정보 Setting
                this.gridHeaderObj.setPageCount(res.pagingDto)

                console.log('조회완료')
            })
        },

        //팝업열기
        dialogClicked: function () {
            this.localDialogShow = true
        },

        //대표모델 팝업
        repProdCdPopup: function () {
            this.basBcoProdsShow = true
        },
        /*
        btnClick() {},
        */
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                console.log('getProdsList : ', res)
                if (res === undefined) return
                if (res.length === 1) {
                    this.searchProdForm.prodCd = _.get(res[0], 'prodCd')
                    this.searchProdForm.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.searchProdForm.prodCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchProdForm.prodCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchProdForm.prodNm = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchProdForm.prodCd = _.get(retrunData, 'prodCd')
            this.searchProdForm.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    console.log('getOutDealList then : ', res)
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.searchOutDealParam.dealcoCd = _.get(
                            res[0],
                            'dealcoCd'
                        )
                        this.searchOutDealParam.dealcoNm = _.get(
                            res[0],
                            'dealcoNm'
                        )
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            if (!_.isEmpty(this.searchOutDealParam.dealcoNm)) {
                this.getOutDealList()
            } else {
                this.showBcoOutDeals = true
            }
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchOutDealParam.dealcoNm)) {
                this.showTcComAlert('외부거래처명을 입력해주세요.')
                return
            }
            // 외부거래처 정보 조회
            this.getOutDealList()
        },
        // 외부거래처 TextField Input 이벤트 처리
        onOutDealInput() {
            // 입력되는 값이 있으면 외부거래처 코드 초기화
            this.searchOutDealParam.dealcoCd = ''
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchOutDealParam.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.searchOutDealParam.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
    },
}
</script>
