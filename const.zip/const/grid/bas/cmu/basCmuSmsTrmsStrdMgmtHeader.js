import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        // {
        //     fieldName: 'pagingSeq',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo5',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo6',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo7',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo8',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo9',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo10',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsSaleYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsAllotAddYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsAllotCnclYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsSuplYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUser',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        // {
        //     name: 'pagingSeq',
        //     fieldName: 'pagingSeq',
        //     header: {
        //         text: 'No.',
        //     },
        // },
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            header: {
                text: '채널코드',
            },
            editor: {
                textCase: 'upper',
                maxLength: 10,
            },
            styleCallback(grid, dataCell) {
                let ret = {}
                if (
                    dataCell.item.rowState == 'created' ||
                    dataCell.item.rowState == 'appending' ||
                    dataCell.item.rowState == 'inserting'
                ) {
                    ret.editable = true
                } else {
                    ret.editable = false
                    ret.styleName = 'orange-column'
                }
                return ret
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            header: {
                text: '거래처코드',
            },
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: {
                text: '거래처명',
            },
            editable: false,
            width: 150,
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            editable: false,
            header: {
                text: '조직',
            },
            width: '400',
            styleName: 'left-column',
        },
        {
            name: 'mblPhonNo1',
            fieldName: 'mblPhonNo1',
            header: {
                text: 'SMS1',
            },
            editor: {
                type: 'line',
                maxLength: 14,
                inputCharacters: '0-9',
            },
        },
        {
            name: 'mblPhonNo2',
            fieldName: 'mblPhonNo2',
            header: {
                text: 'SMS2',
            },
            editor: {
                type: 'line',
                maxLength: 14,
                inputCharacters: '0-9',
            },
        },
        {
            name: 'mblPhonNo3',
            fieldName: 'mblPhonNo3',
            header: {
                text: 'SMS3',
            },
            editor: {
                type: 'line',
                maxLength: 14,
                inputCharacters: '0-9',
            },
        },
        {
            name: 'mblPhonNo4',
            fieldName: 'mblPhonNo4',
            header: {
                text: 'SMS4',
            },
            editor: {
                type: 'line',
                maxLength: 14,
                inputCharacters: '0-9',
            },
        },
        {
            name: 'mblPhonNo5',
            fieldName: 'mblPhonNo5',
            header: {
                text: 'SMS5',
            },
            editor: {
                type: 'line',
                maxLength: 14,
                inputCharacters: '0-9',
            },
        },
        {
            name: 'mblPhonNo6',
            fieldName: 'mblPhonNo6',
            header: {
                text: 'SMS6',
            },
            editor: {
                type: 'line',
                maxLength: 14,
                inputCharacters: '0-9',
            },
        },
        {
            name: 'mblPhonNo7',
            fieldName: 'mblPhonNo7',
            header: {
                text: 'SMS7',
            },
            editor: {
                type: 'line',
                maxLength: 14,
                inputCharacters: '0-9',
            },
        },
        {
            name: 'mblPhonNo8',
            fieldName: 'mblPhonNo8',
            header: {
                text: 'SMS8',
            },
            editor: {
                type: 'line',
                maxLength: 14,
                inputCharacters: '0-9',
            },
        },
        {
            name: 'mblPhonNo9',
            fieldName: 'mblPhonNo9',
            header: {
                text: 'SMS9',
            },
            editor: {
                type: 'line',
                maxLength: 14,
                inputCharacters: '0-9',
            },
        },
        {
            name: 'mblPhonNo10',
            fieldName: 'mblPhonNo10',
            header: {
                text: 'SMS10',
            },
            editor: {
                type: 'line',
                maxLength: 14,
                inputCharacters: '0-9',
            },
        },
        {
            name: 'smsYn',
            fieldName: 'smsYn',
            header: {
                text: '전송여부',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'smsSaleYn',
            fieldName: 'smsSaleYn',
            header: {
                text: '판매',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'smsAllotAddYn',
            fieldName: 'smsAllotAddYn',
            header: {
                text: '할부추가',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'smsAllotCnclYn',
            fieldName: 'smsAllotCnclYn',
            header: {
                text: '할부취소',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'smsSuplYn',
            fieldName: 'smsSuplYn',
            header: {
                text: '부가상품',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'modUser',
            fieldName: 'modUser',
            header: {
                text: '최종처리자',
            },
            editable: false,
            width: 200,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '최종처리일자',
            },
            editable: false,
            width: 200,
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            header: {
                text: '최종처리자',
            },
            editable: false,
            width: 200,
            visible: false,
        },
    ],
}
