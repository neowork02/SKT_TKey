import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmCd', // 전송구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmNm', // 전송구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqClCd', // 마감요청구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqItemNm', // 마감요청구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId', // 마감요청자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDtm', // 마감요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'trmsItmCd',
            fieldName: 'trmsItmCd',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '전송구분코드',
        },
        {
            name: 'trmsItmNm',
            fieldName: 'trmsItmNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '전송구분명',
        },
        {
            name: 'trmsReqItemNm',
            fieldName: 'trmsReqItemNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '마감요청구분',
        },
        {
            name: 'reqUserId',
            fieldName: 'reqUserId',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '마감요청자',
        },
        {
            name: 'reqDtm',
            fieldName: 'reqDtm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '마감요청일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
    ],
}

export const ORGCLS_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmCd', // 전송구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmNm', // 전송구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqClCd', // 마감요청구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqItemNm', // 마감요청구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId', // 마감요청자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDtm', // 마감요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'trmsItmCd',
            fieldName: 'trmsItmCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송구분코드',
        },
        {
            name: 'trmsItmNm',
            fieldName: 'trmsItmNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송구분명',
        },
        {
            name: 'trmsReqItemNm',
            fieldName: 'trmsReqItemNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '마감요청구분',
        },
        {
            name: 'reqUserId',
            fieldName: 'reqUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '마감요청자',
        },
        {
            name: 'reqDtm',
            fieldName: 'reqDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '마감요청일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
    ],
}

export const DEALCOCLS_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크박스
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chkable', // 체크박스 필터용 조건 화면에서 사용한다.
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoShopCd', // 거래처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmCd', // 전송구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsItmNm', // 전송구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqClCd', // 마감요청구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsReqItemNm', // 마감요청구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId', // 마감요청자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDtm', // 마감요청일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '조직',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'dealcoShopCd',
            fieldName: 'dealcoShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처매장코드',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처코드',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처명',
        },
        {
            name: 'trmsItmCd',
            fieldName: 'trmsItmCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송구분코드',
        },
        {
            name: 'trmsItmNm',
            fieldName: 'trmsItmNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송구분명',
        },
        {
            name: 'trmsReqItemNm',
            fieldName: 'trmsReqItemNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '마감요청구분',
        },
        {
            name: 'reqUserId',
            fieldName: 'reqUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '마감요청자',
        },
        {
            name: 'reqDtm',
            fieldName: 'reqDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '마감요청일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
    ],
}
