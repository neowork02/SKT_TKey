import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'opDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'batchProgId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'progNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'objDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'failCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'staDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'endDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opRsltCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'workTm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'opDtm',
            fieldName: 'opDtm',
            type: 'data',
            header: {
                text: '배치작업등록일시',
            },
            editable: false,
            visible: true,
            width: '150',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99 99:99:99',
                },
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'batchProgId',
            fieldName: 'batchProgId',
            type: 'data',
            header: {
                text: '배치ID',
            },
            editable: false,
            visible: true,
            width: '200',
        },
        {
            name: 'progNm',
            fieldName: 'progNm',
            type: 'data',
            header: {
                text: '배치명',
            },
            editable: false,
            visible: true,
            width: '200',
        },
        {
            name: 'objDt',
            fieldName: 'objDt',
            type: 'data',
            header: {
                text: '대상일자',
            },
            editable: false,
            visible: true,
            width: '100',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99',
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'failCnt',
            fieldName: 'failCnt',
            type: 'data',
            header: {
                text: '실패건수',
            },
            editable: false,
            visible: true,
            width: '80',
        },
        {
            name: 'staDtm',
            fieldName: 'staDtm',
            type: 'data',
            header: {
                text: '배치작업시작일시',
            },
            editable: false,
            visible: true,
            width: '150',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99 99:99:99',
                },
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'endDtm',
            fieldName: 'endDtm',
            type: 'data',
            header: {
                text: '배치작업종료일시',
            },
            editable: false,
            visible: true,
            width: '150',
            editor: {
                type: 'date',
                datetimeFormat: 'yyyyMMdd',
                textReadOnly: true,
                mask: {
                    editMask: '9999-99-99 99:99:99',
                },
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            header: {
                text: '비고',
            },
            editable: false,
            visible: true,
            width: '250',
            renderer: {
                showTooltip: true,
            },
        },
        {
            name: 'opRsltCd',
            fieldName: 'opRsltCd',
            type: 'data',
            header: {
                text: '작업결과',
            },
            editable: false,
            visible: true,
            width: '80',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
        },
        {
            name: 'workTm',
            fieldName: 'workTm',
            type: 'data',
            header: {
                text: '작업시간',
            },
            editable: false,
            visible: true,
            width: '100',
        },

        // {
        //     name: 'reqDt',
        //     fieldName: 'reqDt',
        //     header: {
        //         text: '요청일자',
        //     },
        //     editable: false,
        //     visible: true,
        //     width: '150',
        //     editor: {
        //         type: 'date',
        //         datetimeFormat: 'yyyyMMdd',
        //         textReadOnly: true,
        //         mask: {
        //             editMask: '9999-99-99',
        //         },
        //     },
        //     textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        // },
    ],
}
