<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">추가근무지이력관리</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->

                    <!-- //Search_div -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="addDutypHstMgmtGridHeader"
                            ref="addDutypHstMgmtGridHeader"
                            :gridObj="gridObj"
                        />
                        <TCRealGrid
                            id="addDutypHstMgmtGrid"
                            ref="addDutypHstMgmtGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
        </template>
    </TCComDialog>
</template>

<script>
import { HEADER } from '@/const/grid/bas/usm/basUsmAddDutypHstMgmtHeader'

export default {
    name: 'BasUsmAddDutypHstMgmtPopup',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            showAlertBool: false,
            headerText: '',
            alertBodyText: '',
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: HEADER,
            parentData: [],
        }
    },

    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.addDutypHstMgmtGrid
        this.gridHeaderObj = this.$refs.addDutypHstMgmtGridHeader
        this.initGrid()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentData', value)
                this.parentData = value
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        async initGrid() {
            this.gridObj.setGridState(false)
            this.gridObj.gridView.setRowIndicator({ visible: true })

            this.gridObj.setRows(this.parentData)
        },

        onClose() {
            this.activeOpen = false
        },
    },
}
</script>
