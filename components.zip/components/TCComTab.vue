<!-----------------------------------------------
 * 업무그룹명: Tab 컴포넌트
 * 서브업무명: Tab 공통함수
 * 설명: Tab 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.03.22
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="tabLv1_wrap">
        <v-tabs
            v-model="activeTab"
            :background-color="tabColor"
            :color="textColor"
            :centered="centered"
            :grow="grow"
            :height="height"
            :hide-slider="hideSlider"
            :slider-color="sliderColor"
            :slider-size="sliderSize"
            :vertical="vertical"
            @change="emitChange"
            class="tabLv1"
            active-class="active"
        >
            <v-tab
                v-for="(itemName, index) in itemName"
                :key="index"
                :ripple="false"
                @click="emitClick(index)"
                :disabled="chkAuthTab(index)"
            >
                {{ itemName }}
            </v-tab>
        </v-tabs>
        <v-tabs-items v-model="activeTab">
            <v-tab-item v-for="(item, index) in items" :key="index">
                <div class="tabLv1 panels">
                    <v-card flat>
                        <slot
                            :name="
                                item
                                    .replace(/\//g, '')
                                    .replace(/ /g, '')
                                    .replace(/-/g, '')
                            "
                        ></slot>
                    </v-card>
                </div>
            </v-tab-item>
        </v-tabs-items>
    </div>
</template>

<script>
import { CommonUtil } from '@/utils'
import CommonMixin from '@/mixins'
export default {
    inheritAttrs: false,
    name: 'TCComTab',
    mixins: [CommonMixin],
    components: {},
    props: {
        tab: { type: [Number, String], default: 0, required: false },
        items: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        },
        itemName: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        },
        tabColor: { type: String, default: '', required: false }, // 탭 색상
        textColor: { type: String, default: '', required: false }, // Active 폰트 색상
        centered: { type: Boolean, default: false, required: false }, // 가운데정렬
        grow: { type: Boolean, default: false, required: false }, // 부모 width 풀로 채움
        height: { type: String, default: '', required: false }, // 탭 bar 높이
        hideSlider: { type: Boolean, default: false, required: false }, // 밑줄삭제
        sliderColor: { type: String, default: '', required: false }, // Active Tab 밑줄색상
        sliderSize: { type: String, default: '2', required: false }, // Active Tab 밑줄크기
        vertical: { type: Boolean, default: false, required: false }, // 세로정렬
        objAuth: { type: Object, default: () => {}, required: false }, // auth
    },
    data() {
        return {
            dCKey: this.cKey,
            tabMoveCnt: 0,
        }
    },
    computed: {
        activeTab: {
            get() {
                return this.tab
            },
            set(value) {
                this.$emit('update:tab', value)
            },
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {},
        emitChange(tabIdx) {
            this.$emit('change', tabIdx)
        },
        emitClick(tabIdx) {
            this.$emit('click', tabIdx)
        },
        //탭권한 체크
        chkAuthTab(index) {
            //탭 권한설정
            let authTab = CommonUtil.setObjAuth(
                this.$route.path,
                'TAB' + (index + 1)
            )

            //권한있는 탭으로 이동
            if (authTab === false && this.tabMoveCnt === 0) {
                this.activeTab = index
                this.tabMoveCnt++
            }
            // disable 적용할경우
            return authTab
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
