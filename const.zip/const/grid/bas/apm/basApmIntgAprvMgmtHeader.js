import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        { fieldName: 'aprvSeq', dataType: ValueType.TEXT }, // 통합승인관리SEQ
        { fieldName: 'lvOrgCd', dataType: ValueType.TEXT }, // 회사코드
        { fieldName: 'aprvTypCd', dataType: ValueType.TEXT }, // 승인유형코드
        { fieldName: 'aprvStCd', dataType: ValueType.TEXT }, // 승인상태코드
        { fieldName: 'reqStCd', dataType: ValueType.TEXT }, // 요청상태코드
        { fieldName: 'reqOrgCd', dataType: ValueType.TEXT }, // 요청조직코드
        { fieldName: 'reqUserNm', dataType: ValueType.TEXT }, // 요청사용자ID
        { fieldName: 'reqDtm', dataType: ValueType.TEXT }, // 요청일시
        { fieldName: 'aprvUserNm', dataType: ValueType.TEXT }, // 승인사용자ID
        { fieldName: 'aprvDtm', dataType: ValueType.TEXT }, // 승인일시
        { fieldName: 'delYn', dataType: ValueType.TEXT }, // 삭제여부
        { fieldName: 'menuGrpCd', dataType: ValueType.TEXT }, // 업무구분

        { fieldName: 'menuGrpNm', dataType: ValueType.TEXT }, // 업무구분명
        { fieldName: 'aprvTypNm', dataType: ValueType.TEXT }, // 승인유형코드명
        { fieldName: 'aprvStNm', dataType: ValueType.TEXT }, // 승인상태코드명
        { fieldName: 'reqStNm', dataType: ValueType.TEXT }, // 요청상태코드명
        { fieldName: 'reqMenuNm', dataType: ValueType.TEXT }, // 요청화면
        { fieldName: 'aprvApiUrl', dataType: ValueType.TEXT }, //
        { fieldName: 'treeOrgNm', dataType: ValueType.TEXT }, // 소속조직
        { fieldName: 'dealSktCd', dataType: ValueType.TEXT }, // 소속매장
        { fieldName: 'aprvDtlInfo01', dataType: ValueType.TEXT }, // 추가정보01
        { fieldName: 'aprvDtlInfo02', dataType: ValueType.TEXT }, // 추가정보02
        { fieldName: 'aprvDtlInfo03', dataType: ValueType.TEXT }, // 추가정보03
    ],
    columns: [
        {
            name: 'aprvSeq',
            fieldName: 'aprvSeq',
            header: { text: '통합승인관리SEQ' },
            editable: false,
            visible: false,
        }, // 통합승인관리SEQ
        {
            name: 'menuGrpCd',
            fieldName: 'menuGrpCd',
            header: { text: '업무구분' },
            editable: false,
            visible: false,
        }, // 업무구분
        {
            name: 'lvOrgCd',
            fieldName: 'lvOrgCd',
            header: { text: '회사코드' },
            editable: false,
            visible: false,
        }, // 회사코드
        {
            name: 'aprvTypCd',
            fieldName: 'aprvTypCd',
            header: { text: '승인유형코드' },
            editable: false,
            visible: false,
        }, // 승인유형코드
        {
            name: 'aprvStCd',
            fieldName: 'aprvStCd',
            header: { text: '승인상태코드' },
            editable: false,
            visible: false,
        }, // 승인상태코드
        {
            name: 'reqStCd',
            fieldName: 'reqStCd',
            header: { text: '요청상태코드' },
            editable: false,
            visible: false,
        }, // 요청상태코드
        {
            name: 'reqOrgCd',
            fieldName: 'reqOrgCd',
            header: { text: '요청조직코드' },
            editable: false,
            visible: false,
        }, // 요청조직코드
        {
            name: 'reqUserNm',
            fieldName: 'reqUserNm',
            header: { text: '요청자' },
            editable: false,
            visible: true,
        }, // 요청사용자ID
        {
            name: 'reqDtm',
            fieldName: 'reqDtm',
            header: { text: '요청일시' },
            editable: false,
            visible: true,
        }, // 요청일시
        {
            name: 'aprvUserNm',
            fieldName: 'aprvUserNm',
            header: { text: '승인자' },
            editable: false,
            visible: true,
        }, // 승인사용자ID
        {
            name: 'aprvDtm',
            fieldName: 'aprvDtm',
            header: { text: '승인일시' },
            editable: false,
            visible: true,
        }, // 승인일시
        {
            name: 'delYn',
            fieldName: 'delYn',
            header: { text: '삭제여부' },
            editable: false,
            visible: false,
        }, // 삭제여부
        {
            name: 'menuGrpNm',
            fieldName: 'menuGrpNm',
            header: { text: '업무구분' },
            editable: false,
            visible: true,
        }, // 업무구분
        {
            name: 'aprvTypNm',
            fieldName: 'aprvTypNm',
            header: { text: '승인유형명' },
            editable: false,
            visible: true,
        }, // 승인유형명
        {
            name: 'reqMenuNm',
            fieldName: 'reqMenuNm',
            header: { text: '요청화면' },
            editable: false,
            visible: true,
        }, // 요청화면
        {
            name: 'aprvStNm',
            fieldName: 'aprvStNm',
            header: { text: '요청상태' },
            editable: false,
            visible: true,
        }, // 요청상태
        {
            name: 'aprvApiUrl',
            fieldName: 'aprvApiUrl',
            header: { text: '' },
            editable: false,
            visible: false,
        }, // 요청상태
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            header: { text: '소속조직' },
            editable: false,
            visible: true,
        }, // 요청상태
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            header: { text: '소속매장' },
            editable: false,
            visible: true,
        }, // 요청상태
        {
            name: 'aprvDtlInfo01',
            fieldName: 'aprvDtlInfo01',
            header: { text: '추가정보01' },
            editable: false,
            visible: true,
        }, // 요청상태
        {
            name: 'aprvDtlInfo02',
            fieldName: 'aprvDtlInfo02',
            header: { text: '추가정보02' },
            editable: false,
            visible: true,
        }, // 요청상태
        {
            name: 'aprvDtlInfo03',
            fieldName: 'aprvDtlInfo03',
            header: { text: '추가정보03' },
            editable: false,
            visible: true,
        }, // 요청상태
    ],
}

export const M_HEADER2 = {
    fields: [
        { fieldName: 'menuGrpNm', dataType: ValueType.TEXT }, // 업무구분
        { fieldName: 'aprvTypNm', dataType: ValueType.TEXT }, // 승인유형명
        { fieldName: 'reqMenuNm', dataType: ValueType.TEXT }, // 요청화면
        { fieldName: 'aprvDtlInfo01', dataType: ValueType.TEXT }, // 추가정보01
        { fieldName: 'aprvDtlInfo02', dataType: ValueType.TEXT }, // 추가정보02
        { fieldName: 'aprvDtlInfo03', dataType: ValueType.TEXT }, // 추가정보03
        { fieldName: 'aprvDtlInfo04', dataType: ValueType.TEXT }, // 추가정보04
        { fieldName: 'aprvDtlInfo05', dataType: ValueType.TEXT }, // 추가정보05
        { fieldName: 'aprvDtlInfo06', dataType: ValueType.TEXT }, // 추가정보06
        { fieldName: 'aprvDtlInfo07', dataType: ValueType.TEXT }, // 추가정보07
        { fieldName: 'aprvDtlInfo08', dataType: ValueType.TEXT }, // 추가정보08
        { fieldName: 'aprvDtlInfo09', dataType: ValueType.TEXT }, // 추가정보09
        { fieldName: 'aprvDtlInfo10', dataType: ValueType.TEXT }, // 추가정보10
    ],
    columns: [
        {
            name: 'menuGrpNm',
            fieldName: 'menuGrpNm',
            header: { text: '업무구분' },
            editable: false,
            visible: true,
        }, // 업무구분
        {
            name: 'aprvTypNm',
            fieldName: 'aprvTypNm',
            header: { text: '승인유형명' },
            editable: false,
            visible: true,
        }, // 승인유형명
        {
            name: 'reqMenuNm',
            fieldName: 'reqMenuNm',
            header: { text: '요청화면' },
            editable: false,
            visible: true,
        }, // 요청화면

        {
            name: 'aprvDtlInfo01',
            fieldName: 'aprvDtlInfo01',
            header: { text: '추가정보01' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo02',
            fieldName: 'aprvDtlInfo02',
            header: { text: '추가정보02' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo03',
            fieldName: 'aprvDtlInfo03',
            header: { text: '추가정보03' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo04',
            fieldName: 'aprvDtlInfo04',
            header: { text: '추가정보04' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo05',
            fieldName: 'aprvDtlInfo05',
            header: { text: '추가정보05' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo06',
            fieldName: 'aprvDtlInfo06',
            header: { text: '추가정보06' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo07',
            fieldName: 'aprvDtlInfo07',
            header: { text: '추가정보07' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo08',
            fieldName: 'aprvDtlInfo08',
            header: { text: '추가정보08' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo09',
            fieldName: 'aprvDtlInfo09',
            header: { text: '추가정보09' },
            editable: false,
            visible: true,
        },
        {
            name: 'aprvDtlInfo10',
            fieldName: 'aprvDtlInfo10',
            header: { text: '추가정보10' },
            editable: false,
            visible: true,
        },
    ],
}
