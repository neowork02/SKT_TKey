'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: '__rowState',
        dataType: ValueType.TEXT,
        visible: false,
    },

    {
        fieldName: 'wrtDt',
        readOnly: false,
        editor: { type: 'date' },
        header: { text: '전기일' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },

    {
        fieldName: 'org2Nm',
        editable: false,
        header: { text: '사업담당' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'org3Nm',
        editable: false,
        header: { text: '영업팀' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'org4Nm',
        editable: false,
        header: { text: '영업파트' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'dealCoCd',
        readOnly: false,
        header: { text: '거래처' },
        type: 'data',
        dataType: ValueType.TEXT,
        button: 'action',
    },

    {
        fieldName: 'dealCoNm',
        editable: false,
        header: { text: '거래처명' },
        type: 'data',
        dataType: ValueType.TEXT,
        footer: {
            text: '합계',
        },
    },

    {
        fieldName: 'dealcoClCd1',
        editable: false,
        header: { text: '거래처구분코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'dealCoCl',
        editable: false,
        header: { text: '거래처구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'adjtSeq',
        editable: false,
        header: { text: '조정순번' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'adjtAmt',
        readOnly: false,
        header: { text: '조정금액' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
        footer: {
            text: '0',
            expression: 'sum',
            numberFormat: '#,###,###,###',
        },
    },

    {
        fieldName: 'rmks',
        readOnly: false,
        header: { text: '비고' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'opUserId',
        editable: false,
        header: { text: '처리자ID' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'opUserNm',
        editable: false,
        header: { text: '처리자명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'opDtm',
        editable: false,
        header: { text: '처리일시' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyy-MM-dd hh:mm:ss',
        columnDatetimeFormat: 'yyyy-MM-dd hh:mm:ss',
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {
    accPacPrseBondAdjMgmtGrid: {
        gridList: [
            {
                wrtDt: '20211010',
                org2Nm: 'A',
                org3Nm: '202110',
                org4Nm: 'AA1200',
                dealCoCd: 'orgNm2',
                dealCoNm: 'AB1414',
                dealCoCl1: 'orgNm3',
                dealCoCl: null,
                adjtSeq: null,
                adjtAmt: '10202838383',
                rmks: '오늘날짜',
                opUserId: 'A3',
                opUserNm: '판매점',
                opDtm: 1,
            },

            {
                wrtDt: '20211010',
                org2Nm: 'B',
                org3Nm: '202110',
                org4Nm: 'AA1200',
                dealCoCd: 'orgNm2',
                dealCoNm: 'AB1414',
                dealCoCl1: 'orgNm3',
                dealCoCl: null,
                adjtSeq: null,
                adjtAmt: '10202838383',
                rmks: '오늘날짜',
                opUserId: 'A3',
                opUserNm: '판매점',
                opDtm: 1,
            },

            {
                wrtDt: '20211010',
                org2Nm: 'C',
                org3Nm: '202110',
                org4Nm: 'AA1200',
                dealCoCd: 'orgNm2',
                dealCoNm: 'AB1414',
                dealCoCl1: 'orgNm3',
                dealCoCl: null,
                adjtSeq: null,
                adjtAmt: '10202838383',
                rmks: '오늘날짜',
                opUserId: 'A3',
                opUserNm: '판매점',
                opDtm: 1,
            },

            {
                wrtDt: '20211010',
                org2Nm: 'D',
                org3Nm: '202110',
                org4Nm: 'AA1200',
                dealCoCd: 'orgNm2',
                dealCoNm: 'AB1414',
                dealCoCl1: 'orgNm3',
                dealCoCl: null,
                adjtSeq: null,
                adjtAmt: '10202838383',
                rmks: '오늘날짜',
                opUserId: 'A3',
                opUserNm: '판매점',
                opDtm: 1,
            },

            {
                wrtDt: '20211010',
                org2Nm: 'E',
                org3Nm: '202110',
                org4Nm: 'AA1200',
                dealCoCd: 'orgNm2',
                dealCoNm: 'AB1414',
                dealCoCl1: 'orgNm3',
                dealCoCl: null,
                adjtSeq: null,
                adjtAmt: '10202838383',
                rmks: '오늘날짜',
                opUserId: 'A3',
                opUserNm: '판매점',
                opDtm: 1,
            },

            {
                wrtDt: '20211010',
                org2Nm: 'F',
                org3Nm: '202110',
                org4Nm: 'AA1200',
                dealCoCd: 'orgNm2',
                dealCoNm: 'AB1414',
                dealCoCl1: 'orgNm3',
                dealCoCl: null,
                adjtSeq: null,
                adjtAmt: '10202838383',
                rmks: '오늘날짜',
                opUserId: 'A3',
                opUserNm: '판매점',
                opDtm: 1,
            },
        ],
        pagingDto: {
            pageSize: 10,
            pageNum: 1,
            totalPageCnt: 45,
            totalDataCnt: 0,
        },
    },
}

export { GRID_HEADER, MOCK_DATA }
