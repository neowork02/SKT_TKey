<!-----------------------------------------------
 * 업무그룹명: 레이아웃 Content 컴포넌트
 * 서브업무명: 레이아웃 Content 컴포넌트 
 * 설명: 레이아웃 Content 부분 라우팅 처리
 * 작성자: 양현모
 * 작성일: 2022.11.21
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="container">
        <v-slide-x-transition :hide-on-leave="true">
            <router-view></router-view>
        </v-slide-x-transition>
    </div>
</template>

<script>
export default {
    components: {},
    computed: {},
}
</script>
<style></style>
