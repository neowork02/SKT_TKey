<!-----------------------------------------------
 * 업무그룹명: Input 컴포넌트 (No Label)
 * 서브업무명: Input 컴포넌트 (No Label)
 * 설명: 퍼블리싱 적용된 Input 컴포넌트및 공통함수 
 * 작성자: 최고운
 * 작성일: 2022.04.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <span :class="spanClass">
        <TcComTextField
            ref="tcComNoLabelInput"
            v-model="dValue"
            outlined
            dense
            :type="type"
            :size="size"
            :maxlength="maxlength"
            :style="cSize"
            :placeholder="placeholder"
            :readonly="readonly"
            :disabled="disabled"
            :inputRuleType="inputRuleType"
            :suffix="suffix"
            :prefix="prefix"
            :autofocus="autofocus"
            :clearable="clearable"
            :singleLine="true"
            :commaFormat="commaFormat"
            :rateFormat="rateFormat"
            @input="emitInput"
            @click="emitClick"
            @change="emitChange"
            @blur="emitBlur"
            @focus="emitFocus"
            @key-down="emitKeyDown"
            @enterKey="emitEnterKey"
            @enterKeyUp="emitEnterKeyUp"
            @mouse-down="emitMouseDown"
            @clear-click="emitClearClick"
            :textReverse="textReverse"
        >
        </TcComTextField>
    </span>
</template>
<style lang="scss" scoped>
// scss source
</style>
<script>
import TcComTextField from './TCComTextField'
import _ from 'lodash'
export default {
    inheritAttrs: false,
    name: 'TCComNoLabelInput',
    components: { TcComTextField },
    props: {
        // 입력값,양방향 바인딩
        value: { type: [String, Number], default: '', required: false },
        // Type
        type: { type: String, default: 'text', required: false },
        // 넓이
        size: { type: Number, default: null, required: false },
        // 입력값 허용 길이
        maxlength: { type: Number, default: null, required: false },
        // 입력형식 유형
        inputRuleType: { type: String, default: '', required: false },
        // placeholder 제어
        placeholder: { type: String, default: '', required: false },
        // 접미사 텍스트 표시
        suffix: { type: String, default: '', required: false },
        // 접두사 텍스트 표시
        prefix: { type: String, default: '', required: false },
        // Enables autofocus
        autofocus: { type: Boolean, default: false, required: false },
        // 입력 지우기 기능 추가
        clearable: { type: Boolean, default: false, required: false },
        // mask 기능
        mask: { type: [String, Array], default: '', required: false },
        //텍스트박스 명
        labelName: { type: String, default: '', required: false },
        //필수입력여부
        eRequired: { type: Boolean, default: false, required: false },
        //readonly
        readonly: { type: Boolean, default: false, required: false },
        //disabled
        disabled: { type: Boolean, default: false, required: false },
        // auth
        objAuth: { type: Object, default: () => {}, required: false },
        // span class
        spanClass: {
            type: String,
            default: 'iteminput-type2',
            required: false,
        },
        // 콤마 포맷
        commaFormat: { type: Boolean, default: false, required: false },
        // Rate 포맷
        rateFormat: { type: Boolean, default: false, required: false },
        //text align right 여부
        textReverse: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            dValue: '',
        }
    },
    computed: {
        cSize() {
            let res = 'width:auto;'
            if (!_.isEmpty(this.size)) {
                res = 'width:' + this.size + '%;'
            }
            return res
        },
    },
    // props 동적 제어
    watch: {
        value: function () {
            this.dValue = this.value
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.dValue = this.value
        },
        inputFocus() {
            this.$refs.tcComNoLabelInput.inputFocus()
        },
        emitInput(value) {
            this.$emit('input', value)
        },
        emitClick(ev) {
            this.$emit('click', ev)
        },
        emitChange(value) {
            this.emitInput(value)
            this.$emit('change', value)
        },
        emitBlur(ev) {
            this.$emit('blur', ev)
        },
        emitFocus(ev) {
            this.$emit('focus', ev)
        },
        emitKeyDown(ev) {
            this.$emit('key-down', ev)
        },
        emitEnterKey(ev) {
            this.$emit('enterKey', ev)
        },
        emitEnterKeyUp(ev) {
            this.$emit('enterKeyUp', ev)
        },
        emitMouseDown(ev) {
            this.$emit('mouse-down', ev)
        },
        emitClearClick(ev) {
            this.$emit('clear-click', ev)
        },
    },
}
</script>
