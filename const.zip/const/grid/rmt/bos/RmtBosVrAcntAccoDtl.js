import { ValueType } from 'realgrid'

export const GRID_DEL_HEADER = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'state', // 상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstDt', // 입금일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstTm', // 입금시간
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'acntNo', // 계좌번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstAmt', // 입금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dpsterNm', // 입금자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bankCd', // 은행코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bankNm', // 은행명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealNo', //거래번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'partNm', // pt명1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCl1Nm', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstCl', //계좌구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 수정일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seqNo', // 순번
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'remark', //비고
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '60',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'state',
            fieldName: 'state',
            editable: false,
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '상태',
            dataType: ValueType.TEXT,
        },
        {
            name: 'dpstDt',
            fieldName: 'dpstDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 입금일자',
                showTooltip: false,
            },
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            width: '100',
        },
        {
            name: 'dpstTm',
            fieldName: 'dpstTm',
            editable: true,
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '* 입금시간',
            textFormat: '([0-9]{2})([0-9]{2})([0-9]{2})$;$1:$2:$3',
        },
        {
            name: 'acntNo',
            fieldName: 'acntNo',
            editable: true,
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '* 계좌번호',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstAmt',
            editable: true,
            header: '* 입금액',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'dpsterNm',
            fieldName: 'dpsterNm',
            editable: true,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '* 입금자명',
        },
        {
            name: 'bankCd',
            fieldName: 'bankCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'bankNm',
            fieldName: 'bankNm',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '은행명',
        },
        {
            name: 'dealNo',
            fieldName: 'dealNo',
            editable: true,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '* 거래번호',
        },

        {
            name: 'partNm',
            fieldName: 'partNm',
            editable: false,
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: 'PT',
            dataType: ValueType.TEXT,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            editable: false,
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처코드',
            dataType: ValueType.TEXT,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            editable: false,
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처명',
            dataType: ValueType.TEXT,
        },
        {
            name: 'dealcoCl1Nm',
            fieldName: 'dealcoCl1Nm',
            editable: false,
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처구분',
            dataType: ValueType.TEXT,
        },
        {
            name: 'dpstCl',
            fieldName: 'dpstCl',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '계좌구분',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수정일자',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            width: '100',
        },
        {
            name: 'seqNo',
            fieldName: 'seqNo',
            visible: false,
            type: 'data',
        },
        {
            name: 'remark',
            fieldName: 'remark',
            editable: true,
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '* 비고',
        },
    ],
    layout: [
        'rowNum',
        'state',
        'dpstDt',
        'dpstTm',
        'acntNo',
        'dpstAmt',
        'dpsterNm',
        'bankNm',
        'dealNo',
        'partNm',
        'dealcoCd',
        'dealcoNm',
        'dealcoCl1Nm',
        'dpstCl',
        'modDtm',
        'remark',
    ],
}
