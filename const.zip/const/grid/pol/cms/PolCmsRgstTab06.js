import { ValueType } from 'realgrid'

export const GRID_INFO_1 = {
    fields: [
        {
            fieldName: 'suplFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'basAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vasCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'suplSvcClNm',
            fieldName: 'suplSvcClNm',
            type: 'data',
            header: {
                text: '구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            type: 'data',
            header: {
                text: '코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            header: {
                text: '부가상품',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        // {
        //     name: 'basAmt',
        //     fieldName: 'basAmt',
        //     type: 'number',
        //     header: {
        //         text: '기본료',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     editable: false,
        //     numberFormat: '#,##0',
        // },
    ],
}

export const GRID_INFO_2 = {
    fields: [
        {
            fieldName: 'suplFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'basAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vasCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'suplSvcClNm',
            fieldName: 'suplSvcClNm',
            type: 'data',
            header: {
                text: '구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            type: 'data',
            header: {
                text: '코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            header: {
                text: '부가상품',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        // {
        //     name: 'basAmt',
        //     fieldName: 'basAmt',
        //     type: 'number',
        //     header: {
        //         text: '기본료',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     editable: false,
        //     numberFormat: '#,##0',
        // },
    ],
}

export const GRID_INFO_3 = {
    fields: [
        {
            fieldName: 'suplFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'basAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vasCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'suplSvcClNm',
            fieldName: 'suplSvcClNm',
            type: 'data',
            header: {
                text: '구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            type: 'data',
            header: {
                text: '코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            header: {
                text: '부가상품',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        // {
        //     name: 'basAmt',
        //     fieldName: 'basAmt',
        //     type: 'number',
        //     header: {
        //         text: '기본료',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     editable: false,
        //     numberFormat: '#,##0',
        // },
    ],
}

export const GRID_INFO_4 = {
    fields: [
        {
            fieldName: 'suplFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'basAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vasCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'suplSvcClNm',
            fieldName: 'suplSvcClNm',
            type: 'data',
            header: {
                text: '구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            type: 'data',
            header: {
                text: '코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            header: {
                text: '부가상품',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        // {
        //     name: 'basAmt',
        //     fieldName: 'basAmt',
        //     type: 'number',
        //     header: {
        //         text: '기본료',
        //         showTooltip: false,
        //     },
        //     styleName: 'center-column',
        //     editable: false,
        //     numberFormat: '#,##0',
        // },
    ],
}
