<!-----------------------------------------------
 * 업무그룹명: 분실,도난단말기 관리 현황
 * 서브업무명: 분실,도난단말기 관리 
 * 설명: 분실,도난단말기 관리 현황 조회 업데이트한다.
 * 작성자: P179234
 * 작성일: 2022.06.7
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>분실,도난단말기 관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onManage(1)"
                    >등록취소</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onManage(2)"
                    >일괄해제</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onManage(3)"
                    >상태해제</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onManage(4)"
                    >상태변경</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onManage(8)"
                    >유심일괄등록</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onManage(5)"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onManage(6)"
                    >조회</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onManage(7)"
                    >신규</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div2">
                    <div class="arrayType">
                        <div class="col50">
                            <TCComDatePicker
                                :calType="calType5"
                                :eRequired="true"
                                labelName="등록일자"
                                v-model="rgstDt"
                                v-if="showBondTrmsDt === false"
                            />
                            <TCComDatePicker
                                :calType="calType5"
                                :eRequired="true"
                                labelName="상태변경일자"
                                v-model="bondTrmsDt"
                                v-if="showBondTrmsDt === true"
                            />
                        </div>
                        <div class="col45">
                            <TCComCheckBox
                                :itemList="itemList2"
                                labelName=""
                                col="12"
                                @change="onChange1"
                            />
                        </div>
                    </div>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        placeholder="입력해주세요"
                        :codeVal.sync="reqParam.orgCd"
                        :disabledAfter="true"
                        :eRequired="true"
                        :objAuth="objAuth"
                        v-model="reqParam.orgNm"
                        :disabled="orgDisabled"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <!-- codeId="ZBAS_C_00500" -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="단말기구분"
                        :itemList="itemList1"
                        ref="prchTypComboBox"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                        blankItemValue=""
                        v-model="reqParam.prodClCd"
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="Risk 유형"
                        codeId="ZDIS_C_00090"
                        ref="prchTypComboBox"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        v-model="reqParam.riskLclCd"
                        :filterFunc="filterFuncRiskLclCd"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        :appendIconShow="false"
                        :appendIconClass="''"
                        labelName="일련번호"
                        v-model="reqParam.serNum"
                        :objAuth="objAuth"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        :appendIconShow="false"
                        :appendIconClass="''"
                        labelName="모델명"
                        v-model="reqParam.prodNm"
                        :objAuth="objAuth"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.dealcoNm"
                        :codeVal.sync="reqParam.dealcoCd"
                        labelName="보유처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
            </div>
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{
                            ' btn_ty_exp_active ': active,
                        }"
                        @click="active = !active"
                    >
                    </v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="active">
                    <div class="searchform">
                        <div class="formitem div4">
                            <TCComComboBox
                                labelName="거래처구분"
                                codeId="ZBAS_C_00240"
                                ref="prchTypComboBox"
                                :objAuth="objAuth"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                                v-model="reqParam.dealcoClCd"
                                :filterFunc="filterFuncDealcoClCd"
                            />
                        </div>
                        <div class="formitem div4">
                            <!--  :size="70" -->
                            <TCComComboBox
                                :itemList="this.chrgrUserIdData"
                                labelName="영업담당"
                                v-model="reqParam.chrgrUserId"
                                :objAuth="this.objAuth"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                            ></TCComComboBox>
                        </div>
                        <div class="formitem div4">
                            <TCComComboBox
                                labelName="Risk 상태"
                                codeId="ZDIS_C_00172"
                                ref="prchTypComboBox"
                                :objAuth="objAuth"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                                v-model="reqParam.riskStCd"
                                :filterFunc="filterFuncRiskStCd"
                            />
                        </div>
                        <div class="formitem div4">
                            <TCComComboBox
                                labelName="삭제여부"
                                :itemList="itemList3"
                                ref="prchTypComboBox"
                                :objAuth="objAuth"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                                v-model="reqParam.riskDelYn"
                            />
                        </div>
                        <!-- <div class="formitem div4"></div> -->
                    </div>
                </div>
            </v-expand-transition>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="분실,도난단말기 목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="false"
                :isPageCnt="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="gridSet.fields"
                :columns="gridSet.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisBeqLossRobberyProd"
                :gridObj="gridObj"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            />
        </div>
        <!-- 분실,도난단말기 일괄 해제 -->
        <DisBeqLossRobberyProdMgmtRlse
            ref="popup"
            v-if="showChangeLossRobberyProd === true"
            :dialogShow.sync="showChangeLossRobberyProd"
            :lossRobberyProd.sync="reqParam"
            @confirm="onReturnRlse"
        />
        <!-- 분실,도난단말기 해제(등록취소) -->
        <DisBeqLossRobberyProdMgmtIniting
            ref="popup"
            v-if="showDelLossRobberyProd === true"
            :dialogShow.sync="showDelLossRobberyProd"
            :lossRobberyProd.sync="lossRobberyProd"
            @confirm="onReturnIniting"
        />
        <!--  분실,도난단말기 변경 -->
        <DisBeqLossRobberyProdMgmtChanging
            ref="popup"
            v-if="showCancelLossRobberyProd === true"
            :dialogShow.sync="showCancelLossRobberyProd"
            :lossRobberyProd.sync="lossRobberyProdChange"
            @confirm="onReturnChanging"
        />
        <!-- 분실,도난단말기 저장 -->
        <DisBeqLossRobberyProdMgmtRgst
            ref="popup"
            v-if="showCreateLossRobberyProd === true"
            :dialogShow.sync="showCreateLossRobberyProd"
            :lossRobberyProd.sync="lossRobberyInfo"
            @confirm="onReturnRgst"
        />
        <!-- 유심일괄등록 -->
        <DisBeqLossRobberyProdMgmtXlsUpld
            ref="popup"
            v-if="showLossRobberyProdMgmtXlsUpldPop === true"
            :dialogShow.sync="showLossRobberyProdMgmtXlsUpldPop"
            @confirm="onReturnXlsUpld"
        />
    </div>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 콜백 서비스 아이디
 * 6 엑셀업로드
 * 7 유심엑셀업로드 
 * 8 사용자 정의 파라메터 기반 공통 팝업 호출
------------------------------------------------>
<script>
import { CommonGrid, CommonUtil, CommonMsg } from '@/utils'
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
// import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import DisBeqLossRobberyProdMgmtRlse from './DisBeqLossRobberyProdMgmtRlse'
import DisBeqLossRobberyProdMgmtIniting from './DisBeqLossRobberyProdMgmtIniting'
import DisBeqLossRobberyProdMgmtChanging from './DisBeqLossRobberyProdMgmtChanging'
import DisBeqLossRobberyProdMgmtRgst from './DisBeqLossRobberyProdMgmtRgst'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
// import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
// import BasBcoUserSaleChrgrsPopup from '@/components/common/BasBcoUserSaleChrgrsPopup'
import basBcoUserApi from '@/api/biz/bas/bco/basBcoUserPop'
import disBeqLossRobberyProdApi from '@/api/biz/dis/beq/disBeqLossRobberyProdMgmt.js'
import commonApi from '@/api/common/prototype'
import { GRID_HEADER } from '@/const/grid/dis/beq/disBeqLossRobberyProdMgmtHeader.js'
import { BadProd } from './js/disBeqBadProd.js'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

//====================내부거래처-권한조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-권한조직==================

import { SacCommon } from '@/views/biz/sac/js'
import attachedFileApi from '@/api/common/attachedFile'

import DisBeqLossRobberyProdMgmtXlsUpld from './DisBeqLossRobberyProdMgmtXlsUpld'

export default {
    name: 'DisBeqLossRobberyProdMgmt',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        // BasBcoOrgAgencysPopup,
        // BasBcoUserSaleChrgrsPopup,
        DisBeqLossRobberyProdMgmtRlse,
        DisBeqLossRobberyProdMgmtIniting,
        DisBeqLossRobberyProdMgmtChanging,
        DisBeqLossRobberyProdMgmtRgst,
        DisBeqLossRobberyProdMgmtXlsUpld,
        BasBcoDealcosPop,
    },

    data() {
        return {
            objAuth: {},
            indicatorOpt: { sort: 'ASC' },
            codeIDView: true,
            codeIDViewVal: '',
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '400px',
            },
            calType5: 'DP',
            showExpartReqRslt: false,
            showChangeLossRobberyProd: false,
            showDelLossRobberyProd: false,
            showCancelLossRobberyProd: false,
            showCreateLossRobberyProd: false,
            showBcoOrgAgencys1: false,
            showBcoAuthOrgTrees: false,
            showBcoSaleChrgr: false,
            gridSet: GRID_HEADER,
            badProd: BadProd,
            lossRobberyProd: {},
            //상태변경
            lossRobberyProdChange: {},
            //row 더블클릭 상세 조회
            lossRobberyInfo: {},
            rowCnt: 15,
            searchForms: {},
            bondTrmsDt: [],
            active: false,
            showBondTrmsDt: false,
            reqParam: {
                regStaDt: '',
                regEndDt: '',
                strdBondTrmsDt: '',
                endBondTrmsDt: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                prodClCd: '',
                opLclNm: '',
                serNum: '',
                prodNm: '',
                dealcoCd: '',
                dealcoNm: '',
                dealcoClCd: '',
                riskLclCd: '',
                chrgrUserId: '',
                mdlClCd: '',
                chrgrUserNm: '',
                riskStNm: '',
                riskStCd: '',
                stChgDtChk: 'N',
                riskDelYn: '',
            },
            itemList1: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: '일반형',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: '개방형',
                },
            ],
            itemList2: [
                {
                    commCdVal: '',
                    commCdValNm: '상태변경일자',
                },
            ],
            itemList3: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
            ],
            searchSaleChrgrParam: {},
            //====================조직별대리점팝업관련====================
            searchable: false,
            // 영업담당
            chrgrUserIdData: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
            ],
            showLossRobberyProdMgmtXlsUpldPop: false,

            //====================내부거래처-권한조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-권한조직==================
            orgDisabled: false,
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
        }
    },
    computed: {
        rgstDt: {
            get() {
                return [this.reqParam.regStaDt, this.reqParam.regEndDt]
            },
            set(val) {
                this.reqParam.regStaDt = val[0]
                this.reqParam.regEndDt = val[1]
                this.searchable = val[0] === '' || val[1] === '' ? false : true
                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchParam.basMth = CommonUtil.onlyNumber(val[1]).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val[1])
                return val
            },
        },
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setCheckableExpression(
            "((values['riskStCd'] = '01') or (values['riskStCd'] = '07')) and (values['riskDelYn'] = 'N')",
            true
        )

        // 그리드 셀 클릭 이벤트
        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            if ('data' === clickData.cellType) {
                const rowData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.lossRobberyInfo = rowData
                this.lossRobberyInfo.FV_NEW_INSERT_YN = 'N'
                this.showCreateLossRobberyProd = true
            }
        }

        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.initParam()
    },

    methods: {
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, 변경Row데이터),
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        /* 공통코드 */
        getCommCodeList(codeId, columnId) {
            commonApi.getCommonCodeList(codeId).then((res) => {
                let columnValues = []
                let columnLabels = []
                if (res.length) {
                    res.forEach((data) => {
                        columnValues.push(data.commCdVal)
                        columnLabels.push(data.commCdValNm)
                    })
                }
                // 그리드 컬럼 콤보박스 데이터 설정
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'values',
                    columnValues
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'labels',
                    columnLabels
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'lookupDisplay',
                    true
                )
            })
        },
        /* 초기화 */
        clear() {
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.bondTrmsDt = [SacCommon.getFirstday(), SacCommon.getToday()]
            this.initParam()
        },
        initParam() {
            this.reqParam = {
                regStaDt: SacCommon.getFirstday(),
                regEndDt: SacCommon.getToday(),
                strdBondTrmsDt: '',
                endBondTrmsDt: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                prodClCd: '',
                opLclNm: '',
                serNum: '',
                prodNm: '',
                dealcoCd: '',
                dealcoNm: '',
                dealcoClCd: '',
                chrgrUserId: '',
                mdlClCd: '',
                chrgrUserNm: '',
                riskLclCd: '',
                riskStNm: '',
                riskStCd: '',
                riskDelYn: '',
                stChgDtChk: 'N',
            }
            // this.rgstDt = [SacCommon.getFirstday(), SacCommon.getToday()]
            this.bondTrmsDt = [SacCommon.getFirstday(), SacCommon.getToday()]
            this.chrgrUserIdData = [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
            ]

            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLvl'] = this.orgInfo['orgLvl']
                // this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.reqParam['dealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['dealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true

                this.getChrgrUserList() //영업담당 조회
            }
            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
            this.gridData.totalPage = 0
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        gridAddPageBtn() {
            this.gridData = this.gridHeaderObj.setAddPage(this.gridData)
        },
        /* 버튼별 이벤트 */
        onManage(index) {
            if (index === 1) {
                /* 등록취소 */
                this.disBeqLossRobberyProdCanceling()
            } else if (index === 2) {
                /* 일괄해제 */
                this.disBeqLossRobberyProdsCanceling()
            } else if (index === 3) {
                /* 상태해제 */
                this.disBeqLossRobberyProdIniting()
            } else if (index === 4) {
                /* 상태변경 */
                this.disBeqLossRobberyProdChanging()
            } else if (index === 5) {
                /* 초기화 */
                this.clear()
            } else if (index === 6) {
                /* 조회 */
                this.search()
            } else if (index === 7) {
                /* 신규 */
                this.lossRobberyInfo = {
                    FV_NEW_INSERT_YN: 'Y',
                    orgCd: this.reqParam.orgCd,
                    orgNm: this.reqParam.orgNm,
                    orgLvl: this.reqParam.orgLvl,
                    hldDealcoNm: this.reqParam.dealcoNm,
                    hldDealcoCd: this.reqParam.dealcoCd,
                }
                this.showCreateLossRobberyProd = true
            } else if (index === 8) {
                /*  유심일괄등록 */
                this.showLossRobberyProdMgmtXlsUpldPop = true
            }
        },
        /* 사고기기관리 등록취소 */
        async disBeqLossRobberyProdCanceling() {
            const list = await Promise.all(this.getRows(this.gridObj))
            let checkedList = []

            for (var i = 0; i < list.length; i++) {
                if (list[i].riskStCd === '01' || list[i].riskStCd === '07') {
                    checkedList.push(list[i])
                } else {
                    this.showTcComAlert(
                        '확인중 및 상태해제인 기기만 등록취소를 할 수 있습니다.'
                    )
                    return
                }
            }

            if (checkedList.length != 0) {
                this.lossRobberyProd = checkedList
                this.showDelLossRobberyProd = true
            } else {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00134', '사고 단말기')
                )
            }
        },
        /* 사고기기관리 일괄해제 */
        disBeqLossRobberyProdsCanceling() {
            let startMonth = ''
            let endMonth = ''

            startMonth = this.reqParam.regStaDt.substring(5, 7)
            endMonth = this.reqParam.regEndDt.substring(5, 7)
            if (
                this.reqParam.regStaDt === '' ||
                this.reqParam.regEndDt === ''
            ) {
                this.showTcComAlert(
                    '등록일자의 시작일과 종료일을 지정해 주세요.'
                )
                return
            }
            if (startMonth !== endMonth) {
                this.showTcComAlert(
                    '등록일자의 시작일과 종료일을 동일한 월로 지정해 주세요.'
                )
                return
            }
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00121', '조직;진행')
                )
                return
            }
            this.showChangeLossRobberyProd = true
        },
        /* 사고기기관리 상태해제 */
        async disBeqLossRobberyProdIniting() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow > -1) {
                const data = this.gridObj.dataProvider.getJsonRow(
                    current.dataRow
                )
                if (!this.checkCanceling(data)) return

                this.showTcComConfirm('해제하시겠습니까?').then(
                    async (confirm) => {
                        if (confirm) {
                            let setList = []
                            setList.push(data)
                            const formData = { rowDatas: setList }
                            await disBeqLossRobberyProdApi
                                .disBeqLossRobberyProdIniting(formData)
                                .then(() => {
                                    this.getDisBeqLossRobberyProd(
                                        this.searchForms.pageNum
                                    )
                                })
                        }
                    }
                )
            } else {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00134', '사고 단말기')
                )
            }
        },
        /* 사고기기관리 상태해제 - 체크한 열 정보 가져오기 */
        getRows(grid) {
            let jsonData = []
            grid.gridView.commit()
            const checkRows = grid.gridView.getCheckedRows(true)
            checkRows.forEach((row) => {
                const data = grid.dataProvider.getJsonRow(row)
                jsonData.push(data)
            })
            return [...jsonData]
        },
        checkCanceling(data) {
            /* 상태해제시 체크*/
            if (data.clsYn === '1' || data.riskStCd !== '02') {
                this.showTcComAlert(
                    '상품코드' +
                        data.prodCd +
                        '는 처리중(미회수)인 기기가 아니어서 사고기기 상태해제를 할 수 없습니다.'
                )
                return false
            } else {
                return true
            }
        },
        /* 사고기기관리 상태변경 */
        async disBeqLossRobberyProdChanging() {
            this.gridObj.gridView.commit()

            let list = []
            list = await Promise.all(this.getRows(this.gridObj))
            if (list.length === 0) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00134', '사고 단말기')
                )
                return
            } else {
                const paramData = {
                    dataList: list,
                    orgCd: this.searchForms.orgCd,
                    //testdata*****
                    // orgCd: 'AA1211',
                    //testdata*****
                    orgNm: this.searchForms.orgNm,
                }
                this.lossRobberyProdChange = paramData
                this.showCancelLossRobberyProd = true
            }
        },
        /* 사고기기관리 조회 - 최초 */
        search() {
            let startDate = ''
            let endDate = ''
            this.searchForms = {}
            this.searchForms = { ...this.reqParam }

            if (this.reqParam.orgCd === '') {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00121', '조직;조회')
                )
                return
            }

            if (this.showBondTrmsDt === true) {
                startDate = SacCommon.onlyNumber(this.bondTrmsDt[0])
                endDate = SacCommon.onlyNumber(this.bondTrmsDt[1])
                // this.searchForms.strdBondTrmsDt = CommonUtil.onlyNumber(
                //     this.bondTrmsDt[0]
                // )
                // this.searchForms.endBondTrmsDt = CommonUtil.onlyNumber(
                //     this.bondTrmsDt[1]
                // )
                this.searchForms.regStaDt = CommonUtil.onlyNumber(
                    this.bondTrmsDt[0]
                )
                this.searchForms.regEndDt = CommonUtil.onlyNumber(
                    this.bondTrmsDt[1]
                )
            } else {
                startDate = SacCommon.onlyNumber(this.reqParam.regStaDt)
                endDate = SacCommon.onlyNumber(this.reqParam.regEndDt)
                this.searchForms.regStaDt = CommonUtil.onlyNumber(
                    this.reqParam.regStaDt
                )
                this.searchForms.regEndDt = CommonUtil.onlyNumber(
                    this.reqParam.regEndDt
                )
            }

            if (_.isEmpty(startDate)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '시작 등록일자')
                )
                return
            }
            if (_.isEmpty(endDate)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '종료 등록일자')
                )
                return
            }
            if (startDate > endDate) {
                this.showTcComAlert(
                    CommonMsg.getMessage(
                        'MSG_00096',
                        '시작 등록일자;종료 등록일자'
                    )
                )
                return
            }

            const fYear = startDate.substring(0, 4)
            const fMonth = startDate.substring(4, 6)
            const tYear = endDate.substring(0, 4)
            const tMonth = endDate.substring(4, 6)

            if ((tYear - fYear) * 12 + (tMonth - fMonth + 1) > 12) {
                this.showTcComAlert('12개월까지만 조회 가능합니다.')
                return
            }

            this.gridData.totalPage = 0
            this.searchForms.pageSize = this.rowCnt
            this.searchForms.pageNum = 1
            this.getDisBeqLossRobberyProd(this.searchForms.pageNum)
        },
        /* 사고기기관리 조회 - 페이징호출 */
        async getDisBeqLossRobberyProd(page) {
            this.searchForms.pageNum = page

            await disBeqLossRobberyProdApi
                .getDisBeqLossRobberyProd(this.searchForms)
                .then((res) => {
                    if (res) {
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator(
                            res.pagingDto,
                            this.indicatorOpt
                        )
                        this.gridData = this.gridSetData()
                        this.gridData.totalPage = res.pagingDto.totalPageCnt
                        this.gridHeaderObj.setPageCount(res.pagingDto)
                    }
                })
        },
        onChange1(value) {
            if (value.length === 1) {
                this.showBondTrmsDt = true
                this.reqParam.regStaDt = SacCommon.getFirstday()
                this.reqParam.regEndDt = SacCommon.getToday()

                //this.rgstDt = [SacCommon.getFirstday(), SacCommon.getToday()]
                this.reqParam.stChgDtChk = 'Y'
            } else {
                this.showBondTrmsDt = false
                this.bondTrmsDt = [
                    SacCommon.getFirstday(),
                    SacCommon.getToday(),
                ]
                this.reqParam.stChgDtChk = 'N'
            }
        },
        filterFuncDealcoClCd(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] == 'A2' ||
                    item['commCdVal'] == 'A3' ||
                    item['commCdVal'] == 'B1' ||
                    item['commCdVal'] == 'B2' ||
                    item['commCdVal'] == 'Z1'
            )
        },
        filterFuncRiskLclCd(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] == '03' ||
                    item['commCdVal'] == '04' ||
                    item['commCdVal'] == '05' ||
                    item['commCdVal'] == '09'
            )
        },
        filterFuncRiskStCd(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] == '01' ||
                    item['commCdVal'] == '02' ||
                    item['commCdVal'] == '06' ||
                    item['commCdVal'] == '03'
            )
        },
        //영업담당조회
        getChrgrUserList: function () {
            this.chrgrUserIdData = []
            this.reqParam.chrgrUserId = ''

            const chrgrUserParam = {
                orgCd: this.reqParam.orgCd,
                orgLevel: this.reqParam.orgLvl,
            }
            disBeqLossRobberyProdApi
                .getChrgrUser(chrgrUserParam)
                .then((res) => {
                    if (res.length > 0) {
                        res.forEach((data) => {
                            this.chrgrUserIdData.push({
                                commCdVal: _.get(data, 'chrgrUserId'),
                                commCdValNm: _.get(data, 'chrgrUserNm'),
                            })
                        })
                    } else {
                        this.chrgrUserIdData = [
                            {
                                commCdVal: '',
                                commCdValNm: '전체',
                            },
                        ]
                    }
                })
        },
        // 팝업종료
        onReturnRlse(retVal) {
            if (retVal) {
                // 화면재조회
                this.search()
            }
        },
        // 등록취소
        onReturnIniting(retVal) {
            if (retVal) {
                // 화면재조회
                this.search()
            }
        },
        // 상태변경
        onReturnChanging(retVal) {
            if (retVal) {
                // 화면재조회
                this.search()
            }
        },
        // 신규저장
        onReturnRgst(retVal) {
            if (retVal) {
                // 화면재조회
                this.search()
            }
        },
        // 엑셀업로드 종료 후
        onReturnXlsUpld(retVal) {
            if (retVal) {
                // 화면 재조회
                this.search()
            }
        },
        /* 내부조직팝업 */
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.reqParam.orgCd
            this.searchParam.orgNm = this.reqParam.orgNm
            this.searchParam.orgLvl = this.reqParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                        this.searchForm.orgCd = this.reqParam.orgCd
                        this.searchForm.orgNm = this.reqParam.orgNm
                        this.searchForm.orgLvl = this.reqParam.orgLvl
                        this.getChrgrUserList()
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        /* 내부조직팝업 - Icon 이벤트 처리 */
        onAuthOrgTreeIconClick() {
            this.resultAuthOrgTreeRows = []
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        /* 내부조직팝업 - TextField 엔터키 이벤트 처리 */
        onAuthOrgTreeEnterKey() {
            this.resultAuthOrgTreeRows = []
            // if (_.isEmpty(this.reqParam.orgNm)) {
            //     this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
            //     return
            // }
            this.getAuthOrgTreeList()
        },
        /* 내부조직팝업 - TextField Input 이벤트 이벤트 처리 */
        onAuthOrgTreeInput() {
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
            this.reqParam.dealcoNm = ''
            this.reqParam.dealcoCd = ''
            this.reqParam.chrgrUserId = ''
            this.gridObj.gridInit()
            this.chrgrUserIdData = [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
            ]
        },
        /* 내부조직팝업 - 팝업 리턴 이벤트 이벤트 처리 */
        onAuthOrgTreeReturnData(returnData) {
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.orgLvl = _.get(returnData, 'orgLvl')
            this.searchForm.orgCd = this.reqParam.orgCd
            this.searchForm.orgNm = this.reqParam.orgNm
            this.searchForm.orgLvl = this.reqParam.orgLvl
            this.getChrgrUserList()
        },
        /* 영업담당자 팝업 */
        // 사용자 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 사용자 팝업 오픈
        getSaleChrgrPopList() {
            basBcoUserApi
                .getSaleChrgrPopList(this.searchSaleChrgrParam)
                .then((res) => {
                    // 검색된 사용자 정보가 1건이면 TextField에 바로 설정
                    // 검색된 사용자 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                    if (res.length === 1) {
                        this.searchSaleChrgrParam.userId = _.get(
                            res[0],
                            'userId'
                        )
                        this.searchSaleChrgrParam.userNm = _.get(
                            res[0],
                            'userNm'
                        )
                        this.reqParam.chrgrUserId = _.get(res[0], 'userId')
                        this.reqParam.chrgrUserNm = _.get(res[0], 'userNm')
                    } else {
                        this.resultSaleChrgrRows = res
                        this.showBcoSaleChrgr = true
                    }
                })
        },
        // 사용자 TextField 돋보기 Icon 이벤트 처리
        onSaleChrgrIconClick() {
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultSaleChrgrRows = []
            // 검색조건 사용자명이 빈값이 아니면 사용자 정보 조회
            // 그 이외는 사용자 팝업 오픈
            if (!_.isEmpty(this.reqParam.chrgrUserNm)) {
                this.getSaleChrgrPopList()
            } else {
                this.showBcoSaleChrgr = true
            }
        },
        // 사용자 TextField 엔터키 이벤트 처리
        onSaleChrgrEnterKey() {
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultSaleChrgrRows = []
            // 검색조건 사용자명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.chrgrUserNm)) {
                this.showTcComAlert('사용자명을 입력해주세요.')
                return
            }
            // 사용자 정보 조회
            this.getSaleChrgrPopList()
        },
        // 사용자 TextField Input 이벤트 처리
        onSaleChrgrInput() {
            // 입력되는 값이 있으면 사용자 코드 초기화
            this.searchSaleChrgrParam.userId = ''
            this.reqParam.chrgrUserId = ''
        },
        // 사용자 팝업 리턴 이벤트 처리
        onSaleChrgrReturnData(retrunData) {
            this.searchSaleChrgrParam.userId = _.get(retrunData, 'userId')
            this.searchSaleChrgrParam.userNm = _.get(retrunData, 'userNm')
            this.reqParam.chrgrUserId = _.get(retrunData, 'userId')
            this.reqParam.chrgrUserNm = _.get(retrunData, 'userNm')
        },

        //===================== 내부거래처-권한조직팝업관련 methods ================================
        // 내부거래처-권한조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-권한조직 팝업 오픈
        getDealcosList() {
            this.searchForm.dealcoCd = this.reqParam.dealcoCd
            this.searchForm.dealcoNm = this.reqParam.dealcoNm
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-권한조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이 아니면 내부거래처-권한조직 정보 조회
            // 그 이외는 내부거래처-권한조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.dealcoNm)) {
                this.searchForm.basDay = CommonUtil.replaceDash(
                    this.reqParam.regEndDt
                )
                this.getDealcosList()
                // this.showBasBcoDealcos = true
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-권한조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-권한조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-권한조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            // 내부거래처-권한조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-권한조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-권한조직 코드 초기화
            this.reqParam.dealcoCd = ''
        },
        // 내부거래처-권한조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            this.reqParam.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-권한조직팝업관련 methods ================================
        /* 엑셀다운로드 */
        onClickDownload() {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/beq/disBeqLossRobberyProdExcelDown',
                this.searchForms
            )
        },
        /* 팝업 창닫기 */
        onClose() {
            this.activeOpen = false
        },
        /* 현재일자 확인(yyyy-mm-dd)*/
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
    },
}
</script>
