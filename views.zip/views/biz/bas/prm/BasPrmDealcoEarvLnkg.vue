<template>
    <div class="content">
        <h1>전자결재 결재승인확인</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clear"
                    :objAuth="this.objAuth"
                    >초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="search(reqParam)"
                    :objAuth="this.objAuth"
                    >조회
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div5">
                    <TCComDatePicker
                        labelName="조회기간"
                        v-model="opDt"
                        :calType="calType5"
                        :eRequired="true"
                    />
                </div>

                <div class="formitem div3">
                    <TCComAlert
                        v-model="showAlertBool"
                        :headerText="headerText"
                        :bodyText="alertBodyText"
                    ></TCComAlert>
                    <TCComInputSearchText
                        v-model="searchParam.orgNm"
                        :codeVal.sync="searchParam.orgCd"
                        :eRequired="true"
                        labelName="소속조직"
                        placeholder="선택해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div5_1">
                    <!-- TODO 확정여부 확인 필요 -->
                    <TCComComboBox
                        labelName="확정여부"
                        :itemList="searchCode[0]"
                        :objAuth="this.objAuth"
                        v-model="reqParam.zconfirm"
                    />
                </div>
                <div class="formitem div5_1">
                    <TCComComboBox
                        :itemList="searchCode[1]"
                        labelName="결재구분"
                        v-model="reqParam.earvTypCd"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div5_1">
                    <TCComComboBox
                        codeId="ERAV_ST_CD"
                        labelName="전송상태"
                        v-model="reqParam.eravStCd"
                        :objAuth="this.objAuth"
                    ></TCComComboBox>
                </div>
                <div class="formitem div5_1">
                    <TCComInput
                        labelName="거래처명"
                        :objAuth="this.objAuth"
                        v-model="reqParam.dealcoNm"
                    />
                </div>
                <div class="formitem div5_1">
                    <TCComInput
                        labelName="거래처코드"
                        :objAuth="this.objAuth"
                        v-model="reqParam.dealcoCd"
                    />
                </div>
                <div class="formitem div5_1">
                    <TCComInput
                        labelName="요청자명"
                        :objAuth="this.objAuth"
                        v-model="reqParam.drftrNm"
                    />
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="전자결재 결재승인확인"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="this.showNext === true ? true : false"
                :isPageCnt="true"
                @addPageBtn="this.gridAddPageBtn"
                @excelDownBtn="this.excelDown"
                @appendIconClick="open"
            />

            <TCRealGrid
                id="gridTable"
                ref="gridTable"
                :fields="gridTable.fields"
                :columns="gridTable.columns"
            />
        </div>
        <DealcoEarvLnkgDtl
            v-if="showDealcoEarvLnkgDtl === true"
            ref="popup"
            :dialogShow.sync="showDealcoEarvLnkgDtl"
            :dtlData.sync="dtlParam"
        />
    </div>
</template>

<script>
import { CommonGrid } from '@/utils'

import API from '@/api/biz/bas/prm/basPrmDealcoEarvLnkgSrch'
import { GRID_HEADER } from '@/const/grid/bas/prm/basPrmDealcoEarvLnkgGrid'
import DealcoEarvLnkgDtl from './BasPrmDealcoEarvLnkgDtl'

//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
import _ from 'lodash'
//====================//내부조직팝업(권한)팝업====================

export default {
    name: 'DealcoEarvLnkg',
    components: {
        BasBcoAuthOrgTreesPopup,
        DealcoEarvLnkgDtl,
    },

    data() {
        return {
            objAuth: {},
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridDataRaw: {},
            showNext: false,
            showExpartReqRslt: false,
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            //====================//내부조직팝업(권한)팝업관련==================
            showDealcoEarvLnkgDtl: false,
            gridTable: GRID_HEADER,
            calType5: 'DP',
            reqParam: {
                stReqDt: '', // from일자
                endReqDt: '', // to일자
                zconfirm: '', // 확정여부
                earvTypCd: '', // 결재구분
                eravStCd: '', // 전송상태
                dealcoNm: '', // 거래처명
                dealcoCd: '', // 거래처코드
                drftrNm: '', // 요청자명
            },
            dtlParam: {
                erpCase: '', // from일자
                zconfirm: '', // to일자
                earvTypCd: '', // 확정여부
                eravStCd: '', // 결재구분
                bu: '', // 전송상태
                dam: '', // 전송상태
            },
            reqCodeParam: {
                codeId: '', // codeId
            },
            opDt: [],
            searchCode: [
                [
                    {
                        commCdVal: '',
                        commCdValNm: '전체',
                    },
                    {
                        commCdVal: 'a', // TODO 미수행
                        commCdValNm: '미수행',
                    },
                    {
                        commCdVal: 'b', // TODO 전송에러
                        commCdValNm: '전송에러',
                    },
                    {
                        commCdVal: 'c', // TODO 전송성공
                        commCdValNm: '전송성공',
                    },
                    {
                        commCdVal: 'd', // TODO 확정에러
                        commCdValNm: '확정에러',
                    },
                    {
                        commCdVal: 'e', // TODO 확정성공(지급보류)
                        commCdValNm: '확정성공(지급보류)',
                    },
                    {
                        commCdVal: 'f', // TODO 확정성공(지급보류해제)
                        commCdValNm: '확정성공(지급보류해제)',
                    },
                    {
                        commCdVal: 'g', // TODO 확정성공(성공)
                        commCdValNm: '확정성공(성공)',
                    },
                ],
                [
                    {
                        commCdVal: '',
                        commCdValNm: '전체',
                    },
                    {
                        commCdVal: 'a',
                        commCdValNm: '신규',
                    },
                    {
                        commCdVal: 'b',
                        commCdValNm: '변경',
                    },
                    {
                        commCdVal: 'c',
                        commCdValNm: '담보갱신',
                    },
                    {
                        commCdVal: 'd',
                        commCdValNm: '변경&담보갱신',
                    },
                    {
                        commCdVal: 'e',
                        commCdValNm: '해지',
                    },
                    {
                        commCdVal: 'f',
                        commCdValNm: '신규_재품의',
                    },
                ],
            ],
        }
    },
    mounted() {
        this.initParam()
        this.setGrid()
        this.opDt = ['2022-04-01', '2022-04-20']
        this.gridObj.setGridState(true)
    },

    methods: {
        /* 초기화 */
        clear() {
            this.initParam()
            this.opDt = ['', '']
            this.gridObj.setRows({})
        },
        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                stReqDt: '', // from일자
                endReqDt: '', // to일자
                earvTypCd: '', // 회계처리대상
                eravStCd: '', // 전송상태
                dealcoNm: '', // 거래처명
                dealcoCd: '', // 거래처코드
                drftrNm: '', // 요청자
                pageSize: '30',
                pageNum: 0,
            }
            this.reqCodeParam = {
                codeId: '',
            }
            this.opDt = [this.reqParam.stReqDt, this.reqParam.endReqDt]
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.gridTable
            this.gridHeaderObj = this.$refs.gridHeader
            this.gridObj.setGridState(true)
            this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
            this.gridObj.gridView.onCellClicked = (grid, clickData) => {
                if (typeof clickData.itemIndex !== 'undefined') {
                    this.dtlParam.erpCase = grid.getValue(
                        clickData.itemIndex,
                        'erpCase'
                    )
                    this.dtlParam.zconfirm = grid.getValue(
                        clickData.itemIndex,
                        'zconfirm'
                    )
                    this.dtlParam.earvTypCd = grid.getValue(
                        clickData.itemIndex,
                        'earvTypCd'
                    )
                    this.dtlParam.eravStCd = grid.getValue(
                        clickData.itemIndex,
                        'eravStCd'
                    )
                    this.dtlParam.bu = grid.getValue(clickData.itemIndex, 'bu')
                    this.dtlParam.dam = grid.getValue(
                        clickData.itemIndex,
                        'dam'
                    )
                    console.log(clickData)
                    this.open('2')
                }
            }
        },
        gridSetData() {
            return new CommonGrid(0, 10, '', '')
        },
        /* 조회 */
        search() {
            let paramObj = { ...this.reqParam }
            if (_.isEmpty(this.opDt[0]) || _.isEmpty(this.opDt[1])) {
                alert('조회기간을 선택 하세요')
                return
            }

            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }

            paramObj.stReqDt = this.opDt[0].replace(/-/gi, '')
            paramObj.endReqDt = this.opDt[1].replace(/-/gi, '')
            paramObj.pageNum = '1'
            paramObj.pageSize = '30'
            API.getDealcoEarvLnkgList(paramObj).then((res) => {
                if (_.isEmpty(res.gridList)) {
                    alert('조회된 데이터가 없습니다')
                    return
                }
                this.gridObj.setRows(res.gridList)
                this.gridData = this.gridSetData() //초기화
                this.isShowNext(res.pagingDto)
                this.gridData.totalPage = res.pagingDto.totalPageCnt
                this.gridHeaderObj.setPageCount(res.pagingDto)
            })
        },
        /* 다음페이지 노출여부 */
        isShowNext(pageInfo) {
            this.showNext =
                pageInfo.totalDataCnt === pageInfo.pageSize ? true : false
        },
        /* 다음페이지 */
        gridAddPageBtn() {
            let paramObj = { ...this.reqParam }
            paramObj.pageNum += 1
            API.getDealcoEarvLnkgList(paramObj).then((res) => {
                this.isShowNext(res.pagingDto)
                this.gridData.gridRows = this.gridHeaderObj.setAddPage(
                    this.gridData.gridRows,
                    res.gridList
                )
            })
        },
        /* 엑셀다운로드 */
        excelDown() {
            this.gridHeaderObj.exportGrid('dealcoEarvLnkg.xls')
        },
        open() {
            this.showDealcoEarvLnkgDtl = true
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchParam.orgNm = _.get(res[0], 'orgNm')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchParam.orgNm = _.get(retrunData, 'orgNm')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
    },
}
</script>

<style></style>
