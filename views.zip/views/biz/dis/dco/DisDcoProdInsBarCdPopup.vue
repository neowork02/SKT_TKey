<!-----------------------------------------------
 * 업무그룹명: 2차원바코드입력팝업
 * 서브업무명: 2차원바코드입력팝업
 * 설명: 2차원바코드입력한다.[DISDCO00101]
 * 작성자: P179234
 * 작성일: 2022.04.05
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop long overflow-y-auto">
                <p class="popTitle">2차원바코드입력</p>
                <div class="layerCont">
                    <ul class="btn_area top pop">
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="errCheck"
                                :objAuth="objAuth"
                                >바코드검증</TCComButton
                            >
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="errClear"
                                :objAuth="objAuth"
                                >오류일괄제거</TCComButton
                            >
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="clearBtn"
                                >초기화</TCComButton
                            >
                        </li>
                    </ul>
                    <div class="contBoth">
                        <div class="div3_7 cont1 left">
                            <div class="stitHead">
                                <h4 class="subTit">바코드 정보</h4>
                            </div>
                            <!-- // SubTit -->
                            <!-- Search_div -->
                            <div class="searchLayer_wrap">
                                <!-- Search_line 1 -->
                                <div class="searchform">
                                    <span class="iteminput">
                                        <div class="textareaLayer_wrap mt0">
                                            <TCComTextArea
                                                v-model="serNum"
                                                :rows="13"
                                            />
                                        </div>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="div3_7 cont2 right">
                            <div class="gridWrap">
                                <TCRealGridHeader
                                    id="gridHeaderBarCd"
                                    ref="gridHeaderBarCd"
                                    gridTitle="입고상품목록"
                                    :gridObj="gridObj"
                                    :isDelRow="true"
                                    :isPageRows="true"
                                    :isExceldown="false"
                                    :isNextPage="false"
                                    :isPageCnt="true"
                                    @chkDelRowBtn="delRow"
                                />
                                <TCRealGrid
                                    id="gridFieldBarCd"
                                    ref="gridFieldBarCd"
                                    :fields="gridSet.fields"
                                    :columns="gridSet.columns"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>

                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import CommonMixin from '@/mixins'
import { GRID_HEADER } from '@/const/grid/dis/dco/disDcoProdInsBarCdPopupHeader.js'
import disDcoProdInsBarCdApi from '@/api/biz/dis/dco/disDcoProdInsBarCd.js'
import _ from 'lodash'

export default {
    name: 'DisDcoProdInsBarCdPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        parentParam: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            gridData: this.gridSetData(),
            objAuth: {},
            gridSet: GRID_HEADER,
            gridObj: {},
            gridHeaderObj: {},
            serNum: '',
            errChk: false,
            reqBarCdParam: {
                serNumList: [],
                inOutClCd: '',
                outPlcId: '',
                prchTyp: '',
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {},
    created() {},
    mounted() {
        this.gridObj = this.$refs.gridFieldBarCd
        this.gridHeaderObj = this.$refs.gridHeaderBarCd
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        console.log('parentParam :::' + JSON.stringify(this.parentParam))
    },
    methods: {
        /* 그리드 설정 */
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(-1, 10, '', '')
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            this.serNum = ''
            this.errChk = false
            this.gridObj.dataProvider.clearRows()
        },
        /* 행삭제 */
        delRow() {
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        //바코드검증
        errCheck: function () {
            const serNumArray = _.split(this.serNum, '\n')
            let serNumList = []
            serNumArray.forEach((data) => {
                // 상품정보 append
                if (!_.isEmpty(data)) {
                    serNumList.push(data)
                }
            })

            if (serNumList.length < 1) {
                this.showTcComAlert('바코드 정보가 없습니다.')
                return false
            }

            this.reqBarCdParam.inOutClCd = this.parentParam.inOutClCd
            this.reqBarCdParam.outPlcId = this.parentParam.outPlcId
            this.reqBarCdParam.prchTyp = this.parentParam.prchTyp
            this.reqBarCdParam.serNumList = String(serNumList)

            //이동출고(301) , 매출출고(213)
            if (
                this.reqBarCdParam.inOutClCd === '301' ||
                this.reqBarCdParam.inOutClCd === '213'
            ) {
                disDcoProdInsBarCdApi
                    .getProdBarCdOut(this.reqBarCdParam)
                    .then((res) => {
                        this.gridObj.setRows(res)
                        this.errChk = true
                    })
            } else {
                disDcoProdInsBarCdApi
                    .getProdBarCdIn(this.reqBarCdParam)
                    .then((res) => {
                        this.gridObj.setRows(res)
                        this.errChk = true
                    })
            }
        },
        //오류일괄변경
        errClear: function () {
            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
                return
            }
            if (_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
            } else {
                this.gridObj.dataProvider.removeRows(this.getErrRow())
                this.gridObj.gridView.commit()
            }
        },
        //확인
        onConfirm() {
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (!this.errChk) {
                this.showTcComAlert('바코드검증을 하시기 바랍니다.')
                return
            }
            if (!_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('오류제거를 하시기 바랍니다.')
                return
            }
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
                return
            }
            this.$emit('confirm', rowData)
            this.onClose()
        },
        //오류ROW 조회
        getErrRow() {
            let errRow = []
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            rowData.forEach((data, i) => {
                if (!_.isEmpty(_.get(data, 'errDesc'))) {
                    errRow.push(i)
                }
            })
            return errRow
        },
        /* 팝업 창닫기 */
        onClose() {
            this.activeOpen = false
        },
    },
}
</script>
