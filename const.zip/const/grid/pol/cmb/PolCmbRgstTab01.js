import { ValueType } from 'realgrid'

export const GRID_INFO_ITN = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            type: 'data',
            width: '40',
            header: {
                text: '상품ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            header: {
                text: '상품명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_TV = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            type: 'data',
            width: '40',
            header: {
                text: '상품ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            header: {
                text: '상품명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_SETTOP = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'setProdCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'setProdNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'setProdCd',
            fieldName: 'setProdCd',
            type: 'data',
            width: '40',
            header: {
                text: '상품ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'setProdNm',
            fieldName: 'setProdNm',
            type: 'data',
            header: {
                text: '상품명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_RESULT = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktWireless',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktReSel',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'skb',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'sktWireless',
            fieldName: 'sktWireless',
            type: 'number',
            header: {
                text: 'SKT(무선)',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'sktReSel',
            fieldName: 'sktReSel',
            type: 'number',
            header: {
                text: 'SKT(재판매)',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'skb',
            fieldName: 'skb',
            type: 'number',
            header: {
                text: 'SKB',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
    ],
}

export const GRID_INFO_GRADE = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gradeFrom',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'gradeTo',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktWireless',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'sktReSel',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'skb',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'gradeFrom',
            fieldName: 'gradeFrom',
            type: 'number',
            header: {
                text: 'From',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'gradeTo',
            fieldName: 'gradeTo',
            type: 'number',
            header: {
                text: 'To',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'sktWireless',
            fieldName: 'sktWireless',
            type: 'number',
            header: {
                text: 'SKT(무선)',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'sktReSel',
            fieldName: 'sktReSel',
            type: 'number',
            header: {
                text: 'SKT(재판매)',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
        {
            name: 'skb',
            fieldName: 'skb',
            type: 'number',
            header: {
                text: 'SKB',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: true,
            editor: { type: 'number', editFormat: '#,##0' },
            numberFormat: '#,##0',
        },
    ],

    layout: [
        {
            name: 'Grade',
            direction: 'horizontal',
            items: ['gradeFrom', 'gradeTo'],
        },
        'sktWireless',
        'sktReSel',
        'skb',
    ],
}
