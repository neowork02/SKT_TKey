<!-----------------------------------------------
 * 업무그룹명: 분실,도난단말기 관리현황
 * 서브업무명: 분실,도난단말기 해제등록
 * 설명: 분실,도난단말기 해제등록 업데이트한다.
 * 작성자: P179234
 * 작성일: 2022.06.24
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">분실,도난단말기 해제등록</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="해제일자"
                                    calType="D"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.opDt"
                                    @change="dateChange"
                                />
                            </div>
                        </div>
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridLossRobberyProdMgmtDelHeader"
                                ref="gridLossRobberyProdMgmtDelHeader"
                                gridTitle="분실,도난단말기 목록"
                                :gridObj="gridObj"
                                :isPageRows="false"
                                :isExceldown="false"
                                :isNextPage="false"
                                :isPageCnt="false"
                            />
                            <TCRealGrid
                                id="gridLossRobberyProdMgmtDel"
                                ref="gridLossRobberyProdMgmtDel"
                                :fields="gridSet.fields"
                                :columns="gridSet.columns"
                                :styles="gridStyle"
                            />
                        </div>
                    </div>
                    <div class="textareaLayer_wrap">
                        <TCComTextArea
                            v-model="reqParam.rmks"
                            labelName="해제사유"
                            class="boxtype"
                        ></TCComTextArea>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="save"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 콜백 서비스 아이디
 * 4 리스크 기기정보 체크
------------------------------------------------>
<script>
import { CommonGrid, CommonUtil } from '@/utils'
import disBeqLossRobberyProdApi from '@/api/biz/dis/beq/disBeqLossRobberyProdMgmt.js'
import { GRID_HEADER } from '@/const/grid/dis/beq/disBeqLossRobberyProdMgmtHeader.js'
import CommonMixin from '@/mixins'
import moment from 'moment'

import _ from 'lodash'

export default {
    name: 'DisBeqLossRobberyProdMgmtIniting',
    mixins: [CommonMixin],
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        lossRobberyProd: {
            type: Array,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
                this.$emit('update:addBadProd', value)
            },
        },
    },
    data() {
        return {
            objAuth: {},
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeader: {},
            gridStyle: {
                height: '300px',
            },
            gridSet: GRID_HEADER,
            showBcoOrgAgencys: false,
            showBcoAuthOrgTrees: false,
            rowCnt: 15,
            searchForms: {},
            reqParam: {
                opDt: this.getToday(),
                rmks: '',
            },
            opDt: [],
            prod: this.lossRobberyProd,
        }
    },
    mounted() {
        this.initParam()
        this.setGrid()
        console.log(this.prod)
    },
    methods: {
        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                opDt: this.getToday(),
                rmks: '',
            }
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.gridLossRobberyProdMgmtDel
            this.gridHeader = this.$refs.gridLossRobberyProdMgmtDelHeader
            this.gridObj.setGridState(false)
            this.gridObj.gridView.setRowIndicator({ visible: true })
            this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
            this.gridObj.setRows(this.prod)
        },
        gridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        /* 불량기기 등록취소 */
        async save() {
            console.log('save')
            let datas = []
            this.prod.forEach((data) => {
                data.clsDt = this.reqParam.opDt
                data.rmks = this.reqParam.rmks
                datas.push(data)
            })

            const checked = this.check(datas)
            if (!checked) return
            const formData = { rowDatas: checked }

            this.showTcComConfirm('등록취소 하시겠습니까?').then(
                async (confirm) => {
                    if (confirm) {
                        await disBeqLossRobberyProdApi
                            .disBeqLossRobberyProdCanceling(formData)
                            .then(() => {
                                this.$emit('confirm', true)
                                this.activeOpen = false
                            })
                    }
                }
            )
        },
        /* 불량기기관리 상태해제 - 체크한 열 정보 가져오기 */
        getRows(grid) {
            let jsonData = []
            grid.gridView.commit()
            const checkRows = grid.gridView.getCheckedRows(true)
            checkRows.forEach((row) => {
                const data = grid.dataProvider.getJsonRow(row)
                jsonData.push(data)
            })
            return [...jsonData]
        },
        /* 불량기기 해제등록시 조건 체크 */
        check(data) {
            const returnData =
                this.reqParam.rmks === ''
                    ? this.showTcComAlert('해제사유 정보가 없습니다.')
                    : data

            if (_.isEmpty(returnData)) return false

            if (returnData.opDt < this.prod.opDt) {
                this.showTcComAlert(
                    '불량기기 해제 등록일자는 불량기기 해제 등록일자 ' +
                        this.prod.opDt +
                        ' 보다 과거로 과거로 등록할 수 없습니다.'
                )
            } else {
                return returnData
            }
        },
        /* 변경 된 일자가 현재일자 보다 앞설경우 체크 */
        dateChange(val) {
            if (
                CommonUtil.onlyNumber(val) <
                CommonUtil.onlyNumber(this.getToday())
            ) {
                this.showTcComAlert('최종 일마감 이전 일자입니다.')
                setTimeout(() => {
                    this.reqParam.opDt = this.getToday()
                }, 1500)
            }
        },
        /* 현재일자 확인(yyyy-mm-dd)*/
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
        /* 팝업닫기 */
        closeBtn() {
            this.activeOpen = false
        },
    },
}
</script>
