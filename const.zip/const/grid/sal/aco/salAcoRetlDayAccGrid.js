/*****************************************
 * 업무 그룹명 : 판매관리
 * 서브 업무명 : 소매매출-소매매출수납관리
 * 설 명 : 소매매출수납관리 Grid 헤더
 * 작 성 자 : 양현모
 * 작 성 일 : 2022.07.18
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const SELL_PAY_HEADER = {
    fields: [
        {
            fieldName: 'payTyp',
            dataType: ValueType.TEXT, // 수납구분
        },
        {
            fieldName: 'procCl',
            dataType: ValueType.TEXT, // 처리상태
        },
        {
            fieldName: 'paySt',
            dataType: ValueType.TEXT, // 수납상태
        },
        {
            fieldName: 'saleChgDtm',
            dataType: ValueType.TEXT, // 매출일
        },
        {
            fieldName: 'ordDpstSeq',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'ordId',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'ordMgmtNo',
            dataType: ValueType.TEXT, // 주문관리번호
        },
        {
            fieldName: 'webOrdNo',
            dataType: ValueType.TEXT, // 웹주문번호
        },
        {
            fieldName: 'cancelPayDtm',
            dataType: ValueType.TEXT, // 수납취소일
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, // 판매관리번호
        },
        {
            fieldName: 'cntrctMgmtNum',
            dataType: ValueType.TEXT, // 계약관리번호
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, // 서비스관리번호
        },
        {
            fieldName: 'objAmt',
            dataType: ValueType.NUMBER, // 수납대상금액
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, //
        },
        {
            fieldName: 'mdlNm',
            dataType: ValueType.TEXT, // 모델명
        },
        {
            fieldName: 'taxTyp',
            dataType: ValueType.TEXT, // 과세유형
        },
        {
            fieldName: 'custNm',
            dataType: ValueType.TEXT, // 고객명
        },
        {
            fieldName: 'svcNum',
            dataType: ValueType.TEXT, // 개통번호
        },
        {
            fieldName: 'saleDtlTyp',
            dataType: ValueType.TEXT, // 판매유형
        },
        {
            fieldName: 'dsNetCd',
            dataType: ValueType.TEXT, // 약정조건
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT, // 요금제
        },
        {
            fieldName: 'cancelRmks',
            dataType: ValueType.TEXT, // 비고
        },
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, // 수납관리번호
        },
        {
            fieldName: 'gnrlPaymentYn',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'saleClCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'orgYn',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'lastYn',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'dealCoCl',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT, //
        },
    ],
    columns: [
        {
            name: 'payTyp',
            fieldName: 'payTyp',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '수납구분',
            },
        },
        {
            name: 'procCl',
            fieldName: 'procCl',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '처리상태',
            },
        },
        {
            name: 'paySt',
            fieldName: 'paySt',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '수납상태',
            },
            styleCallback(grid, dataCell) {
                // const ret = { styleName: '', renderer: {} }
                const ret = { styleName: '' }

                if (
                    dataCell.value === '처리완료' ||
                    dataCell.value === '수납취소요청'
                ) {
                    ret.styleName = 'underLine'
                    // ret.styleName = 'orange-column'
                    // ret.renderer = { type: 'link' }
                }

                return ret
            },
        },
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            width: '100',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editable: false,
            header: {
                text: '매출일',
            },
        },
        {
            name: 'ordId',
            fieldName: 'ordId',
            type: 'data',
            width: '100',
            visible: false,
            editable: false,
            header: {
                text: '주문번호',
            },
        },
        {
            name: 'webOrdNo',
            fieldName: 'webOrdNo',
            type: 'data',
            width: '100',
            visible: false,
            editable: false,
            header: {
                text: '웹주문번호',
            },
        },
        {
            name: 'cancelPayDtm',
            fieldName: 'cancelPayDtm',
            type: 'data',
            width: '100',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editable: false,
            header: {
                text: '수납취소일',
            },
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '판매관리번호',
            },
        },
        {
            name: 'cntrctMgmtNum',
            fieldName: 'cntrctMgmtNum',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '계약관리번호',
            },
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            width: '120',
            editable: false,
            header: {
                text: '서비스관리번호',
            },
        },
        {
            name: 'objAmt',
            fieldName: 'objAmt',
            type: 'data',
            width: '100',
            numberFormat: '#,##0',
            styleName: 'right-column',
            editable: false,
            header: {
                text: '수납대상금액',
            },
        },
        {
            name: 'mdlNm',
            fieldName: 'mdlNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            editable: false,
            header: {
                text: '모델명',
            },
        },
        {
            name: 'taxTyp',
            fieldName: 'taxTyp',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            editable: false,
            header: {
                text: '과세유형',
            },
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '고객명',
            },
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '개통번호',
            },
        },
        {
            name: 'saleDtlTyp',
            fieldName: 'saleDtlTyp',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '판매유형',
            },
        },
        {
            name: 'dsNetCd',
            fieldName: 'dsNetCd',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '약정조건',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '요금제',
            },
        },
        {
            name: 'cancelRmks',
            fieldName: 'cancelRmks',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '비고',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payTyp = grid.getValue(itemIndex, 'payTyp') ?? ''

                if (payTyp === '위탁') {
                    ret.editable = true
                }

                return ret
            },
        },
    ],
}

export const SALE_PAY_HEADER = {
    fields: [
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, // 수납관리번호
        },
        {
            fieldName: 'ordId',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'webOrdNo',
            dataType: ValueType.TEXT, // 웹주문번호
        },
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, // 판매관리번호
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델
        },
        {
            fieldName: 'eqpSerNo',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'mdlCashSalePrc',
            dataType: ValueType.NUMBER, // 매출금액
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, // 수납일
        },
        {
            fieldName: 'payMgmtNo',
            dataType: ValueType.TEXT, // 수납번호
        },
        {
            fieldName: 'payMthdCd',
            dataType: ValueType.TEXT, // 수납방법
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 처리자ID
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT, // 처리자
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 처리일시
        },
    ],
    columns: [
        {
            name: 'ordId',
            fieldName: 'ordId',
            type: 'data',
            width: '100',
            visible: false,
            header: {
                text: '주문번호',
            },
        },
        {
            name: 'webOrdNo',
            fieldName: 'webOrdNo',
            type: 'data',
            width: '100',
            visible: false,
            header: {
                text: '웹주문번호',
            },
        },
        {
            name: 'saleMgmtNo',
            fieldName: 'saleMgmtNo',
            type: 'data',
            width: '100',
            header: {
                text: '수납관리번호',
            },
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            width: '100',
            header: {
                text: '판매관리번호',
            },
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            width: '100',
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            header: {
                text: '모델',
            },
        },
        {
            name: 'eqpSerNo',
            fieldName: 'eqpSerNo',
            type: 'data',
            width: '100',
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'mdlCashSalePrc',
            fieldName: 'mdlCashSalePrc',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '매출금액',
            },
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            width: '100',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '수납일',
            },
        },
        {
            name: 'payMgmtNo',
            fieldName: 'payMgmtNo',
            type: 'data',
            width: '100',
            header: {
                text: '수납번호',
            },
        },
        {
            name: 'payMthdCd',
            fieldName: 'payMthdCd',
            type: 'data',
            width: '100',
            header: {
                text: '수납방법',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            width: '100',
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            width: '100',
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '100',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
            header: {
                text: '처리일시',
            },
        },
    ],
}

export const PAY_HST_HEADER = {
    fields: [
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, // 수납관리번호
        },
        {
            fieldName: 'ordId',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'webOrdNo',
            dataType: ValueType.TEXT, // 웹주문번호
        },
        {
            fieldName: 'procSt',
            dataType: ValueType.TEXT, // 수납구분
        },
        {
            fieldName: 'prodSaleNo',
            dataType: ValueType.TEXT, // 판매관리번호
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, // 수납일
        },
        {
            fieldName: 'payMgmtNo',
            dataType: ValueType.TEXT, // 수납번호
        },
        {
            fieldName: 'payAmt',
            dataType: ValueType.NUMBER, // 수납금액
        },
        {
            fieldName: 'payMthdCdNm',
            dataType: ValueType.TEXT, // 수납방법
        },
        {
            fieldName: 'cardCoCdNm',
            dataType: ValueType.TEXT, // 카드사
        },
        {
            fieldName: 'cardAprvNo',
            dataType: ValueType.TEXT, // 카드승인번호
        },
        {
            fieldName: 'cardAprvDt',
            dataType: ValueType.TEXT, // 카드승인일자
        },
        {
            fieldName: 'ediYn',
            dataType: ValueType.TEXT, // EDI여부
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, // 비고
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT, // 처리자ID
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT, // 처리자
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT, // 처리일시
        },
    ],
    columns: [
        {
            name: 'ordId',
            fieldName: 'ordId',
            type: 'data',
            width: '100',
            visible: false,
            header: {
                text: '주문번호',
            },
        },
        {
            name: 'webOrdNo',
            fieldName: 'webOrdNo',
            type: 'data',
            width: '100',
            visible: false,
            header: {
                text: '웹주문번호',
            },
        },
        {
            name: 'saleMgmtNo',
            fieldName: 'saleMgmtNo',
            type: 'data',
            width: '100',
            header: {
                text: '수납관리번호',
            },
        },
        {
            name: 'procSt',
            fieldName: 'procSt',
            type: 'data',
            width: '100',
            header: {
                text: '수납구분',
            },
        },
        {
            name: 'prodSaleNo',
            fieldName: 'prodSaleNo',
            type: 'data',
            width: '100',
            header: {
                text: '판매관리번호',
            },
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            width: '100',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '수납일',
            },
        },
        {
            name: 'payMgmtNo',
            fieldName: 'payMgmtNo',
            type: 'data',
            width: '100',
            header: {
                text: '수납번호',
            },
        },
        {
            name: 'payAmt',
            fieldName: 'payAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '수납금액',
            },
        },
        {
            name: 'payMthdCdNm',
            fieldName: 'payMthdCdNm',
            type: 'data',
            width: '100',
            header: {
                text: '수납방법',
            },
        },
        {
            name: 'cardCoCdNm',
            fieldName: 'cardCoCdNm',
            type: 'data',
            width: '100',
            header: {
                text: '카드사',
            },
        },
        {
            name: 'cardAprvNo',
            fieldName: 'cardAprvNo',
            type: 'data',
            width: '100',
            header: {
                text: '카드승인번호',
            },
        },
        {
            name: 'cardAprvDt',
            fieldName: 'cardAprvDt',
            type: 'data',
            width: '100',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '카드승인일자',
            },
        },
        {
            name: 'ediYn',
            fieldName: 'ediYn',
            type: 'data',
            width: '100',
            header: {
                text: 'EDI여부',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '100',
            header: {
                text: '비고',
            },
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            type: 'data',
            width: '100',
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            width: '100',
            header: {
                text: '처리자',
            },
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            width: '100',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
            header: {
                text: '처리일시',
            },
        },
    ],
}

export const PAY_TARGET_HEADER = {
    fields: [
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, // 판매관리번호
        },
        {
            fieldName: 'gnrlPaymentChk',
            dataType: ValueType.TEXT, // 수납대상 설정가능 여부
        },
        {
            fieldName: 'gnrlPaymentYn',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'preCashYn',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'preCashYnTobe',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'settlCondCd',
            dataType: ValueType.TEXT, //
        },
    ],
    columns: [
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '판매관리번호',
            },
        },
        {
            name: 'gnrlPaymentChk',
            fieldName: 'gnrlPaymentChk',
            type: 'data',
            width: '100',
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            values: ['Y', 'N'],
            labels: ['예', '아니오'],
            header: {
                text: '수납대상 설정가능 여부',
            },
        },
    ],
}
