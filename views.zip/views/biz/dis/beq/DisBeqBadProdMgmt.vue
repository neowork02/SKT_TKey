<!-----------------------------------------------
 * 업무그룹명: 불량기기관리현황
 * 서브업무명: 불량기기관리
 * 설명: 불량기기관리현황 조회 업데이트한다.
 * 작성자: P179234
 * 작성일: 2022.06.7
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>불량기기관리</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onManage(1)"
                    >교품결과</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onManage(2)"
                    >불량해제</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="objAuth"
                    @click="onManage(6)"
                    >엑셀업로드</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onManage(3)"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onManage(4)"
                    >조회</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onManage(5)"
                    >신규</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="등록일자"
                        :calType="calType5"
                        :eRequired="true"
                        v-model="setDate"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        placeholder="입력해주세요"
                        :codeVal.sync="reqParam.orgCd"
                        :disabledAfter="true"
                        :eRequired="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        v-model="reqParam.orgNm"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <div class="arrayType">
                        <div class="col60">
                            <TCComInput
                                labelName="개통일"
                                v-model="reqParam.svcDtCnt"
                                :objAuth="objAuth"
                            />
                        </div>
                        <div class="col35">
                            <TCComNoLabelComboBox
                                codeId="ZDIS_C_00200"
                                ref="prchTypComboBox"
                                :objAuth="objAuth"
                                :addBlankItem="true"
                                :blankItemText="'선택'"
                                blankItemValue=""
                                v-model="reqParam.svcDtStrd"
                            />
                        </div>
                    </div>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="불량상태"
                        codeId="ZDIS_C_00090"
                        ref="prchTypComboBox"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                        blankItemValue=""
                        v-model="reqParam.badStCd"
                        :filterFunc="filterFuncbadStCd"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        :appendIconShow="false"
                        :appendIconClass="''"
                        labelName="일련번호"
                        v-model="reqParam.serNum"
                        :objAuth="objAuth"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInput
                        :appendIconShow="false"
                        :appendIconClass="''"
                        labelName="모델명"
                        v-model="reqParam.prodNm"
                        :objAuth="objAuth"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00240"
                        labelName="거래처구분"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                        v-model="reqParam.dealcoClCd"
                        :filterFunc="filterFuncDealcoClCd"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <!-- :size="70"-->
                    <TCComComboBox
                        :itemList="this.chrgrUserIdData"
                        labelName="영업담당"
                        v-model="reqParam.chrgrUserId"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
            </div>
            <template>
                <div class="btn_def">
                    <v-btn
                        plain
                        class="btn_ty_exp"
                        v-bind:class="{
                            ' btn_ty_exp_active ': active,
                        }"
                        @click="active = !active"
                    >
                    </v-btn>
                </div>
            </template>
            <v-expand-transition>
                <div class="toggleWrap" v-show="active">
                    <div class="searchform">
                        <div class="formitem div4">
                            <TCComInputSearchText
                                v-model="reqParam.saleDealcoNm"
                                :codeVal.sync="reqParam.saleDealcoCd"
                                labelName="현보유처"
                                placeholder="입력해주세요"
                                :disabledAfter="true"
                                :objAuth="objAuth"
                                :disabled="dealcoDisabled"
                                @enterKey="onDealcoEnterKey1"
                                @appendIconClick="onDealcoIconClick1"
                                @input="onDealcoInput1"
                            />
                            <BasBcoDealcosPop
                                v-if="showBasBcoDealcos1"
                                :parentParam="searchForm1"
                                :rows="resultDealcoRows1"
                                :dialogShow.sync="showBasBcoDealcos1"
                                @confirm="onDealcoReturnData1"
                            />
                        </div>
                        <div class="formitem div4">
                            <TCComComboBox
                                labelName="구매유형"
                                codeId="PRCH_TYP_CD"
                                ref="prchTypComboBox"
                                :objAuth="objAuth"
                                :addBlankItem="true"
                                :blankItemText="'전체'"
                                blankItemValue=""
                                v-model="reqParam.prchTypCd"
                                :filterFunc="filterFuncPrchTypCd"
                            />
                        </div>
                        <div class="formitem div4">
                            <TCComComboBox
                                labelName="단말기구분"
                                codeId="ZBAS_C_00500"
                                ref="prchTypComboBox"
                                :objAuth="objAuth"
                                :addBlankItem="true"
                                :blankItemText="'전체'"
                                blankItemValue=""
                                v-model="reqParam.eqpClCd"
                            />
                        </div>
                        <div class="formitem div4">
                            <TCComInputSearchText
                                v-model="reqParam.badDealcoNm"
                                :codeVal.sync="reqParam.badDealcoCd"
                                labelName="등록보유처"
                                placeholder="입력해주세요"
                                :disabledAfter="true"
                                :objAuth="objAuth"
                                :disabled="dealcoDisabled"
                                @enterKey="onDealcoEnterKey2"
                                @appendIconClick="onDealcoIconClick2"
                                @input="onDealcoInput2"
                            />
                            <BasBcoDealcosPop
                                v-if="showBasBcoDealcos2"
                                :parentParam="searchForm2"
                                :rows="resultDealcoRows2"
                                :dialogShow.sync="showBasBcoDealcos2"
                                @confirm="onDealcoReturnData2"
                            />
                        </div>
                    </div>
                </div>
            </v-expand-transition>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="불량기기목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="false"
                :isPageCnt="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="gridSet.fields"
                :columns="gridSet.columns"
                :styles="gridStyle"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getBadProdMgmts"
                :gridObj="gridObj"
                :rowCnt="rowCnt"
                @input="chgRowCnt"
            />
        </div>
        <!-- 교품결과 -->
        <ExpartReqRsltPop
            ref="popup"
            v-if="showExpartReqRslt === true"
            :dialogShow.sync="showExpartReqRslt"
            :expartReqRslt.sync="badProd"
        />
        <!-- 불량기기 해제  -->
        <BadProdOutPop
            ref="popup"
            v-if="showBadProdOut === true"
            :dialogShow.sync="showBadProdOut"
            :badProdDataOut.sync="badProd"
            :mainSearchForms.sync="searchForms"
            @confirm="onReturnBadProdOut"
        />
        <!-- 불량기기 저장 -->
        <DisBeqBadProdCrePop
            ref="popup"
            v-if="showCreateBadProd === true"
            :dialogShow.sync="showCreateBadProd"
            :createBadProd.sync="badProdInfo"
            @confirm="onReturnBadProdCre"
        />
        <DisBeqBadProdMgmtXlsUpld
            ref="popup"
            v-if="showBadProdMgmtXlsUpldPop === true"
            :dialogShow.sync="showBadProdMgmtXlsUpldPop"
            @confirm="onReturnXlsUpld"
        />
    </div>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 콜백 서비스 아이디
 * 4 콤보박스의 공통코드적용
 * 5 조회 - 조직 밸리데이션
 * 6 엑셀다운로드 
------------------------------------------------>
<script>
import { CommonGrid, CommonUtil, CommonMsg } from '@/utils'
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
// import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
// import BasBcoUserSaleChrgrsPopup from '@/components/common/BasBcoUserSaleChrgrsPopup'
import basBcoUserApi from '@/api/biz/bas/bco/basBcoUserPop'
import ExpartReqRsltPop from './DisBeqExpartReqRsltPop'
import BadProdOutPop from './DisBeqBadProdOutPop'
import DisBeqBadProdCrePop from './DisBeqBadProdCrePop'
import disDtrDisMovPrstApi from '@/api/biz/dis/dtr/disDtrMovPrst' // 영업담당조회
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
// import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
import disBeqBadProdApi from '@/api/biz/dis/beq/disBeqBadProdMgmt.js'
import commonApi from '@/api/common/prototype'
import { GRID_HEADER } from '@/const/grid/dis/beq/disBeqBadProdMgmtHeader.js'
import { BadProd } from './js/disBeqBadProd.js'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

import { SacCommon } from '@/views/biz/sac/js'
import attachedFileApi from '@/api/common/attachedFile'

import DisBeqBadProdMgmtXlsUpld from './DisBeqBadProdMgmtXlsUpld'

//====================내부거래처-전체조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-전체조직==================

export default {
    name: 'DisBeqBadProdMgmt',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        // BasBcoOrgAgencysPopup,
        // BasBcoUserSaleChrgrsPopup,
        ExpartReqRsltPop,
        BadProdOutPop,
        DisBeqBadProdCrePop,
        BasBcoDealcosPop,
        DisBeqBadProdMgmtXlsUpld,
    },

    data() {
        return {
            active: false,
            //
            objAuth: {},
            indicatorOpt: { sort: 'ASC' },
            codeIDView: true,
            codeIDViewVal: '',
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '400px',
            },
            calType5: 'DP',
            showExpartReqRslt: false,
            showBadProdOut: false,
            showCreateBadProd: false,
            // showBcoOrgAgencys1: false,
            // showBcoOrgAgencys2: false,
            showBcoAuthOrgTrees: false,
            showBcoSaleChrgr: false,
            gridSet: GRID_HEADER,
            badProd: BadProd,
            addBadProd: BadProd,
            rowCnt: 15,
            searchForms: {},
            searchSaleChrgrParam: {},
            rgstDt: [],
            chrgrUserIdData: [],
            reqParam: {
                regStaDt: '',
                regEndDt: '',
                serNum: '',
                org: '',
                oprUsrId: '',
                prodCd: '',
                svcDtStrd: '',
                badStCd: '',
                dealcoClCd: '',
                prchTypCd: '',
                eqpClCd: '',
                //조직검색관련
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                //
                saleDealcoCd: '',
                saleDealcoNm: '',
                badDealcoNm: '',
                badDealcoCd: '',
            },
            searchable: false,
            // row 더블클릭 상세 조회
            badProdInfo: {},

            //====================내부거래처-전체조직====================
            dealcoDisabled: false,
            showBasBcoDealcos1: false, // 현보유처
            resultDealcoRows1: [],
            searchForm1: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
                onlyDisUse: 'Y', // 재고 전용 여부
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            showBasBcoDealcos2: false, // 등록보유처
            resultDealcoRows2: [],
            searchForm2: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
                onlyDisUse: 'Y', // 재고 전용 여부
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            //====================//내부거래처-전체조직==================
            orgDisabled: false,
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            // 엑셀업로드
            showBadProdMgmtXlsUpldPop: false,
        }
    },
    // watch: {
    //     rgstDt: {
    //         handler: function (value) {
    //             this.searchable =
    //                 value[0] === '' || value[1] === '' ? false : true
    //             // this.reqParam.basMth = CommonUtil.onlyNumber(value[1])
    //         },
    //         deep: true,
    //         immediate: true,
    //     },
    // },
    computed: {
        setDate: {
            get() {
                return this.rgstDt
            },
            set(value) {
                this.rgstDt = value
                this.searchable =
                    value[0] === '' || value[1] === '' ? false : true
                this.searchParam.basMth = CommonUtil.onlyNumber(
                    value[1]
                ).substr(0, 6)
                // 내부거래처 기준년월 파라미터 set
                this.searchForm1.basDay = CommonUtil.onlyNumber(value[1])
                this.searchForm2.basDay = CommonUtil.onlyNumber(value[1])
                return value
            },
        },
    },
    mounted() {
        this.init()
        this.initParam()
        this.setGrid()
        this.getCommCodeList('ZBAS_C_00500', 'prodClNm') // 단말기구분코드
        this.getCommCodeList('ZBAS_C_00240', 'dealcoClCd') // 거래처구분코드
    },

    methods: {
        /* 공통코드 */
        getCommCodeList(codeId, columnId) {
            commonApi.getCommonCodeList(codeId).then((res) => {
                let columnValues = []
                let columnLabels = []
                if (res.length) {
                    res.forEach((data) => {
                        columnValues.push(data.commCdVal)
                        columnLabels.push(data.commCdValNm)
                    })
                }
                // 그리드 컬럼 콤보박스 데이터 설정
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'values',
                    columnValues
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'labels',
                    columnLabels
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'lookupDisplay',
                    true
                )
            })
        },
        /* 초기화 */
        clear() {
            this.initParam()
            this.rgstDt = [SacCommon.getFirstday(), SacCommon.getToday()]
            this.setGrid()
        },
        init() {
            this.getChrgrUserIdList() //영업담당 조회
        },
        initParam() {
            this.reqParam = {
                regStaDt: '',
                regEndDt: '',
                serNum: '',
                org: '',
                OPR_USER_ID: '',
                prodCd: '',
                svcDtStrd: '',
                badStCd: '',
                dealcoClCd: '',
                prchTypCd: '',
                eqpClCd: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                saleDealcoCd: '',
                saleDealcoNm: '',
                badDealcoNm: '',
                badDealcoCd: '',
            }
            this.rgstDt = [SacCommon.getFirstday(), SacCommon.getToday()]

            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLvl'] = this.orgInfo['orgLvl']
                // this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.reqParam['saleDealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['saleDealcoNm'] = this.userInfo['dealcoNm']
                this.reqParam['badDealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['badDealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.grid1
            this.gridHeaderObj = this.$refs.gridHeader1
            this.gridObj.setGridState(true, false, false)
            // this.gridObj.gridView.setRowIndicator({
            //     visible: true,
            //     headText: '번호',
            // })

            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                if ('data' === clickData.cellType) {
                    const rowData = this.gridObj.dataProvider.getJsonRow(
                        clickData.dataRow
                    )
                    this.badProdInfo = { ...this.reqParam, ...rowData }
                    this.badProdInfo.FV_NEW_INSERT_YN = 'N'
                    this.showCreateBadProd = true
                }
            }

            this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
            this.gridObj.setRows({})
        },
        gridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        gridAddPageBtn() {
            this.gridData = this.gridHeaderObj.setAddPage(this.gridData)
        },
        searchBadProd(index) {
            this.gridObj.gridView.commit()
            const current = this.gridObj.gridView.getCurrent()

            if (current.dataRow === -1) {
                this.showTcComAlert('불량기기를 선택해주세요.')
                return
            } else {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    current.dataRow
                )
                this.badProd = jsonData
                // console.log('선택된 row data ========= .>>> ', jsonData)

                if (index === 1) {
                    this.showExpartReqRslt = true
                } else if (index === 2) {
                    if (
                        '09' != jsonData.opClCd &&
                        '12' != jsonData.opClCd &&
                        '01' != jsonData.opClCd
                    ) {
                        this.showTcComAlert(
                            '미처리 또는 AS입고/교품반환입고 확정된 불량기기만 불량해제 등록을 할 수 있습니다.'
                        )
                        return
                    }
                    this.showBadProdOut = true
                }
            }
        },
        /* 버튼별 이벤트 */
        onManage(index) {
            if (index === 1) {
                /* 교품결과 */
                this.searchBadProd(1)
            } else if (index === 2) {
                /* 불량해제 */
                this.searchBadProd(2)
            } else if (index === 3) {
                /* 초기화 */
                this.clear()
            } else if (index === 4) {
                /* 조회 */
                this.search()
            } else if (index === 5) {
                /* 신규 */
                this.badProdInfo = {
                    orgCd: this.reqParam.orgCd,
                    orgNm: this.reqParam.orgNm,
                    orgLvl: this.reqParam.orgLvl,
                    hldDealcoNm: this.reqParam.saleDealcoNm,
                    hldDealcoCd: this.reqParam.saleDealcoCd,
                    FV_NEW_INSERT_YN: 'Y',
                }
                this.showCreateBadProd = true
            } else if (index === 6) {
                /* 엑셀업로드 */
                this.showBadProdMgmtXlsUpldPop = true
            }
        },
        /* 불량기기관리 조회 - 최초 */
        search() {
            const startMonth = this.rgstDt[0].substring(5, 7)
            const endMonth = this.rgstDt[1].substring(5, 7)

            if (this.searchable === false) {
                this.showTcComAlert('등록일자를 지정해주세요.')
            } else if (startMonth !== endMonth) {
                this.showTcComAlert(
                    '등록일자의 시작일과 종료일을 동일한 월로 지정해 주세요.'
                )
            } else if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00121', '조직;조회')
                )
            } else {
                this.gridData.totalPage = 0
                this.searchForms = { ...this.reqParam }
                this.searchForms.pageSize = this.rowCnt
                this.searchForms.pageNum = 1
                this.searchForms.regStaDt = CommonUtil.onlyNumber(
                    this.rgstDt[0]
                )
                this.searchForms.regEndDt = CommonUtil.onlyNumber(
                    this.rgstDt[1]
                )
                this.getBadProdMgmts(this.searchForms.pageNum)
            }
        },
        onReturnBadProdOut(retVal) {
            if (retVal) {
                // 화면재조회
                this.search()
            }
        },
        onReturnBadProdCre(retVal) {
            if (retVal) {
                // 화면재조회
                this.search()
            }
        },
        filterFuncbadStCd(items) {
            return items.filter(
                (item) => item['commCdVal'] == '01' || item['commCdVal'] == '02'
            )
        },
        filterFuncPrchTypCd(items) {
            return items.filter((item) => item['commCdVal'] != 'PT03')
        },
        filterFuncDealcoClCd(items) {
            return items.filter(
                (item) =>
                    item['commCdVal'] == 'A2' ||
                    item['commCdVal'] == 'A3' ||
                    item['commCdVal'] == 'A6' ||
                    item['commCdVal'] == 'B1' ||
                    item['commCdVal'] == 'B2' ||
                    item['commCdVal'] == 'Z1'
            )
        },
        /* 불량기기관리 조회 - 페이징호출 */
        async getBadProdMgmts(page) {
            this.searchForms.pageNum = page
            //testdata
            // this.searchForms.orgCd = ''
            // this.searchForms.orgLvl = ''
            // this.searchForms.regStaDt = '20220105'
            // this.searchForms.regEndDt = '20220105'
            //testdata

            await disBeqBadProdApi
                .getBadProdMgmts(this.searchForms)
                .then((res) => {
                    if (res) {
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator(
                            res.pagingDto,
                            this.indicatorOpt
                        )
                        this.gridData = this.gridSetData()
                        this.gridData.totalPage = res.pagingDto.totalPageCnt
                        this.gridHeaderObj.setPageCount(res.pagingDto)
                    }
                    // else {
                    //     this.showTcComAlert(
                    //         '불량기기관리 검색 정보를 불러오지 못했습니다.'
                    //     )
                    // }
                })
        },
        //영업담당조회
        getChrgrUserIdList: function () {
            disDtrDisMovPrstApi.getChrgrUserId().then((res) => {
                res.disDtrChrgrUserIdVo.forEach((data) => {
                    const chrgrUserId = {}
                    chrgrUserId.commCdVal = _.get(data, 'chrgrUserId')
                    chrgrUserId.commCdValNm = _.get(data, 'chrgrUserNm')
                    this.chrgrUserIdData.push(chrgrUserId)
                })
            })
        },
        // 엑셀업로드 종료 후
        onReturnXlsUpld(retVal) {
            if (retVal) {
                // 화면 재조회
                this.search()
            }
        },
        /* 내부조직팝업 */
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.reqParam.orgCd
            this.searchParam.orgNm = this.reqParam.orgNm
            this.searchParam.orgLvl = this.reqParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        /* 내부조직팝업 - Icon 이벤트 처리 */
        onAuthOrgTreeIconClick() {
            this.resultAuthOrgTreeRows = []
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        /* 내부조직팝업 - TextField 엔터키 이벤트 처리 */
        onAuthOrgTreeEnterKey() {
            this.resultAuthOrgTreeRows = []
            // if (_.isEmpty(this.reqParam.orgNm)) {
            //     this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
            //     return
            // }
            this.getAuthOrgTreeList()
        },
        /* 내부조직팝업 - TextField Input 이벤트 이벤트 처리 */
        onAuthOrgTreeInput() {
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
        },
        /* 내부조직팝업 - 팝업 리턴 이벤트 이벤트 처리 */
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.orgLvl = _.get(returnData, 'orgLvl')
        },

        // /* 조직별 대리점팝업 */
        // getOrgAgencyList(index) {
        //     this.resultOrgAgencyRows = []
        //     basBcoOrgAgencysApi.getOrgAgencyList(this.reqParam).then((res) => {
        //         console.log('getOrgAgencyList then : ', res)
        //         if (res.length === 1) {
        //             if (index === 1) {
        //                 this.reqParam.saleDealcoCd = _.get(res[0], 'agencyCd')
        //                 this.reqParam.saleDealcoNm = _.get(res[0], 'agencyNm')
        //             } else {
        //                 this.reqParam.badDealcoCd = _.get(res[0], 'agencyCd')
        //                 this.reqParam.badDealcoNm = _.get(res[0], 'agencyNm')
        //             }
        //         } else {
        //             this.resultOrgAgencyRows = res
        //             if (index === 1) {
        //                 this.showBcoOrgAgencys1 = true
        //             } else {
        //                 this.showBcoOrgAgencys2 = true
        //             }
        //         }
        //     })
        // },
        // /* 조직별 대리점팝업 - 돋보기 Icon 이벤트 */
        // onOrgAgencyIconClick(index) {
        //     this.resultOrgAgencyRows = []
        //     if (!_.isEmpty(this.reqParam.agencyNm)) {
        //         this.getOrgAgencyList(index)
        //     } else {
        //         if (index === 1) {
        //             this.showBcoOrgAgencys1 = true
        //         } else {
        //             this.showBcoOrgAgencys2 = true
        //         }
        //     }
        // },
        // /* 조직별 대리점팝업 - 엔터키 이벤트 */
        // onOrgAgencyEnterKey(index) {
        //     this.resultOrgAgencyRows = []
        //     if (_.isEmpty(this.reqParam.agencyNm)) {
        //         return
        //     }
        //     this.getOrgAgencyList(index)
        // },
        // /* 조직별 대리점팝업 - Input 이벤트 */
        // onOrgAgencyInput1() {
        //     this.reqParam.saleDealcoCd = ''
        // },
        // onOrgAgencyInput2() {
        //     this.reqParam.badDealcoCd = ''
        // },
        // /* 조직별 대리점팝업 - 리턴 이벤트 */
        // onOrgAgencyReturnData1(returnData) {
        //     console.log('returnData: ', returnData)
        //     this.reqParam.saleDealcoCd = _.get(returnData, 'agencyCd')
        //     this.reqParam.saleDealcoNm = _.get(returnData, 'agencyNm')
        // },
        // /* 조직별 대리점팝업 - 리턴 이벤트 */
        // onOrgAgencyReturnData2(returnData) {
        //     console.log('returnData: ', returnData)
        //     this.reqParam.badDealcoCd = _.get(returnData, 'agencyCd')
        //     this.reqParam.badDealcoNm = _.get(returnData, 'agencyNm')
        // },

        /* 영업담당자 팝업 */
        // 사용자 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 사용자 팝업 오픈
        getSaleChrgrPopList() {
            basBcoUserApi
                .getSaleChrgrPopList(this.searchUserdParam)
                .then((res) => {
                    console.log('getSaleChrgrPopList then : ', res)
                    // 검색된 사용자 정보가 1건이면 TextField에 바로 설정
                    // 검색된 사용자 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 대리점 팝업 오픈
                    if (res.length === 1) {
                        this.searchSaleChrgrParam.userCd = _.get(
                            res[0],
                            'userCd'
                        )
                        this.searchSaleChrgrParam.userNm = _.get(
                            res[0],
                            'userNm'
                        )
                    } else {
                        this.resultSaleChrgrRows = res
                        this.showBcoSaleChrgr = true
                    }
                })
        },
        // 사용자 TextField 돋보기 Icon 이벤트 처리
        onSaleChrgrIconClick() {
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultSaleChrgrRows = []
            // 검색조건 사용자명이 빈값이 아니면 사용자 정보 조회
            // 그 이외는 사용자 팝업 오픈
            if (!_.isEmpty(this.searchSaleChrgrParam.suplSvcNm)) {
                this.getSaleChrgrPopList()
            } else {
                this.showBcoSaleChrgr = true
            }
        },
        // 사용자 TextField 엔터키 이벤트 처리
        onSaleChrgrEnterKey() {
            // 사용자 팝업 Row 설정 Prop 변수 초기화
            this.resultSaleChrgrRows = []
            // 검색조건 사용자명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchSaleChrgrParam.UserNm)) {
                this.showTcComAlert('사용자명을 입력해주세요.')
                return
            }
            // 사용자 정보 조회
            this.getSaleChrgrList()
        },
        // 사용자 TextField Input 이벤트 처리
        onSaleChrgrInput() {
            // 입력되는 값이 있으면 사용자 코드 초기화
            this.searchSaleChrgrParam.userCd = ''
        },
        // 사용자 팝업 리턴 이벤트 처리
        onSaleChrgrReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchSaleChrgrParam.userCd = _.get(retrunData, 'userCd')
            this.searchSaleChrgrParam.userNm = _.get(retrunData, 'userNm')
        },
        /* 엑셀다운로드 */
        onClickDownload() {
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/beq/badProdMgmtsExcelDown',
                this.searchForms
            )
        },
        /* 현재일자 확인(yyyy-mm-dd)*/
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },

        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList1() {
            this.searchForm1.dealcoCd = this.reqParam.saleDealcoCd
            this.searchForm1.dealcoNm = this.reqParam.saleDealcoNm
            this.searchForm1.orgCd = this.reqParam.orgCd
            this.searchForm1.orgNm = this.reqParam.orgNm
            this.searchForm1.orgLvl = this.reqParam.orgLvl
            basBcoDealcosApi.getDealcosList(this.searchForm1).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.saleDealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.saleDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows1 = res
                    this.showBasBcoDealcos1 = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick1() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows1 = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.saleDealcoNm)) {
                // this.searchForm1.basDay = CommonUtil.onlyNumber(this.rgstDt[1])
                this.getDealcosList1()
            } else {
                this.showBasBcoDealcos1 = true
            }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey1() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows1 = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요.')
                // this.headerText = '검색조건 필수'
                return
            }
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList1()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput1() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.reqParam.saleDealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData1(retrunData) {
            console.log('retrunData: ', retrunData)
            this.reqParam.saleDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.saleDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-전체조직팝업관련 methods ================================
        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList2() {
            this.searchForm2.dealcoCd = this.reqParam.badDealcoCd
            this.searchForm2.dealcoNm = this.reqParam.badDealcoNm
            this.searchForm2.orgCd = this.reqParam.orgCd
            this.searchForm2.orgNm = this.reqParam.orgNm
            this.searchForm2.orgLvl = this.reqParam.orgLvl
            basBcoDealcosApi.getDealcosList(this.searchForm2).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.badDealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.badDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows2 = res
                    this.showBasBcoDealcos2 = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick2() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows2 = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.badDealcoNm)) {
                // this.searchForm2.basDay = CommonUtil.onlyNumber(this.rgstDt[1])
                this.getDealcosList2()
            } else {
                this.showBasBcoDealcos2 = true
            }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey2() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows2 = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요.')
                // this.headerText = '검색조건 필수'
                return
            }
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList2()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput2() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.reqParam.badDealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData2(retrunData) {
            console.log('retrunData: ', retrunData)
            this.reqParam.badDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.badDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-전체조직팝업관련 methods ================================
    },
}
</script>
