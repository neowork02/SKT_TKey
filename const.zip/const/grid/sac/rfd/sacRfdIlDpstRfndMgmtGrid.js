'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: 'chk',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'rfndDealCo',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'dealCoCl',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'dealCl',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'rfndAccNoOrg',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'dpstPlc',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'rfndBankCd',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'procDtm',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'procUserId',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'trmsDt',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'fixDt',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'ccCd',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'mthChkYn',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'modPosYn',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'equalYn',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'imagAccNo',
        dataType: ValueType.TEXT,
        visible: false,
    },

    {
        fieldName: 'rfndSeqNo',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'dpstDt',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'seqNo',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'jourCd',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'rfndDepo',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'sapRfndDepo',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'depoAgreeYn',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'forceAprvYn',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'dpstRfdPlc',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'dpstRfdDt',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'dpstRfdTm',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'dpstRfdImagAccNo',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'dpstRfdSeq',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'bankCd',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'rfndDtm',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'ukeyAgencyCd',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'mod',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'zifdate',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'zconfirm',
        dataType: ValueType.TEXT,
        visible: false,
    },

    {
        fieldName: 'insUserId',
        dataType: ValueType.TEXT,
        visible: false,
    },

    {
        fieldName: 'modUserId',
        dataType: ValueType.TEXT,
        visible: false,
    },

    {
        fieldName: 'dpstPlcNm',
        readOnly: false,
        header: { text: '입금처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'rfndDealCoNm',
        readOnly: false,
        header: { text: '환불거래처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'rfndDt',
        readOnly: false,
        header: { text: '환불일자' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },

    {
        fieldName: 'rfndAccNo',
        readOnly: false,
        header: { text: '환불계좌' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'rfndSeq',
        readOnly: false,
        header: { text: '환불차수' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'dpstYymm',
        readOnly: false,
        header: { text: '입금월' },
        type: 'data',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM',
    },

    {
        fieldName: 'rfndCl',
        visible: false,
        header: { text: '구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'rfndClNm',
        readOnly: false,
        header: { text: '구분' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'rfndAmt',
        readOnly: false,
        header: { text: '환불액' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },

    {
        fieldName: 'procUserIdNm',
        readOnly: false,
        header: { text: '환불처리자' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'fixYn',
        visible: false,
        header: { text: '전송여부' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'fixYnNm',
        readOnly: false,
        header: { text: '전송여부' },
        type: 'data',
        dataType: ValueType.TEXT,
    },

    {
        fieldName: 'remark',
        readOnly: false,
        header: { text: '비고' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {
    rfndListGrid: {
        gridList: [
            {
                equalYn: 'N',
                dpstPlc: '입금처코드1',
                dpstPlcNm: '입금처1 - modPosYn: Y',
                rfndDealCoNm: 'A',
                rfndDt: '202110',
                rfndAccNo: 'AA1200',
                rfndSeq: 'orgNm2',
                dpstYymm: '20120106',
                rfndCl: 'orgNm3',
                rfndAmt: '1000003983838',
                procUserIdNm: null,
                fixYn: '10202838383',
                remark: '오늘날짜',
                modPosYn: 'Y',
            },
            {
                dpstPlc: '입금처코드1',
                dpstPlcNm: '입금처2',
                rfndDealCoNm: 'A',
                rfndDt: '202110',
                rfndAccNo: 'AA1200',
                rfndSeq: 'orgNm2',
                dpstYymm: '20120106',
                rfndCl: 'orgNm3',
                rfndAmt: '1000003983838',
                procUserIdNm: null,
                fixYn: '10202838383',
                remark: '오늘날짜',
                modPosYn: 'N - modPosYn: N',
            },
            {
                dpstPlc: '입금처코드1',
                rfndDealCoNm: 'A',
                rfndDt: '202110',
                rfndAccNo: 'AA1200',
                rfndSeq: 'orgNm2',
                dpstYymm: '20120106',
                rfndCl: 'orgNm3',
                rfndAmt: '1000003983838',
                procUserIdNm: null,
                fixYn: '10202838383',
                remark: '오늘날짜',
            },
        ],
        pagingDto: {
            pageSize: 10,
            pageNum: 1,
            totalPageCnt: 45,
            totalDataCnt: 0,
        },
    },
}

export { GRID_HEADER, MOCK_DATA }
