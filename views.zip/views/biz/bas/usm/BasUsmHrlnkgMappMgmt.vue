<template>
    <div class="content">
        <!-- Tit -->
        <h1>HR연동매핑관리</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInput
                        v-model="div_search.deptCd"
                        :eRequired="true"
                        labelName="부서코드"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="div_search.deptNm"
                        :eRequired="true"
                        labelName="부서명"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
                <div class="formitem div4">
                    <TCComRadioBox
                        v-model="div_search.aplyYn"
                        :itemList="ds_apply"
                        labelName="반영여부"
                        :objAuth="this.objAuth"
                    ></TCComRadioBox>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="HR연동 매핑관리"
                :gridObj="gridObj"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getHrList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
            <BasBcoOrgTreesPopup
                v-if="showBcoOrgTrees"
                :parentParam="searchParam"
                :rows="resultOrgTreeRows"
                :dialogShow.sync="showBcoOrgTrees"
                @confirm="onOrgTreeReturnData"
            />
            <BasBcoDealcosPopup
                v-if="showBasBcoDealcos"
                :parentParam="searchForm"
                :rows="resultDealcoRows"
                :dialogShow.sync="showBasBcoDealcos"
                @confirm="onDealcoReturnData"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMsg from '@/utils/CommonMsg'
import _ from 'lodash'
import { HEADER } from '@/const/grid/bas/usm/basUsmHrlnkgMappMgmtHeader'
import API from '@/api/biz/bas/usm/basUsmHrlnkgMappMgmt'
import CommonMixin from '@/mixins'
import CommonUtil from '@/utils/CommonUtil.js'
import { SacCommon } from '@/views/biz/sac/js'
//====================내부조직팝업(전체)팝업==============================================
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
import basBcoOrgTreesApi from '@/api/biz/bas/bco/basBcoOrgTrees'
//====================내부거래처(권한조직)=================================================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//======================================================================================

export default {
    name: 'BasUsmHrlnkgMappMgmt',
    components: {
        BasBcoOrgTreesPopup,
        BasBcoDealcosPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //====================내부조직팝업(전체)팝업관련======================
            showBcoOrgTrees: false, // 내부조직팝업(전체) 팝업 오픈 여부
            searchParam: {
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultOrgTreeRows: [], // 내부조직팝업(전체) 팝업 오픈 여부
            //==================================================================
            //====================내부거래처(권한조직)=============================
            showBasBcoDealcos: false,
            searchForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
            },
            resultDealcoRows: [],
            //==================================================================
            // gridStyle: {
            //     height: '500px', //그리드 높이 조절
            // },
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            ds_service: [
                {
                    commCdVal: '1',
                    commCdValNm: '상품코드',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '모델단말기',
                },
                {
                    commCdVal: '4',
                    commCdValNm: 'U.Key ID',
                },
            ],
            ds_apply: [
                {
                    commCdVal: 'N',
                    commCdValNm: '미반영',
                },
                {
                    commCdVal: 'Y',
                    commCdValNm: '반영',
                },
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
            ],
            ds_SearchCl: [
                {
                    commCdVal: '1',
                    commCdValNm: '관리조직',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '원소속조직',
                },
            ],

            ds_prod: [],
            ds_list: [],
            // items: ['전체', 'Option2', 'Option3', 'Option4'],
            switch1: true,
            switch2: false,
            value: '',
            checkBoxItems: [
                { id: 1, isChecked: true },
                { id: 2, isChecked: false },
                { id: 3, isChecked: false, label: '미체크 상태 박스' },
                { id: 4, isChecked: true, label: '체크 상태 박스' },
            ],

            arrDate: [this.getToday(), this.getToday()],

            // 조회조건
            div_search: {
                deptCd: '',
                deptNm: '',
                aplyYn: 'N',
            },
            objAuth: {},
            dataClCd: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
                {
                    commCdVal: '01',
                    commCdValNm: '고객',
                },
                {
                    commCdVal: '02',
                    commCdValNm: '재무',
                },
            ],
            actionCl: [
                {
                    commCdVal: '',
                    commCdValNm: '전체',
                },
            ],
            inputValue: this.getToday(),
            inputValue2: '02',
            reqParam: {
                deptCd: 'string',
                deptNm: 'string',
                applyYn: 'N',
                // pageNum: '0',
                // pageSize: '0',
                // totalPageCnt: '0',
                // totalDataCnt: '0',
            },
            selectedJsonData: {},
            rowCnt: 15,
        }
    },
    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState()

        // 싱글클릭 시 저장데이터 SET
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            this.selectedJsonData = this.gridObj.dataProvider.getJsonRow(
                clickData.dataRow
            )
            console.log('saveparam set', this.selectedJsonData)
        }

        // 그리드내의 부여조직 돋보기 클릭시 이벤트처리
        this.gridObj.gridView.onCellButtonClicked = (
            grid,
            itemIndex,
            column
        ) => {
            this.gridObj.gridView.commit()
            let current = this.gridObj.gridView.getCurrent()
            if (
                column.fieldName === 'orgNm' ||
                column.fieldName === 'bizChrgOrgNm'
            ) {
                this.onOrgTreeIconClick()
            } else if (column.fieldName === 'dealcoNm') {
                this.selectedJsonData = this.gridObj.dataProvider.getJsonRow(
                    current.dataRow
                )
                console.log('selectedJsonData', this.selectedJsonData)
                this.onDealcoIconClick()
            }
        }

        // this.gridObj.gridView.onCellButtonClicked = function (
        //     grid,
        //     index,
        //     col
        // ) {
        //     console.log(index)
        //     const getData = grid.getValue(index, col)
        //     console.log('getData', getData)
        // }

        // this.gridObj.gridView.onCellEdited = (
        //     grid,
        //     itemIndex,
        //     dataRow,
        //     field
        // ) => {
        //     // var column = grid.columnByField('accDealcoNm')
        //     this.gridObj.gridView.commit()
        //     const getData = grid.getValue(itemIndex, field)
        //     console.log('getData', getData)

        //     this.selectedJsonData =
        //         this.gridObj.dataProvider.getJsonRow(dataRow)
        //     console.log('selectedJsonData', this.selectedJsonData)
        // }
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.gridSetData()
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        //===================== 내부조직팝업(전체)팝업관련 methods ================================
        // 내부조직팝업(전체) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(전체) 팝업 오픈
        getOrgTreeList() {
            basBcoOrgTreesApi.getOrgTreeList(this.searchParam).then((res) => {
                console.log('getOrgTreeList then : ', res)
                // 검색된 내부조직팝업(전체) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(전체) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(전체) 팝업 오픈
                if (res.length === 1) {
                    this.searchParam.orgCd = _.get(res[0], 'orgCd')
                    this.searchParam.orgNm = _.get(res[0], 'orgNm')
                } else {
                    this.resultOrgTreeRows = res
                    this.showBcoOrgTrees = true
                }
            })
        },
        // 내부조직팝업(전체) TextField 돋보기 Icon 이벤트 처리
        onOrgTreeIconClick() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이 아니면 내부조직팝업(전체) 정보 조회
            // 그 이외는 내부조직팝업(전체) 팝업 오픈
            if (!_.isEmpty(this.searchParam.orgNm)) {
                this.getOrgTreeList()
            } else {
                this.showBcoOrgTrees = true
            }
        },
        // 내부조직팝업(전체) TextField 엔터키 이벤트 처리
        onOrgTreeEnterKey() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(전체)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(전체) 정보 조회
            this.getOrgTreeList()
        },
        // 내부조직팝업(전체) TextField Input 이벤트 처리
        onOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(전체) 코드 초기화
            this.searchParam.orgCd = ''
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onOrgTreeReturnData(returnData) {
            let current = this.gridObj.gridView.getCurrent()
            console.log('current', current)
            console.log('returnData', returnData)
            let orgCd = _.get(returnData, 'orgCd')
            // let orgNm = _.get(returnData, 'orgNm')
            let orgNmLvl0 = _.get(returnData, 'orgNmLvl0')
            let orgCdLvl1 = _.get(returnData, 'orgCdLvl1')
            let orgNmLvl1 = _.get(returnData, 'orgNmLvl1')
            let orgCdLvl2 = _.get(returnData, 'orgCdLvl2')
            let orgNmLvl2 = _.get(returnData, 'orgNmLvl2')
            let orgCdLvl3 = _.get(returnData, 'orgCdLvl3')
            let orgNmLvl3 = _.get(returnData, 'orgNmLvl3')
            let newOrgNm123 =
                orgNmLvl0 +
                (orgNmLvl1 != null ? ' > ' + orgNmLvl1 : '') +
                (orgNmLvl2 != null ? ' > ' + orgNmLvl2 : '') +
                (orgNmLvl3 != null ? ' > ' + orgNmLvl3 : '')
            if (current.column === 'orgNm') {
                this.gridObj.gridView.setValue(current.dataRow, 'orgCd', orgCd)
                this.gridObj.gridView.setValue(
                    current.dataRow,
                    'orgNm',
                    newOrgNm123
                )
            }
            if (current.column === 'bizChrgOrgNm') {
                this.gridObj.gridView.setValue(
                    current.dataRow,
                    'bizChrgOrgCd',
                    orgCdLvl1
                )
                this.gridObj.gridView.setValue(
                    current.dataRow,
                    'bizChrgOrgNm',
                    orgNmLvl1
                )
                this.gridObj.gridView.setValue(
                    current.dataRow,
                    'teamOrgCd',
                    orgCdLvl2
                )
                this.gridObj.gridView.setValue(
                    current.dataRow,
                    'teamOrgNm',
                    orgNmLvl2
                )
                this.gridObj.gridView.setValue(
                    current.dataRow,
                    'ptOrgCd',
                    orgCdLvl3
                )
                this.gridObj.gridView.setValue(
                    current.dataRow,
                    'ptOrgNm',
                    orgNmLvl3
                )
            }
            // if (current.column === 'dealcoNm') {
            this.gridObj.gridView.setValue(current.dataRow, 'dealcoCd', '')
            this.gridObj.gridView.setValue(current.dataRow, 'dealcoNm', '')
            // }
            this.gridObj.gridView.commit()
        },
        //===================== //내부조직팝업(전체)팝업관련 methods =========================
        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.searchForm.dealcoCd = _.get(res[0], null)
                    this.searchForm.dealcoNm = _.get(res[0], null)
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []

            this.searchForm.orgCd = this.selectedJsonData.orgCd
            this.searchForm.orgNm = this.selectedJsonData.orgNm
            this.searchForm.basDay = CommonUtil.replaceDash(
                SacCommon.getToday()
            )
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.searchForm.dealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchForm.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-전체조직명 입력해주세요.'
                return
            }
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.searchForm.dealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            console.log('returnData: ', returnData)

            let current = this.gridObj.gridView.getCurrent()
            console.log('current', current)
            let dealcoCd = _.get(returnData, 'dealcoCd')
            let dealcoNm = _.get(returnData, 'dealcoNm')
            this.gridObj.gridView.setValue(
                current.dataRow,
                'dealcoCd',
                dealcoCd
            )
            this.gridObj.gridView.setValue(
                current.dataRow,
                'dealcoNm',
                dealcoNm
            )
        },
        //===================== //내부거래처(권한조직)팝업관련 methods ================================
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        //조회 버튼 이벤트
        onSearch: function () {
            this.gridData.totalPage = 0
            this.getHrList(1)
        },

        getHrList(pageNum) {
            let reqParam = {
                deptCd: this.div_search.deptCd,
                deptNm: this.div_search.deptNm,
                aplyYn: this.div_search.aplyYn,
            }
            reqParam.pageNum = pageNum
            reqParam.pageSize = this.rowCnt

            // 페이징 조회
            API.getHrList(reqParam).then((result) => {
                if (result.gridList && result.gridList.length > 0) {
                    this.ds_list = result.gridList
                    this.gridObj.setRows(result.gridList)
                    // 페이징 관련
                    this.gridObj.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                } else if (result.gridList.length == 0) {
                    this.showTcComAlert('데이터가 없습니다.')
                }
            })
        },

        //저장 버튼 이벤트
        onSave: function () {
            // 싱글클릭 시 저장데이터 SET
            let current = this.gridObj.gridView.getCurrent()
            this.selectedJsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            console.log('current param', this.selectedJsonData)

            let basUsmHrlnkgMappMgmtVo = [
                {
                    deptCd: this.selectedJsonData.deptCd,
                    deptNm: this.selectedJsonData.deptNm,
                    psApndYn: this.div_search.aplyYn,
                    orgCd: this.selectedJsonData.orgCd
                        ? this.selectedJsonData.orgCd
                        : '',
                    orgNm: this.selectedJsonData.orgNm
                        ? this.selectedJsonData.orgNm
                        : '',
                    dealcoCd: this.selectedJsonData.dealcoCd
                        ? this.selectedJsonData.dealcoCd
                        : '',
                    dealcoNm: this.selectedJsonData.dealcoNm
                        ? this.selectedJsonData.dealcoNm
                        : '',
                    bizDivOrgCd: this.selectedJsonData.bizDivOrgCd
                        ? this.selectedJsonData.bizDivOrgCd
                        : '', //'AB1000',
                    bizDivOrgNm: this.selectedJsonData.bizDivOrgNm
                        ? this.selectedJsonData.bizDivOrgNm
                        : '',
                    bizChrgOrgCd: this.selectedJsonData.bizChrgOrgCd
                        ? this.selectedJsonData.bizChrgOrgCd
                        : '',
                    bizChrgOrgNm: this.selectedJsonData.bizChrgOrgNm
                        ? this.selectedJsonData.bizChrgOrgNm
                        : '',
                    teamOrgCd: this.selectedJsonData.teamOrgCd
                        ? this.selectedJsonData.teamOrgCd
                        : '',
                    teamOrgNm: this.selectedJsonData.teamOrgNm
                        ? this.selectedJsonData.teamOrgNm
                        : '',
                    ptOrgCd: this.selectedJsonData.ptOrgCd
                        ? this.selectedJsonData.ptOrgCd
                        : '',
                    ptOrgNm: this.selectedJsonData.ptOrgNm
                        ? this.selectedJsonData.ptOrgNm
                        : '',
                    orglDealcoCd: this.selectedJsonData.orglDealcoCd
                        ? this.selectedJsonData.orglDealcoCd
                        : '',
                    orglDealcoNm: this.selectedJsonData.orglDealcoNm
                        ? this.selectedJsonData.orglDealcoNm
                        : '',
                    staffClCd: this.selectedJsonData.staffClCd
                        ? this.selectedJsonData.staffClCd
                        : '',
                    userId: this.userInfo.userId ? this.userInfo.userId : '',
                    insUserId: this.userInfo.userId ? this.userInfo.userId : '',
                    modUserId: this.userInfo.userId ? this.userInfo.userId : '',
                },
            ]

            let saveParam = {
                basUsmHrlnkgMappMgmtVo,
            }

            API.saveHrList(saveParam).then((result) => {
                console.log('result : ', result)
                if (_.isEmpty(result)) {
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    this.onSearch()
                } else {
                    this.showTcComAlert(result.message)
                }
            })
        },

        // 초기화
        onResetPage() {
            // CommonUtil.clearPage(this.$router)
            this.gridObj.gridInit()
            this.div_search.deptCd = ''
            this.div_search.deptNm = ''
            this.div_search.aplyYn = 'N'
        },

        btnChange: function () {
            console.log('테스트')
        },

        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            var date = new Date()
            var year = date.getFullYear()
            var month = ('0' + (1 + date.getMonth())).slice(-2)
            var day = ('0' + date.getDate()).slice(-2)

            return year + '-' + month + '-' + day
        },

        // 문자열 하이픈 제거
        removeHyphen: function (val) {
            const regExp = /[^0-9]/g
            const retVal = val.replace(regExp, '')
            return retVal
        },

        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/usm/usmHrLnkgMappMgmtExcelList',
                this.div_search
            )
        },
    },
}
</script>
