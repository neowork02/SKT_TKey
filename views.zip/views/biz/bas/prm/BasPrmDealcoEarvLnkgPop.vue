<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">조직목록</p>
                <div class="layerCont">
                    <ul class="btn_area pop">
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="searchDatas"
                                :objAuth="objAuth"
                            >
                                조회
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="closeBtn"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton>
                        </li>
                    </ul>
                    <div class="contBoth">
                        <div class="searchLayer_wrap">
                            <div class="searchform">
                                <div class="formitem div3">
                                    <TCComDatePicker
                                        labelName="기준년월"
                                        calType="M"
                                        :eRequired="true"
                                        v-model="opDt"
                                    />
                                </div>
                                <div class="formitem div3">
                                    <TCComInput
                                        labelName="조직명"
                                        :appendIconShow="true"
                                        :appendIconClass="''"
                                        :codeIDView="codeIDView"
                                        :codeIDViewVal="codeIDViewVal"
                                        @onAppendIconClick="btnClick"
                                        :objAuth="objAuth"
                                        v-model="reqParam.salePlcId"
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridHeader1"
                                ref="gridHeader1"
                                gridTitle="조직목록"
                                :gridObj="gridObj"
                            />
                            <TCRealGrid
                                id="gridPop"
                                ref="gridPop"
                                :fields="gridSet.fields"
                                :columns="gridSet.columns"
                            />
                        </div>
                    </div>
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { GRID_POP } from '@/const/grid/bas/prm/basPrmDealcoEarvLnkgGrid'

export default {
    name: 'DealCoEarvLnkgPop',
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        closeDemo: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    data() {
        return {
            objAuth: {},
            codeIDView: true,
            codeIDViewVal: '',
            reqParam: {
                strdDt: '',
                endDt: '',
                chargrUserId: '',
                hdlDealCo: '',
            },
            opDt: [],
            calType5: 'DP',
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridSet: GRID_POP,
            badEquip: this.closeDemo,
            searchCode: [],
        }
    },
    created() {
        this.initParam()
        this.searchDatas()
    },
    mounted() {
        this.setGrid()
    },
    methods: {
        /* 초기화 */
        init() {
            this.initParam()
            this.gridObj.setRows({})
        },
        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                strdDt: '',
                endDt: '',
                chargrUserId: '',
                hdlDealCo: '',
                pageSize: '30',
                pageNum: '1',
            }
            this.opDt = [this.reqParam.strdDt, this.reqParam.endDt]
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.gridPop
            this.gridHeaderObj = this.$refs.gridHeader1
            this.gridObj.setGridState(true, true, true)
        },
        GridSetData() {
            return new CommonGrid(-1, -1, 10, 0, '')
        },
        /* 조회 */
        searchDatas() {
            console.log(this.reqParam)
            this.initParam()
            /*
            API.getBasPrmDealCoEarvLnkgList(this.reqParam).then((res) => {
                console.log(res)
                this.gridObj.setRows(res.gridList)
            })
             */
        },
        btnClick() {
            console.log('click')
        },
        /* 팝업 창닫기 */
        closeBtn() {
            this.activeOpen = false
        },
    },
}
</script>
