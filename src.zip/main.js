import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import vuetify from './plugins/vuetify'
import Element from 'element-ui' /* 20220215 추가*/
import VueBreadcrumbs from 'vue-2-breadcrumbs'
import VueCodemirror from 'vue-codemirror'
import './plugins/globalComponents'
import './plugins/draggableDialog'

import 'codemirror/lib/codemirror.css'
import 'codemirror/theme/3024-night.css'
import 'codemirror/mode/vue/vue.js'

//fort-awesome
import { library } from '@fortawesome/fontawesome-svg-core'
import { faUserSecret } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'

import { fas } from '@fortawesome/free-solid-svg-icons'
import { far } from '@fortawesome/free-regular-svg-icons'
import { fab } from '@fortawesome/free-brands-svg-icons'

// css style
import '@/assets/style/style.css'

library.add(faUserSecret, fas, far, fab)
Vue.component('font-awesome-icon', FontAwesomeIcon)
Vue.config.productionTip = false

Vue.use(VueBreadcrumbs, {
    template:
        '        <nav v-if="$breadcrumbs.length" aria-label="breadcrumb">\n' +
        '            <ol class="breadcrumb">\n' +
        '                <li v-for="(crumb, key) in $breadcrumbs" v-if="crumb.meta.breadcrumb" :key="key" class="breadcrumb-item active" aria-current="page">\n' +
        '                    <router-link :to="{ path: getPath(crumb) }">{{ getBreadcrumb(crumb.meta.breadcrumb) }}</router-link>' +
        '                </li>\n' +
        '            </ol>\n' +
        '        </nav>',
})

Vue.use(Element, {
    size: 'small',
    zIndex: 3000,
})

Vue.use(VueCodemirror, {
    options: {
        tabSize: 4,
        mode: 'text/x-vue',
        theme: '3024-night',
        lineNumbers: true,
        line: true,
    },
})
/*Vue.use({});*/
new Vue({
    vuetify,
    router,
    store,
    render: (h) => h(App),
}).$mount('#app')

require('../node_modules/element-ui/lib/theme-chalk/index.css') /* 20220215 추가*/
