<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="300px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">전송상태</p>

                <div class="layerCont">
                    <div class="stitHead">
                        <h4 class="subTit">전송상태변경</h4>
                    </div>
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComComboBox
                                    labelName="전송"
                                    id="comCheck1"
                                    ref="comCheck1"
                                    v-model="searchParam.sendDtCd"
                                    :itemList="[
                                        { commCdVal: 'I', commCdValNm: 'I' },
                                        { commCdVal: 'U', commCdValNm: 'U' },
                                        { commCdVal: 'D', commCdValNm: 'D' },
                                    ]"
                                ></TCComComboBox>
                            </div>
                        </div>
                    </div>

                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            @click="save"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="close"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="close"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dealcoMgmt/helpers'

import CommonMixin from '@/mixins'

export default {
    name: 'sendPopupContainer',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            objAuth: {},
            searchParam: { sendDtCd: [] },
        }
    },
    mounted() {},
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        initParam: {
            get() {
                return this.initParams
            },
        },
        zbasC00120: {
            get() {
                return this.ZBAS_C_00120 // 전자결재 진행여부
            },
        },
    },
    methods: {
        ...serviceMethods,
        save() {
            this.showTcComConfirm('선택 하시겠습니까?').then((confirm) => {
                if (confirm) {
                    this.defaultAssign_({
                        key: 'sendDtCd',
                        value: this.searchParam.sendDtCd,
                    })

                    this.close()
                } else {
                    this.close()
                }
            })
        },
        close() {
            this.activeOpen = false
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchParam.sendDtCd =
                    value['sendDtCd'] === undefined ? [] : value['sendDtCd']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
