<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccSacSaleCmmsAdpayMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <AccHeadline title="판매수수료 선지급 검증관리" />

        <AccSearchField
            ref="accSearchField"
            :offset="[
                'btn-right-reset',
                'btn-right-view',
                'btn-right-save',
                'btn-right-delete',
                'btn-right-forceAprove',
                'search-accMth',
                'search-orgCd',
                '!search-dealcoCd',
                'search-bondClCd',
                'search-expDueDt',
                '!search-verifyYn',
                '!search-expObjYn',
                'search-bond',
            ]"
            :initValue="initValue"
            :popupParamOrgCd="popupParamOrgCd"
            :popupParamDealcoCd="popupParamDealcoCd"
            @changeAccMth="changeAccMth"
            @changeOrgCd="changeOrgCd"
            @reset="resetForm"
            @view="viewForm"
            @save="saveForm"
            @delete="deleteForm"
            @forceAprove="forceAproveItem"
        />

        <AccGridTable
            ref="accGridTable"
            isEditable
            isCheckbox
            isColumnNo
            noPaging
            :offset="['btn-excelDownload']"
            :gridMeta="GRID_HEADER"
            :data="formAccSacSaleCmmsAdpayVrfList.data"
            :pagingInfo="formAccSacSaleCmmsAdpayVrfList.pagingInfo"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/sac/accs-verify-excel-download`,
                query: formAccSacSaleCmmsAdpayVrfList.query,
            }"
            @movePage="movePage"
            @changePageSize="changePageSize"
        />
    </div>
</template>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import {
    getTodayDate,
    getCalcDays,
    distanceDate,
    errorHandle,
} from '@/utils/accUtil'

import AccHeadline from '@/components/biz/common/acc/AccHeadline'
import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import sacApi from '@/api/biz/acc/sac'

import {
    GRID_HEADER,
    MOCK_DATA,
} from '@/const/grid/acc/sac/accSacSaleCmmsAdpayVrfMgmtGrid'

export default {
    name: 'AccSacSaleCmmsAdpayVrfMgmt',
    mixins: [CommonMixin, accMixin],
    components: {
        AccHeadline,
        AccSearchField,
        AccGridTable,
    },
    data() {
        const dateFormat = 'YYYY-MM-DD'

        return {
            GRID_HEADER,
            initValue: {
                accMth: getTodayDate('YYYY-MM'),
                bondClCd: '1',
                verifyYn: '0',
                expObjYn: '0',
                expDueDt: getTodayDate('YYYYMMDD'),
                bond: [
                    // getTodayDate(dateFormat),
                    getCalcDays(
                        'today',
                        { count: -1, per: 'months' },
                        dateFormat
                    ),
                    getCalcDays(
                        'today',
                        { count: -1, per: 'days' },
                        dateFormat
                    ),
                ],
                pageSize: 15,
                pageNum: 1,
            },

            formAccSacSaleCmmsAdpayVrfList: {
                data: [],
                query: {},
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formAccSacSaleCmmsAdpayVrfSave: {
                query: {},
            },

            formAccSacSaleCmmsAdpayVrfDelete: {
                query: {},
            },

            popupParamOrgCd: {
                basMth: '',
            },

            popupParamDealcoCd: {
                orgNm: '', // 조직이름
                orgCd: '', // 조직코드
                basDay: '', // 기준년월
                dealcoGrpCd: '', // 거래처구분코드
                dealcoClCd1: '', // 거래처구분코드
            },
        }
    },
    computed: {
        getCheckedRow() {
            return this.$refs.accGridTable.getCheckedRow
        },
    },
    created() {
        this.initPage()
        console.log(sacApi, MOCK_DATA)
    },
    methods: {
        initPage() {
            //@TODO 권한이 정리된 후, 사용자에 따라 권한설정. CRUD
            // 권한 설정
            // cf_setAuth('rud')
            // div_search.cal_AccMth.Value = SubStr(Today(), 0, 6)
            // //조직, 거래처 바인딩
            // cf_setPopupDataBindingEvent(
            //     div_search.cdiv_deal_1S,
            //     ds_condition,
            //     'DEAL_CO_CD'
            // )
            // cf_setPopupDataBindingEvent(
            //     div_search.cdiv_authOrg_1S,
            //     ds_condition,
            //     'ORG_ID',
            //     '',
            //     'ORG_LEVEL'
            // )
            // div_search.cdiv_authOrg_1S.edt_authOrgCd.value =
            //     gds_session.GetColumn(0, 'newOrgId')
            // div_search.cdiv_authOrg_1S.edt_authOrgNm.value =
            //     gds_session.GetColumn(0, 'newOrgNm')
            // div_search.cdiv_authOrg_1S.edt_authOrgLvl.value =
            //     gds_session.GetColumn(0, 'newOrgLevel')
            // //    채권상계구분코드 초기값
            // div_search.cmb_BondClCd.index = 0
            // div_search.cal_BondFromDt.Value =
            //     substr(AddMonth(today(), -1), 0, 6) + '21'
            // div_search.cal_BondToDt.Value = AddDate(today(), -1)
            // //    저장, 삭제, 강제승인버튼 Disable
            // div_commonButton.btn_save.Enable = false
            // div_commonButton.btn_delete.Enable = false
            // btn_Force_Aprv.Enable = false
            // //    검증상태, 지출대상여부 초기값
            // div_search.cmb_verify.Index = 0
            // div_search.cmb_expobj.Index = 0
        },

        resetForm(query) {
            this.formAccSacSaleCmmsAdpayVrfList.query = query
            this.formAccSacSaleCmmsAdpayVrfList.data = []
        },

        deleteForm() {
            const rows = this.getCheckedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                const invalidList = []

                rows.forEach((row) => {
                    if (row.verifyYn == 'N') {
                        invalidList.push({
                            msg: `${row.dealCoNm}거래처는 미검증상태입니다.\n검증상태의 거래처만 삭제가능합니다.`,
                            list: row,
                        })
                    }
                })

                if (invalidList.length) {
                    return invalidList.forEach((arr) =>
                        this.showTcComAlert(arr.msg)
                    )
                }

                rows.forEach((arr) => {
                    arr.__rowState = 'deleted'
                })

                this.formAccSacSaleCmmsAdpayVrfDelete.query.adpayMgmtVrfVoList =
                    rows
                return this.deleteAccSacSaleCmmsAdpayVrfList().then(
                    this.getAccSacSaleCmmsAdpayVrfList
                )
            }
        },

        viewForm(query) {
            if (!query.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }

            if (!query.expDueDt) {
                return this.showTcComAlert('지출예정일을 선택해 주세요.')
            }

            if (!query.bondToDt) {
                return this.showTcComAlert('채권상계기간을 입력하십시요.')
            }

            if (!query.bondFromDt) {
                return this.showTcComAlert('채권상계기간을 입력하십시요.')
            }

            if (distanceDate(query.expDueDt, getTodayDate().date) < 0) {
                return this.showTcComAlert(`지출예정일이 현재일 이전입니다.`)
            }

            if (distanceDate(query.bondToDt, query.bondFromDt) > 0) {
                return this.showTcComAlert(
                    `채권상계기간 시작일자가 종료일자보다 큽니다.`
                )
            }

            Object.assign(this.formAccSacSaleCmmsAdpayVrfList.query, query)
            return this.getAccSacSaleCmmsAdpayVrfList()
        },

        saveForm() {
            const rows = this.getCheckedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                this.formAccSacSaleCmmsAdpayVrfSave.query.adpayMgmtVrfVoList =
                    rows

                return this.postAccSacSaleCmmsAdpayVrfList()
            }
        },

        forceAproveItem() {
            const rows = this.getCheckedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                const invalidList = []
                rows.forEach((row) => {
                    if (
                        row.verifyYn == '미검증' ||
                        row.expObjYn == 'Y' ||
                        row.forceAprvYn == 'Y'
                    ) {
                        invalidList.push({
                            msg: `강제승인은 검증상태이거나 지출대상이 아니거나\n강제승인이 아닐 경우 가능합니다.(${row.dealCoNm})`,
                            list: row,
                        })
                    }
                })

                if (invalidList.length) {
                    return invalidList.forEach((arr) =>
                        this.showTcComAlert(arr.msg)
                    )
                }

                rows.forEach((arr) => {
                    arr.forceAprvYn = 'Y'
                })

                this.formAccSacSaleCmmsAdpayVrfSave.query.adpayMgmtVrfVoList =
                    rows
                return this.postAccSacSaleCmmsAdpayVrfList()
            }
        },

        movePage(query) {
            Object.assign(this.formAccSacSaleCmmsAdpayVrfList.query, query)
            this.getAccSacSaleCmmsAdpayVrfList()
        },

        changePageSize(query) {
            this.accSearchField.setQuery(query)
            // Object.assign(this.formAccSacSaleCmmsAdpayVrfList.query, query)
        },

        changeAccMth(date) {
            this.popupParamOrgCd.basMth = date
            this.popupParamDealcoCd.basDay = date
        },

        changeOrgCd(query) {
            const { orgCd, orgNm, orgLvl } = query

            this.popupParamDealcoCd.orgLvl = orgLvl
            this.popupParamDealcoCd.orgCd = orgCd
            this.popupParamDealcoCd.orgNm = orgNm

            this.popupParamOrgCd.orgCd = orgCd
            this.popupParamOrgCd.orgNm = orgNm
        },

        getAccSacSaleCmmsAdpayVrfList() {
            // this.formAccSacSaleCmmsAdpayVrfList.data = [
            //     ...MOCK_DATA['adpayMgmtVrfVoPagingList'].gridList,
            // ]
            // this.formAccSacSaleCmmsAdpayVrfList.pagingInfo =
            //     MOCK_DATA['adpayMgmtVrfVoPagingList'].pagingDto
            // return Promise.resolve()

            if (this.formAccSacSaleCmmsAdpayVrfList.query.bondDate)
                delete this.formAccSacSaleCmmsAdpayVrfList.query.bondDate

            return sacApi
                .getAccSacSaleCmmsAdpayVrfList(
                    this.formAccSacSaleCmmsAdpayVrfList.query
                )
                .then((res) => {
                    this.formAccSacSaleCmmsAdpayVrfList.data = [...res]
                })
                .catch(errorHandle)
        },

        postAccSacSaleCmmsAdpayVrfList() {
            return sacApi
                .postAccSacSaleCmmsAdpayVrfList(
                    this.formAccSacSaleCmmsAdpayVrfSave.query
                )
                .then((res) => {
                    console.log(this.formAccSacSaleCmmsAdpayVrfSave.query)
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                    this.getAccSacSaleCmmsAdpayVrfList()
                })
                .catch(errorHandle)
        },

        deleteAccSacSaleCmmsAdpayVrfList() {
            return sacApi
                .deleteAccSacSaleCmmsAdpayVrfList(
                    this.formAccSacSaleCmmsAdpayVrfDelete.query
                )
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                    this.getAccSacSaleCmmsAdpayVrfList()
                })
                .catch(errorHandle)
        },
    },
}
</script>
