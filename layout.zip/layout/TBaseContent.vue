<script>
export default {
    components: {},
}
</script>

<template>
    <div class="contentWrap">
        <router-view></router-view>
    </div>
</template>
<style></style>
