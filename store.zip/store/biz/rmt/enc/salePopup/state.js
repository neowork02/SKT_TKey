export default {
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 15,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 15, //전체 조회:9999
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    saveAction: false,
    saveDoneA: false,
    saveDoneB: false,

    resultList: '',
    resultListSvcNum: '',
    resultListPcode: '',

    searchParams: {},
    popupParams: {},

    popupRtData: '',
    popupConfirm: false,
    popupClose: false,
}
