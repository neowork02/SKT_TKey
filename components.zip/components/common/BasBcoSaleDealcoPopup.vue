<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1100px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">매장 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="searchForm.orgNm"
                                    :codeVal.sync="searchForm.orgCd"
                                    labelName="조직"
                                    placeholder="입력하세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    :disabled="isDisabledOrgCd"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :eRequired="true"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchPopParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    v-model="searchForm.dealCoClCd1"
                                    codeId="ZBAS_C_00240"
                                    labelName="매장구분"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3"></div>

                            <!-- // item 1-2 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchForm.dealcoCd"
                                    labelName="매장코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div3">
                                <TCComInput
                                    v-model="searchForm.dealcoNm"
                                    labelName="매장명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>

                            <!-- //item 2-2 -->
                            <!-- item 2-5 -->
                            <div class="formitem div3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-5 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <div class="gridWrap">
                        <TCRealGrid
                            id="basBcoGrid"
                            ref="basBcoGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { BAS_BCO_SALE_DEALCO_HEADER } from '@/const/grid/bas/bco/basBcoSaleDealcoHeader'
import basBcoSaleDealcoApi from '@/api/biz/bas/bco/basBcoSaleDealcoPop'
import commonApi from '@/api/common/commonCode'
import CommonMixin from '@/mixins'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
import _ from 'lodash'
export default {
    name: 'basBcoUserPopup',
    mixins: [CommonMixin],
    components: { BasBcoAuthOrgTreesPopup },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchPopParam: {
                basMth: '',
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                vLevel: '', // 디스플레이제한레벨
                sLvlList: '', //선택가능레벨 '2,3' : as-is 와동일하게 쉼표로 나열
                all: 'Y', //전체검색여부 Y or null , N..
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //Paging Class init
            gridData: this.gridSetData(),
            //showAlertBool: false,
            headerText: '',
            //alertBodyText: '',
            objAuth: {},
            view: BAS_BCO_SALE_DEALCO_HEADER,
            content: '',
            gridObj: {},
            gridHeaderObj: {},
            activePage: 1, // 현재페이지
            searchForm: {
                orgCd: '', // 조직코드
                orgNm: '', // 조직코드
                orgLvl: '',
                dealCoClCd1: '',
                dealCoCd: '',
                dealCoNm: '',
            },
            showAgencyPopup: false,
            isDisabledOrgCd: false,
        }
    },
    created() {
        this.init()
    },
    async mounted() {
        console.log('mounted')
        /****************** Grid **********************/
        this.gridObj = this.$refs.basBcoGrid
        this.gridHeaderObj = this.$refs.basBcoSaleDealcoGrid
        this.initGrid()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('### watch parentParam')
                this.searchForm.orgLvl =
                    value['orgLvl'] == undefined ? '' : value['orgLvl'] //조직레벨
                this.searchForm.orgCd =
                    value['orgCd'] == undefined ? '' : value['orgCd'] //조직코드
                this.searchForm.orgNm =
                    value['orgNm'] == undefined ? '' : value['orgNm'] //조직명
                this.searchForm.dealCoClCd1 =
                    value['dealCoClCd1'] == undefined
                        ? ''
                        : value['dealCoClCd1'] //매장구분
                this.searchForm.dealcoCd =
                    value['dealcoCd'] == undefined ? '' : value['dealcoCd'] //매장코드
                this.searchForm.dealcoNm =
                    value['dealcoNm'] == undefined ? '' : value['dealcoNm'] //매장명
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        init() {
            if (this.rows.length > 0) {
                var iOrgLvl = this.searchForm.orgLvl
                if (typeof this.searchForm.orgLvl == 'number') {
                    iOrgLvl = Number(typeof this.searchForm.orgLvl)
                }

                if (iOrgLvl >= 2) {
                    if (!_.isEmpty(this.searchForm.orgCd)) {
                        this.isDisabledOrgCd = true
                    }
                }
            }
        },
        //GridSetData
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            //return new CommonGrid(-1, -1, 10, 0, '')
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        async initGrid() {
            this.gridObj.gridView.displayOptions.fitStyle = 'even'

            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false)
            const commDealClCd1 = await this.getCommCodeList('ZBAS_C_00240')

            // 사용자 구분
            this.gridObj.gridView.columnByName('dealCoClCd1').values =
                CommonUtil.convListToGridLovValues(commDealClCd1, 'commCdVal')
            this.gridObj.gridView.columnByName('dealCoClCd1').labels =
                CommonUtil.convListToGridLovLabels(commDealClCd1, 'commCdValNm')

            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },
        getWorkPlaceList() {
            if (_.isEmpty(this.searchForm.orgCd)) {
                this.showTcComAlert('조직을 선택해주세요.', {
                    //header: '내부거래처',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }

            basBcoSaleDealcoApi
                .getWorkPlaceList(this.searchForm)
                .then((res) => {
                    console.log('getWorkPlaceList : ', res)
                    console.log('res ', res)
                    this.gridObj.setRows(res)
                })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('매장을 선택해주세요.', {
                    header: '매장',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        onSearch() {
            this.getWorkPlaceList()
        },

        onEnterKey() {
            this.onSearch()
        },
        // 조직 공통 팝업 이벤트
        onOrgNmEnterKey() {
            if (!_.isEmpty(this.searchForm.orgNm)) {
                //this.getAgencyList()
            } else {
                this.showAgencyPopup = true
            }
        },
        /*
        onInput() {},
        onOrgNmIconClick() {},
        */
        //---// 조직 공통 팝업 이벤트
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchPopParam.orgNm = this.searchForm.orgNm
            //기준년월에 따라 조직파라미터변경
            this.searchPopParam.basMth = CommonUtil.replaceDash(
                this.searchPopParam.basDayTemp
            )
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchPopParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchForm.basMth = _.get(res[0], 'basMth')
                        this.searchForm.orgCd = _.get(res[0], 'orgCd')
                        this.searchForm.orgNm = _.get(res[0], 'orgNm')
                        this.searchForm.vLevel = _.get(res[0], 'vLevel')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchForm.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈

            if (_.isEmpty(this.searchForm.orgNm)) {
                this.showTcComAlert('조직을 선택해주세요.', {
                    //header: '내부거래처',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchPopParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchForm.orgCd = _.get(retrunData, 'orgCd')
            this.searchForm.orgNm = _.get(retrunData, 'orgNm')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //---// 조직 공통 팝업 이벤트
    },
}
</script>
