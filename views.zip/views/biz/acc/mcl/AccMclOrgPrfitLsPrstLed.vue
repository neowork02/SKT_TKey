<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccMclOrgPrfitLsPrstLed.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <AccHeadline title="조직별손익현황&lt;원장기준&gt;" />

        <AccSearchField
            ref="accSearchField"
            :offset="[
                'btn-right-reset',
                'btn-right-view',
                'search-clsMth',
                'search-aplyDt',
                '!search-salePlc',
                { slotSearch: 'search-zeroView' },
                'search-searchDtmTo',
                '!search-orgCd',
                '!search-accPlc',
            ]"
            :initValue="initValue"
            :popupParamOrgCd="popupParamOrgCd"
            @reset="resetForm"
            @view="viewForm"
            @changeClsmth="changeClsmth"
            @changeAplyDt="changeAplyDt"
        >
            <template slot="search-zeroView" slot-scope="slotProps">
                <div
                    class="formitem"
                    :class="`div${slotProps.divideCellCount}`"
                >
                    <TCComCheckBox
                        itemText="label"
                        itemValue="value"
                        label="0 제외"
                        :itemList="[
                            {
                                label: '0 제외',
                                value: '1',
                            },
                        ]"
                        v-model="zeroViewCheck"
                    />
                </div>
            </template>
        </AccSearchField>

        <AccGridTable
            ref="accGridTable"
            title="조직별손익현황"
            class="accGridTable"
            isFooter
            noPaging
            :offset="['btn-excelDownload']"
            :gridMeta="GRID_HEADER"
            :data="formGetProfitLossBydept.data"
            :pagingInfo="formGetProfitLossBydept.pagingInfo"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/mcl/profit-loss-bydept-excel-download`,
                query: formGetProfitLossBydept.query,
            }"
            @movePage="movePage"
            @changePageSize="changePageSize"
            @dblClickCell="dblClickCell"
        />
        <AccMclOrgPrfitLsPrstLedAr
            v-if="showOrgPrfitLsPrstLedAr"
            :parentParam="ldgrPopupParam"
            :dialogShow.sync="showOrgPrfitLsPrstLedAr"
        />
        <AccMclOrgPrfitLsPrstLedAp
            v-if="showOrgPrfitLsPrstLedAp"
            :parentParam="ldgrPopupParam"
            :dialogShow.sync="showOrgPrfitLsPrstLedAp"
        />
    </div>
</template>
<style scoped>
:deep(.accGridTable) .rg-body .rg-table tr td.emphasis,
:deep(.accGridTable) .rg-fixed-body .rg-table tr td.emphasis {
    color: black;
    background: skyblue;
    font-weight: bold;
}
</style>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import { getTodayDate, getCalcDays, errorHandle } from '@/utils/accUtil'

import AccHeadline from '@/components/biz/common/acc/AccHeadline'
import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import AccMclOrgPrfitLsPrstLedAr from '@/views/biz/acc/mcl/AccMclOrgPrfitLsPrstLedAr' //매출원장팝업
import AccMclOrgPrfitLsPrstLedAp from '@/views/biz/acc/mcl/AccMclOrgPrfitLsPrstLedAp' //매입원장팝업
import mclApi from '@/api/biz/acc/mcl'

import {
    GRID_HEADER,
    MOCK_DATA,
} from '@/const/grid/acc/mcl/AccMclOrgPrfitLsPrstLedGrid'

export default {
    name: 'AccMclOrgPrfitLsPrstLed',
    mixins: [CommonMixin, accMixin],
    components: {
        AccHeadline,
        AccSearchField,
        AccGridTable,
        AccMclOrgPrfitLsPrstLedAr,
        AccMclOrgPrfitLsPrstLedAp,
    },
    data() {
        return {
            GRID_HEADER,
            initValue: {
                clsMth: getTodayDate('YYYY-MM'),
                mccGb: 'CST',
                aplyDt: [
                    getCalcDays(
                        'firstday',
                        { target: getTodayDate() },
                        'YYYY-MM-DD'
                    ),
                    getCalcDays(
                        'lastday',
                        { target: getTodayDate() },
                        'YYYY-MM-DD'
                    ),
                ],
                searchDtmTo: getTodayDate('YYYY-MM-DD'),
            },

            popupParamOrgCd: {
                basMth: '',
            },

            formGetProfitLossBydept: {
                data: [],
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                pagingInfo: {
                    pageSize: 15,
                },
            },
            ldgrPopupParam: {},
            zeroViewCheck: [],
            showOrgPrfitLsPrstLedAr: false,
            showOrgPrfitLsPrstLedAp: false,
        }
    },

    computed: {},

    created() {
        this.initPage()
        console.log(mclApi, MOCK_DATA)
    },

    mounted() {},
    methods: {
        initPage() {},

        resetForm(query) {
            this.formGetProfitLossBydept.query = query
            this.formGetProfitLossBydept.data = []

            this.changeAplyDt(this.initValue.aplyDt)
            this.changeClsmth(this.initValue.clsMth)
            this.changeOrgCd({ orgCd: '', orgNm: '', orgLvl: '' })
        },

        viewForm(query) {
            Object.assign(this.formGetProfitLossBydept.query, query)

            if (this.zeroViewCheck) {
                this.formGetProfitLossBydept.query.zeroView =
                    this.zeroViewCheck[0]
            }

            return this.getProfitLossBydept()
        },

        movePage(query) {
            Object.assign(this.formGetProfitLossBydept.query, query)
            return this.getProfitLossBydept()
        },

        changePageSize(query) {
            this.accSearchField.setQuery(query)
            // Object.assign(this.formGetProfitLossBydept.query, query)
        },

        changeAplyDt(date) {
            this.formGetProfitLossBydept.query.frDt = date[0]
            this.formGetProfitLossBydept.query.toDt = date[1]
        },

        changeClsmth(date) {
            this.popupParamOrgCd.basMth = date

            this.accSearchField.setQuery({
                aplyDt: [
                    getCalcDays('firstday', { target: date }, 'YYYY-MM-DD'),
                    getCalcDays('lastday', { target: date }, 'YYYY-MM-DD'),
                ],
            })
        },

        changeOrgCd(query) {
            const { orgCd, orgNm } = query

            this.popupParamOrgCd.orgCd = orgCd
            this.popupParamOrgCd.orgNm = orgNm
        },

        // dblClickCell(row) {
        dblClickCell(row, rowIdx, rowInfo) {
            console.log('row:::::', row, rowIdx, rowInfo)

            this.ldgrPopupParam.searchGubun = '2' //  전기일
            this.ldgrPopupParam.searchDtFrom =
                this.formGetProfitLossBydept.query.frDt
            this.ldgrPopupParam.searchDtTo =
                this.formGetProfitLossBydept.query.toDt
            this.ldgrPopupParam.prchsDealcoCd =
                this.formGetProfitLossBydept.query.salePlc === undefined
                    ? ''
                    : this.formGetProfitLossBydept.query.salePlc
            this.ldgrPopupParam.saleDealcoCd =
                this.formGetProfitLossBydept.query.salePlc === undefined
                    ? ''
                    : this.formGetProfitLossBydept.query.salePlc
            this.ldgrPopupParam.accDealcoCd =
                this.formGetProfitLossBydept.query.accPlc === undefined
                    ? ''
                    : this.formGetProfitLossBydept.query.accPlc
            this.ldgrPopupParam.orgCd =
                this.formGetProfitLossBydept.query.orgCd === undefined
                    ? ''
                    : this.formGetProfitLossBydept.query.orgCd
            this.ldgrPopupParam.orgNm =
                this.formGetProfitLossBydept.query.orgNm === undefined
                    ? ''
                    : this.formGetProfitLossBydept.query.orgNm
            this.ldgrPopupParam.orgLvl =
                this.formGetProfitLossBydept.query.orgLvl === undefined
                    ? ''
                    : this.formGetProfitLossBydept.query.orgLvl
            this.ldgrPopupParam.searchDtTo =
                this.formGetProfitLossBydept.query.toDt

            this.ldgrPopupParam.prchsClCd = row.arClCd
            this.ldgrPopupParam.arClCd = row.arClCd

            this.ldgrPopupParam.inClCd = ''
            this.ldgrPopupParam.saleClCd = ''

            if (row.clNm == '영업비용') {
                if (row.arClNm != '소계' && row.arClNm.length > 0) {
                    if (rowInfo.fieldIndex >= 6 && rowInfo.fieldIndex <= 8) {
                        //  추정값컬럼(공급가, 부가세, 계) 더블클릭
                        this.ldgrPopupParam.inClCd = 'PSG'
                    } else if (
                        rowInfo.fieldIndex >= 12 &&
                        rowInfo.fieldIndex <= 14
                    ) {
                        //  확정값컬럼(공급가, 부가세, 계) 더블클릭
                        this.ldgrPopupParam.inClCd = 'PSC'
                    }

                    if (row.arClCd == 'LEND') {
                        this.ldgrPopupParam.inClCd = 'LND'
                    }

                    if (row.arClCd == 'SLF1' || row.arClCd == 'SLF2') {
                        this.ldgrPopupParam.inClCd = 'OST'
                    }

                    //  매입원장 팝업 오픈
                    this.showOrgPrfitLsPrstLedAp = true
                }
            } else {
                if (row.arClNm != '소계' && row.arClNm.length > 0) {
                    if (rowInfo.fieldIndex >= 6 && rowInfo.fieldIndex <= 8) {
                        //  추정값컬럼(공급가, 부가세, 계) 더블클릭
                        this.ldgrPopupParam.saleClCd = 'EST'
                    } else if (
                        rowInfo.fieldIndex >= 12 &&
                        rowInfo.fieldIndex <= 14
                    ) {
                        //  확정값컬럼(공급가, 부가세, 계) 더블클릭
                        this.ldgrPopupParam.saleClCd = 'ACC'
                    }

                    if (
                        row.arClCd == 'SIMF' ||
                        row.arClCd == 'FEES' ||
                        row.arClCd == 'APAY'
                    ) {
                        this.ldgrPopupParam.saleClCd = 'NOT'
                    }

                    if (row.arClCd == 'EMPT' || row.arClCd == 'SIME') {
                        this.ldgrPopupParam.saleClCd = 'DSL'
                    }

                    if (row.arClCd == 'NCSH' || row.arClCd == 'PAMT') {
                        this.ldgrPopupParam.saleClCd = 'EXP'
                    }

                    if (
                        row.arClCd == 'DIF1' ||
                        row.arClCd == 'DIF2' ||
                        row.arClCd == 'DIF3' ||
                        row.arClCd == 'DIF4'
                    ) {
                        this.ldgrPopupParam.saleClCd = 'ADJ'
                    }

                    //  매출원장 팝업 오픈
                    this.showOrgPrfitLsPrstLedAr = true
                }
            }
        },

        getProfitLossBydept() {
            console.log('요청쿼리 =>', this.formGetProfitLossBydept.query)
            const setGridFooter = (data) => {
                this.gridView.setFooters([
                    {
                        styleName: 'footer1',
                    },
                    {
                        styleName: 'footer2',
                    },
                    {
                        styleName: 'footer3',
                    },
                ])

                this.accGridTable.getColumn('clNm').setFooters([
                    {
                        text: '매출총이익 ⑨',
                    },
                    {
                        text: '시장운영손익1 ⑪',
                    },
                    {
                        text: '시장운영손익2 ⑫',
                    },
                ])

                this.accGridTable.getColumn('plClNm').setFooters([
                    {
                        text: '= ⑦ - ① - ⑧',
                    },
                    {
                        text: '= ⑨ - ⑩',
                    },
                    {
                        text: '= ⑪ - ①',
                    },
                ])

                let columns = [
                    'estNetAmt',
                    'estVatAmt',
                    'estSumAmt',
                    'erpEstNetAmt',
                    'erpEstVatAmt',
                    'erpEstSumAmt',
                    'accNetAmt',
                    'accVatAmt',
                    'accSumAmt',
                    'erpAccNetAmt',
                    'erpAccVatAmt',
                    'erpAccSumAmt',
                ]

                columns.forEach((arr) => {
                    // 위탁수수료의 합
                    let group1 = data
                        .filter((field) => field.plClNm == '위탁수수료 ①')
                        .reduce(
                            (acc, field) => (acc += parseInt(field[arr], 10)),
                            0
                        )

                    // 총매출액의 합
                    let group7 = data
                        .filter((field) => field.clNm == '총매출액')
                        .reduce(
                            (acc, field) => (acc += parseInt(field[arr], 10)),
                            0
                        )

                    // 매출원가의 합
                    let group8 = data
                        .filter((field) => field.clNm == '매출원가')
                        .reduce(
                            (acc, field) => (acc += parseInt(field[arr], 10)),
                            0
                        )

                    // 영업비용의 합
                    let group10 = data
                        .filter((field) => field.clNm == '영업비용')
                        .reduce(
                            (acc, field) => (acc += parseInt(field[arr], 10)),
                            0
                        )

                    // 매출총이익
                    let group9 = group7 - group1 - group8

                    // 시장운영손익1
                    let group11 = group9 - group10

                    // 시장운영손익2
                    let group12 = group11 - group1

                    this.accGridTable.getColumn(arr).setFooters([
                        {
                            numberFormat: '#,###,###,###',
                            valueCallback: () => group9,
                        },
                        {
                            numberFormat: '#,###,###,###',
                            valueCallback: () => group11,
                        },
                        {
                            numberFormat: '#,###,###,###',
                            valueCallback: () => group12,
                        },
                    ])
                })
            }

            // const data = [...MOCK_DATA.resultGridDto.gridList]
            // this.formGetProfitLossBydept.data = data
            // this.formGetProfitLossBydept.pagingInfo =
            //     MOCK_DATA.resultGridDto.pagingDto

            // this.gridView.groupBy(['clNm', 'plClNm'], false)
            // this.gridView.setRowGroup({
            //     footerStatement: 'SUM(${groupValue})',
            // })
            // setGridFooter(data)

            // return Promise.resolve(MOCK_DATA)

            return mclApi
                .getProfitLossBydept(this.formGetProfitLossBydept.query)
                .then((res) => {
                    if (res) {
                        const data = [...res]
                        this.formGetProfitLossBydept.data = data

                        this.gridView.groupBy(['clNm', 'plClNm'], false)
                        this.gridView.setRowGroup({
                            footerStatement: 'SUM(${groupValue})',
                        })
                        setGridFooter(data)
                    }

                    return res
                })
                .catch(errorHandle)
        },
    },
}
</script>
