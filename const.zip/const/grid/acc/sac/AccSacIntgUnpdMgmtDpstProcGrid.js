import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'dpstDt',
            dataType: ValueType.TEXT,
            Text: 'yyyyMMdd',
        },

        {
            fieldName: 'dpstAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'dpstDt',
            fieldName: 'dpstDt',
            type: 'data',
            width: '150',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: { text: '입금일자' },
            editor: {
                type: 'date',
                datetimeFormat: 'yyyy-MM-dd',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'dpstAmt',
            fieldName: 'dpstAmt',
            type: 'data',
            header: { text: '금액' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '150',
            header: { text: '비고' },
        },
    ],
}
