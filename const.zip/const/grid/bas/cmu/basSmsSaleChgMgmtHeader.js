import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsSaleYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsAllotAddYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsAllotCnclYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsSuplYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            editable: false,
            header: {
                text: '조직',
            },
            width: '400',
            // styleName: 'left-column',
        },
        {
            name: 'mblPhonNo1',
            fieldName: 'mblPhonNo1',
            header: {
                text: '권한',
            },
        },
        {
            name: 'mblPhonNo2',
            fieldName: 'mblPhonNo2',
            header: {
                text: '사용자',
            },
        },
        {
            name: 'smsYn',
            fieldName: 'smsYn',
            header: {
                text: '전체',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'smsSaleYn',
            fieldName: 'smsSaleYn',
            header: {
                text: '판매',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'smsAllotAddYn',
            fieldName: 'smsAllotAddYn',
            header: {
                text: '할부추가',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'smsAllotCnclYn',
            fieldName: 'smsAllotCnclYn',
            header: {
                text: '할부취소',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
        {
            name: 'smsSuplYn',
            fieldName: 'smsSuplYn',
            header: {
                text: '부가상품',
            },
            editable: false,
            renderer: {
                type: 'check',
                shape: 'box',
                editable: true,
                startEditOnClick: true,
                trueValues: '1',
                falseValues: 'N',
            },
        },
    ],
}

export const P_HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mblPhonNo1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            editable: false,
            header: {
                text: '조직',
            },
            width: '400',
            // styleName: 'left-column',
        },
        {
            name: 'mblPhonNo1',
            fieldName: 'mblPhonNo1',
            header: {
                text: '권한',
            },
            editable: false,
        },
        {
            name: 'mblPhonNo2',
            fieldName: 'mblPhonNo2',
            header: {
                text: '사용자명',
            },
            editable: false,
        },
        {
            name: 'smsYn',
            fieldName: 'smsYn',
            header: {
                text: '대표전화번호2',
            },
            editable: false,
        },
    ],
}
