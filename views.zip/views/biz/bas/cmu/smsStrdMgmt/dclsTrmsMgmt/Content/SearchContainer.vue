<template>
    <div>
        <ul class="btn_area top">
            <!-- <li class="left">
                <v-btn outlined class="btn_ty">삭제</v-btn>
            </li> -->
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComDatePicker
                        v-model="clsDt"
                        :calType="calType5"
                        labelName="전송일자"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div3">
                    <!-- <TCComComboBox
                        labelName="대리점유형"
                        v-model="formSearchParams.agencyTypCd"
                        :objAuth="objAuth"
                        @change="selectChange"
                        codeId="AGENCY_TYP"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox> -->
                    <TCComInputSearchText
                        labelName="소속조직"
                        :appendIconClass="''"
                        @appendIconClick="searchCommon('org')"
                        :objAuth="this.objAuth"
                        v-model="formSearchParams.orgNm"
                        :codeVal.sync="formSearchParams.orgCd"
                        :disabledAfter="true"
                        @input="onAuthOrgTreeInput"
                    />
                </div>
                <div class="formitem div3">
                    <!-- 
                    <TCComInputSearchText
                        labelName="대리점"
                        :appendIconClass="''"
                        @appendIconClick="searchCommon('agency')"
                        :objAuth="this.objAuth"
                        v-model="agencyNm"
                        :codeVal="formSearchParams.agencyCd"
                        :disabledAfter="true"
                    /> -->
                    <!-- 숫자 입력
                    <TCComInput
                        v-model="formSearchParams.userNm"
                        labelName="채번"
                        :size="150"
                        :maxlength="100"
                        :objAuth="this.objAuth"
                        inputRuleType="N"
                        @input="inputEvent()"
                    /> -->
                    <TCComInput
                        v-model="formSearchParams.userNm"
                        labelName="조직장"
                        :size="150"
                        :maxlength="100"
                        :objAuth="this.objAuth"
                        @input="inputEvent()"
                        @enterKey="searchBtn"
                    />
                </div>
            </div>
        </div>
        <BasBcoAuthOrgTreesPopup
            v-if="showBcoAuthOrgTrees"
            :parentParam="popupParam"
            :rows="resultAuthOrgTreeRows"
            :dialogShow.sync="showBcoAuthOrgTrees"
            @confirm="onAuthOrgTreeReturnData"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/cmu/smsStrdMgmt/dclsTrmsMgmt/helpers'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
//import CommonUtil from '@/utils/CommonUtil.js'
import { msgTxt } from '@/const/msg.Properties.js'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
//====================//내부조직팝업(권한)팝업====================

export default {
    components: {
        //TCComComboBox,
        BasBcoAuthOrgTreesPopup,
    },
    async created() {
        await this.initControls()
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            calType5: 'D', //'M'
            clsDt: '',
            //agencyNm: '',
            formSearchParams: {
                clsDt: '', //조회년월
                //agencyTypCd: '', //대리점유형
                //agencyCd: '', //대리점코드
                orgCd: '', //조직아이디
                orgNm: '', //조직명
                userNm: '', //조직장
            },
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            popupParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
        }
    },
    async mounted() {
        //화면초기 로딩시 바로 검색
        // this.searchBtn()
    },
    computed: {
        ...serviceComputed,
        commCdIds1: {
            get() {
                return this.commCdIds
            },
            //set(value) {},
        },
        saveDone1: {
            get() {
                return this.saveDoneA && this.saveDoneB
            },
            //set(value) {},
        },
    },
    methods: {
        ...serviceMethods,
        async initControls() {
            //await this.commonCodes_({ option: '전체' })
            //this.defaultAssign_({ key: 'plantCd', value: this.user.plantCd }); //watch call searchList()
        },
        async initData() {
            let today = moment(new Date()).format('YYYY-MM-01')
            this.clsDt = today
            this.formSearchParams.clsDt = moment(new Date()).format('YYYYMMDD') //조회년월
            //this.agencyNm = '' //대리점명
            //this.formSearchParams.agencyCd = '' //대리점코드
            //this.formSearchParams.agencyTypCd = ''

            this.formSearchParams.orgCd = ''
            this.formSearchParams.orgNm = ''
            this.formSearchParams.userNm = ''
            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })
        },
        selectChange(val) {
            console.log('🚀 ~ file: selectChange ~ line 58 ~ selectChange', val)
        },
        searchCommon(flag) {
            // TODO 공통팝업 호출
            if (flag === 'mfact') {
                alert('제조사')
            } else if (flag === 'org') {
                //alert('조직')
                if (this.formSearchParams.orgNm == '') {
                    this.formSearchParams.orgId = ''
                }
                this.resultAuthOrgTreeRows = []
                this.showBcoAuthOrgTrees = true
            } else if (flag === 'prod') {
                alert('모델')
            } else if (flag === 'outPlc') {
                alert('보유처')
            }
        },
        async initBtn() {
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 122 ~ data ',
                this.$data
            )
            await this.initData()
            // this.searchBtn() //이화면은 초기화가 다시 조회처리

            //CommonUtil.clearPage(this.$router)
        },
        async searchBtn() {
            // let fromDt = new Date(this.clsDt[0])
            // let toDt = new Date(this.clsDt[1])
            // if (fromDt > toDt) {
            //     this.showAlert_({
            //         title: '세금계산서일자 오류',
            //         message: '시작일자가 마지막일자 보다 큽니다.',
            //     })
            //     return
            // }
            // if (
            //     moment(fromDt).format('YYYY-MM') !=
            //     moment(toDt).format('YYYY-MM')
            // ) {
            //     this.showAlert_({
            //         title: '세금계산서일자 오류',
            //         message: '같은 월 검색만 됩니다.',
            //     })
            //     return
            // }
            this.formSearchParams.clsDt = this.clsDt.replace(/-/g, '')
            await this.defaultAssign_({ key: 'paging', value: this.initPaging })
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 197 ~ searchBtn ~ this.formSearchParams',
                this.formSearchParams
            )
            await this.defaultAssign_({
                key: 'searchParams',
                value: this.formSearchParams,
            })
            await this.searchData()
        },
        async searchData() {
            let data1
            this.loading(true)
            await this.getBasCmuDclsTrmsMgmtList_()
                .then((data) => {
                    data1 = data
                    // console.log(
                    //     '🚀 ~ file: SearchContent.vue ~ line 51 ~ searchData ~ data',
                    //     data
                    // )
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    //console.log('🚀 ~ file: SearchContent.vue ~ finally')
                    this.loading(false)
                    if (data1 !== undefined && data1.gridList.length == 0) {
                        this.toasting_({
                            message: msgTxt.MSG_00039.replace(/%s/g, ''),
                        })
                    }
                })
        },
        async saveBtn() {
            this.formSearchParams.clsDt = this.clsDt.replace(/-/g, '')
            //console.log('🚀 ~ file: saveBtn~ line 122 ~ data ', this.$data)
            await this.defaultAssign_({
                key: 'saveAction',
                value: true,
            })
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        async inputEvent() {
            // if (
            //     this.formSearchParams.orgNm == '' &&
            //     this.formSearchParams.userNm == ''
            // ) {
            //     await this.setUnFiltering_()
            // } else {
            //     let pass = {
            //         orgNm: this.formSearchParams.orgNm,
            //         userNm: this.formSearchParams.userNm,
            //     }
            //     await this.setFiltering_(pass)
            // }
        },
        //====================내부조직팝업(권한)팝업관련====================
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.formSearchParams.orgCd = ''
            this.inputEvent()
        },
        onAuthOrgTreeReturnData(retrunData) {
            console.log('popup retrunData: ', retrunData)
            this.formSearchParams.orgNm = retrunData.orgNm
            this.formSearchParams.orgCd = retrunData.orgCd
        },
        //====================내부조직팝업(권한)팝업관련====================
    },
    watch: {
        async saveDone1(val, oldVal) {
            if (val == true) {
                console.log('saveDone1: ', val, oldVal)
                //saveAction 작업들이 모두 완료 되면 default 상태로 변환
                await this.defaultAssign_({
                    key: 'saveAction',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: false,
                })
            }
        },
    },
}
</script>
<style>
.boxhidden {
    opacity: 0;
    max-height: 1px;
}
.rightBox {
    display: flex;
    flex-direction: row;
    gap: 0.5em;
    height: 35px;
}
.rightBox .iteminput {
    width: 150px !important;
    flex-direction: row;
    flex-grow: 1;
    flex-shrink: 1;
}
.rightBox .v-input__slot {
    width: 140px !important;
    flex-direction: row;
    flex-grow: 1;
    flex-shrink: 1;
}
</style>
