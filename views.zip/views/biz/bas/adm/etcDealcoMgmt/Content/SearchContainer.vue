<template>
    <div>
        <!-- //================================버튼========================== -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="objAuth"
                    >초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="objAuth"
                    >조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="newBtn"
                    :objAuth="objAuth"
                    >신규
                </TCComButton>
                <RgstPopup
                    v-if="rgstDialogShow"
                    ref="popup"
                    :dialogShow.sync="rgstDialogShow"
                    :dtlData.sync="dtlParam"
                />
            </li>
        </ul>
        <!-- //================================//버튼========================== -->
        <!-- //================================searchLayer_wrap========================== -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <!-- 거래처등록구분 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="searchParam.dealcoRgstClCd"
                        :eRequired="true"
                        labelName="거래처등록구분"
                        :itemList="dealcoRgstClCdList"
                        :objAuth="objAuth"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        :filterFunc="filterRgstClCd"
                        @change="setDealcoGrpCd"
                    ></TCComComboBox>
                </div>
                <!-- //거래처등록구분 -->
                <!-- 거래처그룹 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="searchParam.dealcoGrpCd"
                        labelName="거래처그룹"
                        :itemList="dealcoGrpCdList"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                        :objAuth="objAuth"
                        @change="setDealcoClCd1"
                    ></TCComComboBox>
                </div>
                <!-- //거래처그룹 -->
                <!-- 거래처구분 -->
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="searchParam.dealcoClCd1"
                        labelName="거래처구분"
                        :objAuth="objAuth"
                        :itemList="dealcoClCd1List"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <!-- //거래처구분 -->
            </div>
        </div>
        <!-- //================================//searchLayer_wrap========================== -->
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/etcDealcoMgmt/helpers'

import CommonMixin from '@/mixins'
import commonApi from '@/api/common/prototype'
import { CommonGrid } from '@/utils'
import { msgTxt } from '@/const/msg.Properties'
import _ from 'lodash'

import RgstPopup from './PopupContainer.vue'

export default {
    name: 'SearchContainer',
    components: {
        RgstPopup,
    },
    mixins: [CommonMixin],
    async created() {
        // code 호출 후 store 적재
        await this.getCodeList()
        await this.initData()
    },
    data() {
        return {
            objAuth: {},
            gridHeaderObj: {},
            gridObj: {},
            gridData: this.gridSetData(),

            rgstDialogShow: false,
            searchParam: {
                dealcoRgstClCd: '',
                dealcoGrpCd: '',
                dealcoClCd1: '',
            },
            dtlParam: {
                dealcoRgstClCd: '', // 거래처등록구분
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '', // 거래처그룹코드
                dealcoClCd1: '', // 거래처구분코드
                effStaDtm: '', // 유효시작일시
                effEndDtm: '', // 유효종료일시
                hstSeq: '', // 이력순번
            },

            dealcoRgstClCdList: [{ commCdVal: '', commCdValNm: '선택' }], // 거래처등록구분
            dealcoGrpCdList: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처그룹
            dealcoClCd1List: [{ commCdVal: '', commCdValNm: '전체' }], // 거래처구분
        }
    },
    computed: {
        ...serviceComputed,
        paging1: {
            get() {
                return this.paging
            },
        },
        initPaging1: {
            get() {
                return this.initPaging
            },
        },
    },
    methods: {
        ...serviceMethods,
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        async initData() {
            await this.initParam()
            await this.initPagingAssign_()
            await this.defaultAssign_({
                key: 'resultList',
                value: [],
            })

            await this.setDealcoGrpCd(this.searchParam.dealcoRgstClCd)
        },
        filterRgstClCd(items) {
            return items.filter(
                (item) =>
                    _.isEqual(item['addInfo1'], 'ETC') &&
                    _.isEqual(item['commCdVal'], 'ES')
            )
        },
        initParam() {
            this.searchParam = {
                dealcoRgstClCd: 'ES',
                dealcoGrpCd: '',
                dealcoClCd1: '',
            }
        },
        initPagingAssign_() {
            this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
        },
        initBtn() {
            this.initData()
        },
        async getCodeList() {
            const codeList = [
                'DEALCO_RGST_CL_CD',
                'DEAL_CO_GRP',
                'ZBAS_C_00240',
            ]
            await _.forEach(codeList, (code) => {
                this.getCommCodeList(code)
            })
        },
        async getCommCodeList(codeId) {
            let data = ''

            await commonApi
                .getCommonCodeList(codeId)
                .then((res) => {
                    data = res
                })
                .finally(() => {
                    if (_.isEqual(codeId, 'DEALCO_RGST_CL_CD')) {
                        this.dealcoRgstClCdList = data
                    }
                    /*
                    if (_.isEqual(codeId, 'DEAL_CO_GRP')) {
                        this.dealcoGrpCdList = data
                    }
                    */
                    this.defaultAssign_({
                        key: codeId,
                        value: data,
                    })
                })
        },
        /**
         * 거래처그룹코드 셋팅
         * DC : 매장공통
         * DS : 매장개별
         * EC : 기타공통
         * ES : 기타개별
         * @param dealcoRgstClCd : 거래처등록구분코드
         */
        async setDealcoGrpCd(dealcoRgstClCd) {
            let dealcoGrpCds = [{ commCdVal: '', commCdValNm: '전체' }]
            let dealcoClCd1s = [{ commCdVal: '', commCdValNm: '전체' }]
            const info = 'addInfo5' // 추가정보

            if (!_.isEmpty(dealcoRgstClCd)) {
                dealcoGrpCds = this.getFilterCode(
                    this.DEAL_CO_GRP, // 코드리스트
                    info, // 추가정보
                    dealcoRgstClCd // 필터코드
                )
                this.dealcoGrpCdList = dealcoGrpCds
            } else {
                this.dealcoGrpCdList = dealcoGrpCds
            }
            console.log('this.dealcoGrpCdList->', this.dealcoGrpCdList)
            this.dealcoClCd1List = dealcoClCd1s
        },
        /**
         * 거래처구분코드 셋팅
         * @param dealcoGrpCd : 거래처그룹코드
         */
        setDealcoClCd1(dealcoGrpCd) {
            let dealcoClCd1s = [{ commCdVal: '', commCdValNm: '선택' }]
            const info = 'addInfo1' // 추가정보
            if (!_.isEmpty(dealcoGrpCd)) {
                dealcoClCd1s = this.getFilterCode(
                    this.ZBAS_C_00240, // 코드리스트
                    info, // 추가정보
                    dealcoGrpCd // 필터코드
                )
                this.dealcoClCd1List = dealcoClCd1s
            } else {
                this.dealcoClCd1List = dealcoClCd1s
            }
        },
        getFilterCode(codeList, info, filterCode) {
            let rtnCode = []
            _.forEach(codeList, (data) => {
                if (_.isEqual(data[info], filterCode)) {
                    rtnCode.push(data)
                }
            })
            return rtnCode
        },
        gridSetData() {
            return new CommonGrid(0, 30, '', '')
        },
        async searchBtn() {
            if (_.isEmpty(this.searchParam.dealcoRgstClCd)) {
                this.showTcComAlert(
                    msgTxt.MSG_00047.replace(/%s/g, '거래처등록구분을')
                )
                return false
            }
            this.initPagingAssign_()
            let paramObj = { ...this.searchParam }
            paramObj.pageNum = this.paging1.pageNum
            paramObj.pageSize = this.initPaging1.pageSize

            await this.defaultAssign_({
                key: 'searchParams',
                value: paramObj,
            })
            await this.searchData()
        },
        async searchData() {
            await this.loading(true)
            let data1
            await this.getEtcDealcoMgmtLst_()
                .then((data) => {
                    data1 = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    this.loading(false)
                    if (_.isEmpty(data1)) {
                        this.showTcComAlert(msgTxt.MSG_00039.replace(/%s/g, ''))
                    }
                })
        },

        async newBtn() {
            this.rgstDialogShow = true
        },
    },
}
</script>

<style scoped></style>
