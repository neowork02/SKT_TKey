/*****************************************
 * 업무 그룹명 : 기준정보>조직별대리점검색
 * 서브 업무명 : 조직별대리점검색
 * 설 명 : 조직별대리점검색 Grid 헤더 정보
 * 작 성 자 : 김태훈
 * 작 성 일 : 2022.05.04
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const BAS_BCO_ORG_AGENCYS_HEADER = {
    fields: [
        {
            fieldName: 'agencyClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polOperDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'polOperDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aplyStaDt',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'aplyEndDt',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'agencyClCd',
            fieldName: 'agencyClCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '대리점구분',
            },
        },
        {
            name: 'agencyTypCd',
            fieldName: 'agencyTypCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '대리점유형',
            },
        },
        /*        
        {
            name: 'polOperDealcoNm',
            fieldName: 'polOperDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '운영사',
            },
        },
*/
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '대리점명',
            },
        },
        {
            name: 'aplyStaDt',
            fieldName: 'aplyStaDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '적용시작일',
            },
        },
        {
            name: 'aplyEndDt',
            fieldName: 'aplyEndDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '적용종료일',
            },
        },
    ],
}
