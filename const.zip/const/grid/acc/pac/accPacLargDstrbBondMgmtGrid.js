import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'opDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'orgCd3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm3',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm4',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'payObjC1',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'payObjC2',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'pm02Amt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'objAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'amt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            header: { text: '기준일자' },
            width: '150',
        },
        {
            name: 'orgNm3',
            fieldName: 'orgNm3',
            type: 'data',
            header: { text: '팀' },
            width: '150',
        },
        /*거래처(6)*/
        {
            name: 'orgCd3',
            fieldName: 'orgCd3',
            type: 'data',
            header: { text: '팀코드' },
            width: '150',
        },
        {
            name: 'orgNm4',
            fieldName: 'orgNm4',
            type: 'data',
            header: { text: '파트' },
            width: '150',
        },
        {
            name: 'orgCd4',
            fieldName: 'orgCd4',
            type: 'data',
            header: { text: '파트코드' },
            width: '150',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            header: { text: '거래처코드' },
            width: '150',
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            header: { text: '매장명' },
            width: '150',
        },
        {
            name: 'dpstAmt',
            fieldName: 'dpstAmt',
            type: 'data',
            header: { text: '입금누계(당월)' },
            width: '150',
        },
        {
            name: 'payObjC1',
            fieldName: 'payObjC1',
            type: 'data',
            header: { text: '번호이동(수납)' },
            width: '150',
        },
        {
            name: 'payObjC2',
            fieldName: 'payObjC2',
            type: 'data',
            header: { text: '요금수납(수납)' },
            width: '150',
        },
        {
            name: 'pm02Amt',
            fieldName: 'pm02Amt',
            type: 'data',
            header: { text: '요금수납(기타)' },
            width: '150',
        },
        {
            name: 'objAmt',
            fieldName: 'objAmt',
            type: 'data',
            header: { text: '현금매출(외상)' },
            width: '150',
        },
        {
            name: 'amt',
            fieldName: 'amt',
            type: 'data',
            header: { text: '공기기(외상)' },
            width: '150',
        },
    ],
}
