import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'rowNum', // 순번
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'orgCd', // 조직
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealCoCl1Nm', // 거래처구분
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'pcode', // P코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealStatus', // 거래상태
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealStaDt', // 거래개시일
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'dealEndDt', // 거래종료일
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'saleChrgr', // 영업담당자
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'bondTyp', // 월마감채권유형
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'bondTypNm', // 월마감채권유형명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'clsClctPlan', // 월마감회수계획
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'clsClctPlanNm', // 월마감회수계획명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'overBondAmt', // 채권금액
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'bondMthAge', // 채권월령
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'bfOverBondAmt', // 전월채권금액
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'bfClsClctPlan', // 전월회수계획
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'saleClctPlanMjr', // 영업담당회수계획(대분류)코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'saleClctPlanMjrNm', // 영업담당회수계획(대분류)코드명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'saleClctPlanMin', // 영업담당회수계획(소분류)코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'saleClctPlanMinNm', // 영업담당회수계획(소분류)코드명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'saleClsDt', // 영업담당회수계획실행(마감일)
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'saleClctDelyRsn', // 영업담당회수계획회수지연사유
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'bondClctPlanMjr', // 채권담당회수계획(대분류)코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'bondClctPlanMjrNm', // 채권담당회수계획(대분류)코드명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'bondClctPlanMin', // 채권담당회수계획(소분류)코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'bondClctPlanMinNm', // 채권담당회수계획(소분류)코드명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'bondClsDt', // 채권담당회수계획실행(마감일)
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'bondClctDelyRsn', // 채권담당회수계획회수지연사유
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'clctNoRsn', // 비고
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'modUserId', // 처리자id
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'modUserNm', // 처리자명
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'modDtm', // 처리일시
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'docYn', // 증빙첨부여부
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'attachAddDtm', // 최초증빙파일등록일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'attachDelDtm', // 증빙파일삭제예정일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'docId', // 증빙파일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fileNm', // 증빙파일
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            header: {
                text: '체크',
            },
            visible: false,
        },
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            editable: false,
            header: '순번',
            type: 'data',
            width: '50',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            header: '조직코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            header: '조직명',
            editable: false,
            type: 'data',
            width: '380',
            styleName: 'left-column',
        },
        {
            name: 'dealCoCl1Nm',
            fieldName: 'dealCoCl1Nm',
            header: '거래처구분',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            header: '거래처코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: '거래처명',
            editable: false,
            type: 'data',
            width: '150',
            styleName: 'left-column',
        },
        {
            name: 'pcode',
            fieldName: 'pcode',
            header: '매장코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            header: '거래상태',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            editable: false,
            header: {
                text: '거래개시일',
                showTooltip: false,
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'dealEndDt',
            fieldName: 'dealEndDt',
            editable: false,
            header: {
                text: '거래종료일',
                showTooltip: false,
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'saleChrgr',
            fieldName: 'saleChrgr',
            editable: false,
            header: '영업담당',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'bondTyp',
            fieldName: 'bondTyp',
            header: '* 채권유형',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                domainOnly: true,
                textReadOnly: true,
            },
        },
        {
            name: 'bondTypNm',
            fieldName: 'bondTypNm',
            editable: false,
            header: '채권유형명',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'clsClctPlan',
            fieldName: 'clsClctPlan',
            header: '* 회수계획',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                domainOnly: true,
                textReadOnly: true,
            },
        },
        {
            name: 'clsClctPlanNm',
            fieldName: 'clsClctPlanNm',
            editable: false,
            header: '회수계획명',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'overBondAmt',
            fieldName: 'overBondAmt',
            editable: false,
            header: '채권금액',
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            styleName: 'right-column',
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'bondMthAge',
            fieldName: 'bondMthAge',
            editable: false,
            header: '채권월령',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'bfOverBondAmt',
            fieldName: 'bfOverBondAmt',
            editable: false,
            header: {
                text: '전월\n채권금액',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '100',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            styleName: 'right-column',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'bfClsClctPlan',
            fieldName: 'bfClsClctPlan',
            editable: false,
            header: {
                text: '전월\n회수계획',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'saleClctPlanMjr',
            fieldName: 'saleClctPlanMjr',
            header: '* (대분류)코드',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                domainOnly: true,
                textReadOnly: true,
            },
        },
        {
            name: 'saleClctPlanMjrNm',
            fieldName: 'saleClctPlanMjrNm',
            editable: false,
            header: '(대분류)코드명',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'saleClctPlanMin',
            fieldName: 'saleClctPlanMin',
            header: '* (소분류)코드',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                domainOnly: true,
                textReadOnly: true,
            },
        },
        {
            name: 'saleClctPlanMinNm',
            fieldName: 'saleClctPlanMinNm',
            editable: false,
            header: '(소분류)코드명',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'saleClsDt',
            fieldName: 'saleClsDt',
            header: '* 실행(마감일)',
            type: 'data',
            width: '100',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'saleClctDelyRsn',
            fieldName: 'saleClctDelyRsn',
            header: {
                text: '* 회수지연\n사유',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'bondClctPlanMjr',
            fieldName: 'bondClctPlanMjr',
            header: '* (대분류)코드',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                domainOnly: true,
                textReadOnly: true,
            },
        },
        {
            name: 'bondClctPlanMjrNm',
            fieldName: 'bondClctPlanMjrNm',
            editable: false,
            header: '(대분류)코드명',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'bondClctPlanMin',
            fieldName: 'bondClctPlanMin',
            header: '* (소분류)코드',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                domainOnly: true,
                textReadOnly: true,
            },
        },
        {
            name: 'bondClctPlanMinNm',
            fieldName: 'bondClctPlanMinNm',
            editable: false,
            header: '(소분류)코드명',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'bondClsDt',
            fieldName: 'bondClsDt',
            header: '* 실행(마감일)',
            type: 'data',
            width: '100',
            dataType: ValueType.TEXT,
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'bondClctDelyRsn',
            fieldName: 'bondClctDelyRsn',
            header: {
                text: '* 회수지연\n사유',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'clctNoRsn',
            fieldName: 'clctNoRsn',
            header: '* 비고',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            editable: false,
            header: '처리자id',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            editable: false,
            header: '처리자명',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            editable: false,
            header: '처리일시',
            type: 'data',
            width: '100',
            dataType: ValueType.TEXT,
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'docYn',
            fieldName: 'docYn',
            editable: false,
            header: {
                text: '증빙\n첨부여부',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'attachAddDtm',
            fieldName: 'attachAddDtm',
            editable: false,
            header: {
                text: '최초증빙파일\n등록일시',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'attachDelDtm',
            fieldName: 'attachDelDtm',
            editable: false,
            header: {
                text: '증빙파일삭제\n예정일자',
                styleName: 'multi-line-css',
            },
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'docId',
            fieldName: 'docId',
            editable: false,
            header: '증빙파일',
            type: 'data',
            width: '80',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'fileNm',
            fieldName: 'fileNm',
            editable: false,
            header: '* 증빙파일',
            type: 'data',
            width: '80',
            //showStepButton: true,
            button: 'action',
            buttonVisibility: 'always',
            styles: {
                textAlignment: 'center',
            },
        },
    ],
    layout: [
        'rowNum',
        'orgNm',
        //'orgCd',
        'pcode',
        'dealcoCd',
        'dealcoNm',
        'dealCoCl1Nm',
        'dealStatus',
        'dealStaDt',
        'dealEndDt',
        'saleChrgr',
        {
            name: '월마감 ',
            direction: 'horizontal',
            items: [
                'bondTyp',
                //'bondTypNm',
                'clsClctPlan',
                //'clsClctPlanNm',
            ],
        },
        'overBondAmt',
        'bondMthAge',
        'bfOverBondAmt',
        'bfClsClctPlan',
        {
            name: '영업담당 회수계획 ',
            direction: 'horizontal',
            items: [
                'saleClctPlanMjr',
                //'saleClctPlanMjrNm',
                'saleClctPlanMin',
                //'saleClctPlanMinNm',
                'saleClsDt',
                'saleClctDelyRsn',
            ],
        },
        {
            name: '채권담당 회수계획 ',
            direction: 'horizontal',
            items: [
                'bondClctPlanMjr',
                //'bondClctPlanMjrNm',
                'bondClctPlanMin',
                //'bondClctPlanMinNm',
                'bondClsDt',
                'bondClctDelyRsn',
            ],
        },
        'clctNoRsn',
        //'modUserId',
        'modUserNm',
        'modDtm',
        'docYn',
        'attachAddDtm',
        'attachDelDtm',
        'fileNm',
    ],
}

export const G_EXCEL_HEADER = {
    fields: [
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bondTypNm', // 월마감채권유형명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'clsClctPlanNm', // 월마감회수계획명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bondMthAge', // 채권월령
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            header: '거래처코드',
            editable: false,
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'bondTypNm',
            fieldName: 'bondTypNm',
            editable: false,
            header: '채권유형명',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'clsClctPlanNm',
            fieldName: 'clsClctPlanNm',
            editable: false,
            header: '회수계획명',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'bondMthAge',
            fieldName: 'bondMthAge',
            editable: false,
            header: '채권월령',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
        },
    ],
    layout: ['dealcoCd', 'bondTypNm', 'clsClctPlanNm', 'bondMthAge'],
}
