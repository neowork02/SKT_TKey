import { ValueType } from 'realgrid'

export const WIRELESS_HEADER = {
    fields: [
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'scrbStopDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wdrlDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ignDcodeYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'combProdYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wrcellClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcplnClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcplnClDtlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'basGrpCd',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'polBasGrpCd',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'basAmt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: '__rowState',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            header: {
                text: '상품코드',
            },
        },
        {
            name: 'suplSvcClCd',
            fieldName: 'suplSvcClCd',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '부가상품구분',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            header: {
                text: '상품명',
            },
            width: '200',
        },
        {
            name: 'rgstClCd',
            fieldName: 'rgstClCd',
            editable: false,
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '등록구분',
            },
        },
        {
            name: 'prodStCd',
            fieldName: 'prodStCd',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '상품상태',
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            header: {
                text: '출시일',
            },
        },
        {
            name: 'scrbStopDt',
            fieldName: 'scrbStopDt',
            editable: false,
            header: {
                text: '가입중단일',
            },
        },
        {
            name: 'wdrlDt',
            fieldName: 'wdrlDt',
            editable: false,
            header: {
                text: '퇴출일',
            },
        },
        {
            name: 'ignDcodeYn',
            fieldName: 'ignDcodeYn',
            header: {
                text: '소속영업장 적용여부',
            },
            width: '70',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
            // styleCallback(grid, dataCell) {
            //     console.log('grid', grid)
            //     console.log('dataCell', dataCell)
            //     console.log('dataCell.value', dataCell.value)

            //     return dataCell.value
            // },
        },
        {
            name: 'combProdYn',
            fieldName: 'combProdYn',
            editable: false,
            header: {
                text: '결합상품',
            },
            width: '70',
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            header: {
                text: '사용여부',
            },
            width: '70',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
        },
        {
            name: 'wrcellClCd',
            fieldName: 'wrcellClCd',
            header: {
                text: '유무선구분코드',
            },
        },
        {
            name: 'prcplnClCd',
            fieldName: 'prcplnClCd',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '부가상품분류',
            },
        },
        {
            name: 'prcplnClDtlCd',
            fieldName: 'prcplnClDtlCd',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '부가상품분류상세',
            },
        },
        {
            name: 'basGrpCd',
            fieldName: 'basGrpCd',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '기본료그룹코드',
            },
        },
        // {
        //     name: 'polBasGrpCd',
        //     fieldName: 'polBasGrpCd',
        //     sortable: true,
        //     lookupDisplay: true,
        //     editor: {
        //         type: 'dropdown',
        //         dropDownCount: 10,
        //         domainOnly: true,
        //         textReadOnly: true,
        //         values: [],
        //         labels: [],
        //     },
        //     header: {
        //         text: '정책기본료그룹코드',
        //     },
        // },
        {
            name: 'basAmt',
            fieldName: 'basAmt',
            header: {
                text: '기본료',
            },
        },
    ],
}

export const WIRE_HEADER = {
    fields: [
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wireProdClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wireProdClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mktgDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'scrbStopDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wdrlDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'combProdYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wrcellClCd',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'suplClassCd',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'prcplnClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcplnClDtlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: '__rowState',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            header: {
                text: '상품코드',
            },
        },
        {
            name: 'suplSvcClCd',
            fieldName: 'suplSvcClCd',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '부가상품구분',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            header: {
                text: '상품명',
            },
            width: '200',
        },
        {
            name: 'wireProdClCd',
            fieldName: 'wireProdClCd',
            header: {
                text: '유선상품구분코드',
            },
        },
        {
            name: 'wireProdClNm',
            fieldName: 'wireProdClNm',
            header: {
                text: '유선상품구분',
            },
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: ['인터넷', '인터넷전화', '일반전화', 'IPTV', '없음'],
                labels: ['인터넷', '인터넷전화', '일반전화', 'IPTV', '없음'],
            },
        },
        {
            name: 'rgstClCd',
            fieldName: 'rgstClCd',
            editable: false,
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '등록구분',
            },
        },
        {
            name: 'prodStCd',
            fieldName: 'prodStCd',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '상품상태',
            },
        },
        {
            name: 'mktgDt',
            fieldName: 'mktgDt',
            header: {
                text: '출시일',
            },
        },
        {
            name: 'scrbStopDt',
            fieldName: 'scrbStopDt',
            editable: false,
            header: {
                text: '가입중단일',
            },
        },
        {
            name: 'wdrlDt',
            fieldName: 'wdrlDt',
            editable: false,
            header: {
                text: '퇴출일',
            },
        },
        {
            name: 'combProdYn',
            fieldName: 'combProdYn',
            editable: false,
            header: {
                text: '결합상품',
            },
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
            header: {
                text: '사용여부',
            },
        },
        {
            name: 'wrcellClCd',
            fieldName: 'wrcellClCd',
            header: {
                text: 'WIRE_CL',
            },
        },
        // {
        //     name: 'suplClassCd',
        //     fieldName: 'suplClassCd',
        //     sortable: true,
        //     lookupDisplay: true,
        //     editor: {
        //         type: 'dropdown',
        //         dropDownCount: 10,
        //         domainOnly: true,
        //         textReadOnly: true,
        //         values: [],
        //         labels: [],
        //     },
        //     header: {
        //         text: '요금제구간',
        //     },
        // },
        {
            name: 'prcplnClCd',
            fieldName: 'prcplnClCd',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '부가상품분류',
            },
        },
        {
            name: 'prcplnClDtlCd',
            fieldName: 'prcplnClDtlCd',
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '부가상품분류상세',
            },
        },
    ],
}
