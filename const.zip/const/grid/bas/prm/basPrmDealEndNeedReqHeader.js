import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.BOOLEAN,
        },
        {
            fieldName: 'reqStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealPeriod',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'avrSales',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoClCd1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chargUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndPriRsnCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndRsn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvSeq',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'chk',
            fieldName: 'chk',
            type: 'data',
            editable: false,
            renderer: {
                type: 'check',
            },
            width: '50',
            header: {
                text: '선택',
            },
        },
        {
            name: 'reqStCd',
            fieldName: 'reqStCd',
            editable: false,
            header: {
                text: '요청상태',
            },
        },
        {
            name: 'reqTypCd',
            fieldName: 'reqTypCd',
            editable: false,
            header: {
                text: '유형',
            },
        },
        {
            name: 'dealPeriod',
            fieldName: 'dealPeriod',
            editable: false,
            header: {
                text: '거래기간',
            },
        },
        {
            name: 'avrSales',
            fieldName: 'avrSales',
            editable: false,
            header: {
                text: '3개월 평균실적',
            },
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            editable: false,
            width: '400',
            header: {
                text: '조직',
            },
            styleName: 'left-column',
        },
        /*
        {
            name: 'bizChrgOrgCd',
            fieldName: 'bizChrgOrgCd',
            editable: false,
            header: {
                text: '사업담당',
            },
        },
        {
            name: 'teamOrgCd',
            fieldName: 'teamOrgCd',
            editable: false,
            header: {
                text: '영업팀',
            },
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            editable: false,
            header: {
                text: '영업파트',
            },
        },
        */
        {
            name: 'dealCoClCd1',
            fieldName: 'dealCoClCd1',
            editable: false,
            header: {
                text: '거래처구분',
            },
        },
        {
            name: 'dealSktCd',
            fieldName: 'dealSktCd',
            type: 'data',
            header: { text: '매장코드' },
            width: '150',
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            editable: false,
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            editable: false,
            header: {
                text: '거래처명',
            },
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            editable: false,
            header: {
                text: '채널코드',
            },
        },
        {
            name: 'dealStaDt',
            fieldName: 'dealStaDt',
            editable: false,
            header: {
                text: '거래개시일',
            },
        },
        {
            name: 'chargUserId',
            fieldName: 'chargUserId',
            editable: false,
            header: {
                text: '영업담당',
            },
        },
        {
            name: 'dealStNm',
            fieldName: 'dealStNm',
            editable: false,
            header: {
                text: '거래처상태',
            },
        },
        {
            name: 'reqUserId',
            fieldName: 'reqUserId',
            editable: false,
            header: {
                text: '요청자',
            },
        },
        {
            name: 'reqDtm',
            fieldName: 'reqDtm',
            editable: false,
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
            header: {
                text: '요청일시',
            },
        },
        {
            name: 'aprvUserId',
            fieldName: 'aprvUserId',
            editable: false,
            header: {
                text: '승인자',
            },
        },
        {
            name: 'aprvDtm',
            fieldName: 'aprvDtm',
            editable: false,
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
            header: {
                text: '승인일시',
            },
        },
        {
            name: 'dealEndPriRsnCd',
            fieldName: 'dealEndPriRsnCd',
            editable: false,
            header: {
                text: '거래종료사유',
            },
        },
        {
            name: 'dealEndRsn',
            fieldName: 'dealEndRsn',
            editable: false,
            header: {
                text: '상세사유',
            },
        },
    ],
}
