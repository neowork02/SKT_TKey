<!-----------------------------------------------
 * 업무그룹명: 주소찾기
 * 서브업무명: 주소찾기 팝업
 * 설명: 주소 찾기 팝업
 * 작성자: P179229
 * 작성일: 2022.10.27
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">주소찾기</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="contBoth">
                        <TCComTab
                            :tab.sync="tabIndex"
                            :items="items"
                            :itemName="itemName"
                            :tabColor="tabColor"
                            :textColor="textColor"
                            :objAuth="objAuth"
                            sliderSize="8"
                            :cKey="0"
                        >
                            <template #도로명으로>
                                <div class="div7_1 cont1">
                                    <!-- Search_div -->
                                    <div class="searchLayer_wrap">
                                        <div class="searchform">
                                            <div class="formitem div2">
                                                <TCComComboBox
                                                    labelName="시/도"
                                                    :objAuth="objAuth"
                                                    :addBlankItem="true"
                                                    blankItemText="선택"
                                                    blankItemValue=""
                                                    v-model="fsearch1.selectDo"
                                                    :itemList="doItems"
                                                    @change="getSi"
                                                />
                                            </div>
                                            <div class="formitem div2">
                                                <TCComComboBox
                                                    labelName="시/군/구"
                                                    :objAuth="objAuth"
                                                    :addBlankItem="true"
                                                    blankItemText="선택"
                                                    blankItemValue=""
                                                    v-model="fsearch1.selectSi"
                                                    :itemList="siItems"
                                                />
                                            </div>
                                        </div>
                                        <div class="searchform">
                                            <div class="formitem div2">
                                                <TCComInputSearch
                                                    labelName="도로명"
                                                    :objAuth="objAuth"
                                                    v-model="fsearch1.stName"
                                                    @appendIconClick="getStreet"
                                                    @enterKey="getStreet"
                                                >
                                                </TCComInputSearch>
                                            </div>
                                            <div class="formitem div2">
                                                <div class="arrayType">
                                                    <div class="col0">
                                                        <TCComInput
                                                            labelName="건물번호"
                                                            v-model="
                                                                fsearch1.bdnumMain
                                                            "
                                                            @enterKey="
                                                                getAddress
                                                            "
                                                        >
                                                        </TCComInput>
                                                    </div>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <div class="col0">
                                                        <TCComNoLabelInput
                                                            class="w100"
                                                            v-model="
                                                                fsearch1.bdnumSub
                                                            "
                                                            @enterKey="
                                                                getAddress
                                                            "
                                                        >
                                                        </TCComNoLabelInput>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="searchform">
                                            <div class="formitem div2">
                                                <TCComInputSearch
                                                    labelName="건물명"
                                                    :objAuth="objAuth"
                                                    v-model="fsearch1.bldName"
                                                    @appendIconClick="
                                                        getBuilding
                                                    "
                                                    @enterKey="getBuilding"
                                                >
                                                </TCComInputSearch>
                                            </div>
                                            <div class="formitem div2">
                                                <div class="rightArea btn">
                                                    <span class="inner">
                                                        <TCComButton
                                                            :Vuetify="false"
                                                            eClass="btn_s btn_ty03"
                                                            eAttr="ico_verification"
                                                            labelName="검색"
                                                            :objAuth="objAuth"
                                                            @click="
                                                                getAddress(
                                                                    'fsearch1'
                                                                )
                                                            "
                                                        >
                                                        </TCComButton>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- // Search_div -->
                                </div>
                            </template>
                            <template #지번으로>
                                <div class="div7_1 cont1">
                                    <!-- Search_div -->
                                    <div class="searchLayer_wrap">
                                        <div class="searchform">
                                            <div class="formitem div2">
                                                <TCComInput
                                                    labelName="읍/면/동/건물명"
                                                    v-model="fsearch2.bldName"
                                                    @enterKey="
                                                        getAddress('fsearch2')
                                                    "
                                                >
                                                </TCComInput>
                                            </div>
                                            <div class="formitem div2">
                                                <div class="rightArea btn">
                                                    <span class="inner">
                                                        <TCComButton
                                                            :Vuetify="false"
                                                            eClass="btn_s btn_ty03"
                                                            eAttr="ico_verification"
                                                            labelName="검색"
                                                            :objAuth="objAuth"
                                                            @click="
                                                                getAddress(
                                                                    'fsearch2'
                                                                )
                                                            "
                                                        >
                                                        </TCComButton>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </template>
                        </TCComTab>
                    </div>
                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="popupGridHeader1"
                                ref="popupGridHeader1"
                                :gridObj="gridObj1"
                                gridTitle="주소선택"
                            />
                            <TCRealGrid
                                id="popupGrid1"
                                ref="popupGrid1"
                                :fields="view1.fields"
                                :columns="view1.columns"
                                :styles="gridStyle1"
                            />
                        </div>
                    </div>
                    <!-- //gridWrap -->
                    <div class="contBoth">
                        <div class="div7_1 cont1">
                            <div class="stitHead">
                                <h4 class="subTit">상세주소</h4>
                            </div>
                            <!-- Search_div -->
                            <div class="searchLayer_wrap">
                                <div class="searchform">
                                    <div class="formitem div2">
                                        <TCComInput
                                            labelName="상세주소"
                                            v-model="dtlAddr"
                                            @enterKey="getGdsk"
                                        >
                                        </TCComInput>
                                    </div>
                                    <div class="formitem div2">
                                        <div class="rightArea btn">
                                            <span class="inner">
                                                <TCComButton
                                                    :Vuetify="false"
                                                    eClass="btn_s btn_ty03"
                                                    eAttr="ico_verification"
                                                    labelName="확인"
                                                    :objAuth="objAuth"
                                                    @click="getGdsk"
                                                >
                                                </TCComButton>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- gridWrap -->
                            <div class="gridWrap">
                                <div class="gridWrap">
                                    <TCRealGridHeader
                                        id="popupGridHeader2"
                                        ref="popupGridHeader2"
                                        :gridObj="gridObj2"
                                    />
                                    <TCRealGrid
                                        id="popupGrid2"
                                        ref="popupGrid2"
                                        :fields="view2.fields"
                                        :columns="view2.columns"
                                        :styles="gridStyle2"
                                    />
                                </div>
                            </div>
                            <!-- //gridWrap -->
                        </div>
                    </div>
                    <!-- Close BTN-->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            적용
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty01"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
                <!-- popup -->
                <BasBcoAddresSrchPopup
                    v-if="showAddresSrchPop === true"
                    ref="popup"
                    :dialogShow.sync="showAddresSrchPop"
                    :parentParam="srchAddresParam"
                    @confirm="addresPopReturnData"
                />
                <!-- // popup -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import CommonMixin from '@/mixins'
import {
    BasBcoProdAddresSrchGRID_HEADER,
    BasBcoNewZipSrchGRID_HEADER,
} from '@/const/grid/bas/bco/basBcoAddresSrchPopupHeader'
import BasBcoAddresSrchPopup from './BasBcoAddresSrchPopup'
import store from '@/store'
import _ from 'lodash'

export default {
    name: 'BasBcoNewZipSrchPopup',
    mixins: [CommonMixin],
    components: { BasBcoAddresSrchPopup },
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        parentParam: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            gridData: {},
            objAuth: {},
            view1: BasBcoProdAddresSrchGRID_HEADER,
            gridObj1: {},
            gridHeaderObj1: {},
            gridStyle1: {
                height: '120px',
            },
            view2: BasBcoNewZipSrchGRID_HEADER,
            gridObj2: {},
            gridHeaderObj2: {},
            gridStyle2: {
                height: '20px',
            },
            //개발기 : 8600634 // 211.188.178.99
            //운영기 : 8610851 // 211.188.178.103, 211.188.178.104, 211.188.178.105
            addr: 'https://juso.sktelecom.com',
            auth: '8610851',
            fObj: '',
            //도로명
            fsearch1: {
                selectDo: '',
                selectSi: '',
                stName: '',
                bldName: '',
                bdnumMain: '',
                bdnumSub: '',
            },
            //지번
            fsearch2: {
                bldName: '',
            },
            dtlAddr: '',
            doItems: [],
            siItems: [],
            showAddresSrchPop: false,
            srchAddresParam: {},
            // tab 관련
            tabIndex: 0,
            selectedTab: 'first',
            items: ['도로명으로', '지번으로'],
            itemName: ['도로명으로', '지번으로'],
            tabColor: '',
            textColor: '',
        }
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        this.gridObj1 = this.$refs.popupGrid1
        this.gridHeaderObj1 = this.$refs.popupGridHeader1
        this.gridObj1.setGridState(false, false, true)
        this.gridObj1.gridView.setCheckBar({
            exclusive: true,
        })
        this.gridObj2 = this.$refs.popupGrid2
        this.gridHeaderObj2 = this.$refs.popupGridHeader2
        this.gridObj2.setGridState(false, false, true)
        this.gridObj2.gridView.setCheckBar({
            exclusive: true,
        })
        //운영설정
        if (process.env.NODE_DEV === 'prd') {
            this.addr = '211.188.178.103'
            this.auth = '8610851'
        }
        //시/도 조회
        this.getDo()
    },
    watch: {},
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        /* 그리드 설정 */
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(-1, 10, '', '')
        },
        onClose: function () {
            this.activeOpen = false
        },
        /* 확인 */
        onConfirm() {
            const checkedRows = this.gridObj2.gridView.getCheckedRows(true)
            if (!checkedRows.length) {
                return
            }
            let jsonData = {}
            checkedRows.forEach((item) => {
                jsonData = this.gridObj2.dataProvider.getJsonRow(item)
            })
            console.log('popup:', jsonData)
            this.$emit('confirm', jsonData)
            this.onClose()
        },
        //시/도 조회
        getDo() {
            let search = 'auth=' + this.auth
            this.xmlhttpPost('/getDo.do', search, 'setDo')
        },
        //시/도 setting
        setDo(responseText) {
            let doList = JSON.parse(responseText)
            doList.forEach((data) => {
                let doData = {}
                doData.commCdVal = _.get(data, 'WAREA_NM')
                doData.commCdValNm = _.get(data, 'WAREA_NM')
                this.doItems.push(doData)
            })
        },
        //시/군/구 조회
        getSi() {
            this.siItems = []
            this.fsearch1.selectSi = ''
            if (
                this.fsearch1.selectDo !== '' &&
                this.fsearch1.selectDo !== '세종'
            ) {
                let search = 'selectdo=' + this.fsearch1.selectDo
                this.xmlhttpPost('/getSi.do', search, 'setSi')
            }
        },
        //시/군/구 setting
        setSi(responseText) {
            let doList = JSON.parse(responseText)
            doList.forEach((data) => {
                let siData = {}
                siData.commCdVal = _.get(data, 'CT_GUN_GU_NM')
                siData.commCdValNm = _.get(data, 'CT_GUN_GU_NM')
                this.siItems.push(siData)
            })
        },
        //도로명조회 팝업
        getStreet() {
            if (
                this.fsearch1.selectDo !== '세종' &&
                this.fsearch1.selectSi === '' &&
                this.fsearch1.stName === ''
            ) {
                this.showTcComAlert('도로명을 입력 하십시오.')
                return
            }
            let search = 'selectdo=' + this.fsearch1.selectDo
            search += '&selectsi=' + this.fsearch1.selectSi
            search += '&st_name=' + this.fsearch1.stName

            this.srchAddresParam.gubun = 'st'
            this.srchAddresParam.search = search
            this.srchAddresParam.addr = this.addr
            this.showAddresSrchPop = true
        },
        //건물명조회 팝업
        getBuilding() {
            if (
                this.fsearch1.selectDo !== '세종' &&
                this.fsearch1.selectSi === '' &&
                this.fsearch1.bldName === ''
            ) {
                this.showTcComAlert('건물명을 입력 하십시오.')
                return
            }
            if (
                this.fsearch1.selectDo !== '세종' &&
                this.fsearch1.selectSi === '' &&
                this.fsearch1.stName === ''
            ) {
                this.showTcComAlert('도로명은 필수값입니다.')
                return
            }
            let search = 'selectdo=' + this.fsearch1.selectDo
            search += '&selectsi=' + this.fsearch1.selectSi
            search += '&bld_name=' + this.fsearch1.bldName
            search += '&st_name=' + this.fsearch1.stName

            this.srchAddresParam.gubun = 'bld'
            this.srchAddresParam.search = search
            this.srchAddresParam.addr = this.addr
            this.showAddresSrchPop = true
        },
        // 도로명/건물명 조회 팝업 리턴 이벤트 처리
        addresPopReturnData(returnData) {
            // 도로명/건물명 조회 callback
            if (this.fsearch1.selectDo === '') {
                this.fsearch1.selectDo = returnData.selectDo
            }
            if (this.fsearch1.selectSi === '') {
                this.getSi()
                this.fsearch1.selectSi = returnData.selectSi
            }
            if (returnData.gubun === 'st') {
                this.fsearch1.stName = returnData.stName
            } else if (returnData.gubun === 'bld') {
                this.fsearch1.bldName = returnData.bldName
            }
        },
        //주소검색
        getAddress(fobj) {
            let search = 'fobj=' + fobj
            if (fobj === 'fsearch1') {
                if (
                    this.fsearch1.stName === '' &&
                    this.fsearch1.bldName === ''
                ) {
                    this.showTcComAlert('도로명을 선택 하십시오.')
                    return
                }
                if (
                    this.fsearch1.selectDo !== '세종' &&
                    this.fsearch1.selectSi === '' &&
                    this.fsearch1.stName === ''
                ) {
                    this.showTcComAlert('도로명은 필수값입니다.')
                    return
                }
                search += '&selectdo=' + this.fsearch1.selectDo
                search += '&selectsi=' + this.fsearch1.selectSi
                search += '&st_name=' + this.fsearch1.stName
                search += '&bld_name=' + this.fsearch1.bldName
                search += '&bdnum_main=' + this.fsearch1.bdnumMain
                search += '&bdnum_sub=' + this.fsearch1.bdnumSub
            } else {
                if (this.fsearch2.bldName === '') {
                    this.showTcComAlert('읍/면/동 또는 건물명을 선택 하십시오.')
                    return
                }
                search += '&bld_name=' + this.fsearch2.bldName
            }
            this.xmlhttpPost('/getAddress.do', search, fobj)
        },
        //주소검색 setting
        setAddress(responseText, fobj) {
            let addresJson = []
            let addresList = JSON.parse(responseText)
            addresList.forEach((data) => {
                let addresData = {}
                let addresName = ''
                if (fobj === 'fsearch1') {
                    addresName = _.get(data, 'DO_NM')
                    addresName += ' ' + _.get(data, 'CT_NM')
                    addresName += ' ' + _.get(data, 'RD_NM')
                    if (!_.isEmpty(_.get(data, 'UNDR_GRND_NM'))) {
                        addresName += ' ' + _.get(data, 'UNDR_GRND_NM')
                    }
                    if (!_.isEmpty(_.get(data, 'BLD_SB'))) {
                        addresName += ' ' + _.get(data, 'BLD_MB')
                        addresName += '-' + _.get(data, 'BLD_SB')
                    } else {
                        addresName += ' ' + _.get(data, 'BLD_MB')
                    }
                    addresName += ' ' + _.get(data, 'BLD_NM_CT')
                } else {
                    addresName = _.get(data, 'CT_PVC_NM')
                    addresName += ' ' + _.get(data, 'CT_GUN_NM')
                    addresName += ' ' + _.get(data, 'GU_NM')
                    addresName += ' ' + _.get(data, 'UP_MYUN_DONG_NM')
                    addresName += ' ' + _.get(data, 'RI_NM')
                    if (!_.isEmpty(_.get(data, 'GQTY_DLV_PLC_NM'))) {
                        addresName += ' ' + _.get(data, 'GQTY_DLV_PLC_NM')
                    }
                }
                addresData.addresName = addresName
                addresJson.push(addresData)
            })
            this.gridObj1.dataProvider.fillJsonData(addresJson, {})
            this.gridObj1.gridView.checkItem(0, true)
        },
        //상세주소 검색
        getGdsk() {
            const checkedRows = this.gridObj1.gridView.getCheckedRows(true)
            if (!checkedRows.length) {
                return
            }
            let search = ''
            checkedRows.forEach((item) => {
                const row = this.gridObj1.dataProvider.getJsonRow(item)
                search += 'addr=' + _.get(row, 'addresName')
            })
            console.log(search)
            search += '&dtl_addr=' + this.dtlAddr
            console.log(search)
            this.xmlhttpPost('/getGdsk.do', search, 'setGdsk')
        },
        //상세주소 setting
        setGdsk(responseText) {
            let gdskJson = []
            let gdskList = JSON.parse(responseText)
            gdskList.forEach((data) => {
                let gdskData = {}
                let zipNum =
                    _.get(data, 'ZIP_NUM').substring(0, 3) +
                    '-' +
                    _.get(data, 'ZIP_NUM').substring(3)
                gdskData.rdAddr =
                    zipNum +
                    ' ' +
                    _.get(data, 'RD_ADDR1') +
                    ' ' +
                    _.get(data, 'RD_ADDR2')
                gdskData.aftrAddr =
                    zipNum +
                    ' ' +
                    _.get(data, 'ADDR_AFTR1') +
                    ' ' +
                    _.get(data, 'ADDR_AFTR2')
                gdskData.addr = _.get(data, 'ADDR')
                gdskData.rdAddr1 = _.get(data, 'RD_ADDR1')
                gdskData.rdAddr2 = _.get(data, 'RD_ADDR2')
                gdskData.addrAftr1 = _.get(data, 'ADDR_AFTR1')
                gdskData.addrAftr2 = _.get(data, 'ADDR_AFTR2')
                gdskData.addrAftrEtc = _.get(data, 'ADDR_AFTR_ETC')
                gdskData.doNm = _.get(data, 'DO_NM')
                gdskData.ctNm = _.get(data, 'CT_NM')
                gdskData.bDngNm = _.get(data, 'B_DNG_NM')
                gdskData.bRiNm = _.get(data, 'B_RI_NM')
                gdskData.lotSb = _.get(data, 'LOT_SB')
                gdskData.lotMb = _.get(data, 'LOT_MB')
                gdskData.hDngNm = _.get(data, 'H_DNG_NM')
                gdskData.rdNm = _.get(data, 'RD_NM')
                gdskData.bldMb = _.get(data, 'BLD_MB')
                gdskData.bldSb = _.get(data, 'BLD_SB')
                gdskData.bldNm = _.get(data, 'BLD_NM')
                gdskData.bldDng = _.get(data, 'BLD_DNG')
                gdskData.bldHo = _.get(data, 'BLD_HO')
                gdskData.bldFlr = _.get(data, 'BLD_FLR')
                gdskData.zipNum = _.get(data, 'ZIP_NUM')
                gdskData.basId = _.get(data, 'BAS_ID')
                gdskJson.push(gdskData)
            })
            this.gridObj2.dataProvider.fillJsonData(gdskJson, {})
            this.gridObj2.gridView.checkItem(0, true)
        },
        xmlhttpPost(url, search, rtn) {
            store.dispatch('setApiLoading', true)
            var xmlHttpReq = this.createXMLHttpRequest()
            xmlHttpReq.open('POST', this.addr + url, true)
            xmlHttpReq.setRequestHeader(
                'Content-Type',
                'application/x-www-form-urlencoded; charset=utf-8'
            )
            xmlHttpReq.onreadystatechange = () => {
                if (xmlHttpReq.readyState === XMLHttpRequest.DONE) {
                    if (xmlHttpReq.status === 200) {
                        //console.log(xmlHttpReq.responseText)
                        if (rtn === 'setDo') {
                            this.setDo(xmlHttpReq.responseText)
                        } else if (rtn === 'setSi') {
                            this.setSi(xmlHttpReq.responseText)
                        } else if (rtn === 'fsearch1' || rtn === 'fsearch2') {
                            this.setAddress(xmlHttpReq.responseText, rtn)
                        } else if (rtn === 'setGdsk') {
                            this.setGdsk(xmlHttpReq.responseText)
                        }
                        store.dispatch('setApiLoading', false)
                    } else {
                        console.log(xmlHttpReq.status, xmlHttpReq.statusText)
                        store.dispatch('setApiLoading', false)
                    }
                } else {
                    store.dispatch('setApiLoading', false)
                }
            }
            xmlHttpReq.send(search)
        },
        createXMLHttpRequest() {
            var xmlHttp = null
            if (window.XMLHttpRequest) {
                xmlHttp = new XMLHttpRequest()
            }
            return xmlHttp
        },
    },
}
</script>
<style>
.realgrid-pre-wrap {
    white-space: pre-wrap;
}
</style>
