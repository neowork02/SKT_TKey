<template>
    <div class="content">
        <!-- Tit -->
        <h1>{{ this.CONSTANTS.SYSTEM_NM }} 게시판</h1>
        <!-- // Tit -->
        <RgstPopup
            v-if="showBasBbsRegMgmt"
            ref="popup"
            :dialogShow.sync="showBasBbsRegMgmt"
            @confirm="onReturnData"
        />
        <DetailPopup
            v-if="showBasBbsDetailMgmt === true"
            ref="popup"
            :dialogShow.sync="showBasBbsDetailMgmt"
            :popupParams.sync="popupParams"
            @confirm="onReturnData"
        />
        <AdmRgstPopup
            v-if="showAdmBbsRegPop"
            ref="popup"
            :dialogShow.sync="showAdmBbsRegPop"
            @confirm="onReturnData"
        />
        <BbsModifyPop
            v-if="showBbsModify === true"
            ref="popup"
            :dialogShow.sync="showBbsModify"
            :popupParams.sync="popupParams"
            @confirm="onReturnData"
        />
        <AdmBbsModifyPop
            v-if="showAdmBbsModify === true"
            ref="popup"
            :dialogShow.sync="showAdmBbsModify"
            :popupParams.sync="popupParams"
            @confirm="onReturnData"
        />
        <!--  <ul class="btn_area top">
           <li class="right">
                <TCComButton eClass="btn_ty01" @click="initBtn"
                    >초기화</TCComButton
                >
                <TCComButton eClass="btn_ty01" @click="searchList"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    @click="newBoard"
                    v-show="showRegBtn"
                    >등록</TCComButton
                >
            </li> 
        </ul>-->
        <!-- // Top BTN -->
        <TCComTab
            :tab.sync="guideTab"
            :items="items"
            :itemName="itemName"
            :tabColor="tabColor"
            :textColor="textColor"
            :centered="centered"
            :grow="grow"
            :height="height"
            :hideSlider="hideSlider"
            :sliderColor="sliderColor"
            :vertical="vertical"
            :objAuth="objAuth"
            sliderSize="8"
            :cKey="0"
            @change="changeType"
            :chkAuthTab="0"
        >
            <template #Template0>
                <div class="searchLayer_wrap mt20">
                    <div class="searchform">
                        <!-- item 1-1 -->
                        <div class="formitem div4">
                            <TCComDatePicker
                                calType="D"
                                labelName="등록일자"
                                :eRequired="false"
                                v-model="forms.insDtm"
                            />
                        </div>
                        <!-- //item 1-1 -->
                        <!-- item 1-2 -->
                        <div class="formitem div4">
                            <TCComInput
                                labelName="제목"
                                v-model="forms.textTitle"
                            >
                            </TCComInput>
                        </div>
                        <div class="formitem div4">
                            <TCComInput labelName="내용" v-model="forms.bbsDtl">
                            </TCComInput>
                        </div>
                        <!-- //item 1-2 -->
                    </div>
                </div>
                <div class="gridWrap">
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="대리점공지사항"
                        :gridObj="gridObj"
                    >
                        <!-- TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                        <template #gridElementArea>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="initBtn"
                                labelName="초기화"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="searchList"
                                labelName="조회"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_addedit"
                                @click="newBoard"
                                labelName="신규"
                                v-show="!showAdmin"
                            />
                        </template>
                        <!-- //TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                    </TCRealGridHeader>

                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :editable="true"
                        :movable="false"
                        :columnMovable="false"
                        :fields="view.fields"
                        :columns="view.columns"
                        :isGridReSize="true"
                    />
                </div>
                <div class="pagingWrap">
                    <TCComPaging
                        :totalPage="gridData.totalPage"
                        :apiFunc="getBasBbsMgmtList0"
                        :rowCnt="rowCnt"
                        @input="chgRowCnt"
                    />
                </div>
            </template>
            <template #Template1>
                <div class="searchLayer_wrap mt20">
                    <div class="searchform">
                        <!-- item 1-1 -->
                        <div class="formitem div4">
                            <TCComDatePicker
                                calType="D"
                                labelName="등록일자"
                                :eRequired="false"
                                v-model="forms.insDtm"
                            />
                        </div>
                        <!-- //item 1-1 -->
                        <div class="formitem div4">
                            <TCComComboBox
                                labelName="정책게시판구분"
                                :itemList="bbsTypeList"
                                v-model="forms.searchBbsTypeCd"
                                v-show="showTypeList"
                                blankItemText="전체"
                                blankItemValue="P"
                            ></TCComComboBox>
                        </div>
                        <!-- item 1-2 -->
                        <div class="formitem div4">
                            <TCComInput
                                labelName="제목"
                                v-model="forms.textTitle"
                            >
                            </TCComInput>
                        </div>
                        <div class="formitem div4">
                            <TCComInput labelName="내용" v-model="forms.bbsDtl">
                            </TCComInput>
                        </div>
                        <!-- //item 1-2 -->
                    </div>
                </div>
                <div class="gridWrap">
                    <TCRealGridHeader
                        id="gridHeader2"
                        ref="gridHeader2"
                        gridTitle="정책게시판"
                        :gridObj="gridObj2"
                    >
                        <!-- TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                        <template #gridElementArea>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="initBtn"
                                labelName="초기화"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="searchList"
                                labelName="조회"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_addedit"
                                @click="newBoard"
                                labelName="신규"
                                v-show="!showAdmin"
                            />
                        </template>
                        <!-- //TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid2"
                        ref="grid2"
                        :editable="true"
                        :movable="false"
                        :columnMovable="false"
                        :fields="view2.fields"
                        :columns="view2.columns"
                        :isGridReSize="true"
                        @hook:mounted="tabGridMounted"
                    />
                </div>
                <div class="pagingWrap">
                    <TCComPaging
                        :totalPage="gridData2.totalPage"
                        :apiFunc="getBasBbsMgmtList1"
                        :rowCnt2="rowCnt2"
                        @input="chgRowCnt2"
                    />
                </div>
            </template>
            <template #Template2>
                <div class="searchLayer_wrap mt20">
                    <div class="searchform">
                        <!-- item 1-1 -->
                        <div class="formitem div4">
                            <TCComDatePicker
                                calType="D"
                                labelName="등록일자"
                                :eRequired="false"
                                v-model="forms.insDtm"
                            />
                        </div>
                        <!-- //item 1-1 -->
                        <!-- item 1-2 -->
                        <div class="formitem div4">
                            <TCComInput
                                labelName="제목"
                                v-model="forms.textTitle"
                            >
                            </TCComInput>
                        </div>
                        <div class="formitem div4">
                            <TCComInput labelName="내용" v-model="forms.bbsDtl">
                            </TCComInput>
                        </div>
                        <!-- //item 1-2 -->
                    </div>
                </div>
                <div class="gridWrap">
                    <TCRealGridHeader
                        id="gridHeader3"
                        ref="gridHeader3"
                        gridTitle="시스템공지사항"
                        :gridObj="gridObj3"
                    >
                        <!-- TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                        <template #gridElementArea>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="initBtn"
                                labelName="초기화"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="searchList"
                                labelName="조회"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_addedit"
                                @click="newBoard"
                                labelName="신규"
                                v-show="showAdmin"
                            />
                        </template>
                        <!-- //TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid3"
                        ref="grid3"
                        :editable="true"
                        :movable="false"
                        :columnMovable="false"
                        :fields="view3.fields"
                        :columns="view3.columns"
                        :isGridReSize="true"
                        @hook:mounted="tabGridMounted2"
                    />
                </div>
                <div class="pagingWrap">
                    <TCComPaging
                        :totalPage="gridData3.totalPage"
                        :apiFunc="getBasBbsMgmtList2"
                        :rowCnt3="rowCnt3"
                        @input="chgRowCnt3"
                    />
                </div>
            </template>
            <template #Template3>
                <div class="searchLayer_wrap mt20">
                    <div class="searchform">
                        <!-- item 1-1 -->
                        <div class="formitem div4">
                            <TCComDatePicker
                                calType="D"
                                labelName="등록일자"
                                :eRequired="false"
                                v-model="forms.insDtm"
                            />
                        </div>
                        <!-- //item 1-1 -->
                        <!-- item 1-2 -->
                        <div class="formitem div4">
                            <TCComInput
                                labelName="제목"
                                v-model="forms.textTitle"
                            >
                            </TCComInput>
                        </div>
                        <div class="formitem div4">
                            <TCComInput labelName="내용" v-model="forms.bbsDtl">
                            </TCComInput>
                        </div>
                        <!-- //item 1-2 -->
                    </div>
                </div>
                <div class="gridWrap">
                    <TCRealGridHeader
                        id="gridHeader4"
                        ref="gridHeader4"
                        gridTitle="기능개선요청게시판"
                        :gridObj="gridObj4"
                    >
                        <!-- TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                        <template #gridElementArea>
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="initBtn"
                                labelName="초기화"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_basic"
                                @click="searchList"
                                labelName="조회"
                            />
                            <TCComButton
                                :Vuetify="false"
                                eClass="btn_noline btn_ty04"
                                eAttr="ico_addedit"
                                @click="newBoard"
                                labelName="신규"
                            />
                        </template>
                        <!-- //TCRealGridHeader 영역에 버튼 추가될 경우_오른쪽 -->
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid4"
                        ref="grid4"
                        :editable="true"
                        :movable="false"
                        :columnMovable="false"
                        :fields="view4.fields"
                        :columns="view4.columns"
                        :isGridReSize="true"
                        @hook:mounted="tabGridMounted3"
                    />
                </div>
                <div class="pagingWrap">
                    <TCComPaging
                        :totalPage="gridData4.totalPage"
                        :apiFunc="getBasBbsMgmtList3"
                        :rowCnt3="rowCnt4"
                        @input="chgRowCnt4"
                    />
                </div>
            </template>
        </TCComTab>
    </div>
</template>

<style>
/* @import '@/node_modules/realgrid/dist/realgrid-style.css'; */
</style>

<script>
import { CommonGrid } from '@/utils'
import {
    BAS_BBS_LIST_NOTICE_HEADER,
    BAS_BBS_LIST_POL_HEADER,
    BAS_BBS_LIST_SST_HEADER,
    BAS_BBS_LIST_IPM_HEADER,
} from '@/const/grid/bas/bbs/basBbsMgmtHeader'
// import _ from 'lodash'
import CommonMixin from '@/mixins'
import basBbsMgmtApi from '@/api/biz/bas/bbs/basBbsMgmt'
import RgstPopup from '@/views/biz/bas/bbs/BasBbsRegMgmt'
import DetailPopup from '@/views/biz/bas/bbs/BasBbsDetailMgmt'
import AdmRgstPopup from '@/views/biz/bas/bbs/BasAdmReg'
import BbsModifyPop from '@/views/biz/bas/bbs/BasBbsModify'
import AdmBbsModifyPop from '@/views/biz/bas/bbs/AdmBbsModify'
//import store from '@/store/biz/bas/bco/agencysMgmt'
export default {
    name: 'BasBbsMgmt',
    mixins: [CommonMixin],
    components: {
        RgstPopup,
        AdmRgstPopup,
        DetailPopup,
        BbsModifyPop,
        AdmBbsModifyPop,
    },
    data() {
        return {
            guideTab: 0,
            items: ['Template0', 'Template1', 'Template2', 'Template3'],
            itemName: [
                '대리점공지사항',
                '정책게시판',
                '시스템공지사항',
                '기능개선요청게시판',
            ],
            inputValue: '2021-01-01',
            search: '',
            tabColor: '',
            textColor: '',
            height: '',
            sliderColor: '',
            centered: false,
            grow: false,
            hideSlider: false,
            vertical: false,
            rowCnt: 30,
            rowCnt2: 30,
            rowCnt3: 30,
            rowCnt4: 30,
            activePage: 1, // 현재페이지
            //Grid Class init
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            gridData2: {},
            gridObj2: {},
            gridHeaderObj2: {},
            gridData3: {},
            gridObj3: {},
            gridHeaderObj3: {},
            gridData4: {},
            gridObj4: {},
            gridHeaderObj4: {},
            view: BAS_BBS_LIST_NOTICE_HEADER,
            view2: BAS_BBS_LIST_POL_HEADER,
            view3: BAS_BBS_LIST_SST_HEADER,
            view4: BAS_BBS_LIST_IPM_HEADER,
            toggleActive: false,
            showRegBtn: true,
            showTab: true,
            objAuth: {},
            forms: { searchBbsTypeCd: 'P' },
            popupParams: {
                bbsNo: '',
                bbsTypeCd: '',
                bbsDtl: '',
                textTitle: '',
                insDtm: '',
            },
            userNm: '',
            showNext: false,
            showBasBbsRegMgmt: false,
            showAdmBbsRegPop: false,
            showBasBbsDetailMgmt: false,
            showTypeList: false,
            showBbsModify: false,
            showAdmBbsModify: false,
            showAdmin: false,
        }
    },

    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        //시작시 세션정보 조직정보에 담는다.
        /*
        this.searchParam.orgCd = this.orgInfo.orgCd
        this.searchParam.orgNm = this.orgInfo.orgNm
        this.searchParam.orgLvl = this.orgInfo.orgLvl
        this.searchParam.orgClCd = this.orgInfo.orgLvl
        */
        /****************** Grid **********************/
        //Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            if ('data' === clickData.cellType) {
                this.grdListOnCellblClick(clickData.dataRow)
            }
        }
        //인디게이터 상태바 체크바 사용여부 default false 설정
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        //Default false
        this.gridObj.setGridState(true, false, false, false)
        this.getBasBbsMgmtList0(1)
        // if (this.userInfo.userId == 'TDCS_43') {
        //     this.showRegBtn = true
        //     this.showTab = false
        // }
        //N -> TAB0, D -> TAB1, S-> TAB2
        let bbsTypeCd = this.$route.params.bbsTypeCd
        //N -> TAB0, DS -> TAB1, A-> TAB2, I-> TAB3
        if ('DS' == bbsTypeCd) {
            this.guideTab = 1
        } else if ('A' == bbsTypeCd) {
            this.guideTab = 2
        } else if ('I' == bbsTypeCd) {
            this.guideTab = 3
        }

        if ('ADMIN' == this.orgInfo.orgCd) {
            this.showAdmin = true
        }

        //시작시 정책게시판 show여부 확인
        this.changeType()
        //메인 -> 해당 탭이동.
        // if (this.userInfo.userId == 'TDCS_43') {
        //     this.items = ['Template0']
        //     this.itemName = ['공지게시판']
        // }
    },
    computed: {
        bbsTypeList() {
            return [
                { commCdVal: 'P', commCdValNm: '전체' },
                { commCdVal: 'D', commCdValNm: '도매' },
                { commCdVal: 'S', commCdValNm: '소매' },
                { commCdVal: 'B', commCdValNm: '대형' },
            ]
        },
    },
    methods: {
        init: function () {
            this.gridData = this.gridSetData()
        },
        changeType() {
            if (this.guideTab == 1) {
                this.showTypeList = true
            } else {
                this.showTypeList = false
            }
        },
        searchList() {
            if (this.guideTab == 0) {
                //this.bbsTypeCd = 'N'
                this.getBasBbsMgmtList0()
            } else if (this.guideTab == 1) {
                //this.bbsTypeCd = 'P'
                this.getBasBbsMgmtList1()
            } else if (this.guideTab == 2) {
                //this.bbsTypeCd = 'A'
                this.getBasBbsMgmtList2()
            } else if (this.guideTab == 3) {
                //this.bbsTypeCd = 'I'
                this.getBasBbsMgmtList3()
            }
        },
        async newBoard() {
            if (this.guideTab == 0) {
                //this.bbsTypeCd = 'N'
                this.showAdmBbsRegPop = true
            } else if (this.guideTab == 1) {
                this.showBasBbsRegMgmt = true
            } else if (this.guideTab == 2) {
                //this.bbsTypeCd = 'A'
                this.showAdmBbsRegPop = true
            } else if (this.guideTab == 3) {
                //this.bbsTypeCd = 'I'
                this.showAdmBbsRegPop = true
            }
        },
        // tabGridClick(tabIdx) {
        //     console.log('onActiveTabChange: ', tabIdx)
        //     if (tabIdx == '0') {
        //         if (this.userInfo.userId == 'TDCS_43') {
        //             this.showRegBtn = true
        //         } else {
        //             this.showRegBtn = false
        //         }
        //     } else {
        //         this.showRegBtn = true
        //     }
        // },
        //2번째 탭 클릭시 그리드 Mounted 후 실행
        //@hook:mounted
        tabGridMounted() {
            this.gridObj2 = this.$refs.grid2
            this.gridHeaderObj2 = this.$refs.gridHeader2
            this.gridObj2.setGridState(true, false, false, false)
            this.gridObj2.gridView.onCellClicked = (grid2, clickData) => {
                if ('data' === clickData.cellType) {
                    this.grdListOnCellblClick1(clickData.dataRow)
                }
            }
            this.getBasBbsMgmtList1()

            //this.popupParams.bbsTypeCd = 'D'
        },
        //3번째 탭 클릭시 그리드 Mounted 후 실행
        //@hook:mounted
        tabGridMounted2() {
            this.gridObj3 = this.$refs.grid3
            this.gridHeaderObj3 = this.$refs.gridHeader3
            this.gridObj3.setGridState(true, false, false, false)
            this.gridObj3.gridView.onCellClicked = (grid3, clickData) => {
                if ('data' === clickData.cellType) {
                    this.grdListOnCellblClick2(clickData.dataRow)
                }
            }
            this.getBasBbsMgmtList2()

            //this.popupParams.bbsTypeCd = 'S'
        },
        //4번째 탭 클릭시 그리드 Mounted 후 실행
        //@hook:mounted
        tabGridMounted3() {
            this.gridObj4 = this.$refs.grid4
            this.gridHeaderObj4 = this.$refs.gridHeader4
            this.gridObj4.setGridState(true, false, false, false)
            this.gridObj4.gridView.onCellClicked = (grid4, clickData) => {
                if ('data' === clickData.cellType) {
                    this.grdListOnCellblClick3(clickData.dataRow)
                }
            }
            this.getBasBbsMgmtList3()

            //this.popupParams.bbsTypeCd = 'S'
        },
        grdListOnCellblClick: function (dataRow) {
            let row = this.gridObj.dataProvider.getJsonRow(dataRow, true)

            this.popupParams.bbsNo = row.bbsNo

            this.showBasBbsDetailMgmt = true
        },
        grdListOnCellblClick1: function (dataRow) {
            let row = this.gridObj2.dataProvider.getJsonRow(dataRow, true)

            this.popupParams.bbsNo = row.bbsNo
            this.showBasBbsDetailMgmt = true
        },
        grdListOnCellblClick2: function (dataRow) {
            let row = this.gridObj3.dataProvider.getJsonRow(dataRow, true)

            this.popupParams.bbsNo = row.bbsNo
            this.showBasBbsDetailMgmt = true
        },
        grdListOnCellblClick3: function (dataRow) {
            let row = this.gridObj4.dataProvider.getJsonRow(dataRow, true)

            this.popupParams.bbsNo = row.bbsNo
            this.showBasBbsDetailMgmt = true
        },
        //Grid Init
        gridSetData: function (rowCnt) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, rowCnt, '', '')
        },
        gridSetData2: function (rowCnt2) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, rowCnt2, '', '')
        },
        gridSetData3: function (rowCnt3) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, rowCnt3, '', '')
        },
        gridSetData4: function (rowCnt4) {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, rowCnt4, '', '')
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        chgRowCnt2(val) {
            this.rowCnt2 = val
        },
        chgRowCnt3(val) {
            this.rowCnt3 = val
        },
        chgRowCnt4(val) {
            this.rowCnt4 = val
        },
        initBtn() {
            this.forms.bbsDtl = ''
            this.forms.textTitle = ''
            this.forms.insDtm = ''

            if (this.guideTab == 0) {
                //대리점공지사항
                //this.gridObj.dataProvider.clearRows()
                this.getBasBbsMgmtList0()
            }
            if (this.guideTab == 1) {
                //정책게시판
                this.getBasBbsMgmtList1()
                //this.gridObj2.dataProvider.clearRows()
            }
            if (this.guideTab == 2) {
                //시스템공지사항
                this.getBasBbsMgmtList2()
                //this.gridObj3.dataProvider.clearRows()
            }
            if (this.guideTab == 3) {
                //기능개선요청게시판
                this.getBasBbsMgmtList3()
                //this.gridObj4.dataProvider.clearRows()
            }
        },
        // API 호출
        async getBasBbsMgmtList0(page) {
            //대리점공지사항
            this.forms.pageSize = this.rowCnt
            this.forms.pageNum = page //첫번째 페이지
            this.forms.bbsTypeCd = 'N'
            await basBbsMgmtApi.getBasBbsMgmt(this.forms).then((resultData) => {
                this.gridObj.setRows(resultData.gridList)
                this.gridObj.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData() //초기화
                this.gridData.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                // //Grid Row 가져올때 총건수 Setting
                this.gridHeaderObj.setPageCount(resultData.pagingDto)

                //this.gridObj.gridView.setRowStyleCallback()
            })
        },
        // API 호출
        async getBasBbsMgmtList1(page) {
            //정책게시판
            this.forms.pageSize = this.rowCnt2
            this.forms.pageNum = page //두번째 페이지

            //alert('getBasBbsMgmtList1' + this.forms.searchBbsTypeCd)
            this.forms.bbsTypeCd = this.forms.searchBbsTypeCd
            await basBbsMgmtApi.getBasBbsMgmt(this.forms).then((resultData) => {
                if (resultData.gridList.length) {
                    for (let i = 0; i < resultData.gridList.length; i++) {
                        if (resultData.gridList[i].bbsTypeCd == 'S') {
                            //console.log('::::::::::', rowData)
                            resultData.gridList[i].bbsTypeCd = '소매'
                        } else if (resultData.gridList[i].bbsTypeCd == 'D') {
                            resultData.gridList[i].bbsTypeCd = '도매'
                        } else if (resultData.gridList[i].bbsTypeCd == 'B') {
                            resultData.gridList[i].bbsTypeCd = '대형'
                        }
                    }
                }
                this.gridObj2.setRows(resultData.gridList)
                this.gridObj2.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData2 = this.gridSetData2() //초기화
                this.gridData2.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                //Grid Row 가져올때 총건수 Setting
                this.gridHeaderObj2.setPageCount(resultData.pagingDto)
            })
        },
        /*
        getBasBbsPolMgmtList(page) {
            //정책게시판
            this.forms.pageSize = this.rowCnt2
            this.forms.pageNum = page //두번째 페이지
            basBbsMgmtApi.getBasBbsMgmt(this.forms).then((resultData) => {
                if (resultData.gridList.length) {
                    for (let i = 0; i < resultData.gridList.length; i++) {
                        if (resultData.gridList[i].bbsTypeCd == 'S') {
                            //console.log('::::::::::', rowData)
                            resultData.gridList[i].bbsTypeCd = '소매'
                        } else if (resultData.gridList[i].bbsTypeCd == 'D') {
                            resultData.gridList[i].bbsTypeCd = '도매'
                        } else if (resultData.gridList[i].bbsTypeCd == 'B') {
                            resultData.gridList[i].bbsTypeCd = '대형'
                        }
                    }
                }
                this.gridObj2.setRows(resultData.gridList)
                this.gridObj2.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData2 = this.gridSetData2() //초기화
                this.gridData2.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                //Grid Row 가져올때 총건수 Setting
                this.gridHeaderObj2.setPageCount(resultData.pagingDto)
            })
        },
        */
        // API 호출
        async getBasBbsMgmtList2(page) {
            //시스템공지사항
            this.forms.pageSize = this.rowCnt3
            this.forms.pageNum = page //세번째 페이지
            this.forms.bbsTypeCd = 'A'
            await basBbsMgmtApi
                .getBasBbsAdmMgmtList(this.forms)
                .then((resultData) => {
                    this.gridObj3.setRows(resultData.gridList)
                    this.gridObj3.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData3 = this.gridSetData3() //초기화
                    this.gridData3.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    //Grid Row 가져올때 총건수 Setting
                    this.gridHeaderObj3.setPageCount(resultData.pagingDto)
                })
        },
        async getBasBbsMgmtList3(page) {
            //기능개선요청게시판
            this.forms.pageSize = this.rowCnt4
            this.forms.pageNum = page //네번째 페이지
            this.forms.bbsTypeCd = 'I'
            await basBbsMgmtApi
                .getBasBbsAdmMgmtList(this.forms)
                .then((resultData) => {
                    this.gridObj4.setRows(resultData.gridList)
                    this.gridObj4.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData4 = this.gridSetData4() //초기화
                    this.gridData4.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    //Grid Row 가져올때 총건수 Setting
                    this.gridHeaderObj4.setPageCount(resultData.pagingDto)
                })
        },
        async onReturnData(retrunData) {
            console.log('retrunData: ', retrunData)

            if (this.guideTab == 0) {
                //대리점공지사항
                await this.getBasBbsMgmtList0()
            }
            if (this.guideTab == 1) {
                //this.gridObj2.dataProvider.clearRows()
                //정책게시판
                await this.getBasBbsMgmtList1()
            }
            if (this.guideTab == 2) {
                //시스템공지사항
                await this.getBasBbsMgmtList2()
            }
            if (this.guideTab == 3) {
                //기능개선요청게시판
                await this.getBasBbsMgmtList3()
            }

            //this.showTcComAlert('저장되었습니다.')

            //this.searchParam.agencyCd = _.get(retrunData, 'agencyCd')
            //this.searchParam.agencyNm = _.get(retrunData, 'agencyNm')
        },
    },
}
</script>
