<!-----------------------------------------------
 * 업무그룹명: 바로도착Master관리>바로도착 재고 연동관리
 * 서브업무명: 바로도착 권역별 제한상품 입력
 * 설명: 바로도착 권역별 제한상품 입력
 * 작성자: P179237
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="450px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">바로도착 권역별 제한상품 입력</p>
                <div class="layerCont">
                    <div class="contBoth">
                        <div class="searchLayer_wrap">
                            <div class="searchform">
                                <div class="formitem">
                                    <TCComComboBox
                                        labelName="권역"
                                        :eRequired="true"
                                        codeId="ZBAS_C_00820"
                                        :objAuth="objAuth"
                                        v-model="dsConditionPopup.rgnCd"
                                    />
                                </div>
                            </div>
                            <div class="searchform">
                                <div class="formitem">
                                    <TCComInputSearchText
                                        v-model="dsConditionPopup.prodCd"
                                        :codeVal.sync="dsConditionPopup.prodNm"
                                        labelName="모델"
                                        :eRequired="true"
                                        :disabledAfter="true"
                                        :objAuth="objAuth"
                                        @enterKey="onProdsEnterKey"
                                        @appendIconClick="onProdsIconClick"
                                        @input="onProdsInput"
                                    />
                                    <BasBcoProdsPopup
                                        v-if="basBcoProdsShow"
                                        :parentParam="dsConditionPopup"
                                        :rows="resultProdsRows"
                                        :dialogShow.sync="basBcoProdsShow"
                                        @confirm="onProdsReturnData"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty01"
                            :objAuth="objAuth"
                            @click="cfSave()"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty01"
                            :objAuth="objAuth"
                            @click="closeBtn"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                    <!-- Close BTN-->
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="closeBtn()"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<script>
import CommonMixin from '@/mixins'
import _ from 'lodash'

import api from '@/api/biz/dis/dsm/disDsmDarrvlDisLnkgMgmt'
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================

export default {
    name: 'DisDsmDarrvlDisLnkgRgst',
    mixins: [CommonMixin],
    components: { BasBcoProdsPopup },
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            dsConditionPopup: { prodCd: '', prodNm: '' },

            objAuth: {},
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            //====================//상품팝업관련==================
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    created() {},
    mounted() {},
    methods: {
        cfSave: function () {
            console.log('저장누름')
            if (this.fCheckCondition()) {
                const formData = {
                    dsCondition: {
                        rowData: {
                            ...this.dsConditionPopup,
                        },
                    },
                }

                api.saveRgnRstProdIns(formData).then((resultData) => {
                    console.log(resultData)
                })
            }
        },
        fCheckCondition: function () {
            if (_.isEmpty(this.dsConditionPopup.rgnCd)) {
                this.showTcComAlert('권역을 입력하여 주시기 바랍니다.')
                return false
            }

            if (_.isEmpty(this.dsConditionPopup.prodCd)) {
                this.showTcComAlert('모델을 입력하여 주시기 바랍니다.')
                return false
            }
            return true
        },
        closeBtn: function () {
            this.$emit('confirm', true)
            this.activeOpen = false
        },
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.dsConditionPopup).then((res) => {
                console.log('getProdsList : ', res)
                if (res === undefined) return
                if (res.length === 1) {
                    this.dsConditionPopup.prodCd = _.get(res[0], 'prodCd')
                    this.dsConditionPopup.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.dsConditionPopup.prodCd)) {
                this.getProdsList()
                this.basBcoProdsShow = true
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 TextField 엔터키 이벤트 처리
        onProdsEnterKey() {
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 상품명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.dsConditionPopup.prodCd)) {
                this.onProdsIconClick()
            }
            // 상품팝업 정보 조회
            this.getProdsList()
        },
        // 상품팝업 TextField Input 이벤트 처리
        onProdsInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.dsConditionPopup.prodNm = ''
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.dsConditionPopup.prodCd = _.get(retrunData, 'prodCd')
            this.dsConditionPopup.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
