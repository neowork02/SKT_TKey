<template>
    <div>
        <ul class="btn_area top">
            <!-- <li class="left">
                <v-btn outlined class="btn_ty">삭제</v-btn>
            </li> -->
            <!-- <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="initBtn"
                    :objAuth="objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="saveBtn"
                    :objAuth="objAuth"
                >
                    저장
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onClose"
                    :objAuth="objAuth"
                >
                    닫기
                </TCComButton>
            </li> -->
        </ul>
    </div>
</template>
<script>
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/docRgst/helpers'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
//import CommonUtil from '@/utils/CommonUtil.js'
import CommonMixin from '@/mixins'
export default {
    mixins: [CommonMixin],
    components: {
        //Detail1Popup,
    },
    async created() {
        //await this.initData()
    },
    data() {
        return {
            objAuth: {},
            calType5: 'DP', //'M' //'DP'
            schdDt: [],
            //clsDt: '',
            fromDt: '',
            toDt: '',
            orgCd: '' /*조직코드*/,
            formSearchParams: {
                orgCd: '' /*조직코드*/,
                orgNm: '',
                orgLvl: '',
                fromDt: '',
                toDt: '',
            },
            readOnly: false,
        }
    },
    async mounted() {
        //화면초기 로딩시 바로 검색
        //this.searchBtn()
    },
    computed: {
        ...serviceComputed,
        popupParams1: {
            get() {
                return this.popupParams
            },
        },
        saveDone1: {
            get() {
                return this.saveDoneA && this.saveDoneB
            },
        },
    },
    methods: {
        ...serviceMethods,
        initObj(obj1) {
            for (let prop in obj1) {
                if (Object.prototype.hasOwnProperty.call(obj1, prop)) {
                    obj1[prop] = ''
                }
            }
        },
        async initData() {
            let today = moment(new Date()).format('YYYY-MM-01')
            let today1 = moment(new Date()).format('YYYY-MM-DD')
            this.schdDt = [today, today1]

            this.initObj(this.formSearchParams)

            await this.defaultAssign_({
                key: 'paging',
                value: this.initPaging,
            })
            await this.defaultAssign_({
                key: 'resultList',
                value: '',
            })
        },
        async initBtn() {
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 122 ~ data ',
                this.$data
            )
            await this.initData()
            //this.searchBtn() //이화면은 초기화가 다시 조회처리

            //CommonUtil.clearPage(this.$router)
        },
        async onClose() {
            console.log('close btn')
            // if (this.userCancelSave) {
            //     this.$emit('confirm', this.saveParam)
            // }
            // this.activeOpen1 = false
            await this.defaultAssign_({
                key: 'popupClose',
                value: true,
            })
        },
        async saveBtn() {
            await this.defaultAssign_({
                key: 'saveAction',
                value: true,
            })
        },
        async searchBtn() {
            // let fromDt = new Date(this.schdDt[0])
            // let toDt = new Date(this.schdDt[1])
            // if (fromDt > toDt) {
            //     this.showTcComAlert('시작일자가 마지막일자 보다 큽니다.')
            //     return
            // }
            // if (
            //     moment(fromDt).format('YYYY-MM') !=
            //     moment(toDt).format('YYYY-MM')
            // ) {
            //     this.showTcComAlert('같은 월 검색만 됩니다.')
            //     return
            // }
            // if (_.isEmpty(this.searchGubun)) {
            //     this.showTcComAlert('조회구분은 필수 입니다.')
            //     return
            // }

            //this.formSearchParams.clsDt = this.clsDt.replace(/-/g, '')
            this.formSearchParams.fromDt = this.schdDt[0].replace(/-/g, '')
            this.formSearchParams.toDt = this.schdDt[1].replace(/-/g, '')

            //this.formSearchParams.orgCd = this.searchOrgParam.orgCd
            //this.formSearchParams.orgLvl = this.searchOrgParam.orgLvl

            await this.defaultAssign_({ key: 'paging', value: this.initPaging })

            this.formSearchParams = {
                ...this.formSearchParams,
            }
            console.log(
                '🚀 ~ file: SearchContainer.vue ~ line 197 ~ searchBtn ~ this.formSearchParams',
                this.formSearchParams
            )
            let par1 = _.clone(this.formSearchParams)

            // Test data
            // let par1 = {
            //     searchGubun: '1',
            //     orgCd: 'AA1311',
            //     orgLvl: '3',
            //     fromDt: '20220201',
            //     toDt: '20220206',
            //     //pageNum: '1',
            //     //pageSize: '15',
            // }

            await this.defaultAssign_({
                key: 'searchParams',
                value: par1,
            })
            await this.searchData()
        },
        async searchData() {
            await this.getBasReqDocRgstList_()
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        async popupParams1(val, oldVal) {
            const param1 = _.clone(val)
            if (_.isEmpty(param1)) return
            console.log('popup search params', _.isEmpty(param1), param1)
            this.readOnly = param1.readOnly

            if (param1.mode != 'new') {
                await this.initData()

                let parentParam1 = {
                    reqDt: param1.reqDt,
                    uuid: param1.uuid,
                }

                const param0 = _.clone(parentParam1)

                let data = await this.getBasReqDocRgstList_({
                    param: param0,
                })
                if (!_.isEmpty(data)) {
                    await this.defaultAssign_({
                        key: 'resultList',
                        value: data,
                    })
                } else {
                    await this.defaultAssign_({
                        key: 'resultList',
                        value: '',
                    })
                    this.showTcComAlert('정보가 없습니다.(조회)')
                    this.onClose()
                }
            } else {
                await this.initData()
                console.log('popup search new', param1)

                //const param1 = _.clone(parentParam1)
                await this.defaultAssign_({
                    key: 'resultList',
                    value: '',
                })
            }
        },
        async saveDone1(val, oldVal) {
            if (val == true) {
                console.log('saveDone1: ', val, oldVal)
                //saveAction 작업들이 모두 완료 되면 default 상태로 변환
                await this.defaultAssign_({
                    key: 'saveAction',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: false,
                })
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: false,
                })
            }
        },
    },
}
</script>
