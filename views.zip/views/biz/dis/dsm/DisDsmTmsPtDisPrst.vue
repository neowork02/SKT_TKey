<!-----------------------------------------------
 * 업무 그룹명 : 재고 재고관리>재고관리현황
 * 서브 업무명 : 종합재고현황
 * 설 명 : 종합재고현황을 조회한다.
 * 작 성 자 : P180182
 * 작 성 일 : 2022.05.23
 * Copyright ⓒ SK TELECOM. All Right Reserved
 ------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>종합 재고 현황</h1>
        <!-- //Tit -->
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left"></li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="iniBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <!-- //Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <!-- Search_line 1 -->
            <div class="searchform">
                <!-- item 1-1 -->
                <div class="formitem div4">
                    <TCComDatePicker
                        calType="D"
                        labelName="기준일자"
                        :eRequired="true"
                        v-model="strdDt"
                        @change="onPrdChange"
                    />
                </div>
                <!-- //item 1-1 -->
                <!-- item 1-2 -->
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.orgNm"
                        :codeVal.sync="reqParam.orgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :objAuth="objAuth"
                        @enterKey="onOrgTreeIconClick"
                        @appendIconClick="onOrgTreeIconClick"
                        @input="onOrgTreeInput"
                        :disabled="orgDisabled"
                        :disabledAfter="true"
                        :eRequired="true"
                    />
                    <BasBcoOrgTreesPopup
                        v-if="showBcoOrgTrees"
                        :parentParam="reqParam"
                        :rows="resultOrgTreeRows"
                        :dialogShow.sync="showBcoOrgTrees"
                        @confirm="onOrgTreeReturnData"
                    />
                </div>
                <!-- //item 1-2 -->
                <!-- item 1-3 -->
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="영업담당"
                        :objAuth="this.objAuth"
                        v-model="reqParam.chrgrId"
                        :itemList="chrgrList"
                        itemText="chrgrNm"
                        itemValue="chrgrId"
                        :addBlankItem="true"
                        blankItemText="전체"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-3 -->
                <!-- item 1-4 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00240"
                        labelName="거래처구분"
                        :objAuth="this.objAuth"
                        v-model="reqParam.dealcoClCd"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                    ></TCComComboBox>
                </div>
                <!-- //item 1-4 -->
            </div>
            <!-- //Search_line 1 -->
            <!-- Search_line 2 -->
            <div class="searchform">
                <!-- item 2-1 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        :objAuth="this.objAuth"
                        v-model="reqParam.prodClCd"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-1 -->
                <!-- item 2-2 -->
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="PRCH_TYP_CD"
                        labelName="구매유형"
                        :objAuth="this.objAuth"
                        v-model="reqParam.prchTypCd"
                        :addBlankItem="true"
                        :blankItemText="'전체'"
                        :filterFunc="filterPrchTypFunc"
                    ></TCComComboBox>
                </div>
                <!-- //item 2-2 -->
                <div class="formitem div2"></div>
            </div>
            <!-- //Search_line 2 -->
        </div>
        <!-- //Search_div -->

        <!-- gridWrap -->
        <TCComTab
            :tab.sync="tabIndex"
            :items="items"
            :itemName="itemName"
            :objAuth="this.objAuth"
            sliderSize="8"
            :cKey="0"
            @click="onActiveTabClick"
        >
            <template #item1>
                <TCRealGridHeader
                    id="gridHeader1"
                    ref="gridHeader1"
                    :gridObj="gridObj1"
                    :isPageRows="true"
                    :isExceldown="true"
                    :isNextPage="true"
                    :isPageCnt="true"
                    class="notit"
                    @excelDownBtn="excelDownBtn"
                />
                <TCRealGrid
                    id="grid1"
                    ref="grid1"
                    :fields="gridHeader1.fields"
                    :columns="gridHeader1.columns"
                />
                <TCComPaging
                    :totalPage="gridData1.totalPage"
                    :apiFunc="getStaDisPrstList"
                    :gridObj="gridObj1"
                    :rowCnt="rowCnt1"
                    @input="chgRowCnt"
                />
            </template>
            <template #item2>
                <TCRealGridHeader
                    id="gridHeader2"
                    ref="gridHeader2"
                    :gridObj="gridObj2"
                    :isPageRows="true"
                    :isExceldown="true"
                    :isNextPage="true"
                    :isPageCnt="true"
                    class="notit"
                    @excelDownBtn="excelDownBtn"
                />
                <TCRealGrid
                    id="grid2"
                    ref="grid2"
                    :fields="gridHeader2.fields"
                    :columns="gridHeader2.columns"
                    @hook:mounted="tabGridMounted"
                />
                <TCComPaging
                    :totalPage="gridData2.totalPage"
                    :apiFunc="getStaDisPrstList"
                    :gridObj="gridObj2"
                    :rowCnt="rowCnt2"
                    @input="chgRowCnt"
                />
            </template>
        </TCComTab>

        <!-- Popup -->
        <DtlPopup
            v-if="showDtlPopup"
            ref="popup"
            :dialogShow.sync="showDtlPopup"
            :parentParam="popupParam"
        />
        <!-- Popup -->
    </div>
</template>
<script>
import {
    GRID_HEADER1,
    GRID_LAYOUT1,
    GRID_HEADER2,
    GRID_LAYOUT2,
} from '@/const/grid/dis/dsm/disDsmTmsPtDisPrstHeader.js'
import DtlPopup from './DisDsmTmsPtDisPrstDtlPopup'
import restApi from '@/api/biz/dis/dsm/disDsmTmsPtDisPrst.js'
import rltmDisPrstRestApi from '@/api/biz/dis/dsm/disDsmRltmDisPrst.js'
import attachedFileApi from '@/api/common/attachedFile'
import { CommonGrid, CommonUtil } from '@/utils'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'
//====================내부조직팝업(전체)팝업====================
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
import basBcoOrgTreesApi from '@/api/biz/bas/bco/basBcoOrgTrees'
//====================//내부조직팝업(전체)팝업====================

export default {
    name: 'DisDsmTmsPtDisPrst',
    mixins: [CommonMixin],
    components: {
        DtlPopup,
        BasBcoOrgTreesPopup,
    },
    data() {
        return {
            gridHeader1: GRID_HEADER1,
            gridHeader2: GRID_HEADER2,
            gridData1: {},
            gridData2: {},
            gridObj1: {},
            gridObj2: {},
            gridHeaderObj1: {},
            gridHeaderObj2: {},
            tabIndex: 0,
            items: ['item1', 'item2'],
            itemName: ['거래처 단위', '모델 단위'],
            indicatorOpt: { sort: 'ASC' },
            objAuth: {},
            rowCnt1: 15,
            rowCnt2: 15,
            searchForms: {},
            strdDt: '',
            chrgrList: [
                {
                    chrgrId: '',
                    chrgrNm: '',
                },
            ],
            reqParam: {
                // 요청파라미터
                brwsClCd: '', // 조회구분코드
                strdDt: '', // 기준일자
                dealcoClCd: '', // 거래처구분코드
                prodClCd: '', // 상품구분코드
                orgCd: '', // 조직코드
                orgNm: '', // 조직명
                orgLvl: '', // 조직레벨
                chrgrId: '', // 담당자ID
                prchTypCd: '', // 구매유형코드
            },
            popupParam: {},
            mountedYn: false,
            showDtlPopup: false,
            //====================내부조직팝업(전체)팝업관련====================
            orgDisabled: false,
            showBcoOrgTrees: false,
            resultOrgTreeRows: [],
            //====================//내부조직팝업(전체)팝업관련==================
        }
    },
    watch: {},
    computed: {},
    created() {
        this.gridData1 = this.gridSetData(this.rowCnt1)
        this.gridData2 = this.gridSetData(this.rowCnt2)
    },
    mounted() {
        this.gridObj1 = this.$refs.grid1
        this.gridHeaderObj1 = this.$refs.gridHeader1
        this.gridObj1.setGridState(true)
        this.gridObj1.gridView.setColumnLayout(GRID_LAYOUT1)
        this.gridObj1.gridView.onCellClicked = this.onCellClicked

        this.defaultSet()
    },
    methods: {
        // 화면 default 설정
        defaultSet() {
            // 최초 기준일자 포맷 설정
            this.strdDt = moment(new Date())
                .add(-1, 'days')
                .format('YYYY-MM-DD')

            // 기준일자에 따른 조회관련일자
            this.onPrdChange(this.strdDt)

            this.reqParam.brwsClCd = '1' // 조회구분코드

            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLvl'] = this.orgInfo['orgLvl']

                // 조직의 영업담당자 조회
                this.getSaleChrgrList()

                this.orgDisabled = true
            }
        },
        // Grid Init
        gridSetData(rowCnt) {
            return new CommonGrid(0, rowCnt, '', '')
        },
        // 페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.reqParam.brwsClCd == '1'
                ? (this.rowCnt1 = val)
                : (this.rowCnt2 = val)
        },
        //2번째 탭 클릭시 그리드 Mounted 후 실행
        //@hook:mounted
        tabGridMounted() {
            this.gridObj2 = this.$refs.grid2
            this.gridHeaderObj2 = this.$refs.gridHeader2
            this.gridObj2.setGridState(true)
            this.gridObj2.gridView.setColumnLayout(GRID_LAYOUT2)
            this.gridObj2.gridView.onCellClicked = this.onCellClicked

            this.mountedYn = true
        },
        // 구매유형코드 필터
        filterPrchTypFunc(items) {
            return items.filter((item) => item['commCdVal'] != 'PT03')
        },
        // 영업담당자 조회
        getSaleChrgrList() {
            this.chrgrList = []
            rltmDisPrstRestApi.getSaleChrgrList(this.reqParam).then((res) => {
                if (!_.isEmpty(res.gridList)) {
                    this.chrgrList = res.gridList
                } else {
                    this.chrgrList = [
                        {
                            chrgrId: '',
                            chrgrNm: '',
                        },
                    ]
                }
            })
        },
        // 초기화 버튼 이벤트
        iniBtn() {
            this.gridData1 = this.gridSetData(this.rowCnt)
            this.gridObj1.gridInit()
            this.gridHeaderObj1.setPageCount({ totalDataCnt: 0 })

            if (this.mountedYn) {
                this.gridData2 = this.gridSetData(this.rowCnt)
                this.gridObj2.gridInit()
                this.gridHeaderObj2.setPageCount({ totalDataCnt: 0 })
            }

            this.tabIndex = 0

            CommonUtil.clearPage(this, 'reqParam')
            this.defaultSet()
        },
        // 조회 버튼 이벤트
        searchBtn() {
            this.reqParam.strdDt = this.strdDt.replaceAll('-', '') // 기준일자

            // validation 체크
            if (!this.isValidChk()) return false

            // 첫 조회시 표시할 행의 갯수
            this.searchForms = { ...this.reqParam }
            this.searchForms.pageNum = 1 // 첫번째 페이지

            // 이전페이지정보 초기화
            if (this.reqParam.brwsClCd == '1') {
                this.searchForms.pageSize = this.rowCnt1
                this.gridData1.totalPage = 0
            } else {
                this.searchForms.pageSize = this.rowCnt2
                this.gridData2.totalPage = 0
            }
            this.getStaDisPrstList(this.searchForms.pageNum)
        },
        // 종합재고현황 조회
        getStaDisPrstList(page) {
            this.searchForms.pageNum = page

            restApi.getStaDisPrstList(this.searchForms).then((res) => {
                this.$refs['grid' + this.reqParam.brwsClCd].setRows(
                    res.gridList
                )
                this.$refs['grid' + this.reqParam.brwsClCd].setGridIndicator(
                    res.pagingDto,
                    this.indicatorOpt
                )
                this.$refs['gridHeader' + this.reqParam.brwsClCd].setPageCount(
                    res.pagingDto
                )
                if (this.reqParam.brwsClCd == '1') {
                    this.gridData1 = this.gridSetData(this.rowCnt1)
                    this.gridData1.totalPage = res.pagingDto.totalPageCnt
                } else {
                    this.gridData2 = this.gridSetData(this.rowCnt2)
                    this.gridData2.totalPage = res.pagingDto.totalPageCnt
                }
            })
        },
        // Validation 체크
        isValidChk() {
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 입력해 주십시오.')
                return false
            }

            if (_.isEmpty(this.reqParam.strdDt)) {
                this.showTcComAlert('기준일자를 입력해 주십시오.')
                return false
            }

            if (this.reqParam.strdDt < '20151101') {
                this.showTcComAlert('2015년 11월 이전 조회는 할 수 없습니다.')
                return false
            }
            return true
        },
        // 기준일자 변경 이벤트
        onPrdChange(value) {
            this.reqParam.basMth = value.replaceAll('-', '').substring(0, 6)
        },
        // 탭 버튼 이벤트
        onActiveTabClick(tabIndex) {
            this.reqParam.brwsClCd = (tabIndex + 1).toString()
        },
        // Grid ExcelDown
        excelDownBtn() {
            const rowCount =
                this.$refs[
                    'grid' + this.reqParam.brwsClCd
                ].dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-max/resource/dis/dsm/start-point-inventory-excel-download',
                this.reqParam
            )
        },
        // 그리드 선택 이벤트
        onCellClicked(grid, clickData) {
            // 그리드 선택 데이터
            if (clickData.dataRow == undefined) return
            if (grid.getValue(clickData.itemIndex, clickData.column) <= 0)
                return

            var isPopupCall = false
            this.popupParam = grid.getValues(clickData.itemIndex)

            /** [입고]
             *  구매입고, 교품입고, 매출반품입고, 판매취소입고, 이동입고, 재고조정입고
             **/
            if (
                clickData.column == 'mthInQty' ||
                clickData.column == 'chgInCnt' ||
                clickData.column == 'saleRtnCnt' ||
                clickData.column == 'saleOutCnclCnt' ||
                clickData.column == 'movInCnt' ||
                clickData.column == 'disAdjInQty'
            ) {
                this.popupParam.inoutDtlClCd = clickData.column
                this.popupParam.dtlBrwsClCd = 'T' // TOTAL
                this.popupParam.inoutClCd = 'I'
                isPopupCall = true
            }

            /** [출고]
             *  반품출고, 교품출고, 교품반품출고, 매출출고, 판매출고, 판촉출고, 포상비출고, 비품출고,
             *  T.Gift출고, 이동출고, 재고조정출고, 사고단말기등록
             **/
            if (
                clickData.column == 'rtnOutCnt' ||
                clickData.column == 'chgOutCnt' ||
                clickData.column == 'chgRtnOutCnt' ||
                clickData.column == 'saleOutCnt' ||
                clickData.column == 'mthOutQty' ||
                clickData.column == 'prOutCnt' ||
                clickData.column == 'przOutCnt' ||
                clickData.column == 'eqpOutCnt' ||
                clickData.column == 'giftOutCnt' ||
                clickData.column == 'movOutCnt' ||
                clickData.column == 'disAdjOutQty' ||
                clickData.column == 'riskProdRgstCnt'
            ) {
                this.popupParam.inoutDtlClCd = clickData.column
                this.popupParam.dtlBrwsClCd = 'T' // TOTAL
                this.popupParam.inoutClCd = 'O'
                isPopupCall = true
            }

            // 전월재고
            if (clickData.column == 'pmthDisQty') {
                this.popupParam.dtlBrwsClCd = 'B' // BEFORE
                isPopupCall = true
            }

            // 현재고
            if (clickData.column == 'currDisCnt') {
                this.popupParam.dtlBrwsClCd = 'C' // CURRENT
                isPopupCall = true
            }

            if (isPopupCall) {
                this.popupParam.orgCd = this.reqParam.orgCd
                this.popupParam.orgLvl = this.reqParam.orgLvl
                this.popupParam.strdDt = this.reqParam.strdDt
                this.popupParam.dealcoClCd = this.reqParam.dealcoClCd
                this.popupParam.prodClCd = this.reqParam.prodClCd
                this.popupParam.prchTypCd = this.reqParam.prchTypCd

                // 팝업열기
                this.showDtlPopup = true
            }
        },
        //===================== 내부조직팝업(전체)팝업관련 methods ================================
        // 내부조직팝업(전체) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(전체) 팝업 오픈
        getOrgTreeList() {
            basBcoOrgTreesApi.getOrgTreeList(this.reqParam).then((res) => {
                // 검색된 내부조직팝업(전체) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(전체) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(전체) 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.orgCd = _.get(res[0], 'orgCd')
                    this.reqParam.orgNm = _.get(res[0], 'orgNm')
                    this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                } else {
                    this.resultOrgTreeRows = res
                    this.showBcoOrgTrees = true
                }
            })
        },
        // 내부조직팝업(전체) TextField 돋보기 Icon 이벤트 처리
        onOrgTreeIconClick() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이 아니면 내부조직팝업(전체) 정보 조회
            // 그 이외는 내부조직팝업(전체) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getOrgTreeList()
            } else {
                this.showBcoOrgTrees = true
            }
        },
        // 내부조직팝업(전체) TextField Input 이벤트 처리
        onOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(전체) 코드 초기화
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onOrgTreeReturnData(retrunData) {
            this.reqParam.orgCd = _.get(retrunData, 'orgCd')
            this.reqParam.orgNm = _.get(retrunData, 'orgNm')
            this.reqParam.orgLvl = _.get(retrunData, 'orgLvl')

            // 조직의 영업담당자 조회
            this.getSaleChrgrList()
        },
        //===================== //내부조직팝업(전체)팝업관련 methods ================================
    },
}
</script>
