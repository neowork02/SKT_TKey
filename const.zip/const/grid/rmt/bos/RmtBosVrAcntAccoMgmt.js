import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER, // 번호
        },
        {
            fieldName: 'dpstDt', // 입금일자
            dataType: ValueType.TEXT,
            //fieldDatetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'dpstTm', // 입금시간
            dataType: ValueType.TEXT,
            //fieldDatetimeFormat: 'hhmmss',
        },
        {
            fieldName: 'orgNm', // 조직명1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // pt명1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCl1Nm', // 거래처구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstAmt', // 입금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bankCd', // 은행코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bankNm', // 은행명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpsterNm', // 입금자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'acntNo', // 계좌번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstCl', //계좌구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seqNo', //순번
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dealNo', //거래번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'remark', //비고
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'dpstDt',
            fieldName: 'dpstDt',
            editable: false,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입금일자',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            width: '100',
        },
        {
            name: 'dpstTm',
            fieldName: 'dpstTm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '입금시간',
            textFormat: '([0-9]{2})([0-9]{2})([0-9]{2})$;$1:$2:$3',
            // columnDatetimeFormat: 'hh:mm:ss',
            editable: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '330',
            styleName: 'left-column',
            header: '조직명',
            editable: false,
            dataType: ValueType.TEXT,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '조직코드',
            editable: false,
            dataType: ValueType.TEXT,
            visible: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처코드',
            readOnly: true,
            editable: false,
            dataType: ValueType.TEXT,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            header: '거래처명',
            editable: false,
            dataType: ValueType.TEXT,
        },
        {
            name: 'dealcoCl1Nm',
            fieldName: 'dealcoCl1Nm',
            editable: false,
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: '거래처구분',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstAmt',
            header: '입금액',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            editable: false,
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'bankCd',
            fieldName: 'bankCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'bankNm',
            fieldName: 'bankNm',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '은행명',
            editable: false,
        },
        {
            name: 'dpsterNm',
            fieldName: 'dpsterNm',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '입금자명',
            editable: false,
        },
        {
            name: 'dpstCl',
            fieldName: 'dpstCl',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: '계좌구분',
            editable: false,
        },
        {
            name: 'acntNo',
            fieldName: 'acntNo',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '계좌번호',
            editable: false,
        },
        {
            name: 'seqNo',
            fieldName: 'seqNo',
            visible: false,
            type: 'data',
            editable: false,
        },
        {
            name: 'dealNo',
            fieldName: 'dealNo',
            visible: false,
            type: 'data',
        },
        {
            name: 'remark',
            fieldName: 'remark',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
            editable: false,
        },
    ],
    layout: [
        'rowNum',
        'dpstDt',
        'dpstTm',
        'orgNm',
        // 'orgCd',
        'dealcoCd',
        'dealcoNm',
        'dealcoCl1Nm',
        'dpstAmt',
        'bankNm',
        'dpsterNm',
        'acntNo',
        'dpstCl',
        'remark',
    ],
}
