import { ValueType } from 'realgrid'

export const DisUerDisCmpObjMgmtDtl_GRID_HEADER = {
    fields: [
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'polYm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMM', //정책년월
        },
        {
            fieldName: 'polTs',
            dataType: ValueType.TEXT, //정책차수
        },
        {
            fieldName: 'occrDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', //보상일자
        },
        {
            fieldName: 'fixCrdtPrchsPrc',
            dataType: ValueType.NUMBER, //확정여신가
        },
        {
            fieldName: 'occrAmt',
            dataType: ValueType.NUMBER, //재고보상금액
        },
        {
            fieldName: 'lastInoutDtlClVal',
            dataType: ValueType.TEXT, //최종상품이력
        },
        {
            fieldName: 'dstrbEqpClCdVal',
            dataType: ValueType.TEXT, //유통단말여부
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'fstPrchsPlcId',
            dataType: ValueType.TEXT, //매입처코드
        },
        {
            fieldName: 'fstPrchsPlcIdNm',
            dataType: ValueType.TEXT, //매입처
        },
        {
            fieldName: 'fstInFixDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', //최초입고일
        },
        {
            fieldName: 'fstSaleDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', //최초판매일
        },
        {
            fieldName: 'fstCSaleDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', //최초판매취소일자
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //최초입고조직
        },
        {
            fieldName: 'fstInSktCd',
            dataType: ValueType.TEXT, //최초입고처매장코드
        },
        {
            fieldName: 'fstInPlcId',
            dataType: ValueType.TEXT, //최초입고처코드
        },
        {
            fieldName: 'fstInPlcIdNm',
            dataType: ValueType.TEXT, //최초입고처
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            visible: false,
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 120,
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'polYm',
            fieldName: 'polYm',
            header: {
                text: '정책년월',
            },
            datetimeFormat: 'yyyy-MM',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'polTs',
            fieldName: 'polTs',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정책차수',
                showTooltip: false,
            },
        },
        {
            name: 'occrDt',
            fieldName: 'occrDt',
            header: {
                text: '보상일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'fixCrdtPrchsPrc',
            fieldName: 'fixCrdtPrchsPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '확정여신가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'occrAmt',
            fieldName: 'occrAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: 150,
            header: {
                text: '재고보상금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'lastInoutDtlClVal',
            fieldName: 'lastInoutDtlClVal',
            type: 'data',
            width: 150,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최종상품이력',
                showTooltip: false,
            },
        },
        {
            name: 'dstrbEqpClCdVal',
            fieldName: 'dstrbEqpClCdVal',
            type: 'data',
            width: 150,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '유통단말여부',
                showTooltip: false,
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매입처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'fstPrchsPlcId',
            fieldName: 'fstPrchsPlcId',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매입처코드',
                showTooltip: false,
            },
        },
        {
            name: 'fstPrchsPlcIdNm',
            fieldName: 'fstPrchsPlcIdNm',
            type: 'data',
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매입처',
                showTooltip: false,
            },
        },
        {
            name: 'fstInFixDt',
            fieldName: 'fstInFixDt',
            width: 150,
            header: {
                text: '최초입고일',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'fstSaleDt',
            fieldName: 'fstSaleDt',
            width: 150,
            header: {
                text: '최초판매일',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'fstCSaleDt',
            fieldName: 'fstCSaleDt',
            width: 150,
            header: {
                text: '최초판매취소일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: 300,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초입고조직',
                showTooltip: false,
            },
        },
        {
            name: 'fstInSktCd',
            fieldName: 'fstInSktCd',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초입고처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'fstInPlcId',
            fieldName: 'fstInPlcId',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초입고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'fstInPlcIdNm',
            fieldName: 'fstInPlcIdNm',
            type: 'data',
            width: 150,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최초입고처',
                showTooltip: false,
            },
        },
    ],
}
