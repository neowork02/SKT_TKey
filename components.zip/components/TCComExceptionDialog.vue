<!-----------------------------------------------
 * 업무그룹명: ExceptionDialog 컴포넌트
 * 서브업무명: ExceptionDialog 공통함수
 * 설명: ExceptionDialog 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.05.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="getExceptionInfo.show" :size="500">
        <template #content>
            <div class="layerPop">
                <!-- Popup_tit -->
                <p class="popTitle noDraggable">
                    {{ headerText }}
                </p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont alert">
                    <!-- textbox -->
                    <div class="text-box">
                        <p>
                            {{ getExceptionInfo.message }}
                        </p>
                    </div>
                    <!-- //textbox -->
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose">
                        <!-- 닫기 -->
                    </a>
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
                <!-- Popup_BTN :하단 버튼 1개 -->
                <div class="popBtn">
                    <!-- <TCComButton
                        :Vuetify="false"
                        :labelName="confirmText"
                        class="btn_bottom full"
                        @click="onConfirm"
                    >
                    </TCComButton> -->
                    <button
                        ref="alertBtn"
                        type="button"
                        class="btn_bottom full"
                        @click="onConfirm"
                    >
                        <span>{{ confirmText }}</span>
                    </button>
                </div>
                <!-- //Popup_BTN  :하단 버튼 1개-->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
export default {
    inheritAttrs: false,
    name: 'TCComExceptionDialog',
    components: {},
    props: {
        //헤더 내용
        headerText: {
            type: String,
            default: '오류',
            required: false,
        },
        // 하단 '확인' 버튼명
        confirmText: { type: String, default: '확인', required: false },
    },

    data() {
        return {
            dValue: false,
        }
    },
    computed: {
        getExceptionInfo() {
            let getException = this.$store.getters['exception/getException']
            this.$nextTick(() => {
                if (getException.show === true) {
                    this.$refs.alertBtn.focus()
                }
            })
            return getException
        },
    },
    watch: {},
    created() {},
    mounted() {},
    methods: {
        onClose() {
            this.$store.dispatch('exception/resetException')
        },
        onConfirm() {
            this.$store.dispatch('exception/resetException')
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
