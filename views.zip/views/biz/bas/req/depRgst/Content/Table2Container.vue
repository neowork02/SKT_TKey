<template lang="">
    <div id="idTest1GridWap" class="gridWrap">
        <TCRealGridHeader
            id="depRgstTest1Header1"
            ref="depRgstTest1Header1"
            gridTitle="테스트 항목"
            :gridObj="gridObj"
            :isPageRows="true"
            :isExceldown="false"
            :isNextPage="false"
            :isPageCnt="false"
            :editable="!readOnly"
            :isAddRow="!readOnly && !updateOnly"
            :isDelRow="!readOnly && !updateOnly"
            :addData="this.addData"
            @excelDownBtn="this.excelDownBtn"
            @addRowBtn="this.gridAddRowBtn"
            @chkDelRowBtn="this.gridchkDelRowBtn"
        />
        <TCRealGrid
            id="depRgstTest1Grid"
            ref="depRgstTest1Grid"
            :fields="view.fields"
            :columns="view.columns"
            :styles="gridStyle"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/depRgst/helpers'
import { TEST_HEADER } from '@/const/grid/bas/req/basReqDepHeader'
import { CommonGrid } from '@/utils'
import CommonMsg from '@/utils/CommonMsg'
//import { msgTxt } from '@/const/msg.Properties.js'
import moment from 'moment'
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
import CommonMixin from '@/mixins'
// eslint-disable-next-line no-unused-vars
import { CommonUtil } from '@/utils'

export default {
    mixins: [CommonMixin],
    name: 'BasReqReqTest1Grid1',
    components: {},
    props: {
        // 읽기전용 여부
        readOnly: { type: Boolean, default: false, required: false },
        // 수정전용 여부
        updateOnly: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '200px', //그리드 높이 조절
            },
            view: TEST_HEADER,
            layout: [
                //'pagingSeq',
                //'chk', //체크
                'NO',
                'reqDt', //요청일자
                'uuid', //uuid
                'progId', //프로그램ID
                'itemSeq', //항목SEQ
                'vrfTestTxt', //점검내용
                'preCondTxt', //입력값
                {
                    name: '1차 테스트',
                    direction: 'horizontal',
                    items: ['devTestRslt', 'devTestDtl'],
                },
                //'devTestRslt', //1차테스트_결과
                //'devTestDtl', //1차테스트_내용
                {
                    name: '2차 테스트',
                    direction: 'horizontal',
                    items: ['piTestRslt', 'piTestDtl'],
                },
                //'piTestRslt', //2차테스트_결과
                //'piTestDtl', //2차테스트_내용
            ],
            addData: [
                '', //'NO',
                '', //'reqDt', //요청일자
                '', //'uuid', //uuid
                '', //'progId', //프로그램ID
                '', //itemSeq 항목SEQ
                '', //vrfTestTxt 점검내용
                '', //preCondTxt 입력값
                '', //devTestRslt 1차테스트_결과
                '', //devTestDtl 1차테스트_내용
                '', //piTestRslt 2차테스트_결과
                '', //piTestDtl 2차테스트_내용
            ],
            //행추가,수정시 필수 입력 컬럼
            requiredCols: [
                'progId', //프로그램ID
                'vrfTestTxt', //점검내용
            ],
            gridOnClick: '',
            popupRowIndex: '',
        }
    },
    async mounted() {
        console.log('mount11')
        this.gridObj = this.$refs.depRgstTest1Grid
        this.gridHeaderObj = this.$refs.depRgstTest1Header1
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.setCopyOptions({
            singleMode: true,
            includeHeaderText: false,
        })

        this.setGridReadOnlyCheck()

        //컬럼 고정
        // this.gridObj.gridView.setFixedOptions({
        //     colCount: 3,
        // })

        //특정컬럼 속성변경
        //this.gridObj.gridView.columnByName('NO').visible = false
        this.gridObj.gridView.columnByName('NO').editable = false

        //dropdown combo
        //await this.dropDownSetting()

        this.gridObj.gridView.displayOptions.fitStyle = 'even' //'none' //'even' // 자동간격조정

        this.gridObj.gridView.displayOptions.rowHeight = -1 //자동행높이
        // this.gridOnClick =
        //     this.gridObj.gridView.onCellButtonClicked
        // this.gridObj.gridView.onCellButtonClicked = (
        //     grid,
        //     index,
        //     column
        // ) => {
        //     this.gridPopup(
        //         index.itemIndex,
        //         column.fieldName
        //     )
        // }

        // this.gridObj.gridView.onCellEdited = (
        //     // eslint-disable-next-line no-unused-vars
        //     grid,
        //     // eslint-disable-next-line no-unused-vars
        //     itemIndex,
        //     // eslint-disable-next-line no-unused-vars
        //     row,
        //     // eslint-disable-next-line no-unused-vars
        //     field
        // ) => {
        //     console.log('Test1Grid onCellEdited')
        //     //this.gridObj.gridView.commit()
        // }
    },
    computed: {
        ...serviceComputed,
        data1: {
            get() {
                return this.$data
            },
        },
        resultList1: {
            get() {
                return this.resultTestList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        saveAction1: {
            get() {
                return this.saveAction
            },
        },
    },
    methods: {
        ...serviceMethods,
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 9999, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        excelDownBtn: function () {
            this.gridHeaderObj.exportGrid(
                `신조직관리목록_${moment(new Date()).format(
                    'YYYYMMDDHHmmss'
                )}.xls`
            )
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            //Grid Row 가져올때 페이지정보 Setting
            console.log(
                '🚀 ~ file: TableContainer.vue ~ line 129 ~ SetPaging ~ paging',
                this.paging
            )
            this.gridHeaderObj.setPageCount(this.paging)
        },
        gridAddRowBtn: function () {
            this.gridObj.gridView.commit() //이전 수정 건 완료처리

            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            let focuscell = this.gridObj.gridView.getCurrent()
            console.log(focuscell)
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
        },
        gridDelRowBtn: function () {
            // one select line delete
            // @selDelRow="gridDelRowBtn"
            console.log('del current row')
            this.gridData.gridRows = this.gridHeaderObj.selDelRow()
        },
        gridchkDelRowBtn: function () {
            this.gridObj.gridView.commit() //이전 수정 건 완료처리

            // Checked Row Delete Event
            //@chkDelRowBtn="gridchkDelRowBtn"
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        // async dropDownSetting() {
        //     //업무구분
        //     await this.dropDownCmmonCodes_({
        //         key: 'ZADM_C_00010',
        //         columnName: 'bizClCd',
        //         option: '선택',
        //     })
        //     await this.changeDropDown('bizClCd')
        //     // //등록구분
        //     // await this.dropDownCmmonCodes_({
        //     //     key: 'AGENCY_RGST_CL',
        //     //     columnName: 'agencyRgstClCd',
        //     //     option: '선택',
        //     // })
        //     // await this.changeDropDown('agencyRgstClCd')
        // },
        // async changeDropDown(key) {
        //     let col1 = this.gridObj.gridView.columnByName(key)
        //     col1.values = this.commDropDown[key].values
        //     col1.labels = this.commDropDown[key].labels
        //     this.gridObj.gridView.setColumn(col1)
        // },
        errorCellFocus(chkCell, message) {
            this.showTcComSnackbar(message)
            //cell focus : { index: -1, fieldName: '' }
            this.gridObj.validationChkGrid(chkCell)
        },
        validationCheck() {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            var chk = { index: -1, fieldName: '' }
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.gridObj.dataProvider.getJsonRow(
                        index[i],
                        true
                    )

                    if (
                        row.__rowState == 'created' ||
                        row.__rowState == 'updated'
                    ) {
                        //필수 입력 체크
                        if (this.requiredCols.length) {
                            // created(추가) / updated(수정) 인경우 필수입력항목 체크
                            for (var j = 0; j < this.requiredCols.length; j++) {
                                //필수입력항목이 누락된경우
                                if (
                                    !row[this.requiredCols[j]] ||
                                    _.isEmpty(row[this.requiredCols[j]])
                                ) {
                                    chk.index = index[i]
                                    chk.fieldName = this.requiredCols[j]

                                    this.errorCellFocus(
                                        chk,
                                        this.gridObj.gridView.columnByField(
                                            chk.fieldName
                                        ).header.text + ' 필수 입력 입니다.'
                                    )
                                    return false
                                }
                            }
                        }

                        //적용일자 체크
                        // let fromDt = moment(row.aplyStaDt, 'YYYYMMDD').toDate()
                        // let toDt = moment(row.aplyEndDt, 'YYYYMMDD').toDate()
                        // if (fromDt > toDt) {
                        //     chk.index = index[i]
                        //     chk.fieldName = 'aplyStaDt'

                        //     this.errorCellFocus(
                        //         chk,
                        //         '적용시작일자가 적용마지막일자 보다 큽니다.'
                        //     )
                        //     return false
                        // }
                    }

                    //프로그램ID+점검내용 중복 체크
                    if (row.__rowState == 'created') {
                        let all1 = this.gridObj.dataProvider.getJsonRows(0, -1)
                        let dup1 = all1.filter(
                            (e) =>
                                e.progId === row.progId &&
                                e.vrfTestTxt === row.vrfTestTxt
                        )
                        if (dup1.length > 1) {
                            chk.index = index[i]
                            chk.fieldName = 'vrfTestTxt'

                            this.errorCellFocus(chk, '점검내용 중복 입니다.')
                            return false
                        }
                    }

                    //대리점 코드, 위탁창코 중복 체크
                    // if (row.__rowState == 'created') {
                    //     let all1 = this.gridObj.dataProvider.getJsonRows(0, -1)
                    //     let dup1 = all1.filter(
                    //         (e) => e.agencyCd === row.agencyCd
                    //     )
                    //     //대리점 체크
                    //     if (dup1.length > 1) {
                    //         chk.index = index[i]
                    //         chk.fieldName = 'agencyCd'

                    //         this.errorCellFocus(chk, '중복코드 입니다.')
                    //         return false
                    //     }
                    //     //위탁창고 체크
                    //     let dup2 = all1.filter(
                    //         (e) => e.cnsgHldPlcCd === row.cnsgHldPlcCd
                    //     )
                    //     if (dup2.length > 1 && row.cnsgHldPlcCd != '') {
                    //         chk.index = index[i]
                    //         chk.fieldName = 'cnsgHldPlcCd'

                    //         this.errorCellFocus(chk, '중복코드 입니다.')
                    //         return false
                    //     }
                    // }
                }
            } else {
                if (!this.gridData.delRows.length) {
                    //this.showTcComSnackbar(msgTxt.MSG_01002)
                    return false
                }
            }

            return true
        },
        async saveData() {
            let saveRows = []

            for (let i = 0; i < this.gridData.delRows.length; i++) {
                let e = this.gridData.delRows[i]
                saveRows.push({
                    ...e,
                    rowState: e.__rowState,
                    //agencyCd: e.agencyCd, //UKEY대리점코드
                })
            }

            var arr = []
            var cIndex = this.gridObj.dataProvider.getStateRows('created')
            var uIndex = this.gridObj.dataProvider.getStateRows('updated')
            arr.push(...cIndex)
            arr.push(...uIndex)
            for (var i = 0; i < arr.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(arr[i], true)
                saveRows.push({
                    ...row,
                    rowState: row.__rowState,
                    reqDt: this.popupParams.reqDt,
                    uuid: this.popupParams.uuid,
                })
            }

            //checkBar 를 사용할 경우 체크된 건만 저장처리
            // if (this.gridObj.gridView.checkBar.fieldName == 'chk') {
            //     saveRows = saveRows.filter((x) => {
            //         return (
            //             x['chk'] != null &&
            //             x['chk'] == 'true' &&
            //             x['origin'] != 'in'
            //         )
            //     })
            // }

            console.log('crud api call', saveRows)

            // 모아서 저장할 경우 별도로 저장해둠
            await this.defaultAssign_({
                key: 'saveTestList',
                value: saveRows,
            })

            // 단독 저장일 경우 아래 코드 처리
            // let res1 = await this.saveTestRgst_({ saveRows })
            // console.log('save Test', saveRows, res1)
        },
        // gridPopup(row, col) {
        //     if (col == 'agencyCd') {
        //         //alert('준비중 UKEY대리점 팝업:' + row + ', fieldName=' + col)
        //     }
        // },
        setNO() {
            //순번처리
            //let pageInfo = { ...this.paging1, type: 'paging' } //페이징의 경우
            let pageInfo = {} //페이징이 없는경우
            pageInfo.type = 'noPaging' //페이징이 없는경우
            pageInfo.totalDataCnt = this.resultList1.length //페이징이 없는경우

            this.gridObj.setGridIndicator(pageInfo, { sort: 'ASC' }) //'ASC' 'DESC'
            this.gridObj.gridView.clearCurrent() //선택해제
        },
        setGridReadOnlyCheck() {
            /*
             * indicatorBl  : 인디게이터 사용여부
             * stateBarBl   : 상태바 사용여부
             * checkBarBl   : 체크바 사용여부
             * footerBl     : Footer 사용여부
             */
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))

            if (this.readOnly) {
                this.gridObj.setGridState(false, false, false, false) //삭제를 위한 선택을 위해 활성화(false, false, true, false)
                //체크바: 삭제를 위한 선택을 위해 활성화
                this.gridObj.gridView.setCheckBar({
                    visible: false,
                })

                //편집가능
                this.gridObj.gridView.setEditOptions({
                    editable: false,
                    updatable: false,
                    editWhenFocused: false,
                    enterToTab: false,
                })

                this.view.columns.forEach((element) => {
                    this.gridObj.gridView.columnByName(
                        element.fieldName
                    ).editable = false
                })
            } else {
                this.gridObj.setGridState(false, false, true, false)
                //체크바: 삭제를 위한 선택을 위해 활성화
                this.gridObj.gridView.setCheckBar({
                    visible: true,
                })
                //this.gridObj.gridView.checkBar.fieldName = 'chk'

                //편집가능
                this.gridObj.gridView.setEditOptions({
                    editable: true,
                    updatable: true,
                    editWhenFocused: true,
                    enterToTab: true,
                })
                this.gridObj.gridView.columnByName(
                    'piTestRslt'
                ).editable = false
                this.gridObj.gridView.columnByName('piTestDtl').editable = false
            }
        },
        setGridUpdateOnlyCheck() {
            if (this.updateOnly) {
                this.gridObj.setGridState(false, false, false, false) //삭제를 위한 선택을 위해 활성화(false, false, true, false)
                //체크바: 삭제를 위한 선택을 위해 활성화여부
                this.gridObj.gridView.setCheckBar({
                    visible: false,
                })

                //편집가능
                this.gridObj.gridView.setEditOptions({
                    editable: true,
                    updatable: true,
                    editWhenFocused: true,
                    enterToTab: true,
                })

                this.view.columns.forEach((element) => {
                    this.gridObj.gridView.columnByName(
                        element.fieldName
                    ).editable = false
                })
                this.gridObj.gridView.columnByName('piTestRslt').editable = true
                this.gridObj.gridView.columnByName('piTestDtl').editable = true
            }
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        resultList1(val, oldVal) {
            this.gridObj.dataProvider.clearRows()
            this.gridData = this.GridSetData()
            //this.gridObj.gridView.commit()
            this.gridObj.setRows(this.resultList1)

            this.setNO()

            // //신규 row 상태값 변경
            // let arr1 = this.gridObj.dataProvider.getJsonRows()
            // for (let j = 0; j < arr1.length; j++) {
            //     // if (arr1[j].chk == 'true') {
            //     //     // this.gridObj.dataProvider.setValue(
            //     //     //     j,
            //     //     //     'orgCd',
            //     //     //     this.currentOrg.orgCd
            //     //     // )
            //     //     this.gridObj.dataProvider.setRowState(j, 'updated', false) //updated
            //     // }
            //     this.gridObj.dataProvider.setRowState(j, 'updated', false) //updated
            // }
            // this.gridObj.gridView.commit()
        },
        // eslint-disable-next-line no-unused-vars
        paging1(val, oldVal) {
            this.SetPaging()
        },
        async saveAction1(val, oldVal) {
            if (val == true) {
                console.log('saveAction1: ', val, oldVal)
                this.gridObj.gridView.commit()

                console.log('저장 호출 이벤트 TestDep')

                if (this.validationCheck()) {
                    await this.saveData()
                } else {
                    console.log('validation false')
                }

                //에러든 정상종료든 완료되면 flag처리
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: true,
                })

                // //그리드 저장이 하나 일경우 임시로 두개의 saveAction 이 있다고 간주
                // //그리드 저장이 둘 이상일 경우 코멘트 처리 사용
                // await this.defaultAssign_({
                //     key: 'saveDoneB',
                //     value: true,
                // })
            }
        },
        readOnly(val, oldVal) {
            console.log(
                'readOnly change',
                val,
                oldVal,
                this.readOnly,
                this.view
            )
            this.setGridReadOnlyCheck()
        },
        updateOnly(val, oldVal) {
            console.log(
                'updateOnly change',
                val,
                oldVal,
                this.updateOnly,
                this.view
            )
            this.setGridUpdateOnlyCheck()
        },
    },
}
</script>
<style>
/* #idTest1GridWap .stitHead {
    margin-top: -20px !important;
} */
#depRgstTest1Grid .multiline-editor {
    white-space: pre;
    text-align: left;
}
#depRgstTest1Grid .rg-editor-container > textarea {
    background-color: #ffffff;
    line-height: normal;
    text-align: left !important;
    color: #666 !important;
    font: inherit;
    ime-mode: auto;
    cursor: text;
    font-size: 13px !important;
}
</style>
