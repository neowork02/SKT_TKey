import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'
import actions from './actions'
import getters from './getters'
import mutations from './mutations'
import state from './state'

export const serviceComputed = {
    ...mapState('bas.req.depMgmtStore', Object.keys(state)),
    ...mapGetters('bas.req.depMgmtStore', Object.keys(getters)),
}
export const serviceMethods = {
    ...mapActions('bas.req.depMgmtStore', Object.keys(actions)),
    ...mapMutations('bas.req.depMgmtStore', Object.keys(mutations)),
}
