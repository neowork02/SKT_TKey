<template>
    <div class="content">
        <!-- Tit -->
        <h1>부가상품관리</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch(type)"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="부가상품구분"
                        v-model="div_search.cmb_suplSvcCl"
                        :objAuth="this.objAuth"
                        :codeId="'ZBAS_C_00320'"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        labelName="상품명"
                        :objAuth="this.objAuth"
                        v-model="div_search.prod_nm"
                        @enterKey="onSearch(type)"
                    />
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="부가상품분류"
                        v-model="div_search.cmb_prcplnClCd"
                        :objAuth="this.objAuth"
                        codeId="PRCPLN_CL_CD"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="부가상품분류 상세"
                        v-model="div_search.cmb_prcplnClDtlCd"
                        :objAuth="this.objAuth"
                        codeId="PRCPLN_CL_DTL_CD"
                        :addBlankItem="true"
                        blankItemText="선택"
                        blankItemValue=""
                        labelClass="line2"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="사용여부"
                        v-model="div_search.cmb_useYn"
                        :itemList="ds_useYn"
                        itemText="text"
                        itemValue="value"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>

                <div class="formitem div4">
                    <TCComComboBox
                        labelName="상품상태"
                        v-model="div_search.cmb_prod_st"
                        :objAuth="this.objAuth"
                        codeId="ZBAS_C_00180"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="결합상품"
                        v-model="div_search.cmb_combProdYn"
                        :itemList="ds_combProdYn"
                        itemText="text"
                        itemValue="value"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="등록구분"
                        v-model="div_search.cmb_rgstCl"
                        :objAuth="this.objAuth"
                        codeId="ZBAS_C_00170"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <template>
                    <div class="btn_def">
                        <v-btn
                            plain
                            class="btn_ty_exp"
                            v-bind:class="{
                                ' btn_ty_exp_active ': toggleActive,
                            }"
                            @click="toggleActive = !toggleActive"
                        >
                        </v-btn>
                    </div>
                </template>
                <v-expand-transition>
                    <div class="toggleWrap" v-show="toggleActive">
                        <div
                            class="formitem div4"
                            v-show="this.type == 0 ? true : false"
                        >
                            <TCComComboBox
                                labelName="소속영업장YN"
                                v-model="div_search.cmb_ignDcodeYn"
                                :itemList="ds_ignDcodeYn"
                                itemText="text"
                                itemValue="value"
                                :objAuth="this.objAuth"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                            ></TCComComboBox>
                        </div>
                        <div
                            class="formitem div4"
                            v-show="this.type == 0 ? true : false"
                        >
                            <TCComComboBox
                                labelName="기본료그룹코드"
                                v-model="div_search.cmb_basGrpCd"
                                :objAuth="this.objAuth"
                                codeId="ZBAS_C_00620"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                            ></TCComComboBox>
                        </div>
                        <!-- <div
                            class="formitem div4"
                            v-show="this.type == 0 ? true : false"
                        >
                            <TCComComboBox
                                labelName="정책기본료 그룹코드"
                                labelClass="line2"
                                v-model="div_search.cmb_polBasGrpCd"
                                :objAuth="this.objAuth"
                                codeId="ZPOL_CEMP_00110"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                            ></TCComComboBox>
                        </div> -->
                        <div class="formitem div4_6"></div>
                        <!-- <div
                            class="formitem div4"
                            v-show="this.type == 0 ? false : true"
                        >
                            <TCComComboBox
                                labelName="사업대분류"
                                v-model="div_search.cmb_ProdCL"
                                :objAuth="this.objAuth"
                                codeId="ZTKP_C_00010"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                            ></TCComComboBox>
                        </div>
                        <div
                            class="formitem div4"
                            v-show="this.type == 0 ? false : true"
                        >
                            <TCComComboBox
                                labelName="요금제구간"
                                v-model="div_search.cmb_suplClassCd"
                                codeId="SUPL_CLASS_CD"
                                :objAuth="this.objAuth"
                                :addBlankItem="true"
                                blankItemText="전체"
                                blankItemValue=""
                                :size="combSize"
                            ></TCComComboBox>
                        </div> -->
                    </div>
                </v-expand-transition>
            </div>
        </div>
        <div class="gridWrap">
            <TCComTab
                :tab.sync="guideTab2"
                :items="items"
                :itemName="itemName"
                :tabColor="tabColor"
                :textColor="textColor"
                :centered="centered"
                :grow="grow"
                :height="height"
                :hideSlider="hideSlider"
                :sliderColor="sliderColor"
                :vertical="vertical"
                :objAuth="objAuth"
                sliderSize="8"
                @change="onActiveTabChange"
                @click="onActiveTabClick"
                :cKey="0"
            >
                <template #Template1>
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="상품목록"
                        :gridObj="gridObj1"
                        :isPageRows="true"
                        :isPageCnt="true"
                        :isExceldown="true"
                        :isAddRow="true"
                        :isDelRow="true"
                        @addRowBtn="btn_add_OnClick"
                        @chkDelRowBtn="btn_del_OnClick"
                        @excelDownBtn="onClickDownload(type)"
                    />
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :fields="view1.fields"
                        :columns="view1.columns"
                        :editable="true"
                        :updatable="true"
                        :isGridReSize="true"
                    />
                    <TCComPaging
                        :totalPage="gridData1.totalPage"
                        :apiFunc="getSuplSvcList"
                        :rowCnt="rowCnt"
                        :gridObj="gridObj1"
                        @input="chgRowCnt1"
                    />
                </template>
                <template #Template2>
                    <TCRealGridHeader
                        id="gridHeader2"
                        ref="gridHeader2"
                        gridTitle="사용자 목록"
                        :gridObj="gridObj2"
                        :isPageRows="true"
                        :isPageCnt="true"
                        :isExceldown="true"
                        :isAddRow="true"
                        :isDelRow="true"
                        @addRowBtn="btn_add_OnClick"
                        @chkDelRowBtn="btn_del_OnClick"
                        @excelDownBtn="onClickDownload(type)"
                    />
                    <TCRealGrid
                        id="grid2"
                        ref="grid2"
                        :fields="view2.fields"
                        :columns="view2.columns"
                        :editable="true"
                        :updatable="true"
                        @hook:mounted="tabGridMounted"
                        :isGridReSize="true"
                    />
                    <TCComPaging
                        :totalPage="gridData2.totalPage"
                        :apiFunc="getSuplTkpList"
                        :rowCnt="rowCnt"
                        :gridObj="gridObj2"
                        @input="chgRowCnt2"
                    />
                </template>

                <br />
            </TCComTab>
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
// import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
import moment from 'moment'
import attachedFileApi from '@/api/common/attachedFile'
// import _ from 'lodash'
// import BasUsmSaleChrgrMgmtPopup from '@/views/biz/bas/usm/BasUsmSaleChrgrMgmtPopup'
import {
    WIRELESS_HEADER,
    WIRE_HEADER,
} from '@/const/grid/bas/pdm/basPdmSuplSvcMgmtHeader'
import API from '@/api/biz/bas/pdm/basPdmSuplSvcMgmt'
import CommonMixin from '@/mixins'

export default {
    name: 'BasPdmSuplSvcMgmt',
    mixins: [CommonMixin],
    props: {},
    components: {},
    data() {
        return {
            toggleActive: false,
            guideTab: 0,
            guideTab2: 0,
            items: ['Template1', 'Template2'],
            itemName: ['무선', '유선'],
            gridData1: this.gridSetData(),
            gridData2: this.gridSetData(),
            gridObj1: {},
            gridHeaderObj1: {},
            gridObj2: {},
            gridHeaderObj2: {},
            view1: WIRELESS_HEADER,
            view2: WIRE_HEADER,
            ds_combProdYn: [
                { text: 'N', value: 'N' },
                { text: 'Y', value: 'Y' },
            ],
            ds_useYn: [
                { text: 'N', value: 'N' },
                { text: 'Y', value: 'Y' },
            ],
            ds_ignDcodeYn: [
                { text: 'N', value: 'N' },
                { text: 'Y', value: 'Y' },
            ],
            type: 0,
            tabColor: '',
            textColor: '',
            height: '',
            sliderColor: '',
            centered: false,
            grow: false,
            hideSlider: false,
            vertical: false,
            objAuth: {},
            rowCnt: 15, // 표시할 행의 갯수
            // rowCnt2: 15, // 표시할 행의 갯수
            div_search: {
                cmb_suplSvcCl: '',
                cmb_prcplnClCd: '',
                cmb_prcplnClDtlCd: '',
                prod_nm: '',
                cmb_prod_st: '',
                cmb_combProdYn: '',
                cmb_rgstCl: '',
                cmb_useYn: '',
                cmb_ignDcodeYn: '',
                cmb_ProdCL: '',
                cmb_basGrpCd: '',
                cmb_polBasGrpCd: '',
            },
            showBool: false,
            pageNum: 1,
            pageSize: 10,
            showNext: false,
            showNext2: false,
            selectedJsonData: {},
            suplSvcClCdList: [],
            ds_suplSvcList: [],
            suplSvcClCdWList: [],
            suplSvcClCdCode: 'ZBAS_C_00320',
            combSize: 94,
            wireProd: {
                없음: '9',
                인터넷: '1',
                인터넷전화: '2',
                일반전화: '3',
                IPTV: '4',
            },
        }
    },
    async mounted() {
        console.log('------mounted------')
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        this.gridObj1 = this.$refs.grid1
        this.gridHeaderObj1 = this.$refs.gridHeader1
        this.gridObj1.setGridState(true)
        this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

        // 특정 필드 가리기
        this.gridObj1.gridView.columnByName('wrcellClCd').visible = false

        console.log('type : ', this.type)
        console.log('suplSvcClCdCode : ', this.suplSvcClCdCode)

        await this.init()
        await this.dropDownSetting1()

        //페이지 정보
        let pageInfo = {}
        // pageInfo.type = 'noPaging' //페이징이 없는경우
        pageInfo.totalDataCnt = this.gridObj1.dataProvider.getRowCount() // 총건수
        this.gridObj1.setGridIndicator(pageInfo) //순번 셋팅

        let paramObj = {}
        paramObj.pageNum = 1
        paramObj.pageSize = 10

        this.gridObj1.gridView.onCellEdited = (
            grid,
            itemIndex,
            dataRow,
            field
        ) => {
            // var column = grid.columnByField('accDealcoNm')
            this.gridObj1.gridView.commit()
            const getData = grid.getValue(itemIndex, field)
            console.log('getData', getData)
            this.selectedJsonData =
                this.gridObj.dataProvider.getJsonRow(dataRow)
            console.log('selectedJsonData', this.selectedJsonData)
        }
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt1(val) {
            this.rowCnt = val
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt2(val) {
            this.rowCnt = val
        },

        // 무선 그리드에 그룹명 dropdown셋팅 공통코드 api
        async dropDownSetting1() {
            console.log('무선')
            // 부가상품구분(무선)
            await this.dropDownCmmonCodes1({
                key: 'ZBAS_C_00320',
                colName: 'suplSvcClCd',
                option: '',
            })
            // 등록구분
            await this.dropDownCmmonCodes1({
                key: 'ZBAS_C_00170',
                colName: 'rgstClCd',
                option: '',
            })
            // 상품상태
            await this.dropDownCmmonCodes1({
                key: 'ZBAS_C_00180',
                colName: 'prodStCd',
                option: '',
            })
            // 요금제분류 set
            await this.dropDownCmmonCodes1({
                key: 'PRCPLN_CL_CD',
                colName: 'prcplnClCd',
                option: '',
            })
            //
            await this.dropDownCmmonCodes1({
                key: 'PRCPLN_CL_DTL_CD',
                colName: 'prcplnClDtlCd',
                option: '',
            })
            // 기본료그룹코드
            await this.dropDownCmmonCodes1({
                key: 'ZBAS_C_00620',
                colName: 'basGrpCd',
                option: '',
            })
            // 정책기본료그룹코드
            // await this.dropDownCmmonCodes1({
            //     key: 'ZPOL_CEMP_00110',
            //     colName: 'polBasGrpCd',
            //     option: '',
            // })
        },

        // 유선 그리드에 그룹명 dropdown셋팅 공통코드 api
        async dropDownSetting2() {
            console.log('유선')
            // 부가상품구분(유선)
            await this.dropDownCmmonCodes2({
                key: 'ZBAS_C_00320',
                colName: 'suplSvcClCd',
                option: '',
            })
            // 등록구분
            await this.dropDownCmmonCodes2({
                key: 'ZBAS_C_00170',
                colName: 'rgstClCd',
                option: '',
            })
            // 상품상태
            await this.dropDownCmmonCodes2({
                key: 'ZBAS_C_00180',
                colName: 'prodStCd',
                option: '',
            })
            // 요금제분류 set
            await this.dropDownCmmonCodes2({
                key: 'PRCPLN_CL_CD',
                colName: 'prcplnClCd',
                option: '',
            })
            // 요금제분류상세 set
            await this.dropDownCmmonCodes2({
                key: 'PRCPLN_CL_DTL_CD',
                colName: 'prcplnClDtlCd',
                option: '',
            })
            // 요금제구간코드 set
            // await this.dropDownCmmonCodes2({
            //     key: 'SUPL_CLASS_CD',
            //     colName: 'suplClassCd',
            //     option: '',
            // })
        },

        async dropDownCmmonCodes1({ key, colName, option }) {
            let result = await API.dropDownCmmonCodes_(key)
            let values = []
            let labels = []
            values = result.map((a) => a.commCdVal)
            labels = result.map((a) => a.commCdValNm)
            if (option != undefined) {
                values.unshift('')
                labels.unshift(option)
            }

            const wirelessList = [
                'suplSvcClCd',
                'rgstClCd',
                'prodStCd',
                'prcplnClCd',
                'prcplnClDtlCd',
                'basGrpCd',
                // 'polBasGrpCd',
            ]

            wirelessList.forEach((col) => {
                if (colName == col) {
                    let col1 = this.gridObj1.gridView.columnByName(colName)
                    col1.values = values
                    col1.labels = labels
                    this.gridObj1.gridView.setColumn(col1)
                }
            })
        },

        async dropDownCmmonCodes2({ key, colName, option }) {
            let result = await API.dropDownCmmonCodes_(key)
            let values = []
            let labels = []
            values = result.map((a) => a.commCdVal)
            labels = result.map((a) => a.commCdValNm)
            if (option != undefined) {
                values.unshift('')
                labels.unshift(option)
            }

            const wireList = [
                'suplSvcClCd',
                'rgstClCd',
                'prodStCd',
                'prcplnClCd',
                'prcplnClDtlCd',
                // 'suplClassCd',
            ]

            wireList.forEach((col) => {
                if (colName == col) {
                    let col1 = this.gridObj2.gridView.columnByName(colName)
                    col1.values = values
                    col1.labels = labels
                    this.gridObj2.gridView.setColumn(col1)
                }
            })
        },

        //엑셀다운로드
        onClickDownload(type) {
            if (type === 0) {
                // 무선 부가상품서비스 조회
                const rowCount = this.gridObj1.dataProvider.getRowCount()
                if (rowCount == 0) {
                    this.showTcComAlert(
                        '엑셀다운로드 대상이 존재하지 않습니다.'
                    )
                    return
                }
                attachedFileApi.downLoadFile(
                    '/api/v1/backend-long/resource/bas/pdm/wless-add-prod-svc-excel',
                    this.div_search
                )
            } else if (type === 1) {
                // 유선 부가상품서비스 조회
                const rowCount = this.gridObj2.dataProvider.getRowCount()
                if (rowCount == 0) {
                    this.showTcComAlert(
                        '엑셀다운로드 대상이 존재하지 않습니다.'
                    )
                    return
                }
                attachedFileApi.downLoadFile(
                    '/api/v1/backend-long/resource/bas/pdm/wire-add-prod-svc-excel',
                    this.div_search
                )
            }
        },
        onActiveTabClick() {},
        tabGridMounted() {
            this.gridObj2 = this.$refs.grid2
            this.gridHeaderObj2 = this.$refs.gridHeader2
            this.gridObj2.setGridState(true)
            // this.gridObj2.gridView.setRowIndicator({ visible: true })
            this.gridObj2.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

            this.dropDownSetting2()

            // 특정 필드 가리기
            this.gridObj2.gridView.columnByName('wrcellClCd').visible = false
            this.gridObj2.gridView.columnByName('wireProdClCd').visible = false

            // this.dropDownSetting()
            this.gridObj2.gridView.onCellEdited = (
                grid,
                itemIndex,
                dataRow,
                field
            ) => {
                // var column = grid.columnByField('accDealcoNm')
                this.gridObj2.gridView.commit()
                const getData = grid.getValue(itemIndex, field)
                console.log('getData', getData)
                this.selectedJsonData =
                    this.gridObj2.dataProvider.getJsonRow(dataRow)
                // const wireClCd = this.returnWireProdClCd(
                //     this.wireProd,
                //     this.selectedJsonData.wireProdClNm
                // )
                // this.selectedJsonData.wireProdClCd = wireClCd
                console.log('selectedJsonData', this.selectedJsonData)
            }
        },

        returnWireProdClCd(map, name) {
            return map[name]
        },

        onClick() {
            this.showBool = true
        },

        onSearch(type) {
            console.log('onSearch조회', type)
            this.delIdxs = []
            if (type === 0) {
                this.gridData1.totalPage = 0
                this.getSuplSvcList(1)
                // 0 : 운영모델
            } else if (type === 1) {
                this.gridData2.totalPage = 0
                this.getSuplTkpList(1)
                // 1 : 일반상품
            }
        },

        // 무선 상품 조회
        getSuplSvcList(pageNum) {
            let paramObj = {
                suplSvcNm: this.div_search.prod_nm, // 부가서비스명(상품명)
                suplSvcClCd: this.div_search.cmb_suplSvcCl, // 부가서비스구분코드
                prodStCd: this.div_search.cmb_prod_st, // 상품상태코드
                prcplnClCd: this.div_search.cmb_prcplnClCd, // 요금제분류코드
                prcplnClDtlCd: this.div_search.cmb_prcplnClDtlCd, // 요금제분류상세코드
                combProdYn: this.div_search.cmb_combProdYn, // 결합상품여부
                rgstClCd: this.div_search.cmb_rgstCl, // 등록구분코드
                wrcellClCd: '1', // 유무선구분코드
                useYn: this.div_search.cmb_useYn, // 사용여부
                ignDcodeYn: this.div_search.cmb_ignDcodeYn, // 소속영업장적용여부
                basGrpCd: this.div_search.cmb_basGrpCd, // 정책기본료그룹코드
                polBasGrpCd: this.div_search.cmb_polBasGrpCd, // 정책기본료그룹코드
            }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt

            // 페이징 조회
            API.getSuplSvcList(paramObj).then((result) => {
                console.log(result)
                if (result == undefined) {
                    this.showTcComAlert('조회된 데이터가 없습니다.')
                    return
                } else {
                    this.gridObj1.setRows(result.gridList)
                    // 페이징 관련
                    this.gridObj1.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData1 = this.gridSetData() //초기화
                    this.gridData1.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj1.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
                // this.setNmSuplSvc()
            })
        },

        getSuplTkpList(pageNum) {
            let paramObj = {
                suplSvcNm: this.div_search.prod_nm, // 부가서비스명(상품명)
                suplSvcClCd: this.div_search.cmb_suplSvcCl, // 부가서비스구분코드
                prodStCd: this.div_search.cmb_prod_st, // 상품상태코드
                prodClCd: this.div_search.cmb_ProdCL, // 사업대분류코드
                prcplnClCd: this.div_search.cmb_prcplnClCd, // 요금제분류코드
                prcplnClDtlCd: this.div_search.cmb_prcplnClDtlCd, // 요금제분류상세코드
                combProdYn: this.div_search.cmb_combProdYn, // 결합상품여부
                rgstClCd: this.div_search.cmb_rgstCl, // 등록구분코드
                wrcellClCd: '2', // 유무선구분코드
                useYn: this.div_search.cmb_useYn, // 사용여부
                suplClassCd: this.div_search.cmb_suplClassCd, // 요금제구간
            }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt
            // if (this.reqParam.effUserYn[0] !== undefined) {
            //     paramObj.effUserYn = 'Y'
            // }
            // 페이징 조회
            API.getSuplTkpList(paramObj).then((resultData) => {
                console.log(resultData)
                if (resultData == undefined) {
                    this.showTcComAlert('조회된 데이터가 없습니다.')
                    return
                } else {
                    this.ds_suplTkpList = resultData.gridList
                    this.gridObj2.setRows(resultData.gridList) // 임시주석
                    // 페이징 관련
                    this.gridObj2.setGridIndicator(resultData.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData2 = this.gridSetData() //초기화
                    this.gridData2.totalPage = resultData.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj2.setPageCount(resultData.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                    // this.setNmSuplTkp()
                }
            })
        },

        setNmSuplSvc() {
            for (let idx = 0; idx < this.ds_suplSvcList.length; idx++) {
                this.suplSvcClCdList.map((a) => {
                    if (a.commCdVal == this.ds_suplSvcList[idx].suplSvcClCd) {
                        this.gridObj1.gridView.setValue(
                            idx,
                            'suplSvcClNm',
                            a.commCdValNm
                        )
                    }
                })
                this.rgstClCdList.map((a) => {
                    if (a.commCdVal == this.ds_suplSvcList[idx].rgstClCd) {
                        this.gridObj1.gridView.setValue(
                            idx,
                            'rgstClNm',
                            a.commCdValNm
                        )
                    }
                })
                this.prodStCdList.map((a) => {
                    if (a.commCdVal == this.ds_suplSvcList[idx].prodStCd) {
                        this.gridObj1.gridView.setValue(
                            idx,
                            'prodStNm',
                            a.commCdValNm
                        )
                    }
                })
            }
        },

        setNmSuplTkp() {
            for (let idx = 0; idx < this.ds_suplTkpList.length; idx++) {
                this.suplSvcClCdWList.map((a) => {
                    if (a.commCdVal == this.ds_suplTkpList[idx].suplSvcClCd) {
                        this.gridObj2.gridView.setValue(
                            idx,
                            'suplSvcClNm',
                            a.commCdValNm
                        )
                    }
                })
                this.rgstClCdList.map((a) => {
                    if (a.commCdVal == this.ds_suplTkpList[idx].rgstClCd) {
                        this.gridObj2.gridView.setValue(
                            idx,
                            'rgstClNm',
                            a.commCdValNm
                        )
                    }
                })
                this.prodStCdList.map((a) => {
                    if (a.commCdVal == this.ds_suplTkpList[idx].prodStCd) {
                        this.gridObj2.gridView.setValue(
                            idx,
                            'prodStNm',
                            a.commCdValNm
                        )
                    }
                })
            }
        },

        onActiveTabChange(tabIdx) {
            console.log('onActiveTabChange: ', tabIdx)
            this.type = tabIdx
            // this.isSms = false
            if (tabIdx === 1) {
                // this.tabGrid()
                // this.isSms = true
                // this.showBool = false
                // this.onSmsSearch()
            } else {
                // this.isSms = true
                // this.showBool = false
                // this.onSearch(tabIdx)
            }
            // this.onSearch(tabIdx)
        },

        //저장 버튼 이벤트
        onSave: function () {
            let saveParam = []
            let gridCreatedIndexArr = []
            let gridUpdatedIndexArr = []

            // 무선
            if (this.type == 0) {
                gridCreatedIndexArr =
                    this.gridObj1.dataProvider.getStateRows('created')
                gridUpdatedIndexArr =
                    this.gridObj1.dataProvider.getStateRows('updated')

                console.log('gridCreatedIndexArr', gridCreatedIndexArr)
                console.log('gridUpdatedIndexArr', gridUpdatedIndexArr)

                for (let idx = 0; idx < gridCreatedIndexArr.length; idx++) {
                    let getJson = this.gridObj1.dataProvider.getJsonRow(
                        gridCreatedIndexArr[idx]
                    )
                    getJson.suplSvcCd = getJson.suplSvcCd
                        ? getJson.suplSvcCd
                        : ''
                    getJson.suplSvcClCd = getJson.suplSvcClCd
                        ? getJson.suplSvcClCd
                        : ''
                    getJson.suplSvcNm = getJson.suplSvcNm
                        ? getJson.suplSvcNm
                        : ''
                    getJson.wireProdClCd = getJson.wireProdClCd
                        ? getJson.wireProdClCd
                        : ''
                    getJson.rgstClCd = getJson.rgstClCd ? getJson.rgstClCd : ''
                    getJson.prodStCd = getJson.prodStCd ? getJson.prodStCd : ''
                    getJson.mktgDt = getJson.mktgDt ? getJson.mktgDt : ''
                    getJson.wdrlDt = getJson.wdrlDt ? getJson.wdrlDt : ''
                    getJson.rgstDt = getJson.serNumEndLenCnt
                        ? getJson.serNumEndLenCnt
                        : ''
                    getJson.combProdYn = getJson.combProdYn
                        ? getJson.combProdYn
                        : ''
                    getJson.useYn = getJson.useYn ? getJson.useYn : ''
                    getJson.wrcellClCd = ''
                    getJson.prcplnClCd = getJson.prcplnClCd
                        ? getJson.prcplnClCd
                        : ''
                    getJson.prcplnClDtlCd = getJson.prcplnClDtlCd
                        ? getJson.prcplnClDtlCd
                        : ''
                    getJson.basAmt = getJson.basAmt ? getJson.basAmt : ''
                    getJson.basGrpCd = getJson.basGrpCd ? getJson.basGrpCd : ''
                    getJson.polBasGrpCd = getJson.polBasGrpCd
                        ? getJson.polBasGrpCd
                        : ''
                    getJson.ignDcodeYn = getJson.ignDcodeYn
                        ? getJson.ignDcodeYn
                        : ''
                    getJson.__rowState = 'created'
                    saveParam.push(getJson)
                }

                for (let idx = 0; idx < gridUpdatedIndexArr.length; idx++) {
                    let getJson = this.gridObj1.dataProvider.getJsonRow(
                        gridUpdatedIndexArr[idx]
                    )
                    getJson.suplSvcCd = getJson.suplSvcCd
                        ? getJson.suplSvcCd
                        : ''
                    getJson.suplSvcClCd = getJson.suplSvcClCd
                        ? getJson.suplSvcClCd
                        : ''
                    getJson.suplSvcNm = getJson.suplSvcNm
                        ? getJson.suplSvcNm
                        : ''
                    getJson.rgstClCd = getJson.rgstClCd ? getJson.rgstClCd : ''
                    getJson.prodStCd = getJson.prodStCd ? getJson.prodStCd : ''
                    getJson.mktgDt = getJson.mktgDt ? getJson.mktgDt : ''
                    getJson.wdrlDt = getJson.wdrlDt ? getJson.wdrlDt : ''
                    getJson.rgstDt = getJson.rgstDt ? getJson.rgstDt : ''
                    getJson.combProdYn = getJson.combProdYn
                        ? getJson.combProdYn
                        : ''
                    getJson.useYn = getJson.useYn ? getJson.useYn : ''
                    getJson.wrcellClCd = ''
                    getJson.prcplnClCd = getJson.prcplnClCd
                        ? getJson.prcplnClCd
                        : ''
                    getJson.prcplnClDtlCd = getJson.prcplnClDtlCd
                        ? getJson.prcplnClDtlCd
                        : ''
                    getJson.basAmt = getJson.basAmt ? getJson.basAmt : ''
                    getJson.basGrpCd = getJson.basGrpCd ? getJson.basGrpCd : ''
                    getJson.polBasGrpCd = getJson.polBasGrpCd
                        ? getJson.polBasGrpCd
                        : ''
                    getJson.ignDcodeYn = getJson.ignDcodeYn
                        ? getJson.ignDcodeYn
                        : ''
                    getJson.__rowState = 'updated'

                    saveParam.push(getJson)
                }

                console.log('saveParam : ', saveParam)

                API.saveSuplSvcList(saveParam).then((result) => {
                    if (result !== undefined) {
                        this.showTcComAlert('정상적으로 처리되었습니다.')
                        // 매핑정보 재조회
                        this.onSearch()
                    } else {
                        this.showTcComAlert(result.message)
                    }
                })
                // 유선
            } else {
                gridCreatedIndexArr =
                    this.gridObj2.dataProvider.getStateRows('created')
                gridUpdatedIndexArr =
                    this.gridObj2.dataProvider.getStateRows('updated')

                console.log('gridCreatedIndexArr', gridCreatedIndexArr)
                console.log('gridUpdatedIndexArr', gridUpdatedIndexArr)
                for (let idx = 0; idx < gridCreatedIndexArr.length; idx++) {
                    let getJson = this.gridObj2.dataProvider.getJsonRow(
                        gridCreatedIndexArr[idx]
                    )
                    getJson.suplSvcCd = getJson.suplSvcCd
                        ? getJson.suplSvcCd
                        : ''
                    getJson.suplSvcClCd = getJson.suplSvcClCd
                        ? getJson.suplSvcClCd
                        : ''
                    getJson.suplSvcNm = getJson.suplSvcNm
                        ? getJson.suplSvcNm
                        : ''
                    const wireClCd = this.returnWireProdClCd(
                        this.wireProd,
                        getJson.wireProdClNm
                    )
                    getJson.wireProdClCd = wireClCd
                    // getJson.wireProdClCd = getJson.wireProdClCd
                    //     ? getJson.wireProdClCd
                    //     : ''
                    getJson.rgstClCd = getJson.rgstClCd ? getJson.rgstClCd : ''
                    getJson.prodStCd = getJson.prodStCd ? getJson.prodStCd : ''
                    getJson.mktgDt = getJson.mktgDt ? getJson.mktgDt : ''
                    getJson.scrbStopDt = getJson.scrbStopDt
                        ? getJson.scrbStopDt
                        : ''
                    getJson.wdrlDt = getJson.wdrlDt ? getJson.wdrlDt : ''
                    getJson.rgstDt = getJson.rgstDt ? getJson.rgstDt : ''
                    getJson.combProdYn = getJson.combProdYn
                        ? getJson.combProdYn
                        : ''
                    getJson.useYn = getJson.useYn ? getJson.useYn : ''
                    getJson.wrcellClCd = ''
                    getJson.prcplnClCd = getJson.prcplnClCd
                        ? getJson.prcplnClCd
                        : ''
                    getJson.prcplnClDtlCd = getJson.prcplnClDtlCd
                        ? getJson.prcplnClDtlCd
                        : ''
                    getJson.__rowState = 'created'
                    saveParam.push(getJson)
                }

                for (let idx = 0; idx < gridUpdatedIndexArr.length; idx++) {
                    let getJson = this.gridObj2.dataProvider.getJsonRow(
                        gridUpdatedIndexArr[idx]
                    )
                    getJson.suplSvcCd = getJson.suplSvcCd
                        ? getJson.suplSvcCd
                        : ''
                    getJson.suplSvcClCd = getJson.suplSvcClCd
                        ? getJson.suplSvcClCd
                        : ''
                    getJson.suplSvcNm = getJson.suplSvcNm
                        ? getJson.suplSvcNm
                        : ''
                    const wireClCd = this.returnWireProdClCd(
                        this.wireProd,
                        getJson.wireProdClNm
                    )
                    getJson.wireProdClCd = wireClCd
                    // getJson.wireProdClCd = getJson.wireProdClCd
                    //     ? getJson.wireProdClCd
                    //     : ''
                    getJson.rgstClCd = getJson.rgstClCd ? getJson.rgstClCd : ''
                    getJson.prodStCd = getJson.prodStCd ? getJson.prodStCd : ''
                    getJson.mktgDt = getJson.mktgDt ? getJson.mktgDt : ''
                    getJson.scrbStopDt = getJson.scrbStopDt
                        ? getJson.scrbStopDt
                        : ''
                    getJson.wdrlDt = getJson.wdrlDt ? getJson.wdrlDt : ''
                    getJson.rgstDt = getJson.rgstDt ? getJson.rgstDt : ''
                    getJson.combProdYn = getJson.combProdYn
                        ? getJson.combProdYn
                        : ''
                    getJson.useYn = getJson.useYn ? getJson.useYn : ''
                    getJson.wrcellClCd = ''
                    getJson.prcplnClCd = getJson.prcplnClCd
                        ? getJson.prcplnClCd
                        : ''
                    getJson.prcplnClDtlCd = getJson.prcplnClDtlCd
                        ? getJson.prcplnClDtlCd
                        : ''
                    getJson.__rowState = 'updated'

                    saveParam.push(getJson)
                }

                console.log('saveParam : ', saveParam)

                API.saveSuplTkpList(saveParam).then((result) => {
                    if (result !== undefined) {
                        this.showTcComAlert('정상적으로 처리되었습니다.')
                        // 매핑정보 재조회
                        this.onSearch()
                    } else {
                        this.showTcComAlert(result.message)
                    }
                })
            }
        },

        // 상품관리 화면 이동
        onProdClick() {
            this.$router.push({
                name: '/bas/pdm/BasPdmProdMgmt',
                params: { search: this.reqParam },
            })
        },

        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            return moment().format('YYYYMMDD') ?? ''
        },

        // 초기화
        onResetPage() {
            let clearDivSearch = {
                cmb_suplSvcCl: '',
                cmb_prcplnClCd: '',
                cmb_prcplnClDtlCd: '',
                prod_nm: '',
                cmb_prod_st: '',
                cmb_combProdYn: '',
                cmb_rgstCl: '',
                cmb_useYn: '',
                cmb_ignDcodeYn: '',
                cmb_ProdCL: '',
                cmb_basGrpCd: '',
                cmb_polBasGrpCd: '',
            }
            if (this.type == 0) {
                // 그리드 초기화
                this.gridData1 = this.gridSetData()
                this.gridObj1.dataProvider.clearRows()
                // 검색조건 초기화
                this.div_search = clearDivSearch
            } else {
                // 그리드 초기화
                this.gridData2 = this.gridSetData()
                this.gridObj2.dataProvider.clearRows()
                // 검색조건 초기화
                this.div_search = clearDivSearch
            }
        },
        // 그리드 로우 추가
        btn_add_OnClick() {
            let gridObj = this.type == 0 ? this.gridObj1 : this.gridObj2
            gridObj.gridView.commit()
            let rowCount = gridObj.dataProvider.getRowCount()
            let rowData = {
                rgstClCd: '사용자지정',
                mktgDt: this.getToday(),
                __rowState: 'created',
            }
            gridObj.dataProvider.insertRow(rowCount, rowData)
        },
        // 그리드 로우 삭제
        btn_del_OnClick() {
            let gridObj = this.type == 0 ? this.gridObj1 : this.gridObj2
            gridObj.gridView.commit()

            // 선택한 그리드 로우값
            const dataRow = gridObj.gridView.getCurrent().dataRow
            // 그리드 로우 == -1 => 선택된, 또는 선택할 데이터가 없음
            if (dataRow == -1) {
                this.showTcComAlert('삭제할 데이터가 없습니다.')
                return
            }

            // 선택한 로우에 해당하는 JSON데이터
            const selectedData = gridObj.dataProvider.getJsonRow(dataRow)
            console.log('selectedData : ', selectedData)
            const rowState = selectedData.__rowState

            if (dataRow >= 0) {
                if (rowState == undefined) {
                    this.showTcComAlert('기등록된 데이터는 삭제할 수 없습니다.')
                    return
                } else {
                    gridObj.dataProvider.removeRow(dataRow)
                }
            }
        },
    },
}
</script>
