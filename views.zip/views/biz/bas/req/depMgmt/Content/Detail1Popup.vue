<template>
    <TCComDialog :dialogShow.sync="activeOpen1" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">검증시나리오 등록</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- <ul class="btn_area top">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                @click="onUserCancel"
                                :objAuth="objAuth"
                            >
                                사용자취소
                            </TCComButton>
                        </li>
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="onConfirm"
                                :objAuth="objAuth"
                            >
                                저장
                            </TCComButton>
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="onClose"
                                :objAuth="objAuth"
                            >
                                닫기
                            </TCComButton>
                        </li>
                    </ul> -->
                    <!-- <div class="stitHead pop">
                        <h4 class="subTit">승인</h4>
                    </div> -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div1">
                                <TCComNoLabelTextArea
                                    v-model="parentParam1.vrfSnro"
                                    class="boxtype"
                                    :rows="10"
                                    labelName="검증시나리오"
                                />
                            </div>
                            <!-- <div class="formitem div1">
                                <span class="itemtit">
                                    <TCComLabel
                                        labelName="검증시나리오"
                                        :eRequired="true"
                                    />
                                </span>
                                <span class="iteminput">
                                    <TCComNoLabelTextArea
                                        v-model="parentParam1.vrfSnro"
                                        class="boxtype"
                                        :rows="10"
                                    />
                                </span>
                            </div> -->
                        </div>
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/req/depMgmt/helpers'
// eslint-disable-next-line no-unused-vars
import commonApi from '@/api/common/commonCode'
// eslint-disable-next-line no-unused-vars
import { CommonMsg, CommonBizClosing } from '@/utils'
// eslint-disable-next-line no-unused-vars
import moment from 'moment'
// eslint-disable-next-line no-unused-vars
import _ from 'lodash'
import CommonMixin from '@/mixins'

export default {
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            objAuth: {},
            parentParam0: [],
            parentParam1: {
                vrfSnro: '',
            },
            saveParam: {},
            userCancelSave: false,
        }
    },
    created() {
        //this.init()
    },
    mounted() {},
    computed: {
        ...serviceComputed,
        activeOpen1: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        ...serviceMethods,
        async init() {
            this.parentParam0 = []
            this.parentParam1 = {}
            this.saveParam = {}
            this.userCancelSave = false

            //this.searchDealParam.accDealcoCd = ''
            //this.searchDealParam.accDealcoNm = ''
        },
        async onConfirm() {
            const check1 = await this.validationCheck()
            if (!check1) {
                return
            }
            await this.save()
            console.log('onConfirm done')
            this.$emit('confirm', this.saveParam)
            this.onClose()
        },
        // onUserCancel() {
        //     const dtl1 = this.parentParam_origin
        //     this.resultPopup2Rows = []
        //     this.searchPopup2 = {
        //         nsokReqSerNo: dtl1.nsokReqSerNo,
        //         opDt: dtl1.opDt,
        //         opTm: dtl1.opTm,
        //         opSeq: dtl1.opSeq,
        //         rmks: '', //'비고',
        //     }
        //     this.showPopup2 = true
        //     console.log('UserCancel Popup', this.searchPopup2)
        // },
        onClose() {
            if (this.userCancelSave) {
                this.$emit('confirm', this.saveParam)
            }
            this.activeOpen1 = false
        },

        onSearch() {
            //this.getAgencyList()
        },

        onEnterKey() {
            //this.onSearch()
        },
        async validationCheck() {
            console.log('validationCheck', this.parentParam0)
            //const dtl1 = this.parentParam_origin //팝업에서 호출할 detail api value
            //const par1 = this.parentParam0 //전달 받은 value

            // let saleChgDtm = new Date(this.saleChgDtm)
            // let procDt1 = new Date(this.parentParam1.procDt)
            // let todatDt = new Date()
            // if (saleChgDtm > todatDt) {
            //     this.showTcComAlert('매출일자가 오늘일자 보다 큽니다.')
            //     return false
            // }
            if (_.isEmpty(this.parentParam1.vrfSnro)) {
                this.showTcComAlert('검증시나리오는 필수 입니다.')
                return false
            }

            const confirm = await this.showTcComConfirm('저장 하시겠습니까?')

            if (!confirm) {
                return false
            }
            return true
        },
        async save() {
            let saveRows = []
            //const lng1 = this.parentParam0.length
            // for (let i = 0; i < lng1; i++) {
            //     saveRows.push({
            //         //...this.parentParam0[i],
            //         rowState: 'updated',
            //         reqDt: this.parentParam0[i].reqDt,
            //         uuid: this.parentParam0[i].uuid,
            //         reqStNm: '승인',
            //         ...this.parentParam1,
            //     })
            // }
            saveRows.push({
                //...this.parentParam0[i],
                rowState: 'updated',
                reqDt: this.parentParam0[0].reqDt,
                uuid: this.parentParam0[0].uuid,
                ...this.parentParam1,
            })

            console.log('save 검증시나리오', saveRows)
            await this.saveDocMgmt_({ saveRows })
            this.saveParam = saveRows
        },
        maskingName(strName) {
            if (_.isEmpty(strName)) return strName
            if (strName.length > 2) {
                let originName = strName.split('')
                originName.forEach(function (name, i) {
                    if (i === 0 || i === originName.length - 1) return
                    originName[i] = '*'
                })
                let joinName = originName.join()
                return joinName.replace(/,/g, '')
            } else {
                let pattern = /.$/ // 정규식
                return strName.replace(pattern, '*')
            }
        },
    },
    watch: {
        parentParam: {
            handler: async function (value) {
                console.log('receive popup param', value)
                //await this.init()
                // console.log('menuInfo', this.menuInfo) //메뉴정보
                // console.log('orgInfo', this.orgInfo) //조직정보
                // console.log('userInfo', this.userInfo) //사용자정보
                // console.log('authInfo', this.authInfo) // 권한정보(속성권한)

                // //test data end -----------------
                const lst1 = _.clone(value.chkList)
                this.parentParam0 = lst1

                //파라메터 포맷팅 -------------------------------
                // this.parentParam1.aprvOrgCd = this.orgInfo.orgCd
                // this.parentParam1.aprvOrgNm = this.orgInfo.orgNm
                // this.parentParam1.aprvOrgNmView = this.orgInfo.orgNm
                // this.parentParam1.aprvUserId = this.userInfo.userId
                // this.parentParam1.aprvUserNm = this.userInfo.userNm
                // this.parentParam1.aprvUserNmView = `${this.maskingName(
                //     this.userInfo.userNm
                // )}(${this.userInfo.userId})`

                this.parentParam1.vrfSnro = this.parentParam0[0].vrfSnro

                console.log(
                    '검증시나리오 popup param value',
                    this.parentParam0,
                    this.parentParam1
                )
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>
