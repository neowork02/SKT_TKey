import { ValueType } from 'realgrid'

export const DisOpnOpenStMgmt_GRID_HEADER = {
    fields: [
        {
            fieldName: 'opnOrdDt',
            dataType: ValueType.TEXT, //개봉일자
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직
        },
        {
            fieldName: 'hldPlcNm',
            dataType: ValueType.TEXT, //보유처
        },
        {
            fieldName: 'openYn',
            dataType: ValueType.TEXT, //상태변경
        },
        {
            fieldName: 'procCnt',
            dataType: ValueType.TEXT, //개수
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT, //처리자
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, //처리자ID
        },
        {
            fieldName: 'hldPlcId',
            dataType: ValueType.TEXT, //보유처코드
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'newOrgId',
            dataType: ValueType.TEXT, //조직코드
        },
        {
            fieldName: 'newOrgNm',
            dataType: ValueType.TEXT, //조직
        },
        {
            fieldName: 'opnMgmtNo',
            dataType: ValueType.TEXT, //개봉관리번호
        },
    ],
    columns: [
        {
            name: 'opnOrdDt',
            fieldName: 'opnOrdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개봉일자',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            width: 300,
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcNm',
            fieldName: 'hldPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처',
                showTooltip: false,
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'openYn',
            fieldName: 'openYn',
            header: {
                text: '상태변경',
            },
            lookupDisplay: true,
            values: ['Y', 'N'],
            labels: ['미개봉 -> 개봉', '개봉 -> 미개봉'],
            editor: {
                type: 'dropDown',
                dropDownCount: 2,
            },
            styles: {
                textAlignment: 'center',
            },
        },
        {
            name: 'procCnt',
            fieldName: 'procCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '개수',
                showTooltip: false,
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcId',
            fieldName: 'hldPlcId',
            type: 'data',
            visible: false,
        },
        {
            name: 'newOrgId',
            fieldName: 'newOrgId',
            type: 'data',
            visible: false,
        },
        {
            name: 'newOrgNm',
            fieldName: 'newOrgNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'opnMgmtNo',
            fieldName: 'opnMgmtNo',
            type: 'data',
            visible: false,
        },
    ],
}
