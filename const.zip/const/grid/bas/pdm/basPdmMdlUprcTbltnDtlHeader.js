import { ValueType } from 'realgrid'

export const UPRC_DTL_HEADER = {
    fields: [
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        // {
        //     fieldName: 'prodChrticCd1',
        //     dataType: ValueType.TEXT,
        // },
        // {
        //     fieldName: 'prodChrticCd2',
        //     dataType: ValueType.TEXT,
        // },
        {
            fieldName: 'exitCashPrchsPrc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'exitCrdtPrchsPrc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'exitStrdSalePrc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'exitUnitSalePrc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixCashPrchsPrc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixCrdtPrchsPrc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixStrdSalePrc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixUnitSalePrc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'realPrchsPrc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgRealPrchsPrc',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            editable: false,
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            editable: false,
            width: '100',
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'eqpClCd',
            fieldName: 'eqpClCd',
            editable: false,
            header: {
                text: '단말기구분코드',
            },
        },
        {
            name: 'eqpClNm',
            fieldName: 'eqpClNm',
            editable: false,
            sortable: true,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: [],
                labels: [],
            },
            width: '80',
            header: {
                text: '단말기구분',
            },
        },
        {
            name: 'dealCoNm',
            fieldName: 'dealCoNm',
            editable: false,
            width: '150',
            header: {
                text: '제조사',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            editable: false,
            width: '250',
            header: {
                text: '모델',
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            editable: false,
            header: {
                text: '모델ID',
            },
        },
        // {
        //     name: 'prodChrticCd1',
        //     fieldName: 'prodChrticCd1',
        //     editable: false,
        //     header: {
        //         text: '상품특성1',
        //     },
        // },
        // {
        //     name: 'prodChrticCd2',
        //     fieldName: 'prodChrticCd2',
        //     editable: false,
        //     header: {
        //         text: '상품특성2',
        //     },
        // },
        {
            name: 'exitCashPrchsPrc',
            fieldName: 'exitCashPrchsPrc',
            editable: false,
            header: {
                text: '현금매입가',
            },
        },
        {
            name: 'exitCrdtPrchsPrc',
            fieldName: 'exitCrdtPrchsPrc',
            editable: false,
            header: {
                text: '여신매입가',
            },
        },
        {
            name: 'exitStrdSalePrc',
            fieldName: 'exitStrdSalePrc',
            editable: false,
            header: {
                text: '기준판매가',
            },
        },
        {
            name: 'exitUnitSalePrc',
            fieldName: 'exitUnitSalePrc',
            editable: false,
            header: {
                text: '판매단가',
            },
        },
        {
            name: 'fixCashPrchsPrc',
            fieldName: 'fixCashPrchsPrc',
            header: {
                text: '현금매입가',
            },
        },
        {
            name: 'fixCrdtPrchsPrc',
            fieldName: 'fixCrdtPrchsPrc',
            header: {
                text: '여신매입가',
            },
        },
        {
            name: 'fixStrdSalePrc',
            fieldName: 'fixStrdSalePrc',
            header: {
                text: '기준판매가',
            },
        },
        {
            name: 'fixUnitSalePrc',
            fieldName: 'fixUnitSalePrc',
            header: {
                text: '판매단가',
            },
        },
        {
            name: 'realPrchsPrc',
            fieldName: 'realPrchsPrc',
            header: {
                text: '실제매입가',
            },
        },
        {
            name: 'orgRealPrchsPrc',
            fieldName: 'orgRealPrchsPrc',
            header: {
                text: '',
            },
            visible: false,
        },
    ],
}

// Dtl header => 하나로 통합
// export const GNRL_HEADER = {
//     fields: [
//         {
//             fieldName: 'prodClCd',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'dstrbEqpClCd',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'dealCoNm',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'prodNm',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'prodCd',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'prodChrticCd1',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'prodChrticCd2',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'exitCashPrchsPrc',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'exitCrdtPrchsPrc',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'exitStrdSalePrc',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'exitUnitSalePrc',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'fixCashPrchsPrc',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'fixCrdtPrchsPrc',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'fixStrdSalePrc',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'fixUnitSalePrc',
//             dataType: ValueType.TEXT,
//         },
//         {
//             fieldName: 'realPrchsPrc',
//             dataType: ValueType.TEXT,
//         },
//     ],
//     columns: [
//         {
//             name: 'POL_YM',
//             fieldName: 'POL_YM',
//             editable: false,
//             header: {
//                 text: '적용년월',
//             },
//         },
//         {
//             name: 'POL_TS',
//             fieldName: 'POL_TS',
//             editable: false,
//             header: {
//                 text: '차수',
//             },
//         },
//         {
//             name: 'APLY_STA_DTM',
//             fieldName: 'APLY_STA_DTM',
//             editable: false,
//             header: {
//                 text: '적용시작일시',
//             },
//         },
//         {
//             name: 'APLY_END_DTM',
//             fieldName: 'APLY_END_DTM',
//             editable: false,
//             header: {
//                 text: '적용종료일시',
//             },
//         },
//         {
//             name: 'RMKS',
//             fieldName: 'RMKS',
//             editable: false,
//             header: {
//                 text: '비고',
//             },
//         },
//         {
//             name: 'PRD_MD_YN',
//             fieldName: 'PRD_MD_YN',
//             editable: false,
//             header: {
//                 text: '상품관리 변경여부',
//             },
//         },
//         {
//             name: 'mdl_cnt',
//             fieldName: 'mdl_cnt',
//             editable: false,
//             header: {
//                 text: '상품대상수',
//             },
//         },
//         {
//             name: 'MOD_USER_ID',
//             fieldName: 'MOD_USER_ID',
//             editable: false,
//             header: {
//                 text: '처리자ID',
//             },
//         },
//         {
//             name: 'MOD_USER_NM',
//             fieldName: 'MOD_USER_NM',
//             editable: false,
//             header: {
//                 text: '처리자',
//             },
//         },
//         {
//             name: 'MOD_DTM',
//             fieldName: 'MOD_DTM',
//             editable: false,
//             header: {
//                 text: '처리일시',
//             },
//         },
//     ],
// }
