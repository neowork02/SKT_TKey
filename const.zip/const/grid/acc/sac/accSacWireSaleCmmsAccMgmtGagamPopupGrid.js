import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = [
    {
        fieldName: 'accYm',
        header: { text: '정산월' },
        width: '80',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMM',
        columnDatetimeFormat: 'yyyy-MM',
        editable: false,
    },
    {
        fieldName: 'dataClNm',
        header: { text: '구분' },
        width: '80',
        editable: false,
    },
    {
        fieldName: 'saleMthClCd',
        header: { text: '영업월' },
        width: '100',
        sortable: true,
        lookupDisplay: true,
        values: ['2', '1'],
        labels: ['당월', '이전월'],
        editor: {
            type: 'dropdown',
            dropDownCount: 3,
            domainOnly: true,
            textReadOnly: true,
            values: ['2', '1'],
            labels: ['당월', '이전월'],
        },
    },
    {
        fieldName: 'orgTree',
        header: { text: '조직' },
        width: '310',
        editable: false,
    },
    {
        fieldName: 'accDealcoCd',
        header: { text: '정산처', showTooltip: false },
        width: '100',
        button: 'action',
        buttonVisibility: 'always',
    },
    {
        fieldName: 'accDealcoCdOld',
        header: { text: '[원값보존변수]정산처(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'accDealcoNm',
        header: { text: '정산처명' },
        width: '160',
        editable: false,
    },
    {
        fieldName: 'saleDealcoCd',
        header: { text: '판매처' },
        width: '100',
    },
    {
        fieldName: 'saleDealcoNm',
        header: { text: '판매처명' },
        width: '160',
    },
    {
        fieldName: 'addSubItmCd',
        header: { text: '수수료구분' },
        sortable: true,
        lookupDisplay: true,
        width: '180',
        values: [],
        labels: [],
        editor: {
            type: 'dropdown',
            dropDownCount: 10,
            domainOnly: true,
            textReadOnly: true,
            values: [],
            labels: [],
        },
    },
    {
        fieldName: 'addSubItmCdOld',
        header: { text: '[원값보존변수]수수료구분(숨김)' },
        width: '200',
        visible: false,
    },
    {
        fieldName: 'cmmsAddSubRsn',
        header: { text: '수수료설명' },
        width: '145',
    },
    {
        fieldName: 'addSubAmt',
        header: { text: '금액' },
        width: '100',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'saleDt',
        header: { text: '판매일' },
        width: '100',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'custNm',
        header: { text: '고객명' },
        width: '100',
    },
    {
        fieldName: 'svcNum',
        header: { text: '서비스번호' },
        width: '120',
    },
    {
        fieldName: 'wireSvcMgmtNum',
        header: { text: '서비스관리번호' },
        width: '120',
    },
    {
        fieldName: 'prodNm',
        header: { text: '모델명' },
        width: '150',
    },
    {
        fieldName: 'serNum',
        header: { text: '일련번호' },
        width: '100',
    },
    {
        fieldName: 'rmks',
        header: { text: '비고' },
        width: '200',
    },
    {
        fieldName: 'orgCd',
        header: { text: '조직코드(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'orgLvl',
        header: { text: '조직레벨(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'lvOrgCd',
        header: { text: '레벨0조직코드(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'orgNm',
        header: { text: '조직명(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'addSubSeq',
        header: { text: '가감순번(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'custNo',
        header: { text: '고객번호(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'saleTypeNm',
        header: { text: '판매유형명(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'prodClNm',
        header: { text: '상품구분명(숨김)' },
        width: '100',
        visible: false,
    },
    {
        fieldName: 'isAddRow',
        header: { text: '행추가Row인지여부(숨김)' },
        width: '100',
        visible: false,
    },
]

const GRID_HEADER = {}
GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)

export { GRID_HEADER }
