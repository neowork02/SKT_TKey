<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccPacPrseBondAdjMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <AccHeadline title="현금시재/채권조정관리" />

        <AccSearchField
            ref="accSearchField"
            divideCellCount="3"
            :offset="[
                'btn-right-reset',
                'btn-right-view',
                'btn-right-save',
                'btn-right-delete',
                'search-brws',
                'search-orgCd',
                '!search-dealcoCd',
            ]"
            :initValue="initValue"
            :popupParamOrgCd="popupParamOrgCd"
            :popupParamDealcoCd="popupParamDealcoCd"
            @reset="resetForm"
            @view="viewForm"
            @save="saveForm"
            @delete="deleteForm"
            @changeBrws="changeBrws"
            @changeOrgCd="changeOrgCd"
        />

        <AccGridTable
            ref="accGridTable"
            title="현금시재/채권조정관리"
            class="accGridTable"
            isEditable
            isCheckbox
            isFooter
            isColumnNo
            :isExcelupParse="true"
            :offset="['btn-addRow', 'btn-deleteRow', 'btn-excelDownload']"
            :preventEvent="['clickAddRow']"
            :gridMeta="GRID_HEADER"
            :data="formGetCashAdjs.data"
            :pagingInfo="formGetCashAdjs.pagingInfo"
            :exportInfo="{
                uri: `/api/v1/backend-max/resource/acc/pac/cash-adjs-excel-download`,
                query: formGetCashAdjs.query,
            }"
            @editCellButton="editCellButton"
            @rowUpdated="rowUpdated"
            @rowEditing="rowEditing"
            @movePage="movePage"
            @changePageSize="changePageSize"
            @addRow="addRow"
            @excelUpParseloadBtn="excelUpParseloadBtn"
        >
            <template #gridElementLeftArea>
                <span class="infoTxt color-red"
                    >당일 이전 데이터 입력/삭제 시 반드시 운영팀에 해당 월부터
                    채권 마감 재수행 요청 필수!</span
                >
            </template>
        </AccGridTable>

        <v-file-input
            id="excelUpload"
            ref="excelUpload"
            label="엑셀업로드 파일선택(숨김)"
            style="display: none"
            @change="onChangeExcelFile"
        ></v-file-input>

        <!-- 거래처팝업 -->
        <PopupDealcoClCd1
            v-if="popupDealcoClCd1.status.show"
            :parentParam="popupParamDealcoCd"
            :dialogShow.sync="popupDealcoClCd1.status.show"
            @confirm="changeDealcoClCd1"
        />
    </div>
</template>
<style lang="scss" scoped></style>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'
import _ from 'lodash'

import {
    getTodayDate,
    getCalcDays,
    distanceDate,
    convertDate,
    // gridMetaUtil,
} from '@/utils/accUtil'

import AccHeadline from '@/components/biz/common/acc/AccHeadline'
import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup' // 내부거래처(권한조직) 팝업

import pacApi from '@/api/biz/acc/pac'

import {
    GRID_HEADER,
    MOCK_DATA,
} from '@/const/grid/acc/pac/accPacPrseBondAdjMgmtGrid'

export default {
    name: 'AccPacPrseBondAdjMgmt',
    mixins: [CommonMixin, accMixin],
    components: {
        AccHeadline,
        AccSearchField,
        AccGridTable,
        PopupDealcoClCd1: BasBcoDealcosPopup,
    },
    data() {
        const today = getTodayDate('YYYY-MM-DD')

        return {
            GRID_HEADER,
            gridOldValue: {},

            initValue: {
                brws: [
                    getCalcDays('firstday', { target: today }, 'YYYY-MM-DD'),
                    today,
                ],
                pageSize: 15,
                pageNum: 1,
            },

            formGetCashAdjs: {
                data: [],
                query: {},
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formPostCashAdjs: {
                data: [],
                query: {},
                pagingInfo: {
                    pageSize: 15,
                },
            },

            popupParamOrgCd: {
                basMth: '',
            },

            popupParamDealcoCd: {
                orgNm: '', // 조직이름
                orgCd: '', // 조직코드
                basDay: '', // 기준년월
                dealcoGrpCd: '', // 거래처구분코드
                dealcoClCd1: '', // 거래처구분코드
            },

            popupDealcoClCd1: {
                query: {},
                status: {
                    show: false,
                },
            },
        }
    },

    computed: {},

    created() {
        this.initPage()
        console.log(pacApi, MOCK_DATA)
    },
    methods: {
        initPage() {},

        resetForm(query) {
            this.formGetCashAdjs.query = query
            this.formGetCashAdjs.data = []
        },

        viewForm(query) {
            //   "brwsTo": "string", 시작
            //   "brwsFr": "string", 끝
            //   "searchCoClOrgCd": "string", 조직코드
            //   "dealCoCd": "string", 거래처
            //   "dealCoNm": "string", 거래처

            if (!query.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }

            // MOCK
            // query.brwsTo = '20190501'
            // query.brwsFr = '20190530'
            // query.searchCoClOrgCd = 'O00000'

            if (distanceDate(query.brwsTo, query.brwsFr, 'months') != 0) {
                return this.showTcComAlert(
                    '시작일자와 종료일자을 동일한 월로 지정하세요'
                )
            }

            Object.assign(this.formGetCashAdjs.query, query)
            return this.getCashAdjs()
        },

        saveForm() {
            this.gridView.commit()

            // const rows = this.accGridTable.getChangedRow() 수정된 Row 데이터
            const rows = this.accGridTable.getAllRow() // 전체 Row 데이터

            if (rows.length == 0) {
                return this.showTcComAlert(`수정된 항목이 없습니다.`)
            } else {
                let ignoreList = []
                rows.forEach((row) => {
                    if (!row.wrtDt) {
                        ignoreList.push({
                            msg: '전기일을 입력해주세요.',
                            list: row,
                        })
                    }

                    if (!row.dealCoCd) {
                        ignoreList.push({
                            msg: '거래처를 입력해주세요.',
                            list: row,
                        })
                    }

                    if (!row.adjtAmt) {
                        ignoreList.push({
                            msg: '조정금액을 입력해주세요.',
                            list: row,
                        })
                    }

                    if (!row.rmks) {
                        ignoreList.push({
                            msg: '비고를 입력해주세요.',
                            list: row,
                        })
                    }
                })

                if (ignoreList.length) {
                    return this.showTcComAlert(ignoreList[0].msg)
                }

                this.formPostCashAdjs.query.accPacPrseBondAdjMgmtList = rows

                return this.postCashAdjs().then(this.getCashAdjs)
            }
        },

        async deleteForm() {
            this.gridView.commit()

            const rows = this.accGridTable.getCheckedRow() // 선택된 Row 데이터

            if (rows.length == 0) {
                return this.showTcComAlert(`선택된 항목이 없습니다.`)
            } else {
                if (
                    await this.showTcComConfirm(
                        '선택한 데이터를 삭제하시겠습니까?'
                    )
                ) {
                    // 신규추가 데이터는 서버통신 없이 삭제한다
                    const savedRow = rows.filter(
                        (row) => row.__rowState != 'created'
                    )

                    const createdRow = rows.filter(
                        (row) => row.__rowState == 'created'
                    )

                    const removeRowIdx = []

                    if (createdRow.length) {
                        createdRow.forEach((row) => {
                            removeRowIdx.push(row.dataRow)
                        })
                    }

                    if (savedRow.length) {
                        savedRow.forEach((arr) => (arr.__rowState = 'deleted'))

                        this.formPostCashAdjs.query.accPacPrseBondAdjMgmtList =
                            savedRow
                        this.postCashAdjs().then(() => {
                            savedRow.forEach((row) => {
                                removeRowIdx.push(row.dataRow)
                            })

                            this.accGridTable.removeRowData(removeRowIdx)
                        })
                    } else {
                        this.accGridTable.removeRowData(removeRowIdx)
                    }
                } else {
                    this.showTcComAlert('삭제가 취소되었습니다.')
                }
            }
        },

        // excelUpload(xlsData) {
        //     const rows = gridMetaUtil.xlsToGridData(this.GRID_HEADER, xlsData)

        //     rows.forEach((row) => {
        //         row.__rowState = 'created'
        //     })

        //     this.formGetCashAdjs.data = rows
        //     this.formGetCashAdjs.pagingInfo = {}
        // },

        excelUpParseloadBtn() {
            console.log('업로드')
            // this.$refs.accFileLoader.openSelector('excel')
            document.getElementById('excelUpload').click()
        },

        onChangeExcelFile: function (xlsData) {
            if (!_.isUndefined(xlsData) && !_.isNull(xlsData)) {
                const formData = new FormData()
                formData.append('files', xlsData)
                pacApi.getParseExcelCashAdjsTcip(formData).then((res) => {
                    console.log('res', res)
                    const rows = res
                    console.log('rows', rows)
                    rows.forEach((row) => {
                        row.__rowState = 'created'
                    })
                    this.formGetCashAdjs.data = rows
                    this.formGetCashAdjs.pagingInfo = {}
                })
                // 파일선택 inputbox의 값 제거
                document.getElementById('excelUpload').value = ''
            }
        },

        editCellButton(row, rowIdx, rowInfo) {
            const columnName = rowInfo.header.text
            console.log('columnName', columnName)

            switch (rowInfo.fieldName) {
                case 'dealCoCd':
                    if (row.__rowState == null) {
                        this.gridView.cancelEditor()
                        this.showTcComAlert(
                            `저장된 [${columnName}]는 수정할 수 없습니다.\n삭제 후 다시 등록하십시요.`
                        )
                    } else {
                        this.popupDealcoClCd1.query.rowIdx = rowIdx
                        this.popupDealcoClCd1.status.show = true
                    }
                    break
            }
        },

        rowEditing(row) {
            this.gridOldValue = { ...row }
        },

        rowUpdated(row, rowIdx, rowInfo) {
            const columnName = rowInfo.header.text
            const fieldName = rowInfo.fieldName

            switch (rowInfo.fieldName) {
                case 'wrtDt':
                case 'adjtAmt':
                    // rowInfo.status == 'none' --> 조회된 데이터
                    // rowInfo.status == 'updated' --> 조회된 데이터를 변경한 경우
                    // rowInfo.status == 'created' --> 추가된 데이터
                    // rowInfo.status == 'created' --> 추가한걸 변경한 경우
                    if (row.__rowState != 'created') {
                        this.gridView.cancelEditor()
                        this.accGridTable.dataProvider.setValue(
                            rowIdx,
                            fieldName,
                            this.gridOldValue[fieldName]
                        )
                        this.showTcComAlert(
                            `저장된 [${columnName}]는 수정할 수 없습니다.\n삭제 후 다시 등록하십시요.`
                        )
                    }
                    break
            }
        },

        addRow() {
            this.accGridTable.addRowData({}, 'first')
            //
        },

        changeOrgCd(query) {
            const { orgCd, orgNm, orgLvl } = query

            this.popupParamDealcoCd.orgLvl = orgLvl
            this.popupParamDealcoCd.orgCd = orgCd
            this.popupParamDealcoCd.orgNm = orgNm

            this.popupParamOrgCd.orgCd = orgCd
            this.popupParamOrgCd.orgNm = orgNm
        },

        changeBrws(date) {
            this.popupParamOrgCd.basMth = convertDate(date[0], 'YYYYMM')
        },

        changeDealcoClCd1(model) {
            const row = {
                dealCoCd: model.dealcoCd,
                dealCoNm: model.dealcoNm,
            }

            this.accGridTable.modifyRowData(
                this.popupDealcoClCd1.query.rowIdx,
                row
            )
        },

        movePage(query) {
            Object.assign(this.formGetCashAdjs.query, query)
            this.getCashAdjs()
        },

        changePageSize(query) {
            this.accSearchField.setQuery(query)
            // Object.assign(this.formGetCashAdjs.query, query)
        },

        deleteRow(rows, rowIdx) {
            this.dataProvider.removeRows(rowIdx)
        },

        getCashAdjs() {
            // this.formGetCashAdjs.data = [
            //     ...MOCK_DATA.accPacPrseBondAdjMgmtGrid.gridList,
            // ]

            // this.formGetCashAdjs.pagingInfo =
            //     MOCK_DATA.accPacPrseBondAdjMgmtGrid.pagingDto

            // return Promise.resolve()

            return pacApi
                .getCashAdjs(this.formGetCashAdjs.query)
                .then((res) => {
                    this.formGetCashAdjs.data = [
                        ...res.accPacPrseBondAdjMgmtGrid.gridList,
                    ]
                    this.formGetCashAdjs.pagingInfo =
                        res.accPacPrseBondAdjMgmtGrid.pagingDto

                    this.formPostCashAdjs.query = {
                        ...this.formGetCashAdjs.query,
                    }
                })
        },

        postCashAdjs() {
            return pacApi
                .postCashAdjs(this.formPostCashAdjs.query)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
        },
    },
}
</script>
