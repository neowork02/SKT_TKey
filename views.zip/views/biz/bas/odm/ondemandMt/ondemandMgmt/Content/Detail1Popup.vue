<template>
    <TCComDialog :dialogShow.sync="activeDetailPopup" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">OnDemand 상세</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div4">
                                <TCComComboBox
                                    v-model="parentParam1.opTypCd"
                                    codeId="ZBAS_ONDMND_OP_TYP_CD"
                                    labelName="업무유형"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div4">
                                <TCComDatePicker
                                    v-model="parentParam1.rgstDt"
                                    labelName="등록일자"
                                    :objAuth="objAuth"
                                ></TCComDatePicker>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="parentParam1.batId"
                                    labelName="BATCH ID"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="50"
                                ></TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    v-model="parentParam1.progId"
                                    labelName="프로그램ID"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                    :maxlength="50"
                                ></TCComInput>
                            </div>
                        </div>
                    </div>
                    <div id="detail1" class="searchLayer_wrap">
                        <div class="searchform">
                            <div id="detail1_1" class="formitem div2">
                                <div class="contBoth">
                                    <!-- gridWrap -->
                                    <div class="gridWrap">
                                        <table-container />
                                        <!-- <TCRealGrid
                                            id="ondemandMgmtDetail1Grid"
                                            ref="ondemandMgmtDetail1Grid"
                                            :editable="true"
                                        /> -->
                                        <!--
                                            :fields="header.fields"
                                            :columns="header.columns"
                                            @hook:mounted="gridMounted"
                                        -->
                                    </div>
                                    <!-- //gridWrap -->
                                </div>
                            </div>
                            <div id="detail1_c" class="formitem div2">
                                <div class="contBoth">
                                    <!-- gridWrap -->
                                    <div class="gridWrap">
                                        <TCComButton
                                            eClass="btn_ty"
                                            @click="onLeft"
                                        >
                                            {{ '' }}
                                            <font-awesome-icon
                                                icon="fa-solid fa-angles-left"
                                            />
                                        </TCComButton>
                                    </div>
                                    <div class="gridWrap">
                                        <TCComButton
                                            eClass="btn_ty"
                                            @click="onRight"
                                        >
                                            {{ '' }}
                                            <font-awesome-icon
                                                icon="fa-solid fa-angles-right"
                                            />
                                        </TCComButton>
                                    </div>
                                    <!--
                                            @click="removeChild(item)"

                                    -->
                                </div>
                            </div>
                            <div id="detail1_2" class="formitem div2">
                                <div class="contBoth">
                                    <!-- gridWrap -->
                                    <div class="gridWrap">
                                        <table-container2 />
                                        <!-- <TCRealGrid
                                            id="ondemandMgmtDetail2Grid"
                                            ref="ondemandMgmtDetail2Grid"
                                            :editable="true"
                                        /> -->
                                        <!--
                                            :fields="header.fields"
                                            :columns="header.columns"
                                            @hook:mounted="gridMounted"
                                        -->
                                    </div>
                                    <!-- //gridWrap -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="detail2" class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="parentParam1.pgmNm"
                                    labelName="작업설명(프로그램명)"
                                    class="boxtype"
                                    :rows="3"
                                    :maxlength="100"
                                ></TCComTextArea>
                            </div>
                            <!--
                                    v-model="selectedRow1.execCondDesc"
                                    class="boxtype"
                                            @click="removeChild(item)"

                                    -->
                        </div>
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/odm/ondemandMt/ondemandMgmt/helpers'
import { CommonGrid, CommonUtil } from '@/utils'
//import { SKT_AGENCYS_HEADER } from '@/const/grid/bas/odm/basOdmOndemandMgmtHeader'
//import basBcoAgencysApi from '@/api/biz/bas/bco/basBcoAgencys'
import commonApi from '@/api/common/commonCode'
import moment from 'moment'
// import _ from 'lodash'
import CommonMixin from '@/mixins'
import TableContainer from './Detail1Popup/TableContainer.vue'
import TableContainer2 from './Detail1Popup/TableContainer2.vue'

export default {
    mixins: [CommonMixin],
    components: {
        TableContainer,
        TableContainer2,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            //header: SKT_AGENCYS_HEADER,
            searchParam: {
                searchDateModel: '', // 조회기준일(v-model)
                searchDate: '', // 조회기준일
            },
            parentParam1: {},
            condArr: [],
        }
    },
    computed: {
        ...serviceComputed,
        activeDetailPopup: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    created() {
        this.init()
    },
    async mounted() {
        //this.gridObj = this.$refs.agencyMgmtAgencyGrid // Grid Object 설정
        //this.initGrid()
        let data = await this.basOdmOndemandMgmtConds_({
            param: {},
        })
        let inConds = []
        let outConds = []
        data.forEach((r) => {
            if (this.condArr.indexOf(r.condId) >= 0) {
                inConds.push(r)
            } else {
                outConds.push(r)
            }
        })
        await this.defaultAssign_({
            key: 'resultDetailAllList',
            value: outConds,
        })
        await this.defaultAssign_({
            key: 'resultDetailList',
            value: inConds,
        })
    },
    methods: {
        ...serviceMethods,
        init() {
            //this.gridData = this.gridSetData()
            this.searchParam.searchDateModel = moment().format('YYYY-MM-DD')
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false)
            this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

            //const commAgencyPtn = await this.getCommCodeList('AGENCY_PTN')
            //const commAgencyTyp = await this.getCommCodeList('AGENCY_TYP')

            // // 대리점 구분 lOV
            // this.gridObj.gridView.columnByName('agencyClCd').values =
            //     CommonUtil.convListToGridLovValues(commAgencyPtn, 'commCdVal')
            // this.gridObj.gridView.columnByName('agencyClCd').labels =
            //     CommonUtil.convListToGridLovLabels(commAgencyPtn, 'commCdValNm')
            // // 대리점 유형 lOV
            // this.gridObj.gridView.columnByName('agencyTypCd').values =
            //     CommonUtil.convListToGridLovValues(commAgencyTyp, 'commCdVal')
            // this.gridObj.gridView.columnByName('agencyTypCd').labels =
            //     CommonUtil.convListToGridLovLabels(commAgencyTyp, 'commCdValNm')

            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },

        gridMounted() {
            //console.log('gridMounted')
        },

        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            //console.log('getCommCodeList res: ', res)
            return res
        },

        async getAgencyList() {
            this.searchParam.searchDate = CommonUtil.replaceDash(
                this.searchParam.searchDateTemp
            )
            await this.getBasPrmAgencyMgmtAgencys_({
                param: this.searchParam,
            }).then((res) => {
                //console.log('getAgencyList then : ', res)
                this.gridObj.setRows(res)
            })
        },
        async onLeft() {
            console.log('click left : ')
            await this.defaultAssign_({
                key: 'moveStore',
                value: 'add',
            })
        },
        async onRight() {
            console.log('click right : ')
            await this.defaultAssign_({
                key: 'moveStore',
                value: 'del',
            })
        },
        async onConfirm() {
            // const current = this.gridObj.gridView.getCurrent()
            // if (current.dataRow === -1) {
            //     return
            // }
            // const jsonData = this.gridObj.dataProvider.getJsonRow(
            //     current.dataRow
            // )
            //this.$emit('confirm', jsonData)

            if (this.parentParam1.opTypCd === '') {
                this.showTcComAlert('업무유형을 선택하세요.')
                return
            }
            if (this.parentParam1.batId.trim() === '') {
                this.showTcComAlert('BATCH ID를 입력하세요.')
                return
            }
            if (this.parentParam1.progId.trim() === '') {
                this.showTcComAlert('프로그램ID를 입력하세요.')
                return
            }
            if (this.parentParam1.pgmNm.trim() === '') {
                this.showTcComAlert('작업설명(프로그램명) 을(를) 입력하세요.')
                return
            }
            if (this.resultDetailList.length == 0) {
                this.showTcComAlert('선택된 조회 조건이 없습니다.')
                return
            }

            for (let i = 1; i < 10; i++) {
                this.parentParam1['condId' + i] = null
                this.parentParam1['condNm' + i] = null
            }

            this.resultDetailList.forEach((r, index) => {
                this.parentParam1['condId' + (index + 1)] = r.condId
                this.parentParam1['condNm' + (index + 1)] = r.condNm
            })
            this.parentParam1['condCnt'] = this.resultDetailList.length

            this.parentParam1['rgstDt'] = this.parentParam1.rgstDt.replace(
                /-/g,
                ''
            )

            console.log('save popup param', JSON.stringify(this.parentParam1))
            let saveRows = []
            saveRows.push(this.parentParam1)
            let res1 = await this.saveOndemandMgmt_({ saveRows })
            if (res1 == 1) {
                this.toasting_({
                    message: '정상처리 되었습니다.',
                })
            }

            this.$emit('confirm', {})
            this.onClose()
        },

        onClose() {
            this.parentParam1 = {}
            this.activeDetailPopup = false
        },

        onSearch() {
            this.getAgencyList()
        },

        onEnterKey() {
            //this.onSearch()
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                if (value == null) {
                    console.log('new detail')
                    this.parentParam1['rowState'] = 'created'
                    this.parentParam1['opTypCd'] = ''
                    this.parentParam1['batId'] = ''
                    this.parentParam1['progId'] = ''
                    this.parentParam1['rgstDt'] = moment(new Date()).format(
                        'YYYY-MM-DD'
                    )
                    this.parentParam1['pgmNm'] = ''
                } else {
                    this.parentParam1 = value
                    this.parentParam1['rowState'] = 'updated'
                    // this.parentParam1.rgstDt = moment(
                    //     value.rgstDt,
                    //     'YYYYMMDDHHmmss'
                    // ).format('YYYY-MM-DD HH:mm:ss')
                    this.parentParam1.rgstDt = moment(
                        value.rgstDt,
                        'YYYYMMDD'
                    ).format('YYYY-MM-DD')

                    for (let i = 1; i < 10; i++) {
                        if (this.parentParam1['condId' + i] == null) break
                        this.condArr.push(this.parentParam1['condId' + i])
                    }
                }
                console.log(
                    'receive popup param',
                    JSON.stringify(this.parentParam1)
                )
            },
            deep: false, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style>
#detail1,
#detail2 {
    background-color: #ffffff !important;
}
#detail1_1 {
    width: 45% !important;
}
#detail1_c {
    width: 10% !important;
    text-align: center !important;
}
#detail1_2 {
    width: 45% !important;
}
</style>
