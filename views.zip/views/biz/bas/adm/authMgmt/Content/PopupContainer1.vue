<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">메뉴권한 설정</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- userMenuWrap -->
                    <div class="userMenuWrap">
                        <!-- userMenu_1depth -->
                        <div class="itemCont">
                            <ul>
                                <li
                                    v-for="(depth, idx) in itemList"
                                    v-bind:key="idx"
                                >
                                    <div class="item_wrap">
                                        <!-- depth1 -->
                                        <!-- label -->
                                        <span
                                            :class="
                                                depth.lastDepth
                                                    ? getIcon[depth.menuNo]
                                                    : 'minus'
                                            "
                                            @click="depthShow(depth)"
                                        ></span>
                                        <!-- 하위 depth 가 존재하는 경우 plus 아닌 경우 minus -->
                                        <!-- label -->
                                        <!-- checkbox -->
                                        <span
                                            class="chkWrap1"
                                            v-if="!depth.lastDepth"
                                        >
                                            <v-checkbox
                                                v-model="menuDepthKey"
                                                :value="
                                                    depth.menuNo + '_1_기본'
                                                "
                                            />
                                        </span>
                                        <!-- checkbox -->
                                        <!-- txt -->
                                        <span
                                            class="txt"
                                            @click="depthShow(depth)"
                                            :style="
                                                depth.boldCheck == true
                                                    ? 'color:blue;'
                                                    : 'color:black;'
                                            "
                                        >
                                            {{ depth.menuNm }}
                                        </span>
                                        <!-- txt -->
                                        <!-- depth1 -->
                                        <!-- depth2 -->
                                        <ol>
                                            <li
                                                v-for="(
                                                    subDepth, subIdx
                                                ) in depth.subMenus"
                                                v-bind:key="subIdx"
                                                v-show="
                                                    isDepthShow[depth.menuNo]
                                                "
                                            >
                                                <div class="item_wrap">
                                                    <!-- label -->
                                                    <span
                                                        :class="
                                                            subDepth.lastDepth
                                                                ? getIcon[
                                                                      subDepth
                                                                          .menuNo
                                                                  ]
                                                                : 'minus'
                                                        "
                                                        @click="
                                                            depthShow(subDepth)
                                                        "
                                                    ></span>
                                                    <!--
{{ subDepth.menuNo }} //
{{
    isDepthShow[
        depth.menuNo
    ]
}}-->
                                                    <!-- 하위 depth 가 존재하는 경우 plus 아닌 경우 minus -->
                                                    <!-- label -->
                                                    <!-- checkbox -->
                                                    <span
                                                        class="chkWrap1"
                                                        v-if="
                                                            !subDepth.lastDepth
                                                        "
                                                    >
                                                        <v-checkbox
                                                            v-model="
                                                                menuDepthKey
                                                            "
                                                            :value="
                                                                subDepth.menuNo +
                                                                '_1_기본'
                                                            "
                                                        />
                                                    </span>

                                                    <!-- checkbox -->
                                                    <!-- txt -->
                                                    <span
                                                        class="txt"
                                                        @click="
                                                            depthShow(subDepth)
                                                        "
                                                        :style="
                                                            subDepth.boldCheck ==
                                                            true
                                                                ? 'color:blue;'
                                                                : 'color:black;'
                                                        "
                                                    >
                                                        {{ subDepth.menuNm }}
                                                    </span>
                                                    <!-- txt -->
                                                </div>
                                                <!-- lastMenuCont -->
                                                <div
                                                    class="lastMenuCont"
                                                    v-for="(
                                                        lastDepth, lastIdx
                                                    ) in menuTadmAuthLst"
                                                    v-bind:key="lastIdx"
                                                >
                                                    <ul>
                                                        <li
                                                            v-for="(
                                                                data, idx
                                                            ) in lastDepth[
                                                                subDepth.menuNo
                                                            ]"
                                                            v-bind:key="idx"
                                                        >
                                                            <span
                                                                class="chkWrap1"
                                                            >
                                                                <v-checkbox
                                                                    v-model="
                                                                        menuDepthKey
                                                                    "
                                                                    :value="
                                                                        subDepth.menuNo +
                                                                        '_' +
                                                                        data.authNo +
                                                                        '_' +
                                                                        data.authNm
                                                                    "
                                                                    @change="
                                                                        depthKeyEvent(
                                                                            subDepth.menuNo +
                                                                                '_' +
                                                                                data.authNo +
                                                                                '_' +
                                                                                data.authNm
                                                                        )
                                                                    "
                                                                />
                                                            </span>
                                                            <span class="txt">
                                                                {{
                                                                    data.authNm
                                                                }}
                                                            </span>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <!-- lastMenuCont -->
                                                <ul>
                                                    <li
                                                        v-for="(
                                                            subDepth2, subIdx2
                                                        ) in subDepth.subMenus"
                                                        v-bind:key="subIdx2"
                                                        v-show="
                                                            isDepthShow[
                                                                subDepth.menuNo
                                                            ]
                                                        "
                                                    >
                                                        <div class="item_wrap">
                                                            <!-- label -->
                                                            <span
                                                                :class="
                                                                    subDepth2.lastDepth
                                                                        ? getIcon[
                                                                              subDepth2
                                                                                  .menuNo
                                                                          ]
                                                                        : 'minus'
                                                                "
                                                                @click="
                                                                    depthShow(
                                                                        subDepth2
                                                                    )
                                                                "
                                                            ></span>
                                                            <!-- 하위 depth 가 존재하는 경우 plus 아닌 경우 minus -->
                                                            <!-- label -->
                                                            <!-- checkbox -->
                                                            <span
                                                                class="chkWrap1"
                                                                v-if="
                                                                    !subDepth2.lastDepth
                                                                "
                                                            >
                                                                <v-checkbox
                                                                    v-model="
                                                                        menuDepthKey
                                                                    "
                                                                    :value="
                                                                        subDepth2.menuNo +
                                                                        '_1_기본'
                                                                    "
                                                                    @click="
                                                                        onCheckDepth2(
                                                                            subDepth2.menuNo
                                                                        )
                                                                    "
                                                                />
                                                            </span>
                                                            <!-- checkbox -->
                                                            <!-- txt -->
                                                            <span
                                                                class="txt"
                                                                @click="
                                                                    depthShow(
                                                                        subDepth2
                                                                    )
                                                                "
                                                                :style="
                                                                    subDepth2.boldCheck ==
                                                                    true
                                                                        ? 'color:blue;'
                                                                        : 'color:black;'
                                                                "
                                                            >
                                                                {{
                                                                    subDepth2.menuNm
                                                                }}
                                                            </span>
                                                            <!-- txt -->
                                                        </div>
                                                        <div
                                                            class="lastMenuCont"
                                                            v-for="(
                                                                lastDepth,
                                                                lastIdx
                                                            ) in menuTadmAuthLst"
                                                            v-bind:key="lastIdx"
                                                        >
                                                            <ul>
                                                                <li
                                                                    v-for="(
                                                                        data,
                                                                        idx
                                                                    ) in lastDepth[
                                                                        subDepth2
                                                                            .menuNo
                                                                    ]"
                                                                    v-bind:key="
                                                                        idx
                                                                    "
                                                                >
                                                                    <span
                                                                        class="chkWrap1"
                                                                    >
                                                                        <v-checkbox
                                                                            v-model="
                                                                                menuDepthKey
                                                                            "
                                                                            :value="
                                                                                subDepth2.menuNo +
                                                                                '_' +
                                                                                data.authNo +
                                                                                '_' +
                                                                                data.authNm
                                                                            "
                                                                            @change="
                                                                                depthKeyEvent(
                                                                                    subDepth2.menuNo +
                                                                                        '_' +
                                                                                        data.authNo +
                                                                                        '_' +
                                                                                        data.authNm
                                                                                )
                                                                            "
                                                                        />
                                                                    </span>
                                                                    <span
                                                                        class="txt"
                                                                    >
                                                                        {{
                                                                            data.authNm
                                                                        }}
                                                                    </span>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <!-- depth3 -->
                                                        <ul>
                                                            <li
                                                                v-for="(
                                                                    subDepth3,
                                                                    subIdx3
                                                                ) in subDepth2.subMenus"
                                                                v-bind:key="
                                                                    subIdx3
                                                                "
                                                                v-show="
                                                                    isDepthShow[
                                                                        subDepth2
                                                                            .menuNo
                                                                    ]
                                                                "
                                                            >
                                                                <div
                                                                    class="item_wrap"
                                                                >
                                                                    <!-- label -->
                                                                    <span
                                                                        :class="
                                                                            subDepth3.lastDepth
                                                                                ? getIcon[
                                                                                      subDepth3
                                                                                          .menuNo
                                                                                  ]
                                                                                : 'minus'
                                                                        "
                                                                        @click="
                                                                            depthShow(
                                                                                subDepth3
                                                                            )
                                                                        "
                                                                    ></span>
                                                                    <!-- 하위 depth 가 존재하는 경우 plus 아닌 경우 minus -->
                                                                    <!-- label -->
                                                                    <!-- checkbox -->
                                                                    <span
                                                                        class="chkWrap1"
                                                                        v-if="
                                                                            !subDepth3.lastDepth
                                                                        "
                                                                    >
                                                                        <v-checkbox
                                                                            v-model="
                                                                                menuDepthKey
                                                                            "
                                                                            :value="
                                                                                subDepth3.menuNo +
                                                                                '_1_기본'
                                                                            "
                                                                            @click="
                                                                                onCheckDepth3(
                                                                                    subDepth3.menuNo
                                                                                )
                                                                            "
                                                                        />
                                                                    </span>
                                                                    <!-- checkbox -->
                                                                    <!-- txt -->
                                                                    <span
                                                                        class="txt"
                                                                        @click="
                                                                            depthShow(
                                                                                subDepth3
                                                                            )
                                                                        "
                                                                        :style="
                                                                            subDepth3.boldCheck ==
                                                                            true
                                                                                ? 'color:blue;'
                                                                                : 'color:black;'
                                                                        "
                                                                    >
                                                                        {{
                                                                            subDepth3.menuNm
                                                                        }}
                                                                    </span>
                                                                    <!-- txt -->
                                                                </div>
                                                                <div
                                                                    class="lastMenuCont"
                                                                    v-for="(
                                                                        lastDepth2,
                                                                        lastIdx2
                                                                    ) in menuTadmAuthLst"
                                                                    v-bind:key="
                                                                        lastIdx2
                                                                    "
                                                                >
                                                                    <ul>
                                                                        <li
                                                                            v-for="(
                                                                                data3,
                                                                                idx3
                                                                            ) in lastDepth2[
                                                                                subDepth3
                                                                                    .menuNo
                                                                            ]"
                                                                            v-bind:key="
                                                                                idx3
                                                                            "
                                                                        >
                                                                            <span
                                                                                class="chkWrap1"
                                                                            >
                                                                                <v-checkbox
                                                                                    v-model="
                                                                                        menuDepthKey
                                                                                    "
                                                                                    :value="
                                                                                        subDepth3.menuNo +
                                                                                        '_' +
                                                                                        data3.authNo +
                                                                                        '_' +
                                                                                        data3.authNm
                                                                                    "
                                                                                    @change="
                                                                                        depthKeyEvent(
                                                                                            subDepth3.menuNo +
                                                                                                '_' +
                                                                                                data3.authNo +
                                                                                                '_' +
                                                                                                data3.authNm
                                                                                        )
                                                                                    "
                                                                                />
                                                                            </span>
                                                                            <span
                                                                                class="txt"
                                                                            >
                                                                                {{
                                                                                    data3.authNm
                                                                                }}
                                                                            </span>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                        <!-- //depth3 -->
                                                    </li>
                                                </ul>
                                            </li>
                                        </ol>
                                        <!-- depth2 -->
                                    </div>
                                    <!-- lastMenuCont -->
                                    <div
                                        class="lastMenuCont"
                                        v-for="(
                                            lastDepth, lastIdx
                                        ) in menuTadmAuthLst"
                                        v-bind:key="lastIdx"
                                    >
                                        <ul>
                                            <li
                                                v-for="(data, idx) in lastDepth[
                                                    depth.menuNo
                                                ]"
                                                v-bind:key="idx"
                                            >
                                                <span class="chkWrap1">
                                                    <v-checkbox
                                                        v-model="menuDepthKey"
                                                        :value="
                                                            depth.menuNo +
                                                            '_' +
                                                            data.authNo +
                                                            '_' +
                                                            data.authNm
                                                        "
                                                        @change="
                                                            depthKeyEvent(
                                                                depth.menuNo +
                                                                    '_' +
                                                                    data.authNo +
                                                                    '_' +
                                                                    data.authNm
                                                            )
                                                        "
                                                    />
                                                </span>
                                                <span class="txt">
                                                    {{ data.authNm }}
                                                </span>
                                            </li>
                                        </ul>
                                    </div>
                                    <!-- lastMenuCont -->
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- //userMenuWrap -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="saveBtn"
                            >저장
                        </TCComButton>
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import _ from 'lodash'
import { msgTxt } from '@/const/msg.Properties'
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/authMgmt/helpers'

export default {
    name: 'Home',
    mixins: [CommonMixin],
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: (data) => {
                return data
            },
            required: false,
        },
    },
    data() {
        return {
            isChecked: false,
            itemList: [],
            menuTadmAuthLst: [],
            getIcon: [],
            isDepthShow: [],
            menuDepthKey: [],
            delMenuDepthKey: new Set(),
            menuNo: [],
            clickMenuNo: [],
            userGrpCd: this.dtlData.userGrpCd,
            dtlList: [],
        }
    },
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        resultListMenuAdm1: {
            get() {
                return this.resultListAdmMenu
            },
        },
    },
    async mounted() {
        await this.getBasAdmMenuAuthMgmtList()
        console.log('itemList', this.itemList)
        console.log('dtlList', this.dtlList)
        // this.dtlList

        // this.dtlList.map((dtl) => {
        //     this.itemList.map((item) => {
        //         if (dtl.screenNo == item.menuNo) {
        //             this.depthShow(item)
        //         }
        //     })
        // })
        // this.depthShow()
        await this.init()
    },
    methods: {
        ...serviceMethods,
        init: function () {
            this.menuDepthKey = []
            this.defaultAssign_({
                key: 'menuParams',
                value: [],
            })
            this.defaultAssign_({
                key: 'menuAuthMgmtParam',
                value: [],
            })
            this.defaultAssign_({
                key: 'tadmAuthParam',
                value: [],
            })
        },

        //팝업닫기
        closeBtn: function () {
            this.activeOpen = false
        },

        async saveBtn() {
            if (!this.setParam()) {
                this.showTcComAlert('1개 이상 선택해 주시기 바랍니다.')
                return
            }
            await this.rgstBasAdmAuthMenuMgmt_()
                .then((data) => {
                    if (data === 0) {
                        this.showTcComAlert('등록실패')
                    } else {
                        this.showTcComAlert('등록완료')
                        this.activeOpen = false
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer1.vue ~ finally')
                    this.defaultAssign_({
                        key: 'menuParams',
                        value: [],
                    })
                })
        },
        setSaveDepthKey(params) {
            let depthParam = []

            let parentNo = new Set()
            let menuNo = new Set()
            console.log('this.menuDepthKey -> ', this.menuDepthKey)
            _.forEach(this.menuDepthKey, (item) => {
                let param = {}
                let screenNo = _.split(item, '_')[0]
                let authNo = _.split(item, '_')[1]
                let authNm = _.split(item, '_')[2]

                param['userGrpCd'] = this.userGrpCd
                param['screenNo'] = screenNo
                param['authNo'] = authNo
                param['authNm'] = authNm
                depthParam.push(param)
                menuNo.add(screenNo)
            })

            if (_.isEmpty(menuNo)) {
                return false
            }

            parentNo.forEach((item) => {
                let param = {}
                param['userGrpCd'] = this.userGrpCd
                param['screenNo'] = item
                param['authNo'] = '1'
                param['authNm'] = '기본'
                depthParam.push(param)
            })

            const unique = new Set(depthParam)
            const uniqueParam = [...unique]

            console.log('depthParam -> ', uniqueParam)
            params['tbasUserGrpDtlLst'] = uniqueParam
            params['userGrpCd'] = this.userGrpCd
        },
        setDelDepthKey(params) {
            let depthParam = []

            let menuNo = new Set()
            console.log('this.delMenuDepthKey -> ', this.delMenuDepthKey)

            this.delMenuDepthKey.forEach((item) => {
                let param = {}
                let screenNo = _.split(item, '_')[0]
                let authNo = _.split(item, '_')[1]
                let authNm = _.split(item, '_')[2]

                param['userGrpCd'] = this.userGrpCd
                param['screenNo'] = screenNo
                param['authNo'] = authNo
                param['authNm'] = authNm
                depthParam.push(param)
                menuNo.add(screenNo)
            })

            if (_.isEmpty(menuNo)) {
                return false
            }

            const unique = new Set(depthParam)
            const uniqueParam = [...unique]

            console.log('depthParam -> ', uniqueParam)
            params['tbasDelUserGrpDtlLst'] = uniqueParam
        },
        setParam() {
            let params = {}
            this.setSaveDepthKey(params)
            this.setDelDepthKey(params)
            this.defaultAssign_({
                key: 'menuParams',
                value: params,
            })
            return true
        },

        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        getMenuTree(menus) {
            const parentProp = 'supMenuNo' // 부모가 되는 속성 정의
            const keyProp = 'menuNo' // 키가 되는 속성 정의
            let map = {}
            let menuIds = new Set()

            let menuShow = {}
            let isDepthShow = {}
            for (let i = 0; i < menus.length; i++) {
                let obj = menus[i]
                obj.subMenus = []
                obj.lastDepth = false
                obj.depthCnt = i

                // 메뉴 정보를 map 오브젝트 속성(메뉴번호)에 설정
                map[obj[keyProp]] = obj
                // map[menus[i].parentProp].lvlGubun = 'subLvl'
                // 값이 존재하지 않으면 문자열 root으로 처리
                const parent = obj[parentProp] ?? 'root'
                obj.parentProp
                // 값이 존재하지 않으면 subMenus 속성 초기화
                if (!map[parent]) {
                    map[parent] = {
                        subMenus: [],
                        lastDepth: false,
                        depthCnt: i,
                    }
                }
                // obj.lvlGubun = 'subLvl'
                map[parent].subMenus.push(obj)
                // map[parent].subMenus.lvlGubun = 'subLvl'
                if (!_.isEmpty(map[parent].subMenus)) {
                    // 마지막뎁스에만 버튼 리스트를 추가한다.
                    map[parent].tadmAuthList = []
                    map[parent].lastDepth = true
                }

                if (!_.isEmpty(obj[parentProp])) {
                    menuIds.add(obj[parentProp])
                }
            }

            menuIds.forEach(
                (menuId) => (
                    (menuShow[menuId] = 'plus'), (isDepthShow[menuId] = false)
                )
            )

            this.getIcon = { ...menuShow }
            this.isDepthShow = { ...isDepthShow }

            return map['root'].subMenus
        },
        depthShow(obj) {
            console.log('itemList', this.itemList)
            if (_.isEqual(this.getIcon[obj.menuNo], 'minus')) {
                this.getIcon[obj.menuNo] = 'plus'
                this.isDepthShow[obj.menuNo] = false
            } else {
                this.getIcon[obj.menuNo] = 'minus'
                this.isDepthShow[obj.menuNo] = true
                if (obj.menuLvlCd != '1') {
                    for (let idx = 0; idx < obj.subMenus.length; idx++) {
                        this.getBasAdmMenuTadmAuthLst(
                            !obj.lastDepth,
                            obj.subMenus[idx].menuNo
                        )
                    }
                    console.log('this.menuTadmAuthLst', this.menuTadmAuthLst)
                }
            }
        },
        getBasAdmMenuTadmAuthLst(lastDepth, menuNo) {
            if (lastDepth) return
            let authLst = {}

            if (this.clickMenuNo.indexOf(menuNo) > -1) {
                return
            } else {
                this.clickMenuNo.push(menuNo)
            }
            this.loading(true)
            let data1

            let params = {}
            params['menuNo'] = menuNo
            this.defaultAssign_({
                key: 'tadmAuthParam',
                value: params,
            })
            this.getBasAdmMenuTadmAuthLst_()
                .then((data) => {
                    data1 = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    this.loading(false)
                    this.isChecked = true
                    // if (_.isEmpty(data1)) {
                    //     this.showTcComAlert(msgTxt.MSG_00039.replace(/%s/g, ''))
                    // } else {
                    //     // 조회성공시
                    //     authLst[menuNo] = data1
                    //     this.menuTadmAuthLst.push(authLst)
                    // }
                    if (!_.isEmpty(data1)) {
                        // 조회성공시
                        authLst[menuNo] = data1
                        this.menuTadmAuthLst.push(authLst)
                    }
                })
        },
        async getBasAdmMenuAuthMgmtList() {
            let params = {}
            params['userGrpCd'] = this.userGrpCd

            await this.defaultAssign_({
                key: 'menuAuthMgmtParam',
                value: params,
            })
            await this.loading(true)
            let data1
            await this.getBasAdmMenuAuthMgmtList_()
                .then((data) => {
                    data1 = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    this.loading(false)
                    this.isChecked = true
                    if (_.isEmpty(data1)) {
                        this.showTcComAlert(msgTxt.MSG_00039.replace(/%s/g, ''))
                        this.isChecked = false
                    } else {
                        const menuTree = this.getMenuTree(data1)
                        menuTree.map((menu) => {
                            menu.boldCheck = false
                            menu.subMenus.map((subMenu1) => {
                                subMenu1.boldCheck = false
                                subMenu1.subMenus.map((subMenu2) => {
                                    subMenu2.boldCheck = false
                                })
                            })
                        })
                        // this.$set(menuTree, 'boldCheck', 'false')
                        this.itemList = menuTree

                        console.log('menuTree -> ', menuTree)
                        if (this.isChecked) {
                            this.getBasAdmMenuAuthMgmtListDtl()
                        }
                    }
                })
        },
        async getBasAdmMenuAuthMgmtListDtl() {
            await this.loading(true)

            let data1

            await this.getBasAdmMenuAuthMenuMgmtDtl_()
                .then((data) => {
                    data1 = data
                    this.dtlList = data
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    this.loading(false)
                    this.setAuthInfo()

                    if (_.isEmpty(data1)) {
                        this.showTcComAlert(
                            msgTxt.MSG_00039.replace(/%s/g, '설정된')
                        )
                    } else {
                        _.forEach(data1, (items) => {
                            this.menuDepthKey.push(
                                (items.screenNo +=
                                    '_' + items.authNo + '_' + items.authNm)
                            )
                        })
                    }
                })
        },

        // 서버에서 가져온 권한정보를 화면이 마운트될때 표시
        setAuthInfo() {
            this.dtlList.map((dtl) => {
                this.itemList.map((item) => {
                    if (dtl.screenNo == item.menuNo) {
                        // this.depthShow(item)
                        item.boldCheck = true
                    }
                    this.dtlList.map((dtl) => {
                        item.subMenus.map((subMenu1) => {
                            if (dtl.screenNo == subMenu1.menuNo) {
                                // this.depthShow(subMenu1)
                                subMenu1.boldCheck = true
                            }
                            // this.dtlList.map((dtl) => {
                            //     subMenu1.subMenus.map((subMenu2) => {
                            //         if (dtl.screenNo == subMenu2.menuNo) {
                            //             // this.depthShow(subMenu2)
                            //             subMenu2.boldCheck = true
                            //         }
                            //     })
                            // })
                        })
                    })
                })
            })

            console.log('authinfo making', this.itemList, this.dtlList)
        },
        // 저장 시 단건처리
        depthKeyEvent(depthKey) {
            console.log('menuDepthKey -> ', this.menuDepthKey)

            let isDel = true
            _.forEach(this.menuDepthKey, (item) => {
                if (_.isEqual(item, depthKey)) {
                    isDel = false // 같은게 있으면 삭제된게 아님
                }
            })
            if (isDel) {
                console.log('depthKey -> ', depthKey)
                this.delMenuDepthKey.add(depthKey)
            } else {
                this.delMenuDepthKey.delete(depthKey)
            }

            console.log('this.delMenuDepthKey -> ', this.delMenuDepthKey)
        },

        // 저장 시 전체체크처리 삭제
        delAllEvent(depthKey, menuNo) {
            console.log(
                'menuDepthKey -> ',
                this.menuDepthKey,
                'depthKey -> ',
                depthKey
            )

            let menuDepthKeyCopy = this.menuDepthKey

            console.log('depthKey -> ', depthKey)
            let array = menuDepthKeyCopy.filter((value) => {
                return value.includes(menuNo)
            })
            array.push(`${menuNo}_1_기본`)
            // let list = new Set(array)
            array.map((p) => this.delMenuDepthKey.add(p))
            // this.delMenuDepthKey = list.add(`${menuNo}_1_기본`)

            console.log('this.delMenuDepthKey -> ', this.delMenuDepthKey)
        },

        onCheckDepth2(menuNo) {
            this.setDepthChk(menuNo)
        },

        onCheckDepth3(menuNo) {
            this.setDepthChk(menuNo)
        },

        async setDepthChk(menuNo) {
            const auths = _.find(this.menuTadmAuthLst, (item) => {
                return item[menuNo]
            })
            if (!_.isEmpty(auths)) {
                const menuDepthFindIndex = _.findIndex(
                    this.menuDepthKey,
                    (value) => {
                        return value === `${menuNo}_1_기본`
                    }
                )
                // this.delAllEvent(menuNo + '_1_기본', menuNo)
                // let menuDepthKeyCopy = this.menuDepthKey
                // this.delMenuDepthKey = menuDepthKeyCopy.filter((value) => {
                //     let returnValue = value.includes(menuNo)
                //     returnValue.push(`${menuNo}_1_기본`)
                //     return returnValue
                // })
                // this.delMenuDepthKey.push(`${menuNo}_1_기본`)
                if (menuDepthFindIndex < 0) {
                    // this.delMenuDepthKey.add(`${menuNo}_1_기본`)
                    await this.delAllEvent(menuNo + '_1_기본', menuNo)
                    this.menuDepthKey = this.menuDepthKey.filter((value) => {
                        return !value.includes(menuNo)
                    })
                }
                if (menuDepthFindIndex >= 0) {
                    // this.menuDepthKey.push(`${menuNo}_1_기본`)

                    _.forEach(auths[menuNo], (item) => {
                        this.menuDepthKey.push(
                            `${menuNo}_${item.authNo}_${item.authNm}`
                        )
                    })
                }
                // this.depthKeyEvent()
            }
            console.log('setDepthChk menuDepthKey: ', this.menuDepthKey)
        },
    },
}
</script>

<style lang="scss" scoped>
.item_wrap .chkWrap1 {
    position: relative;
    margin-bottom: 12px;
    user-select: none;
    cursor: pointer;
    height: 0;
    top: 2px;
}
</style>
