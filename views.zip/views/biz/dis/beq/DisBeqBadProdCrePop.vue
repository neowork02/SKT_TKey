<!-----------------------------------------------
 * 업무그룹명: 불량기기관리현황
 * 서브업무명: 불량기기등록
 * 설명: 불량기기등록 업데이트한다.
 * 작성자: P179234
 * 작성일: 2022.06.7
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">불량기기등록</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :codeVal.sync="reqParam.orgCd"
                                    :disabledAfter="true"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.orgNm"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :disabled="dataInfoDisabled01"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="reqParam.hldDealcoNm"
                                    :codeVal.sync="reqParam.hldDealcoCd"
                                    labelName="보유처"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onDealcoEnterKey"
                                    @appendIconClick="onDealcoIconClick"
                                    @input="onDealcoInput"
                                />
                                <BasBcoDealcosPop
                                    v-if="showBasBcoDealcos"
                                    :parentParam="searchForm"
                                    :rows="resultDealcoRows"
                                    :dialogShow.sync="showBasBcoDealcos"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComDatePicker
                                    labelName="등록일자"
                                    calType="D"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="setDate"
                                    :disabled="dataInfoDisabled02"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="일련번호"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.serNum"
                                    @enterKey="serNumChk"
                                    :disabled="dataInfoDisabled01"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="상품구분"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.prodClNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="모델"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.prodNm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="등록자"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.oprUserNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="제조사"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.mfactNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="색상"
                                    :eRequired="false"
                                    :disabled="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.colorNm"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComComboBox
                                    ref="opLclNmRef"
                                    codeId="ZDIS_C_00160"
                                    labelName="불량사유1"
                                    :objAuth="objAuth"
                                    :addBlankItem="true"
                                    :blankItemText="'선택'"
                                    v-model="reqParam.opLclCd"
                                    @change="onChangeOpLclNm"
                                    :disabled="dataInfoDisabled02"
                                    :eRequired="true"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComComboBox
                                    :codeId="opMclNmCodeId"
                                    labelName="불량사유2"
                                    v-model="reqParam.opMclCd"
                                    :objAuth="objAuth"
                                    :disabled="opMclNmDisabled"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    labelName="비고"
                                    :rows="5"
                                    v-model="reqParam.rmks"
                                    :disabled="dataInfoDisabled02"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="save"
                            :disabled="dataInfoDisabled02"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="deleteBtn"
                            :disabled="deleteBtnDisabled"
                            >불량해제</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                </div>
                <!-- 불량기기 해제  -->
                <BadProdOutPop
                    ref="popup"
                    v-if="showBadProdOut === true"
                    :dialogShow.sync="showBadProdOut"
                    :badProdDataOut.sync="badProd"
                    @confirm="onReturnBadProdOut"
                />

                <!-- 재고상품 리스트 조회 -->
                <DisDsmProdHstBrwsSerNumPopup
                    v-if="showPopupSerNum === true"
                    ref="popup"
                    :dialogShow.sync="showPopupSerNum"
                    :popupParams.sync="popupParamsSerNum"
                    @confirm="onReturnDisDsmProdHstBrwsSerNum"
                />
            </div>
        </template>
    </TCComDialog>
</template>
<!-----------------------------------------------
 * TODO LIST
 * 1 권한설정 - 로그인 사용자별 조직제어, 거래처 제어
 * 2 세션의 조직정보
 * 3 불량처리구분이 미처리가 아니면 비활성화
 * 4 콤보박스 - 불량사유 중분류
 * 5 불량기기 내역 조회하여 해제 정보 체크
 * 6 불량사유 중분류 onchanged 이벤트
 * 7 불량기기 검색 - onkeydown 이벤트 중 밸리데이션 및 바코드 입력
 * 8 등록일자 onchanged 이벤트
------------------------------------------------>
<script>
// import { AddBadProd } from './js/disBeqBadProd.js'
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
// import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
// import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
import disBeqBadProdApi from '@/api/biz/dis/beq/disBeqBadProdMgmt.js'
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

import { SacCommon } from '@/views/biz/sac/js'
import { CommonMsg, CommonBizClosing, CommonUtil } from '@/utils'
import BadProdOutPop from './DisBeqBadProdOutPop'

//====================내부거래처-전체조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-전체조직==================

// import dsmApi from '@/api/biz/dis/dsm/disDsmProdHstBrws'
import DisDsmProdHstBrwsSerNumPopup from '@/views/biz/dis/dsm/DisDsmProdHstBrwsSerNumPopup'

export default {
    name: 'Home',
    mixins: [CommonMixin],
    components: {
        // BasBcoOrgAgencysPopup,
        BasBcoAuthOrgTreesPopup,
        BadProdOutPop,
        BasBcoDealcosPop,
        DisDsmProdHstBrwsSerNumPopup,
    },
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        createBadProd: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    computed: {
        setDate: {
            get() {
                return this.reqParam.opDt
            },
            set(val) {
                this.reqParam.opDt = val

                // 내부조직팝업(권한) 기준년월 파라미터 set
                this.searchParam.basMth = CommonUtil.onlyNumber(val).substr(
                    0,
                    6
                )
                // 내부거래처 기준년월 파라미터 set
                this.searchForm.basDay = CommonUtil.onlyNumber(val)
                return val
            },
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
                this.$emit('update:addBadProd', value)
            },
        },
    },
    data() {
        return {
            objAuth: {},
            showBcoOrgAgencys: false,
            showBcoAuthOrgTrees: false,
            rowCnt: 15,
            searchForms: {},
            reqParam: {
                orgCd: '',
                orgLvl: '',
                orgNm: '',
                hldDealcoCd: '',
                hldDealcoNm: '',
                opDt: '',
                serNum: '',
                prodClCd: '',
                prodClNm: '',
                prodCd: '',
                prodNm: '',
                oprId: '',
                oprUserNm: '',
                mfactId: '',
                mfactNm: '',
                colorCd: '',
                colorNm: '',
                opLclCd: '',
                opMclCd: '',
                rmks: '',
            },
            // 상세 조회시 활성화여부
            dataInfoDisabled01: false,
            dataInfoDisabled02: false,
            //불량해제 버튼
            deleteBtnDisabled: false,
            // 불량사유 중분류
            opMclNmDisabled: true,
            opMclNmCodeId: '',
            //불량기기해제 팝업
            showBadProdOut: false,
            badProd: {},
            FV_NEW_INSERT_YN: '',
            // 불량기기 등록여부
            dsBadEquiYn: {},
            //====================내부거래처-전체조직====================
            showBasBcoDealcos: false,
            searchForm: {
                basDay: '', //기준일
                orgLvl: '', //조직레벨
                orgCd: '', //조직코드
                orgNm: '', //조직명
                dealcoGrpCd: '', //거래처그룹코드
                dealcoClCd1: '', //거래처구분코드
                dealcoClCd2: '', //거래처유형코드
                dealcoNm: '', //거래처명
                dealcoCd: '', //거래처코드
                sktChnlCd: '', //채널코드
                onlyAccDeaCoCd: '', //정산처여부
                dealEndYn: '', //거래종료포함여부
            },
            resultDealcoRows: [],
            //====================//내부거래처-전체조직==================
            // 내부조직 관련
            searchParam: {
                basMth: '', //예)202202, 2022-02 null이면 현재월셋팅
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            //일련번호 조회팝업
            popupParamsSerNum: {},
            showPopupSerNum: false,
        }
    },
    mounted() {
        this.initParam()
        this.setInfoData()
    },
    methods: {
        /* 파라미터 초기화 */
        initParam() {
            this.reqParam = {
                orgId: '',
                orgNm: '',
                hldDealcoCd: '',
                hldDealcoNm: '',
                opDt: this.getToday(),
                serNum: '',
                prodClCd: '',
                prodClNm: '',
                prodCd: '',
                prodNm: '',
                oprId: '',
                oprUserNm: this.userInfo['userNm'],
                mfactId: '',
                mfactNm: '',
                colorCd: '',
                colorNm: '',
                opLclCd: '',
                opMclCd: '',
                rmks: '',
            }
        },
        // 조회시 데이터 set
        setInfoData() {
            if (!_.isEmpty(this.createBadProd)) {
                this.FV_NEW_INSERT_YN = this.createBadProd.FV_NEW_INSERT_YN
                // 상세조회
                if ('N' == this.createBadProd.FV_NEW_INSERT_YN) {
                    this.reqParam = this.createBadProd

                    console.log(
                        'this.reqParam =============>>> ',
                        this.reqParam
                    )

                    this.dataInfoDisabled01 = true
                    if ('01' != this.reqParam.opClCd) {
                        this.dataInfoDisabled02 = true
                        this.opMclNmDisabled = true
                        if (
                            '09' != this.reqParam.opClCd &&
                            '12' != this.reqParam.opClCd
                        ) {
                            this.deleteBtnDisabled = true // 불량해제 버튼
                        }
                    }
                } else {
                    //신규등록
                    this.deleteBtnDisabled = true // 불량해제 버튼
                    this.reqParam.orgCd = this.createBadProd.orgCd
                        ? this.createBadProd.orgCd
                        : ''
                    this.reqParam.orgNm = this.createBadProd.orgNm
                        ? this.createBadProd.orgNm
                        : ''
                    this.reqParam.orgLvl = this.createBadProd.orgLvl
                        ? this.createBadProd.orgLvl
                        : ''
                    this.reqParam.hldDealcoNm = this.createBadProd.hldDealcoNm
                        ? this.createBadProd.hldDealcoNm
                        : ''
                    this.reqParam.hldDealcoCd = this.createBadProd.hldDealcoCd
                        ? this.createBadProd.hldDealcoCd
                        : ''
                }
            }
        },
        serNumChk() {
            let sSerNum = this.reqParam.serNum.replace('%', '')
            this.reqParam.serNum = sSerNum
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return
            }

            const formData = {
                orgCd: this.reqParam.orgCd,
                orgLvl: this.reqParam.orgLvl,
                serNum: this.reqParam.serNum,
                opDt: this.reqParam.opDt,
            }

            const snLength = _.size(this.reqParam.serNum)
            console.log('sernumber length >>>> ', snLength)
            if (
                7 == snLength ||
                8 == snLength ||
                10 == snLength ||
                11 == snLength ||
                12 == snLength
            ) {
                // 재고상품정보조회
                disBeqBadProdApi
                    .getBadProdDisInfo(formData)
                    .then((resultData) => {
                        if (resultData && resultData.length > 1) {
                            this.popupParamsSerNum.params = formData
                            this.popupParamsSerNum.api = 'badProd'

                            this.showPopupSerNum = true
                        } else if (resultData && resultData.length == 1) {
                            // this.setResultInfoData(resultData)
                            resultData[0].opDt = _.isEmpty(resultData[0].opDt)
                                ? this.getToday()
                                : resultData[0].opDt
                            this.reqParam = Object.assign(
                                this.reqParam,
                                resultData[0]
                            )
                            this.reqParam.orgCd = formData.orgCd
                            // this.reqParam.orgNm = formData.orgNm
                            this.reqParam.orgLvl = formData.orgLvl
                            this.reqParam.oprUserNm = this.userInfo['userNm']

                            // this.onProdEnterKey()
                        } else if (!resultData || resultData.length == 0) {
                            this.showTcComAlert(
                                '불량기기 대상 검색 정보가 없습니다.'
                            )
                        }
                    })
            } else {
                // 바코드조회
                // api url 변경해서 추가하기 *****
                disBeqBadProdApi
                    .getBadProdDisInfoBarCode(formData)
                    .then((res) => {
                        console.log(res)
                        if (!res || res.length == 0) {
                            this.showTcComAlert(
                                '불량기기 대상 검색 정보가 없습니다.'
                            )
                        } else {
                            // this.setResultInfoData(res)
                            res[0].opDt = _.isEmpty(res[0].opDt)
                                ? this.getToday()
                                : res[0].opDt
                            this.reqParam = Object.assign(this.reqParam, res[0])
                            this.reqParam.orgCd = formData.orgCd
                            // this.reqParam.orgNm = formData.orgNm
                            this.reqParam.orgLvl = formData.orgLvl
                            this.reqParam.oprUserNm = this.userInfo['userNm']
                        }
                    })
            }
        },
        onReturnDisDsmProdHstBrwsSerNum: function (retVal) {
            if (retVal.flag) {
                this.reqParam.serNum = retVal.data.serNum
                this.reqParam.prodCd = retVal.data.prodCd
                this.reqParam.colorCd = retVal.data.colorCd
                this.onProdEnterKey()
            }
        },

        /* 불량기기 검색 - 엔터키 이벤트 */
        async onProdEnterKey() {
            // if (ev) {
            // if (_.isEmpty(this.reqParam.orgCd)) {
            //     this.showTcComAlert(
            //         CommonMsg.getMessage('MSG_00083', '조직')
            //     )
            //     return
            // }
            //this.searchForms = { ...this.reqParam }
            this.searchForms = {
                orgCd: this.reqParam.orgCd,
                orgLvl: this.reqParam.orgLvl,
                // orgCd: 'A1003',
                // serNum: '02863820',
                serNum: this.reqParam.serNum,
                prodCd: this.reqParam.prodCd,
                colorCd: this.reqParam.colorCd,
                opDt: this.reqParam.opDt,
            }
            await disBeqBadProdApi
                .getBadProdDisInfo(this.searchForms)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        if (!res) {
                            this.showTcComAlert(
                                '불량기기 대상 검색 정보가 없습니다.'
                            )
                        } else {
                            // this.setResultInfoData(res)
                            res[0].opDt = _.isEmpty(res[0].opDt)
                                ? this.getToday()
                                : res[0].opDt
                            this.reqParam = Object.assign(this.reqParam, res[0])
                            this.reqParam.orgCd = this.searchForms.orgCd
                            // this.reqParam.orgNm = formData.orgNm
                            this.reqParam.orgLvl = this.searchForms.orgLvl
                            this.reqParam.oprUserNm = this.userInfo['userNm']
                        }
                    }
                })
            // }
        },

        // 바코드 조회 정보 세팅
        setResultInfoData(resList) {
            resList[0].opDt = _.isEmpty(resList[0].opDt)
                ? this.getToday()
                : resList[0].opDt
            this.reqParam = Object.assign(this.reqParam, resList[0])
        },

        /* 불량기기 저장 */
        async save() {
            console.log('저장')
            if (!(await this.fCheckCondition())) return
            console.log('저장전')
            const list = []

            // const testdata = {
            //     opDt: '20220801',
            //     oprUserId: '',
            //     oprUserNm: '',
            //     chrgrUserId: '',
            //     chrgrUserNm: '',
            //     dealcoClCd: '',
            //     dealcoClNm: '',
            //     saleDealcoCd: '',
            //     saleDealcdNm: '',
            //     saleShopCd: '',
            //     sktChnlCd: '',
            //     prodClCd: '',
            //     prodClNm: '',
            //     eqpClCd: '',
            //     mfactCd: '',
            //     mfactNm: '',
            //     barCdTypCd: '',
            //     barCdTypNm: '',
            //     prodCd: '10064',
            //     prodNm: '',
            //     colorCd: '99',
            //     colorNm: '',
            //     serNum: '19959651',
            //     ukeyExpartYn: '',
            //     opLclCd: '7',
            //     opLclNm: '',
            //     opMclCd: '',
            //     opMclNm: '',
            //     badStCd: '',
            //     badStNm: '',
            //     badDealcoCd: '',
            //     badDealcoNm: '',
            //     badShopCd: '',
            //     hldDealcoCd: '77399',
            //     hldDealcoNm: '',
            //     hldShopCd: '',
            //     lastInoutDtlClCd: '',
            //     lastInoutDtlClNm: '',
            //     opClCd: '',
            //     opClNm: '',
            //     rgstClCd: '',
            //     rgstClNm: '',
            //     rmks: '',
            //     badCnclDt: '',
            //     badCnclRsn: '',
            //     outOrgCd: '',
            //     outOrgNm: '',
            //     outLvOrgCd: '',
            //     outLvOrgNm: '',
            //     outLvOrgCd1: '',
            //     outLvOrgNm1: '',
            //     outLvOrgCd2: '',
            //     outLvOrgNm2: '',
            //     outLvOrgCd3: '',
            //     outLvOrgNm3: '',
            //     chk: '',
            //     rgstSeq: '',
            //     reqUserId: '',
            // }
            // list.push(testdata)

            list.push(this.reqParam)

            const formData = { rowDatas: list }
            await disBeqBadProdApi.saveBadProdRgsts(formData).then(() => {
                this.$emit('confirm', true)
                this.activeOpen = false
            })
        },
        // 불량해제
        deleteBtn() {
            if (
                '09' != this.reqParam.opClCd &&
                '12' != this.reqParam.opClCd &&
                '01' != this.reqParam.opClCd
            ) {
                this.showTcComAlert(
                    '미처리 또는 AS입고/교품반환입고 확정된 불량기기만 불량해제 등록을 할 수 있습니다.'
                )
                return
            }
            this.badProd = this.reqParam
            this.showBadProdOut = true
        },
        async fCheckCondition() {
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00083', '조직'))
                return false
            }
            if (_.isEmpty(this.reqParam.hldDealcoCd)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00083', '보유처'))
                return false
            }
            if (_.isEmpty(this.reqParam.opDt)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '등록일자')
                )
                return false
            }
            if (_.isEmpty(this.reqParam.serNum)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '일련번호')
                )
                return false
            }
            if (_.isEmpty(this.reqParam.prodNm)) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00083', '상품'))
                return false
            }
            if (_.isEmpty(this.reqParam.opLclCd)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '불량사유')
                )
                return false
            }
            if (!this.opMclNmDisabled && _.isEmpty(this.reqParam.opMclCd)) {
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00083', '불량사유')
                )
                return false
            }

            if (!this.cfGetClsStatus()) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00185', ''))
                return false
            }

            const oneAddMonth = SacCommon.cf_addMonth(
                SacCommon.cf_today(),
                1,
                'YYYYMMDD'
            )
            if (SacCommon.onlyNumber(this.reqParam.opDt) > oneAddMonth) {
                //불량등록일자는 현재일자보다 +30일 이상 일자는 선택 할 수 없습니다.
                this.showTcComAlert(
                    CommonMsg.getMessage('MSG_00099', '불량등록일자')
                )
                return false
            }

            // 최종입출고일자체크

            if ('Y' == this.FV_NEW_INSERT_YN) {
                // 불량기기 일련번호 기등록 여부 확인
                await this.fGetBadEquipYn()
                if (this.dsBadEquiYn && !_.isEmpty(this.dsBadEquiYn.serNum)) {
                    //
                    this.showTcComAlert(
                        CommonMsg.getMessage('MSG_00057', '일련번호')
                    )
                    return false
                }
            }
            return true

            // 불량해제 후 비고변경시 체크
        },
        // 불량기기내역 조회
        async fGetBadEquipYn() {
            const params = {
                prodCd: this.reqParam.prodCd,
                colorCd: this.reqParam.colorCd,
                serNum: this.reqParam.serNum,
                opDt: this.reqParam.opDt,
                hldDealcoCd: this.reqParam.hldDealcoCd,
            }
            await disBeqBadProdApi.getBadProdYn(params).then((res) => {
                this.dsBadEquiYn = res
            })
        },
        // 마감월 체크
        async cfGetClsStatus() {
            const clsStatus = await CommonBizClosing.getClsStatus(
                'D',
                SacCommon.removeHyphen(this.reqParam.opDt),
                'STK',
                this.reqParam.orgCd
            )
            if (clsStatus && 'CLS' == clsStatus.clsStCd) {
                this.showTcComAlert(CommonMsg.getMessage('MSG_00185', ''))
                return false
            }
            return true
        },
        onReturnBadProdOut(retVal) {
            if (retVal) {
                this.$emit('confirm', true)
                this.activeOpen = false
            }
        },
        onChangeOpLclNm(value) {
            console.log('onChangeOpLclNm =======>> ', value)
            if (
                '1' == value ||
                '2' == value ||
                '3' == value ||
                '4' == value ||
                '5' == value ||
                '6' == value
            ) {
                this.opMclNmDisabled = false
                this.opMclNmCodeId =
                    this.$refs.opLclNmRef.cItemList[value].subCommCdId
            } else {
                this.opMclNmDisabled = true
                this.opMclNmCodeId = ''
            }
        },

        /* 내부조직팝업 */
        getAuthOrgTreeList() {
            this.searchParam.orgCd = this.reqParam.orgCd
            this.searchParam.orgNm = this.reqParam.orgNm
            this.searchParam.orgLvl = this.reqParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        /* 내부조직팝업 - Icon 이벤트 처리 */
        onAuthOrgTreeIconClick() {
            this.resultAuthOrgTreeRows = []
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        /* 내부조직팝업 - TextField 엔터키 이벤트 처리 */
        onAuthOrgTreeEnterKey() {
            this.resultAuthOrgTreeRows = []
            // if (_.isEmpty(this.reqParam.orgNm)) {
            //     this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
            //     return
            // }
            this.getAuthOrgTreeList()
        },
        /* 내부조직팝업 - TextField Input 이벤트 이벤트 처리 */
        onAuthOrgTreeInput() {
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
        },
        /* 내부조직팝업 - 팝업 리턴 이벤트 이벤트 처리 */
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.reqParam.orgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.orgLvl = _.get(returnData, 'orgLvl')
        },
        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            this.searchForm.orgCd = this.reqParam.orgCd
            this.searchForm.orgNm = this.reqParam.orgNm
            this.searchForm.orgLvl = this.reqParam.orgLvl
            this.searchForm.dealcoCd = this.reqParam.hldDealcoCd
            this.searchForm.dealcoNm = this.reqParam.hldDealcoNm
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.reqParam.hldDealcoCd = _.get(res[0], 'dealcoCd')
                    this.reqParam.hldDealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.reqParam.hldDealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                // this.headerText = '검색조건 필수'
                return
            }
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.reqParam.hldDealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.reqParam.hldDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.hldDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        closeBtn() {
            this.activeOpen = false
        },
        /* 현재일자 확인(yyyy-mm-dd)*/
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
    },
}
</script>
