<!-----------------------------------------------
 * 업무그룹명: LoadingBar 컴포넌트
 * 서브업무명: LoadingBar 공통함수
 * 설명: LoadingBar 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.04.14
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <v-dialog v-model="dValue" persistent>
        <v-overlay :opacity="0">
            <v-progress-circular
                indeterminate
                color="point"
                size="30"
            ></v-progress-circular>
        </v-overlay>
    </v-dialog>
</template>

<script>
export default {
    inheritAttrs: false,
    name: 'TCComLoadingBar',
    components: {},
    props: {
        // 팝업오픈여부 양방향 바인딩
        value: { type: Boolean, default: false, required: false },
    },

    data() {
        return {
            dValue: false,
        }
    },
    computed: {},
    // props 동적 제어
    watch: {
        value: function () {
            this.dValue = this.value
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.dValue = this.value
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
