import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'trmsYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNmTree',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'setDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'setAmt', // 설정금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'originSetAmt', // 원본설정금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'accStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arSeq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'basSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'teamCd',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'erpTrmsYn',
            fieldName: 'erpTrmsYn',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: 'ERP 전송여부',
            },
        },
        {
            name: 'orgNmTree',
            fieldName: 'orgNmTree',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            editable: false,
            header: {
                text: '조직',
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '매장코드',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '거래처',
            },
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '거래처코드',
            },
        },
        {
            name: 'setDt',
            fieldName: 'setDt',
            type: 'data',
            width: '100',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editor: {
                type: 'date',
                textReadOnly: true,
                datetimeFormat: 'yyyyMMdd',
                mask: {
                    editMask: '9999-99-99',
                },
            },
            header: {
                // text: '* 설정일자',
                template: '<span class="emph_txt">* </span>${headerText}',
                values: { headerText: '설정일자' },
            },
        },
        {
            name: 'setAmt',
            fieldName: 'setAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                // text: '* 금액',
                template: '<span class="emph_txt">* </span>${headerText}',
                values: { headerText: '금액' },
            },
        },
        {
            name: 'accStNm',
            fieldName: 'accStNm',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '상태',
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '100',
            editable: false,
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
            header: {
                text: '처리일시',
            },
        },
    ],
}
