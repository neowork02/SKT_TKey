export default {
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 15,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 15, //전체 조회:9999
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    paging2: {
        pageNum: 1, //fix
        pageSize: 15,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging2: {
        pageNum: 1, //fix
        pageSize: 15, //전체 조회:9999
        totalPageCnt: 0,
        totalDataCnt: 0,
    },

    resultList: [],
    resultDetailList: [],
    resultDetailAllList: [],

    searchParams: {},
    popupParams: {},
    popupOpenNew: false,

    searchCl: '',
}
