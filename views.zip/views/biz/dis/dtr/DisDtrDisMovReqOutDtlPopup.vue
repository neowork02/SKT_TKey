<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 재고이동요청(출고) 상세
 * 설명: 재고이동요청 상세를 조회한다.
 * 작성자: P179229
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">재고이동요청(출고)</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.asgnDealcoNm"
                                    :readonly="true"
                                    labelName="재고보유처"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInputSearchText
                                    v-model="reqParam.prodCd"
                                    :codeVal.sync="reqParam.prodNm"
                                    labelName="모델"
                                    :readonlyAfter="true"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.colorNm"
                                    labelName="색상"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.mfactNm"
                                    labelName="제조사"
                                    :readonly="true"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.petNm"
                                    labelName="펫네임"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    codeId="ZDIS_C_00662"
                                    labelName="개봉상태"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.reqClCd"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    :itemList="chkData"
                                    labelName="대표모델"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.repProdYn"
                                />
                            </div>
                            <div class="formitem div1">
                                <TCComRadioBox
                                    :itemList="chkData"
                                    labelName="색상무관"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.colorUnrelYn"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.qckSvcCoNm"
                                    labelName="퀵서비스 업체명"
                                    :readonly="true"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.qckSvcTelNo"
                                    :readonly="true"
                                    labelName="퀵서비스 연락처"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.asgnReqQty"
                                    labelName="요청수량"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                    </div>
                    <!-- // Search_div -->

                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="popupGridHeader"
                            ref="popupGridHeader"
                            gridTitle="재고이동요청(출고)"
                            :gridObj="gridObj"
                        />
                        <TCRealGrid
                            id="popupGrid"
                            ref="popupGrid"
                            :editable="true"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>
                    <!-- //gridWrap -->
                    <!-- Close BTN-->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            v-show="reqParam.asgnStCd === '01'"
                            @click="saveBtn('03')"
                        >
                            거부
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            v-show="reqParam.asgnStCd === '01'"
                            @click="saveBtn('02')"
                        >
                            확정
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty01"
                            @click="closeBtn"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="closeBtn()"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import disDtrDisMovReqOutApi from '@/api/biz/dis/dtr/disDtrMovReqOut'
import { DisDtrDisMovReqOutDtlPopupGRID_HEADER } from '@/const/grid/dis/dtr/disDtrDisMovReqOutDtlPopupHeader'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'DisDtrDisMovReqOutDtlPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: DisDtrDisMovReqOutDtlPopupGRID_HEADER,
            reqParam: this.dtlData,
            chkData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
        }
    },
    created() {},
    mounted() {
        this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.popupGridHeader
        this.gridObj.setGridState(false, false, false)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        //요청정보 조회
        this.getDisMovReqOutDtl()
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        defaultSet() {
            this.gridData = this.gridSetData()
        },
        gridSetData: function () {
            // CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(-1, 10, '', '')
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        //요청상세조회
        getDisMovReqOutDtl() {
            disDtrDisMovReqOutApi
                .getDisDtrDisMovReqOutDtl(this.reqParam)
                .then((res) => {
                    this.reqParam = Object.assign(
                        {},
                        res.disDtrDisMovReqOutDtlVo
                    )
                    //Get Row Data
                    this.gridObj.setRows(res.disDtrDisMovReqOutVo)
                })
        },
        //확정
        saveBtn(stCd) {
            let saveData = Object.assign({}, this.reqParam)
            let confirmStr = '확정 하시겠습니까?'
            let chkData = []
            this.gridObj.gridView.commit()
            if (stCd == '02') {
                const rowCount = this.gridObj.dataProvider.getRowCount()
                for (var i = 0; i < rowCount; i++) {
                    var rowData = this.gridObj.dataProvider.getJsonRow(i)
                    if (_.get(rowData, 'asgnFixYn') === 'Y') {
                        chkData.push(rowData)
                    }
                }
                if (_.isEmpty(chkData)) {
                    this.showTcComAlert('확정할 일련번호를 선택해 주십시오.')
                    return
                }
                // if (this.reqParam.asgnReqQty != chkData.length) {
                //     this.showTcComAlert(
                //         '요청 수량과 동일한 일련번호 수량을 선택해 주십시오.'
                //     )
                //     return false
                // }
            } else {
                confirmStr = '거부 하시겠습니까?'
            }

            this.showTcComConfirm(confirmStr).then((confirm) => {
                if (confirm) {
                    saveData.asgnStCd = stCd
                    saveData.serNumList = chkData
                    disDtrDisMovReqOutApi
                        .saveDisDtrDisMovReqOutDtl(saveData)
                        .then((res) => {
                            // 정상
                            if (res === 1) {
                                this.getDisMovReqOutDtl()
                                this.$parent.searchBtn()
                            }
                        })
                }
            })
        },
    },
}
</script>
