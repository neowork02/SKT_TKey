import { ValueType } from 'realgrid'

export const DisIioSaleOutMgmt_GRID_HEADER = {
    fields: [
        {
            fieldName: 'outMgmtNo',
            dataType: ValueType.TEXT, // 출고관리번호
        },
        {
            fieldName: 'outPlcNm',
            dataType: ValueType.TEXT, // 출고처
        },
        {
            fieldName: 'outSktCd',
            dataType: ValueType.TEXT, // 출고처매장코드
        },
        {
            fieldName: 'inPlcNm',
            dataType: ValueType.TEXT, // 입고처
        },
        {
            fieldName: 'inSktCd',
            dataType: ValueType.TEXT, // 입고처매장코드
        },
        {
            fieldName: 'asgnClNm',
            dataType: ValueType.TEXT, // 주문유형
        },
        {
            fieldName: 'ordDt',
            dataType: ValueType.TEXT, // 주문일
        },
        {
            fieldName: 'prdpayReqDt',
            dataType: ValueType.TEXT, // 납기요청일
        },
        {
            fieldName: 'ordOprNm',
            dataType: ValueType.TEXT, // 주문처리자
        },
        {
            fieldName: 'ordQty',
            dataType: ValueType.NUMBER, // 요청수량
        },
        {
            fieldName: 'asgnQty',
            dataType: ValueType.NUMBER, // 배정수량
        },
        {
            fieldName: 'outSchdDt',
            dataType: ValueType.TEXT, // 출고지시일
        },
        {
            fieldName: 'outQty',
            dataType: ValueType.NUMBER, // 출고지시
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER, // 단가
        },
        {
            fieldName: 'amt',
            dataType: ValueType.NUMBER, // 금액
        },
        {
            fieldName: 'gap',
            dataType: ValueType.NUMBER, // Gap
        },
        {
            fieldName: 'outFixYn',
            dataType: ValueType.TEXT, // 처리상태
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 처리자ID
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT, // 처리자
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'asgnCl',
            dataType: ValueType.TEXT, // 주문유형코드
        },
        {
            fieldName: 'outOrgId',
            dataType: ValueType.TEXT, // 출고조직코드
        },
        {
            fieldName: 'outOrgNm',
            dataType: ValueType.TEXT, // 출고조직명
        },
        {
            fieldName: 'outDealCoGrp',
            dataType: ValueType.TEXT, // 출고처그룹코드
        },
        {
            fieldName: 'inOrgId',
            dataType: ValueType.TEXT, // 입고조직코드
        },
        {
            fieldName: 'inOrgNm',
            dataType: ValueType.TEXT, // 입고조직명
        },
        {
            fieldName: 'inDealCoGrp',
            dataType: ValueType.TEXT, // 입고처그룹코드
        },
        {
            fieldName: 'outPlcId',
            dataType: ValueType.TEXT, // 출고처코드
        },
        {
            fieldName: 'inPlcId',
            dataType: ValueType.TEXT, // 입고처코드
        },
    ],
    columns: [
        {
            name: 'outMgmtNo',
            fieldName: 'outMgmtNo',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'outSktCd',
            fieldName: 'outSktCd',
            type: 'data',
            width: 150,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcId',
            fieldName: 'outPlcId',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcNm',
            fieldName: 'outPlcNm',
            type: 'data',
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처',
                showTooltip: false,
            },
        },
        {
            name: 'inSktCd',
            fieldName: 'inSktCd',
            type: 'data',
            width: 150,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcId',
            fieldName: 'inPlcId',
            type: 'data',
            width: 120,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcNm',
            fieldName: 'inPlcNm',
            type: 'data',
            width: 200,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처',
                showTooltip: false,
            },
        },
        {
            name: 'asgnClNm',
            fieldName: 'asgnClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문유형',
                showTooltip: false,
            },
        },
        {
            name: 'ordDt',
            fieldName: 'ordDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'prdpayReqDt',
            fieldName: 'prdpayReqDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '납기요청일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'ordOprNm',
            fieldName: 'ordOprNm',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '주문처리자',
                showTooltip: false,
            },
        },
        {
            name: 'ordQty',
            fieldName: 'ordQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'asgnQty',
            fieldName: 'asgnQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정수량',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'outSchdDt',
            fieldName: 'outSchdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고일',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'outQty',
            fieldName: 'outQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'amt',
            fieldName: 'amt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'gap',
            fieldName: 'gap',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'GAP',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'outFixYn',
            fieldName: 'outFixYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리상태',
                showTooltip: false,
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: 150,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'asgnCl',
            fieldName: 'asgnCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'outOrgId',
            fieldName: 'outOrgId',
            type: 'data',
            visible: false,
        },
        {
            name: 'outOrgNm',
            fieldName: 'outOrgNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'outDealCoGrp',
            fieldName: 'outDealCoGrp',
            type: 'data',
            visible: false,
        },
        {
            name: 'inOrgId',
            fieldName: 'inOrgId',
            type: 'data',
            visible: false,
        },
        {
            name: 'inOrgNm',
            fieldName: 'inOrgNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'inDealCoGrp',
            fieldName: 'inDealCoGrp',
            type: 'data',
            visible: false,
        },
        {
            name: 'outPlcId',
            fieldName: 'outPlcId',
            type: 'data',
            visible: false,
        },
        {
            name: 'inPlcId',
            fieldName: 'inPlcId',
            type: 'data',
            visible: false,
        },
    ],
}
