import { ValueType } from 'realgrid'

export const GRID_INFO_EQP = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpTypClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpTypClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'eqpTypClNm',
            fieldName: 'eqpTypClNm',
            type: 'data',
            width: '20',
            header: {
                text: '단말방식',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            header: {
                text: '모델명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'petNm',
            fieldName: 'petNm',
            type: 'data',
            header: {
                text: '펫네임',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_PRICE = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'priceNm',
            fieldName: 'priceNm',
            type: 'data',
            header: {
                text: '기본료그룹',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'priceDesc',
            fieldName: 'priceDesc',
            type: 'data',
            header: {
                text: '기본료',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_PRICE_ID = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'priceCd',
            fieldName: 'priceCd',
            type: 'data',
            header: {
                text: '요금제ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'priceNm',
            fieldName: 'priceNm',
            type: 'data',
            header: {
                text: '요금제명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_PRICE_RESULT = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'priceCheck',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'priceCd',
            fieldName: 'priceCd',
            type: 'data',
            header: {
                text: '요금제그룹(ID)',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'priceNm',
            fieldName: 'priceNm',
            type: 'data',
            header: {
                text: '요금제그룹(ID)명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_EQP_TYPE = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpTypeCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpTypeNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'eqpTypeCd',
            fieldName: 'eqpTypeCd',
            type: 'data',
            header: {
                text: '유형코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'eqpTypeNm',
            fieldName: 'eqpTypeNm',
            type: 'data',
            header: {
                text: '단말기유형명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}

export const GRID_INFO_PRE_PAY = {
    fields: [
        {
            fieldName: 'gridFlag',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prePayCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prePayNm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'prePayCd',
            fieldName: 'prePayCd',
            type: 'data',
            header: {
                text: '선후불유형코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'prePayNm',
            fieldName: 'prePayNm',
            type: 'data',
            header: {
                text: '선후불유형명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
    ],
}
