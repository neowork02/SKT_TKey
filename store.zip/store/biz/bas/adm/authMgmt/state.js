export default {
    //alert message
    alertShow: false,
    alertHeaderText: '',
    alertBodyText: '',
    loadingShow: false,
    snackbar: false,
    snackbarText: '',
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 99999,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 99999,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    saveAction: false,
    saveDoneA: false,
    saveDoneB: false,
    saveOrgAction: false,
    saveAdmAuthDone: false,
    searchOrg: '',
    moveStore: '',

    currentAuth: '',
    resultList: [],
    resultListAll: [],
    resultListAdm: [],
    resultListAdmMenu: [],
    resultListTadmAuth: [],
    userGrpNmList: [],
    saveDataAdd: [],
    saveDataDel: [],

    searchParams: {},
    menuAuthMgmtParam: {},
    params: {},
    menuParams: {},
    saveParams: {},
    newDtlParam: {},
}
