<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="700px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">정산지원 답변등록</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="inputData.inqTitle"
                                    labelName="제목"
                                    :eRequired="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="inputData.inqCtt"
                                    labelName="내용"
                                    class="boxtype"
                                    :eRequired="true"
                                    :rows="8"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComComboBox
                                    codeId="ZACC_C_00200"
                                    labelName="처리상태"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    v-model="inputData.accProcStCd"
                                ></TCComComboBox>
                            </div>
                            <div class="searchform">
                                <div class="formitem div2">
                                    <TCComComboBox
                                        codeId="ZACC_C_00210"
                                        labelName="문의유형"
                                        :addBlankItem="true"
                                        blankItemText="전체"
                                        blankItemValue=""
                                        v-model="inputData.accQueTypCd"
                                    ></TCComComboBox>
                                </div>
                                <div class="formitem div2">
                                    <TCComComboBox
                                        codeId="ZACC_C_00220"
                                        labelName="문의세부"
                                        :addBlankItem="true"
                                        blankItemText="전체"
                                        blankItemValue=""
                                        v-model="inputData.accQueDtlCd"
                                    ></TCComComboBox>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 파일첨부 그리드 -->
                    <AttachedFileAdd
                        ref="attachedFileAdd"
                        :fileList="fileSearchList"
                        @file-change="onFileAddChange"
                        gridHeight="80px"
                        gridHeaderId="gridHearderAnsw"
                        gridId="gridAnsw"
                    ></AttachedFileAdd>

                    <!-- <div class="btn_area_bottom">
                        <div class="left">
                            <TCComButton
                                eClass="btn_ty01"
                                @click="reAnswRgstPopup"
                                >답변등록</TCComButton
                            >
                        </div>

                        <div class="right">
                            <TCComButton eClass="btn_ty01" @click="saveAnswRgst"
                                >저장</TCComButton
                            >
                            <TCComButton eClass="btn_ty01" @click="closeBtn"
                                >닫기</TCComButton
                            >
                        </div>
                    </div> -->
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom type2">
                        <div class="left">
                            <TCComButton
                                eClass="btn_ty02"
                                :eLarge="true"
                                @click="reAnswRgstPopup"
                                >답변등록</TCComButton
                            >
                        </div>
                        <div class="right">
                            <TCComButton
                                eClass="btn_ty02"
                                :eLarge="true"
                                @click="saveAnswRgst"
                                >저장</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty02"
                                :eLarge="true"
                                @click="closeBtn"
                                >목록</TCComButton
                            >
                        </div>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN(화면 우측 상단 X표시)-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>

            <!-- 답변등록 팝업 -->
            <reAnswRgstPopup
                v-if="reAnswShowPopupOrg === true"
                ref="reAnswPopup"
                :dialogShow.sync="reAnswShowPopupOrg"
                :popupParams="popupReAnswParams"
                @close="closeBtn"
            />
        </template>
    </TCComDialog>
</template>

<style lang="scss" scoped></style>

<script>
import CommonMixin from '@/mixins'
import { CommonUtil } from '@/utils'
import _ from 'lodash'
import AttachedFileAdd from '@/components/common/AttachedFileAdd'
import boardApi from '@/api/biz/acc/sac/AccSacAccBltnBrdApi'
import reAnswRgstPopup from '@/views/biz/acc/sac/AccSacAccBltnBrdReAnswRgst'

export default {
    name: 'AccSacAccBltnBrdAnswRgst',
    mixins: [CommonMixin],
    components: {
        AttachedFileAdd, //  파일첨부
        reAnswRgstPopup,
    },
    props: {
        //parmas
        popupParams: { type: Object, default: () => {}, required: false },
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            //  파일첨부
            admAppendFileList: [],
            formData: new FormData(),
            fileSearchList: [],

            //  답변등록팝업
            reAnswShowPopupOrg: false,
            popupReAnswParams: {},

            inputData: {
                accDealcoCd: '',
                accDealcoNm: '',
                accProcStCd: '',
                accQueDtlCd: '',
                accQueTypCd: '',
                accYm: '',
                boardLvl: '',
                boardNo: '',
                docId: '',
                inqCtt: '',
                inqTitle: '',
                makeDtm: '',
                maxBoardLvl: '',
                maxBoardNo: '',
                modUserId: '',
                orgCd: '',
                orgBoardNo: '',
                supBoardNo: '',
                screenId: 'AccSacAccBltnBrd',
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        //  화면 초기 셋팅
        this.getBase()
    },
    methods: {
        //팝업닫기
        closeBtn: function () {
            this.activeOpen = false
            this.$emit('close')
        },
        //  초기값 셋팅
        getBase: function () {
            delete this.popupParams.inqTitle
            delete this.popupParams.inqCtt

            if (this.popupParams.newOpenYn == 'Y') {
                //  질문상세화면(AccSacAccBltnBrdInqRgst)에서 호출
                this.inputData = this.popupParams
                this.inputData.modUserId = ''

                this.isAnswRgstBtn = true
            } else {
                //  메인화면(AccSacAccBltnBrd)에서 Row더블클릭으로 오픈
                this.isAnswRgstBtn = false

                // 조회
                this.loadData()
            }
        },
        loadData: function () {
            //  조회API 호출
            boardApi
                .getBoardAnswRgstList(this.popupParams)
                .then((resultData) => {
                    this.inputData = resultData

                    //  첨부파일 조회
                    boardApi.getAnswAttachFile(this.inputData).then((res) => {
                        this.fileSearchList = []
                        res.forEach((item) => {
                            this.fileSearchList.push({
                                screenId: item.screenId,
                                docId: item.docId,
                                name: item.fileNm,
                                size: item.fileSize,
                                filePathNm: item.filePathNm,
                                fileType: item.fileType,
                            })
                        })
                        this.$refs.attachedFileAdd.init()
                    })
                })
        },

        //  저장
        saveAnswRgst: function () {
            if (_.isEmpty(this.inputData.inqTitle)) {
                this.showTcComAlert('제목을 입력하십시오.')
                return
            } else if (!CommonUtil.chkRmks(this.inputData.inqTitle)) {
                this.showTcComAlert('제목을 확인하십시오.')
                return
            }
            if (_.isEmpty(this.inputData.inqCtt)) {
                this.showTcComAlert('내용을 입력하십시오.')
                return
            } else if (!CommonUtil.chkRmks(this.inputData.inqCtt)) {
                this.showTcComAlert('내용을 확인하십시오.')
                return
            }
            if (
                !_.isEmpty(this.inputData.modUserId) &&
                this.inputData.modUserId != this.userInfo.userId
            ) {
                this.showTcComAlert('작성자만 저장 할 수 있습니다.')
                return
            }
            if (this.inputData.boardLvl < this.inputData.maxBoardLvl) {
                this.showTcComAlert('답글이 등록되어 저장 할 수 없습니다.')
                return
            }
            if (_.isEmpty(this.inputData.accProcStCd)) {
                this.showTcComAlert('처리상태를 입력하십시오.')
                return
            }
            if (_.isEmpty(this.inputData.accQueTypCd)) {
                this.showTcComAlert('문의유형을 입력하십시오.')
                return
            }
            if (_.isEmpty(this.inputData.accQueDtlCd)) {
                this.showTcComAlert('문의세부를 입력하십시오.')
                return
            }

            this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    //  첨부파일 저장
                    boardApi
                        .saveAnswAttachFile(this.formData)
                        .then((resultData) => {
                            if (resultData != null) {
                                this.inputData.docId = resultData[0].docId
                            }

                            //  문의상세내용 저장
                            return boardApi.saveBoardAnswRgst(this.inputData)
                        })
                        .then((resultData) => {
                            if (resultData) {
                                this.showTcComAlert('저장되었습니다.')
                                this.closeBtn()
                            }
                        })
                }
            })
        },
        //  파일첨부(Add,Delete)
        onFileAddChange(files) {
            console.log('files: ', files)
            this.formData = new FormData()
            const addFileLength = files.addFile.length

            var sDocId = ''
            if (
                this.inputData.docId == undefined ||
                this.inputData.docId == null
            ) {
                sDocId = ''
            } else {
                sDocId = this.inputData.docId
            }

            _.forEach(files.addFile, (item, index) => {
                this.formData.append('files', item.file)
                this.formData.append(
                    `admAppendFileList[${index}].fileNm`,
                    CommonUtil.getFileName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].fileType`,
                    CommonUtil.getExtensionName(item.file.name)
                )
                this.formData.append(
                    `admAppendFileList[${index}].screenId`,
                    'AccSacAccBltnBrd'
                )
                this.formData.append(
                    `admAppendFileList[${index}].docId`,
                    sDocId
                    // this.inputData.docId === undefined
                    //     ? ''
                    //     : this.inputData.docId
                )
                this.formData.append(
                    `admAppendFileList[${index}].__rowState`,
                    'created'
                )
            })
            _.forEach(files.delFile, (item, index) => {
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].filePathNm`,
                    item.filePathNm
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].fileType`,
                    item.fileType
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].screenId`,
                    item.screenId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].docId`,
                    item.docId
                )
                this.formData.append(
                    `admAppendFileList[${index + addFileLength}].__rowState`,
                    'deleted'
                )
            })
        },

        //  답변등록 팝업 Open
        reAnswRgstPopup: function () {
            if (this.inputData.boardLvl < this.inputData.maxBoardLvl) {
                this.showTcComAlert('답글이 등록되어 있습니다.')
                return
            }
            if (this.inputData.boardLvl == '4') {
                this.showTcComAlert('더이상 답변등록 할 수 없습니다.')
                return
            }
            if (this.userInfo.userId == this.inputData.modUserId) {
                this.showTcComAlert('질문게시자는 답변등록 할 수 없습니다.')
                return
            }

            //  답변등록 팝업 오픈
            this.popupReAnswParams.orgBoardNo = this.inputData.orgBoardNo
            this.popupReAnswParams.supBoardNo = this.inputData.boardNo
            this.popupReAnswParams.accYm = this.inputData.accYm
            this.popupReAnswParams.accDealcoCd = this.inputData.accDealcoCd
            this.popupReAnswParams.accDealcoNm = this.inputData.accDealcoNm
            this.popupReAnswParams.boardLvl = this.inputData.boardLvl
            this.popupReAnswParams.accProcStCd = this.inputData.accProcStCd
            this.popupReAnswParams.accQueTypCd = this.inputData.accQueTypCd
            this.popupReAnswParams.accQueDtlCd = this.inputData.accQueDtlCd
            this.popupReAnswParams.makeDtm = this.inputData.makeDtm

            this.reAnswShowPopupOrg = true
        },
    },
}
</script>
