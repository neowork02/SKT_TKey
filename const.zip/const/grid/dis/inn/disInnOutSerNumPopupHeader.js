import { ValueType } from 'realgrid'

export const DisInnOutSerNumSrchGRID_HEADER = {
    fields: [
        {
            fieldName: 'outOrgNm',
            dataType: ValueType.TEXT, //츨고조직
        },
        {
            fieldName: 'outDealcoCd',
            dataType: ValueType.TEXT, //출고처코드
        },
        {
            fieldName: 'outDealcoNm',
            dataType: ValueType.TEXT, //출고처
        },
        {
            fieldName: 'outDealSktCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'outSerNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'outColorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'outColorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'outUpdCnt',
            dataType: ValueType.TEXT, //수정횟수
        },
        {
            fieldName: 'outBadYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'outDisStCd',
            dataType: ValueType.TEXT, //재고상태
        },
    ],
    columns: [
        {
            name: 'outOrgNm',
            fieldName: 'outOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: '400',
            header: {
                text: '츨고조직',
                showTooltip: false,
            },
        },
        {
            name: 'outDealcoCd',
            fieldName: 'outDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: '100',
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: '140',
            header: {
                text: '출고처',
                showTooltip: false,
            },
        },
        {
            name: 'outDealSktCd',
            fieldName: 'outDealSktCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: '120',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'outSerNum',
            fieldName: 'outSerNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: '140',
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'outColorNm',
            fieldName: 'outColorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: '140',
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'outColorCd',
            fieldName: 'outColorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'outUpdCnt',
            fieldName: 'outUpdCnt',
            visible: false,
            type: 'data',
        },
        {
            name: 'outBadYn',
            fieldName: 'outBadYn',
            visible: false,
            type: 'data',
        },
        {
            name: 'outDisStCd',
            fieldName: 'outDisStCd',
            visible: false,
            type: 'data',
        },
    ],
}
