/**************************************************************************************************************
 * 가상데이터 선언 영역
 **************************************************************************************************************/
import send from '@/api/axios-tdcs'
// import _ from 'lodash'

export default {
    namespaced: true,
    state: {
        // 목록검색조건
        dsCondition: {
            grpNo: '', // 거래처그룹번호
            orgCd: '', // 조직코드
            orgNm: '', // 조직명
            dealcoGrpClCd: '', // 거래처그룹구분코드
            aplyDt: [], // 적용기간
            aplyStaDt: '', // 적용시작일자
            aplyEndDt: '', // 적용종료일자
            dealcoGrpNm: '', // 거래처그룹명
            dealcoClCd2: '', // 거래처유형
            dealcoClCd1: '', // 거래처구분
            dealcoNm: '', // 거래처코드/명
        },
        dsPolDealCoGrpMgmt: {
            rowState: '',
            grpNo: '', // 그룹번호
            dealcoGrpNm: '', // 거래처그룹명
            useYn: '', // 사용여부
            regDealCnt: 0, // 거래처수
            aplyDt: [], // 적용기간
            aplyStaDt: '', // 적용시작일자
            aplyEndDt: '', // 적용종료일자
            rmks: '', // 비고
        },
        dsPolDealCoGrpDtl: [], // 거래처그룹상세목록
        dsBasDealCoList: [], // 거래처목록
    },

    mutations: {
        setDsCondition(state, payload) {
            state.dsCondition = {
                ...state.dsCondition,
                ...payload,
            }
        },
        setDsPolDealCoGrpMgmt(state, payload) {
            state.dsPolDealCoGrpMgmt = payload
        },
        setDsPolDealCoGrpDtl(state, payload) {
            state.dsPolDealCoGrpDtl = payload
        },
        setDsBasDealCoList(state, payload) {
            state.dsBasDealCoList = payload
        },
        setPolDealCoGrpInfo(state, payload) {
            state.dsPolDealCoGrpMgmt = {
                ...payload.polDealCoGrpMgmt,
                aplyDt: [
                    payload.polDealCoGrpMgmt.aplyStaDt,
                    payload.polDealCoGrpMgmt.aplyEndDt,
                ],
            }
            state.dsPolDealCoGrpDtl = payload.polDealCoGrpDtl
        },
    },
    actions: {
        async getPolDealCoGrpList({ commit }, payload) {
            console.log('getPolTDealCoGrpList::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'get',
                    url: '/api/v1/backend/pol/std/getPolTdealcoGrpList',
                    params: payload,
                })
                    .then((res) => {
                        console.log('getPolDealCoGrpList[then]', res)
                        commit('setPolDealCoGrpList', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
        async getCommDealcoByDealcoGrpBizList({ commit }, payload) {
            console.log('getCommDealcoByDealcoGrpBizList::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'get',
                    url: '/api/v1/backend/pol/shd/getCommDealcoByDealcoGrpBizList',
                    params: payload,
                })
                    .then((res) => {
                        console.log(
                            'getCommDealcoByDealcoGrpBizList[then]',
                            res
                        )
                        commit('setDsBasDealCoList', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
        async getPolDealCoGrpInfo({ commit }, payload) {
            console.log('getPolDealCoGrpInfo::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'get',
                    url: '/api/v1/backend/pol/std/getPolTdealcoGrpInfo',
                    params: payload,
                })
                    .then((res) => {
                        console.log('getPolDealCoGrpInfo[then]', res)
                        commit('setPolDealCoGrpInfo', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
        async savePolDealCoGrpInfo({ commit }, payload) {
            console.log('savePolDealCoGrpInfo::::', payload)

            return await new Promise((resolve, reject) => {
                send({
                    method: 'post',
                    url: '/api/v1/backend/pol/std/savePolDealCoGrpInfo',
                    data: payload,
                    // {
                    //     ...payload.polDealCoGrpMgmt,
                    //     ...payload.polDealCoGrpDtl,
                    // },
                })
                    .then((res) => {
                        console.log('savePolDealCoGrpInfo[then]', res)
                        // setDsCondition({
                        //     ictId:
                        // })
                        commit('setDsPolDealCoGrpInfo', res)
                        resolve(res)
                    })
                    .catch((err) => {
                        alert('오류가 발생 하였습니다. 관리자에게 문의하세요')
                        console.log(err)
                        reject(err)
                    })
            })
        },
    },
    getters: {
        //
    },
}
