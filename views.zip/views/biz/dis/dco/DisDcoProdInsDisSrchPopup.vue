<!-----------------------------------------------
 * 업무그룹명: 재고공통팝업
 * 서브업무명: 상품입력(재고검색)
 * 설명: 재고상품을 조회한다.
 * 작성자: P179890
 * 작성일: 2022.05.14
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">상품입력(재고검색)</p>
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="left"></li>
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="clearBtn"
                                >초기화</TCComButton
                            >
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="searchBtn"
                            >
                                조회
                            </TCComButton>
                            <!-- <TCComButton
                                    color="btn2"
                                    eClass="btn_ty01"
                                    :objAuth="objAuth"
                                    @click="closeBtn"
                                >
                                    닫기
                                </TCComButton> -->
                        </li>
                    </ul>

                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="출고처"
                                    :disabled="true"
                                    :eRequired="true"
                                    v-model="reqParam.outPlcNm"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComComboBox
                                    codeId="ZBAS_C_00010"
                                    labelName="상품구분"
                                    :objAuth="objAuth"
                                    ref="prchTypComboBox"
                                    v-model="reqParam.prodCl"
                                    :addBlankItem="true"
                                    :blankItemText="'전체'"
                                    :filterFunc="filterProdClFunc"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="일련번호"
                                    v-model="reqParam.serNum"
                                    @enterKey="searchBtn"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComComboBox
                                    codeId="PRCH_TYP_CD"
                                    labelName="구매유형"
                                    :objAuth="objAuth"
                                    ref="mdlClComboBox"
                                    v-model="reqParam.prchTyp"
                                    :addBlankItem="false"
                                    :eRequired="true"
                                    :filterFunc="filterPrchTypFunc"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComComboBox
                                    labelName="제조사"
                                    :objAuth="objAuth"
                                    v-model="reqParam.mfactId"
                                    :addBlankItem="true"
                                    :blankItemText="'전체'"
                                    :autocomplete="true"
                                    :itemList="mfactComboList"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    labelName="모델"
                                    @enterKey="onProdsIconClick"
                                    @appendIconClick="onProdsIconClick"
                                    @input="reqParam.prodCd = ''"
                                    :objAuth="objAuth"
                                    v-model="reqParam.prodNm"
                                    :codeVal="reqParam.prodCd"
                                    :disabledAfter="true"
                                >
                                </TCComInputSearchText>
                                <BasBcoProdsPopup
                                    v-if="basBcoProdsShow === true"
                                    :dialogShow.sync="basBcoProdsShow"
                                    :parentParam="searchProdForm"
                                    :rows="resultProdsRows"
                                    @confirm="onProdsReturnData"
                                />
                            </div>
                        </div>
                    </div>

                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="popupGridHeader"
                            ref="gridHeader"
                            gridTitle="상품내역"
                            :gridObj="gridObj"
                            :isPageRows="true"
                            @excelDownBtn="exportGridBtn"
                        />
                        <TCRealGrid
                            id="popupGrid"
                            ref="grid"
                            :fields="view.fields"
                            :columns="view.columns"
                            :styles="gridStyle"
                        />
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="confirmBtn"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            :objAuth="objAuth"
                            @click="closeBtn"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil, CommonMsg } from '@/utils'
import commonApi from '@/api/common/prototype'
import { DisDcoProdInsDisSrchPopup_GRID_HEADER } from '@/const/grid/dis/dco/disDcoProdInsDisSrchPopupHeader.js'
import dcoApi from '@/api/biz/dis/dco/disDcoProdInsDisSrch.js'
import opnApi from '@/api/biz/dis/opn/disOpnOpenStMgmtProdRgst.js'
import _ from 'lodash'
import CommonMixin from '@/mixins'
//====================상품팝업====================
import BasBcoProdsPopup from '@/components/common/BasBcoProdsPopup'
import basBcoProdsApi from '@/api/biz/bas/bco/basBcoProds'
//====================//상품팝업==================

export default {
    name: 'DisDcoProdInsDisSrchPopup',
    mixins: [CommonMixin],
    components: { BasBcoProdsPopup },
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        params: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
        prodOrgList: {
            type: Array,
            default: () => {
                return []
            },
            required: false,
        },
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        params: {
            handler: function (value) {
                this.reqParam.outSchdDt = value['outSchdDt']
                this.reqParam.outPlcId = value['outPlcId']
                this.reqParam.outPlcNm = value['outPlcNm']
                this.reqParam.outCl = value['outCl']
                this.reqParam.prchTyp = _.isEmpty(value['prchTyp'])
                    ? 'PT01'
                    : value['prchTyp']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    data() {
        return {
            //====================상품팝업관련====================
            basBcoProdsShow: false,
            resultProdsRows: [],
            searchProdForm: {
                prodCd: '', // 상품코드
                prodNm: '', // 상품명
                prodClCd: '', //상품구분
                sktOperYn: '', //skt운영여부
                useYn: '', //사용여부
            },
            //====================//상품팝업관련==================
            objAuth: {},
            gridObj: {},
            gridHeaderObj: {},
            gridData: {},
            view: DisDcoProdInsDisSrchPopup_GRID_HEADER,
            searchForms: {},
            rowCnt: 15,
            removeCnt: 0,
            dealcoClCd1: '',
            alertHeadTxt: '상품입력(재고검색)',
            gridStyle: {
                height: '300px', //그리드 높이 조절
            },
            mfactComboList: [],
            reqParam: {
                // 요청파라미터
                outSchdDt: '', // 출고예정일
                outPlcId: '', // 출고처ID
                outPlcNm: '', // 출고처명
                outCl: '', // 출고구분
                prchTyp: '', // 구매유형코드
                prodCl: '', // 상품구분코드
                mfactId: '', // 제조사
                serNum: '', // 일련번호
                prodCd: '', // 모델코드
                prodNm: '', // 모델명
            },
        }
    },
    created() {
        // 화면 default설정
        this.gridData = this.gridSetData()
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.setRowStyleCallback(function (grid, item) {
            let ret = {}
            const regYn = grid.getValue(item.index, 'regYn')

            if (regYn == '1') {
                ret.editable = false
                ret.styleName = 'rg-fileuplod-error'
            }

            return ret
        })
        this.gridObj.gridView.setCheckableExpression(
            "values['regYn'] < 1",
            true
        )
        this.dealcoClCd1 = this.userInfo?.dealcoClCd1
        // 제조사조회
        this.getMfact()
        // 공통코드 조회 그리드 property 추가
        this.getCommCodeList('ZBAS_C_00010', 'prodClNm')
        this.getCommCodeList('ZDIS_C_00090', 'badYn')
        this.getCommCodeList('ZDIS_C_00100', 'disSt')
    },
    methods: {
        init() {
            this.reqParam.outSchdDt = this.params['outSchdDt']
            this.reqParam.outPlcId = this.params['outPlcId']
            this.reqParam.outPlcNm = this.params['outPlcNm']
            this.reqParam.outCl = this.params['outCl']
            this.reqParam.prchTyp = _.isEmpty(this.params['prchTyp'])
                ? 'PT01'
                : this.params['prchTyp']

            this.gridHeaderObj.setPageCount({ totalDataCnt: 0 })
            // this.gridData.totalPage = 0
        },
        closeBtn() {
            this.activeOpen = false
        },
        //GridSetData
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(0, this.rowCnt, '', '')
        },
        //Grid ExcelDown
        exportGridBtn: function () {
            this.gridHeaderObj.exportGrid('상품입력(재고검색).xls')
        },
        // 제조사 조회
        getMfact() {
            const mfactParam = { dealCoCl: '20' }
            opnApi.getMfact(mfactParam).then((res) => {
                this.mfactComboList = res
            })
        },
        // Validation 체크
        isValidChk() {
            if (_.isEmpty(this.reqParam.outPlcId)) {
                this.openAlert(CommonMsg.getMessage('MSG_00083', '출고처ID'))
                return false
            }
            if (
                !_.isEmpty(this.reqParam.serNum) &&
                this.reqParam.serNum.length < 4
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00999', '일련번호;4'))
                return false
            }
            return true
        },
        getCommCodeList(codeId, columnId) {
            commonApi.getCommonCodeList(codeId).then((res) => {
                let columnValues = []
                let columnLabels = []
                if (res.length) {
                    res.forEach((data) => {
                        columnValues.push(data.commCdVal)
                        columnLabels.push(data.commCdValNm)
                    })
                }
                // 그리드 컬럼 콤보박스 데이터 설정
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'values',
                    columnValues
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'labels',
                    columnLabels
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'lookupDisplay',
                    true
                )
            })
        },
        // 구매유형comboBox filter
        filterPrchTypFunc(items) {
            return items.filter((item) =>
                this.params.prchTyp == 'PT03'
                    ? item['commCdVal'] === 'PT03'
                    : item['commCdVal'] === 'PT01' ||
                      item['commCdVal'] === 'PT02'
            )
        },
        // 상품구분comboBox filter
        filterProdClFunc(items) {
            // 재고상품입력 : USIM 상품 조회	불가 조치요청
            // 직영매장 > 직영위탁(A6) /	자영위탁직영(A7) , 하부망 >	전체(Yx)
            if (!_.isEmpty(this.dealcoClCd1)) {
                if (
                    this.dealcoClCd1 == 'A6' ||
                    this.dealcoClCd1 == 'A7' ||
                    this.dealcoClCd1.substr(0, 1) == 'Y'
                ) {
                    return items.filter((item) => item['commCdVal'] !== '2')
                } else {
                    return items
                }
            } else {
                return items
            }
        },
        clearBtn() {
            // 검색영역 초기화
            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.init()
        },
        // 확인버튼
        confirmBtn() {
            var chkRow = this.gridObj.gridView.getCheckedRows(true)
            if (chkRow.length == 0) {
                this.openAlert(CommonMsg.getMessage('MSG_00134', '상품'))
                return
            }

            const chkProdList = []
            for (var i = 0; i < chkRow.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(chkRow[i], true)
                if (this.prodOrgList.length > 0) {
                    if (row.prchTyp != this.prodOrgList[0].prchTyp) {
                        this.openAlert('등록된 구매유형과 다른 유형입니다.')
                        return
                    }
                }
                row['outQty'] = row['movCnt']
                row['outCl'] = '301'
                row['amt'] = row['movCnt'] * row['unitPrc']
                row['realPrchsPrc'] = row['unitPrc']
                row['unitPrc'] = row.fdisAmt //20161220변경 단가->개별원가
                row['prodCdColorCd'] = row['prodCd'] + row['colorCd']
                row['prodCdserNum'] = row['prodCd'] + row['serNum']
                chkProdList.push(row)
            }
            this.$emit('addDisProdList', chkProdList)
            this.activeOpen = false
        },
        //조회 버튼 이벤트
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            //첫 조회시 표시할 행의 갯수
            this.searchForms = { ...this.reqParam }
            if (!_.isEmpty(this.dealcoClCd1)) {
                if (
                    this.dealcoClCd1 == 'A6' ||
                    this.dealcoClCd1 == 'A7' ||
                    this.dealcoClCd1.substr(0, 1) == 'Y'
                ) {
                    this.searchForms.exceptUsim = this.dealcoClCd1
                }
            }
            this.searchForms.outSchdDt = CommonUtil.onlyNumber(
                this.searchForms.outSchdDt
            )
            // 2022-09-06 페이징 삭제
            // this.searchForms.pageSize = this.rowCnt
            // this.searchForms.pageNum = 1 //첫번째 페이지
            // this.gridData.totalPage = 0 // 이전페이지정보 초기화
            // this.getInProd(this.searchForms.pageNum)
            this.getInProd()
        },
        getInProd() {
            dcoApi.getInProd(this.searchForms).then((res) => {
                const girdList = this.setNewProd(res.gridList)
                this.gridObj.setRows(girdList)
                this.gridHeaderObj.setPageCount({
                    totalDataCnt: res.gridList.length,
                })

                // 2022-09-06 페이징 삭제
                // this.gridData = this.gridSetData() //초기화
                // this.gridObj.setGridIndicator(res.pagingDto) //순번이 필요한경우 계산하는 함수
                // this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수

                //Grid Row 가져올때 총건수 Setting
                // this.gridHeaderObj.setPageCount(res.pagingDto)
            })
        },
        // 개봉상품등록 그리드에 선택된 상품 중복 제외
        setNewProd(prodList) {
            if (this.prodOrgList.length > 0) {
                for (var i = 0; i < this.prodOrgList.length; i++) {
                    for (var j = 0; j < prodList.length; j++) {
                        if (
                            this.prodOrgList[i].serNum == prodList[j].serNum &&
                            this.prodOrgList[i].colorCd ==
                                prodList[j].colorCd &&
                            this.prodOrgList[i].prodCd == prodList[j].prodCd
                        ) {
                            prodList[j].regYn = '1'
                        }
                    }
                }
            }
            return prodList
        },
        // alert창 호출
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //===================== 상품팝업관련 methods ================================
        // 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 대리점 팝업 오픈
        getProdsList() {
            basBcoProdsApi.getProdsList(this.searchProdForm).then((res) => {
                if (res.length === 1) {
                    this.reqParam.prodCd = _.get(res[0], 'prodCd')
                    this.reqParam.prodNm = _.get(res[0], 'prodNm')
                } else {
                    this.resultProdsRows = res
                    this.basBcoProdsShow = true
                }
            })
        },
        // 상품팝업 TextField 돋보기 Icon 이벤트 처리
        onProdsIconClick() {
            this.searchProdForm['prodCd'] = this.reqParam['prodCd']
            this.searchProdForm['prodNm'] = this.reqParam['prodNm']
            // 상품팝업 Row 설정 Prop 변수 초기화
            this.resultProdsRows = []
            // 검색조건 대표모델이 빈값이면 팝업오픈
            if (!_.isEmpty(this.reqParam.prodNm)) {
                this.getProdsList()
            } else {
                this.basBcoProdsShow = true
            }
        },
        // 상품팝업 리턴 이벤트 처리
        onProdsReturnData(retrunData) {
            this.reqParam.prodCd = _.get(retrunData, 'prodCd')
            this.reqParam.prodNm = _.get(retrunData, 'prodNm')
        },
        //===================== //상품팝업관련 methods ================================
    },
}
</script>
