import { ValueType } from 'realgrid'

//부가서비스 그리드
export const SVCGRIDHEARDER = {
    fields: [
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //구분
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT, //부가서비스구분코드명
        },
        {
            fieldName: 'scrbDt',
            dataType: ValueType.DATETIME, //가입일자
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'svcEndDt',
            dataType: ValueType.DATETIME, //해지일자
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'endDurDt',
            dataType: ValueType.DATETIME, //유지일
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'idmLmtCd',
            dataType: ValueType.TEXT, //유치기한코드
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.DATETIME, //변경일자
            datetimeFormat: 'yyyy-MM-dd HH:mm:ss',
        },
    ],
    columns: [
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            width: '100',
            header: {
                text: '구분',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '서비스',
            },
        },
        {
            name: 'idmLmtCd',
            fieldName: 'idmLmtCd',
            type: 'data',
            width: '100',
            header: {
                text: '유치기한',
                showTooltip: false,
            },
            editable: true,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'scrbDt',
            fieldName: 'scrbDt',
            type: 'data',
            width: '100',
            header: {
                text: '가입일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
        },
        {
            name: 'svcEndDt',
            fieldName: 'svcEndDt',
            type: 'data',
            width: '100',
            header: {
                text: '해지일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
        },
        {
            name: 'endDurDt',
            fieldName: 'endDurDt',
            type: 'data',
            width: '100',
            header: {
                text: '유지일',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '100',
            header: {
                text: '변경일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd HH:mm:ss',
            editor: {
                datetimeFormat: 'yyyy-MM-dd HH:mm:ss',
            },
        },
    ],
}
