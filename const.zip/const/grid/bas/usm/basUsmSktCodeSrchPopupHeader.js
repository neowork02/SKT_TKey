import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'sktId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktIdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktUserId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'sktId',
            fieldName: 'sktId',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing ID',
            },
        },
        {
            name: 'sktIdNm',
            fieldName: 'sktIdNm',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing 사용자명',
            },
        },
    ],
}
