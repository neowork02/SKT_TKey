import { ValueType } from 'realgrid'

export const HEADER = {
    fields: [
        {
            fieldName: 'hstSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'staDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'expirDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodMenuId',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        /*
        {
            name: 'hstSeq',
            fieldName: 'hstSeq',
            header: {
                text: '이력순번',
            },
        },
        */
        {
            name: 'userId',
            fieldName: 'userId',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용자ID',
            },
        },
        /*
        {
            name: 'serNo',
            fieldName: 'serNo',
            // type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
            },
        },
        */
        {
            name: 'addOrgCd',
            fieldName: 'addOrgCd',
            header: {
                text: '추가조직아이디',
            },
        },
        {
            name: 'staDt',
            fieldName: 'staDt',
            header: {
                text: '적용시작일',
            },
        },
        {
            name: 'expirDt',
            fieldName: 'expirDt',
            header: {
                text: '적용만료일',
            },
        },
        {
            name: 'delYn',
            fieldName: 'delYn',
            header: {
                text: '삭제여부',
            },
        },
        /*
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            header: {
                text: '입력일시',
            },
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            header: {
                text: '입력자ID',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '수정일시',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            header: {
                text: '수정자ID',
            },
        },*/
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            header: {
                text: '처리일시',
            },
        },
    ],
}
