import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'
import login from './modules/login'
import menu from './modules/menu'
import auth from './modules/auth'
import rmks from './modules/rmks'
import exception from './modules/exception'
import constants from '@/const/constants'
import _ from 'lodash'

Vue.use(Vuex)

export default new Vuex.Store({
    state: {
        constants: constants,
        _apiLoading: false,
        _tcComAlertShow: false,
        _tcComAlertMessage: '',
        _tcComAlertOptions: {
            header: '',
            size: '',
            confirmLabel: '',
        },
        _tcComConfirmShow: false,
        _tcComConfirmResolve: false,
        _tcComConfirmMessage: '',
        _tcComConfirmOptions: {
            header: '',
            size: '',
            confirmLabel: '',
            cancelLabel: '',
            isCancelBtn: true,
        },
        _tcComSnackbarShow: false,
        _tcComSnackbarMessage: '',
        _tcComSnackbarOptions: {
            timeout: '',
        },
        _svcMgmtNum: '',
    },
    mutations: {
        SET_API_LOADING(state, loading) {
            state._apiLoading = loading
        },
        SHOW_TCCOMALERT(state, payload) {
            state._tcComAlertMessage = payload.message
            if (!_.isEmpty(payload.options)) {
                state._tcComAlertOptions = payload.options
            }
            state._tcComAlertShow = true
        },
        CLOSE_TCCOMALERT(state) {
            state._tcComAlertShow = false
            state._tcComAlertMessage = ''
            state._tcComAlertOptions = {
                header: '',
                size: '',
                confirmLabel: '',
            }
        },
        SHOW_TCCOMCONFIRM(state, payload) {
            state._tcComConfirmMessage = payload.message
            if (!_.isEmpty(payload.options)) {
                state._tcComConfirmOptions = payload.options
            }
            state._tcComConfirmShow = true
        },
        CLOSE_TCCOMCONFIRM(state) {
            state._tcComConfirmShow = false
            state._tcComConfirmMessage = ''
            state._tcComConfirmOptions = {
                header: '',
                size: '',
                confirmLabel: '',
                cancelLabel: '',
                isCancelBtn: true,
            }
        },
        SET_TCCOMCONFIRM_RESOLVE(state, resolve) {
            state._tcComConfirmResolve = resolve
        },
        SHOW_TCCOMSNACKBAR(state, payload) {
            state._tcComSnackbarMessage = payload.message
            if (!_.isEmpty(payload.options)) {
                state._tcComSnackbarOptions = payload.options
            }
            state._tcComSnackbarShow = true
        },
        CLOSE_TCCOMSNACKBAR(state) {
            state._tcComSnackbarShow = false
            state._tcComSnackbarMessage = ''
            state._tcComSnackbarOptions = {
                timeout: '',
            }
        },
        SET_SVC_MGMT_NUM(state, data) {
            state._svcMgmtNum = data
        },
    },
    getters: {
        CONSTANTS: (state) => {
            return state.constants
        },
        apiLoading: (state) => {
            return state._apiLoading
        },
        tcComAlertShow: (state) => {
            return state._tcComAlertShow
        },
        tcComAlertMessage: (state) => {
            return state._tcComAlertMessage
        },
        tcComAlertOptions: (state) => {
            return state._tcComAlertOptions
        },
        tcComConfirmShow: (state) => {
            return state._tcComConfirmShow
        },
        tcComConfirmMessage: (state) => {
            return state._tcComConfirmMessage
        },
        tcComConfirmOptions: (state) => {
            return state._tcComConfirmOptions
        },
        tcComConfirmResolve: (state) => {
            return state._tcComConfirmResolve
        },
        tcComSnackbarShow: (state) => {
            return state._tcComSnackbarShow
        },
        tcComSnackbarMessage: (state) => {
            return state._tcComSnackbarMessage
        },
        tcComSnackbarOptions: (state) => {
            return state._tcComSnackbarOptions
        },
        SVC_MGMT_NUM: (state) => {
            return state._svcMgmtNum
        },
    },
    actions: {
        setApiLoading({ commit }, loading) {
            commit('SET_API_LOADING', loading)
        },
        showTcComAlert({ commit }, payload) {
            commit('SHOW_TCCOMALERT', payload)
        },
        closeTcComAlert({ commit }) {
            commit('CLOSE_TCCOMALERT')
        },
        showTcComConfirm({ commit }, payload) {
            commit('SHOW_TCCOMCONFIRM', payload)
        },
        closeTcComConfirm({ commit }) {
            commit('CLOSE_TCCOMCONFIRM')
        },
        setTcComConfirmResolve({ commit }, resolve) {
            commit('SET_TCCOMCONFIRM_RESOLVE', resolve)
        },
        showTcComSnackbar({ commit }, payload) {
            commit('SHOW_TCCOMSNACKBAR', payload)
        },
        closeTcComSnackbar({ commit }) {
            commit('CLOSE_TCCOMSNACKBAR')
        },
        setSvcMgmtNum({ commit }, data) {
            commit('SET_SVC_MGMT_NUM', data)
        },
    },
    modules: {
        login,
        menu,
        auth,
        exception,
        rmks,
    },
    plugins: [
        createPersistedState({
            paths: ['login', 'menu', 'rmks', 'auth'],
            key: 'vuexStore', // storate의 item 이름 설정
            storage: window.sessionStorage,
        }),
    ],
    strict:
        process.env.NODE_ENV === 'dev' || process.env.NODE_ENV === 'development'
            ? true
            : false,
    //strict: false,
})
