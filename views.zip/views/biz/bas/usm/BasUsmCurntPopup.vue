<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">사용자 현행화</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <p class="infoTxt">
                        <span class="color-red"
                            >사용자정보 현행화가 되지 않은 경우, 현행화면 조회
                            등 업무시 불편함이 발생할 수 있습니다./비활성화
                            항목에 대한 수정은 소속조직 STAFF에게 문의 바랍니다.
                        </span>
                    </p>
                    <!-- SubTit  -->
                    <div class="stitHead pop">
                        <h4 class="subTit">기본정보</h4>
                    </div>
                    <!-- //SubTit -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="통합 LoginID"
                                    v-model="ds_user.portalUserId"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="사용자ID"
                                    v-model="ds_user.userId"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="사용자명"
                                    v-model="ds_user.userNm"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 1-3 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="사번"
                                    :eRequired="true"
                                    v-model="ds_user.userCd"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="Swing 무선전화"
                                    v-model="ds_user.repMblPhonNo"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-2 -->
                            <!-- item 2-3 -->
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="사용자 무선전화"
                                    v-model="ds_user.mblPhonNo"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            <!-- //item 2-3 -->
                        </div>
                        <!-- //Search_line 2 -->
                        <!-- Search_line 3 -->
                        <div class="searchform">
                            <!-- item 3-1 -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    :itemList="attcCatList"
                                    v-model="ds_user.attcClCd"
                                    labelName="소속유형"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    @change="cmb_attcCat_OnChanged"
                                    :objAuth="objAuth"
                                    disabled
                                ></TCComComboBox>
                            </div>
                            <!-- //item 3-1 -->
                            <!-- item 3-2 -->
                            <div class="formitem div3">
                                <!-- //item 2-2 -->

                                <TCComNoLabelCheckBox
                                    v-model="indirInfoPraAgreeYn"
                                    :itemList="items4"
                                    :disabled="chk_ageeYn.enable == false"
                                />
                            </div>
                        </div>
                        <!-- //Search_line 3-->
                        <!-- Search_line 4 -->
                        <!--
                        <div class="searchform">
                            
                            <div class="formitem div1">
                                
                                <div class="arrayType">
                                    <div class="col0">
                                        <TCComInput
                                            labelName="Email"
                                            v-model="ds_user.email1"
                                            :objAuth="objAuth"
                                        />
                                    </div>
                                    <div class="col0">@</div>
                                    <div class="col0">
                                        <TCComNoLabelInput
                                            v-model="ds_user.email2"
                                            :objAuth="objAuth"
                                        />
                                    </div>
                                    <div class="col0">
                                        <TCComNoLabelComboBox
                                            ref="emailList"
                                            codeId="EMAIL_ACC"
                                            v-model="mailList"
                                            :objAuth="objAuth"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                            @change="cmb_mailList_OnChanged"
                                        />
                                    </div>
                                    <div class="col0">
                                        <TCComNoLabelCheckBox
                                            v-model="indirInfoPraAgreeYn"
                                            :itemList="items4"
                                            :disabled="
                                                chk_ageeYn.enable == false
                                            "
                                        />
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div> -->
                        <!-- //Search_line 4-->
                    </div>
                    <!-- //Search_div -->

                    <!-- gridWrap -->
                    <TCRealGridHeader
                        id="gridHeaderPopup1"
                        ref="gridHeaderPopup1"
                        gridTitle="Swing ID 정보"
                        :gridObj="gridObj1"
                        :isPageRows="true"
                        :isExceldown="false"
                        :isPageCnt="true"
                    />
                    <TCRealGrid
                        id="gridPopup1"
                        ref="gridPopup1"
                        :editable="true"
                        :movable="false"
                        :columnMovable="false"
                        :fields="view1.fields"
                        :columns="view1.columns"
                        :styles="gridStyle"
                    />
                    <!-- //gridWrap -->

                    <!-- SubTit  -->
                    <div class="stitHead">
                        <h4 class="subTit">조직정보</h4>
                    </div>
                    <!-- //SubTit -->
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="searchAuthOrgTreeParam.orgNm"
                                    :codeVal.sync="searchAuthOrgTreeParam.orgCd"
                                    labelName="소속조직"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :eRequired="true"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchAuthOrgTreeParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="searchForm.dealcoNm"
                                    :codeVal.sync="searchForm.dealcoCd"
                                    labelName="근무지"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :eRequired="false"
                                    :objAuth="objAuth"
                                    @enterKey="onDealcoEnterKey"
                                    @appendIconClick="onDealcoIconClick"
                                    @input="onDealcoInput"
                                />
                                <BasBcoDealcosPopup
                                    v-if="showBasBcoDealcos"
                                    :parentParam="searchForm"
                                    :rows="resultDealcoRows"
                                    :dialogShow.sync="showBasBcoDealcos"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div3">
                                <TCComComboBox
                                    :itemList="commUserGrpList"
                                    v-model="ds_user.userGrpCd"
                                    labelName="권한그룹"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :eRequired="true"
                                ></TCComComboBox>
                            </div>
                            <!-- //item 1-3 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->

                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <!--
                    
                    <div class="stitHead pop">
                        <h4 class="subTit">SMS 수신 전화번호 정보</h4>
                    </div>
                    
                    <div class="searchLayer_wrap">
                        
                        <div class="searchform mgt-20">
                            <p class="formTit">공통/정책/재고</p>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 1"
                                    v-model="ds_user.mblPhonNo"
                                    :objAuth="objAuth"
                                />
                            </div>
                     
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 2"
                                    v-model="ds_user.mblPhonNo2"
                                    :objAuth="objAuth"
                                />
                            </div>
                         
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 3"
                                    v-model="ds_user.mblPhonNo3"
                                    :objAuth="objAuth"
                                />
                            </div>
                       
                        </div>
        
                        <div class="searchform vline">
                            <p class="formTit">영업/Happy</p>
                 
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 1"
                                    v-model="ds_user.happySmsNo1"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
        
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 2"
                                    v-model="ds_user.happySmsNo2"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
      
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 3"
                                    v-model="ds_user.happySmsNo3"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
          
                        </div>
                        
                        <div class="searchform vline">
                            <p class="formTit">요금/정산</p>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 1"
                                    v-model="ds_user.accSmsYn1"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="SMS 2"
                                    v-model="ds_user.accSmsYn2"
                                    :objAuth="objAuth"
                                    disabled
                                />
                            </div>
                            
                            <div class="formitem div3"></div>
                            
                        </div>
                        
                    </div>
                    
-->
                    <!-- gridWrap -->
                    <TCRealGridHeader
                        id="gridHeaderPopup2"
                        ref="gridHeaderPopup2"
                        gridTitle="담당거래처"
                        :gridObj="gridObj2"
                        :isPageRows="true"
                        :isExceldown="false"
                        :isPageCnt="true"
                    />
                    <TCRealGrid
                        id="gridPopup2"
                        ref="gridPopup2"
                        :editable="true"
                        :movable="false"
                        :columnMovable="false"
                        :fields="view2.fields"
                        :columns="view2.columns"
                        :styles="gridStyle2"
                    />
                    <!-- //gridWrap -->
                    <p class="infoTxt">
                        <span class="color-red"
                            >실제 사용자와의 정보가 일치하며, 위 내용과 실제
                            사용자정보 불일치로 인한 책임은 사용자에게 있습니다.
                        </span>
                    </p>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="onSave"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="onClose"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import { SacCommon } from '@/views/biz/sac/js'
import { HEADER1, HEADER2 } from '@/const/grid/bas/usm/basUsmCurntPopupHeader'
import API from '@/api/biz/bas/usm/basUsmCurntPopup'
import _ from 'lodash'
import CommonMixin from '@/mixins'
//====================내부조직팝업(권한)팝업==============================================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//======================================================================================
//====================내부거래처-권한조직=================================================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//======================================================================================

export default {
    name: 'BasUsmCurntPopup',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            calType7: 'DHMP',
            inputValue: '2021-01-01',
            inputValue7: ['2022-03-20', '2022-03-25'],
            sHourVal7: '11',
            eHourVal7: '23',
            sMinuVal7: '50',
            eMinuVal7: '59',
            inputValue2: '2021-02',
            inputValue5: '2022-03-15',
            calType5: 'M',
            endDateVal5: '2022-03-16',
            calType4: 'DHM',
            inputValue4: '2022-03-11',
            inputValue41: '01',
            inputValue42: '59',
            // guideTab: 0,
            // guideTab2: 0,
            // tabItems: ['가상배정', '위탁배정'],
            gridData: {},
            objAuth: {},
            gridObj1: {},
            gridObj2: {},
            gridHeaderObj1: {},
            gridHeaderObj2: {},
            codeIDView: true,
            codeIDViewVal: '',
            // value1: '',

            view1: HEADER1,
            view2: HEADER2,
            // radio1: '1',
            // radio2: '2',
            checked1: true,
            checked2: false,
            input: '',
            checkbox: true,
            // radios: null,
            // tab: null,
            itemName: ['판매상세', '수납', '비고'],
            items4: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '개인정보활용동의',
                },
            ],
            gridStyle: {
                height: '100px', //그리드 높이 조절
            },
            gridStyle2: {
                height: '100px', //그리드 높이 조절
            },
            // ds_condition: {},
            commUserGrpList: [],
            commUserGrpOriginList: [],
            reqParam: {
                attcCat: '',
                userGrp: '',
                edit0: '',
            },
            attcCatList: [], // 소속유형
            div_search: {},
            ds_user: {
                // mailList: '',
                // indirInfoPraAgreeYn: [],
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                dealcoCd: '',
                dealcoNm: '',
            },
            mailList: '',
            indirInfoPraAgreeYn: [],
            ds_ukey_lst: [],
            chk_ageeYn: {
                enable: true,
            },
            ds_saleChrgrDealCoList: [],
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchAuthOrgTreeParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //================================================================
            //====================내부거래처(권한조직) 근무지===========================
            showBasBcoDealcos: false,
            searchForm: {
                dealcoCd: '',
                dealcoNm: '',
            },
            resultDealcoRows: [],
            //================================================================
            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },

    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentParam', value)
                this.propsParam = value
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },

    created() {
        console.log('------created------')
        console.log('this.$route Detail: ', this.$route)
    },

    mounted() {
        this.init()
        // this.ds_condition.userId = this.userInfo.userId
        this.onSearch()
        // 사용자 권한그룹 목록 조회
        this.getUserGrpLst()
        // 소속 유형 코드조회
        this.dropDownSetting()

        // this.setInitGrid()

        // this.gridObj.setRows(SAMPLE_D_DATA)
        this.gridObj1.gridView.onCellClicked = (grid, clickData) => {
            alert(clickData.fieldName)
        }
        // this.gridObj2 = this.$refs.grid2
        // this.gridHeaderObj2 = this.$refs.gridHeader2
        // this.gridObj3.setRows(SAMPLE_DATA)
        this.gridObj2.gridView.onCellClicked = (grid, clickData) => {
            alert(clickData.fieldName)
        }
    },
    methods: {
        init() {
            this.gridObj1 = this.$refs.gridPopup1
            this.gridHeaderObj1 = this.$refs.gridHeaderPopup1
            this.gridObj2 = this.$refs.gridPopup2
            this.gridHeaderObj2 = this.$refs.gridHeaderPopup2
            this.gridData = this.gridSetData()
            // this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            // this.gridObj2.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj1.setGridState()
            this.gridObj2.setGridState()
        },
        gridSetData: function () {
            return new CommonGrid(0, 10, '', '')
        },
        //팝업닫기
        onClose: function () {
            this.activeOpen = false
        },

        // 사용자 권한 목록조회
        getUserGrpLst() {
            API.getUserGrpLst().then((res) => {
                if (res !== undefined) {
                    this.commUserGrpOriginList = res
                    this.commUserGrpList = res
                    // this.dCommItemList = res
                }
            })
        },

        // 그리드에 dropdown셋팅 공통코드 api
        async dropDownSetting() {
            console.log('dropDownSetting')

            // 소속유형
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00380',
                columnName: 'attcCat',
                option: '전체',
            })
        },

        async dropDownCmmonCodes({ key, columnName, option }) {
            console.log('key columnName option', key, columnName, option)
            let result = await API.dropDownCmmonCodes_(key)
            console.log('result', result)

            if (columnName == 'attcCat') {
                this.attcCatList = result
                console.log('resultAttcCat', result)
                // "PS&Marketing" 일시에 해당 대리점/판매점 콤보박스에서 숨김
                if (this.orgInfo.orgCdLvl0 == 'O00000') {
                    this.attcCatList = this.attcCatList
                        .filter((p) => p.commCdVal != 'D')
                        .filter((p) => p.commCdVal != 'P')
                } else {
                    this.attcCatList = this.attcCatList.filter(
                        (p) => p.commCdVal == ('D' || 'P')
                    )
                    // .filter((p) => p.commCdVal == 'P')
                }
            }
        },

        //조회 버튼
        onSearch() {
            this.getUserDetailInfo()
        },

        //API 호출
        getUserDetailInfo: function () {
            // console.log('orgLvlCd : ', this.searchAuthOrgTreeParam.orgLvl)
            // console.log('serachGubnCd : ', this.div_search.cmbSchCon)
            this.gridObj1.setRows()
            // this.gridObj2.setRows()

            let params = {
                userId: this.userInfo.userId,
            }
            // params.pageNum = pageNum
            // params.pageSize = this.rowCnt

            console.log('this.params : ', params)
            API.getUserDetailInfo(params).then((resultData) => {
                this.ds_user = resultData.basUsmCurntUserInfoVo[0]
                this.indirInfoPraAgreeYn = [
                    resultData.basUsmCurntUserInfoVo[0].indirInfoPraAgreeYn,
                ]
                console.log(
                    'this.indirInfoPraAgreeYn',
                    this.indirInfoPraAgreeYn
                )
                this.ds_ukey_lst = resultData.basUsmUserUKeyIdVo
                this.gridObj1.setRows(this.ds_ukey_lst)
                this.setInitGrid()

                if (this.ds_user.indirInfoPraAgreeYn == 'Y') {
                    this.chk_ageeYn.enable = false
                }

                if (this.ds_user.userGrpCd == 'D13') {
                    this.getSaleChrgrDealCoList(1)
                }
            })
        },

        setInitGrid() {
            this.searchAuthOrgTreeParam.orgNm = this.ds_user.newOrgNm
            this.searchAuthOrgTreeParam.orgCd = this.ds_user.orgCd

            this.searchForm.dealcoCd = this.ds_user.dealcoCd
            this.searchForm.dealcoNm = this.ds_user.dealcoNm
        },

        // 소속유형 이벤트
        cmb_attcCat_OnChanged(e) {
            // console.log(e)
            this.commUserGrpList = []

            if (e == '') {
                this.ds_user.userGrpCd = ''
                this.commUserGrpList = this.commUserGrpOriginList
                // this.disabledUserGrp = true
            } else {
                // 소속유형에 따른 권한그룹 combobox filter
                this.commUserGrpList = this.commUserGrpOriginList.filter(
                    (item) => item['attcClCd'] == e
                )
                this.ds_user.userGrpCd = ''
            }
        },

        // 담당 거래처 정보 조회
        getSaleChrgrDealCoList(pageNum) {
            this.gridObj2.setRows()
            // this.gridObj2.setRows()

            let params = {
                userId: this.ds_user.userId,
                orgCd: this.searchAuthOrgTreeParam.orgCd,
            }
            params.pageNum = pageNum
            // params.pageSize = this.rowCnt

            console.log('params : ', params)
            API.getSaleChrgrDealCoList(params).then((resultData) => {
                this.ds_saleChrgrDealCoList = resultData
                this.gridObj2.setRows(resultData)
                // this.setInitGrid()
            })
        },

        // 저장이벤트
        onSave: function () {
            this.gridObj1.gridView.commit()
            this.gridObj2.gridView.commit()
            this.getUserCnt()
        },

        // 사번중복체크
        getUserCnt() {
            this.gridObj2.setRows()
            // this.gridObj2.setRows()
            if (_.isEmpty(this.ds_user.userCd)) {
                this.showTcComAlert('사번을 입력해주세요.')
                return
            }
            let params = {
                userId: this.ds_user.userId,
                userCd: this.ds_user.userCd,
            }
            // params.pageNum = pageNum
            // params.pageSize = this.rowCnt

            console.log('this.params : ', params)
            API.getUserCnt(params).then((resultData) => {
                let ds_userCnt = resultData
                // this.ds_saleChrgrDealCoList = resultData.basUsmCurntUserInfoVo[0]
                if (ds_userCnt[0].cnt == '0') {
                    console.log('resultData : ', resultData)
                    this.saveUserDetailInfo()
                } else {
                    this.showTcComAlert('다른아이디가 사용 중인 사번입니다.')
                    return
                }
            })
        },

        async saveUserDetailInfo() {
            var sMsg =
                '위 내용과 실제 사용자와의 정보는 일치하며,' +
                '\n불일치로 인한 책임은 사용자에게 있습니다.\n저장하시겠습니까?'

            if (!(await this.showTcComConfirm(sMsg))) {
                return
            }

            let saveParam = {
                userId: this.ds_user.userId ? this.ds_user.userId : '',
                orgCd: this.searchAuthOrgTreeParam.orgCd
                    ? this.searchAuthOrgTreeParam.orgCd
                    : '',
                userCd: this.ds_user.userCd ? this.ds_user.userCd : '',
                // wphonNo: this.ds_user.wphonNo ? this.ds_user.wphonNo : '',
                repMblPhonNo: this.ds_user.repMblPhonNo
                    ? this.ds_user.repMblPhonNo
                    : '',
                // email1: this.ds_user.email1 ? this.ds_user.email1 : '',
                // email2: this.ds_user.email2 ? this.ds_user.email2 : '',
                indirInfoPraAgreeYn: this.ds_user.indirInfoPraAgreeYn
                    ? this.ds_user.indirInfoPraAgreeYn
                    : '',
                dealcoCd: this.searchForm.dealcoCd ? this.ds_user.dealcoCd : '',
                mblPhonNo: this.ds_user.mblPhonNo ? this.ds_user.mblPhonNo : '',
                // mblPhonNo2: this.ds_user.mblPhonNo2
                //     ? this.ds_user.mblPhonNo2
                //     : '',
                // mblPhonNo3: this.ds_user.mblPhonNo3
                //     ? this.ds_user.mblPhonNo3
                //     : '',
                // happySmsNo1: this.ds_user.happySmsNo1
                //     ? this.ds_user.happySmsNo1
                //     : '',
                // happySmsNo2: this.ds_user.happySmsNo2
                //     ? this.ds_user.happySmsNo2
                //     : '',
                // happySmsNo3: this.ds_user.happySmsNo3
                //     ? this.ds_user.happySmsNo3
                //     : '',
                // accSmsYn1: this.ds_user.accSmsYn1 ? this.ds_user.accSmsYn1 : '',
                // accSmsYn2: this.ds_user.accSmsYn2 ? this.ds_user.accSmsYn2 : '',
                attcClCd: this.ds_user.attcClCd ? this.ds_user.attcClCd : '',
            }

            await API.saveUserDetailInfo(saveParam)
                .then((result) => {
                    console.log('result : ', result)
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    // 매핑정보 재조회
                    this.onClose()
                })
                .catch((error) => {
                    this.showTcComAlert('저장에 실패했습니다.')
                    throw error
                    // 매핑정보 재조회
                    // this.onSearch()
                })
        },

        //메일계정 선택 시
        cmb_mailList_OnChanged(e) {
            console.log('cmb_mailList_OnChangedcmb_mailList_OnChanged', e)
            _.forEach(this.$refs.emailList.dCommItemList, (data) => {
                if (_.isEqual(e, data.commCdVal)) {
                    this.ds_user.email2 = data.commCdValNm
                }
            })
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchAuthOrgTreeParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 4) {
                        this.searchAuthOrgTreeParam.orgCd = _.get(
                            res[3],
                            'orgCd'
                        )
                        this.searchAuthOrgTreeParam.orgNm = _.get(
                            res[3],
                            'orgNm'
                        )
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // this.searchAuthOrgTreeParam.basMth = CommonUtil.replaceDash(
            //     SacCommon.getToday()
            // )
            this.searchAuthOrgTreeParam.vLevel = '3' // 디스플레이제한레벨
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchAuthOrgTreeParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // this.searchAuthOrgTreeParam.basMth = CommonUtil.replaceDash(
            //     SacCommon.getToday()
            // )
            this.searchAuthOrgTreeParam.vLevel = '3' // 디스플레이제한레벨
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchAuthOrgTreeParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchAuthOrgTreeParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchAuthOrgTreeParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchAuthOrgTreeParam.orgNm = _.get(retrunData, 'orgNm')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================

        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처(권한조직) 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처(권한조직) 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된내부거래처(권한조직) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처(권한조직) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.searchForm.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.searchForm.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처(권한조직) 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.searchForm.orgCd = this.searchAuthOrgTreeParam.orgCd
            this.searchForm.orgNm = this.searchAuthOrgTreeParam.orgNm
            this.searchForm.basDay = CommonUtil.replaceDash(
                SacCommon.getToday()
            )
            // 검색조건 내부거래처(권한조직)명이 빈값이 아니면 내부거래처(권한조직) 정보 조회
            // 그 이외는 내부거래처(권한조직) 팝업 오픈
            if (!_.isEmpty(this.searchForm.dealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처(권한조직) TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처(권한조직) 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.searchForm.orgCd = this.searchAuthOrgTreeParam.orgCd
            this.searchForm.orgNm = this.searchAuthOrgTreeParam.orgNm
            this.searchForm.basDay = CommonUtil.replaceDash(
                SacCommon.getToday()
            )

            //replace     substring(0, 6)
            // 검색조건 내부거래처(권한조직)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchForm.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처(권한조직)명 입력해주세요.'
                return
            }
            // 내부거래처(권한조직) 정보 조회
            this.getDealcosList()
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처(권한조직) 코드 초기화
            this.searchForm.dealcoCd = ''
        },
        // 내부거래처(권한조직) 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchForm.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.searchForm.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===========================================================================================
    },
}
</script>
