import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'aplyDt',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.DATETIME,
        },
    ],
    columns: [
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            header: { text: '수수료항목', excelName: '수수료항목' },
            width: '410',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            header: { text: '공급가', excelName: '공급가' },
            width: '200',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'aplyDt',
            fieldName: 'aplyDt',
            type: 'data',
            header: { text: '업로드일자', excelName: '업로드일자' },
            width: '200',
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            header: { text: '처리자', excelName: '처리자' },
            width: '200',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            header: { text: '처리일', excelName: '처리일' },
            width: '200',
            datetimeFormat: 'yyyy-MM-dd HH:mm:ss',
        },
    ],
}
