import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'accYm',
            dataType: ValueType.TEXT,
            Text: 'yyyyMM',
        },
        {
            fieldName: 'aprvStatCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'aprvStatNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'confirmYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'aplyPrcPrc',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'tbasAgrmtAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'totAmt',
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'sktTrmsDtm',
            dataType: ValueType.TEXT,
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcsDtm',
            // dataType: ValueType.DATETIME,
            // datetimeFormat: 'yyyyMMddhhmmss',
            dataType: ValueType.TEXT,
            // datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'saveAmt',
            dataType: ValueType.NUMBER,
        },

        {
            fieldName: 'taxfreeAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'accYm',
            fieldName: 'accYm',
            type: 'data',
            header: { text: '정산월', excelName: '정산월' },
            width: '150',
            datetimeFormat: 'yyyy-MM',
            visible: false,
        },
        {
            name: 'aprvStatCd',
            fieldName: 'aprvStatCd',
            type: 'data',
            header: { text: '승인상태코드', excelName: '승인상태코드' },
            width: '150',
            visible: false,
        },

        {
            name: 'aprvStatNm',
            fieldName: 'aprvStatNm',
            type: 'data',
            header: { text: '승인상태', excelName: '승인상태' },
            width: '150',
        },
        {
            name: 'fixYn',
            fieldName: 'fixYn',
            type: 'data',
            header: { text: '확정여부', excelName: '확정여부' },
            width: '150',
            visible: false,
        },
        {
            name: 'confirmYn',
            fieldName: 'confirmYn',
            type: 'data',
            header: { text: '확정여부명', excelName: '확정여부명' },
            width: '150',
        },

        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점', excelName: '대리점' },
            width: '150',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: { text: '대리점명', excelName: '대리점명' },
            width: '200',
        },
        {
            name: 'accAmt',
            fieldName: 'accAmt',
            type: 'data',
            header: { text: '추정 인센티브', excelName: '추정 인센티브' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'aplyPrcPrc',
            fieldName: 'aplyPrcPrc',
            type: 'data',
            header: { text: '공급가', excelName: '공급가' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            header: { text: '부가세', excelName: '부가세' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'tbasAgrmtAmt',
            fieldName: 'tbasAgrmtAmt',
            type: 'data',
            header: { text: '약정지원금', excelName: '약정지원금' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'totAmt',
            fieldName: 'totAmt',
            type: 'data',
            header: { text: '합계', excelName: '합계' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'sktTrmsDtm',
            fieldName: 'sktTrmsDtm',
            type: 'data',
            header: { text: 'Swing 전송일', excelName: 'Swing 전송일' },
            width: '150',
            datetimeFormat: 'yyyy-MM-dd',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            header: { text: '처리자', excelName: '처리자' },
            width: '150',
        },
        {
            name: 'prcsDtm',
            fieldName: 'prcsDtm',
            type: 'data',
            header: { text: '처리일', excelName: '처리일' },
            width: '150',
            // dataType: ValueType.DATETIME,
            // datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
        },

        {
            name: 'saveAmt',
            visible: false,
        },

        {
            name: 'taxfreeAmt',
            visible: false,
        },
    ],
    layout: [
        'aprvStatNm',
        'confirmYn',
        'agencyCd',
        'agencyNm',
        'accAmt',
        {
            name: 'fixInfo',
            direction: 'horizontal',
            items: ['aplyPrcPrc', 'vatAmt', 'tbasAgrmtAmt', 'totAmt'],
            header: { text: '확정 인센티브' },
        },
        'sktTrmsDtm',
        'modUserNm',
        'prcsDtm',
        'saveAmt',
        'taxfreeAmt',
    ],
}

export const GRID_HEADER_DTL = {
    fields: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlItmNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prMnyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prMnyDtlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlItmDtlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'objSumCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prMnyAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bdgtYm',
            dataType: ValueType.DATE,
            datetimeFormat: 'yyyyMM',
        },
        {
            fieldName: 'objClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'extrtMthdClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ifDate',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점', excelName: '대리점' },
            width: '150',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: { text: '대리점명', excelName: '대리점명' },
            width: '200',
        },
        {
            name: 'settlItmNm',
            fieldName: 'settlItmNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '그룹항목',
                excelName: '그룹항목',
            },
            width: '200',
        },
        {
            name: 'prMnyNm',
            fieldName: 'prMnyNm',
            type: 'data',
            styleName: 'left-column',
            header: { text: '계열', excelName: '계열' },
            width: '150',
        },
        {
            name: 'prMnyDtlNm',
            fieldName: 'prMnyDtlNm',
            type: 'data',
            styleName: 'left-column',
            header: { text: '그룹', excelName: '그룹' },
            width: '150',
        },
        {
            name: 'settlItmDtlNm',
            fieldName: 'settlItmDtlNm',
            type: 'data',
            styleName: 'left-column',
            header: { text: '정책', excelName: '정책' },
            width: '150',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'objSumCnt',
            fieldName: 'objSumCnt',
            type: 'data',
            styleName: 'right-column',
            header: { text: '건수', excelName: '건수' },
            width: '150',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'prMnyAmt',
            fieldName: 'prMnyAmt',
            type: 'data',
            header: { text: '금액', excelName: '금액' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'bdgtYm',
            fieldName: 'bdgtYm',
            type: 'data',
            header: { text: '영업년월', excelName: '영업년월' },
            width: '150',
            datetimeFormat: 'yyyy-MM',
        },
        {
            name: 'objClNm',
            fieldName: 'objClNm',
            type: 'data',
            header: { text: '지급주체', excelName: '지급주체' },
            width: '150',
            visible: false,
        },
        {
            name: 'extrtMthdClNm',
            fieldName: 'extrtMthdClNm',
            type: 'data',
            header: { text: '추출방법', excelName: '추출방법' },
            width: '150',
        },
        {
            name: 'ifDate',
            fieldName: 'ifDate',
            type: 'data',
            header: { text: '전송일자', excelName: '전송일자' },
            width: '150',
            datetimeFormat: 'yyyy-MM-dd',
        },
    ],
    layout: [
        'agencyCd',
        'agencyNm',
        {
            name: 'incenInfo',
            direction: 'horizontal',
            items: [
                'settlItmNm',
                'prMnyNm',
                'prMnyDtlNm',
                'settlItmDtlNm',
                'objSumCnt',
                'prMnyAmt',
            ],
            header: { text: '인센티브정보' },
        },
        'bdgtYm',
        'objClNm',
        'extrtMthdClNm',
        'ifDate',
    ],
}

export const GRID_HEADER_SUB = {
    fields: [
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlItmNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'objSumCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prMnyAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            header: { text: '대리점', excelName: '대리점' },
            width: '150',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            header: { text: '대리점명', excelName: '대리점명' },
            width: '200',
        },
        {
            name: 'settlItmNm',
            fieldName: 'settlItmNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '그룹항목',
                excelName: '그룹항목',
            },
            footer: {
                text: '합계',
            },
            width: '150',
        },
        {
            name: 'objSumCnt',
            fieldName: 'objSumCnt',
            type: 'data',
            header: { text: '건수', excelName: '건수' },
            width: '150',
            styleName: 'right-column',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
        {
            name: 'prMnyAmt',
            fieldName: 'prMnyAmt',
            type: 'data',
            header: { text: '금액', excelName: '금액' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
    ],
    layout: [
        'agencyCd',
        'agencyNm',
        {
            name: 'incenSubInfo',
            direction: 'horizontal',
            items: ['settlItmNm', 'objSumCnt', 'prMnyAmt'],
            header: { text: '인센티브정보' },
        },
    ],
}

export const GRID_HEADER_SUB1 = {
    fields: [
        {
            fieldName: 'bdgtYm',
            dataType: ValueType.DATE,
            datetimeFormat: 'yyyyMM',
        },
        {
            fieldName: 'prMnyAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'bdgtYm',
            fieldName: 'bdgtYm',
            type: 'data',
            header: { text: '영업월', excelName: '영업월' },
            width: '122',
            datetimeFormat: 'yyyy-MM',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'prMnyAmt',
            fieldName: 'prMnyAmt',
            type: 'data',
            header: { text: '장려금', excelName: '장려금' },
            width: '122',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
    ],
}

export const GRID_HEADER_SUB2 = {
    fields: [
        {
            fieldName: 'accYm',
            dataType: ValueType.TEXT,
            Text: 'yyyyMM',
        },
        {
            fieldName: 'trmsSplyPrc',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'accYm',
            fieldName: 'accYm',
            type: 'data',
            header: { text: '정책월', excelName: '정책월' },
            width: '122',
            datetimeFormat: 'yyyy-MM',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'trmsSplyPrc',
            fieldName: 'trmsSplyPrc',
            type: 'data',
            header: { text: '제외금액', excelName: '제외금액' },
            width: '122',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
    ],
}

export const GRID_HEADER_SUB3 = {
    fields: [
        {
            fieldName: 'title1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'title2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'amt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'title1',
            fieldName: 'title1',
            header: { visible: false },
            type: 'data',
            width: '60',
            mergeRule: {
                criteria: 'value',
            },
        },

        {
            name: 'title2',
            fieldName: 'title2',
            header: { visible: false },
            type: 'data',
            width: '60',
        },
        {
            name: 'amt',
            fieldName: 'amt',
            header: { visible: false },
            type: 'data',
            width: '60',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
    ],
    layout5: [
        {
            name: 'items',
            direction: 'horizontal',
            hideChildHeaders: true,
            items: ['title1', 'title2', 'amt'],
            header: { text: 'T-약정금액', visible: true },
        },
    ],
}
