import { ValueType } from 'realgrid'

export const DisCioDisSrchPopup_GRID_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disSt',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'movCnt',
            dataType: ValueType.NUMBER, //수량
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER, //단가
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT, //제조사코드
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'outPlcId',
            dataType: ValueType.TEXT, //출고처코드
        },
        {
            fieldName: 'inPlcId',
            dataType: ValueType.TEXT, //입고처코드
        },
        {
            fieldName: 'inSktCd',
            dataType: ValueType.TEXT, //입고처매장코드
        },
        {
            fieldName: 'inPlcNm',
            dataType: ValueType.TEXT, //입고처명
        },
        {
            fieldName: 'updCnt',
            dataType: ValueType.TEXT, //수정횟수
        },
        {
            fieldName: 'amt',
            dataType: ValueType.NUMBER, //금액
        },
        {
            fieldName: 'outMgmtNo',
            dataType: ValueType.TEXT, //출고관리번호
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'outSeq',
            dataType: ValueType.TEXT, //출고순번
        },
        {
            fieldName: 'regYn',
            dataType: ValueType.NUMBER, //등록여부
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: 90,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: 140,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'badYn',
            fieldName: 'badYn',
            width: 90,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
            },
            header: {
                text: '불량여부',
            },
        },
        {
            name: 'disSt',
            fieldName: 'disSt',
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
            },
            header: {
                text: '재고상태',
            },
        },
        {
            name: 'movCnt',
            fieldName: 'movCnt',
            type: 'data',
            width: 90,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수량',
                showTooltip: false,
            },
            numberFormat: '##0',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            type: 'data',
            visible: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'outPlcId',
            fieldName: 'outPlcId',
            type: 'data',
            visible: false,
        },
        {
            name: 'inPlcId',
            fieldName: 'inPlcId',
            type: 'data',
            visible: false,
        },
        {
            name: 'inSktCd',
            fieldName: 'inSktCd',
            type: 'data',
            visible: false,
        },
        {
            name: 'inPlcNm',
            fieldName: 'inPlcNm',
            type: 'data',
            visible: false,
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            type: 'data',
            visible: false,
        },
        {
            name: 'amt',
            fieldName: 'amt',
            type: 'data',
            visible: false,
        },
        {
            name: 'outMgmtNo',
            fieldName: 'outMgmtNo',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'outSeq',
            fieldName: 'outSeq',
            type: 'data',
            visible: false,
        },
        {
            name: 'regYn',
            fieldName: 'regYn',
            type: 'data',
            visible: false,
        },
    ],
}
