import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'actorId',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'firstName',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lastName',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lastUpdate',
            dataType: ValueType.DATETIME,
        },
    ],
    columns: [
        {
            name: 'actorId',
            fieldName: 'actorId',
            type: 'data',
            width: '80',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'No',
                showTooltip: true,
                tooltip: '<span style="color: red;">No</span>',
            },
            renderer: {
                type: 'text',
                showTooltip: true,
            },
        },
        {
            name: 'firstName',
            fieldName: 'firstName',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '성',
                showTooltip: false,
            },
        },
        {
            name: 'lastName',
            fieldName: 'lastName',
            type: 'data',
            width: '220',
            styles: {
                textAlignment: 'center',
            },
            header: '이름',
        },
        {
            name: 'lastUpdate',
            fieldName: 'lastUpdate',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수정일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            editor: {
                datetimeFormat: 'yyyy-MM-dd hh:mm:ss',
            },
        },
    ],
}
