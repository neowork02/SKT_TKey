/*****************************************
* 업무 그룹명 : IPLOG
* 서브 업무명 : IPLOG
* 설 명 : IPLOG Grid 헤더 정보
* 작 성 자 : 배수현
* 작 성 일 : 2022.00.00
* Copyright ⓒ SK TELECOM. All Right Reserved
*
======================================
* 변경자/변경일 : 배수현  / 2022.00.00
* 변경사유/내역 : 
* ---------------------------------------
* 변경자/변경일 :
* 변경사유/내역 : 
*
======================================
*****************************************/
import { ValueType } from 'realgrid'

export const BAS_IP_LOG_HEADER = {
    fields: [
        {
            fieldName: 'userId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'connectIp',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'metHodId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'mobileYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'userId',
            fieldName: 'userId',
            type: 'data',
            width: 50,

            header: {
                text: '사용자ID',
            },
        },
        {
            name: 'connectIp',
            fieldName: 'connectIp',
            type: 'data',
            width: 70,
            header: {
                text: '접속IP',
            },
        },
        {
            name: 'metHodId',
            fieldName: 'metHodId',
            type: 'data',
            width: 80,
            header: {
                text: '화면경로',
            },
        },
        {
            name: 'dealCoCd',
            fieldName: 'dealCoCd',
            type: 'data',
            width: 50,
            header: {
                text: '근무지코드',
            },
        },
        {
            name: 'mobileYn',
            fieldName: 'mobileYn',
            type: 'data',
            width: 20,
            header: {
                text: '모바일접속여부',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: 80,
            header: {
                text: '접속일시',
            },
        },
    ],
}
