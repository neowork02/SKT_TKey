/*****************************************
 * 업무 그룹명 : 판매관리
 * 서브 업무명 : 소매매출-기타 매출수납관리상세
 * 설 명 : 기타 매출수납관리상세 Grid 헤더
 * 작 성 자 : 양현모
 * 작 성 일 : 2022.07.18
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const PAY_REQ_DTL_HEADER = {
    fields: [
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, // 판매관리번호
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'eqpMdlCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'eqpSerNo',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'mdlPolSalePrc',
            dataType: ValueType.NUMBER, // 고객부담금
        },
        {
            fieldName: 'mdlCashSalePrc',
            dataType: ValueType.NUMBER, // 매출금액
        },
        {
            fieldName: 'payItem',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'payMgmtNo',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'payMthdCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'gnrlSaleChgSeq',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'fixCashSale',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'despotsCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'saleClCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 처리자ID
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT, // 처리자
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 처리일시
        },
    ],
    columns: [
        {
            name: 'saleMgmtNo',
            fieldName: 'saleMgmtNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '수납관리번호',
            },
            footer: {
                text: '수납대상금액',
            },
        },
        {
            name: 'saleClCd',
            fieldName: 'saleClCd',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '상품구분',
            },
        },
        {
            name: 'mdlCashSalePrc',
            fieldName: 'mdlCashSalePrc',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '매출금액',
            },
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '100',
            editable: false,
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
            header: {
                text: '처리일시',
            },
        },
    ],
    footerLayout: [
        {
            name: 'footerGroup',
            header: { visible: false },
            direction: 'horizontal',
            items: [
                {
                    column: 'saleMgmtNo',
                    footerUserSpans: [{ colspan: 2 }],
                },
                'saleClCd',
                'mdlCashSalePrc',
                {
                    column: 'modUserId',
                    footerUserSpans: [{ colspan: 3 }],
                },
                'userNm',
                'modDtm',
            ],
        },
    ],
}

export const PAY_DTL_HEADER = {
    fields: [
        {
            fieldName: 'payMgmtNo',
            dataType: ValueType.TEXT, // 수납번호
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, // 수납날짜
        },
        {
            fieldName: 'payAmt',
            dataType: ValueType.NUMBER, // 수납금액
        },
        {
            fieldName: 'payMthdCd',
            dataType: ValueType.TEXT, // 수납방법
        },
        {
            fieldName: 'cardAprvNo',
            dataType: ValueType.TEXT, // 카드승인번호
        },
        {
            fieldName: 'refNo',
            dataType: ValueType.TEXT, // 레퍼런스번호
        },
        {
            fieldName: 'cardCoCd',
            dataType: ValueType.TEXT, // 카드사
        },
        {
            fieldName: 'cardCoNm',
            dataType: ValueType.TEXT, // 카드사 명
        },
        {
            fieldName: 'unpayBamt',
            dataType: ValueType.NUMBER, // 미수납잔액
        },
        {
            fieldName: 'ediYn',
            dataType: ValueType.TEXT, // 수납구분
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, // 비고
        },
        {
            fieldName: 'tmpUnbay',
            dataType: ValueType.NUMBER, //
        },
        {
            fieldName: 'cardAprvDt',
            dataType: ValueType.TEXT, // 카드승인날짜
        },
        {
            fieldName: 'trmsDtm',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'cardEqpNo',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'paySeq',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'payCl',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'salePlc',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'paymentDtm',
            dataType: ValueType.TEXT, //
        },
    ],
    columns: [
        {
            name: 'payMgmtNo',
            fieldName: 'payMgmtNo',
            type: 'data',
            width: '100',
            editable: false,
            header: {
                text: '수납번호',
            },
        },
        {
            name: 'payAmt',
            fieldName: 'payAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '수납금액',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const ediYn = grid.getValue(itemIndex, 'ediYn') ?? ''
                const payMgmtNo = grid.getValue(itemIndex, 'payMgmtNo') ?? ''

                if (ediYn === 'Y') {
                    ret.editable = false
                } else {
                    if (payMgmtNo.length > 5) {
                        ret.editable = false
                    } else {
                        ret.editable = true
                    }
                }

                return ret
            },
        },
        {
            name: 'payMthdCd',
            fieldName: 'payMthdCd',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '수납방법',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const ediYn = grid.getValue(itemIndex, 'ediYn') ?? ''

                if (ediYn === 'Y') {
                    ret.editable = false
                } else {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'cardAprvNo',
            fieldName: 'cardAprvNo',
            type: 'data',
            width: '100',
            header: {
                text: '카드승인번호',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                if (payMthdCd === 'PM04') {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'cardCoCd',
            fieldName: 'cardCoCd',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '카드사',
            },
            styleCallback(grid, dataCell) {
                const ret = { editable: false }
                const itemIndex = dataCell.index.itemIndex
                const payMthdCd = grid.getValue(itemIndex, 'payMthdCd') ?? ''

                if (payMthdCd === 'PM04') {
                    ret.editable = true
                }

                return ret
            },
        },
        {
            name: 'unpayBamt',
            fieldName: 'unpayBamt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            editable: false,
            header: {
                text: '미수납잔액',
            },
        },
        {
            name: 'ediYn',
            fieldName: 'ediYn',
            type: 'data',
            width: '100',
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            editable: false,
            header: {
                text: '수납구분',
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '비고',
            },
        },
    ],
}
