import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = [
    {
        fieldName: 'fixDt',
        header: { text: '정산일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'payDtm',
        header: { text: '수납일자' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'orgTree',
        header: { text: '조직' },
        width: '300',
    },
    {
        fieldName: 'accDealcoCd',
        header: { text: '정산처' },
        width: '150',
    },
    {
        fieldName: 'accDealcoNm',
        header: { text: '정산처명' },
        width: '150',
    },
    {
        fieldName: 'dealcoCd',
        header: { text: '수납처' },
        width: '150',
    },
    {
        fieldName: 'dealcoNm',
        header: { text: '수납처명' },
        width: '150',
    },
    {
        fieldName: 'dealcoClNm1',
        header: { text: '거래처구분' },
        width: '150',
    },
    {
        fieldName: 'saleMgmtNo',
        header: { text: '관리번호' },
        width: '150',
    },
    {
        fieldName: 'saleMgmtSeq',
        header: { text: '변경순번' },
        width: '150',
    },
    {
        fieldName: 'saleClNm',
        header: { text: '수납구분' },
        width: '150',
    },
    {
        fieldName: 'opStNm',
        header: { text: '수납상태' },
        width: '150',
    },
    {
        fieldName: 'payMgmtNo',
        header: { text: '수납번호' },
        width: '150',
    },
    {
        fieldName: 'cardCoNm',
        header: { text: '카드사' },
        width: '150',
    },
    {
        fieldName: 'cardAprvNo',
        header: { text: '승인번호' },
        width: '150',
    },
    {
        fieldName: 'payAmt',
        header: { text: '수납금액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'dpstAccAmt',
        header: { text: '입금금액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'dpstAccCmmsAmt',
        header: { text: '수수료' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'svcMgmtNums',
        header: { text: 'T서비스관리번호' },
        width: '150',
    },
    {
        fieldName: 'freeProdSaleNos',
        header: { text: '일반상품판매번호' },
        width: '150',
    },
]

const GRID_HEADER = {}
GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)

export { GRID_HEADER }
