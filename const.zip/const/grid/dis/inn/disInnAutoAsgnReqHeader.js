import { ValueType } from 'realgrid'

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'asgnQty',
            dataType: ValueType.NUMBER, //배정수량
        },
        {
            fieldName: 'ordAsgnQty',
            dataType: ValueType.NUMBER, //실배정수량
        },
        {
            fieldName: 'rlAsgnQty',
            dataType: ValueType.NUMBER, //자동배정수량
        },
        {
            fieldName: 'addAsgnQty',
            dataType: ValueType.NUMBER, //추가배정수량
        },
        {
            fieldName: 'lmtQty',
            dataType: ValueType.NUMBER, //배정수량합계
            valueExpression: "values['rlAsgnQty']+values['addAsgnQty']",
        },
        {
            fieldName: 'gap',
            dataType: ValueType.NUMBER, //GAP
            valueExpression:
                "values['asgnQty']-values['rlAsgnQty']-values['addAsgnQty']",
        },
        {
            fieldName: 'asgnDt',
            dataType: ValueType.TEXT, //배정일자
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
    ],
    columns: [
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'asgnQty',
            fieldName: 'asgnQty', //sknAsgnQty
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'ordAsgnQty',
            fieldName: 'ordAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '실배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'rlAsgnQty',
            fieldName: 'rlAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            // editor: {
            //     type: 'number',
            // },
            header: {
                text: '자동배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'addAsgnQty',
            fieldName: 'addAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '추가배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'lmtQty',
            fieldName: 'lmtQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            // editor: {
            //     type: 'number',
            // },
            header: {
                text: '배정수량합계',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'gap',
            fieldName: 'gap',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            // editor: {
            //     type: 'number',
            // },
            header: {
                text: 'GAP',
                showTooltip: false,
            },
            editable: false,
        },
    ],
}

export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'asgnDt',
            dataType: ValueType.TEXT, //배정일자
        },
        {
            fieldName: 'fidcYn',
            dataType: ValueType.TEXT, //수탁재고여부
        },
        {
            fieldName: 'dlvYnD2',
            dataType: ValueType.TEXT, //D+2
        },
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT, //사업담당코드
        },
        {
            fieldName: 'orgId2Nm',
            dataType: ValueType.TEXT, //사업담당명
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT, //사업팀코드
        },
        {
            fieldName: 'orgId3Nm',
            dataType: ValueType.TEXT, //사업팀명
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT, //조직코드
        },
        // {
        //     fieldName: 'newOrgNm',
        //     dataType: ValueType.TEXT, //조직명
        // },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'dealcoShopCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT, //거래처코드
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT, //거래처명
        },
        {
            fieldName: 'repDlvDealcoCd',
            dataType: ValueType.TEXT, //배송지코드
        },
        {
            fieldName: 'sknDelvDealcdNm',
            dataType: ValueType.TEXT, //배송지명
        },
        {
            fieldName: 'rcvSknDelvPlcCd',
            dataType: ValueType.TEXT, //SKN배송지코드
        },
        {
            fieldName: 'sknDelvPlcNm',
            dataType: ValueType.TEXT, //SKN배송지명
        },
        // {
        //     fieldName: 'rcvSknDelvPlcCd',
        //     dataType: ValueType.TEXT, //SKN반송처코드
        // },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상명
        },
        {
            fieldName: 'currHldQty',
            dataType: ValueType.TEXT, //현보유수량
        },
        {
            fieldName: 'salePlcProdQty',
            dataType: ValueType.TEXT, //30일실적
        },
        {
            fieldName: 'asgnQty',
            dataType: ValueType.NUMBER, //배정수량
        },
        {
            fieldName: 'ordAsgnQty',
            dataType: ValueType.NUMBER, //실배정수량
        },
        {
            fieldName: 'rlAsgnQty',
            dataType: ValueType.NUMBER, //자동배정수량
        },
        {
            fieldName: 'addAsgnQty',
            dataType: ValueType.NUMBER, //추가배정수량
        },
        {
            fieldName: 'sumQty',
            dataType: ValueType.NUMBER, //배정수량합계
        },
        {
            fieldName: 'crdtOverYn',
            dataType: ValueType.TEXT, //여신초과여부
        },
        {
            fieldName: 'crdtAmt',
            dataType: ValueType.NUMBER, //여신금액
        },
        {
            fieldName: 'crdtBalAmt',
            dataType: ValueType.NUMBER, //여신잔액
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.NUMBER, //단가
        },
        {
            fieldName: 'amt',
            dataType: ValueType.NUMBER, //주문금액
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.NUMBER, //요청사용자ID
        },
        {
            fieldName: 'sknTrmsYn',
            dataType: ValueType.NUMBER, //SKN전송여부
        },
        {
            fieldName: 'ordAmt',
            dataType: ValueType.NUMBER, //주문금액
            valueExpression:
                "(values['rlAsgnQty']+values['addAsgnQty'])*values['unitPrc']",
        },
    ],
    columns: [
        {
            name: 'asgnDt',
            fieldName: 'asgnDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '기준일',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'fidcYn',
            fieldName: 'fidcYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수탁재고',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dlvYnD2',
            fieldName: 'dlvYnD2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'D+2',
                showTooltip: false,
            },
            editable: false,
        },
        // {
        //     name: 'bizChrgOrgCd',
        //     fieldName: 'bizChrgOrgCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '사업담당',
        //         showTooltip: false,
        //     },
        //     visible: false,
        // },
        // {
        //     name: 'orgId2Nm',
        //     fieldName: 'orgId2Nm',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '사업담당',
        //         showTooltip: false,
        //     },
        // },
        // {
        //     name: 'teamOrgCd',
        //     fieldName: 'teamOrgCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '사업팀',
        //         showTooltip: false,
        //     },
        //     visible: false,
        // },
        // {
        //     name: 'orgId3Nm',
        //     fieldName: 'orgId3Nm',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '사업팀',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        // {
        //     name: 'newOrgNm',
        //     fieldName: 'newOrgNm',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: 'PT',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
        },
        {
            name: 'dealcoShopCd',
            fieldName: 'dealcoShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'rcvSknDelvPlcCd',
            fieldName: 'rcvSknDelvPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKN배송지코드',
                showTooltip: false,
            },
            editable: false,
        },
        // {
        //     name: 'repDlvDealcoCd',
        //     fieldName: 'repDlvDealcoCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: 'SKN배송지',
        //         showTooltip: false,
        //     },
        //     editable: false,
        // },
        // {
        //     name: 'rcvSknDelvPlcCd',
        //     fieldName: 'rcvSknDelvPlcCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: 'SKN반송처코드',
        //         showTooltip: false,
        //     },
        //     editable: false,
        // },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'currHldQty',
            fieldName: 'currHldQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현보유수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'salePlcProdQty',
            fieldName: 'salePlcProdQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '30일실적',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'rlAsgnQty',
            fieldName: 'rlAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'ordAsgnQty',
            fieldName: 'ordAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '실배정수량',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'rlAsgnQty',
            fieldName: 'rlAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '자동배정수량',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'addAsgnQty',
            fieldName: 'addAsgnQty',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sumQty',
            fieldName: 'sumQty',
            type: 'number',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정수량합계',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'crdtOverYn',
            fieldName: 'crdtOverYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신초과여부',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'crdtAmt',
            fieldName: 'crdtAmt',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신금액',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'crdtBalAmt',
            fieldName: 'crdtBalAmt',
            type: 'data',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '여신잔액',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'number',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단가',
                showTooltip: false,
            },
            editable: false,
            // numberFormat: '#,##0',
        },
        {
            name: 'ordAmt',
            fieldName: 'ordAmt',
            type: 'number',
            numberFormat: '#,###,###,##0',
            styles: {
                textAlignment: 'right',
            },
            header: {
                text: '주문금액',
                showTooltip: false,
            },
            editable: false,
            // numberFormat: '#,##0',
        },
    ],
}
