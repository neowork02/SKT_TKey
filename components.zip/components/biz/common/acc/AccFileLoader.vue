<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccGridTable.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="fileContext">
        <TCComFileInput
            ref="fileLoader"
            class="fileLoader"
            v-model="fileLoaderValue"
            :class="{ hidden: this.isHidden }"
            :labelName="labelName"
            :accept="accept"
            @change="loadFile"
        ></TCComFileInput>

        <TCComLoadingBar v-model="loading" ref="loading" />
    </div>
</template>
<style scoped>
.fileLoader.hidden {
    position: absolute;
    top: 0;
    left: 0;
    opacity: 0;
    visibility: hidden;
    overflow: hidden;
    width: 0;
    height: 0;
}

.fileLoader :deep(.search-btn.v-file-input) .v-text-field__slot {
    overflow: hidden;
}

.fileLoader
    :deep(.search-btn.v-file-input)
    .v-text-field__slot
    .v-file-input__text {
    white-space: nowrap;
}
</style>

<script>
import { fileHandler } from '@/utils/accUtil'

import CommonMixin from '@/mixins'

export default {
    name: 'AccFileLoader',
    mixins: [CommonMixin],
    components: {},
    props: {
        isHidden: Boolean,

        value: {
            default: null,
        },

        data: {
            default: () => [],
        },

        labelName: {
            default: '첨부파일',
        },
    },
    computed: {
        fileLoaderInput() {
            return this.$refs.fileLoader.$refs.fileInput.$refs.input
        },

        fileLoaderValue: {
            get() {
                return this.value
            },
            set(value) {
                this.$emit('input', value)
            },
        },
    },
    data() {
        return {
            files: null,
            accept: null,
            loading: false,
        }
    },
    created() {},
    mounted() {},
    methods: {
        loadFile(files) {
            if (!files) {
                this.$emit('load', null)
                return
            }

            this.file = files

            this.loading = true
            this.$refs.loading.$el.style.zIndex = '9999999'

            fileHandler
                .loadFile(files)
                .then((fileData) => {
                    this.fileLoaderInput.val = null
                    this.$emit('load', fileData, files)
                })
                .finally(() => {
                    this.loading = false
                })
        },

        openSelector(type) {
            this.accept = this.getAcceptType(type)
            this.fileLoaderInput.value = null
            this.fileLoaderInput.click()
        },

        getFile() {
            return this.file
        },

        getAcceptType(type) {
            let accept

            switch (type) {
                case 'excel':
                    accept = `.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel`
                    break
                default:
                    break
            }

            return accept
        },

        setAcceptType(type) {
            this.accept = this.getAcceptType(type)
        },

        clearFile() {
            this.fileLoaderValue = null
        },
    },
}
</script>
