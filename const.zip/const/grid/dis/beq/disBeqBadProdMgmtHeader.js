import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'rgstSeq',
            dataType: ValueType.INT, //번호
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT, //등록일자
        },
        {
            fieldName: 'oprUserId',
            dataType: ValueType.TEXT, //등록자
        },
        {
            fieldName: 'oprUserNm',
            dataType: ValueType.TEXT, //등록자
        },
        {
            fieldName: 'chrgrUserId',
            dataType: ValueType.TEXT, //영업담당
        },
        {
            fieldName: 'chrgrUserNm',
            dataType: ValueType.TEXT, //영업담당
        },
        {
            fieldName: 'dealcoClCd',
            dataType: ValueType.TEXT, //거래처 구분
        },
        {
            fieldName: 'dealCoClNm',
            dataType: ValueType.TEXT, //거래처 구분
        },
        {
            fieldName: 'saleDealcoCd',
            dataType: ValueType.TEXT, //판매처
        },
        {
            fieldName: 'saleDealcdNm',
            dataType: ValueType.TEXT, //판매처
        },
        {
            fieldName: 'saleShopCd',
            dataType: ValueType.TEXT, //판매처매장코드
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT, //채널코드
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'mfactCd',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT, //제조사
        },
        {
            fieldName: 'barCdTypCd',
            dataType: ValueType.TEXT, //바코드종류코드
        },
        {
            fieldName: 'barCdTypNm',
            dataType: ValueType.TEXT, //바코드종류명 바코드유형
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //모델코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'ukeyExpartYn',
            dataType: ValueType.TEXT, //Swing교품여부
        },
        {
            fieldName: 'opLclCd',
            dataType: ValueType.TEXT, //불량대분류
        },
        {
            fieldName: 'opLclNm',
            dataType: ValueType.TEXT, //불량대분류
        },
        {
            fieldName: 'opMclCd',
            dataType: ValueType.TEXT, //불량중분류
        },
        {
            fieldName: 'opMclNm',
            dataType: ValueType.TEXT, //불량중분류
        },
        {
            fieldName: 'badStCd',
            dataType: ValueType.TEXT, //불량상태
        },
        {
            fieldName: 'badStNm',
            dataType: ValueType.TEXT, //불량상태
        },
        {
            fieldName: 'badShopCd',
            dataType: ValueType.TEXT, //등록보유처매장코드
        },
        {
            fieldName: 'badDealcoCd',
            dataType: ValueType.TEXT, //등록보유처
        },
        {
            fieldName: 'badDealcoNm',
            dataType: ValueType.TEXT, //등록보유처
        },
        {
            fieldName: 'hldShopCd',
            dataType: ValueType.TEXT, //현보유처매장코드
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, //현보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, //현보유처
        },
        {
            fieldName: 'lastInoutDtlClCd',
            dataType: ValueType.TEXT, //최종입출고
        },
        {
            fieldName: 'lastInoutDtlClNm',
            dataType: ValueType.TEXT, //최종입출고
        },
        {
            fieldName: 'opClCd',
            dataType: ValueType.TEXT, //처리구분
        },
        {
            fieldName: 'opClNm',
            dataType: ValueType.TEXT, //처리구분
        },

        {
            fieldName: 'rgstClCd',
            dataType: ValueType.TEXT, //등록구분코드
        },
        {
            fieldName: 'rgstClNm',
            dataType: ValueType.TEXT, //등록구분명
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'badCnclDt',
            dataType: ValueType.TEXT, //불량해제일자
        },
        {
            fieldName: 'badCnclRsn',
            dataType: ValueType.TEXT, //불량해제사유
        },
        {
            fieldName: 'outOrgCd',
            dataType: ValueType.TEXT, //출고조직코드
        },
        {
            fieldName: 'outOrgNm',
            dataType: ValueType.TEXT, //출고조직명
        },
        {
            fieldName: 'outLvOrgCd',
            dataType: ValueType.TEXT, //출고레벨0조직코드
        },
        {
            fieldName: 'outLvOrgNm',
            dataType: ValueType.TEXT, //출고레벨0조직명
        },
        {
            fieldName: 'outLvOrgCd1',
            dataType: ValueType.TEXT, //출고레벨1조직코드
        },
        {
            fieldName: 'outLvOrgNm1',
            dataType: ValueType.TEXT, //출고레벨1조직명
        },
        {
            fieldName: 'outLvOrgCd2',
            dataType: ValueType.TEXT, //출고레벨2조직코드
        },
        {
            fieldName: 'outLvOrgNm2',
            dataType: ValueType.TEXT, //출고레벨2조직명
        },
        {
            fieldName: 'outLvOrgCd3',
            dataType: ValueType.TEXT, //출고레벨3조직코드
        },
        {
            fieldName: 'outLvOrgNm3',
            dataType: ValueType.TEXT, //출고레벨3조직명
        },
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT, //체크
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT, //요청사용자ID
        },
        {
            fieldName: 'expartDealcoCd',
            dataType: ValueType.TEXT, //교품신청처코드
        },
        {
            fieldName: 'expartReqPlcNm',
            dataType: ValueType.TEXT, //교품신청처명
        },
        {
            fieldName: 'expartReqDt',
            dataType: ValueType.TEXT, //교품신청일자
        },
        {
            fieldName: 'expartOpStCd',
            dataType: ValueType.TEXT, //교품처리상태코드
        },
        {
            fieldName: 'expartOpStNm',
            dataType: ValueType.TEXT, //교품처리상태명
        },
        {
            fieldName: 'expartOpCttCd',
            dataType: ValueType.TEXT, //교품처리내용코드
        },
        {
            fieldName: 'expartOpCttNm',
            dataType: ValueType.TEXT, //교품처리내용명
        },
        {
            fieldName: 'expartRgstUserId',
            dataType: ValueType.TEXT, //교품등록사용자ID
        },
        {
            fieldName: 'expartRgstNm',
            dataType: ValueType.TEXT, //교품등록사용자명
        },
        {
            fieldName: 'expartNoRsnCd',
            dataType: ValueType.TEXT, //교품불가사유코드
        },
        {
            fieldName: 'expartNoRsnNm',
            dataType: ValueType.TEXT, //교품불가사유명
        },
        {
            fieldName: 'expartDlvSchdDt',
            dataType: ValueType.TEXT, //교품배송예정일자
        },
        {
            fieldName: 'badYn',
            dataType: ValueType.TEXT, //불량여부
        },
    ],
    columns: [
        {
            name: 'opDt',
            fieldName: 'opDt',
            header: {
                text: '등록일자',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'oprUserNm',
            fieldName: 'oprUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록자',
                showTooltip: false,
            },
        },
        {
            name: 'chrgrUserNm',
            fieldName: 'chrgrUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '영업담당',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoClNm',
            fieldName: 'dealCoClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
        },
        {
            name: 'saleShopCd',
            fieldName: 'saleShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매처\n매장코드',
                styleName: 'multi-line-css',
                showTooltip: false,
            },
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매처코드',
                showTooltip: false,
            },
        },
        {
            name: 'saleDealcdNm',
            fieldName: 'saleDealcdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매처',
                showTooltip: false,
            },
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채널코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '제조사',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'ukeyExpartYn',
            fieldName: 'ukeyExpartYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Swing교품여부',
                showTooltip: false,
            },
        },
        {
            name: 'opLclNm',
            fieldName: 'opLclNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량대분류',
                showTooltip: false,
            },
        },
        {
            name: 'opMclNm',
            fieldName: 'opMclNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량중분류',
                showTooltip: false,
            },
        },
        {
            name: 'badStNm',
            fieldName: 'badStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량상태',
                showTooltip: false,
            },
        },
        {
            name: 'badShopCd',
            fieldName: 'badShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록보유처\n매장코드',
                styleName: 'multi-line-css',
                showTooltip: false,
            },
        },
        {
            name: 'badDealcoCd',
            fieldName: 'badDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'badDealcoNm',
            fieldName: 'badDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록보유처',
                showTooltip: false,
            },
        },
        {
            name: 'hldShopCd',
            fieldName: 'hldShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현보유처\n매장코드',
                styleName: 'multi-line-css',
                showTooltip: false,
            },
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현보유처',
                showTooltip: false,
            },
        },
        {
            name: 'lastInoutDtlClNm',
            fieldName: 'lastInoutDtlClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최종입출고',
                showTooltip: false,
            },
        },
        {
            name: 'opClNm',
            fieldName: 'opClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리구분',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_COLOR_HEADER = {
    fields: [
        {
            fieldName: 'COLOR_CODE',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'COLOR_NM',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'COLOR_CODE',
            fieldName: 'COLOR_CODE',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'COLOR_NM',
            fieldName: 'COLOR_NM',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
    ],
}
