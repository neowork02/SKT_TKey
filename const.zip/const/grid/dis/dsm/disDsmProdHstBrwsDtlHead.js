import { ValueType } from 'realgrid'

// 입고
export const IN_HEADER = {
    fields: [
        {
            fieldName: 'inoutDtlClCd', // 입출고상세구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDtlClNm', // 입출고상세구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDt', // 입출고일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoCd', // 매입처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoNm', // 매입처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsShopCd', // 매입처 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd', // 제조사코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm', // 제조사명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd', // 상품구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm', // 상품구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comMthdCd', // 통신방식코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comMthdNm', // 통신방식명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 상품코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', // 색상코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum', // 일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disAmt', // 단가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'inDealcoCd', // 입고처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoNm', // 입고처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inShopCd', // 입고처 매장코드
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'inoutDtlClNm',
            fieldName: 'inoutDtlClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '구분',
        },
        {
            name: 'inoutDt',
            fieldName: 'inoutDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고일자',
        },
        {
            name: 'prchsDealcoCd',
            fieldName: 'prchsDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처코드',
        },
        {
            name: 'prchsDealcoNm',
            fieldName: 'prchsDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '제조사',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품구분',
        },
        {
            name: 'comMthdNm',
            fieldName: 'comMthdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '통신방식',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '색상',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '일련번호',
        },
        {
            name: 'disAmt',
            fieldName: 'disAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '단가',
        },
    ],
}

// 출고, 재고이동
export const OUT_MOVE_HEADER = {
    fields: [
        {
            fieldName: 'inoutDtlClCd', // 입출고상세구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDtlClNm', // 입출고상세구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDt', // 출고일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoCd', // 출고처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outDealcoNm', // 출고처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outShopCd', // 출고처 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoCd', // 입고처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inDealcoNm', // 입고처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inShopCd', // 입고처 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fstInFixDt', // 최초입고일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoCd', // 매입처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoNm', // 매입처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsShopCd', // 매입처 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd', // 제조사코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm', // 제조사명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd', // 상품구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm', // 상품구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comMthdCd', // 통신방식코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comMthdNm', // 통신방식명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 상품코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', // 색상코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum', // 일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disAmt', // 단가
            dataType: ValueType.NUMBER,
        },
    ],
    columns_out: [
        {
            name: 'inoutDtlClNm',
            fieldName: 'inoutDtlClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '구분',
        },
        {
            name: 'inoutDt',
            fieldName: 'inoutDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '출고일자',
        },
        {
            name: 'outShopCd',
            fieldName: 'outShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처\n매장코드',
                styleName: 'multi-line-css',
            },
        },
        {
            name: 'outDealcoCd',
            fieldName: 'outDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '출고처코드',
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '출고처',
        },
        {
            name: 'inShopCd',
            fieldName: 'inShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처\n매장코드',
                styleName: 'multi-line-css',
            },
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고처코드',
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고처',
        },
        {
            name: 'fstInFixDt',
            fieldName: 'fstInFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입일자',
        },
        {
            name: 'prchsDealcoCd',
            fieldName: 'prchsDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처코드',
        },
        {
            name: 'prchsDealcoNm',
            fieldName: 'prchsDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '제조사',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품구분',
        },
        {
            name: 'comMthdNm',
            fieldName: 'comMthdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '통신방식',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '색상',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '일련번호',
        },
        {
            name: 'disAmt',
            fieldName: 'disAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '단가',
        },
    ],
    columns_move: [
        {
            name: 'inoutDtlClNm',
            fieldName: 'inoutDtlClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '구분',
        },
        {
            name: 'inoutDt',
            fieldName: 'inoutDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '출고일자',
        },
        {
            name: 'outShopCd',
            fieldName: 'outShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처\n매장코드',
                styleName: 'multi-line-css',
            },
        },
        {
            name: 'outDealcoCd',
            fieldName: 'outDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '출고처코드',
        },
        {
            name: 'outDealcoNm',
            fieldName: 'outDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '출고처',
        },
        {
            name: 'inShopCd',
            fieldName: 'inShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고처\n매장코드',
                styleName: 'multi-line-css',
            },
        },
        {
            name: 'inDealcoCd',
            fieldName: 'inDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고처코드',
        },
        {
            name: 'inDealcoNm',
            fieldName: 'inDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입고처',
        },
        {
            name: 'fstInFixDt',
            fieldName: 'fstInFixDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입일자',
        },
        {
            name: 'prchsDealcoCd',
            fieldName: 'prchsDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처코드',
        },
        {
            name: 'prchsDealcoNm',
            fieldName: 'prchsDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '제조사',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품구분',
        },
        {
            name: 'comMthdNm',
            fieldName: 'comMthdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '통신방식',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '색상',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '일련번호',
        },
        {
            name: 'disAmt',
            fieldName: 'disAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '단가',
        },
    ],
}

// 판매
export const SALE_HEADER = {
    fields: [
        {
            fieldName: 'inoutDtlClCd', // 입출고상세구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDtlClNm', // 입출고상세구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDt', // 판매일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd', // 판매처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoNm', // 판매처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleShopCd', // 판매처 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtlTypCd', // 판매상세유형코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtlTypNm', // 판매상세유형명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChgHstClNm', // 판매유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', // 서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNum', // 개통번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd', // 제조사코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm', // 제조사명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd', // 상품구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm', // 상품구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comMthdCd', // 통신방식코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comMthdNm', // 통신방식명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 상품코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', // 색상코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum', // 일련번호
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'inoutDtlClNm',
            fieldName: 'inoutDtlClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '구분',
        },
        {
            name: 'saleDt',
            fieldName: 'saleDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매일자',
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처코드',
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처',
        },
        {
            name: 'saleChgHstClNm',
            fieldName: 'saleChgHstClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매유형',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '서비스관리번호',
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '개통번호',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '제조사',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품구분',
        },
        {
            name: 'comMthdNm',
            fieldName: 'comMthdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '통신방식',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '색상',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '일련번호',
        },
    ],
}

// 판매
export const SERNUM_HEADER = {
    fields: [
        {
            fieldName: 'prodClNm', // 상품구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 모델코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 모델
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', //
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum', // 일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldOrgNm', // 소속조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hldDealcoNm', // 재고보유처
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품구분',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델코드',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '색상',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '일련번호',
        },
        {
            name: 'hldOrgNm',
            fieldName: 'hldOrgNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '소속조직',
        },
        {
            name: 'hldDealcoNm',
            fieldName: 'hldDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '재고보유처',
        },
    ],
}
