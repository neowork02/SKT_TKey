/*****************************************
 * 업무그룹명: 판매관리
 * 서브업무명: T수납대행관리
 * 설 명 : 판매관리-T수납대행관리-SKT수납대행 상세 Grid 헤더
 * 작성자: P179234
 * 작성일: 2022.07.28
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'
// import _ from 'lodash'

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'custNm',
            dataType: ValueType.TEXT, //고객명
        },
        {
            fieldName: 'svcNum',
            dataType: ValueType.TEXT, //서비스번호
        },
        {
            fieldName: 'opStCd',
            dataType: ValueType.TEXT, //처리상태
        },
        {
            fieldName: 'sktChargeNo',
            dataType: ValueType.TEXT, //수납관리번호
        },
        {
            fieldName: 'ifOpDt',
            dataType: ValueType.TEXT, //처리일자
        },
        {
            fieldName: 'ifOpTm',
            dataType: ValueType.TEXT, //처리시간
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, //Swing수납일자
        },
        {
            fieldName: 'payDt',
            dataType: ValueType.TEXT, //Tkey수납일자
        },
        {
            fieldName: 'payReqDealcoNm',
            dataType: ValueType.TEXT, //수납처
        },
        {
            fieldName: 'payReqDealcoCd',
            dataType: ValueType.TEXT, //수납처
        },
        {
            fieldName: 'accDealcoNm',
            dataType: ValueType.TEXT, //정산처
        },
        {
            fieldName: 'accDealcoCd',
            dataType: ValueType.TEXT, //정산처
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT, //서비스관리번호
        },
        {
            fieldName: 'payClCd',
            dataType: ValueType.TEXT, //수납구분
        },
        {
            fieldName: 'payObjAmt',
            dataType: ValueType.NUMBER, //수납대상금액
        },
        {
            fieldName: 'sktChargeSeq',
            dataType: ValueType.TEXT, //skt수납대행순번
        },
        {
            fieldName: 'ifSeq',
            dataType: ValueType.TEXT, //전문순번
        },
        {
            fieldName: 'settlWayNm',
            dataType: ValueType.TEXT, //결제조건
        },
        {
            fieldName: 'settlWayCd',
            dataType: ValueType.TEXT, //결제조건
        },
        {
            fieldName: 'payChgrgUserId',
            dataType: ValueType.TEXT, //처리담당자
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT, //처리담당자
        },
        {
            fieldName: 'wcktDealTypCd',
            dataType: ValueType.TEXT, //청구거래유형코드
        },
        {
            fieldName: 'slNetClCd',
            dataType: ValueType.TEXT, //코드
        },
        {
            fieldName: 'revItmCd',
            dataType: ValueType.TEXT, //코드
        },
        {
            fieldName: 'revItmNm',
            dataType: ValueType.TEXT, //코드
        },
        {
            fieldName: 'opMthdCd',
            dataType: ValueType.TEXT, //코드
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT, //코드
        },
        {
            fieldName: 'opDt',
            dataType: ValueType.TEXT, //코드
        },
        {
            fieldName: 'opTm',
            dataType: ValueType.TEXT, //코드
        },
        {
            fieldName: 'opSeq',
            dataType: ValueType.TEXT, //코드
        },
        {
            fieldName: 'prprcYn',
            dataType: ValueType.TEXT, //코드
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'sktAgencyCd',
            dataType: ValueType.TEXT, //대리점
        },
        {
            fieldName: 'sktAgencyNm',
            dataType: ValueType.TEXT, //대리점
        },
        {
            fieldName: 'lastYn', // lastYn
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '고객명',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'svcNum',
            fieldName: 'svcNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스번호',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'opStCd',
            fieldName: 'opStCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '처리상태',
                showTooltip: false,
            },
        },
        {
            name: 'sktChargeNo',
            fieldName: 'sktChargeNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'ifOpDt',
            fieldName: 'ifOpDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'ifOpTm',
            fieldName: 'ifOpTm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '전문처리시간',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            header: {
                text: 'Swing수납일자',
                showTooltip: false,
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'payDt',
            fieldName: 'payDt',
            type: 'data',
            header: {
                text: 'Tkey수납일자',
                showTooltip: false,
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'payReqDealcoNm',
            fieldName: 'payReqDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납처',
                showTooltip: false,
            },
        },
        {
            name: 'payReqDealcoCd',
            fieldName: 'payReqDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납처',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처',
                showTooltip: false,
            },
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '정산처',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'payClCd',
            fieldName: 'payClCd',
            type: 'data',
            editable: false,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납구분',
                showTooltip: false,
            },
        },
        {
            name: 'payObjAmt',
            fieldName: 'payObjAmt',
            type: 'data',
            styleName: 'right-column',
            header: {
                text: '수납대상금액',
                showTooltip: false,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'sktChargeSeq',
            fieldName: 'sktChargeSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'skt수납대행순번',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'ifSeq',
            fieldName: 'ifSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'SKT수납대행번호',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'settlWayNm',
            fieldName: 'settlWayNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '결제조건',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'settlWayCd',
            fieldName: 'settlWayCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '결제조건',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'payChgrgUserId',
            fieldName: 'payChgrgUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리담당자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리담당자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'wcktDealTypCd',
            fieldName: 'wcktDealTypCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '청구거래유형코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'slNetClCd',
            fieldName: 'slNetClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'revItmCd',
            fieldName: 'revItmCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'revItmNm',
            fieldName: 'revItmNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'opMthdCd',
            fieldName: 'opMthdCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'opTm',
            fieldName: 'opTm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'opSeq',
            fieldName: 'opSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'prprcYn',
            fieldName: 'prprcYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '코드',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'lastYn',
            fieldName: 'lastYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'lastYn',
                showTooltip: false,
            },
            visible: false,
        },
    ],
}

export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'status',
            dataType: ValueType.TEXT, //수납상태
        },
        {
            fieldName: 'payMgmtNo',
            dataType: ValueType.TEXT, //수납관리번호
        },
        {
            fieldName: 'payAmt',
            dataType: ValueType.NUMBER, //수납금액
        },
        {
            fieldName: 'payMthdCd',
            dataType: ValueType.TEXT, //수납방법
        },
        {
            fieldName: 'unpayBamt',
            dataType: ValueType.NUMBER, //잔액
        },
        {
            fieldName: 'rmks',
            dataType: ValueType.TEXT, //비고
        },
        {
            fieldName: 'tmpUnbay',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'paySeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payClCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'status',
            fieldName: 'status',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            values: ['1', '2'],
            labels: ['미처리', '처리완료'],
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '수납상태',
                showTooltip: false,
            },
        },
        {
            name: 'payMgmtNo',
            fieldName: 'payMgmtNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            header: {
                text: '수납관리번호',
                showTooltip: false,
            },
        },
        {
            name: 'payAmt',
            fieldName: 'payAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '수납금액',
                showTooltip: false,
            },
        },
        {
            name: 'payMthdCd',
            fieldName: 'payMthdCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            lookupDisplay: true,
            // values: ['PM06', 'PM01'],
            // labels: ['PG', '현금'],
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '수납방법',
                showTooltip: false,
            },
        },
        {
            name: 'unpayBamt',
            fieldName: 'unpayBamt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            editable: false,
            header: {
                text: '잔액',
                showTooltip: false,
            },
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '비고',
                showTooltip: false,
            },
        },
        {
            name: 'tmpUnbay',
            fieldName: 'tmpUnbay',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '미수납',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납일시',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'paySeq',
            fieldName: 'paySeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리순번',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'payDt',
            fieldName: 'payDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일자',
                showTooltip: false,
            },
            visible: false,
        },
        {
            name: 'payClCd',
            fieldName: 'payClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '수납구분코드',
                showTooltip: false,
            },
            visible: false,
        },
    ],
}
