import { ValueType } from 'realgrid'

export const basBcoSvcProdsHeader = {
    fields: [
        {
            fieldName: 'wrcellClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'suplSvcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'combProdYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'useYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcplnClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prcplnClDtlCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'wrcellClCd',
            fieldName: 'wrcellClCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '서비스구분',
            },
        },
        {
            name: 'suplSvcClCd',
            fieldName: 'suplSvcClCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '서비스상세구분',
            },
        },
        {
            name: 'suplSvcCd',
            fieldName: 'suplSvcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스코드',
            },
        },
        {
            name: 'suplSvcNm',
            fieldName: 'suplSvcNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '서비스명',
            },
            width: 200,
        },
        {
            name: 'prodStCd',
            fieldName: 'prodStCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '상품상태',
            },
        },
        {
            name: 'combProdYn',
            fieldName: 'combProdYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '결합상품',
            },
        },
        {
            name: 'rgstClCd',
            fieldName: 'rgstClCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '등록구분',
            },
        },
        {
            name: 'useYn',
            fieldName: 'useYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용여부',
            },
        },
        {
            name: 'prcplnClCd',
            fieldName: 'prcplnClCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '분류',
            },
        },
        {
            name: 'prcplnClDtlCd',
            fieldName: 'prcplnClDtlCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '분류상세',
            },
        },
    ],
}
