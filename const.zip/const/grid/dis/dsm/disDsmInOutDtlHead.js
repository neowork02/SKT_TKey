import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'inoutDt', // 입출고일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutClCd', // 입출고구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutClNm', // 입출고구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDtlClCd', // 입출고상세구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDtlClNm', // 입출고상세구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDt', // 판매일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleBfYn', // 전월/당월
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleExpartYn', // 교품여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'gnrlSaleNo', // 공기기여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd', // 레벨0조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm', // 레벨0조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd1', // 레벨1조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm1', // 레벨1조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd2', // 레벨2조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgNm2', // 레벨2조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'lvOrgCd3', // 레벨3조직코드
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'lvOrgNm3', // 레벨3조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDealcoCd', // 입출고거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutDealcoNm', // 입출고거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inoutShopCd', // 입출고거래처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd', // 채널코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoCd', // 매입처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsDealcoNm', // 매입처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchsShopCd', // 매입처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactCd', // 제조사코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm', // 제조사명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd', // 상품구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm', // 상품구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClCd', // 단말기구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comMthdCd', // 통신방식코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'comMthdNm', // 통신방식명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 상품코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', // 색상코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum', // 일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'unitPrc', // 단가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'inoutQty', // 입출고수량
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'inoutDt',
            fieldName: 'inoutDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입출고일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'inoutClNm',
            fieldName: 'inoutClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입출고구분',
        },
        {
            name: 'inoutDtlClNm',
            fieldName: 'inoutDtlClNm',
            styles: {
                textAlignment: 'center',
            },
            header: '입출고상세구분',
        },
        {
            name: 'saleDt',
            fieldName: 'saleDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'saleBfYn',
            fieldName: 'saleBfYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전월/당월',
        },
        {
            name: 'saleExpartYn',
            fieldName: 'saleExpartYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '교품여부',
        },
        {
            name: 'gnrlSaleNo',
            fieldName: 'gnrlSaleNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공기기여부',
        },
        // {
        //     name: 'orgCd',
        //     fieldName: 'orgCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '조직',
        // },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'inoutDealcoCd',
            fieldName: 'inoutDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입출고처코드',
        },
        {
            name: 'inoutDealcoNm',
            fieldName: 'inoutDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입출고처',
        },

        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '채널코드',
        },
        {
            name: 'prchsDealcoCd',
            fieldName: 'prchsDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처코드',
        },
        {
            name: 'prchsDealcoNm',
            fieldName: 'prchsDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '매입처명',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '제조사',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상품구분',
        },
        // {
        //     name: 'eqpClCd',
        //     fieldName: 'eqpClCd',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: '단말기구분',
        // },
        {
            name: 'comMthdNm',
            fieldName: 'comMthdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '통신방식',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            width: '150',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '색상',
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '일련번호',
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,###,###,##0',
            header: '단가',
        },
    ],
    layout: [
        'NO',
        'inoutDt',
        'inoutClNm',
        'inoutDtlClNm',
        {
            name: '판매상세정보',
            direction: 'horizontal',
            items: ['saleDt', 'saleBfYn', 'saleExpartYn', 'gnrlSaleNo'],
        },
        // 'orgCd',
        'orgNm',
        'inoutDealcoCd',
        'inoutDealcoNm',
        'sktChnlCd',
        'prchsDealcoCd',
        'prchsDealcoNm',
        'mfactNm',
        'prodClNm',
        // 'eqpClCd',
        'comMthdNm',
        'prodNm',
        'colorNm',
        'serNum',
        'unitPrc',
    ],
}
