<!-----------------------------------------------
 * 업무그룹명: Paging 컴포넌트
 * 서브업무명: Paging 공통함수
 * 설명: Paging 컴포넌트및 공통함수 
 * 작성자: 최고운
 * 작성일: 2022.04.26
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div ref="paging">
        <div class="wpagingWrap" v-if="isPagingList">
            <TCComComboBox
                labelName=""
                :itemList="pagingList"
                class="wpagingCont"
                v-model="rowcntStr"
                @change="chgPagingList"
            />
        </div>
        <div class="pagingWrap">
            <ul>
                <li>
                    <TCComButton
                        :Vuetify="false"
                        eClass="arrow first"
                        :disabled="disabled"
                        @click="emitFirstClick"
                    >
                        <span class="blind">맨앞</span>
                    </TCComButton>
                </li>
                <li>
                    <TCComButton
                        :Vuetify="false"
                        eClass="arrow prev"
                        :disabled="disabled"
                        @click="emitPrevClick"
                    >
                        <span class="blind">이전</span>
                    </TCComButton>
                </li>
                <li v-for="n in listData" :key="n">
                    <a
                        @click="emitClick(n)"
                        :class="{ active: activePage == n }"
                    >
                        {{ n }}
                    </a>
                </li>
                <li>
                    <TCComButton
                        :Vuetify="false"
                        eClass="arrow next"
                        :disabled="disabled"
                        @click="emitNextClick"
                    >
                        <span class="blind">다음</span>
                    </TCComButton>
                </li>
                <li>
                    <TCComButton
                        :Vuetify="false"
                        eClass="arrow last"
                        :disabled="disabled"
                        @click="emitLastClick"
                    >
                        <span class="blind">맨끝</span>
                    </TCComButton>
                </li>
            </ul>
        </div>
    </div>
</template>
<style lang="scss" scoped>
// scss source
</style>
<script>
import CommonMixin from '@/mixins'
export default {
    inheritAttrs: false,
    name: 'TCComPaging',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 페이지 수
        totalPage: { type: Number, default: 0, required: true },
        //disabled
        disabled: { type: Boolean, default: false, required: false },
        // API호출
        apiFunc: { type: Function, required: false },
        // Grid Object
        gridObj: { type: Object, required: false },
        // 페이지 표시되는 행의 수
        rowCnt: { type: Number, default: 15, required: false },
        //페이지영역 행의 콤보박스
        isPagingList: { type: Boolean, default: true, required: false },
        //표시되는 페이지 수
        limitPage: { type: Number, default: 10, required: false },
    },
    data() {
        return {
            activePage: 1,
            sIndex: 1,
            eIndex: this.limitPage,
            listData: [],
            dRowCnt: this.rowCnt,
            pagingList: [
                {
                    commCdVal: '15',
                    commCdValNm: '15',
                },
                {
                    commCdVal: '30',
                    commCdValNm: '30',
                },
                {
                    commCdVal: '50',
                    commCdValNm: '50',
                },
                {
                    commCdVal: '100',
                    commCdValNm: '100',
                },
                {
                    commCdVal: '200',
                    commCdValNm: '200',
                },
            ],
        }
    },
    computed: {
        // limitPage() {
        //     let pageCnt = this.limitPage
        //     if (this.limitPage > this.totalPage) pageCnt = this.totalPage
        //     return pageCnt
        // },
        rowcntStr: {
            get() {
                return String(this.dRowCnt)
            },
            set(val) {
                return val
            },
        },
    },
    // props 동적 제어
    watch: {
        totalPage: function () {
            this.activePage = 1
            this.sIndex = this.activePage
            this.eIndex =
                this.totalPage > this.limitPage
                    ? this.limitPage
                    : this.totalPage
            this.listData = []
            for (let i = this.sIndex; i <= this.eIndex; i++) {
                this.listData.push(i)
            }
        },
        dRowCnt: function () {
            this.$emit('input', parseInt(this.dRowCnt))
        },
    },
    created() {
        this.init()
    },
    mounted() {
        // console.log('paging Height::', this.$refs)
    },
    methods: {
        init() {},
        chgPagingList(value) {
            this.dRowCnt = String(value)
        },
        pageDataSetting() {
            this.listData = []
            for (let i = this.sIndex; i <= this.eIndex; i++) {
                this.listData.push(i)
            }
        },
        //맨앞으로 이동 Event
        emitFirstClick() {
            if (this.activePage == 1) {
                this.getAlert('first')
            } else {
                if (typeof this.apiFunc === 'function') {
                    this.activePage = 1
                    this.sIndex = this.activePage
                    this.eIndex =
                        this.totalPage > this.limitPage
                            ? this.limitPage
                            : this.totalPage
                    this.pageDataSetting()
                    this.apiFunc(1)
                }
            }
        },
        //이전페이지 이동 Event
        emitPrevClick() {
            if (this.activePage - 1 <= 0) {
                this.getAlert('first')
            } else {
                if (typeof this.apiFunc === 'function') {
                    this.activePage = this.activePage - 1
                    if (this.activePage < this.sIndex) {
                        this.sIndex =
                            (Math.ceil(this.activePage / this.limitPage) - 1) *
                                this.limitPage +
                            1
                        if (this.totalPage != this.eIndex)
                            this.eIndex -= this.limitPage
                        else
                            this.eIndex =
                                this.sIndex + this.limitPage > this.totalPage
                                    ? this.totalPage
                                    : this.sIndex + this.limitPage - 1
                        this.pageDataSetting()
                    }
                    this.apiFunc(this.activePage)
                }
            }
        },
        //다음페이지 이동 Event
        emitNextClick() {
            if (this.activePage + 1 > this.totalPage) {
                this.getAlert('last')
            } else {
                if (typeof this.apiFunc === 'function') {
                    this.activePage = this.activePage + 1
                    if (this.activePage > this.eIndex) {
                        this.sIndex = this.activePage
                        this.eIndex =
                            this.sIndex + this.limitPage > this.totalPage
                                ? this.totalPage
                                : this.sIndex + this.limitPage - 1
                        this.pageDataSetting()
                    }
                    this.apiFunc(this.activePage)
                }
            }
        },
        //마지막페이지 이동 Event
        emitLastClick() {
            if (this.activePage == this.totalPage || this.totalPage == 0) {
                this.getAlert('last')
            } else {
                if (typeof this.apiFunc === 'function') {
                    this.activePage = this.totalPage
                    if (this.totalPage != this.eIndex) {
                        this.sIndex =
                            (Math.ceil(this.activePage / this.limitPage) - 1) *
                                this.limitPage +
                            1
                        this.eIndex = this.totalPage
                        this.pageDataSetting()
                    }
                    this.apiFunc(this.totalPage)
                }
            }
        },
        //페이지 이동 Event
        emitClick(page) {
            if (typeof this.apiFunc === 'function') {
                this.activePage = page
                this.apiFunc(page)
            }
        },
        getAlert(typ) {
            let msg = ''
            if (typ == 'last') msg = '현재 마지막 페이지 입니다.'
            else if (typ == 'first') msg = '현재 첫번째 페이지 입니다.'

            this.showTcComAlert(msg, {
                header: '페이지이동',
                size: '500',
                confirmLabel: 'OK',
            })
        },
    },
}
</script>
