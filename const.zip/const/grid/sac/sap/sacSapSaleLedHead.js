import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arSeq', // 매출순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDtm', // 판매일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wrtDt', // 전기일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'evdDt', // 증빙일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dueDt', // 납부기한일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trClCd', // 거래구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trClNm', // 거래구분코드명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleClCd', // 판매구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleClNm', // 판매구분코드명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arClCd', // 매출구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'arClNm', // 매출구분코드명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlCd', // 영업채널코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleChnlNm', // 영업채널명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', // 서브점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyNm', // 서브점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'subStoreCd', // 종사업장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'secCd', // 사업장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleShopCd', // 판매처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd', // 판매처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoNm', // 판매처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accShopCd', // 정산처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoCd', // 정산처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealcoNm', // 정산처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // 단말기모델코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 단말기모델명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleQty', // 판매수량
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleAmt', // 판매금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prcrdPrc', // 여신매입금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'prchsCostPrc', // 현금매입금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'taxClCd', // 과세구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxClNm', // 과세구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'splyPrc', // 공급가격
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'ccId', // 코스트센터ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ccNm', // 코스트센터명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcMgmtNum', // 서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBilId', // 세금계산서발행ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBilSeq', // 세금계산서발행순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxCfmId', // 세금계산서승인ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxAprvDtm', // 세금계산서승인일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBilStNm', // 세금계산서상태코드명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTaxCfmIf', // 원세금계산서승인ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgTaxAprvDtm', // 원세금계산서승인일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'setoffBamt', // 미결금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'erpTrmsId', // ERP전송ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsDtm', // ERP전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpFixDtm', // ERP확정일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsId1', // ERP전송ID1 // ERP 추정 역분개?
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsDtm1', // ERP전송일시1
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpFixDtm1', // ERP확정일시 << ????
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsId2', // ERP전송ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsDtm2', // ERP전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpFixDtm2', // ERP확정일시 << ???
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsId3', // ERP전송ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpTrmsDtm3', // ERP전송일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'erpFixDtm3', // ERP확정일시 << ???
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refId', // 참고ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'refSeq', // 참고순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgRefId', // 원참고ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgRefSeq', // 원참고순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'hitPgmId', // 발생PGM ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 매출조정절차비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm', //입력일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm', // 입력처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 수정일시
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm', // 수정처리자명
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'saleDtm',
            fieldName: 'saleDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매일시',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            // textFormat:
            //     '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'wrtDt',
            fieldName: 'wrtDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전기일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'evdDt',
            fieldName: 'evdDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '증빙일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'dueDt',
            fieldName: 'dueDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '납부기한',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'trClCd',
            fieldName: 'trClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드',
        },
        {
            name: 'trClNm',
            fieldName: 'trClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드명',
        },
        {
            name: 'saleClCd',
            fieldName: 'saleClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드',
        },
        {
            name: 'saleClNm',
            fieldName: 'saleClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드명',
        },
        {
            name: 'arClCd',
            fieldName: 'arClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드',
        },
        {
            name: 'arClNm',
            fieldName: 'arClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드명',
        },
        {
            name: 'saleChnlCd',
            fieldName: 'saleChnlCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드',
        },
        {
            name: 'saleChnlNm',
            fieldName: 'saleChnlNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코드명',
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '대리점코드',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '서브점코드',
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '서브점명',
        },
        {
            name: 'subStoreCd',
            fieldName: 'subStoreCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '종사업장번호',
        },
        {
            name: 'secCd',
            fieldName: 'secCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '사업장코드',
        },
        {
            name: 'saleShopCd',
            fieldName: 'saleShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처매장코드',
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처',
        },
        {
            name: 'saleDealcoNm',
            fieldName: 'saleDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매처명',
        },
        {
            name: 'accShopCd',
            fieldName: 'accShopCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처매장코드',
        },
        {
            name: 'accDealcoCd',
            fieldName: 'accDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처',
        },
        {
            name: 'accDealcoNm',
            fieldName: 'accDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '정산처명',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델ID',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '모델명',
        },
        {
            name: 'saleQty',
            fieldName: 'saleQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매수량',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'saleAmt',
            fieldName: 'saleAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '판매금액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'prcrdPrc',
            fieldName: 'prcrdPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '여신매입금액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'prchsCostPrc',
            fieldName: 'prchsCostPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '현금매입금액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'taxClCd',
            fieldName: 'taxClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '과세구분코드',
        },
        {
            name: 'taxClNm',
            fieldName: 'taxClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '과세구분명',
        },
        {
            name: 'splyPrc',
            fieldName: 'splyPrc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '공급가액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '부가세액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'ccId',
            fieldName: 'ccId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '코스트센터ID',
        },
        {
            name: 'ccNm',
            fieldName: 'ccNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '코스트센터명',
        },
        {
            name: 'svcMgmtNum',
            fieldName: 'svcMgmtNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '서비스관리번호',
        },
        {
            name: 'taxBilId',
            fieldName: 'taxBilId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발행ID',
        },
        {
            name: 'taxBilSeq',
            fieldName: 'taxBilSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발행순번',
        },
        {
            name: 'taxCfmId',
            fieldName: 'taxCfmId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '승인ID',
        },
        {
            name: 'taxAprvDtm',
            fieldName: 'taxAprvDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '승인일시',
        },
        {
            name: 'taxBilStNm',
            fieldName: 'taxBilStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '상태코드명',
        },
        {
            name: 'orgTaxCfmIf',
            fieldName: 'orgTaxCfmIf',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '승인ID',
        },
        {
            name: 'orgTaxAprvDtm',
            fieldName: 'orgTaxAprvDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '승인일시',
        },
        {
            name: 'setoffBamt',
            fieldName: 'setoffBamt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '미결금액',
            numberFormat: '#,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'erpTrmsId',
            fieldName: 'erpTrmsId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송ID',
        },
        {
            name: 'erpTrmsDtm',
            fieldName: 'erpTrmsDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
        },
        {
            name: 'erpFixDtm',
            fieldName: 'erpFixDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '확정일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'erpTrmsId1',
            fieldName: 'erpTrmsId1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송ID',
        },
        {
            name: 'erpTrmsDtm1',
            fieldName: 'erpTrmsDtm1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
        },
        {
            name: 'erpFixDtm1',
            fieldName: 'erpFixDtm1',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '확정일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'erpTrmsId2',
            fieldName: 'erpTrmsId2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송ID',
        },
        {
            name: 'erpTrmsDtm2',
            fieldName: 'erpTrmsDtm2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
        },
        {
            name: 'erpFixDtm2',
            fieldName: 'erpFixDtm2',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '확정일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'erpTrmsId3',
            fieldName: 'erpTrmsId3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송ID',
        },
        {
            name: 'erpTrmsDtm3',
            fieldName: 'erpTrmsDtm3',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송일시',
        },
        {
            name: 'erpFixDtm3',
            fieldName: 'erpFixDtm3',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '확정일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'refId',
            fieldName: 'refId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '참고ID',
        },
        {
            name: 'refSeq',
            fieldName: 'refSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '참고순번',
        },
        {
            name: 'orgRefId',
            fieldName: 'orgRefId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '원참고ID',
        },
        {
            name: 'orgRefSeq',
            fieldName: 'orgRefSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '원참고순번',
        },
        {
            name: 'hitPgmId',
            fieldName: 'hitPgmId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '발생PGM ID',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            width: '600',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '최초처리일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '최초처리자',
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: '변경처리일시',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '변경처리자',
        },
    ],
    layout: [
        'NO',
        'saleDtm',
        'wrtDt',
        'evdDt',
        'dueDt',
        {
            name: '거래구분',
            direction: 'horizontal',
            items: ['trClCd', 'trClNm'],
        },
        {
            name: '판매구분',
            direction: 'horizontal',
            items: ['saleClCd', 'saleClNm'],
        },
        {
            name: '매출구분',
            direction: 'horizontal',
            items: ['arClCd', 'arClNm'],
        },
        {
            name: '영업채널',
            direction: 'horizontal',
            items: ['saleChnlCd', 'saleChnlNm'],
        },
        'sktAgencyCd',
        'sktSubCd',
        'sktAgencyNm',
        //'subStoreCd',
        //'secCd',
        'saleShopCd',
        'saleDealcoCd',
        'saleDealcoNm',
        'accShopCd',
        'accDealcoCd',
        'accDealcoNm',
        'prodCd',
        'prodNm',
        'saleQty',
        'saleAmt',
        'prcrdPrc',
        'prchsCostPrc',
        'taxClCd',
        'taxClNm',
        'splyPrc',
        'vatAmt',
        //'ccId',
        //'ccNm',
        'svcMgmtNum',
        {
            name: '세금계산서',
            direction: 'horizontal',
            items: [
                'taxBilId',
                'taxBilSeq',
                'taxCfmId',
                'taxAprvDtm',
                'taxBilStNm',
            ],
        },
        {
            name: '원세금계산서',
            direction: 'horizontal',
            items: ['orgTaxCfmIf', 'orgTaxAprvDtm'],
        },
        'setoffBamt',
        {
            name: 'ERP',
            direction: 'horizontal',
            items: ['erpTrmsId', 'erpTrmsDtm', 'erpFixDtm'],
        },
        // {
        //     name: 'ERP 추정 역분개',
        //     direction: 'horizontal',
        //     items: ['erpTrmsId1', 'erpTrmsDtm1', 'erpFixDtm1'],
        // },
        {
            name: 'ERP 확정',
            direction: 'horizontal',
            items: ['erpTrmsId2', 'erpTrmsDtm2', 'erpFixDtm2'],
        },
        // {
        //     name: 'ERP 확정 역분개',
        //     direction: 'horizontal',
        //     items: ['erpTrmsId3', 'erpTrmsDtm3', 'erpFixDtm3'],
        // },
        'refId',
        'refSeq',
        'orgRefId',
        'orgRefSeq',
        'hitPgmId',
        'rmks',
        {
            name: '처리자 정보',
            direction: 'horizontal',
            items: ['insDtm', 'insUserNm', 'modDtm', 'modUserNm'],
        },
    ],
}
