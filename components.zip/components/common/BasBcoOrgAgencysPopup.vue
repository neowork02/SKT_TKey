<!-----------------------------------------------
 * 업무그룹명: 기준정보>조직별대리점검색
 * 서브업무명: 조직별대리점검색
 * 설명: 조직별대리점검색 Popup 컴포넌트
 * 작성자: 김태훈
 * 작성일: 2022.05.04
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpenOrgAgency" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">조직별대리점검색 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="searchOrgAgencyParam.orgNm"
                                    :codeVal.sync="searchOrgAgencyParam.orgCd"
                                    labelName="조직"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    :disabled="isDisabledOrgCd"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :eRequired="true"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            -->
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="searchOrgAgencyParam.agencyCd"
                                    labelName="대리점코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <!-- //item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="searchOrgAgencyParam.agencyNm"
                                    labelName="대리점명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                ></TCComInput>
                            </div>
                            <!-- //item 1-3-->
                        </div>
                        <!-- // Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div2">
                                <TCComDatePicker
                                    v-model="
                                        searchOrgAgencyParam.searchDateModel
                                    "
                                    labelName="조회기준일"
                                    :objAuth="objAuth"
                                ></TCComDatePicker>
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 
                            <div class="formitem div2"></div>
                            -->
                            <!-- //item 2-2 -->
                            <!-- item 2-4 -->
                            <div class="formitem div2">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                            =
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- // Search_line 2 -->
                    </div>
                    <div class="contBoth">
                        <!-- SubTit -->
                        <div class="stitHead pop">
                            <h4 class="subTit">대리점 목록</h4>
                        </div>
                        <!-- // SubTit -->

                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="orgAgencyGrid"
                                ref="orgAgencyGrid"
                                :editable="true"
                                :fields="header.fields"
                                :columns="header.columns"
                                @hook:mounted="gridMounted"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { BAS_BCO_ORG_AGENCYS_HEADER } from '@/const/grid/bas/bco/basBcoOrgAgencysHeader'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
import commonApi from '@/api/common/commonCode'
import moment from 'moment'
import CommonMixin from '@/mixins'

import _ from 'lodash'

//====================내부조직팝업(권한)팝업====================
//import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================

export default {
    name: 'BasBcoOrgAgencysPopup',
    mixins: [CommonMixin],
    components: {
        //BasBcoAuthOrgTreesPopup,
    },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            gridObj: {},
            objAuth: {},
            header: BAS_BCO_ORG_AGENCYS_HEADER,
            // showAlertBool: false,
            //alertBodyText: '',
            headerText: '',
            searchOrgAgencyParam: {
                //agencyRgstCl: '', // 대리점등록구분
                //agencyTyp: '', // 대리점유형
                //agencyPtn: '', // 대리점구분코드
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
                searchDateModel: '', // 조회기준일(v-model)
                searchDate: '', // 조회기준일
                orgLvl: '', //레벨
                orgCd: '', //조직코드
            },
            //====================대리점팝업관련====================
            showBcoAgencys: false, // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
            searchParam: {
                //내부조직팝업(권한)팝업관련
                basMth: '', //예)202202, 2022-02 null이면 부모창현재월셋팅
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                orgLvl: '', // 디스플레이제한레벨
                sLvlList: '', //선택가능레벨 '2,3' : as-is 와동일하게 쉼표로 나열
                all: 'Y', //전체검색여부 Y or null , N..
            },
            resultAgencyRows: [], // 대리점 팝업 오픈 여부

            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부

            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            isDisabledOrgCd: false,
        }
    },
    computed: {
        activeOpenOrgAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchOrgAgencyParam.orgCd =
                    value['orgCd'] == undefined ? '' : value['orgCd'] // 대리점등록구분
                this.searchOrgAgencyParam.orgNm =
                    value['orgNm'] == undefined ? '' : value['orgNm'] // 대리점유형
                this.searchOrgAgencyParam.agencyCd =
                    value['agencyCd'] == undefined ? '' : value['agencyCd'] // 대리점코드
                this.searchOrgAgencyParam.agencyNm =
                    value['agencyNm'] == undefined ? '' : value['agencyNm'] //대리점명
                this.searchOrgAgencyParam.searchDateModel =
                    value['searchDate'] == undefined ? '' : value['searchDate'] // 조회기준일
                this.searchOrgAgencyParam.orgLvl =
                    value['orgLvl'] == undefined ? '' : value['orgLvl'] //레벨
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    created() {
        this.init()
    },
    async mounted() {
        this.gridObj = this.$refs.orgAgencyGrid // Grid Object 설정
        this.initGrid()
        //컬럼전체채우기
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
    },
    methods: {
        async init() {
            this.gridData = this.gridSetData()
            if (_.isEmpty(this.searchOrgAgencyParam.searchDateModel)) {
                this.searchOrgAgencyParam.searchDateModel =
                    moment().format('YYYY-MM-DD')
            }

            if (this.rows.length > 0) {
                var iOrgLvl = this.searchOrgAgencyParam.orgLvl
                if (typeof this.searchOrgAgencyParam.orgLvl == 'number') {
                    iOrgLvl = Number(typeof this.searchOrgAgencyParam.orgLvl)
                }

                if (iOrgLvl >= 2) {
                    if (!_.isEmpty(this.searchOrgAgencyParam.orgCd)) {
                        this.isDisabledOrgCd = true
                    }
                }
            }
        },
        //GridSetData
        gridSetData() {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10, '', '')
        },
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.setGridState(false, false, false)
            const commAgencyPtn = await this.getCommCodeList('AGENCY_PTN')
            const commAgencyTyp = await this.getCommCodeList('AGENCY_TYP')

            // 대리점 구분 lOV
            this.gridObj.gridView.columnByName('agencyClCd').values =
                CommonUtil.convListToGridLovValues(commAgencyPtn, 'commCdVal')
            this.gridObj.gridView.columnByName('agencyClCd').labels =
                CommonUtil.convListToGridLovLabels(commAgencyPtn, 'commCdValNm')
            // 대리점 유형 lOV
            this.gridObj.gridView.columnByName('agencyTypCd').values =
                CommonUtil.convListToGridLovValues(commAgencyTyp, 'commCdVal')
            this.gridObj.gridView.columnByName('agencyTypCd').labels =
                CommonUtil.convListToGridLovLabels(commAgencyTyp, 'commCdValNm')

            //this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }
        },

        gridMounted() {
            console.log('gridMounted')
        },

        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        getOrgAgencyList() {
            this.searchOrgAgencyParam.searchDate = CommonUtil.replaceDash(
                this.searchOrgAgencyParam.searchDateModel
            )
            basBcoOrgAgencysApi
                .getOrgAgencyList(this.searchOrgAgencyParam)
                .then((res) => {
                    console.log('getOrgAgencyList then : ', res)
                    this.gridObj.setRows(res)
                })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('대리점을 선택해주세요.', {
                    header: '대리점 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpenOrgAgency = false
        },

        onSearch() {
            /*
            if (_.isEmpty(this.searchOrgAgencyParam.orgCd)) {
                this.showTcComAlert('조직을 선택해주세요.', {
                    header: '조직 선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            */
            this.getOrgAgencyList()
        },

        onEnterKey() {
            this.onSearch()
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        setAuthOrgTreeListParam() {
            this.searchParam.orgNm = this.searchOrgAgencyParam.orgNm
            //기준년월에 따라 조직파라미터변경
            this.searchParam.basMth = CommonUtil.replaceDash(
                this.searchOrgAgencyParam.searchDateModel
            )
            if (this.searchParam.basMth.length > 6) {
                this.searchParam.basMth = this.searchParam.basMth.substring(
                    0,
                    6
                )
            }
        },
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchOrgAgencyParam.basMth = _.get(
                            res[0],
                            'basMth'
                        )
                        this.searchOrgAgencyParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchOrgAgencyParam.orgNm = _.get(res[0], 'orgNm')
                        this.searchOrgAgencyParam.orgLvl = _.get(
                            res[0],
                            'orgLvl'
                        )
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            this.setAuthOrgTreeListParam()
            if (!_.isEmpty(this.searchParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchOrgAgencyParam.orgNm)) {
                this.showTcComAlert('조직을 선택해주세요.', {
                    //header: '내부거래처',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.setAuthOrgTreeListParam()
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchOrgAgencyParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchOrgAgencyParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchOrgAgencyParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchOrgAgencyParam.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
    },
}
</script>
