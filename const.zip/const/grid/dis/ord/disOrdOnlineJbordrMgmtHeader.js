import { ValueType } from 'realgrid'

export const GRID_LAYOUT1 = [
    'NO',
    'brwsClNm',
    'ordRcvDtm',
    'ordId',
    'pickSlipNo',
    'spSalBrNm',
    'waybillNo',
    'svcClNm',
    'salePlcNm',
    'outPlcNm',
    'dlvClNm',
    'shipStNm',
    'dlvCoNm',
    'ordProdStNm',
    'eqpExpartTypNm',
    'ordSpmallNm',
    'ordProdTypCd',
    'eqpInfo',
    {
        name: '단말기/일반',
        direction: 'horizontal',
        items: [
            'gnrlScanStNm',
            'gnrlProdCd',
            'gnrlProdNm',
            'gnrlColorCd',
            'gnrlColorNm',
            'gnrlQty',
            'gnrlSerNum',
            'gnrlBoxNum1',
            'gnrlBoxNum2',
        ],
    },
    {
        name: 'USIM',
        direction: 'horizontal',
        items: [
            'usimScanStNm',
            'usimProdCd',
            'usimProdNm',
            'usimSerNum',
            'usimBoxNum1',
            'usimBoxNum2',
        ],
    },
    {
        name: 'T.gift',
        direction: 'horizontal',
        items: [
            'tgiftScanStNm',
            'tgiftProdCd',
            'tgiftProdNm',
            'tgiftSerNum',
            'tgiftBoxNum1',
            'tgiftBoxNum2',
        ],
    },
    {
        name: 'Accessory',
        direction: 'horizontal',
        items: [
            'accsScanStNm',
            'accsProdCd',
            'accsProdNm',
            'accsSerNum',
            'accsBoxNum1',
            'accsBoxNum2',
        ],
    },
    {
        name: '스마트홈(소품)',
        direction: 'horizontal',
        items: [
            'smartHomeScanStNm',
            'smartHomeProdCd',
            'smartHomeProdNm',
            'smartHomeSerNum',
            'smartHomeBoxNum1',
            'smartHomeBoxNum2',
        ],
    },
    'pkgNo',
]

export const GRID_LAYOUT2 = [
    'NO',
    'brwsClNm',
    'ordRcvDtm',
    'ordId',
    'pickSlipNo',
    'spSalBrNm',
    'waybillNo',
    'svcClNm',
    'salePlcNm',
    'outPlcNm',
    'dlvClNm',
    'shipStNm',
    'dlvCoNm',
    'ordProdStNm',
    'ordSpmallNm',
    'ordProdTypCd',
    {
        name: '단말기/일반',
        direction: 'horizontal',
        items: [
            'gnrlScanStNm',
            'gnrlProdCd',
            'gnrlProdNm',
            'gnrlColorCd',
            'gnrlColorNm',
            'gnrlQty',
            'gnrlSerNum',
            'gnrlBoxNum1',
            'gnrlBoxNum2',
        ],
    },
    {
        name: 'USIM',
        direction: 'horizontal',
        items: [
            'usimScanStNm',
            'usimProdCd',
            'usimProdNm',
            'usimSerNum',
            'usimBoxNum1',
            'usimBoxNum2',
        ],
    },
    'pkgNo',
]

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'brwsClNm',
            dataType: ValueType.TEXT, // 조회구분명
        },
        {
            fieldName: 'ordRcvDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 주문접수일시
        },
        {
            fieldName: 'ordId',
            dataType: ValueType.TEXT, // 주문번호
        },
        {
            fieldName: 'pickSlipNo',
            dataType: ValueType.TEXT, // 작업지시번호
        },
        {
            fieldName: 'spSalBrNm',
            dataType: ValueType.TEXT, // 특판처명
        },
        {
            fieldName: 'waybillNo',
            dataType: ValueType.TEXT, // 송장번호
        },
        {
            fieldName: 'svcClCd',
            dataType: ValueType.TEXT, // 개통구분코드
        },
        {
            fieldName: 'svcClNm',
            dataType: ValueType.TEXT, // 개통구분명
        },
        {
            fieldName: 'salePlcNm',
            dataType: ValueType.TEXT, // 판매처명
        },
        {
            fieldName: 'outPlcNm',
            dataType: ValueType.TEXT, // 출고처명
        },
        {
            fieldName: 'dlvClNm',
            dataType: ValueType.TEXT, // 배송구분명
        },
        {
            fieldName: 'shipStCd',
            dataType: ValueType.TEXT, // 배송상태코드
        },
        {
            fieldName: 'shipStNm',
            dataType: ValueType.TEXT, // 배송상태명
        },
        {
            fieldName: 'dlvCoNm',
            dataType: ValueType.TEXT, // 배송사명
        },
        {
            fieldName: 'ordProdStNm',
            dataType: ValueType.TEXT, // 주문진행상태명
        },
        {
            fieldName: 'eqpExpartTypNm',
            dataType: ValueType.TEXT, // 단말기교품유형명
        },
        {
            fieldName: 'ordSpmallNm',
            dataType: ValueType.TEXT, // 주문쇼핑몰명
        },
        {
            fieldName: 'ordProdTypCd',
            dataType: ValueType.TEXT, // 주문상품유형코드
        },
        {
            fieldName: 'eqpInfo',
            dataType: ValueType.TEXT, // 단말기정보
        },
        {
            fieldName: 'gnrlScanStCd',
            dataType: ValueType.TEXT, // 일반스캔상태코드
        },
        {
            fieldName: 'gnrlScanStNm',
            dataType: ValueType.TEXT, // 일반스캔상태명
        },
        {
            fieldName: 'gnrlProdCd',
            dataType: ValueType.TEXT, // 일반상품코드
        },
        {
            fieldName: 'gnrlProdNm',
            dataType: ValueType.TEXT, // 일반상품명
        },
        {
            fieldName: 'gnrlColorCd',
            dataType: ValueType.TEXT, // 일반색상코드
        },
        {
            fieldName: 'gnrlColorNm',
            dataType: ValueType.TEXT, // 일반색상명
        },
        {
            fieldName: 'gnrlQty',
            dataType: ValueType.NUMBER, // 일반수량
        },
        {
            fieldName: 'gnrlSerNum',
            dataType: ValueType.TEXT, // 일반일련번호
        },
        {
            fieldName: 'gnrlBoxNum1',
            dataType: ValueType.TEXT, // 일반BOX번호1
        },
        {
            fieldName: 'gnrlBoxNum2',
            dataType: ValueType.TEXT, // 일반BOX번호2
        },
        {
            fieldName: 'usimScanStCd',
            dataType: ValueType.TEXT, // USIM스캔상태코드
        },
        {
            fieldName: 'usimScanStNm',
            dataType: ValueType.TEXT, // USIM스캔상태명
        },
        {
            fieldName: 'usimProdCd',
            dataType: ValueType.TEXT, // USIM상품코드
        },
        {
            fieldName: 'usimProdNm',
            dataType: ValueType.TEXT, // USIM상품명
        },
        {
            fieldName: 'usimSerNum',
            dataType: ValueType.TEXT, // USIM일련번호
        },
        {
            fieldName: 'usimBoxNum1',
            dataType: ValueType.TEXT, // USIMBOX번호1
        },
        {
            fieldName: 'usimBoxNum2',
            dataType: ValueType.TEXT, // USIMBOX번호2
        },
        {
            fieldName: 'tgiftScanStCd',
            dataType: ValueType.TEXT, // T.gift스캔상태코드
        },
        {
            fieldName: 'tgiftScanStNm',
            dataType: ValueType.TEXT, // T.gift스캔상태명
        },
        {
            fieldName: 'tgiftProdCd',
            dataType: ValueType.TEXT, // T.gift상품코드
        },
        {
            fieldName: 'tgiftProdNm',
            dataType: ValueType.TEXT, // T.gift상품명
        },
        {
            fieldName: 'tgiftSerNum',
            dataType: ValueType.TEXT, // T.gift일련번호
        },
        {
            fieldName: 'tgiftBoxNum1',
            dataType: ValueType.TEXT, // T.giftBOX번호1
        },
        {
            fieldName: 'tgiftBoxNum2',
            dataType: ValueType.TEXT, // T.giftBOX번호2
        },
        {
            fieldName: 'accsScanStCd',
            dataType: ValueType.TEXT, // 액세서리스캔상태코드
        },
        {
            fieldName: 'accsScanStNm',
            dataType: ValueType.TEXT, // 액세서리스캔상태명
        },
        {
            fieldName: 'accsProdCd',
            dataType: ValueType.TEXT, // 액세서리상품코드
        },
        {
            fieldName: 'accsProdNm',
            dataType: ValueType.TEXT, // 액세서리상품명
        },
        {
            fieldName: 'accsSerNum',
            dataType: ValueType.TEXT, // 액세서리일련번호
        },
        {
            fieldName: 'accsBoxNum1',
            dataType: ValueType.TEXT, // 액세서리BOX번호1
        },
        {
            fieldName: 'accsBoxNum2',
            dataType: ValueType.TEXT, // 액세서리BOX번호2
        },
        {
            fieldName: 'smartHomeScanStCd',
            dataType: ValueType.TEXT, // 스마트홈스캔상태코드
        },
        {
            fieldName: 'smartHomeScanStNm',
            dataType: ValueType.TEXT, // 스마트홈스캔상태명
        },
        {
            fieldName: 'smartHomeProdCd',
            dataType: ValueType.TEXT, // 스마트홈상품코드
        },
        {
            fieldName: 'smartHomeProdNm',
            dataType: ValueType.TEXT, // 스마트홈상품명
        },
        {
            fieldName: 'smartHomeSerNum',
            dataType: ValueType.TEXT, // 스마트홈일련번호
        },
        {
            fieldName: 'smartHomeBoxNum1',
            dataType: ValueType.TEXT, // 스마트홈BOX번호1
        },
        {
            fieldName: 'smartHomeBoxNum2',
            dataType: ValueType.TEXT, // 스마트홈BOX번호2
        },
        {
            fieldName: 'pkgNo',
            dataType: ValueType.TEXT, // 패키지번호
        },
        {
            fieldName: 'ordMgmtNo',
            dataType: ValueType.TEXT, // 주문관리번호
        },
    ],
    columns: [
        {
            name: 'brwsClNm',
            fieldName: 'brwsClNm',
            type: 'data',
            width: '60',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '구분',
            },
        },
        {
            name: 'ordRcvDtm',
            fieldName: 'ordRcvDtm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문접수일자',
            },
        },
        {
            name: 'ordId',
            fieldName: 'ordId',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문번호',
            },
        },
        {
            name: 'pickSlipNo',
            fieldName: 'pickSlipNo',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '작업지시번호',
            },
        },
        {
            name: 'spSalBrNm',
            fieldName: 'spSalBrNm',
            type: 'data',
            width: '120',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '특판처',
            },
        },
        {
            name: 'waybillNo',
            fieldName: 'waybillNo',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '송장번호',
            },
        },
        {
            name: 'svcClNm',
            fieldName: 'svcClNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '개통구분',
            },
        },
        {
            name: 'salePlcNm',
            fieldName: 'salePlcNm',
            type: 'data',
            width: '120',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '매출처',
            },
        },
        {
            name: 'outPlcNm',
            fieldName: 'outPlcNm',
            type: 'data',
            width: '120',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '출고처',
            },
        },
        {
            name: 'dlvClNm',
            fieldName: 'dlvClNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '배송구분',
            },
        },
        {
            name: 'shipStNm',
            fieldName: 'shipStNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '배송상태',
            },
        },
        {
            name: 'dlvCoNm',
            fieldName: 'dlvCoNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '배송사',
            },
        },
        {
            name: 'ordProdStNm',
            fieldName: 'ordProdStNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문상태',
            },
        },
        {
            name: 'eqpExpartTypNm',
            fieldName: 'eqpExpartTypNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '단말기교품유형',
            },
        },
        {
            name: 'ordSpmallNm',
            fieldName: 'ordSpmallNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '접수처',
            },
        },
        {
            name: 'ordProdTypCd',
            fieldName: 'ordProdTypCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '상품유형',
            },
        },
        {
            name: 'eqpInfo',
            fieldName: 'eqpInfo',
            type: 'data',
            width: '120',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '단말기 정보',
            },
        },
        {
            name: 'gnrlScanStNm',
            fieldName: 'gnrlScanStNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '스캔상태',
            },
        },
        {
            name: 'gnrlProdCd',
            fieldName: 'gnrlProdCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '상품코드',
            },
        },
        {
            name: 'gnrlProdNm',
            fieldName: 'gnrlProdNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '상품명',
            },
        },
        {
            name: 'gnrlColorCd',
            fieldName: 'gnrlColorCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상코드',
            },
        },
        {
            name: 'gnrlColorNm',
            fieldName: 'gnrlColorNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '색상명',
            },
        },
        {
            name: 'gnrlQty',
            fieldName: 'gnrlQty',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '수량',
            },
        },
        {
            name: 'gnrlSerNum',
            fieldName: 'gnrlSerNum',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'gnrlBoxNum1',
            fieldName: 'gnrlBoxNum1',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX1',
            },
        },
        {
            name: 'gnrlBoxNum2',
            fieldName: 'gnrlBoxNum2',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX2',
            },
        },
        {
            name: 'usimScanStNm',
            fieldName: 'usimScanStNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '스캔상태',
            },
        },
        {
            name: 'usimProdCd',
            fieldName: 'usimProdCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '코드',
            },
        },
        {
            name: 'usimProdNm',
            fieldName: 'usimProdNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '명',
            },
        },
        {
            name: 'usimSerNum',
            fieldName: 'usimSerNum',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'usimBoxNum1',
            fieldName: 'usimBoxNum1',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX1',
            },
        },
        {
            name: 'usimBoxNum2',
            fieldName: 'usimBoxNum2',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX2',
            },
        },
        {
            name: 'tgiftScanStNm',
            fieldName: 'tgiftScanStNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '스캔상태',
            },
        },
        {
            name: 'tgiftProdCd',
            fieldName: 'tgiftProdCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '코드',
            },
        },
        {
            name: 'tgiftProdNm',
            fieldName: 'tgiftProdNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '명',
            },
        },
        {
            name: 'tgiftSerNum',
            fieldName: 'tgiftSerNum',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'tgiftBoxNum1',
            fieldName: 'tgiftBoxNum1',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX1',
            },
        },
        {
            name: 'tgiftBoxNum2',
            fieldName: 'tgiftBoxNum2',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX2',
            },
        },
        {
            name: 'accsScanStNm',
            fieldName: 'accsScanStNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '스캔상태',
            },
        },
        {
            name: 'accsProdCd',
            fieldName: 'accsProdCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '코드',
            },
        },
        {
            name: 'accsProdNm',
            fieldName: 'accsProdNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '명',
            },
        },
        {
            name: 'accsSerNum',
            fieldName: 'accsSerNum',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'accsBoxNum1',
            fieldName: 'accsBoxNum1',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX1',
            },
        },
        {
            name: 'accsBoxNum2',
            fieldName: 'accsBoxNum2',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX2',
            },
        },
        {
            name: 'smartHomeScanStNm',
            fieldName: 'smartHomeScanStNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '스캔상태',
            },
        },
        {
            name: 'smartHomeProdCd',
            fieldName: 'smartHomeProdCd',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '코드',
            },
        },
        {
            name: 'smartHomeProdNm',
            fieldName: 'smartHomeProdNm',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '명',
            },
        },
        {
            name: 'smartHomeSerNum',
            fieldName: 'smartHomeSerNum',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '일련번호',
            },
        },
        {
            name: 'smartHomeBoxNum1',
            fieldName: 'smartHomeBoxNum1',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX1',
            },
        },
        {
            name: 'smartHomeBoxNum2',
            fieldName: 'smartHomeBoxNum2',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: 'BOX2',
            },
        },
        {
            name: 'pkgNo',
            fieldName: 'pkgNo',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '패키지번호',
            },
        },
    ],
}

export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'brwsClNm',
            dataType: ValueType.TEXT, // 조회구분명
        },
        {
            fieldName: 'pickSlipNo',
            dataType: ValueType.TEXT, // 작업지시번호
        },
        {
            fieldName: 'pickDtm',
            dataType: ValueType.DATETIME,
            datetimeFormat: 'yyyyMMdd', // 작업지시일시
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, // 조직명
        },
        {
            fieldName: 'salePlcNm',
            dataType: ValueType.TEXT, // 판매처명
        },
        {
            fieldName: 'outPlcNm',
            dataType: ValueType.TEXT, // 출고처명
        },
        {
            fieldName: 'ordCnt',
            dataType: ValueType.NUMBER, // 주문건수
        },
    ],
    columns: [
        {
            name: 'brwsClNm',
            fieldName: 'brwsClNm',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '구분',
            },
        },
        {
            name: 'pickSlipNo',
            fieldName: 'pickSlipNo',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '작업지시번호',
            },
        },
        {
            name: 'pickDtm',
            fieldName: 'pickDtm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            datetimeFormat: 'yyyy-MM-dd',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '지시일자',
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '200',
            styleName: 'center-column',
            renderer: {
                showTooltip: true,
            },
            header: {
                text: '조직',
            },
        },
        {
            name: 'salePlcNm',
            fieldName: 'salePlcNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '매출처',
            },
        },
        {
            name: 'outPlcNm',
            fieldName: 'outPlcNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '출고처',
            },
        },
        {
            name: 'ordCnt',
            fieldName: 'ordCnt',
            type: 'data',
            width: '80',
            styleName: 'center-column',
            numberFormat: '#,##0',
            renderer: {
                showTooltip: false,
            },
            header: {
                text: '주문수량',
            },
        },
    ],
}
