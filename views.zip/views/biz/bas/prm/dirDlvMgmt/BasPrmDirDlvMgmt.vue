<!-----------------------------------------------
 * 업무그룹명: 기준정보>배송처관리
 * 서브업무명: 배송처관리
 * 설명: 배송처관리 조회/입력/수정/삭제 한다.
 * 작성자: P180291
 * 작성일: 2022.07.26
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <!-- Tit -->
        <h1>배송처관리</h1>
        <!-- // Tit -->
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dirDlvMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/prm/dirDlvMgmt'

export default {
    name: 'BasPrmDirDlvMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (!this.$store.hasModule('bas.prm.dirDlvMgmtStore')) {
            this.$store.registerModule('bas.prm.dirDlvMgmtStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.prm.dirDlvMgmtStore')) {
            this.$store.unregisterModule('bas.prm.dirDlvMgmtStore')
        }
    },

    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>

<style></style>
