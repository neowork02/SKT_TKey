<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">
                    {{ title }}
                </p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComComboBox
                                    labelName="소속유형"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    codeId="ZBAS_C_00380"
                                    :eRequired="true"
                                    v-model="dtlData.attcClCd"
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="권한그룹"
                                    :eRequired="true"
                                    v-model="dtlData.userGrpNm"
                                >
                                </TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="순서"
                                    v-model="dtlData.sortSeq"
                                    inputRuleType="UPEN"
                                    :maxlength="4"
                                >
                                </TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    labelName="설명"
                                    v-model="dtlData.userGrpDesc"
                                >
                                </TCComTextArea>
                            </div>
                        </div>
                        <div class="searchform" v-if="isCopy">
                            <div class="formitem div1">
                                <TCComCheckBox
                                    labelName="복사옵션"
                                    v-model="dtlData.copyOption"
                                    :itemList="[
                                        {
                                            commCdVal: '01',
                                            commCdValNm: '권한설정',
                                        },
                                        {
                                            commCdVal: '02',
                                            commCdValNm: '사용자',
                                        },
                                    ]"
                                >
                                </TCComCheckBox>
                            </div>
                        </div>
                        <div
                            class="searchform"
                            v-if="dtlData.type !== 'create'"
                        >
                            <div class="formitem div1">
                                <span class="itemtit">등록자</span>
                                <span class="iteminput">
                                    {{ insData }}
                                </span>
                            </div>
                        </div>
                        <div
                            class="searchform"
                            v-if="dtlData.type !== 'create'"
                        >
                            <div class="formitem div1">
                                <span class="itemtit">최종수정자</span>
                                <span class="iteminput">
                                    {{ modData }}
                                </span>
                            </div>
                        </div>

                        <!-- //Search_line 1 -->
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="save"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/authMgmt/helpers'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    mixins: [CommonMixin],
    name: 'PopupContainer',
    components: {},

    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: (data) => {
                return data
            },
            required: false,
        },
    },
    data() {
        return {
            showFlag: false,
            title: '그룹 등록,수정,복사 팝업',
            objAuth: {},
            isCopy: true,
            status: 1,
            isReadOnly: false,
            form: {},
            insData: '',
            modData: '',
        }
    },
    async created() {
        await this.initData()
    },
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        this.initData()
        const type = this.dtlData.type

        console.log('this.dtlData.attcClCd -> ', this.dtlData.attcClCd)
        if (_.isEqual(type, 'create')) {
            this.title = '그룹 등록 팝업'
            this.isCopy = false
        } else if (_.isEqual(type, 'update')) {
            this.title = '그룹 수정 팝업'
            this.isCopy = false
        } else if (_.isEqual(type, 'copy')) {
            this.title = '그룹 복사 팝업'
            this.isCopy = true
        }
        if (!_.isEmpty(this.dtlData.insUserId)) {
            this.insData =
                this.dtlData.insUserId +
                '(' +
                this.dtlData.insUserNm +
                ') ' +
                this.dtlData.insDtm
        }
        if (!_.isEmpty(this.dtlData.modUserId)) {
            this.modData =
                this.dtlData.modUserId +
                '(' +
                this.dtlData.modUserNm +
                ') ' +
                this.dtlData.modDtm
        }
    },
    methods: {
        ...serviceMethods,
        open(param) {
            console.log('open-----', param)
        },
        close() {
            this.status = 1
            this.form = {}
            this.showFlag = false
        },
        initData() {
            if (_.isEqual(this.dtlData.type, 'create')) {
                // this.dtlData.attcClCd = ''
                this.dtlData.userGrpNm = ''
                this.dtlData.userGrpDesc = ''
                this.dtlData.sortSeq = ''
                this.defaultAssign_({
                    key: 'params',
                    value: [],
                })
            }
        },
        clear() {},
        setParam() {
            let params = {}
            _.forEach(Object.keys(this.dtlData), (item) => {
                params[item] = this.dtlData[item]
            })

            this.defaultAssign_({
                key: 'params',
                value: params,
            })
        },
        save() {
            if (this.isCopy) {
                if (
                    _.isEmpty(this.dtlData.copyOption) ||
                    this.dtlData.copyOption.length == 0
                ) {
                    this.showTcComAlert('복사옵션을 선택해 주세요')
                    return
                } else {
                    this.setParam()
                    this.copy()
                }
            } else {
                if (_.isEqual(this.dtlData.type, 'create')) {
                    this.setParam()
                    this.insert()
                } else if (_.isEqual(this.dtlData.type, 'update')) {
                    this.setParam()
                    this.update()
                }
            }
            return
        },
        refresh() {
            let paramObj = {}

            if (!_.isEmpty(this.delYn)) {
                paramObj.delYn = 'Y'
            } else {
                paramObj.delYn = 'N'
            }

            this.defaultAssign_({
                key: 'searchParams',
                value: paramObj,
            })

            this.defaultAssign_({
                key: 'resultListAdm',
                value: [],
            })

            this.getBasAdmAuthMgmtList_()
                .then((data) => {
                    console.log(
                        '🚀 ~ file: SearchContent.vue ~ line 272 ~ searchData ~ data',
                        data
                    )
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: SearchContent.vue ~ finally')
                })
        },
        //팝업닫기
        closeBtn: function () {
            this.activeOpen = false
        },
        async update() {
            await this.uptBasAdmAuthMgmt_()
                .then((data) => {
                    if (data !== 1) {
                        this.showTcComAlert('수정실패')
                    } else {
                        this.showTcComAlert('수정완료')
                        this.activeOpen = false
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                    this.refresh()
                })
        },
        async insert() {
            await this.rgstBasAdmAuthMgmt_()
                .then((data) => {
                    console.log('data -> ', data)
                    if (data >= 1) {
                        this.showTcComAlert('등록완료')
                        this.activeOpen = false
                    } else {
                        this.showTcComAlert('등록실패')
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                    this.refresh()
                })
        },
        async copy() {
            await this.copyBasAdmAuthMgmt_()
                .then((data) => {
                    console.log('data -> ', data)
                    if (data !== 1) {
                        this.showTcComAlert('복사실패')
                    } else {
                        this.showTcComAlert('복사완료')
                        this.activeOpen = false
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                    this.refresh()
                })
        },
    },
    watch: {
        dtlData: {
            handler: function (values) {
                console.log('attcClCd ->', values['attcClCd'])
                this.dtlData.attcClCd =
                    values['attcClCd'] === undefined ? '' : values['attcClCd']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
