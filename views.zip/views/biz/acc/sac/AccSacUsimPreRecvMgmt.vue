<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 신품자급 USIM후불예수금 기준관리
 * 설명: 조회, 저장
 * 작성자: P180190
 * 작성일: 2022.08.01
------------------------------------------------>
<template>
    <div class="content">
        <h1>정산 종합 기준관리</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="init()"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    v-show="searchShow"
                    @click="Search"
                    >조회</TCComButton
                >

                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    v-show="onSearchShow"
                    @click="onSearch"
                    >조회</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    v-show="saveShow"
                    @click="save"
                    >저장</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    v-show="onSaveShow"
                    @click="onSave"
                    >저장</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInputSearchText
                        labelName="조직"
                        placeholder="입력해주세요"
                        :eRequired="true"
                        :disabled="false"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick('reqParam')"
                        @input="onAuthOrgTreeInput"
                        :codeVal.sync="reqParam.srchOrgCd"
                        v-model="reqParam.orgNm"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="reqParams"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                    <BasBcoAuthOrgTreesPopupGrid
                        v-if="showBcoAuthOrgTreesGrid"
                        :parentParam="reqParams"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTreesGrid"
                        @confirm="onAuthOrgTreeReturnDataGrid"
                    />
                    <BasBcoAuthOrgTreesPopupGrid1
                        v-if="showBcoAuthOrgTreesGrid1"
                        :parentParam="reqParams"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTreesGrid1"
                        @confirm="onAuthOrgTreeReturnDataGrid1"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.agencyNm"
                        :codeVal.sync="reqParam.agencyCd"
                        v-show="agencyNmShow"
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOrgAgencyEnterKey"
                        @appendIconClick="onOrgAgencyIconClick"
                        @input="onOrgAgencyInput"
                    />
                    <BasBcoOrgAgencysPopup
                        v-if="showBcoOrgAgencys"
                        :parentParam="reqParam"
                        :rows="resultAgencyRows"
                        :dialogShow.sync="showBcoOrgAgencys"
                        @confirm="onOrgAgencyReturnData"
                    />
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="searchForm.dealcoNm"
                        :codeVal.sync="searchForm.dealcoCd"
                        labelName="정산처"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        v-show="false"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPopup
                        v-if="showBasBcoDealco"
                        :parentParam="searchForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealco"
                        @confirm="onDealcoReturnData"
                    />
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCComTab
                :tab.sync="tab.tabSync1"
                :items="['template1', 'template2']"
                :itemName="['조직별 기준관리', '매장별 기준관리']"
                @click="onActiveTabClick"
                sliderSize="8"
            >
                <template #template1>
                    <TCRealGridHeader
                        id="gridHeader"
                        ref="gridHeader"
                        gridTitle="조직별 기준관리"
                        :gridObj="gridObj"
                        :isAddRow="true"
                        :isDelRow="true"
                        :isExceldown="true"
                        @addRowBtn="gridAddRowBtn"
                        @chkDelRowBtn="gridDelRowBtn"
                        @excelDownBtn="downloadUsimExcel"
                    >
                    </TCRealGridHeader>
                    <TCRealGrid
                        id="grid"
                        ref="grid"
                        :fields="view.fields"
                        :columns="view.columns"
                        :styles="gridStyle"
                        :editable="true"
                    />
                </template>
                <template #template2>
                    <TCRealGridHeader
                        id="gridHeader1"
                        ref="gridHeader1"
                        gridTitle="매장별 기준관리"
                        :gridObj="gridObj1"
                        :isExceldown="true"
                        @excelDownBtn="downloadShopExcel"
                    />
                    <TCRealGrid
                        id="grid1"
                        ref="grid1"
                        :fields="view1.fields"
                        :columns="view1.columns"
                        :editable="true"
                        :updatable="true"
                        :isGridReSize="true"
                        @hook:mounted="tabGridMounted"
                    />
                </template>
            </TCComTab>
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
import { CommonGrid, CommonUtil } from '@/utils'
import { msgTxt } from '@/const/msg.Properties.js'
import usimPreApi from '@/api/biz/acc/sac/AccSacUsimPreRecvMgmt'
import { GRID_HEADER } from '@/const/grid/acc/sac/AccSacUsimPreRecvMgmtGrid'
import { HEADER } from '@/const/grid/acc/sac/accSacSwingAgnDealcoMappMgmtHeader'
import CommonMixin from '@/mixins'
import moment from 'moment'
//====================내부조직팝업(권한)======================================================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import BasBcoAuthOrgTreesPopupGrid from '@/components/common/BasBcoAuthOrgTreesPopup'
import BasBcoAuthOrgTreesPopupGrid1 from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================조직별대리점팝업======================================================
import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
//====================내부거래처(권한조직)==================================================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup' // 내부거래처(권한조직) 팝업
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//=========================================================================================
export default {
    name: 'AccSacUsimPreRecvMgmt',
    title: '정산 종합 기준관리',
    components: {
        BasBcoAuthOrgTreesPopupGrid,
        BasBcoAuthOrgTreesPopupGrid1,
        BasBcoAuthOrgTreesPopup,
        BasBcoOrgAgencysPopup,
        BasBcoDealcosPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            gridData: {},
            //Grid Class init
            view: GRID_HEADER,
            view1: HEADER,

            //Grid
            objAuth: {},
            // gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            gridObj1: {},
            gridHeaderObj1: {},

            //tab
            tab: {
                nowIndex: 0,
                tabSync1: 0,
            },

            // items: ['Template1', 'Template2'],
            // itemName: ['조직별 기준관리', '매장별 기준관리'],

            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            reqParam: {
                srchOrgCd: '', // 조직코드
                srchCoClOrgCd: '', // 조직명
                srchOrgLvl: '', // 조직레벨
                agencyCd: '',
                agencyNm: '',
                basMth: '', //기준일자
                orgLvl: '', //조직level
                orgCdLvl0: '', //레벨0조직코드
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            reqParams: {
                orgNm: '',
            },
            // 행추가 기본 json
            defaultJson: {
                ssupOrgNm: '',
                supOrgNm: '',
                orgCd: '',
                orgNm: '',
                orgTree: '',
                usimPayYn: '',
                aplyStaDt: '',
                aplyEndDt: '',
            },
            // 업데이트 요청 파람
            param: {
                srchCoClOrgCd: '',
                usimPayList: [],
            },
            //요청 파라미터
            searchForms: {
                srchOrgCd: '',
                srchCoClOrgCd: '',
                srchOrgLvl: '',
            },

            //====================내부거래처(권한조직)==========================
            showBasBcoDealco: false,
            searchForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한조직)========================
            getData: '',

            selectDataField: '',

            //행 추가 입력된 데이터 리스트
            gridDatas: [],
            changedDatas: [],

            //기존 그리드 데이터 리스트
            oldGridList: [],

            rowCnt: 15,

            //  내부조직팝업(권한)
            showBcoAuthOrgTrees: false,
            showBcoAuthOrgTreesGrid: false,
            showBcoAuthOrgTreesGrid1: false,
            resultAuthOrgTreeRows: [],
            //  내부조직팝업(권한)

            //row cnt
            gridLastIndex: 0,
            nowGridIndex: 0,
            gridRows: 0,
            newAplyEndDt: '',
            itemIndex: [],
            shopDataRow: '',

            // 선택한 돋보기
            orgTreeClicked: '',

            // 신품자급 USIM후불예수금 기준관리
            //================================================================
            showBcoOrgAgencys: false,
            resultAgencyRows: [],
            //====================내부조직팝업(권한)팝업관련====================
            searchAuthOrgTreeParam: {},

            selectedJsonData: {},

            // 버튼 제어
            agencyNmShow: false,
            searchShow: true,
            saveShow: true,
            onSearchShow: false,
            onSaveShow: false,

            ds_list: [],
        }
    },
    mounted() {
        // 그리드 세팅
        this.gridObj = this.$refs.grid
        this.gridObj.setGridState(false, true, false, false)
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridHeaderObj = this.$refs.gridHeader

        // 조직 기준 tab 숨김처리
        // if (this.orgInfo.orgCd != 'O00000') {
        //     this.items = ['Template1']
        //     this.itemName = ['조직별 기준관리']
        // }

        //상위공통코드 그리드 클릭이벤트
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            if (
                grid._dataProvider.getRowState(clickData.dataRow) ==
                    'created' &&
                clickData.cellType == 'data'
            ) {
                this.itemIndex = clickData.itemIndex
                //선택한그리드
                this.selectDataRow = clickData.dataRow
                this.selectDataField = clickData.fieldName

                if (undefined == this.selectDataRow) {
                    return
                }
                if ('orgTree' == this.selectDataField) {
                    this.onAuthOrgTreeIconClick('grid')
                }
                this.selectBdataRow = clickData.dataRow
            }
        }

        // 조직코드 조회
        this.reqParam.orgCd = this.orgInfo.orgCd
        this.reqParam.orgNm = this.orgInfo.orgNm
        this.reqParam.orgLvl = this.orgInfo.orgLvl

        // 조직 초기화
        if (!_.isEmpty(this.orgInfo['orgCd'])) {
            this.reqParam.srchOrgCd = this.orgInfo.orgCd
            this.reqParam.orgNm = this.orgInfo['orgNm']
            this.reqParam.srchOrgLvl = this.orgInfo['orgLvl']
            this.reqParam.srchCoClOrgCd = this.orgInfo['orgCdLvl0']
        }

        // this.init()
    },
    computed: {},
    watch: {},
    created() {
        this.gridData = this.gridSetData(this.rowCnt)
    },
    methods: {
        // 탭선택시 마운트
        tabGridMounted: function () {
            this.resultAgencyRows = []
            this.gridObj1 = this.$refs.grid1
            this.gridHeaderObj1 = this.$refs.gridHeader1
            this.gridObj1.setGridState(false, false, false, false) //footer 나오게
            this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            // this.gridObj1.gridView.setColumnLayout(this.view1.layout)

            // this.dropDownSetting()
            this.gridObj1.gridView.onCellEdited = (
                grid,
                itemIndex,
                dataRow,
                field
            ) => {
                this.gridObj1.gridView.commit()
                this.getData = grid.getValue(itemIndex, field)
                if (field == 8) {
                    this.dealcoClCd1List.map((dealcoClCd1) => {
                        if (dealcoClCd1.value == this.getData) {
                            grid.setValue(
                                itemIndex,
                                'dealcoClCd1',
                                dealcoClCd1.label
                            )
                            return
                        }
                    })
                }
                this.selectedJsonData =
                    this.gridObj1.dataProvider.getJsonRow(dataRow)
            }

            // 그리드내의 부여조직 돋보기 클릭시 이벤트처리
            this.gridObj1.gridView.onCellClicked = (grid, clickData) => {
                if (
                    clickData.fieldName == 'dealcoCd' &&
                    clickData.cellType == 'data'
                ) {
                    this.gridObj1.gridView.commit()
                    this.getData = this.gridObj1.dataProvider.getJsonRow(
                        clickData.dataRow
                    )
                    this.shopDataRow = clickData.itemIndex
                    console.log('this.getData', this.getData)

                    if (this.getData.dealcoClCd1 == '1') {
                        this.onAuthOrgTreeIconClick('1')
                    } else if (this.getData.dealcoClCd1 == '2') {
                        this.onDealcoIconClick()
                    }
                }
            } // this.dropDownSetting()
            this.gridObj1.gridView.onCellEdited = (
                grid,
                itemIndex,
                dataRow,
                field
            ) => {
                this.gridObj1.gridView.commit()
                this.getData = grid.getValue(itemIndex, field)
                if (field == 8) {
                    this.dealcoClCd1List.map((dealcoClCd1) => {
                        if (dealcoClCd1.value == this.getData) {
                            grid.setValue(
                                itemIndex,
                                'dealcoClCd1',
                                dealcoClCd1.label
                            )
                            return
                        }
                    })
                }
                this.selectedJsonData =
                    this.gridObj1.dataProvider.getJsonRow(dataRow)
            }

            // 조직코드 조회
            this.reqParam.orgCd = this.orgInfo.orgCd
            this.reqParam.orgNm = this.orgInfo.orgNm
            this.reqParam.orgLvl = this.orgInfo.orgLvl
        },
        // 초기화
        init() {
            // commit
            this.gridObj.gridView.commit()
            if (this.gridObj1.gridView != undefined) {
                this.gridObj1.gridView.commit()
                CommonUtil.clearPage(this, 'reqParam', this.gridObj1)
                this.gridObj1.gridView.orderBy([]) // 정렬 초기화
            }

            CommonUtil.clearPage(this, 'reqParam', this.gridObj)
            this.gridObj.gridView.orderBy([]) // 정렬 초기화

            // 첫번째 탭으로 이동
            this.tab = {
                tabSync1: 0,
            }

            // 현재 그리드 cnt 초기화
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.nowGridIndex = 0
            this.gridLastIndex = 0
            // param 초기화
            this.param = {}

            // 버튼 컨트롤 초기화
            this.agencyNmShow = false
            this.searchShow = true
            this.onSearchShow = false
            this.saveShow = true
            this.onSaveShow = false

            // 조직 초기화
            if (!_.isEmpty(this.orgInfo['orgCd'])) {
                this.reqParam.srchOrgCd = this.orgInfo.orgCd
                this.reqParam.orgNm = this.orgInfo['orgNm']
                this.reqParam.srchOrgLvl = this.orgInfo['orgLvl']
                this.reqParam.srchCoClOrgCd = this.orgInfo['orgCdLvl0']
            }
        },

        //탭 변경에 따른 승인버튼 숨김 및 구분 콤보박스 변경
        onActiveTabClick(tabIndex) {
            this.tab.nowIndex = tabIndex
            if (tabIndex == 0) {
                this.agencyNmShow = false
                this.searchShow = true
                this.onSearchShow = false
                this.saveShow = true
                this.onSaveShow = false
            }
            if (tabIndex == 1) {
                this.agencyNmShow = true
                this.searchShow = false
                this.onSearchShow = true
                this.saveShow = false
                this.onSaveShow = true
            }
        },

        gridSetData(rowCnt) {
            return new CommonGrid(0, rowCnt, '', '')
        },

        //페이지 표시 행의수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        //================================================
        //조회 ::::::::USIM후불
        //================================================
        async Search() {
            this.changedDatas.saveRows = []
            this.changedDatas = this.gridObj.setModifyData(this.changedDatas)

            if (this.changedDatas.saveRows.length > 0) {
                //변경/추가 된 내용이 있으면 confirm 확인
                const confirm = await this.showTcComConfirm(msgTxt.MSG_00168)
                if (confirm) {
                    this.onSearchData()
                } else {
                    return
                }
            } else {
                this.onSearchData()
            }
        },
        onSearchData: function () {
            //조회 조직 입력 확인
            const orgCd = this.reqParam.srchOrgCd
            if (_.isEmpty(orgCd)) {
                this.showTcComAlert('조직을 입력하십시오.')
                return
            }
            this.searchForms = { ...this.reqParam }
            this.getUsimPayList()
        },

        getUsimPayList() {
            usimPreApi.getUsimPayList(this.searchForms).then((res) => {
                if (res) {
                    this.gridObj.dataProvider.clearRows()
                    this.gridObj.dataProvider.beginUpdate()
                    this.gridObj.setRows(res.gridList)
                    this.oldGridList = res.gridList
                    this.gridObj.dataProvider.endUpdate()
                    // 조회된 데이터의 length
                    this.gridRows = res.gridList.length
                    // 고정
                    this.gridIndex = this.gridObj.dataProvider.getRowCount()
                    // 동적으로 변경될 rowcnt
                    this.nowGridIndex = this.gridObj.dataProvider.getRowCount()
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },

        //================================================
        // 행추가::::::::USIM후불
        //================================================
        gridAddRowBtn: function () {
            this.gridObj.gridView.commit()
            //조회된 결과값이 없을시 행추가 방지
            if (this.nowGridIndex == 0) {
                return
            }
            // 행추가 되면 해당 위치로 focused 하기
            let focuscell = this.gridObj.gridView.getCurrent()
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
            // row cnt 변경
            this.gridRows = this.gridHeaderObj.addRow(this.gridRows)
            this.nowGridIndex = this.gridObj.dataProvider.getRowCount()
            this.gridLastIndex = this.gridObj.dataProvider.getRowCount() - 1
            //행추가 기본값 세팅하기
            this.defaultJson = {}
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'ssupOrgNm',
                this.defaultJson.ssupOrgNm
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'supOrgNm',
                this.defaultJson.supOrgNm
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'orgNm',
                this.defaultJson.orgNm
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'orgTree',
                this.defaultJson.orgTree
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'usimPayYn',
                this.defaultJson.usimPayYn
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'aplyStaDt',
                this.defaultJson.aplyStaDt
            )
            this.gridObj.gridView.setValue(
                this.gridLastIndex,
                'aplyEndDt',
                this.defaultJson.aplyEndDt
            )
            this.gridObj.gridView.getSelectedRows(-1)
            this.gridObj.gridView.commit()
        },
        //================================================
        // 행삭제::::::::USIM후불
        //================================================
        gridDelRowBtn: function () {
            // 조회된 데이터 행삭제 방지
            if (
                this.gridIndex == this.nowGridIndex ||
                this.gridLastIndex == 0
            ) {
                return
            }

            this.gridObj1.dataProvider.removeRow(this.gridLastIndex)
            this.nowGridIndex = this.gridObj.dataProvider.getRowCount()
            this.gridLastIndex = this.gridObj.dataProvider.getRowCount() - 1
        },
        //================================================
        // insert/udate validation::::::::USIM후불
        //================================================
        AplyDtChk() {
            this.gridDatas = []
            this.gridObj.gridView.commit()
            //변경된 행 데이터 가져오기
            this.gridDatas = this.gridObj.setModifyData(this.gridDatas)
            this.param.usimPayList = this.gridDatas.saveRows
            // 변경 여부 확인
            if (_.isEmpty(this.param.usimPayList)) {
                this.showTcComAlert(msgTxt.MSG_01002)
                return false
            }
            for (var i = 0; i < this.param.usimPayList.length; i++) {
                if (_.isEmpty(this.param.usimPayList[i].orgTree)) {
                    this.showTcComAlert(
                        msgTxt.MSG_01002 + '\n 조직을 선택해 주세요.'
                    )
                    return false
                }
                // USIM 후불예수금 적용
                if (
                    this.param.usimPayList[i].usimPayYn == 1 &&
                    (this.param.usimPayList[i].__rowState == 'created' ||
                        this.param.usimPayList[i].__rowState == 'updated')
                ) {
                    if (_.isEmpty(this.param.usimPayList[i].aplyStaDt)) {
                        this.param.usimPayList[i].aplyStaDt = moment(
                            new Date()
                        ).format('YYYY-MM-DD')
                    }
                    if (this.param.usimPayList[i].aplyEndDt == undefined) {
                        this.param.usimPayList[i].aplyEndDt = '99991231'
                        this.newAplyEndDt = this.param.usimPayList[i].aplyEndDt
                    }
                    if (this.param.usimPayList[i].aplyEndDt != undefined) {
                        this.param.usimPayList[i].aplyEndDt = '99991231'
                    }
                    console.log(
                        ':::::' +
                            this.param.usimPayList[i].__rowState +
                            ' 로직 처리:::::'
                    )
                    // ****USIM 후불예수금 적용 Y일경우 시작/종료일자 체크*****
                    // 시작/종료일자 입력 여부 확인
                    if (
                        this.param.usimPayList[i].usimPayYn == 1 &&
                        this.param.usimPayList[i].aplyStaDt == undefined
                    ) {
                        this.showTcComAlert(
                            '적용시작일자/적용종료일자를 입력하십시오.'
                        )
                        return false
                    }
                    // 시작일자가 종료일자 보다 큰지 체크
                    if (
                        this.newAplyEndDt != undefined &&
                        CommonUtil.onlyNumber(
                            this.param.usimPayList[i].aplyStaDt
                        ) > this.param.usimPayList[i].aplyEndDt
                    ) {
                        this.showTcComAlert(
                            this.param.usimPayList[i].orgTree +
                                '의 적용시작일자가 적용종료일자보다 큽니다.'
                        )
                        return false
                    }
                    //if 행추가(created)
                    if (this.param.usimPayList[i].__rowState == 'created') {
                        // 새로 입력된 종료일자
                        this.param.usimPayList[i].aplyEndDt = '99991231'

                        // 행추가인 경우 기존에 입력된 동일한 PT의 적용시작/종료일자 중복 여부를 체크
                        for (var j = 0; j < this.oldGridList.length; j++) {
                            if (
                                this.param.usimPayList[i].orgTree ==
                                this.oldGridList[j].orgTree
                            ) {
                                // 기존 입력된 종료일자
                                var oldAplyEndDt
                                if (!_.isEmpty(this.oldGridList[j].aplyEndDt)) {
                                    if (
                                        CommonUtil.onlyNumber(
                                            this.oldGridList[j].aplyEndDt
                                        ) > 0
                                    ) {
                                        oldAplyEndDt = CommonUtil.onlyNumber(
                                            this.oldGridList[j].aplyEndDt
                                        )
                                    } else {
                                        oldAplyEndDt = '99991231'
                                    }

                                    // 새로 입력된 시작일자가 기존 입력된 시작일자보다 작거나
                                    // 새로 입력된 시작일자가 기존 입력된 시작/종료일자 구간이면 입력불가
                                    if (
                                        CommonUtil.onlyNumber(
                                            this.param.usimPayList[i].aplyStaDt
                                        ) < this.oldGridList[j].aplyStaDt
                                    ) {
                                        this.showTcComAlert(
                                            this.param.usimPayList[i].orgNm +
                                                '적용시작일자가 기존에 입력된 시작일자보다 작습니다.'
                                        )
                                        return false
                                    }
                                    if (
                                        CommonUtil.onlyNumber(
                                            this.param.usimPayList[i].aplyStaDt
                                        ) >= this.oldGridList[j].aplyStaDt &&
                                        CommonUtil.onlyNumber(
                                            this.param.usimPayList[i].aplyStaDt
                                        ) <= oldAplyEndDt
                                    ) {
                                        this.showTcComAlert(
                                            this.param.usimPayList[i].orgNm +
                                                '적용시작일자가 기존에 입력된 시작/종료일자 구간입니다.'
                                        )
                                        return false
                                    }
                                }
                                // 새로 입력된 종료일자가 기존 입력된 시작일자보다 작거나
                                // 새로 입력된 종료일자가 기존 입력된 시작/종료일자 구간이면 입력불가
                                if (!_.isEmpty(this.oldGridList[j].aplyStaDt)) {
                                    if (
                                        this.newAplyEndDt <
                                        CommonUtil.onlyNumber(
                                            this.oldGridList[j].aplyStaDt
                                        )
                                    ) {
                                        this.showTcComAlert(
                                            this.param.usimPayList[i].orgNm +
                                                '종료일자가 기존에 입력된 시작일자보다 작습니다다.'
                                        )
                                        return false
                                    }
                                    if (
                                        this.newAplyEndDt >=
                                            CommonUtil.onlyNumber(
                                                this.oldGridList[j].aplyStaDt
                                            ) &&
                                        this.newAplyEndDt <= oldAplyEndDt
                                    ) {
                                        this.showTcComAlert(
                                            this.param.usimPayList[i].orgNm +
                                                '종료일자가 기존에 입력된 시작/종료일자 구간입니다.'
                                        )
                                        return false
                                    }
                                }
                            }
                        }
                    }
                    console.log(
                        ':::::' +
                            this.param.usimPayList[i].__rowState +
                            ' 로직 처리 종료:::::'
                    )
                } else {
                    this.param.usimPayList[i].aplyEndDt = moment(
                        new Date()
                    ).format('YYYY-MM-DD')
                }
            }
        },

        //================================================
        // 저장:::::::::USIM후불
        //================================================
        save() {
            // 시작/종료일자 체크
            if (this.AplyDtChk() == false) {
                return
            }
            this.saveUsimPay()
        },
        saveUsimPay() {
            usimPreApi.saveUsimPay(this.param).then((res) => {
                if (res) {
                    this.changedDatas.saveRows = []
                    this.onSearchData()
                } else {
                    this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                }
            })
        },

        //================================================
        // EXCEL DOWNLOAD:::::::::USIM후불
        //================================================
        downloadUsimExcel: function () {
            usimPreApi.downloadUsimPayListExcel(this.searchForms)
        },

        //================================================
        // ::::::::SWING대리점거래처매핑관리::::::::::
        //================================================
        //================================================
        // :::::::조회 ::::::::매장별 기준관리
        //================================================

        onSearch() {
            this.gridObj1.gridView.commit()
            if (_.isEmpty(this.reqParam.srchOrgCd)) {
                this.showTcComAlert('조직을 입력하십시오.')
                return
            } else {
                this.reqParam.orgCd = this.reqParam.srchOrgCd
                this.reqParam.orglevel = this.reqParam.srchOrgLvl
                this.reqParam.dealcoCd = this.reqParam.agencyCd
            }

            usimPreApi.getDealList(this.reqParam).then((result) => {
                this.ds_list = result.gridList
                this.gridObj1.setRows(result.gridList)
                // 페이징 관련
                this.gridObj1.setGridIndicator() //순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData() //초기화
            })
        },

        //================================================
        // :::::::저장:::::::::매장별 기준관리
        // :::::::정산 메뉴로 변경 되며 행추가/삭제 기능 제거
        //================================================
        onSave: function () {
            this.gridObj1.gridView.commit()
            let saveParamList = []
            // let getJson = {}
            let gridUpdatedIndexArr =
                this.gridObj1.dataProvider.getStateRows('updated')

            for (let idx = 0; idx < gridUpdatedIndexArr.length; idx++) {
                let getJson = this.gridObj1.dataProvider.getJsonRow(
                    gridUpdatedIndexArr[idx]
                )
                getJson.agencyCd = getJson.agencyCd ? getJson.agencyCd : ''
                getJson.sktSubCd = getJson.sktSubCd ? getJson.sktSubCd : ''
                getJson.dealcoCd = getJson.dealcoCd ? getJson.dealcoCd : ''
                getJson.dealcoClCd1 = getJson.dealcoClCd1
                    ? getJson.dealcoClCd1
                    : ''
                getJson.bizChrgOrgCd = getJson.bizChrgOrgCd
                    ? getJson.bizChrgOrgCd
                    : ''
                getJson.teamOrgCd = getJson.teamOrgCd ? getJson.teamOrgCd : ''
                getJson.ptOrgCd = getJson.ptOrgCd ? getJson.ptOrgCd : ''
                getJson.adjtYn = getJson.adjtYn ? getJson.adjtYn : ''
                if (getJson.checkBox == 1) {
                    getJson.rowState = 'delete'
                } else {
                    getJson.rowState = 'updated'
                }
                if (_.isEmpty(getJson.adjtYn)) {
                    this.showTcComAlert('위탁수수료 조정 여부를 입력해주세요.')
                    return
                }
                saveParamList.push(getJson)
            }

            usimPreApi.saveDealList(saveParamList).then((result) => {
                if (result) {
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    // 매핑정보 재조회
                    this.onSearch()
                }
            })
        },

        // 그리드에 그룹명 dropdown셋팅 공통코드 api
        async dropDownSetting() {
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00250',
                columnName: 'wdrlDt',
                option: '--선택--',
            })
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00730',
                columnName: 'biId',
                option: '--선택--',
            })
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00740',
                columnName: 'deptCd',
                option: '--선택--',
            })
            await this.dropDownCmmonCodes({
                key: '',
                columnName: 'rpstyCd',
                option: '--선택--',
            })
        },

        async dropDownCmmonCodes({ key, columnName, option }) {
            let result = await usimPreApi.dropDownCmmonCodes_(key)
            if (columnName == 'wdrlDt') {
                this.wdrlDtList = result
            }
            if (columnName == 'deptCd') {
                this.deptCdList = result
            }
            if (columnName == 'dutyCdList') {
                this.dutyCdList = result
            }
            if (columnName == 'rpstyCdList') {
                this.rpstyCdList = result
            }
            let values = []
            let labels = []
            values = result.map((a) => a.commCdVal)
            labels = result.map((a) => a.commCdValNm)
            if (option != undefined) {
                values.unshift('')
                labels.unshift(option)
            }
            if (columnName == 'userGrpNm') {
                let col1 = this.gridObj1.gridView.columnByName(columnName)
                col1.values = values
                col1.labels = labels
                this.gridObj1.gridView.setColumn(col1)
            }
        },

        downloadShopExcel: function () {
            if (this.ds_list.length > 0) {
                usimPreApi.downloadShopDealExcel(this.reqParam)
            } else {
                this.showTcComAlert('데이터 조회를 먼저 해주십시오.')
            }
        },

        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.reqParams.orgNm = this.reqParam.orgNm
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.reqParams)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res) {
                        if (res.length === 1) {
                            this.reqParam.srchOrgCd = _.get(res[0], 'orgCd')
                            this.reqParam.orgNm = _.get(res[0], 'orgNm')
                            this.reqParam.srchOrgLvl = _.get(res[0], 'vLevel')
                            this.reqParam.srchCoClOrgCd = _.get(
                                res[0],
                                'orgCdLvl0'
                            )
                            this.reqParam.orgTree = _.get(res[0], 'orgTree')
                        } else {
                            this.resultAuthOrgTreeRows = res
                            this.showBcoAuthOrgTrees = true
                        }
                    }
                })
        },

        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick(state) {
            this.orgTreeClicked = state
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (this.orgTreeClicked == 'grid') {
                this.showBcoAuthOrgTreesGrid = true
            }
            if (this.orgTreeClicked == '1') {
                this.showBcoAuthOrgTreesGrid1 = true
            }
            if (this.orgTreeClicked == 'reqParam') {
                if (!_.isEmpty(this.reqParam.orgNm)) {
                    this.getAuthOrgTreeList()
                }
                this.showBcoAuthOrgTrees = true
            }
        },

        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgNm)) {
                this.showTcComAlert('내부조직팝업(권한)명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.srchOrgCd = ''
            this.reqParam.srchOrgLvl = ''
            this.reqParam.srchCoClOrgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리

        onAuthOrgTreeReturnDataGrid(returnData) {
            // 행추가 -> 조직검색 버튼 클릭시 추가된 그리드에 조직정보 세팅
            if (
                this.gridLastIndex <= this.nowGridIndex &&
                this.selectDataField == 'orgTree'
            ) {
                this.defaultJson.orgNm1 = _.get(returnData, 'orgNmLvl0')
                this.defaultJson.ssupOrgNm = _.get(returnData, 'orgNmLvl1')
                this.defaultJson.supOrgNm = _.get(returnData, 'orgNmLvl2')
                this.defaultJson.supOrgNm13 = _.get(returnData, 'orgNmLvl3')
                this.defaultJson.orgNm = _.get(returnData, 'orgNm')
                this.defaultJson.orgCd = _.get(returnData, 'orgCd')
                this.defaultJson.orgTree =
                    this.defaultJson.orgNm1 +
                    '>' +
                    this.defaultJson.ssupOrgNm +
                    '>' +
                    this.defaultJson.supOrgNm +
                    '>' +
                    this.defaultJson.supOrgNm13
                this.gridObj.gridView.setValue(
                    this.itemIndex,
                    'ssupOrgNm',
                    this.defaultJson.ssupOrgNm
                )
                this.gridObj.gridView.setValue(
                    this.itemIndex,
                    'supOrgNm',
                    this.defaultJson.supOrgNm
                )
                this.gridObj.gridView.setValue(
                    this.itemIndex,
                    'orgNm',
                    this.defaultJson.orgNm
                )
                this.gridObj.gridView.setValue(
                    this.itemIndex,
                    'orgCd',
                    this.defaultJson.orgCd
                )
                this.gridObj.gridView.setValue(
                    this.itemIndex,
                    'orgTree',
                    this.defaultJson.orgTree
                )
            }
        },
        onAuthOrgTreeReturnDataGrid1(retrunData) {
            // let current = this.gridObj1.gridView.getCurrent()
            // this.shopDataRow
            console.log('this.shopDataRow', this.shopDataRow)
            this.reqParam.orgCd = _.get(retrunData, 'orgCd')
            this.reqParam.orgNm = _.get(retrunData, 'orgNm')
            // this.searchAuthOrgTreeParam.orgLvl = _.get(retrunData, 'orgLvl')
            let orgCdLvl1 = _.get(retrunData, 'orgCdLvl1')
            let orgCdLvl2 = _.get(retrunData, 'orgCdLvl2')
            let orgCdLvl3 = _.get(retrunData, 'orgCdLvl3')
            let orgNmLvl1 = _.get(retrunData, 'orgNmLvl1')
            let orgNmLvl2 = _.get(retrunData, 'orgNmLvl2')
            let orgNmLvl3 = _.get(retrunData, 'orgNmLvl3')
            // 그리드 거래처 SET
            this.gridObj1.gridView.setValue(
                this.shopDataRow,
                'dealcoCd',
                this.reqParam.orgCd
            )
            // 그리드 거래처명 SET
            this.gridObj1.gridView.setValue(
                this.shopDataRow,
                'dealcoNm',
                this.reqParam.orgNm
            )
            // 그리드 사업담당 SET
            this.gridObj1.gridView.setValue(
                this.shopDataRow,
                'bizChrgOrgCd',
                orgCdLvl1
            )
            // 그리드 사업담당명 SET
            this.gridObj1.gridView.setValue(
                this.shopDataRow,
                'bizChrgOrgNm',
                orgNmLvl1
            )
            // 그리드 팀 SET
            this.gridObj1.gridView.setValue(
                this.shopDataRow,
                'teamOrgCd',
                orgCdLvl2
            )
            // 그리드 팀명 SET
            this.gridObj1.gridView.setValue(
                this.shopDataRow,
                'teamOrgNm',
                orgNmLvl2
            )
            // 그리드 파트 SET
            this.gridObj1.gridView.setValue(
                this.shopDataRow,
                'ptOrgCd',
                orgCdLvl3
            )
            // 그리드 파트명 SET
            this.gridObj1.gridView.setValue(
                this.shopDataRow,
                'ptOrgNm',
                orgNmLvl3
            )
        },
        onAuthOrgTreeReturnData(returnData) {
            this.reqParam.srchOrgCd = _.get(returnData, 'orgCd')
            this.reqParam.orgNm = _.get(returnData, 'orgNm')
            this.reqParam.srchOrgLvl = _.get(returnData, 'orgLvl')
            this.reqParam.srchCoClOrgCd = _.get(returnData, 'orgCdLvl0')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== //조직별 대리점팝업관련 methods ================================

        /* 조직별 대리점팝업 */
        getOrgAgencyList() {
            this.reqParam.basMth = moment(new Date()).format('YYYY-MM')
            basBcoOrgAgencysApi.getOrgAgencyList(this.reqParam).then((res) => {
                if (res.length === 1) {
                    this.reqParam.agencyCd = _.get(res[0], 'agencyCd')
                    this.reqParam.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultAgencyRows = res
                    this.showBcoOrgAgencys = true
                }
            })
        },
        /* 조직별 대리점팝업 - 돋보기 Icon 이벤트 */
        onOrgAgencyIconClick() {
            this.resultAgencyRows = []
            if (!_.isEmpty(this.reqParam.agencyNm)) {
                this.getOrgAgencyList()
            } else {
                this.showBcoOrgAgencys = true
            }
        },
        /* 조직별 대리점팝업 - 엔터키 이벤트 */
        onOrgAgencyEnterKey() {
            this.resultAgencyRows = []
            if (!_.isEmpty(this.reqParam.agencyNm)) {
                this.getOrgAgencyList()
            } else {
                this.showBcoOrgAgencys = true
            }
        },
        /* 조직별 대리점팝업 - Input 이벤트 */
        onOrgAgencyInput() {
            this.reqParam.agencyCd = ''
        },
        /* 조직별 대리점팝업 - 리턴 이벤트 */
        onOrgAgencyReturnData(retrunData) {
            this.reqParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.reqParam.agencyNm = _.get(retrunData, 'agencyNm')
        },

        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.searchForm.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.searchForm.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealco = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            let basDay = moment().format('YYYYMM')
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            this.searchForm.basDay = basDay
            // this.searchForm.orgCd = this.reqParam.orgCd
            // this.searchForm.orgNm = this.reqParam.orgNm
            // this.searchForm.dealcoCd = this.reqParam.dealcoCd
            // this.searchForm.dealcoNm = this.reqParam.dealcoNm

            // 팝업오픈
            this.showBasBcoDealco = true
            // }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchForm.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-전체조직명 입력해주세요.'
                return
            }
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.searchForm.dealcoCd = ''
        },

        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            // let current = this.gridObj1.gridView.getCurrent()
            // this.shopDataRow
            let dealcoCd = _.get(returnData, 'dealcoCd')
            let dealcoNm = _.get(returnData, 'dealcoNm')
            // 그리드 거래처 SET
            this.gridObj1.gridView.setValue(
                this.shopDataRow,
                'dealcoCd',
                dealcoCd
            )
            // 그리드 거래처명 SET
            this.gridObj1.gridView.setValue(
                this.shopDataRow,
                'dealcoNm',
                dealcoNm
            )
            // // 그리드 사업담당 SET
            // this.gridObj1.gridView.setValue(this.shopDataRow, '', dealcoNm)
            // // 그리드 팀 SET
            // this.gridObj1.gridView.setValue(this.shopDataRow, '', dealcoNm)
            // // 그리드 파트 SET
            // this.gridObj1.gridView.setValue(this.shopDataRow, '', dealcoNm)
        },
        //===================== //내부거래처(권한조직)팝업관련 methods =====================
    },
}
</script>
