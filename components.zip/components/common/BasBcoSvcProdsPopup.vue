<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1100px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">서비스상품팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div5">
                                <TCComComboBox
                                    v-model="searchSvcProdForm.wrcellClCd"
                                    codeId="ZBAS_C_00480"
                                    labelName="유무선구분"
                                    :objAuth="objAuth"
                                    :disabled="isDisabledWrcelClCd"
                                    :eRequired="true"
                                ></TCComComboBox>
                            </div>
                            <!-- //item 1-1 -->
                            <!-- item 1-2 -->
                            <div class="formitem div5">
                                <TCComComboBox
                                    v-model="searchSvcProdForm.suplSvcClCd"
                                    :codeId="commIdPrcplnClCd"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    labelName="서비스구분"
                                    :objAuth="objAuth"
                                    :disabled="isDisabledSuplSvcClCd"
                                    :eRequired="true"
                                ></TCComComboBox>
                            </div>
                            <!-- // item 1-2 -->
                            <!-- item 1-3 -->
                            <div class="formitem div5">
                                <TCComComboBox
                                    v-model="searchSvcProdForm.prodStCd"
                                    codeId="ZBAS_C_00180"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    labelName="상품상태"
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                            <!-- // item 1-3 -->
                            <!-- item 1-4 -->
                            <div class="formitem div5">
                                <TCComComboBox
                                    v-model="searchSvcProdForm.useYn"
                                    :itemList="codeYn"
                                    itemText="codeVal"
                                    itemValue="codeId"
                                    labelName="사용여부"
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                            <!-- // item 1-4 -->
                            <!-- item 1-5 -->
                            <div class="formitem div5"></div>
                            <!-- // item 1-5 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div5">
                                <TCComInput
                                    v-model="searchSvcProdForm.suplSvcCd"
                                    labelName="서비스코드"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 2-1 -->
                            <!-- item 2-2 -->
                            <div class="formitem div5">
                                <TCComInput
                                    v-model="searchSvcProdForm.suplSvcNm"
                                    labelName="서비스상품명"
                                    :objAuth="objAuth"
                                    @enterKey="onEnterKey"
                                >
                                </TCComInput>
                            </div>
                            <!-- //item 2-2 -->
                            <!-- item 2-3 -->
                            <div class="formitem div5">
                                <TCComComboBox
                                    v-model="searchSvcProdForm.prcplnClCd"
                                    codeId="PRCPLN_CL_CD"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    labelName="분류"
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                            <!-- //item 2-3 -->
                            <!-- item 2-4 -->
                            <div class="formitem div5">
                                <TCComComboBox
                                    v-model="searchSvcProdForm.prcplnClDtlCd"
                                    codeId="PRCPLN_CL_DTL_CD"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    labelName="분류상세"
                                    :objAuth="objAuth"
                                ></TCComComboBox>
                            </div>
                            <!-- //item 2-4 -->
                            <!-- item 2-5 -->
                            <div class="formitem div5">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="조회"
                                            @click="onSearch"
                                        />
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-5 -->
                        </div>
                        <!-- //Search_line 2 -->
                    </div>
                    <!-- //Search_div -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="svcProdsGridHeader"
                            ref="svcProdsGridHeader"
                            :gridObj="gridObj"
                        />
                        <TCRealGrid
                            id="svcProdsGrid"
                            ref="svcProdsGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onConfirm"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { basBcoSvcProdsHeader } from '@/const/grid/bas/bco/basBcoSvcProdsHeader'
import basBcoSvcProdsApi from '@/api/biz/bas/bco/basBcoSvcProds'
import commonApi from '@/api/common/commonCode'
import _ from 'lodash'
import CommonMixin from '@/mixins'
export default {
    name: 'BasBcoSvcProdsPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            //Paging Class init
            gridData: this.gridSetData(),
            headerText: '',
            objAuth: {},
            view: basBcoSvcProdsHeader,
            codeYn: [
                {
                    codeId: '',
                    codeVal: '전체',
                },
                {
                    codeId: 'Y',
                    codeVal: 'Y',
                },
                {
                    codeId: 'N',
                    codeVal: 'N',
                },
            ],
            chkData: [
                {
                    codeId: '1',
                    codeNm: '',
                },
            ],
            combProdYn: [
                {
                    codeId: '',
                    codeVal: '',
                },
                {
                    codeId: 'Y',
                    codeVal: '결합',
                },
            ],
            content: '',
            gridObj: {},
            gridHeaderObj: {},
            commIdPrcplnClCd: 'ZBAS_C_00320',
            searchSvcProdForm: {
                wrcellClCd: '', // 유무선구분
                suplSvcClCd: '', // 서비스구분
                prodStCd: '1', // 상품상태
                useYn: '', // 사용여부
                suplSvcCd: '', // 서비스코드
                suplSvcNm: '', // 서비스명
                prcplnClCd: '', // 분류
                prcplnClDtlCd: '', // 분류상세
            },
            isDisabledWrcelClCd: false,
            isDisabledSuplSvcClCd: false,
        }
    },

    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.svcProdsGrid
        this.gridHeaderObj = this.$refs.svcProdsGridHeader
        this.initGrid()
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                this.searchSvcProdForm.suplSvcCd =
                    value['suplSvcCd'] == undefined ? '' : value['suplSvcCd'] //서비스상품
                this.searchSvcProdForm.suplSvcNm =
                    value['suplSvcNm'] == undefined ? '' : value['suplSvcNm'] //서비스상품명
                this.searchSvcProdForm.wrcellClCd =
                    value['wrcellClCd'] == undefined ? '' : value['wrcellClCd'] //유무선구분
                this.searchSvcProdForm.suplSvcClCd =
                    value['suplSvcClCd'] == undefined
                        ? ''
                        : value['suplSvcClCd'] //서비스구분
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        //GridSetData
        gridSetData: function () {
            //CommonGrid(현재페이지 번호, 총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 현재페이지 Row수, Grid JsonData),
            return new CommonGrid(-1, -1, 10, 0, '')
        },
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            this.gridObj.gridView.displayOptions.fitStyle = 'even'
            this.gridObj.setGridState(false, false, false)
            const commWrcellClCd = await this.getCommCodeList('ZBAS_C_00480')
            const commSuplSvcClCd = await this.getCommCodeList('ZBAS_C_00320')
            const commProdStCd = await this.getCommCodeList('ZBAS_C_00180')
            const commRgstClCd = await this.getCommCodeList('ZBAS_C_00170')
            const commPrcplnClCd = await this.getCommCodeList('PRCPLN_CL_CD')
            const commPrcplnClDtlCd = await this.getCommCodeList(
                'PRCPLN_CL_DTL_CD'
            )

            // 서비스구분
            this.gridObj.gridView.columnByName('wrcellClCd').values =
                CommonUtil.convListToGridLovValues(commWrcellClCd, 'commCdVal')
            this.gridObj.gridView.columnByName('wrcellClCd').labels =
                CommonUtil.convListToGridLovLabels(
                    commWrcellClCd,
                    'commCdValNm'
                )
            // 서비스상세구분
            this.gridObj.gridView.columnByName('suplSvcClCd').values =
                CommonUtil.convListToGridLovValues(commSuplSvcClCd, 'commCdVal')
            this.gridObj.gridView.columnByName('suplSvcClCd').labels =
                CommonUtil.convListToGridLovLabels(
                    commSuplSvcClCd,
                    'commCdValNm'
                )
            // 상품상태
            this.gridObj.gridView.columnByName('prodStCd').values =
                CommonUtil.convListToGridLovValues(commProdStCd, 'commCdVal')
            this.gridObj.gridView.columnByName('prodStCd').labels =
                CommonUtil.convListToGridLovLabels(commProdStCd, 'commCdValNm')
            // 등록구분
            this.gridObj.gridView.columnByName('rgstClCd').values =
                CommonUtil.convListToGridLovValues(commRgstClCd, 'commCdVal')
            this.gridObj.gridView.columnByName('rgstClCd').labels =
                CommonUtil.convListToGridLovLabels(commRgstClCd, 'commCdValNm')
            // 분류
            this.gridObj.gridView.columnByName('prcplnClCd').values =
                CommonUtil.convListToGridLovValues(commPrcplnClCd, 'commCdVal')
            this.gridObj.gridView.columnByName('prcplnClCd').labels =
                CommonUtil.convListToGridLovLabels(
                    commPrcplnClCd,
                    'commCdValNm'
                )
            // 분류상세
            this.gridObj.gridView.columnByName('prcplnClDtlCd').values =
                CommonUtil.convListToGridLovValues(
                    commPrcplnClDtlCd,
                    'commCdVal'
                )
            this.gridObj.gridView.columnByName('prcplnClDtlCd').labels =
                CommonUtil.convListToGridLovLabels(
                    commPrcplnClDtlCd,
                    'commCdValNm'
                )

            this.gridObj.setRows(this.rows)
            this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
                const jsonData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.$emit('confirm', jsonData)
                this.onClose()
            }

            //그리드실행후 시작시 한번실행
            this.init()
            this.getSvcProdList()
        },
        init() {
            if (!_.isEmpty(this.searchSvcProdForm.wrcellClCd)) {
                this.isDisabledWrcelClCd = true
            } else {
                this.searchSvcProdForm.wrcellClCd = '1'
            }
            if (!_.isEmpty(this.searchSvcProdForm.suplSvcClCd)) {
                this.isDisabledSuplSvcClCd = true
            }

            if (this.rows.length == 0) {
                this.onSearch()
            }
        },
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },
        getSvcProdList() {
            basBcoSvcProdsApi
                .getSvcProdList(this.searchSvcProdForm)
                .then((res) => {
                    console.log('getSvcProdList : ', res)
                    this.gridObj.setRows(res)
                })
        },

        onConfirm() {
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow === -1) {
                this.showTcComAlert('상품을 선택해주세요.', {
                    header: '상품',
                    size: '500',
                    confirmLabel: 'OK',
                })
            }
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                current.dataRow
            )
            this.$emit('confirm', jsonData)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        onSearch() {
            this.getSvcProdList()
        },

        onEnterKey() {
            this.onSearch()
        },
        onChangeWrcellClCd() {
            console.log(
                'onChangeWrcellClCd::',
                this.searchSvcProdForm.wrcellClCd
            )
            if (this.searchSvcProdForm.wrcellClCd === '1') {
                console.log('11')
                this.commIdPrcplnClCd = 'ZBAS_C_00320'
            } else if (this.searchSvcProdForm.wrcellClCd === '2') {
                console.log('22')

                this.commIdPrcplnClCd = 'ZBAS_C_00321'
            }
        },
    },
}
</script>
