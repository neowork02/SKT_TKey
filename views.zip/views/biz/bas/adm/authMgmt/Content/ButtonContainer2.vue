<template>
    <!-- Bottom BTN Group -->
    <div class="btn_area_bottom">
        <TCComButton
            eClass="btn_ty02_point"
            :objAuth="this.objAuth"
            :eLarge="true"
            @click="saveBtn"
            >저장</TCComButton
        >
    </div>
    <!-- // Bottom BTN Group -->
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/authMgmt/helpers'
import _ from 'lodash'
import { msgTxt } from '@/const/msg.Properties'
export default {
    name: 'buttonContainer2',
    components: {},
    data() {
        return {
            objAuth: {},
        }
    },
    created() {},
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },

        async saveBtn() {
            await this.saveData()
        },

        async saveData() {
            await this.loading(true)
            let saveRows = []

            _.forEach(this.resultList, (add) => {
                if (_.isEqual(add.origin, 'ex')) {
                    // 매핑안된 사용자가 추가된 경우
                    let serNo = _.isEmpty(add.serNo) ? 1 : Number(add.serNo)
                    add.__rowState = 'created'
                    add.delYn = 'N'
                    add.authTypCd = '1'
                    add.userGrpCd = this.newDtlParam.userGrpCd
                    add.serNo = serNo

                    saveRows.push(add)
                }
            })
            _.forEach(this.resultListAll, (del) => {
                if (_.isEqual(del.origin, 'in')) {
                    // 매핑된 사용자중 추가된 경우
                    let serNo = Number(del.serNo)
                    del.delYn = 'Y'
                    del.authTypCd = '1'
                    del.userGrpCd = this.newDtlParam.userGrpCd
                    del.serNo = serNo - 1
                    console.log('del -> ', del)
                    saveRows.push(del)
                }
            })

            if (!saveRows.length) {
                this.showTcComAlert(msgTxt.MSG_01002)
                return false
            }

            let params = {}
            params['tbasAddUserAuthInfoVoList'] = saveRows
            this.defaultAssign_({
                key: 'saveParams',
                value: params,
            })
            await this.rgstBasAdmAuthMgmtUser_()
                .then((data) => {
                    if (data === 0) {
                        this.showTcComAlert('등록실패')
                    } else {
                        this.activeOpen = false
                        let param1 = {
                            userGrpCd: this.newDtlParam.userGrpCd,
                            attcClCd: this.newDtlParam.attcClCd,
                        }
                        this.getAuthMgmtUserList_({
                            param: param1,
                        })
                        this.showTcComAlert('등록되었습니다.')
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    this.loading(false)

                    this.defaultAssign_({
                        key: 'saveParams',
                        value: [],
                    })
                })
        },
    },
}
</script>
