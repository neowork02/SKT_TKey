import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = [
    {
        fieldName: 'storeId',
        header: { text: '상점아이디' },
        width: '150',
    },
    {
        fieldName: 'dealClNm',
        header: { text: '거래상태' },
        width: '150',
    },
    {
        fieldName: 'caDt',
        header: { text: '승인일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'prchSchdDt',
        header: { text: '매입요청일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'prchDt',
        header: { text: '매입일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'ccDt',
        header: { text: '취소일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'dpstSchdDt',
        header: { text: '지급(예정)일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'prchCoCdNm',
        header: { text: '결제기관' },
        width: '150',
    },
    {
        fieldName: 'settlMthdNm',
        header: { text: '결제수단' },
        width: '150',
    },
    {
        fieldName: 'istmtMthCnt',
        header: { text: '할부개월수' },
        width: '150',
    },
    {
        fieldName: 'aprvNo',
        header: { text: '승인번호' },
        width: '150',
    },
    {
        fieldName: 'aprvAmt',
        header: { text: '거래금액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'cmms',
        header: { text: '수수료' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'vat',
        header: { text: '부가세' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'dpstSchdAmt',
        header: { text: '정산(예정)금액' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'joinbrDealNo',
        header: { text: '주문번호' },
        width: '150',
    },
    {
        fieldName: 'ordProd',
        header: { text: '상품명' },
        width: '150',
    },
    {
        fieldName: 'com',
        header: { text: '법인명' },
        width: '150',
    },
    {
        fieldName: 'ordrNm',
        header: { text: '구매자' },
        width: '150',
    },
    {
        fieldName: 'coCom',
        header: { text: '제휴사' },
        width: '150',
    },
    {
        fieldName: 'cmmsFree',
        header: { text: '무이자수수료' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'errMsg',
        header: { text: '오류사항' },
        width: '250',
        styleName: 'left-column',
    },
]

const GRID_HEADER = {}
GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)

export { GRID_HEADER }
