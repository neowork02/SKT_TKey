<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="680px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">가격표 정책변경</p>
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComDatePicker
                                    v-if="v_aplyDtm.visible"
                                    labelName="기존정책"
                                    v-model="div_search.aplyDtm"
                                    elementClass="iteminput"
                                    calType="DHMP"
                                    :hourVal.sync="div_search.aplyStaHour"
                                    :minuVal.sync="div_search.aplyStaMin"
                                    :endHourVal.sync="div_search.aplyEndHour"
                                    :endMinuVal.sync="div_search.aplyEndMin"
                                    :disabled="!v_aplyDtm.enable"
                                    @change="onAplyDtmChange"
                                />
                            </div>
                        </div>
                    </div>
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div1">
                                <div class="formitem div2">
                                    <TCComCheckBox
                                        labelName="변경구분"
                                        v-model="div_search.rad_policy"
                                        :objAuth="objAuth"
                                        :itemList="ds_policy"
                                        :disabled="!v_rad_policy.enable"
                                    ></TCComCheckBox>
                                </div>
                                <br />
                                <div class="formitem div1">
                                    <TCComDatePicker
                                        calType="DHM"
                                        v-model="div_search.cal_polYm"
                                        labelName="변경일시"
                                        :eRequired="true"
                                        :hourVal.sync="div_search.cal_polYmHour"
                                        :minuVal.sync="div_search.cal_polYmMin"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Bottom BTN Group -->

                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                            :objAuth="objAuth"
                        >
                            취소
                        </TCComButton>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            @click="onConfirm"
                            :objAuth="objAuth"
                        >
                            확인
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->
                </div>

                <!-- Close BTN-->
                <a href="#none" class="layerClose b-close" @click="onClose()">
                    닫기
                </a>
                <!--//Close BTN-->
            </div>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
        </template>
    </TCComDialog>
</template>

<script>
import { HEADER } from '@/const/grid/bas/usm/basUsmDutypChgHstMgmtHeader'
// import moment from 'moment'
/**************************************************************************************************************
 * 공통 LIB import 영역
 **************************************************************************************************************/
import { NewLib } from '@/views/newlib'

export default {
    name: 'BasPdmPrcTbltnPolChgPopup',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            showAlertBool: false,
            headerText: '',
            alertBodyText: '',
            gridObj: {},
            gridHeaderObj: {},
            objAuth: {},
            view: HEADER,
            div_search: {
                cal_polYm: NewLib.cf_today(),
                aplyDtm: ['', ''], //[NewLib.cf_today(), NewLib.cf_today()],
                cal_polYmHour: '00',
                cal_polYmMin: '00',
                aplyStaHour: '',
                aplyStaMin: '',
                aplyEndHour: '',
                aplyEndMin: '',
                // aplyProd: '1',
                // addPrice: 0,
                // cmb_OpenCl: '',
                // edt_Rmks: '',
                rad_policy: ['1'],
            },
            v_aplyDtm: { visible: true, enable: true },
            v_rad_policy: { enable: false },
            ds_policy: [
                {
                    commCdVal: '1',
                    commCdValNm: '일반',
                },
                {
                    commCdVal: '2',
                    commCdValNm: '종결',
                },
            ],
            parentData: [],
        }
    },

    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)
        /****************** Grid **********************/
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        // 적용기간 diabled 처리
        this.v_aplyDtm.enable = false
        this.v_rad_policy.enable = false
        this.initGrid()
        console.log('NewLib.cf_today()', NewLib.cf_today())
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentData', value)
                this.div_search.aplyDtm[0] = value['aplyStaDtm']
                this.div_search.aplyDtm[1] = value['aplyEndDtm']
                this.div_search.aplyStaHour = value['aplyStaHour']
                this.div_search.aplyStaMin = value['aplyStaMin']
                this.div_search.aplyEndHour = value['aplyEndHour']
                this.div_search.aplyEndMin = value['aplyEndMin']
                // this.searchParam.prodCd = value['prodCd']
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    methods: {
        async initGrid() {
            //인디게이터 상태바 체크바 사용여부 default false 설정
            //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
            //Default false
            // this.gridObj.setGridState()
            // this.gridObj.setRows(this.parentData)
        },

        // 적용기간 변경 이벤트
        onAplyDtmChange(val) {
            console.log('onAplyDtmChange::::', val)
            this.div_search.aplyStaDtm = val[0]
            this.div_search.aplyEndDtm = val[1]
        },

        // 변경일시가 기존정책일시 사이인지 체크
        selectedChgDtmCheck() {
            let result = ''
            const divSearch = this.div_search
            const selected = divSearch.cal_polYm
                .concat(divSearch.cal_polYmHour, divSearch.cal_polYmMin)
                .replaceAll('-', '')
            const orginStaDtm = divSearch.aplyDtm[0]
                .concat(divSearch.aplyStaHour, divSearch.aplyStaMin)
                .replaceAll('-', '')
            const orginEndDtm = divSearch.aplyDtm[1]
                .concat(divSearch.aplyEndHour, divSearch.aplyEndMin)
                .replaceAll('-', '')
            console.log(`${selected} / ${orginStaDtm} / ${orginEndDtm}`)
            if (orginStaDtm < selected && selected < orginEndDtm) {
                result = true
            } else {
                result = false
            }
            return result
        },

        onConfirm() {
            const dateCheck = this.selectedChgDtmCheck()
            if (this.div_search.cal_polYm == '') {
                this.showAlertBool = true
                this.headerText = '가격표 정책변경팝업'
                this.alertBodyText = '변경일시를 선택해주세요.'
                return
            } else {
                if (!dateCheck) {
                    this.showAlertBool = true
                    this.headerText = '가격표 정책변경팝업'
                    this.alertBodyText =
                        '변경일시는 적용기간 사이로 적용되어야 합니다.'
                    return
                }
            }
            this.$emit('confirm', this.div_search)
            this.onClose()
        },

        onClose() {
            this.activeOpen = false
        },

        onChange(e) {
            console.log('eChange::::', e)
        },
    },
}
</script>
