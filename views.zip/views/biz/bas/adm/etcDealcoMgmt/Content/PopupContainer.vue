<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">
                    {{ title }}
                </p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <!-- 거래처등록구분 -->
                            <div class="formitem div1">
                                <TCComComboBox
                                    v-model="dtlParam.dealcoRgstClCd"
                                    :eRequired="true"
                                    labelName="거래처등록구분"
                                    :itemList="dealcoRgstClCdList"
                                    :objAuth="objAuth"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :filterFunc="filterRgstClCd"
                                    @change="setDealcoGrpCd"
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <!-- //거래처등록구분 -->
                            <div class="formitem div1">
                                <TCComComboBox
                                    v-model="dtlParam.dealcoGrpCd"
                                    :eRequired="true"
                                    labelName="거래처그룹"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :itemList="dealcoGrpCdList"
                                    @change="setDealcoClCd1"
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComComboBox
                                    v-model="dtlParam.dealcoClCd1"
                                    :eRequired="true"
                                    labelName="거래처구분"
                                    :objAuth="objAuth"
                                    :itemList="dealcoClCd1List"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                ></TCComComboBox>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComInput
                                    labelName="거래처명"
                                    :eRequired="true"
                                    v-model="dtlParam.dealcoNm"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComDatePicker
                                    calType="DHM"
                                    v-model="dtlParam.effStaDtm"
                                    :eRequired="true"
                                    labelName="유효시작일시"
                                    :hourVal.sync="dtlParam.effStaDtmHour"
                                    :minuVal.sync="dtlParam.effStaDtmMin"
                                    :objAuth="objAuth"
                                >
                                    <template #multiFrom>
                                        <div class="col9">
                                            <TCComTextField
                                                v-model="dtlParam.effStaDtmSec"
                                                :maxlength="2"
                                                inputRuleType="N"
                                                :objAuth="objAuth"
                                            ></TCComTextField>
                                        </div>
                                        <div class="col0">초</div>
                                    </template>
                                </TCComDatePicker>
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComDatePicker
                                    calType="DHM"
                                    v-model="dtlParam.effEndDtm"
                                    :eRequired="true"
                                    labelName="유효종료일시"
                                    :hourVal.sync="dtlParam.effEndDtmHour"
                                    :minuVal.sync="dtlParam.effEndDtmMin"
                                    :objAuth="objAuth"
                                >
                                    <template #multiFrom>
                                        <div class="col9">
                                            <TCComTextField
                                                v-model="dtlParam.effEndDtmSec"
                                                :maxlength="2"
                                                inputRuleType="N"
                                                :objAuth="objAuth"
                                            ></TCComTextField>
                                        </div>
                                        <div class="col0">초</div>
                                    </template>
                                </TCComDatePicker>
                            </div>
                        </div>
                        <div class="searchform" v-if="type === 'detail'">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    labelName="사용여부"
                                    v-model="dtlParam.delYn"
                                    :objAuth="objAuth"
                                    :itemList="delYn"
                                >
                                </TCComRadioBox>
                            </div>
                        </div>
                    </div>
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="save"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/etcDealcoMgmt/helpers'
import CommonMixin from '@/mixins'
import _ from 'lodash'
import { msgTxt } from '@/const/msg.Properties'
import { getTodayDate } from '@/utils/accUtil'

export default {
    name: 'PopupContainer',
    mixins: [CommonMixin],
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: (data) => {
                return data
            },
            required: false,
        },
    },
    data() {
        return {
            showFlag: false,
            title: '신규',
            type: 'create',
            objAuth: {},
            dtlParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoRgstClCd: '', // 거래처등록구분코드
                dealcoGrpCd: '', // 거래처그룹코드
                dealcoClCd1: '', // 거래처구분코드
                effStaDtm: '', // 유효시작일시
                effStaDtmHour: '', // 유효시작일시 (시)
                effStaDtmMin: '', // 유효시작일시 (분)
                effStaDtmSec: '', // 유효시작일시 (초)
                effEndDtm: '', // 유효종료일시
                effEndDtmHour: '', // 유효종료일시 (시)
                effEndDtmMin: '', // 유효종료일시 (분)
                effEndDtmSec: '', // 유효종료일시 (초)
                hstSeq: '', // 이력순번
                delYn: '', // 사용여부
            },
            delYn: [
                { commCdVal: 'N', commCdValNm: '사용' },
                { commCdVal: 'Y', commCdValNm: '미사용' },
            ],
            dealcoRgstClCdList: [{ commCdVal: '', commCdValNm: '선택' }], // 거래처등록구분
            dealcoGrpCdList: [{ commCdVal: '', commCdValNm: '선택' }], // 거래처등록구분
            dealcoClCd1List: [{ commCdVal: '', commCdValNm: '선택' }], // 거래처구분
        }
    },
    created() {
        this.initData()
    },
    computed: {
        ...serviceComputed,
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        dealcoRgstClCdList1: {
            get() {
                return this.DEALCO_RGST_CL_CD // 거래처등록구분
            },
        },
        dealcoGrpCdList1: {
            get() {
                return this.DEAL_CO_GRP // 거래처그룹
            },
        },
        dealcoClCd1List1: {
            get() {
                return this.ZBAS_C_00240 // 거래처구분
            },
        },
    },
    methods: {
        ...serviceMethods,
        open(param) {
            console.log('open-----', param)
        },
        close() {},
        //팝업닫기
        closeBtn: function () {
            this.initData()
            this.activeOpen = false
        },
        initParam() {
            this.dtlParam = {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoRgstClCd: 'ES', // 거래처등록구분코드
                dealcoGrpCd: '', // 거래처그룹코드
                dealcoClCd1: '', // 거래처구분코드
                effStaDtm: getTodayDate('YYYY-MM-DD'), // 유효시작일시
                effStaDtmHour: '0', // 유효시작일시 (시)
                effStaDtmMin: '0', // 유효시작일시 (분)
                effStaDtmSec: '0', // 유효시작일시 (초)
                effEndDtm: '9999-12-31', // 유효종료일시
                effEndDtmHour: '23', // 유효종료일시 (시)
                effEndDtmMin: '59', // 유효종료일시 (분)
                effEndDtmSec: '59', // 유효종료일시 (초)
                hstSeq: '', // 이력순번
                delYn: '', // 사용여부
            }
        },
        initData() {
            _.forEach(Object.keys(this.dtlData), (item) => {
                this.dtlParam[item] = this.dtlData[item]
            })

            if (!_.isEmpty(this.dtlParam.dealcoCd)) {
                this.title = '상세 팝업'
                this.type = 'detail'

                let newEffStaDtm = this.dtlParam.effStaDtm
                this.dtlParam.effStaDtm = newEffStaDtm.substring(0, 8)
                this.dtlParam.effStaDtmHour = newEffStaDtm.substring(8, 10)
                this.dtlParam.effStaDtmMin = newEffStaDtm.substring(10, 12)
                this.dtlParam.effStaDtmSec = newEffStaDtm.substring(12, 14)

                let newEffEndDtm = this.dtlParam.effEndDtm
                this.dtlParam.effEndDtm = newEffEndDtm.substring(0, 8)
                this.dtlParam.effEndDtmHour = newEffEndDtm.substring(8, 10)
                this.dtlParam.effEndDtmMin = newEffEndDtm.substring(10, 12)
                this.dtlParam.effEndDtmSec = newEffEndDtm.substring(12, 14)
            } else {
                this.initParam()
                this.defaultAssign_({
                    key: 'params',
                    value: [],
                })
            }
            this.setDealcoGrpCd(this.dtlParam.dealcoRgstClCd)
            this.setDealcoClCd1(this.dtlParam.dealcoGrpCd)
        },
        filterRgstClCd(items) {
            return items.filter(
                (item) =>
                    _.isEqual(item['addInfo1'], 'ETC') &&
                    _.isEqual(item['commCdVal'], 'ES')
            )
        },
        /**
         * 거래처그룹코드 셋팅
         * DC : 매장공통
         * DS : 매장개별
         * EC : 기타공통
         * ES : 기타개별
         * @param dealcoRgstClCd : 거래처등록구분코드
         */
        setDealcoGrpCd(dealcoRgstClCd) {
            let dealcoGrpCds = [{ commCdVal: '', commCdValNm: '선택' }]
            let dealcoClCd1s = [{ commCdVal: '', commCdValNm: '선택' }]
            const info = 'addInfo5' // 추가정보

            if (!_.isEmpty(dealcoRgstClCd)) {
                dealcoGrpCds = this.getFilterCode(
                    this.DEAL_CO_GRP, // 코드리스트
                    info, // 추가정보
                    dealcoRgstClCd // 필터코드
                )
                this.dealcoGrpCdList = dealcoGrpCds
            } else {
                this.dealcoGrpCdList = dealcoGrpCds
            }

            this.dealcoClCd1List = dealcoClCd1s
        },
        /**
         * 거래처구분코드 셋팅
         * @param dealcoGrpCd : 거래처그룹코드
         */
        setDealcoClCd1(dealcoGrpCd) {
            let dealcoClCd1s = [{ commCdVal: '', commCdValNm: '선택' }]
            const info = 'addInfo1' // 추가정보
            if (!_.isEmpty(dealcoGrpCd)) {
                dealcoClCd1s = this.getFilterCode(
                    this.ZBAS_C_00240, // 코드리스트
                    info, // 추가정보
                    dealcoGrpCd // 필터코드
                )
                this.dealcoClCd1List = dealcoClCd1s
            } else {
                this.dealcoClCd1List = dealcoClCd1s
            }
        },
        getFilterCode(codeList, info, filterCode) {
            let rtnCode = []
            _.forEach(codeList, (data) => {
                if (_.isEqual(data[info], filterCode)) {
                    rtnCode.push(data)
                }
            })
            return rtnCode
        },

        isTimeCheck(time) {
            return /([01][0-9]|2[0-3])[0-5][0-9][0-5][0-9]/g.test(time)
        },
        async save() {
            if (_.isEmpty(this.dtlParam.dealcoRgstClCd)) {
                this.showTcComAlert(
                    msgTxt.MSG_00047.replace(/%s/g, '거래처등록구분을')
                )
                return
            } else if (_.isEmpty(this.dtlParam.dealcoGrpCd)) {
                this.showTcComAlert(
                    msgTxt.MSG_00047.replace(/%s/g, '거래처그룹을')
                )
                return
            } else if (_.isEmpty(this.dtlParam.dealcoClCd1)) {
                this.showTcComAlert(
                    msgTxt.MSG_00047.replace(/%s/g, '거래처구분을')
                )
                return
            } else if (_.isEmpty(this.dtlParam.dealcoNm)) {
                this.showTcComAlert(msgTxt.MSG_00083.replace(/%s/g, '거래처명'))
                return
            } else if (_.isEmpty(this.dtlParam.effStaDtm)) {
                this.showTcComAlert(
                    msgTxt.MSG_00083.replace(/%s/g, '유효시작일시')
                )
                return
            } else if (_.isEmpty(this.dtlParam.effEndDtm)) {
                this.showTcComAlert(
                    msgTxt.MSG_00083.replace(/%s/g, '유효종료일시')
                )
                return
            }

            let effStaDtmTime =
                this.appendZero(this.dtlParam.effStaDtmHour) +
                this.appendZero(this.dtlParam.effStaDtmMin) +
                this.appendZero(this.dtlParam.effStaDtmSec)

            let effEndDtmTime =
                this.appendZero(this.dtlParam.effEndDtmHour) +
                this.appendZero(this.dtlParam.effEndDtmMin) +
                this.appendZero(this.dtlParam.effEndDtmSec)

            if (!this.isTimeCheck(effStaDtmTime)) {
                this.showTcComAlert('시작시간이 유효하지 않습니다.')
                return
            }
            if (!this.isTimeCheck(effEndDtmTime)) {
                this.showTcComAlert('종료시간이 유효하지 않습니다.')
                return
            }

            let reqParams = {}
            reqParams = { ...this.dtlParam }

            let effStaDtm = this.dtlParam.effStaDtm.replace(/-/g, '')
            let effEndDtm = this.dtlParam.effEndDtm.replace(/-/g, '')

            reqParams['effStaDtm'] = effStaDtm + effStaDtmTime
            reqParams['effEndDtm'] = effEndDtm + effEndDtmTime

            this.defaultAssign_({
                key: 'params',
                value: reqParams,
            })

            if (_.isEqual(this.type, 'create')) {
                await this.insert()
            } else {
                await this.update()
            }

            this.getEtcDealcoMgmtLst_()
                .then((data) => {
                    if (data === undefined && data.gridList.length === 0) {
                        this.showTcComAlert(msgTxt.MSG_00039.replace(/%s/g, ''))
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {})
        },
        async insert() {
            await this.rgstBasAdmEtcDealcoMgmt_()
                .then((data) => {
                    console.log('data -> ', data)
                    if (data !== 1) {
                        this.showTcComAlert('등록실패')
                    } else {
                        this.showTcComAlert('등록완료')
                        this.activeOpen = false
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                })
        },
        async update() {
            await this.uptBasAdmEtcDealcoMgmt_()
                .then((data) => {
                    if (data !== 1) {
                        this.showTcComAlert('수정실패')
                    } else {
                        this.showTcComAlert('수정완료')
                        this.activeOpen = false
                    }
                })
                .catch((error) => {
                    Promise.reject(error)
                })
                .finally(() => {
                    console.log('🚀 ~ file: PopupContainer.vue ~ finally')
                })
        },
        appendZero(value) {
            if (value.length == 1) {
                return '0' + value
            } else {
                return value
            }
        },
    },
    watch: {
        dealcoRgstClCdList1: {
            handler: function (values) {
                console.log('dealcoRgstClCd values ->', values)
                if (!_.isEmpty(values)) {
                    this.dealcoRgstClCdList = values
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
