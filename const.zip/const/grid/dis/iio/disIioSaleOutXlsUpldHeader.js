import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'outDt',
            dataType: ValueType.TEXT, // 일자
        },
        {
            fieldName: 'outPlcId',
            dataType: ValueType.TEXT, // 출고처코드
        },
        {
            fieldName: 'outPlcNm',
            dataType: ValueType.TEXT, // 출고처명
        },
        {
            fieldName: 'inPlcId',
            dataType: ValueType.TEXT, // 반품처코드
        },
        {
            fieldName: 'inPlcNm',
            dataType: ValueType.TEXT, // 반품처명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 상품명
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, // 색상명
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'errDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'outCl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'barCdTyp',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'amt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'unitPrc',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'outDt',
            fieldName: 'outDt',
            type: 'data',
            datetimeFormat: 'yyyy-MM-dd',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '일자',
            },
        },
        {
            name: 'outPlcId',
            fieldName: 'outPlcId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcNm',
            fieldName: 'outPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처명',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'inPlcId',
            fieldName: 'inPlcId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반품처코드',
                showTooltip: false,
            },
        },
        {
            name: 'inPlcNm',
            fieldName: 'inPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반품처명',
                showTooltip: false,
            },
            width: '200',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품명',
                showTooltip: false,
            },
            width: '180',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상명',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'errDesc',
            fieldName: 'errDesc',
            type: 'data',
            styles: {
                textAlignment: 'near',
            },
            header: {
                text: '오류사항',
                showTooltip: true,
            },
            renderer: {
                type: 'text',
                showTooltip: true,
            },
            width: '300',
        },
        {
            name: 'outCl',
            fieldName: 'outCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'mfactId',
            fieldName: 'mfactId',
            type: 'data',
            visible: false,
        },
        {
            name: 'prodCl',
            fieldName: 'prodCl',
            type: 'data',
            visible: false,
        },
        {
            name: 'barCdTyp',
            fieldName: 'barCdTyp',
            type: 'data',
            visible: false,
        },
        {
            name: 'amt',
            fieldName: 'amt',
            type: 'data',
            visible: false,
        },
        {
            name: 'unitPrc',
            fieldName: 'unitPrc',
            type: 'data',
            visible: false,
        },
    ],
}
