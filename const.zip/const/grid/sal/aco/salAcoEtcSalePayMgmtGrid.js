/*****************************************
 * 업무 그룹명 : 판매관리
 * 서브 업무명 : 소매매출-기타수납관리
 * 설 명 : 기타수납관리 Grid 헤더
 * 작 성 자 : 양현모
 * 작 성 일 : 2022.07.18
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'
export const SALE_PAY_HEADER = {
    fields: [
        {
            fieldName: 'gnrlSaleNo',
            dataType: ValueType.TEXT, // 판매관리번호
        },
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT, // 수납관리번호
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델
        },
        {
            fieldName: 'eqpMdlCd',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'eqpSerNo',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'payItem',
            dataType: ValueType.TEXT, //
        },
        {
            fieldName: 'payObjAmt',
            dataType: ValueType.NUMBER, // 매출금액
        },
        {
            fieldName: 'payDtm',
            dataType: ValueType.TEXT, // 수납일
        },
        {
            fieldName: 'payMgmtNo',
            dataType: ValueType.TEXT, // 수납번호
        },
        {
            fieldName: 'payMthdCd',
            dataType: ValueType.TEXT, // 수납방법
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 처리자ID
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT, // 처리자
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT, // 처리일시
        },
        {
            fieldName: 'opStCdNm',
            dataType: ValueType.TEXT, // 처리상태
        },
    ],
    columns: [
        {
            name: 'opStCdNm',
            fieldName: 'opStCdNm',
            type: 'data',
            width: '100',
            header: {
                text: '처리상태',
            },
            styleCallback(grid, dataCell) {
                // const ret = { styleName: '', renderer: {} }
                const ret = { styleName: '' }

                if (dataCell.value !== '미처리') {
                    ret.styleName = 'underLine'
                    // ret.styleName = 'orange-column'
                    // ret.renderer = { type: 'link' }
                }

                return ret
            },
        },
        {
            name: 'saleMgmtNo',
            fieldName: 'saleMgmtNo',
            type: 'data',
            width: '100',
            header: {
                text: '수납관리번호',
            },
        },
        {
            name: 'payObjAmt',
            fieldName: 'payObjAmt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '매출금액',
            },
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            width: '100',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            header: {
                text: '수납일',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            width: '100',
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            width: '100',
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '100',
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
            header: {
                text: '처리일시',
            },
        },
    ],
}
