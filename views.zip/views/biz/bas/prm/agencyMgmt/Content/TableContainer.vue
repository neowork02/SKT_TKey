<template lang="">
    <div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="agencyMgmtGridHeader1"
                ref="agencyMgmtGridHeader1"
                gridTitle="대리점목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="false"
                :isPageCnt="false"
                :editable="true"
                :isAddRow="true"
                :isDelRow="true"
                :addData="this.addData"
                @excelDownBtn="this.excelDownBtn"
                @addRowBtn="this.gridAddRowBtn"
                @chkDelRowBtn="this.gridchkDelRowBtn"
            />
            <TCRealGrid
                id="agencyMgmtGrid1"
                ref="agencyMgmtGrid1"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
        </div>
        <BasBcoOrgTreesPopup
            v-if="showBcoOrgTrees"
            :parentParam="searchParam"
            :rows="resultOrgTreeRows"
            :dialogShow.sync="showBcoOrgTrees"
            @confirm="onOrgTreeReturnData"
        />
        <BasBcoOutDealsPopup
            v-if="showBcoOutDeals"
            :parentParam="searchOutDealParam"
            :rows="resultOutDealRows"
            :dialogShow.sync="showBcoOutDeals"
            @confirm="onOutDealReturnData"
        />
        <SktAgencysPopup
            v-if="showSktAgencys"
            :parentParam="searchSktAgencys"
            :rows="resultAgencyRows"
            :dialogShow.sync="showSktAgencys"
            @confirm="onAgencyReturnData"
        />
    </div>
</template>
<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/agencyMgmt/helpers'
import { M_HEADER } from '@/const/grid/bas/prm/basPrmAgencyMgmtHeader'
import { CommonGrid } from '@/utils'
import CommonMsg from '@/utils/CommonMsg'
import { msgTxt } from '@/const/msg.Properties.js'
import moment from 'moment'
//import { forEach } from 'lodash'
//====================내부조직팝업(전체)팝업====================
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
//====================//내부조직팝업(전체)팝업====================
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
//====================대리점팝업====================
import SktAgencysPopup from './SktAgencysPopup'
//====================//대리점팝업====================

export default {
    name: 'BasPrmAgencyMgmtGrid1',
    components: {
        BasBcoOrgTreesPopup,
        BasBcoOutDealsPopup,
        SktAgencysPopup,
    },
    data() {
        return {
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridStyle: {
                height: '460px', //그리드 높이 조절
            },
            view: M_HEADER,
            layout: [
                'pagingSeq',
                'agencyRgstClCd', //등록구분
                'agencyClCd', //대리점구분
                'agencyTypCd', //대리점유형
                'operCmpNm', //운영사
                'agencyCd', //대리점코드
                'agencyNm', //대리점명
                'orgNm', //관리조직
                'cnsgHldPlcCd', //위탁창고
                'disAsgnYn', //자동배정
                'wlClYn', //유선이용여부
                'aplyStaDt', //적용시작일자
                'aplyEndDt', //적용종료일자
                'insUserId', //처리자ID
                'modUserNm', //처리자
                'modDtm', //처리일시
                'operDealcoCd', //정책운영사코드 //추가
                'orgCd', //대리점코드 //추가
                'ukeyOrgClCd', //UKEY대리점구분코드 //추가
                'ukeySubCd', //UKEY서브점코드 //추가
            ],
            //행추가시 기본값
            // addData: [
            //     '',
            //     '',
            //     '',
            //     '',
            //     '', //operCmpNm
            //     '', //agencyCd
            //     '', //agencyNm
            //     '', //orgNm test
            //     '',
            //     'N', //자동배정
            //     'N', //유선이용여부
            //     moment(new Date()).format('YYYYMMDD'),
            //     '99991231',
            //     '',
            //     '',
            //     '',
            //     '', //'operDealcoCd', //정책운영사코드 //추가
            //     '', //'orgCd', //대리점코드 //추가
            //     '', //'ukeyOrgClCd', //UKEY대리점구분코드 //추가
            //     '', //'ukeySubCd', //UKEY서브점코드 //추가
            // ],
            //행추가시 기본값 테스트용
            addData: [
                '',
                '',
                '',
                '',
                '', //operCmpNm 양반텔레콤
                '', //agencyCd
                '', //agencyNm
                '', //orgNm test
                '', //'cnsgHldPlcCd', //위탁창고
                'Y', //'disAsgnYn', //자동배정
                'N', //'wlClYn', //유선이용여부
                moment(new Date()).format('YYYYMMDD'),
                '99991231',
                '',
                '',
                '',
                '', //'operDealcoCd', //정책운영사코드 //추가 10001
                '', //'orgCd', //대리점코드 //추가
                '05', //'ukeyOrgClCd', //UKEY대리점구분코드 //추가
                '', //'ukeySubCd', //UKEY서브점코드 //추가
            ],
            //행추가,수정시 필수 입력 컬럼
            requiredCols: [
                'agencyRgstClCd', //등록구분
                'agencyClCd', //대리점구분
                'agencyTypCd', //대리점유형
                'operCmpNm', //운영사
                'agencyCd', //대리점코드
                'agencyNm', //대리점명
                'orgNm', //관리조직
                'disAsgnYn', //자동배정
                'wlClYn', //유선이용여부
                'aplyStaDt', //적용시작일자
                'aplyEndDt', //적용종료일자
                'operDealcoCd', //정책운영사코드 //추가
                'orgCd', //대리점코드 //추가
                'ukeyOrgClCd', //UKEY대리점구분코드 //추가
                //'ukeySubCd', //UKEY서브점코드 //추가 //AS-IS에서 할당하지 않음 dev-tkeyplus-miplatform\SKTPS\BAS\BASPRM00400.xml
            ],
            gridOnClick: '',
            //====================내부조직팝업(전체)팝업관련====================
            showBcoOrgTrees: false, // 내부조직팝업(전체) 팝업 오픈 여부
            searchParam: {
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultOrgTreeRows: [], // 내부조직팝업(전체) 팝업 오픈 여부
            popupRowIndex: '',
            //====================//내부조직팝업(전체)팝업관련==================
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '2X',
            },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            //====================대리점팝업관련====================
            showSktAgencys: false, // 대리점 팝업 오픈 여부
            searchSktAgencys: {
                agencyCd: '', // 대리점코드
                agencyNm: '', // 대리점명
            },
            resultAgencyRows: [], // 대리점 팝업 오픈 여부
            //====================//대리점팝업관련==================
        }
    },
    async mounted() {
        this.gridObj = this.$refs.agencyMgmtGrid1
        this.gridHeaderObj = this.$refs.agencyMgmtGridHeader1
        this.gridObj.gridView.setColumnLayout(this.layout)

        /*
         * indicatorBl  : 인디게이터 사용여부
         * stateBarBl   : 상태바 사용여부
         * checkBarBl   : 체크바 사용여부
         * footerBl     : Footer 사용여부
         */
        //this.$refs.agencyMgmtGrid1.setGridState(true, true, true, false)
        //    this.gridObj.setGridState()
        //setGridState(인디게이터(true/false), 상태바(true/false), 체크바(true/false), Footer(true/false))
        this.gridObj.setGridState(false, true, false, false)
        //체크바
        this.$refs.agencyMgmtGrid1.gridView.setCheckBar({
            visible: true,
        })
        //편집가능
        this.$refs.agencyMgmtGrid1.gridView.setEditOptions({
            editable: true,
            updatable: true,
        })
        //컬럼 고정
        this.gridObj.gridView.setFixedOptions({
            colCount: 3,
        })
        //dropdown combo
        await this.dropDownSetting()

        // this.gridOnClick =
        //     this.$refs.agencyMgmtGrid1.gridView.onCellButtonClicked
        // this.$refs.agencyMgmtGrid1.gridView.onCellButtonClicked = (
        //     grid,
        //     index,
        //     column
        // ) => {
        //     this.gridPopup(
        //         index.itemIndex,
        //         column.fieldName
        //     )
        // }
        this.$refs.agencyMgmtGrid1.gridView.onCellButtonClicked = (
            grid,
            index,
            column
        ) => {
            this.gridPopup(index.itemIndex, column.fieldName)
        }
    },
    computed: {
        ...serviceComputed,
        data1: {
            get() {
                return this.$data
            },
        },
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        saveAction1: {
            get() {
                return this.saveAction
            },
        },
    },
    methods: {
        ...serviceMethods,
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.GridSetData()
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, 9999, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
        excelDownBtn: function () {
            this.gridHeaderObj.exportGrid(
                `대리점관리목록_${moment(new Date()).format(
                    'YYYYMMDDHHmmss'
                )}.xls`
            )
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            //Grid Row 가져올때 페이지정보 Setting
            console.log(
                '🚀 ~ file: TableContainer.vue ~ line 129 ~ SetPaging ~ paging',
                this.paging
            )
            this.gridHeaderObj.setPageCount(this.paging) //TCRealGridHeader 계산식이 좀 이상함??
        },
        async loading(val) {
            await this.defaultAssign_({
                key: 'loadingShow',
                value: val,
            })
        },
        gridAddRowBtn: function () {
            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            let focuscell = this.gridObj.gridView.getCurrent()
            console.log(focuscell)
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)
        },
        gridDelRowBtn: function () {
            // one select line delete
            // @selDelRow="gridDelRowBtn"
            console.log('del current row')
            this.gridData.gridRows = this.gridHeaderObj.selDelRow()
        },
        gridchkDelRowBtn: function () {
            // Checked Row Delete Event
            //@chkDelRowBtn="gridchkDelRowBtn"
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
        },
        async dropDownSetting() {
            //등록구분
            await this.dropDownCmmonCodes_({
                key: 'AGENCY_RGST_CL',
                columnName: 'agencyRgstClCd',
                option: '선택',
            })
            await this.changeDropDown('agencyRgstClCd')
            //대리점구분
            await this.dropDownCmmonCodes_({
                key: 'AGENCY_PTN',
                columnName: 'agencyClCd',
                option: '선택',
            })
            await this.changeDropDown('agencyClCd')
            //대리점유형
            await this.dropDownCmmonCodes_({
                key: 'AGENCY_TYP',
                columnName: 'agencyTypCd',
                option: '선택',
            })
            await this.changeDropDown('agencyTypCd')
            //자동배정
            await this.dropDownCmmonCodes_({
                key: 'USE_YN',
                columnName: 'disAsgnYn',
                option: '선택',
            })
            await this.changeDropDown('disAsgnYn')
            //유선이용여부
            await this.dropDownCmmonCodes_({
                key: 'USE_YN',
                columnName: 'wlClYn',
                option: '선택',
            })
            await this.changeDropDown('wlClYn')
        },
        async changeDropDown(key) {
            let col1 = this.gridObj.gridView.columnByName(key)
            col1.values = this.commDropDown[key].values
            col1.labels = this.commDropDown[key].labels
            this.gridObj.gridView.setColumn(col1)
        },
        errorCellFocus(chkCell, message) {
            this.toasting_({
                message: message,
            })
            //cell focus : { index: -1, fieldName: '' }
            this.gridObj.validationChkGrid(chkCell)
        },
        validationCheck() {
            let index = this.gridObj.modifyGrid() //변경한 행 index 가져오기
            var chk = { index: -1, fieldName: '' }
            if (index.length) {
                for (var i = 0; i < index.length; i++) {
                    var row = this.gridObj.dataProvider.getJsonRow(
                        index[i],
                        true
                    )

                    if (
                        row.__rowState == 'created' ||
                        row.__rowState == 'updated'
                    ) {
                        //필수 입력 체크
                        if (this.requiredCols.length) {
                            // created(추가) / updated(수정) 인경우 필수입력항목 체크
                            for (var j = 0; j < this.requiredCols.length; j++) {
                                //필수입력항목이 누락된경우
                                if (!row[this.requiredCols[j]]) {
                                    chk.index = index[i]
                                    chk.fieldName = this.requiredCols[j]

                                    this.errorCellFocus(
                                        chk,
                                        this.gridObj.gridView.columnByField(
                                            chk.fieldName
                                        ).header.text + ' 필수 입력 입니다.'
                                    )
                                    return false
                                }
                            }
                        }

                        //적용일자 체크
                        let fromDt = moment(row.aplyStaDt, 'YYYYMMDD').toDate()
                        let toDt = moment(row.aplyEndDt, 'YYYYMMDD').toDate()
                        if (fromDt > toDt) {
                            chk.index = index[i]
                            chk.fieldName = 'aplyStaDt'

                            this.errorCellFocus(
                                chk,
                                '적용시작일자가 적용마지막일자 보다 큽니다.'
                            )
                            return false
                        }
                    }

                    //대리점 코드, 위탁창코 중복 체크
                    if (row.__rowState == 'created') {
                        let all1 = this.gridObj.dataProvider.getJsonRows(0, -1)
                        let dup1 = all1.filter(
                            (e) => e.agencyCd === row.agencyCd
                        )
                        //대리점 체크
                        if (dup1.length > 1) {
                            chk.index = index[i]
                            chk.fieldName = 'agencyCd'

                            this.errorCellFocus(chk, '중복코드 입니다.')
                            return false
                        }
                        //위탁창고 체크
                        let dup2 = all1.filter(
                            (e) => e.cnsgHldPlcCd === row.cnsgHldPlcCd
                        )
                        if (dup2.length > 1 && row.cnsgHldPlcCd != '') {
                            chk.index = index[i]
                            chk.fieldName = 'cnsgHldPlcCd'

                            this.errorCellFocus(chk, '중복코드 입니다.')
                            return false
                        }
                    }
                }
            } else {
                if (!this.gridData.delRows.length) {
                    this.toasting_({
                        message: msgTxt.MSG_01002,
                    })
                    return false
                }
            }

            return true
        },
        async saveData() {
            this.loading(true)
            let saveRows = []

            for (let i = 0; i < this.gridData.delRows.length; i++) {
                let e = this.gridData.delRows[i]
                saveRows.push({
                    ...e,
                    rowState: e.__rowState,
                    //agencyCd: e.agencyCd, //UKEY대리점코드
                })
            }

            var arr = []
            var cIndex = this.gridObj.dataProvider.getStateRows('created')
            var uIndex = this.gridObj.dataProvider.getStateRows('updated')
            arr.push(...cIndex)
            arr.push(...uIndex)
            for (var i = 0; i < arr.length; i++) {
                var row = this.gridObj.dataProvider.getJsonRow(arr[i], true)
                saveRows.push({
                    ...row,
                    rowState: row.__rowState,
                })
            }

            console.log('crud api call', saveRows)

            let res1
            await this.saveAgencyMgmt_({ saveRows })
                .then((res) => {
                    res1 = res
                })
                .finally(() => {
                    this.loading(false)
                    if (res1 === 1) {
                        this.toasting_({
                            message: '정상처리 되었습니다.',
                        })

                        //정상등록시 다시 조회
                        this.$emit('Refresh', '')

                        //그리드 초기화 하는 경우
                        //this.gridObj.gridInit()
                    }
                })
        },
        gridPopup(row, col) {
            //참고 dev-tkeyplus-miplatform\SKTPS\BAS\BASPRM00400.xml
            //운영사 공통 팝업 : 외부거래처 팝업(공통)
            //TODO : 공통 개발 리스트에 있으나 공통 에 생성되어 있지 않음.(외부거래처-제조사)
            if (col == 'operCmpNm') {
                //TODO operDealcoCd, operCmpNm 값을 팝업에서 받아와야 함
                this.showBcoOutDeals = true
                this.resultOutDealRows = []
                this.popupRowIndex = row
            }
            //
            //UKEY대리점 공통 팝업 : UKEY대리점(공통)
            //등록구분 swing 선택시 팝업 그외는 수기 입력 가능
            //TODO : 공통 개발 리스트에 없음. 별도 추가 개발 요망
            if (col == 'agencyCd') {
                //TODO agencyCd , agencyNm, ukeyOrgClCd  값을 팝업에서 받아와야 함
                this.resultAgencyRows = []
                this.showSktAgencys = true
                this.popupRowIndex = row
            }
            //관리조직 공통 팝업 : 내부조직팝업(전체)(공통)
            if (col == 'orgNm') {
                //TODO orgCd , orgNm 값을 팝업에서 받아와야 함
                this.resultOrgTreeRows = []
                this.showBcoOrgTrees = true
                this.popupRowIndex = row
            }
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onOrgTreeReturnData(retrunData) {
            this.gridObj.gridView.commit()
            console.log('retrunData: ', retrunData)
            this.gridObj.dataProvider.setValue(
                this.popupRowIndex,
                'orgCd',
                retrunData.orgCd
            )
            this.gridObj.dataProvider.setValue(
                this.popupRowIndex,
                'orgNm',
                retrunData.orgNm
            )
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            this.gridObj.gridView.commit()
            console.log('retrunData: ', retrunData)
            this.gridObj.dataProvider.setValue(
                this.popupRowIndex,
                'operDealcoCd',
                retrunData.dealcoCd
            )
            this.gridObj.dataProvider.setValue(
                this.popupRowIndex,
                'operCmpNm',
                retrunData.dealcoNm
            )
            console.log('retrunData: ', retrunData)
        },
        // 대리점 팝업 리턴 이벤트 처리
        onAgencyReturnData(retrunData) {
            this.gridObj.gridView.commit()
            console.log('retrunData: ', retrunData)
            this.gridObj.dataProvider.setValue(
                this.popupRowIndex,
                'agencyCd',
                retrunData.orgCd
            )
            this.gridObj.dataProvider.setValue(
                this.popupRowIndex,
                'agencyNm',
                retrunData.orgNm
            )
            this.gridObj.dataProvider.setValue(
                this.popupRowIndex,
                'ukeyOrgClCd',
                retrunData.ukeyOrgClCd
            )
            console.log('retrunData: ', retrunData)
        },
    },
    watch: {
        // eslint-disable-next-line no-unused-vars
        resultList1(val, oldVal) {
            //console.log('resultList1 watched: ', val, oldVal, this.pageSize)
            //this.$refs.agencyMgmtGrid1.setRows(this.resultList)
            this.gridObj.gridView.commit()
            this.gridObj.setRows(this.resultList)

            //this.gridData = this.GridSetData() //초기화
        },
        // eslint-disable-next-line no-unused-vars
        paging1(val, oldVal) {
            //console.log('paging1 watched: ', val, oldVal)
            this.SetPaging()
        },
        async saveAction1(val, oldVal) {
            if (val == true) {
                console.log('saveAction1: ', val, oldVal)
                this.gridObj.gridView.commit()

                console.log(
                    '변경 데이타',
                    this.gridObj.modifyGrid(), // 추가/수정 건 체크
                    this.gridData.delRows
                )
                //bug ?? saveRows 로는 추가/수정 건을 알수 없음.
                //console.log('변경 데이타 saverows ', this.gridData.saveRows)

                if (this.validationCheck()) {
                    await this.saveData()
                } else {
                    console.log('validation false')
                }

                //에러든 정상종료든 완료되면 flag처리
                await this.defaultAssign_({
                    key: 'saveDoneA',
                    value: true,
                })

                //temp 임시로 두개의 saveAction 이 있다고 간주
                await this.defaultAssign_({
                    key: 'saveDoneB',
                    value: true,
                })
            }
        },
    },
}
</script>
