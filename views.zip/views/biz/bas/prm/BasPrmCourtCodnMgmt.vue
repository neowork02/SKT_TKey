<template>
    <div class="content">
        <!-- Tit -->
        <h1>권역별 배송사 매핑관리</h1>
        <!-- Top BTN  STA-->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onUpdate"
                    :objAuth="objAuth"
                >
                    수정
                </TCComButton>
                <BasPrmCourtCodnMgmtPop
                    v-if="showBasPrmCourtCodnMgmtPop === true"
                    ref="popup"
                    :dialogShow.sync="showBasPrmCourtCodnMgmtPop"
                    @confirm="onPopReturnData"
                />
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clear"
                    :objAuth="objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    :disabled="saveDisable"
                    @click="onSave"
                    :objAuth="objAuth"
                >
                    저장
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onDelete"
                    :objAuth="objAuth"
                >
                    삭제
                </TCComButton>
            </li>
        </ul>
        <!-- Top BTN  END-->
        <!-- contBoth STA-->
        <div class="contBoth">
            <!-- searchLayer_wrap STA -->
            <div class="searchLayer_wrap">
                <!-- serachform STA -->
                <div class="searchform">
                    <div class="formitem div4">
                        <TCComInput
                            v-model="searchParam.rgnNm"
                            :maxlength="12"
                            labelName="권역명"
                            :objAuth="objAuth"
                        />
                    </div>
                    <div class="formitem div4">
                        <TCComInput
                            v-model="searchParam.rgnCd"
                            :maxlength="12"
                            labelName="권역코드"
                            :objAuth="objAuth"
                        />
                    </div>
                    <div class="formitem div4">
                        <TCComComboBox
                            v-model="searchParam.svcObjCd"
                            labelName="서비스대상"
                            :itemList="svcComb"
                            :addBlankItem="true"
                            :blankItemText="'전체'"
                            :objAuth="objAuth"
                        ></TCComComboBox>
                    </div>
                    <div class="formitem div4">
                        <TCComInput
                            v-model="searchParam.siDoNm"
                            :maxlength="12"
                            labelName="시도명"
                            :objAuth="objAuth"
                        />
                    </div>
                </div>
                <div class="searchform">
                    <div class="formitem div4">
                        <TCComInput
                            v-model="searchParam.siGunGuNm"
                            :maxlength="12"
                            labelName="시군구명"
                            :objAuth="objAuth"
                        />
                    </div>

                    <div class="formitem div4">
                        <TCComInput
                            v-model="searchParam.ldongNm"
                            :maxlength="12"
                            labelName="법정동명"
                            :objAuth="objAuth"
                        />
                    </div>
                    <div class="formitem div2"></div>
                </div>
                <!-- searchForm END  -->
            </div>
            <!-- searchform 엑셀업로드 STA-->
            <div class="searchLayer_wrap">
                <div class="searchform">
                    <div class="formitem div4">
                        <TCComFileInput
                            v-model="files"
                            labelName="파일선택"
                            @change="onFilesChange"
                        ></TCComFileInput>
                    </div>
                    <div class="formitem div4_6">
                        <div class="rightArea btn">
                            <span class="inner">
                                <TCComButton
                                    labelName="오류검증"
                                    eClass="btn_s btn_ty03"
                                    eAttr="ico_verification"
                                    :Vuetify="false"
                                    :disabled="errVerithDisable"
                                    @click="errCheck"
                                />
                                <TCComButton
                                    labelName="오류일괄제거"
                                    eClass="btn_s btn_ty03"
                                    eAttr="ico_del"
                                    :Vuetify="false"
                                    :disabled="errDeleteDisable"
                                    @click="errClear"
                                />
                                <TCComButton
                                    labelName="양식다운로드"
                                    eClass="btn_s btn_ty03"
                                    eAttr="ico_save"
                                    :Vuetify="false"
                                    @click="excelTemplateDownBtn"
                                />
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- searchform END 엑셀업로드 -->
        </div>
        <!-- contBoth END -->

        <!-- gridWrap STA -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="권역별배송사매핑관리"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                :isAddRow="true"
                @addRowBtn="this.gridAddRowBtn"
                @excelDownBtn="this.excelDown"
            />
            <TCRealGrid
                id="gridTable"
                ref="gridTable"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
            />
            <TCComPaging
                :totalPage="gridData1.totalPage"
                :apiFunc="getPrmLdong"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt1"
            />
            <TCRealGridHeader
                v-show="false"
                id="gridHeaderExcel"
                ref="gridHeaderExcel"
                gridTitle="엑셀업로드 양식다운로드(숨김)"
                :gridObj="gridObj3"
            />
            <TCRealGrid
                v-show="false"
                id="gridExcel3"
                ref="gridExcel3"
                :gridObj="gridObj3"
                :fields="view.fields"
                :columns="view.columns2"
            />
        </div>
        <!-- gridWrap END -->
    </div>
</template>

<style></style>

<script>
import BasPrmCourtCodnMgmtPop from './BasPrmCourtCodnMgmtPop'

import commonApi from '@/api/common/commonCode'
import { GRID_HEADER } from '@/const/grid/bas/prm/basPrmCourtCodnMgmtHeader'
import { CommonGrid, FileUtil } from '@/utils'
import { msgTxt } from '@/const/msg.Properties.js'
import basPrmApi from '@/api/biz/bas/prm/basPrmCourtCodnMgmt'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMixin from '@/mixins'
import _ from 'lodash'
import * as XLSX from 'xlsx'
export default {
    name: 'BasPrmCourtCodnMgmt',
    components: {
        BasPrmCourtCodnMgmtPop,
    },
    mixins: [CommonMixin],
    props: {},
    data() {
        return {
            //====================공통기능====================
            objAuth: {},
            searchParam: {
                rgnNm: '',
                rgnCd: '',
                svcObjCd: '',
                siDoNm: '',
                siGunGuNm: '',
                ldongNm: '',
            },
            //GRID
            gridObj: {},
            gridHeaderObj: {},
            gridHeaderObjExcel: {},
            gridObj3: {},
            view: GRID_HEADER,

            svcComb: [],

            // paging
            rowCnt: 15,
            pageNum: 1,
            pageSize: 15,
            gridData1: {},

            //file
            files: null,

            errDeleteDisable: null,
            saveDisable: null,
            errVerithDisable: null,
            fvFile: 0, //0 엑셀업로드가 아님, 1: 엑셀업로드

            // POPUP
            showBasPrmCourtCodnMgmtPop: false,
        }
    },

    created() {
        this.gridData1 = this.gridSetData(this.rowCnt)
    },

    mounted() {
        this.gridObj = this.$refs.gridTable
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'
        this.gridObj.gridView.onEditRowChanged = this.onEditRowChanged
        this.gridObj.setGridState(true, false, true, false)

        // 엑셀양식다운로드 Grid 기본세팅(Hiddened)
        this.gridObj3 = this.$refs.gridExcel3
        this.gridHeaderObjExcel = this.$refs.gridHeaderExcel
        this.gridObj3.setGridState(false, false, false)

        this.dropDownSetting()
    },

    computed: {},
    methods: {
        onPopReturnData(returnData) {
            const checkRows = this.gridObj.gridView.getCheckedRows(true)
            checkRows.forEach((row) => {
                this.gridObj.gridView.setValue(row, 'svcObjCd', returnData)
                this.gridObj.gridView.setValue(row, 'svcObjNm', returnData)
            })
        },
        // 그리드에 변경된 값이 행에 반영될때 발생
        onEditRowChanged(grid, itemIndex, dataRow, field) {
            if (field === 2) {
                const value = grid.getValue(itemIndex, field)
                this.gridObj.gridView.setValue(itemIndex, 'rgnCd', value)
            }

            if (field === 4) {
                const value = grid.getValue(itemIndex, field)
                this.gridObj.gridView.setValue(itemIndex, 'svcObjCd', value)
            }
        },
        async dropDownSetting() {
            await commonApi
                .getCommonCodeListById('ZBAS_C_00820')
                .then((data) => {
                    let col = this.gridObj.gridView.columnByName('rgnNm')
                    col.values = data.map((m) => m.commCdVal)
                    col.labels = data.map((m) => m.commCdValNm)
                })

            await commonApi
                .getCommonCodeListById('ZBAS_C_00830')
                .then((data) => {
                    let col = this.gridObj.gridView.columnByName('svcObjNm')
                    col.values = data.map((m) => m.commCdVal)
                    col.labels = data.map((m) => m.commCdValNm)

                    this.svcComb = data
                })
        },

        setInit() {
            this.gridObj.gridInit()
            this.errDeleteDisable = false // 오류일괄제거버튼 활성화
            this.errVerithDisable = false // 오류검증버튼 활성화
            this.saveDisable = false // 저장버튼 활성화
            this.searchParam = {
                pageSize: this.rowCnt,
                pageNum: 1,
            }
            this.fvFile = 0
        },

        /* 초기화 */
        clear() {
            console.log('🚀 ~ file: basprmdirarrvlmgmt.vue ~ Clear()')
            this.setInit()
            this.files = null
        },

        /* 엑셀다운로드 */
        excelDown() {
            if (this.fvFile == 1) {
                this.openAlert('엑셀업로드 이후에 다운로드 가능합니다.')
                return
            }

            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.openAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }

            attachedFileApi.downLoadFile(
                '/api/v1/backend-max/resource/bas/prm/getLdongCodnXlsDload',
                this.searchParam
            )
        },
        //양식다운로드
        excelTemplateDownBtn() {
            attachedFileApi.downloadSampleFile('502')
        },

        /* CRUD STA */
        // 조회 버튼
        onSearch() {
            console.log('🚀 ~ file: BASPRMCOURTCODN.vue ~ onSearch')
            this.gridObj.gridView.commit()
            this.gridData1.totalPage = 0
            this.getPrmLdong(1)
        },

        // 조회
        getPrmLdong(pageNum) {
            let paramObj = { ...this.searchParam }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt

            basPrmApi.getLdongCodn(paramObj).then((resultData) => {
                if (_.isEmpty(resultData.gridList)) {
                    this.openAlert('조회된 데이터가 없습니다')
                    return
                }
                this.gridObj.setRows(resultData.gridList)
                this.gridObj.setGridIndicator(resultData.pagingDto) // 순번이 필요한경우 계산하는 함수
                this.gridData1 = this.gridSetData(this.rowCnt) //초기화
                this.gridData1.totalPage = resultData.pagingDto.totalPageCnt
                // GridHeader (총 ?건)
                this.gridHeaderObj.setPageCount(resultData.pagingDto)
            })
        },

        // 저장
        onSave: function () {
            this.gridObj.gridView.commit()

            if (this.fvFile == 1) {
                // 엑셀 업로드시
                const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
                if (rowData.length === 0) {
                    // msgTxt.MSG_00071
                    this.openAlert('처리할 대상이 없습니다.') // '처리할 대상이 없습니다.'
                    return
                }
                console.log(
                    '🚀 ~ file: BASPRMCOURTCODN.vue ~ onSave fvFile 1',
                    rowData
                )
                this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                    if (confirm) {
                        basPrmApi
                            .updateLdongCodn({
                                basPrmCourtCodnMgmtListDto: rowData,
                            })
                            .then((res) => {
                                if (res === 1) {
                                    this.fvFile = 0
                                    this.onSearch()
                                    this.errVerithDisable = true
                                    this.errDeleteDisable = true
                                }
                            })
                    }
                })
            } else {
                let jsonData = this.getGridEditRows()
                if (jsonData.length === 0) {
                    // msgTxt.MSG_00071
                    this.openAlert('처리할 대상이 없습니다.') // '처리할 대상이 없습니다.'
                    return
                }
                console.log(
                    '🚀 ~ file: BASPRMCOURTCODN.vue ~ onSave fvFile 0',
                    jsonData
                )
                this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                    if (confirm) {
                        basPrmApi
                            .updateLdongCodn({
                                basPrmCourtCodnMgmtListDto: jsonData,
                            })
                            .then((res) => {
                                if (res === 1) {
                                    this.onSearch()
                                    this.errVerithDisable = false // 활성화
                                    this.errDeleteDisable = false // 활성화
                                }
                            })
                    }
                })
            }
        },

        // 수정
        onUpdate: function () {
            this.showBasPrmCourtCodnMgmtPop = true
        },

        //삭제
        onDelete() {
            let checkRows = this.gridObj.gridView.getCheckedRows(true)
            if (checkRows.length <= 0) {
                this.openAlert('처리할 대상이 없습니다.')
                return
            }

            for (var i = 0; i < checkRows.length; i++) {
                if (
                    !_.isEmpty(
                        this.gridObj.gridView.getValue(
                            checkRows[i],
                            'oldLdongCd'
                        )
                    )
                ) {
                    this.openAlert('추가된 대상만 삭제 가능합니다.')
                    return
                }
            }

            this.gridObj.gridView.commit()
            this.gridObj.dataProvider.removeRows(checkRows)
        },
        /* CRUD END */

        getGridEditRows: function () {
            // 아래 commit을 해야 Row 값을 가져올 수 있음
            this.gridObj.gridView.commit()
            const arr = []
            const cIndex = this.gridObj.dataProvider.getStateRows('created')
            const uIndex = this.gridObj.dataProvider.getStateRows('updated')
            // 행삭제 옵션 중에 Row를 바로 삭제하는 옵션 아닌 것을 쓸 때에는 getStateRows 할 수 있음
            arr.push(...cIndex)
            arr.push(...uIndex)

            let jsonData = []
            arr.forEach((data) => {
                jsonData = [
                    ...jsonData,
                    ...this.gridObj.dataProvider.getJsonRows(data, data, true),
                ]
            })
            return jsonData
        },
        // 로우추가
        gridAddRowBtn: function () {
            this.gridObj.gridView.commit()

            let rowCount = this.gridObj.dataProvider.getRowCount()
            let rowData = {
                NO: rowCount + 1,
            }
            this.gridObj.dataProvider.insertRow(rowCount, rowData)

            // 행추가 되면 해당 위치로 focused 하기
            let focuscell = this.gridObj.gridView.getCurrent()
            focuscell.dataRow =
                this.gridObj.dataProvider.getRows(0, -1).length - 1
            this.gridObj.gridView.setCurrent(focuscell)

            this.gridObj.gridView.commit()
        },

        onFilesChange(files) {
            this.setInit()
            this.fvFile = 1
            this.errDeleteDisable = true // 오류일괄제거버튼 비활성화
            this.errVerithDisable = false // 오류검증버튼 활성화
            this.saveDisable = true // 저장버튼 비활성화
            this.excelUploadFile(files)
        },

        excelUploadFile(files) {
            const f = files
            if (!_.isUndefined(f) && !_.isNull(f)) {
                const reader = new FileReader()
                // const name = f.name

                reader.onload = (e) => {
                    const data = e.target.result

                    // Array Buffer인 경우 base64로 변환 처리
                    const arr = FileUtil.arrayBufferFixdata(data)
                    const workbook = XLSX.read(FileUtil.encodeBase64(arr), {
                        type: 'base64',
                        cellText: true,
                        cellDates: true,
                    })
                    // 워크북 처리(1줄 헤더 포함 처리)
                    this.processWorkbook(workbook)
                }
                // binary
                // reader.readAsBinaryString(f)
                // Array Buffer
                reader.readAsArrayBuffer(f)
            }
        },

        // file
        // 오류검증 버튼 이벤트
        errCheck: function () {
            if (this.fvFile == 0) {
                this.openAlert(msgTxt.MSG_00106)
                return
            }

            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)

            if (
                rowData.length == 0 ||
                (rowData.length == 1 && _.isEmpty(rowData[0].rgnCd))
            ) {
                this.openAlert(msgTxt.MSG_00106)
                return
            }
            basPrmApi.chkRgnbyExcel(rowData).then((res) => {
                this.errDeleteDisable = false // 오류일괄제거버튼 활성화
                this.errVerithDisable = true // 오류검증버튼 비활성화
                this.gridObj.setRows(res)
            })
        },

        // 오류일괄제거 버튼 이벤트
        errClear: function () {
            if (this.fvFile == 0) {
                this.openAlert(msgTxt.MSG_00106)
                return
            }

            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.(데이터 없음)')
                return
            }
            if (_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('처리할 데이터가 없습니다.(에러 없음)')
                this.saveDisable = false // 저장버튼 활성화
                this.errDeleteDisable = true // 오류일괄제거버튼 비활성화
            } else {
                this.gridObj.dataProvider.removeRows(this.getErrRow())
                this.saveDisable = false // 저장버튼 활성화
                this.errDeleteDisable = true // 오류일괄제거버튼 비활성화
            }
        },

        // 워크북 처리(1줄 헤더 포함 처리)
        processWorkbook(wb) {
            const output = FileUtil.excelTojson(wb, {
                raw: false,
            })
            const sheetNames = Object.keys(output)
            if (sheetNames.length) {
                const colsObj = output[sheetNames][0]
                if (colsObj) {
                    const data = output[sheetNames]
                    console.log('processWorkbook: ', output[sheetNames])
                    if (data.length > 3000) {
                        this.showTcComAlert(
                            '1회당 업로드 데이터는 3000건까지 가능합니다.'
                        )
                        return
                    } else {
                        this.gridObj.gridView.commit()
                    }
                    const mappedData = data.map((item) => {
                        return {
                            rgnCd: item['권역코드'],
                            svcObjCd: item['서비스대상코드'],
                            sktLdongCd: item['SKT법정동코드'],
                            ldongCd: item['PS법정동코드'],
                            ldongNm: item['PS법정동명'],
                            siDoCd: item['시도코드'],
                            siDoNm: item['시도명'],
                            siGunGuCd: item['시군구코드'],
                            siGunGuNm: item['시군구명'],
                        }
                    })
                    this.gridObj.dataProvider.fillJsonData(mappedData, {})
                }
            } else {
                this.openAlert(msgTxt.MSG_00106)
            }
        },

        //오류ROW 조회
        getErrRow() {
            let errRow = []
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            rowData.forEach((data, i) => {
                if (!_.isEmpty(_.get(data, 'errDesc'))) {
                    errRow.push(i)
                }
            })
            return errRow
        },

        // Alert창 호출
        openAlert(alertBodyTxt) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: '450',
            })
        },

        // 페이징 처리
        // 페이지 표시 행의 수 변경처리
        chgRowCnt1(val) {
            this.rowCnt = val
        },

        //GridSet Init
        gridSetData(rowCnt) {
            return new CommonGrid(0, rowCnt, '', '')
        },
    },

    watch: {},
}
</script>
