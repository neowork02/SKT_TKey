import Vue from 'vue'
import VueRouter from 'vue-router'
import GuideLayout from '@/views/guide/guidelayout/GuideLayout'
// import GuideContent from '@/views/guide/guidelayout/GuideContent'
// import GuideLeft from '@/views/guide/guidelayout/GuideLeft'

Vue.use(VueRouter)

const routes = [
    {
        path: '/guide',
        component: GuideLayout,
        redirect: '/guide/guidemain',
        // meta: {
        //     breadcrumb: 'sample',
        //     key: 'TDCS.sample',
        // },
        children: [
            {
                path: 'guidemain',
                component: () => import('@/views/guide/button/button.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            {
                path: 'form',
                component: () => import('@/views/guide/form/form.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            {
                path: 'form/paging',
                component: () => import('@/views/guide/form/paging.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            {
                path: 'form/treeview',
                component: () => import('@/views/guide/form/treeview.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            {
                path: 'form/treeviewcom',
                component: () => import('@/views/guide/form/Treeviewcom.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            // {
            //     path: 'form/TreeviewDrag',
            //     component: () => import('@/views/guide/form/TreeviewDrag.vue'),
            //     // meta: {
            //     //     breadcrumb: 'sample.grid',
            //     //     key: 'TDCS.sample.grid',
            //     // },
            // },
            {
                path: 'form/progress',
                component: () => import('@/views/guide/form/progress.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            {
                path: 'title',
                component: () => import('@/views/guide/title/title.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            {
                path: 'datapicker',
                component: () =>
                    import('@/views/guide/datapicker/datapicker.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            {
                path: 'tab',
                component: () => import('@/views/guide/tab/tab.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            {
                path: 'search',
                component: () => import('@/views/guide/search/search.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            {
                path: 'modal',
                component: () => import('@/views/guide/modal/modal.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            {
                path: 'grid',
                component: () => import('@/views/guide/grid/grid.vue'),
                // meta: {
                //     breadcrumb: 'sample.grid',
                //     key: 'TDCS.sample.grid',
                // },
            },
            // {
            //     path: 'GuideContent',
            //     component: GuideContent,
            //     // meta: {
            //     //     breadcrumb: 'sample.grid',
            //     //     key: 'TDCS.sample.grid',
            //     // },
            // },
            // {
            //     path: 'GuideLeft',
            //     component: GuideLeft,
            //     // meta: {
            //     //     breadcrumb: 'sample.grid',
            //     //     key: 'TDCS.sample.grid',
            //     // },
            // },
        ],
    },
]

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch((err) => {
        if (err.name !== 'NavigationDuplicated') throw err
    })
}

export default routes
