import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'saleMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleMgmtSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payAmt',
            dataType: ValueType.NUMBER,
        },
    ],

    columns: [
        {
            name: 'saleMgmtNo',
            fieldName: 'saleMgmtNo',
            type: 'data',
            width: '150',
            header: { text: '수납번호' },
            editable: false,
        },
        {
            name: 'saleMgmtSeq',
            fieldName: 'saleMgmtSeq',
            type: 'data',
            width: '150',
            header: { text: '수납순번' },
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '150',
            editable: false,
            header: {
                text: '수납의뢰처',
            },
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            header: { text: '수납의뢰처명' },
            type: 'data',
            width: '150',
        },
        {
            name: 'payAmt',
            fieldName: 'payAmt',
            type: 'data',
            header: { text: '금액' },
            width: '150',
            styleName: 'right-column',
            numberFormat: '#,###,###,##0',
            footer: {
                expression: 'sum',
                numberFormat: '#,###,###,##0',
                styleName: 'right-column',
            },
        },
    ],
}
