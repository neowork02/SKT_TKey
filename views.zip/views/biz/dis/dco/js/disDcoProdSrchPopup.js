export const Prod = {
    chk: '', // 체크여부
    prodNm: '', //모델명
    prodCd: '', //모델코드
    prodClNm: '', //상품구분명
    prodClCd: '', //상품구분코드
    mfactNm: '', //제조사명
    mfactCd: '', //제조사코드
    eqpClCd: '', // 단말기구분
    unitPrc: '', //단가
    barCdTypCd: '', // 바코드유형코드
    sktOperYn: '', //SKT운영여부
    prodChrticCd1: '', //상품특성코드1
    prodChrticCd2: '', //상품특성코드2
    mktgDt: '', //출시일자
    endDt: '', //단종일자
    useYn: '', //사용여부
    useStopDt: '', //사용중지일자
    rgstClCd: '', //등록구분코드
    rmks: '', //비고
    delYn: '', //삭제여부
    updCnt: '', //수정횟수
    insDtm: '', //입력일시
    insUserId: '', //입력사용자ID
    modDtm: '', //수정일시
    modUserId: '', //수정사용자ID
    cashPrchsPrc: '', //최초등록출고가격
    /* 색상 정보 */
    colorCd: '', // 색상
    colorNm: '', //색상명
    rawColorCd: '',
    /* 바코드 정보 */
    serNum: '', //번호
    badYn: '', //불량여부
    badYnNm: '', //불량여부명
    disStCd: '', //재고상태
    disStNm: '', //재고상태명
    lastInoutClCd: '', //최종입출고구분코드
    lastInoutDtlClCd: '', //최종입출고상세구분코드
    errDesc: '', //오류내용
    errorClCd: '', //오류코드
    /* swing 정보 */
    seq: '', //번호
    opDt: '', //처리일자
    opTm: '', //if처리일자
    rgstSeq: '', //등록순번
    reflYn: '', //반영여부
    inoutSchdDt: '', //입고예정일
    inoutPlcCd: '', //입출고처코드
    inoutPlcNm: '', //입출고처명
    inoutClCd: '', //입출고구분코드
    inoutClNm: '', //입출고구분명
    toSerNo: '', //종료일련번호
    sktOrgCd: '', //SKT조직코드
    sktSubOrgCd: '', //SKT서브조직코드
    sknRnpTypCd: '', //SKN수불유형코드
    sknOpClCd: '', //SKN처리구분코드
    prodClCdNm: '', //상품구분코드
    inQty: '',
    fixYn: '', //수정여부
}
