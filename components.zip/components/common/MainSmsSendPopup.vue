<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">SMS 전송</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="contBoth">
                        <!-- left area -->
                        <div class="div3_7 cont1 left">
                            <div class="smsboxWrap">
                                <div class="smsMsg">
                                    <div class="desc">
                                        <!-- [2022-07-11] 수정 : TCComTextArea 으로 변경 -->
                                        <TCComTextArea
                                            v-model="searchParam.context"
                                            labelName=""
                                            class="boxtype"
                                            :rows="6"
                                            :maxLength="
                                                searchParam.setMaxLength
                                            "
                                            placeholder="입력하세요"
                                            @input="sendByte"
                                        />
                                        <!-- //[2022-07-11] 수정 : TCComTextArea 으로 변경 -->
                                        <!-- 전송SMS전송SMS전송SMS전송SMS전송SMS전송
                                        SMS전송SMS전송SMS전송SMS전송
                                        SMS전송SMS전송SMS전송SMS전송 SMS전송SMS
                                        전송 -->
                                    </div>
                                    <div class="information">
                                        <span
                                            >{{ contextByte }}/{{
                                                maxByte
                                            }}
                                            Byte</span
                                        >
                                        <button
                                            type="button"
                                            @click="smsClear()"
                                        >
                                            다시쓰기
                                        </button>
                                    </div>
                                </div>

                                <div class="receiver">
                                    <h4 class="subTit">
                                        수신인 {{ cSendArray.length }}명 / 최대
                                        500명
                                    </h4>
                                    <div class="memberWrap">
                                        <ul>
                                            <li
                                                v-for="(
                                                    item, idx
                                                ) in cSendArray"
                                                v-bind:key="idx"
                                            >
                                                <span class="name">{{
                                                    item.userNm
                                                }}</span>
                                                <span class="num">{{
                                                    item.repMblPhonNo
                                                }}</span>
                                                <button
                                                    type="button"
                                                    class="close"
                                                    @click="
                                                        sendSendTelNoDel(item)
                                                    "
                                                ></button>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="number">
                                    <h4 class="subTit">발신번호</h4>
                                    <div>
                                        <p>
                                            <TCComComboBox
                                                v-model="searchParam.rtnTelNo"
                                                :itemList="numberData"
                                                itemText="rtnTelNo"
                                                itemValue="rtnTelNo"
                                                :addBlankItem="false"
                                                :objAuth="objAuth"
                                            ></TCComComboBox>
                                        </p>

                                        <p class="overflow">
                                            <TCComDatePicker
                                                v-model="searchParam.tranDd"
                                                :calType="calType4"
                                                :hourVal.sync="searchParam.hh"
                                                :minuVal.sync="searchParam.mm"
                                            >
                                            </TCComDatePicker>
                                        </p>
                                    </div>
                                </div>
                                <!-- Bottom BTN -->
                                <div class="bottom">
                                    <button
                                        type="button"
                                        class="btn_bottom left"
                                        @click="saveSendMessage()"
                                    >
                                        보내기
                                    </button>
                                    <button
                                        type="button"
                                        class="btn_bottom right"
                                        @click="clearPhoneImg"
                                    >
                                        초기화
                                    </button>
                                </div>
                                <!-- // Bottom BTN -->
                            </div>
                        </div>
                        <!-- //left area -->
                        <!-- right area -->
                        <div class="div3_7 cont2 right sms">
                            <div class="contBoth mt-20">
                                <!-- left area_inner -->
                                <div class="div4_6 cont4 left pr10">
                                    <!-- subTit -->
                                    <div class="stitHead">
                                        <h4 class="subTit">주소록</h4>
                                    </div>
                                    <!-- // subTit -->
                                    <!-- Search_div -->
                                    <div class="searchLayer_wrap">
                                        <!-- Search_line 1 -->
                                        <div class="searchform">
                                            <!-- item 1-1 -->
                                            <div class="formitem div1 pr0">
                                                <TCComInputSearchText
                                                    v-model="searchParam.orgCd"
                                                    :codeVal.sync="
                                                        searchParam.orgNm
                                                    "
                                                    labelName="조직"
                                                    placeholder="입력해주세요"
                                                    :size="5000"
                                                    :disabledAfter="true"
                                                    :objAuth="objAuth"
                                                    @enterKey="
                                                        onAuthOrgTreeEnterKey
                                                    "
                                                    @appendIconClick="
                                                        onAuthOrgTreeIconClick
                                                    "
                                                    @input="onAuthOrgTreeInput"
                                                />
                                                <BasBcoAuthOrgTreesPopup
                                                    v-if="showBcoAuthOrgTrees"
                                                    :parentParam="searchParam"
                                                    :rows="
                                                        resultAuthOrgTreeRows
                                                    "
                                                    :dialogShow.sync="
                                                        showBcoAuthOrgTrees
                                                    "
                                                    @confirm="
                                                        onAuthOrgTreeReturnData
                                                    "
                                                />
                                            </div>
                                            <!-- //item 1-1 -->
                                        </div>
                                        <!-- //Search_line 1 -->
                                        <!-- Search_line 2 -->
                                        <div class="searchform">
                                            <!-- item 2-1 -->
                                            <div class="formitem div1 pr0">
                                                <TCComComboBox
                                                    v-model="
                                                        searchParam.classification
                                                    "
                                                    labelName="유형선택"
                                                    :itemList="mdlClData"
                                                    :objAuth="objAuth"
                                                    @change="onChangeCg"
                                                ></TCComComboBox>
                                            </div>
                                            <!-- //item 2-1 -->
                                        </div>

                                        <div
                                            class="searchform"
                                            v-if="searchNameDis"
                                        >
                                            <div class="formitem div1 pr0">
                                                <TCComInputSearch
                                                    v-model="searchParam.name"
                                                    labelName="검색"
                                                    placeholder="검색어없을시전체"
                                                    :objAuth="objAuth"
                                                    @enterKey="getSmsRight"
                                                    @appendIconClick="
                                                        getSmsRight
                                                    "
                                                />
                                            </div>
                                        </div>

                                        <!-- //Search_line 2 -->
                                        <!-- Search_line 3_Text area -->
                                        <div class="mb10">
                                            <!-- gridWrap -->
                                            <TCRealGridHeader
                                                id="gridHeaderC"
                                                ref="gridHeaderC"
                                                :gridObj="gridCobj"
                                                :isPageRows="true"
                                                :isExceldown="false"
                                                :isExcelup="false"
                                                :isPageCnt="false"
                                                class="mgt-20"
                                            />
                                            <TCRealGrid
                                                id="gridC"
                                                ref="gridC"
                                                :editable="true"
                                                :movable="false"
                                                :columnMovable="false"
                                                :fields="viewC.fields"
                                                :columns="viewC.columns"
                                                :styles="gridStyleC"
                                            />
                                            <!-- //gridWrap -->
                                        </div>
                                        <!-- //Search_line 3_Text area -->
                                    </div>
                                    <!-- //Search_div -->
                                </div>
                                <!-- //left area_inner -->
                                <!-- right area_inner -->
                                <div class="div4_6 cont5 right pl0">
                                    <!-- gridWrap -->
                                    <TCRealGridHeader
                                        id="gridHeaderR"
                                        ref="gridHeaderR"
                                        gridTitle="받는사람"
                                        :gridObj="gridRobj"
                                        :isPageRows="true"
                                        :isExceldown="false"
                                        :isExcelup="false"
                                        :isPageCnt="false"
                                    />
                                    <TCRealGrid
                                        id="gridR"
                                        ref="gridR"
                                        :editable="true"
                                        :movable="false"
                                        :columnMovable="false"
                                        :fields="viewR.fields"
                                        :columns="viewR.columns"
                                        :styles="gridStyleR"
                                    />
                                    <!-- //gridWrap -->
                                </div>
                            </div>
                        </div>
                        <!-- //right area -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="addSendTelNoBtn"
                            >번호추가</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="clearAllImg"
                            >초기화</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import CommonMixin from '@/mixins'
import { CommonGrid } from '@/utils'
import { CommonUtil } from '@/utils'
import { SacCommon } from '@/views/biz/sac/js'
import { GRID_C_HEADER } from '@/const/grid/common/mainSmsCenterHeader'
import { GRID_R_HEADER } from '@/const/grid/common/mainSmsRightHeader'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
import mainSmsSendPopupApi from '@/api/common/mainSmsSendPopupApi'
import commonApi from '@/api/common/commonCode'
import { stringByteLength } from '@/utils/accUtil'
import _ from 'lodash'
export default {
    name: 'MainSmsSendPopup',
    mixins: [CommonMixin],
    components: { BasBcoAuthOrgTreesPopup },
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
    },
    data() {
        return {
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchPopParam: {
                basMth: '',
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                vLevel: '', // 디스플레이제한레벨
                sLvlList: '', //선택가능레벨 '2,3' : as-is 와동일하게 쉼표로 나열
                all: 'N', //전체검색여부 Y or null , N..
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부

            //====================//내부조직팝업(권한)팝업관련==================
            searchParam: {
                orgCd: '', // 조직코드
                orgNm: '', // 조직코드
                orgLvl: '',
                orgClCd: '',
                dealCoClCd1: '',
                dealCoCd: '',
                dealCoNm: '',
                sendMsg: '',
                classification: '',
                grp: '',
                classificationGrp: '',
                code: '',
                rtnTelNo: '',
                context: '',
                tranDd: SacCommon.getToday(),
                hh: SacCommon.getTodayHh(),
                mm: SacCommon.getTodayMm(),
                setMaxLength: 0,
                name: '',
                codeId: '',
                lvOrgCd: '',
            },

            objAuth: {},
            gridCenterData: this.GridCenterData(),
            gridRightData: this.GridRightData(),
            gridCobj: {},
            gridRobj: {},
            gridHeaderRobj: {},
            gridHeaderCobj: {},
            //codeIDView: true,
            //codeIDViewVal: '',
            viewC: GRID_C_HEADER,
            viewR: GRID_R_HEADER,
            calType4: 'DHM',

            //유형
            mdlClData: [],
            //보내는사람
            numberData: [],

            //itemList1: ['홍길동', '김진수'],
            gridStyleC: {
                height: '351px', //그리드 높이 조절
            },
            gridStyleR: {
                height: '450px', //그리드 높이 조절
            },
            /*
            gridStyleCase1: {
                height: '351px', //그리드 높이 조절
            },
            gridStyleCase2: {
                height: '316px', //그리드 높이 조절
            },
            */
            value: '',
            rCheckArray: [],
            //수신자
            cSendArray: [],
            //저장param
            saveParam: {
                selectedUser: [],
                sms: {},
            },
            contextByte: '0',
            maxByte: 2000,
            searchNameDis: false,
        }
    },
    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        //시작시 세션정보 조직정보에 담는다.
        this.searchParam.orgCd = this.orgInfo.orgCd
        this.searchParam.orgNm = this.orgInfo.orgNm
        this.searchParam.orgLvl = this.orgInfo.orgLvl
        this.searchParam.orgClCd = this.orgInfo.orgLvl

        this.gridCobj = this.$refs.gridC
        this.gridHeaderCobj = this.$refs.gridHeaderC
        this.gridCobj.setGridState(false, false, false, false)
        //중간그리드 체크 제거
        this.gridCobj.gridView.setCheckBar({
            visible: false,
        })
        //컬럼 전체사이즈변경
        this.gridCobj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })

        //수정불가
        this.gridCobj.gridView.setEditOptions({
            editable: false,
        })
        this.gridCobj.gridView.setHeader({
            visible: false,
        })

        //그리드컬럼 안보이게
        this.gridCobj.gridView.columnByName('commCdVal').visible = false

        this.gridRobj = this.$refs.gridR
        this.gridHeaderRobj = this.$refs.gridHeaderR
        this.gridRobj.setGridState(false, false, true, false)
        //this.$refs.gridR.setRows(SAMPLE_D_DATA)

        this.gridRobj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })

        //수정불가
        this.gridRobj.gridView.setEditOptions({
            editable: false,
        })

        //그리드컬럼 안보이게
        this.gridRobj.gridView.columnByName('classificationGrp').visible = false
        this.gridRobj.gridView.columnByName('grp').visible = false
        this.gridRobj.gridView.columnByName('sktDealCd').visible = false

        //1.유형선택
        this.getCategoryList()
        //보내는사람 전화번호정보
        this.getSenderNumList()

        //상위공통코드 그리드 클릭이벤트
        this.gridCobj.gridView.onCellClicked = (grid, clickData) => {
            //빈곳클릭시작업없음
            if (undefined == clickData.dataRow) {
                return
            }
            //두번째그리드 초기화
            this.gridRobj.dataProvider.clearRows()
            //중앙유형리스트에서 코드값추출
            let commCdVal = grid.getValue(clickData.itemIndex, 'commCdVal')

            //삭제를 위해 유형+그룹 으로 해당 그리드에 셋팅한다.
            //유형+그룹으로 셋팅(쿼리 classificationGrp 에 넣어놓음.)하여야 현재 클릭되어있는 그룹을 셋팅한다.
            //실제 삭제시 선택한 유형(상단콤보박스) + 선택한 그룹(중앙그리드) + 선택한 받는사람(우측그리드) 로 찾아
            //현재 상태가  선택한 유형(상단콤보박스) + 선택한 그룹(중앙그리드) 와 같으면 수신인->받는사람 쪽으로 넘긴다. 다를경우 수신인에서 삭제만됨.
            //다시 그룹(중앙그리드)를 선택하여 클릭하면 수신인을 필터하여 받는사람에 뿌린다.
            //중앙그리드(그룹)은 없을 경우가 있기때문에 유형선택만 사용할때가 있다.(성명검색, 거래처검색, P코드검색)

            //this.searchParam.grp = commCdVal
            this.searchParam.classificationGrp =
                this.searchParam.classification + commCdVal

            this.getSmsRight(commCdVal)
        }
        //더블클릭시 수신인이동
        this.gridRobj.gridView.onCellDblClicked = (grid, clickData) => {
            //빈곳클릭시작업없음
            if (undefined == clickData.dataRow) {
                return
            }

            //더블클릭 시 한건씩 추가됨
            if (!this.arrayValidation(1)) {
                return false
            }

            const row = this.gridRobj.dataProvider.getJsonRow(clickData.dataRow)
            this.rCheckArray = []
            this.rCheckArray.push(row)

            const rCheckArry = this.rCheckArray
            const cSendArray = this.cSendArray
            rCheckArry.forEach((item) => {
                let inData = true
                cSendArray.forEach((itemR) => {
                    if (itemR.repMblPhonNo == item.repMblPhonNo) {
                        console.log('중복' + item.repMblPhonNo)
                        inData = false
                    }
                })
                if (inData) {
                    this.cSendArray.push(item)
                }
                inData = true
            })
            //추가후 초기화
            this.rCheckArray = []
            //그리드에서 클릭값삭제
            this.gridRobj.dataProvider.removeRow(clickData.itemIndex)

            //console.log(row)
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    /*
    watch: {
        parentParam: {
            handler: function () {},
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
    */
    methods: {
        sendByte(value) {
            this.contextByte = stringByteLength(value)

            /*
            -- 2000바이트 이상일경우 해당 글자의 글자수를 확인하여 MAX값에 적용하는 로직이었음.
            -- 바이트단위로 MAX값설정 옵션없음, 길이단위옵션만 있음.
            -- AS-IS 와같은 화면펑션설정시 복잡하고 경우의 수가 많음. (붙여넣기 및, key입력 대응이 복잡함.)
            -- 글자 바이트 표시 후 저장시 2000바이트 넘으면 ALRT창 으로 막는 방식으로 적용.

            //if (undefined == value || '' == value) return
            //alert(e.target.value)
            //alert(this.searchParam.context)
            //console.log(value)
            // console.log(stringByteLength(value))
            // console.log(this.contextByte)
            this.contextByte = stringByteLength(value)
            //키보드 입력으로 딱맞는경우
            if (this.contextByte == this.maxByte) {
                //this.showTcComAlert('불가')
                let sliceText = this.cutByLen(value, this.maxByte)
                this.contextByte = stringByteLength(sliceText)
                console.log(
                    'stringByteLength===========>',
                    stringByteLength(sliceText)
                )

                console.log('sliceText.length1:' + sliceText.length)
                this.searchParam.setMaxLength = sliceText.length
            } else if (
                //키보드 입력 한글
                this.contextByte == Number(this.maxByte) + 1 ||
                this.contextByte == Number(this.maxByte) + 2 ||
                this.contextByte == Number(this.maxByte) + 3
            ) {
                let sliceText = this.cutByLen(value, Number(this.maxByte))
                this.contextByte = stringByteLength(sliceText)
                console.log('sliceText.length2:' + sliceText.length)
                this.searchParam.setMaxLength = sliceText.length - 50
                //붙여넣기
            } else if (this.contextByte > this.maxByte) {
                let sliceText = this.cutByLen(value, this.maxByte - 3)
                this.contextByte = stringByteLength(sliceText)
                console.log('한꺼번에 붙여넣기:' + this.contextByte)
                console.log(
                    '한꺼번에 붙여넣기 sliceText.length:' + sliceText.length
                )
                this.searchParam.setMaxLength = sliceText.length - 1
                this.subByte(sliceText)
            } else if (this.contextByte < this.maxByte) {
                console.log('this.contextByte < this.maxByte')
                let sliceText = this.cutByLen(value, Number(this.maxByte))
                this.contextByte = stringByteLength(sliceText)
                this.searchParam.setMaxLength = this.maxByte
            } else {
                console.log('else')
                let sliceText = this.cutByLen(value, Number(this.maxByte))
                this.contextByte = stringByteLength(sliceText)
                this.searchParam.setMaxLength = sliceText.length
            }

            //console.log(sssss)
            //this.contextByte = contextByte
            // if (!(e.keyCode == 8 || e.keyCode == 46)) {
            //     this.subByte(value)
            // }
            */
        },
        /*
        subByte(sliceText) {
            console.log('context: ', this.searchParam.context)
            console.log('sliceText===========22222>', sliceText)
            this.searchParam.context = sliceText

        },

        cutByLen(str, maxByte) {
            let b
            let i
            let c
            for (b = i = 0; (c = str.charCodeAt(i)); ) {
                b += c >> 7 ? 2 : 1
                if (b > maxByte) break
                i++
            }
            return str.substring(0, i)
        },
        */

        smsClear() {
            this.searchParam.context = ''
            this.contextByte = 0
        },
        GridCenterData: function () {
            return new CommonGrid(0, 10, '', '')
        },
        GridRightData: function () {
            return new CommonGrid(0, 10, '', '')
        },
        //팝업닫기
        closeBtn: function () {
            this.activeOpen = false
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchPopParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchParam.basMth = _.get(res[0], 'basMth')
                        this.searchParam.orgCd = _.get(res[0], 'orgCd')
                        this.searchParam.orgNm = _.get(res[0], 'orgNm')
                        this.searchParam.orgLvl = _.get(res[0], 'orgLvl')
                        this.searchParam.orgClCd = _.get(res[0], 'orgLvl')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchPopParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchPopParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchParam.orgCd = ''
            this.searchParam.orgNm = ''
            this.gridCobj.dataProvider.clearRows()
            this.gridRobj.dataProvider.clearRows()
            this.mdlClData = []
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchParam.orgLvl = _.get(retrunData, 'orgLvl')
            this.searchParam.orgClCd = _.get(retrunData, 'orgLvl')
            //유형선택 콤보박스로드.
            this.getCategoryList()
            this.searchParam.classification = ''
            //그리드 초기화
            this.gridCobj.dataProvider.clearRows()
            this.gridRobj.dataProvider.clearRows()
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //2. 유형선택 변경 시
        async onChangeCg(items) {
            // this.gridCobj.dataProvider.clearRows()
            this.gridRobj.dataProvider.clearRows()
            //alert(items)
            //조직을 선택하지 않았을경우 유형선택불가
            if ('' == this.searchParam.orgNm) {
                this.showTcComAlert('조직선택 후 유형선택이 가능합니다', {
                    header: '선택불가',
                    size: '500',
                    confirmLabel: 'OK',
                })
                let radomCd = Math.random()
                this.searchParam.classification = radomCd
                //this.searchParam.classification = ''
                return
            }

            if (
                'ZBAS_C_00001' == items ||
                'ZBAS_C_00002' == items ||
                'ZBAS_C_00003' == items
            ) {
                //검색인풋박스 노출
                console.log(items)
                this.searchNameDis = true
                this.searchParam.name = ''

                this.gridStyleC.height = '316px'
                // alert(this.gridStyleC.height)
            } else {
                this.searchNameDis = false
                this.searchParam.name = ''

                this.gridStyleC.height = '351px'
                // alert(this.gridStyleC.height)
            }

            if ('ZBAS_C_00002' == items) {
                this.gridRobj.gridView.columnByName('sktDealCd').visible = true
            } else {
                this.gridRobj.gridView.columnByName('sktDealCd').visible = false
            }

            //console.log('=======================>', items)
            //console.log('=======================>', this.searchParam)
            //this.searchParam.orgLvl = '2'
            //items => code
            if ('' != items) {
                //삭제를 위한 유형+그룹에 일단 담아놓고 그룹선택시에 다시 담는다.
                //유형만 쓰는 경우도 있기 때문이다.
                this.searchParam.classificationGrp = items
                this.getCommonSmsTypList(items)
            }
        },

        // 유형선택 후 공통코드 선택 API
        getCommonSmsTypList(codeId) {
            this.searchParam.codeId = codeId
            commonApi.getCommonSmsTypList(this.searchParam).then((res) => {
                console.log(' === res', res)
                this.gridCobj.setRows(res)

                //console.log(' === res', res[0].commCdValNm)
                /*
                for (let i = 0; i < res.length; i++) {
                    this.items2.push(res[i])
                }
                */
            })
        },

        //유형선택
        getCategoryList() {
            var params = {}
            mainSmsSendPopupApi
                .getMainCategoryList(params)
                .then((resultData) => {
                    //Get Row Data
                    console.log(resultData)
                    this.mdlClData = resultData
                })
        },
        //발신번호
        getSenderNumList() {
            var params = {}
            mainSmsSendPopupApi
                .getMainSenderNumList(params)
                .then((resultData) => {
                    //Get Row Data
                    console.log(resultData)
                    this.numberData = resultData
                    console.log(
                        'this.numberData==============>',
                        this.numberData
                    )
                    //시작시 첫번째선택
                    this.searchParam.rtnTelNo = resultData[0].rtnTelNo
                })
        },
        //받는사람 조회완료
        getSmsRight(codeId) {
            this.searchParam.code = codeId

            mainSmsSendPopupApi
                .getMainSmsRight(this.searchParam)
                .then((resultData) => {
                    console.log('resultData======>', resultData)

                    //수신인에 있는 전화번호는 제거한후 그리드에 표시한다.
                    let cSendObj = this.cSendArray
                    let resultFilter = resultData.filter(
                        (item) =>
                            cSendObj.filter(
                                (i) => i.repMblPhonNo === item.repMblPhonNo
                            ).length == 0
                    )
                    //Get Row Data
                    this.gridRobj.setRows(resultFilter)
                    // this.gridData = this.GridSetData() //초기화

                    console.log('받는사람 조회완료')
                })
        },
        addSendTelNoBtn() {
            const checkedRows = this.gridRobj.gridView.getCheckedRows(false)

            console.log(checkedRows)

            if (!this.arrayValidation(checkedRows.length)) {
                return false
            }

            for (let i = 0; i < checkedRows.length; i++) {
                let rowData = this.gridRobj.dataProvider.getJsonRow(
                    checkedRows[i]
                )
                this.rCheckArray.push(rowData)
            }

            /*
            _.forEach(rows, (item, idx) => {
                //alert(item)
                console.log(item)
                console.log(idx)

                //체크된것만 배열에 담는다.
                //if (this.gridRobj.gridView.isCheckedItem(idx)) {
                this.rCheckArray.push(rowData)
                //}
            })
            */

            if (0 == this.rCheckArray.length) {
                this.showTcComAlert('체크된 내역이 없습니다.', {
                    header: '선택',
                    size: '500',
                    confirmLabel: 'OK',
                })
            }

            const rCheckArry = this.rCheckArray
            const cSendArray = this.cSendArray
            rCheckArry.forEach((item) => {
                let inData = true
                cSendArray.forEach((itemR) => {
                    if (itemR.repMblPhonNo == item.repMblPhonNo) {
                        console.log('중복' + item.repMblPhonNo)
                        inData = false
                    }
                })
                if (inData) {
                    this.cSendArray.push(item)
                }
                inData = true
            })

            this.rCheckArray = []
            console.log(this.cSendArray)
            console.log('this.cSendArray.length:', this.cSendArray.length)

            //체크된것 그리드에서 삭제
            const checkIdx = this.gridRobj.gridView.getCheckedRows(false)
            this.gridRobj.dataProvider.removeRows(checkIdx)
        },
        arrayValidation(moveRowLength) {
            let vCnt = 500 //기준
            let mCnt = this.cSendArray.length + moveRowLength

            if (vCnt < mCnt) {
                this.showTcComAlert('1회 최대전송건수는: ' + vCnt + '건입니다.')
                return false
            }
            return true
        },
        //보내는사람 삭제
        sendSendTelNoDel(item) {
            let repMblPhonNo = item.repMblPhonNo

            console.log(
                this.searchParam.classificationGrp,
                item.classificationGrp
            )

            /*
            alert(item.repMblPhonNo)
            alert(item.grp)
            console.log(item)

            alert(this.searchParam.code)
            alert(this.searchParam.code)
            */

            //삭제버튼클릭시 현재 선택한 유형선택, 중간그리드코드값인 그룹코드가 같으면 gridR에추가.
            if (this.searchParam.classificationGrp == item.classificationGrp) {
                let newRows = [
                    item.classificationGrp,
                    item.grp,
                    item.userNm,
                    item.repMblPhonNo,
                    item.orgNm,
                    item.sktDealCd,
                ]

                this.gridRobj.dataProvider.insertRow(0, newRows)
            }

            let delIdx
            this.cSendArray.forEach((itemR, idx) => {
                console.log(idx)
                if (itemR.repMblPhonNo == repMblPhonNo) {
                    delIdx = idx
                }
            })

            this.cSendArray.splice(delIdx, 1)
        },

        //보내기버튼클릭
        saveSendMessage() {
            if (!this.sendValidtation()) {
                return
            }

            this.showTcComConfirm('전송 하시겠습니까?').then((confirm) => {
                if (confirm) {
                    //보낼내용
                    this.saveParam.sms = {
                        title: '', //backend 사용안함.(프로시저에서 내용에서 컷하여 사용확인)
                        context: this.searchParam.context,
                        senderNm: '', //backend 사용안함.
                        rtnTelNo: this.searchParam.rtnTelNo,
                        tranDt: '', //예약전송 프로시저구현없음.
                        tranCnt: '', //backend 사용안함
                        tranUserId: this.userInfo.userId,
                        smsJobCl: '', //backend 에서 고정값처리 (기준정보:01)
                        smsTime: '', //backend 사용안함
                        sktAgencyCd: this.userInfo.sktAgencyCd, // 대리점코드
                        reservedDtm:
                            String(this.searchParam.tranDd)
                                .replace('-', '')
                                .replace('-', '') +
                            String(this.searchParam.hh) +
                            String(this.searchParam.mm),
                    }

                    //수신인
                    const cSendArray = this.cSendArray
                    this.saveParam.selectedUser = cSendArray

                    mainSmsSendPopupApi
                        .saveMainSendMessage(this.saveParam)
                        .then((res) => {
                            if (res) {
                                console.log('저장완료')
                            }
                        })

                    this.$emit('confirm', this.saveParam)
                }
            })
        },

        clearPhoneImg() {
            this.cSendArray.forEach((itemR, idx) => {
                console.log(idx)
                //전체 배열 돌면서 유형이 같은 경우에만 해당 유형 받는사람에 추가한다.
                //다른유형은 중간objC 클릭시 다시 노출된다.
                this.sendSendTelNoDel(itemR)
            })

            this.cSendArray = []
            this.searchParam.context = ''
        },
        clearAllImg() {
            this.gridCobj.dataProvider.clearRows()
            this.gridRobj.dataProvider.clearRows()

            this.searchParam.classification = ''
            //this.searchParam.orgCd = ''
            //this.searchParam.orgNm = ''
            //this.mdlClData = []

            this.rCheckArray = []
            this.cSendArray = []
        },
        sendValidtation() {
            let yDate =
                String(
                    this.searchParam.tranDd.replace('-', '').replace('-', '')
                ) +
                String(this.searchParam.hh) +
                String(this.searchParam.mm) +
                '00'

            if (CommonUtil.checkDate('S', yDate)) {
                this.showTcComAlert('예약발송시간을 확인하세요.', {
                    header: '전송불가',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }

            if (
                2000 < Number(this.contextByte) ||
                0 == Number(this.contextByte)
            ) {
                this.showTcComAlert(
                    '문자내용은 1 Byte 이상,  2000 Byte 이하만 가능합니다',
                    {
                        header: '전송불가',
                        size: '500',
                        confirmLabel: 'OK',
                    }
                )
                return false
            }
            if (0 >= this.cSendArray.length) {
                this.showTcComAlert('수신인이 존재하지 않습니다.', {
                    header: '전송불가',
                    size: '500',
                    confirmLabel: 'OK',
                })
                return false
            }

            return true
        },
    },
}
</script>
