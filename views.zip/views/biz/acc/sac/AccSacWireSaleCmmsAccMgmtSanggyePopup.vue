<template>
    <TCComDialog :dialogShow.sync="activeOpenAgency" size="1600px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">유선정산상계 팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- input -->
                            <div class="formitem div4">
                                <TCComInputSearchText
                                    v-model="searchParams.searchOrgNm"
                                    :codeVal.sync="searchParams.searchOrgCd"
                                    labelName="조직"
                                    :disabled="true"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                />
                            </div>
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="M"
                                    v-model="searchParams.searchAccYm_"
                                    :disabled="true"
                                >
                                </TCComDatePicker>
                            </div>
                            <div class="formitem div4"></div>
                            <!-- // input -->
                            <!-- item 2-4 -->
                            <div class="formitem div4">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="초기화"
                                            :objAuth="objAuth"
                                            @click="onSearch"
                                        >
                                        </TCComButton>
                                    </span>
                                </div>
                            </div>
                            <!-- //item 2-4 -->
                        </div>
                        <!-- // Search_line 1 -->
                    </div>
                    <div class="contBoth">
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGridHeader
                                id="gridGagamPopupHeader1"
                                ref="gridGagamPopupHeader1"
                                gridTitle="정산 상계"
                                :gridObj="gridObj"
                                :isAddRow="true"
                                :isDelRow="true"
                                :isExceldown="true"
                                @addRowBtn="gridAddRowBtn"
                                @chkDelRowBtn="gridChkDelRowBtn"
                                @excelDownBtn="exportExcelDown"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="gridGagamPopup1"
                                ref="gridGagamPopup1"
                                :editable="true"
                                :fields="view.fields"
                                :columns="view.columns"
                            />
                            <!-- 정산처 팝업 -->
                            <BasBcoDealcosPopup
                                v-if="basBcoDealcoShow"
                                :parentParam="searchAccDealcoParams"
                                :dialogShow.sync="basBcoDealcoShow"
                                @confirm="onDealcoReturnData"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onSave"
                        >
                            저장
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="onDelete"
                        >
                            삭제
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="onClose"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import _ from 'lodash'
import CommonMixin from '@/mixins'
import moment from 'moment'
import sacApi from '@/api/biz/acc/sac'
import commonApi from '@/api/common/prototype'
import { AccUtil } from '@/views/biz/acc'
import { GRID_HEADER } from '@/const/grid/acc/sac/accSacWireSaleCmmsAccMgmtSanggyePopupGrid'

//  내부거래처(권한조직)[정산처]
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//  내부거래처(권한조직)[정산처]

export default {
    name: 'AccSacWireSaleCmmsAccMgmtSanggyePopup',
    title: '정산 상계 팝업',
    mixins: [CommonMixin],
    components: {
        BasBcoDealcosPopup, //  내부거래처(권한조직)[정산처]
    },
    props: {
        //params
        popupParams: { type: Object, default: () => {}, required: false },

        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
    },
    data() {
        return {
            view: GRID_HEADER,
            objAuth: {},
            list: [],
            gridObj: {},
            gridHeaderObj: {},
            gridRows: 0,
            codeId: {
                accMtchClCd: 'WIRE_ACC_MTCH_ITM_CD',
            },
            defaultJson: {
                accYm: '',
                dataClCd: '0',
                dataClNm: '일반',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                lvOrgCd: '',
                orgTree: '',
                slClCd: 'N/',
            },
            paramJson: {},
            searchParams: {
                searchPageType: 'SANGGYE-POPUP',
                searchAccYm_: moment(this.popupParams.accYm).format('YYYY-MM'),
                searchAccYm: moment(this.popupParams.accYm).format('YYYYMM'),
                searchOrgCd: this.popupParams.orgCd,
                searchOrgNm: this.popupParams.orgNm,
                searchOrgLvl: this.popupParams.orgLvl,
                searchLvOrgCd: this.popupParams.lvOrgCd,
                searchAccDealcoCd: this.popupParams.accDealcoCd,
                // searchAccYm_: moment('201711').format('YYYY-MM'), // 테스트값 세팅
                // searchAccYm: moment('201711').format('YYYYMM'), // 테스트값 세팅
                // searchOrgCd: 'AB1154', // 테스트값 세팅
                // searchOrgNm: '도매영동PT', // 테스트값 세팅
                // searchOrgLvl: '3', // 테스트값 세팅
                // searchLvOrgCd: 'O00000', // 테스트값 세팅
                // searchAccDealcoCd: '77785', // 테스트값 세팅
                checkedRows: [],
            },

            //  내부거래처(권한조직)[정산처]
            basBcoDealcoShow: false,
            resultDealcoRows: [],
            gridDealcoIndex: -1,
            searchAccDealcoParams: {
                basDay: '',
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                lvOrgCd: '',
                dealcoCd: '',
                dealcoNm: '',
            },
            //  내부거래처(권한조직)[정산처]
        }
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpenAgency: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        // 수수료구분 combo 목록 세팅하기
        this.setComboAccMtchClCd()

        // grid 기본세팅
        this.gridObj = this.$refs.gridGagamPopup1
        this.gridHeaderObj = this.$refs.gridGagamPopupHeader1
        this.gridObj.setGridState()

        //체크바
        this.gridObj.gridView.setCheckBar({
            visible: true,
        })
        //편집가능
        this.gridObj.gridView.setEditOptions({
            editable: true,
            updatable: true,
        })

        // 그리드 내 아이콘 클릭시 오픈될 팝업 세팅
        this.gridObj.gridView.onCellButtonClicked = (grid, clickData) => {
            // 정산처 아이콘 클릭시 정산처 팝업 오픈
            if (clickData.fieldName == 'accDealcoCd') {
                this.gridDealcoIndex = clickData.itemIndex
                this.searchAccDealcoParams.basDay = AccUtil.dateToFormat(
                    grid.getValue(clickData.itemIndex, 'accYm'),
                    'YYYYMM'
                )
                this.searchAccDealcoParams.orgCd = grid.getValue(
                    clickData.itemIndex,
                    'orgCd'
                )
                this.searchAccDealcoParams.orgNm = grid.getValue(
                    clickData.itemIndex,
                    'orgNm'
                )
                this.searchAccDealcoParams.orgLvl = grid.getValue(
                    clickData.itemIndex,
                    'orgLvl'
                )
                this.searchAccDealcoParams.lvOrgCd = grid.getValue(
                    clickData.itemIndex,
                    'lvOrgCd'
                )
                this.searchAccDealcoParams.dealcoCd = grid.getValue(
                    clickData.itemIndex,
                    'accDealcoCd'
                )
                this.searchAccDealcoParams.dealcoNm = grid.getValue(
                    clickData.itemIndex,
                    'accDealcoNm'
                )

                // 정산처 팝업 오픈
                this.onDealcoIconClick()
            }
        }

        // 그리드 한번 클릭시 편집기 상태로 변경
        this.gridObj.gridView.onCellClicked = () => {
            this.gridObj.gridView.showEditor()
        }

        // 목록 조회
        this.onSearch()
    },
    watch: {
        'searchParams.searchAccYm_'(newVal) {
            this.searchParams.searchAccYm = newVal
            if (!_.isEmpty(newVal)) {
                this.searchParams.searchAccYm = newVal.replace(/-/g, '')
            }
        },
    },
    methods: {
        setParamJson: function (_method) {
            this.paramJson = _.cloneDeep(this.searchParams)

            // get방식으로 파라미터 넘길 때 오류로 인해 아래 제거함
            if (_method == 'GET') {
                delete this.paramJson['searchAccYm_']
                delete this.paramJson['checkedRows']
            }

            return this.paramJson
        },
        /* DB에서 처리할 수 있게 row데이터를 가공해서 return */
        getChangeRowData: function (rowData) {
            // 정산일 날짜를 String으로 변경한다.
            rowData.accYm = AccUtil.dateToFormat(rowData.accYm, 'YYYYMM')

            // 판매일 날짜를 String으로 변경한다.
            if (!AccUtil.isEmpty(rowData.saleDt)) {
                rowData.saleDt = AccUtil.dateToFormat(
                    rowData.saleDt,
                    'YYYYMMDD'
                )
            }

            return rowData
        },
        onSearch: function () {
            console.log('search')
            this.gridObj.gridView.commit()

            if (!this.popupParams.isSearch) {
                this.list = []
                this.gridObj.setRows(this.list)
                this.defaultJson.accYm = this.popupParams.accYm
                this.defaultJson.orgCd = this.popupParams.orgCd
                this.defaultJson.orgNm = this.popupParams.orgNm
                this.defaultJson.orgLvl = this.popupParams.orgLvl
                this.defaultJson.lvOrgCd = this.popupParams.lvOrgCd
                this.defaultJson.orgTree = this.popupParams.orgTree

                return
            }

            sacApi
                .getAccSacWireSaleCmmsAccMgmtList(this.setParamJson('GET'))
                .then((resultData) => {
                    if (!AccUtil.isEmpty(resultData) && resultData.length > 0) {
                        this.list = resultData
                        this.gridObj.setRows(this.list)
                        if (this.list && this.list.length > 0) {
                            this.searchParams.searchOrgNm = this.list[0].orgNm
                            this.defaultJson.accYm = this.list[0].accYm
                            this.defaultJson.orgCd = this.list[0].orgCd
                            this.defaultJson.orgNm = this.list[0].orgNm
                            this.defaultJson.orgNm = this.list[0].orgNm
                            this.defaultJson.orgLvl = this.list[0].orgLvl
                            this.defaultJson.orgTree = this.list[0].orgTree
                            this.defaultJson.slClCd = this.list[0].slClCd
                            this.gridRows = this.list.length
                        }
                    }
                })
        },
        onSaveValidate: function () {
            var checkedRows = this.gridObj.gridView.getCheckedRows(true)
            if (_.isEmpty(checkedRows)) {
                this.showTcComAlert('저장할 행을 선택해 주세요.')
                return false
            }

            var isOk = true
            this.searchParams.checkedRows = []
            for (var i = 0; i < checkedRows.length; i++) {
                var rowData = this.gridObj.gridView.getValues(checkedRows[i])

                if (_.isEmpty(rowData.accDealcoCd)) {
                    this.showTcComAlert('정산처를 선택해 주세요.')
                    isOk = false
                    break
                }

                if (_.isEmpty(rowData.accMtchClCd)) {
                    this.showTcComAlert('수수료구분을 선택해 주세요.')
                    isOk = false
                    break
                }

                // if (_.isEmpty(rowData.accMtchItmNm)) {
                //     this.showTcComAlert('수수료설명을 선택해 주세요.')
                //     isOk = false
                //     break
                // }

                if (
                    rowData.accMtchAmt == null ||
                    rowData.accMtchAmt == undefined ||
                    rowData.accMtchAmt == 0
                ) {
                    this.showTcComAlert('금액은 필수 입력 항목입니다.')
                    isOk = false
                    break
                }

                this.searchParams.checkedRows.push(
                    this.getChangeRowData(rowData)
                )
            }

            if (!isOk) {
                this.searchParams.checkedRows = []
            }

            return isOk
        },
        async onSave() {
            this.gridObj.gridView.commit()

            if (this.onSaveValidate() == false) {
                return
            }

            const confirmMsg = await this.showTcComConfirm(
                '정산상계를 저장하시겠습니까?'
            )
            if (!confirmMsg) {
                return
            }

            sacApi
                .saveAccSacWireSaleCmmsAccMgmtList(this.searchParams)
                .then((res) => {
                    console.log(res)
                    if (AccUtil.isEmpty(res)) {
                        return
                    }

                    if (res.resultCode == 'SUCCESS') {
                        this.showTcComAlert('저장되었습니다.')
                    } else if (res.resultCode == 'FAIL') {
                        this.showTcComAlert(res.resultMessage)
                    }

                    if (this.popupParams.isSearch) {
                        //  조회여부가 true일 경우만 재조회
                        //  +버튼으로 팝업이 오픈되었으면 False / 더블클릭으로 팝업이 오픈되었으면 true
                        this.onSearch()
                    } else {
                        //  +버튼으로 팝업이 오픈되었으면 Grid의 row를 모두 삭제한다.
                        var delteRowIds = []
                        var rowCount = this.gridObj.dataProvider.getRowCount()
                        for (var i = 0; i < rowCount; i++) {
                            delteRowIds.push(
                                this.gridObj.gridView.getDataRow(i)
                            )
                        }
                        this.gridObj.dataProvider.removeRows(delteRowIds)
                        this.gridObj.gridView.setAllCheck(false)
                        this.gridObj.gridView.commit()
                    }
                })
        },
        async onDelete() {
            var checkedRows = this.gridObj.gridView.getCheckedRows(true)
            if (_.isEmpty(checkedRows)) {
                this.showTcComAlert('삭제할 행을 선택해 주세요.')
                return
            }

            const confirmMsg = await this.showTcComConfirm(
                '정산상계를 삭제하시겠습니까?'
            )
            if (!confirmMsg) {
                return
            }

            this.searchParams.checkedRows = []
            for (var i = 0; i < checkedRows.length; i++) {
                var rowData = this.gridObj.gridView.getValues(checkedRows[i])
                this.searchParams.checkedRows.push(
                    this.getChangeRowData(rowData)
                )
            }

            this.gridObj.gridView.commit()
            sacApi
                .deleteAccSacWireSaleCmmsAccMgmtList(this.searchParams)
                .then((res) => {
                    console.log(res)
                    if (res.resultCode == 'SUCCESS') {
                        this.showTcComAlert('삭제되었습니다.')
                        this.onSearch()
                    } else if (res.resultCode == 'FAIL') {
                        this.showTcComAlert(res.resultMessage)
                    }
                })
        },
        onClose: function () {
            // 부모 함수 실행
            if (this.popupParams.isParentSearch) {
                this.$parent.onSearch()
            }

            // 팝업 닫기 실행
            this.activeOpenAgency = false
        },
        //Add Row Event
        gridAddRowBtn: function () {
            this.gridRows = this.gridHeaderObj.addRow(this.gridRows)
            var gridLastIndex = this.gridObj.dataProvider.getRowCount() - 1

            // checkbox에 체크하기
            // this.gridObj.gridView.checkItem(gridLastIndex, true)

            // 기본값 세팅하기
            this.gridObj.gridView.setValue(
                gridLastIndex,
                'accYm',
                this.defaultJson.accYm
            )
            this.gridObj.gridView.setValue(
                gridLastIndex,
                'dataClNm',
                this.defaultJson.dataClNm
            )
            this.gridObj.gridView.setValue(
                gridLastIndex,
                'orgCd',
                this.defaultJson.orgCd
            )
            this.gridObj.gridView.setValue(
                gridLastIndex,
                'orgNm',
                this.defaultJson.orgNm
            )
            this.gridObj.gridView.setValue(
                gridLastIndex,
                'orgLvl',
                this.defaultJson.orgLvl
            )
            this.gridObj.gridView.setValue(
                gridLastIndex,
                'lvOrgCd',
                this.defaultJson.lvOrgCd
            )
            this.gridObj.gridView.setValue(
                gridLastIndex,
                'orgTree',
                this.defaultJson.orgTree
            )
            this.gridObj.gridView.setValue(
                gridLastIndex,
                'slClCd',
                this.defaultJson.slClCd
            )
            /* 행추가로 추가한 row는 조회여부컬럼을 0으로 세팅한다. */
            this.gridObj.gridView.setValue(gridLastIndex, 'isAddRow', '1')
            this.gridObj.gridView.commit()
        },
        //Check Row Delete Event
        gridChkDelRowBtn: function () {
            var checkedRows = this.gridObj.gridView.getCheckedRows(true)
            if (_.isEmpty(checkedRows)) {
                this.showTcComAlert('삭제할 행을 선택해 주세요.')
            } else {
                var isExistAddRow = false
                for (var i = 0; i < checkedRows.length; i++) {
                    var rowJson = this.gridObj.gridView.getValues(
                        checkedRows[i]
                    )
                    if (rowJson.isAddRow != '1') {
                        isExistAddRow = true
                    }
                }

                if (isExistAddRow) {
                    this.showTcComAlert('삭제할 수 없는 행이 존재합니다.')
                    return
                }

                this.gridObj.dataProvider.removeRows(checkedRows)
                this.gridObj.gridView.commit()
            }
        },
        exportExcelDown: function () {
            if (this.list.length == 0) {
                this.showTcComAlert('출력할 데이터가 없습니다.')
                return
            }
            // this.gridHeaderObj.exportGrid('정산상계-팝업.xls')
            this.searchParams.excelFileName =
                '유선정산상계_세부내역_팝업' +
                '_' +
                this.searchParams.searchAccYm +
                '_' +
                this.searchParams.searchOrgNm +
                '_' +
                this.searchParams.searchAccDealcoNm

            sacApi
                .downloadAccSacWireSaleCmmsAccMgmtExcelDown(
                    this.setParamJson('GET')
                )
                .then(() => {
                    this.showTcComAlert('엑셀파일이 다운로드되었습니다.')
                })
        },
        // 수수료구분 combo 목록 가져와 세팅하기
        setComboAccMtchClCd: function () {
            commonApi
                .getCommonCodeList(this.codeId.accMtchClCd)
                .then((list) => {
                    var values = []
                    var labels = []
                    if (list.length > 0) {
                        list.map(function (item) {
                            values.push(item.commCdVal)
                            labels.push(item.commCdValNm)
                        })

                        var columns = this.view.columns
                        for (var i = 0; i < columns.length; i++) {
                            if (columns[i].name == 'accMtchClCd') {
                                columns[i].values = values
                                columns[i].labels = labels
                                columns[i].editor.values = values
                                columns[i].editor.labels = labels
                            }
                        }
                    }
                })
        },
        //===================== 내부거래처(권한조직)[정산처] methods ================================
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchAccDealcoParams)
                .then((res) => {
                    if (res.length === 1) {
                        // 검색된 내부거래처-권한조직 정보가 1건이면 TextField에 바로 설정
                        this.searchParams.searchAccDealcoCd = _.get(
                            res[0],
                            'dealcoCd'
                        )
                        this.searchParams.searchAccDealcoNm = _.get(
                            res[0],
                            'dealcoNm'
                        )
                    } else {
                        // 검색된 내부거래처-권한조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-권한조직 팝업 오픈
                        this.resultDealcoRows = res
                        this.basBcoDealcoShow = true
                    }
                })
        },
        onDealcoIconClick() {
            // 내부거래처(권한조직) Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 팝업오픈
            this.basBcoDealcoShow = true
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            this.resultDealcoRows = []
            if (_.isEmpty(this.searchParams.searchOrgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            if (_.isEmpty(this.searchParams.searchAccDealcoNm)) {
                this.showTcComAlert('정산처를 입력해주세요.')
                return
            }
            this.searchAccDealcoParams.orgCd = this.searchParams.searchOrgCd
            this.searchAccDealcoParams.orgNm = this.searchParams.searchOrgNm
            this.searchAccDealcoParams.orgLvl = this.searchParams.searchOrgLvl
            this.searchAccDealcoParams.dealcoCd =
                this.searchParams.searchAccDealcoCd
            this.searchAccDealcoParams.dealcoNm =
                this.searchParams.searchAccDealcoNm
            console.log(
                'BBBbbbb=>',
                this.searchAccDealcoParams,
                this.searchParams
            )
            // 내부거래처조회
            this.getDealcosList()
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 코드 초기화
            this.searchParams.searchAccDealcoCd = ''
        },
        // 내부거래처(권한조직) 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            if (this.gridDealcoIndex != -1) {
                this.gridObj.gridView.setValue(
                    this.gridDealcoIndex,
                    'accDealcoCd',
                    _.get(retrunData, 'dealcoCd')
                )
                this.gridObj.gridView.setValue(
                    this.gridDealcoIndex,
                    'accDealcoNm',
                    _.get(retrunData, 'dealcoNm')
                )
            }
        },
        //===================== //내부거래처(권한조직)[정산처] methods ================================
    },
}
</script>
