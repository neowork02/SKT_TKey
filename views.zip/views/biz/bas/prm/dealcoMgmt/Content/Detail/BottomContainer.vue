<template>
    <div>
        <div class="btn_area_bottom">
            <TCComButton eClass="btn_ty02_point" :eLarge="true"
                >확인</TCComButton
            >
            <TCComButton eClass="btn_ty02" :eLarge="true" @click="closeBtn"
                >닫기</TCComButton
            >
        </div>
        <!-- // Bottom BTN Group -->

        <!-- Close BTN-->
        <a href="#none" class="layerClose b-close" @click="closeBtn">닫기</a>
        <!--//Close BTN-->
    </div>
</template>

<script>
export default {
    name: 'BottomContainer',
    methods: {
        //팝업닫기
        closeBtn: function () {
            this.activeOpen = false
        },
    },
}
</script>

<style scoped></style>
