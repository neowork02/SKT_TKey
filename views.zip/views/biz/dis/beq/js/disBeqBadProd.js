export const BadProd = {
    rgstSeq: '', //번호
    opDt: '', //등록일자
    oprNm: '', //등록자
    chrgrUserNm: '', //영업담당
    dealCoClNm: '', //거래처 구분
    salePlcNm: '', //판매처
    sktChnlCd: '', //채널코드
    prodClNm: '', //상품구분
    eqpClCd: '', //단말기구분
    mfactNm: '', //제조사
    barNm: '', //바코드유형
    prodNm: '', //모델
    colorNm: '', //색상
    serNum: '', //일련번호
    ukeyExpartYn: '', //Swing교품여부
    opLclNm: '', //불량대분류
    opMclNm: '', //불량중분류
    badStNm: '', //불량상태
    badPlcNm: '', //등록보유처
    hldPlcNm: '', //현보유처
    lastInoutDtlClNm: '', //최종입출고
    opClNm: '', //처리구분
    opClCd: '', //처리구분코드
}

export const AddBadProd = {
    opDt: '',
    prodCd: 'A1E3',
    prodNm: 'A1E3',
    colorCd: '12',
    colorNm: '12',
    serNum: '',
    rgstSeq: '1',
    prodCl: '',
    prodClNm: '',
    mfactId: '',
    mfactNm: '',
    hldDealcoCd: '57553',
    hldDealcoNm: '역삼역점',
    oprId: '',
    oprNm: '',
    opLclCd: '1',
    opMclCd: '1',
    rmks: '',
    badYn: '',
    badYnNm: '',
    disSt: '',
    disStNm: '',
    posAgency: '',
    posAgencyNm: '',
    orgId: 'AA1211',
    orgNm: '강남소매(PT)',
    loginId: 'TEST',
}
