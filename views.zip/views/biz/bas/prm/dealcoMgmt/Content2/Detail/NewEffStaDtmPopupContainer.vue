<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="900px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">적용시작일자</p>

                <div class="layerCont">
                    <div class="stitHead">
                        <h4 class="subTit">적용시작일자</h4>
                    </div>
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComDatePicker
                                    calType="DHM"
                                    v-model="effStaDtm"
                                    :disabled="true"
                                    :eRequired="true"
                                    labelName="기존적용시작일자"
                                    :hourVal.sync="effStaDtmHour"
                                    :minuVal.sync="effStaDtmMin"
                                    :objAuth="objAuth"
                                >
                                    <template #multiFrom>
                                        <div class="col9">
                                            <TCComTextField
                                                v-model="effStaDtmSec"
                                                :disabled="true"
                                                :maxlength="2"
                                                inputRuleType="N"
                                                :objAuth="objAuth"
                                            ></TCComTextField>
                                        </div>
                                        <div class="col0">초</div>
                                    </template>
                                </TCComDatePicker>
                            </div>
                            <div class="formitem div2">
                                <TCComDatePicker
                                    calType="DHM"
                                    v-model="effEndDtm"
                                    :disabled="true"
                                    labelName=""
                                    :hourVal.sync="effEndDtmHour"
                                    :minuVal.sync="effEndDtmMin"
                                    :objAuth="objAuth"
                                >
                                    <template #multiFrom>
                                        <div class="col9">
                                            <TCComTextField
                                                v-model="effEndDtmSec"
                                                :disabled="true"
                                                :maxlength="2"
                                                inputRuleType="N"
                                                :objAuth="objAuth"
                                            ></TCComTextField>
                                        </div>
                                        <div class="col0">초</div>
                                    </template>
                                </TCComDatePicker>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComDatePicker
                                    calType="DHM"
                                    v-model="newEffStaDtm"
                                    :eRequired="true"
                                    labelName="신규적용시작일자"
                                    :hourVal.sync="newEffStaDtmHour"
                                    :minuVal.sync="newEffStaDtmMin"
                                    :objAuth="objAuth"
                                >
                                    <template #multiFrom>
                                        <div class="col9">
                                            <TCComTextField
                                                v-model="newEffStaDtmSec"
                                                :maxlength="2"
                                                inputRuleType="N"
                                                :objAuth="objAuth"
                                            ></TCComTextField>
                                        </div>
                                        <div class="col0">초</div>
                                    </template>
                                </TCComDatePicker>
                            </div>
                        </div>
                    </div>

                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            @click="save"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            @click="close"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a href="#none" class="layerClose b-close" @click="close"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/tDealcoMgmt/helpers'
import _ from 'lodash'

import CommonMixin from '@/mixins'
import { msgTxt } from '@/const/msg.Properties'

import basBcoSysClsInfoApi from '@/api/biz/bas/bco/basBcoSysClsInfo'
import moment from 'moment'
import { CommonUtil } from '@/utils'

export default {
    name: 'NewEffStaDtmPopupContainer',
    mixins: [CommonMixin],
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },
    data() {
        return {
            objAuth: {},
            effStaDtm: '', // 유효시작일시
            effStaDtmHour: '', // 유효시작일시 (시)
            effStaDtmMin: '', // 유효시작일시 (분)
            effStaDtmSec: '', // 유효시작일시 (초)
            effEndDtm: '', // 유효종료일시
            effEndDtmHour: '', // 유효종료일시 (시)
            effEndDtmMin: '', // 유효종료일시 (분)
            effEndDtmSec: '', // 유효종료일시 (초)
            newEffStaDtm: '', // 신규유효시작일시
            newEffStaDtmHour: '', // 신규유효시작일시 (시)
            newEffStaDtmMin: '', // 신규유효시작일시 (분)
            newEffStaDtmSec: '', // 신규유효시작일시 (초)
        }
    },
    mounted() {},
    computed: {
        ...serviceComputed,
        basPrmDealcoDtlVo: {
            get() {
                return this.basPrmDealcoDtlListVo // 거래처상세
            },
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        ...serviceMethods,
        save() {
            if (_.isEmpty(this.effStaDtm)) {
                this.showTcComAlert(
                    msgTxt.MSG_00083.replace(/%s/g, '유효시작일시')
                )
                return
            } else if (_.isEmpty(this.effEndDtm)) {
                this.showTcComAlert(
                    msgTxt.MSG_00083.replace(/%s/g, '유효종료일시')
                )
                return
            }
            let effStaDtmTime =
                this.appendZero(this.effStaDtmHour) +
                this.appendZero(this.effStaDtmMin) +
                this.appendZero(this.effStaDtmSec)

            let effEndDtmTime =
                this.appendZero(this.effEndDtmHour) +
                this.appendZero(this.effEndDtmMin) +
                this.appendZero(this.effEndDtmSec)

            if (!this.isTimeCheck(effStaDtmTime)) {
                this.showTcComAlert('시작시간이 유효하지 않습니다.')
                return
            }
            if (!this.isTimeCheck(effEndDtmTime)) {
                this.showTcComAlert('종료시간이 유효하지 않습니다.')
                return
            }

            // 기등록된 시작일시보다 +2 초가  커야 하고 기존종료일자 보다 작아야 한다.
            if (
                CommonUtil.onlyNumber(this.newEffStaDtmSec) <
                CommonUtil.onlyNumber(this.effStaDtmSec)
            ) {
                alert('기존 [적용시작일자] 보다 2초 커야 합니다.')
                return false
            } else if (
                CommonUtil.onlyNumber(this.newEffStaDtm) >=
                CommonUtil.onlyNumber(this.effEndDtm)
            ) {
                alert('기존 [적용종료일자] 보다 작아야 합니다.')
                return false
            }

            this.getClsStatus()
        },
        closeNewEffStaDtm() {
            let newDtm =
                this.newEffStaDtm.replace(/-/g, '') +
                this.newEffStaDtmHour +
                this.newEffStaDtmMin +
                this.newEffStaDtmSec
            this.defaultAssign_({
                key: 'newEffStaDtmParam',
                value: newDtm,
            })
            this.close()
        },
        close() {
            this.activeOpen = false
        },
        isTimeCheck(time) {
            return /([01][0-9]|2[0-3])[0-5][0-9][0-5][0-9]/g.test(time)
        },
        appendZero(value) {
            if (value.length == 1) {
                return '0' + value
            } else {
                return value
            }
        },
        async getClsStatus() {
            let searchData = {}
            searchData.gubun = 'D'
            searchData.strdDt = this.effStaDtm
            searchData.orgCd = '*'
            searchData.workClCd = 'SLS'

            await basBcoSysClsInfoApi
                .getCloseBisDayMth(searchData)
                .then((resultData) => {
                    console.log(resultData)
                    console.log('resultData.clsStCd ->', resultData.clsStCd)
                    if (_.isEqual(resultData.clsStCd, 'SLS')) {
                        let lastClsDtm = resultData.lastClsDtm
                        if (!_.isEmpty(lastClsDtm)) {
                            this.showTcComAlert(
                                '적용일시는 일마감 이후로 설정가능합니다. \n최종 일마감일자는 [' +
                                    lastClsDtm +
                                    '] 입니다.'
                            ).then(() => {
                                this.newEffStaDtm = moment(lastClsDtm)
                                    .add('1', 'd')
                                    .format('YYYY-MM-DD')
                                this.closeNewEffStaDtm()
                            })
                        }
                        return false
                    } else {
                        this.closeNewEffStaDtm()
                    }
                })
        },
    },
    watch: {
        basPrmDealcoDtlVo: {
            handler: function (value) {
                if (!_.isEmpty(value)) {
                    let effStaDtm = value['effStaDtm']
                    this.effStaDtm = effStaDtm.substring(0, 8)
                    this.effStaDtmHour = effStaDtm.substring(8, 10)
                    this.effStaDtmMin = effStaDtm.substring(10, 12)
                    this.effStaDtmSec = effStaDtm.substring(12, 14)

                    let effEndDtm = value['effEndDtm']
                    this.effEndDtm = effEndDtm.substring(0, 8)
                    this.effEndDtmHour = effEndDtm.substring(8, 10)
                    this.effEndDtmMin = effEndDtm.substring(10, 12)
                    this.effEndDtmSec = effEndDtm.substring(12, 14)
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },
}
</script>

<style scoped></style>
