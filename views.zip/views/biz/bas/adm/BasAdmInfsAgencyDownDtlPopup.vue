<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <!--  팝업 사이즈 가로 사이즈 줄일경우 최소 size="800px"정도로만 줄여주세요/ -->
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">개인정보추출내역</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- TableWrap -->
                    <div class="wrapTblDefault">
                        <table cellpadding="0" cellspacing="0" class="thCenter">
                            <colgroup>
                                <col style="width: 20%" />
                                <col style="width: auto" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row" class="sub">down/upload</th>
                                    <td>
                                        {{ basAdmPrivacyFileDetail.typeNm }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">요청일시</th>
                                    <td>
                                        {{ basAdmPrivacyFileDetail.insDtm }}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" class="sub">상태</th>
                                    <td>
                                        {{ basAdmPrivacyFileDetail.stateNm }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- //TableWrap -->
                    <!-- gridWrap -->
                    <!-- <TCRealGridHeader
                        id="agencyDownDtlGridHeader"
                        ref="agencyDownDtlGridHeader"
                        gridTitle=""
                        :gridObj="gridObj"
                        class="notit"
                    /> -->
                    <TCRealGrid
                        id="agencyDownDtlGrid"
                        ref="agencyDownDtlGrid"
                        :movable="false"
                        :columnMovable="false"
                        :fields="agencyDownDtlHeader.fields"
                        :columns="agencyDownDtlHeader.columns"
                        :styles="gridStyle"
                        class="mt20"
                    />
                    <!-- //gridWrap -->

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <!-- <TCComButton eClass="btn_ty02_point" :eLarge="true"
                            >확인</TCComButton
                        > -->
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="onCloseClick"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="onCloseClick"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { AGENCY_DOWN_DTL_HEADER } from '@/const/grid/bas/adm/basAdmInfsAgencyDownHeader'
import basAdmInfsAgencyDownApi from '@/api/biz/bas/adm/basAdmInfsAgencyDownApi'
import CommonMixin from '@/mixins'

export default {
    name: 'BasAdmInfsAgencyDownDtlPopup',
    components: {},
    mixins: [CommonMixin],
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 데이터
        parentParam: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            agencyDownDtlHeader: AGENCY_DOWN_DTL_HEADER,
            searchParam: {
                seq: null,
            },
            basAdmPrivacyFileDetail: {},
            gridStyle: {
                height: '250px', //그리드 높이 조절
            },
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    created() {
        this.init()
    },
    async mounted() {
        this.gridObj = this.$refs.agencyDownDtlGrid
        // this.gridHeaderObj = this.$refs.agencyDownDtlGridHeader
        this.gridObj.setGridState(false, false, false, false)
        this.setGridInfo()
        await this.getAgencyDownDetail()
    },
    methods: {
        init() {
            this.gridData = this.gridSetData()
            this.searchParam.seq = this.parentParam.seq
        },
        gridSetData() {
            return new CommonGrid(0, 10, '', '')
        },
        // 그리드 정보 설정
        setGridInfo() {
            // 번호 설정(리얼 그리드에서 제공해주는 순번)
            this.gridObj.gridView.setRowIndicator({
                visible: true,
                headText: 'No',
            })
        },
        // 그리드 이벤트 설정
        setGridEvent() {},
        // 상세 조회
        getAgencyDownDetail() {
            basAdmInfsAgencyDownApi
                .getAgencyDownDetail(this.searchParam)
                .then((res) => {
                    console.log('getAgencyDownDetail res: ', res)
                    this.basAdmPrivacyFileDetail = res.basAdmPrivacyFileDetail
                    this.gridObj.dataProvider.setRows(res.basAdmExcelDetailList)
                })
        },
        onCloseClick() {
            this.activeOpen = false
        },
    },
}
</script>
