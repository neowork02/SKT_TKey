<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : RmtAccAccRptNoticePopup.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div>
        <TCComDialog :dialogShow.sync="statusShow" size="1000px">
            <template #content>
                <div class="layerPop overflow-y-auto">
                    <p class="popTitle">정산 Report 공지사항 및 비고관리</p>

                    <!-- Popup_Cont -->
                    <div class="layerCont">
                        <AccSearchField
                            ref="accSearchField"
                            :offset="[
                                'btn-left-downloadForm',
                                'btn-right-reset',
                                'btn-right-view',
                                'btn-right-save',
                                'btn-right-delete',
                                'btn-right-close',
                                'search-accMth',
                                'search-orgCd',
                            ]"
                            :initValue="initValue"
                            :divideCellCount="3"
                            :popupParamOrgCd="popupParamOrgCd"
                            @reset="resetForm"
                            @view="viewForm"
                            @save="saveForm"
                            @delete="deleteForm"
                            @changeAccMth="changeAccMth"
                            @downloadForm="downloadForm"
                            @close="closePopup"
                            @onChanged="onChanged"
                        >
                        </AccSearchField>

                        <!-- Tab -->
                        <TCComTab
                            :tab.sync="activeTabIdx"
                            :items="tabInfo.id"
                            :itemName="tabInfo.label"
                            :objAuth="objAuth"
                            sliderSize="8"
                            sliderColor="sliderColor"
                            @change="changeTabMenu"
                            @click="clickTabMenu"
                        >
                            <template #RmtAccAccRptPopupNotice>
                                <div class="textareaLayer_wrap">
                                    <TCComTextArea
                                        v-model="
                                            formPostRmtAccNoticRmks.query
                                                .noticRmkVoList[0].notic
                                        "
                                        labelName=""
                                        class="boxtype"
                                        placeholder="공지사항영역"
                                        :maxLength="20"
                                        :rows="10"
                                    />
                                </div>
                            </template>

                            <template #RmtAccAccRptPopupEtc>
                                <div class="contBoth">
                                    <div
                                        style="text-align: right"
                                        v-if="!isCloseAccount"
                                    >
                                        <TCComButton
                                            :Vuetify="false"
                                            :disabled="false"
                                            eClass="btn_noline btn_ty04"
                                            eAttr="ico_exelup"
                                            labelName="업로드"
                                            @click="clickEtcExcelUpload"
                                        />
                                        <TCComButton
                                            :Vuetify="false"
                                            :disabled="false"
                                            eClass="btn_noline btn_ty04"
                                            eAttr="ico_exeldown"
                                            labelName="다운로드"
                                            @click="clickEtcExcelDownload"
                                        />
                                    </div>
                                    <!-- left area -->
                                    <div class="div5_5 cont1 left">
                                        <div class="stitHead">
                                            <h4 class="subTit">
                                                1-1. 무선상세
                                            </h4>
                                        </div>

                                        <div class="wrapTblDefault">
                                            <table
                                                cellpadding="0"
                                                cellspacing="0"
                                                class="thCenter"
                                            >
                                                <colgroup>
                                                    <col style="width: 25%" />
                                                    <col style="width: auto" />
                                                </colgroup>
                                                <thead>
                                                    <tr>
                                                        <th scope="col">
                                                            항목
                                                        </th>
                                                        <th scope="col">
                                                            비고
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            판매인센티브
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r1
                                                                "
                                                                placeholder="New단말 R/B"
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            중고 PPS 수수료
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r2
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            전환정책
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r3
                                                                "
                                                                placeholder="전환정책"
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            무선추가1
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r4
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            무선추가2
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r5
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            기간 Infra 1
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r6
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            기간 Infra 2
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r7
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            PT Infra 1
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r8
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            PT Infra 2
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r9
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            2G전환USIM지원
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r10
                                                                "
                                                                placeholder="2G 전환 단말 대상"
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            USIM후불수수료
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r11
                                                                "
                                                                placeholder="세금계산서 미포함"
                                                            />
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="stitHead">
                                            <h4 class="subTit">
                                                2-1. Infra 정책상세
                                            </h4>
                                        </div>

                                        <div class="wrapTblDefault">
                                            <table
                                                cellpadding="0"
                                                cellspacing="0"
                                                class="thCenter"
                                            >
                                                <colgroup>
                                                    <col style="width: 25%" />
                                                    <col style="width: auto" />
                                                </colgroup>
                                                <thead>
                                                    <tr>
                                                        <th scope="col">
                                                            항목
                                                        </th>
                                                        <th scope="col">
                                                            비고
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            Infra 1
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r19
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            Infra 2
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r20
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            Infra 3
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r21
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            Infra 4
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r22
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            Infra 5
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r23
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            Infra 6
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r24
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            Infra 7
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r41
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            보증보험
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r25
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="stitHead">
                                            <h4 class="subTit">
                                                3-1. 공기기/USIM 판매(참고용)
                                            </h4>
                                        </div>

                                        <div class="wrapTblDefault">
                                            <table
                                                cellpadding="0"
                                                cellspacing="0"
                                                class="thCenter"
                                            >
                                                <colgroup>
                                                    <col style="width: 25%" />
                                                    <col style="width: auto" />
                                                </colgroup>
                                                <thead>
                                                    <tr>
                                                        <th scope="col">
                                                            항목
                                                        </th>
                                                        <th scope="col">
                                                            비고
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            공기기판매
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r26
                                                                "
                                                                placeholder="귀사 매입 계산서"
                                                            />
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!-- //left area -->

                                    <!-- right area -->
                                    <div class="div5_5 cont2 right">
                                        <div class="stitHead">
                                            <h4 class="subTit">
                                                1-2. 유선상세
                                            </h4>
                                        </div>

                                        <div class="wrapTblDefault">
                                            <table
                                                cellpadding="0"
                                                cellspacing="0"
                                                class="thCenter"
                                            >
                                                <colgroup>
                                                    <col style="width: 25%" />
                                                    <col style="width: auto" />
                                                </colgroup>
                                                <thead>
                                                    <tr>
                                                        <th scope="col">
                                                            항목
                                                        </th>
                                                        <th scope="col">
                                                            비고
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            유선 인센티브
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r12
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            유선 추가1
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r13
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            유선 추가2
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r14
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            유선 추가3
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r15
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            유선 추가4
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r16
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            재정산
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r17
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            환수
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r18
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="stitHead">
                                            <h4 class="subTit">
                                                2-2. 재정산 상세
                                            </h4>
                                        </div>

                                        <div class="wrapTblDefault">
                                            <table
                                                cellpadding="0"
                                                cellspacing="0"
                                                class="thCenter"
                                            >
                                                <colgroup>
                                                    <col style="width: 25%" />
                                                    <col style="width: auto" />
                                                </colgroup>
                                                <thead>
                                                    <tr>
                                                        <th scope="col">
                                                            항목
                                                        </th>
                                                        <th scope="col">
                                                            비고
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            중고 PPS 미유지
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r27
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            회선관리 정책
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r28
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            비정상 해지
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r29
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            파파라치(VAT포함)
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r30
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            CIA
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r31
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            SKN 물류비
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r32
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            고정비
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r33
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            기타 재정산
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r34
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            요금제 재정산
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r35
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            전월 재정산
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r36
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            파파라치
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r37
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            VOC/명의도용
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r38
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            기타1(VAT제외)
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r39
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th
                                                            scope="row"
                                                            class="sub"
                                                        >
                                                            기타2(VAT제외)
                                                        </th>
                                                        <td>
                                                            <TCComInput
                                                                v-model="
                                                                    formPostRmtAccNoticRmks
                                                                        .query
                                                                        .noticRmkVoList[0]
                                                                        .r40
                                                                "
                                                            />
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!-- //right area -->
                                </div>
                            </template>
                        </TCComTab>
                        <!-- //Tab -->

                        <!-- Bottom BTN Group -->
                        <div class="btn_area_bottom">&nbsp;</div>
                        <!-- // Bottom BTN Group -->

                        <!-- Close BTN-->
                        <button
                            type="button"
                            class="layerClose b-close"
                            @click="closePopup"
                        >
                            닫기
                        </button>
                        <!--//Close BTN-->
                    </div>
                    <!-- //Popup_Cont -->
                </div>
            </template>
        </TCComDialog>
        <AccFileLoader
            ref="accFileLoader"
            labelName="파일선택"
            isHidden
            @load="loadExcelEtc"
        />
    </div>
</template>
<style scoped>
.layerPop
    :deep(.v-window-item)
    .v-text-field.v-text-field--enclosed
    > .v-input__control
    > .v-input__slot,
.layerPop
    :deep(.v-window-item)
    .v-text-field.v-text-field--enclosed
    .v-text-field__details {
    margin-top: 0;
}
</style>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import {
    getCalcDays,
    filter,
    distanceDate,
    stringByteLength,
    errorHandle,
    gridMetaUtil,
} from '@/utils/accUtil'

import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccFileLoader from '@/components/biz/common/acc/AccFileLoader'

import rmtApi from '@/api/biz/rmt/acc'
import attachApi from '@/api/common/attachedFile'
import attachedFileApi from '@/api/common/attachedFile'

import { GRID_HEADER as GRID_HEADER_RMKLIST } from '@/const/grid/rmt/acc/rmtAccAccRptRmkListGrid'

export default {
    name: 'RmtAccAccRptNoticePopup',
    mixins: [CommonMixin, accMixin],
    components: { AccSearchField, AccFileLoader },

    props: {
        status: {
            default: false,
        },
    },
    data() {
        return {
            GRID_HEADER_RMKLIST,
            objAuth: {},
            activeTabIdx: 0,
            tabInfo: {
                id: ['RmtAccAccRptPopupNotice', 'RmtAccAccRptPopupEtc'],
                label: ['공지사항', '비고'],
            },
            initValue: {
                accMth: getCalcDays(
                    'today',
                    { count: -1, per: 'months' },
                    'YYYY-MM'
                ),
                pageSize: 15,
                pageNum: 1,
            },

            popupParamOrgCd: {
                basMth: '',
            },

            formRmtAccAccRptNotice: {
                query: {
                    dataClCd: 1,
                },
            },

            formPostRmtAccNoticRmks: {
                query: {
                    dataClCd: 1,
                    noticRmkVoList: [{ notic: '', r1: '' }],
                },
            },

            // 마감상태확인 폼
            formGetRmtAccReportsClose: {
                query: {},
                data: {
                    accMth: '',
                    closeYnList: [],
                    accRptClsMthVoList: [],
                },
            },
        }
    },

    computed: {
        statusShow: {
            get() {
                return this.status
            },
            set(value) {
                this.$emit('update:status', value)
            },
        },

        // 회계마감 여부
        isCloseAccount() {
            // 당월(accMth) <= 마감월(clsLastMth)
            if (!this.formGetRmtAccReportsClose.data.accRptClsMthVoList.length)
                return false

            let date = {
                source: this.formGetRmtAccReportsClose.data.accMth,
                target: this.formGetRmtAccReportsClose.data
                    .accRptClsMthVoList[0].clsLastMth,
            }
            let period = distanceDate(date.source, date.target)

            return period <= 0
        },
    },

    filters: {
        currency: filter.currency,
    },

    created() {
        this.initPage()
    },
    mounted() {},
    methods: {
        initPage() {},

        changeTabMenu(tabIdx) {
            console.log('tabIdx', tabIdx)
        },

        clickTabMenu() {},
        closePopup() {
            this.statusShow = false
        },

        resetForm() {
            this.formPostRmtAccNoticRmks.query = {
                dataClCd: 1,
                noticRmkVoList: [{ notic: '' }],
            }

            this.changeAccMth(this.initValue.accMth)

            this.$emit('reset')
        },

        viewForm(query) {
            if (!query.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }

            // 공지사항 및 비고관리
            // query.dataClCd = 1
            // query.orgId = 'AA1132'
            this.formRmtAccAccRptNotice.query = query
            this.formRmtAccAccRptNotice.query.dataClCd = this.activeTabIdx + 1

            return this.getRmtAccNoticRmks()
        },

        saveForm(query) {
            if (!query.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }

            if (
                stringByteLength(
                    this.formPostRmtAccNoticRmks.query.noticRmkVoList[0].notic
                ) > 500
            ) {
                return this.showTcComAlert(
                    '공지사항 최대입력 길이는 500Byte 입니다. (한글:250자, 영문:500자)'
                )
            }

            Object.assign(
                this.formPostRmtAccNoticRmks.query,
                this.formRmtAccAccRptNotice.query,
                query
            )
            this.formPostRmtAccNoticRmks.query.dataClCd = this.activeTabIdx + 1

            this.postRmtAccNoticRmks()
        },

        deleteForm(query) {
            Object.assign(this.formPostRmtAccNoticRmks.query, query)
            this.formPostRmtAccNoticRmks.query.dataClCd = this.activeTabIdx + 1

            this.deleteRmtAccNoticRmks()
        },

        downloadForm() {
            attachApi.downloadSampleFile('417')
        },

        // 정산월 변경 시
        changeAccMth(date) {
            if (this.formGetRmtAccReportsClose.query.accMth == date) return

            this.formGetRmtAccReportsClose.query.accMth = date

            this.popupParamOrgCd.basMth = date

            //  KYJ : 정산월의 길이가 6자리 일경우만 조회
            if (this.formGetRmtAccReportsClose.query.accMth.length == 6) {
                this.getDeadlineStatus()
            }
        },

        // 비고 > 엑셀업로드 버튼 클릭 시
        clickEtcExcelUpload() {
            this.accFileLoader.openSelector('excel')
        },

        // 비고 > 엑셀업로드 파일 선택 후
        loadExcelEtc(xlsData) {
            const listData = gridMetaUtil.xlsToGridData(
                this.GRID_HEADER_RMKLIST,
                xlsData
            )

            Object.assign(
                this.formPostRmtAccNoticRmks.query.noticRmkVoList[0],
                listData[0]
            )
        },

        // 비고 > 엑셀다운로드 버튼 클릭 시
        clickEtcExcelDownload() {
            this.formRmtAccAccRptNotice.query = this.accSearchField.getQuery()
            this.formRmtAccAccRptNotice.query.dataClCd = this.activeTabIdx + 1

            attachedFileApi.downLoadFile(
                `/api/v1/backend-max/resource/rmt/acc/notic-rmks-excel-download`,
                this.formRmtAccAccRptNotice.query
            )
        },

        getRmtAccNoticRmks() {
            return rmtApi
                .getRmtAccNoticRmks(this.formRmtAccAccRptNotice.query)
                .then((res) => {
                    if (res.noticRmkVoList.length) {
                        this.formPostRmtAccNoticRmks.query.noticRmkVoList =
                            res.noticRmkVoList
                    } else {
                        this.formPostRmtAccNoticRmks.query.noticRmkVoList = [
                            { notic: '' },
                        ]
                    }

                    return res
                })
                .catch(errorHandle)
        },

        postRmtAccNoticRmks() {
            return rmtApi
                .postRmtAccNoticRmks(this.formPostRmtAccNoticRmks.query)
                .then(() => {
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
                .catch(errorHandle)
        },

        deleteRmtAccNoticRmks() {
            return rmtApi
                .deleteRmtAccNoticRmks(this.formPostRmtAccNoticRmks.query)
                .then(() => {
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
                .catch(errorHandle)
        },

        getDeadlineStatus() {
            return rmtApi
                .getRmtAccReportsClose(this.formGetRmtAccReportsClose.query)
                .then((res) => {
                    this.$set(this.formGetRmtAccReportsClose, 'data', res)
                })
        },

        onChanged() {
            this.formPostRmtAccNoticRmks.query.noticRmkVoList = [{ notic: '' }]
        },
    },
}
</script>
