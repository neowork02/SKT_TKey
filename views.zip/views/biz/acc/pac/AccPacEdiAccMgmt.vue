<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccPacEdiAccMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <AccHeadline title="EDI 매출/입금 정산관리" />

        <keep-alive>
            <component
                ref="accSearchField"
                :is="curSearchField"
                :curTabIdx.sync="activeTabIdx"
                :tabInfo="tabInfo"
                :dtlInfo.sync="formAccPacEdiDepositDetail.dtlInfo"
                @view="viewForm"
                @save="saveForm"
                @reset="resetForm"
            />
        </keep-alive>

        <TCComTab
            :tab.sync="activeTabIdx"
            :items="tabInfo.id"
            :itemName="tabInfo.label"
            :centered="false"
            :grow="false"
            :hideSlider="false"
            :vertical="false"
            :objAuth="objAuth"
            sliderSize="8"
            @change="changeTabMenu"
            @click="clickTabMenu"
        >
            <template #AccPacEdiSales>
                <AccPacEdiSales
                    ref="AccPacEdiSales"
                    :query="formAccPacEdiSales.query"
                    :data="formAccPacEdiSales.data"
                    :pagingInfo="formAccPacEdiSales.pagingInfo"
                    @movePage="movePage"
                    @changePageSize="changePageSize"
                />
            </template>
            <template #AccPacEdiDeposit>
                <AccPacEdiDeposit
                    ref="AccPacEdiDeposit"
                    :query="formAccPacEdiDeposit.query"
                    :data="formAccPacEdiDeposit.data"
                    :pagingInfo="formAccPacEdiDeposit.pagingInfo"
                    @movePage="movePage"
                    @changePageSize="changePageSize"
                />
            </template>
            <template #AccPacEdiDepositReport>
                <AccPacEdiDepositReport
                    ref="AccPacEdiDepositReport"
                    :query="formAccPacEdiDepositReport.query"
                    :data="formAccPacEdiDepositReport.data"
                    :pagingInfo="formAccPacEdiDepositReport.pagingInfo"
                    @dblClickCell="dblClickCellAccPacEdiDepositReport"
                    @movePage="movePage"
                    @changePageSize="changePageSize"
                />
            </template>
            <template #AccPacEdiDepositDetail>
                <AccPacEdiDepositDetail
                    ref="AccPacEdiDepositDetail"
                    :query="formAccPacEdiDepositDetail.query"
                    :data="formAccPacEdiDepositDetail.data"
                    :pagingInfo="formAccPacEdiDepositDetail.pagingInfo"
                    :dtlInfo="formAccPacEdiDepositDetail.dtlInfo"
                    @movePage="movePage"
                    @changePageSize="changePageSize"
                />
            </template>
            <template #AccPacEdiHardWrite>
                <AccPacEdiHardWrite
                    ref="AccPacEdiHardWrite"
                    :query="formAccPacEdiHardWrite.query"
                    :data="formAccPacEdiHardWrite.data"
                    :pagingInfo="formAccPacEdiHardWrite.pagingInfo"
                    @movePage="movePage"
                    @changePageSize="changePageSize"
                    @excelUpParseloadBtn="excelUpParseloadBtn"
                />
            </template>
        </TCComTab>
    </div>
</template>
<script>
import CommonMixin from '@/mixins'

import { errorHandle } from '@/utils/accUtil'

import AccHeadline from '@/components/biz/common/acc/AccHeadline'

import AccPacEdiSales from '@/components/biz/acc/pac/AccPacEdiSales'
import AccPacEdiSalesSearch from '@/components/biz/acc/pac/AccPacEdiSalesSearch'

import AccPacEdiDeposit from '@/components/biz/acc/pac/AccPacEdiDeposit'
import AccPacEdiDepositSearch from '@/components/biz/acc/pac/AccPacEdiDepositSearch'

import AccPacEdiDepositReport from '@/components/biz/acc/pac/AccPacEdiDepositReport'
import AccPacEdiDepositReportSearch from '@/components/biz/acc/pac/AccPacEdiDepositReportSearch'

import AccPacEdiDepositDetail from '@/components/biz/acc/pac/AccPacEdiDepositDetail'
import AccPacEdiDepositDetailSearch from '@/components/biz/acc/pac/AccPacEdiDepositDetailSearch'

import AccPacEdiHardWrite from '@/components/biz/acc/pac/AccPacEdiHardWrite'
import AccPacEdiHardWriteSearch from '@/components/biz/acc/pac/AccPacEdiHardWriteSearch'

import pacApi from '@/api/biz/acc/pac'

import { MOCK_DATA } from '@/const/grid/acc/pac/accPacEdiSalesGrid'

export default {
    name: 'AccPacEdiAccMgmt',
    mixins: [CommonMixin],
    components: {
        AccHeadline,
        AccPacEdiSales,
        AccPacEdiSalesSearch,
        AccPacEdiDeposit,
        AccPacEdiDepositSearch,
        AccPacEdiDepositReport,
        AccPacEdiDepositReportSearch,
        AccPacEdiDepositDetail,
        AccPacEdiDepositDetailSearch,
        AccPacEdiHardWrite,
        AccPacEdiHardWriteSearch,
    },
    data() {
        return {
            objAuth: {},
            activeTabIdx: 0,
            tabInfo: {
                id: [
                    'AccPacEdiSales',
                    'AccPacEdiDeposit',
                    'AccPacEdiDepositReport',
                    'AccPacEdiDepositDetail',
                    'AccPacEdiHardWrite',
                ],
                label: [
                    'EDI 매출정산',
                    'EDI 입금정산',
                    '카드입금정산 내역',
                    '카드입금정산 상세',
                    '수기입금정산',
                ],
            },

            formAccPacEdiSales: {
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                data: [],
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formAccPacEdiDeposit: {
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                data: [],
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formAccPacEdiDepositReport: {
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                data: [],
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formAccPacEdiDepositDetail: {
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                data: [],
                dtlInfo: {},
                pagingInfo: {
                    pageSize: 15,
                },
            },

            formAccPacEdiHardWrite: {
                query: {
                    pageNum: 1,
                    pageSize: 15,
                },
                data: [],
                pagingInfo: {
                    pageSize: 15,
                },
            },
        }
    },
    computed: {
        curSearchField() {
            return `${this.tabInfo.id[this.activeTabIdx]}Search`
        },

        curForm() {
            return this[`form${this.tabInfo.id[this.activeTabIdx]}`]
        },

        curGrid() {
            return this.$refs[this.tabInfo.id[this.activeTabIdx]].$refs
                .accGridTable
        },

        curListApi() {
            let targetAPI

            switch (this.activeTabIdx) {
                case 0:
                    targetAPI = pacApi.getEdiSalesList
                    break
                case 1:
                    targetAPI = pacApi.getEdiDpstsList
                    break
                case 2:
                    targetAPI = pacApi.getCardDpstsList
                    break
                case 3:
                    targetAPI = pacApi.getCardDpstsDtlList
                    break
                case 4:
                    targetAPI = pacApi.getCardHndsList
                    break
            }

            return targetAPI
        },

        curPostApi() {
            let targetAPI

            switch (this.activeTabIdx) {
                case 0:
                case 1:
                    targetAPI = pacApi.postEdiSalesList
                    break
                case 4:
                    targetAPI = pacApi.postCardHndsList
                    break
            }

            return targetAPI
        },

        curVoListName() {
            let voListName

            switch (this.activeTabIdx) {
                case 0:
                    voListName = 'ediSaleAccVoList'
                    break
                case 1:
                    voListName = 'ediDpstAccVoList'
                    break
                case 2:
                    voListName = 'ediCardDpstAccVoList'
                    break
                case 3:
                    voListName = 'ediCardDpstAccVoList'
                    break
                case 4:
                    voListName = 'hndwrtDpstAccVoList'
                    break
            }

            return voListName
        },

        curVoPagingListName() {
            let voPagingListName

            switch (this.activeTabIdx) {
                case 0:
                    voPagingListName = 'ediSaleAccVoPagingList'
                    break
                case 1:
                    voPagingListName = 'ediDpstAccVoPagingList'
                    break
                case 2:
                    voPagingListName = 'ediCardDpstAccVoPagingList'
                    break
                case 3:
                    voPagingListName = 'ediCardDpstAccVoDtlVoPagingList'
                    break
                case 4:
                    voPagingListName = 'hndwrtDpstAccVoPagingList'
                    break
            }

            return voPagingListName
        },
    },
    created() {
        this.initPage()
        console.log(MOCK_DATA)
    },
    mounted() {},
    methods: {
        initPage() {},

        changeTabMenu(tabIdx) {
            this.activeTabIdx = tabIdx
        },

        clickTabMenu() {},

        resetForm() {
            const form = this.curForm
            form.data = []
        },

        viewForm(query) {
            const form = this.curForm
            const getList = this.curListApi
            const voPagingListName = this.curVoPagingListName

            // form.data = MOCK_DATA[voPagingListName].gridList
            // form.pagingInfo = MOCK_DATA[voPagingListName].pagingDto
            // form.pagingInfo.pageNum = query.pageNum || 1
            // form.pagingInfo.pageSize = query.pageSize || 15
            // console.log('요청쿼리 =>', query, getList)
            // return Promise.resolve()
            //
            //
            //
            //
            //
            //
            if (!query.orgId) query.orgId = query.orgCd

            form.query = query
            return getList(query)
                .then((res) => {
                    // console.log('응답!', voPagingListName, res)
                    form.data = [...res[voPagingListName].gridList]
                    form.pagingInfo = res[voPagingListName].pagingDto
                })
                .catch(errorHandle)
        },

        saveForm() {
            const form = this.curForm
            const postList = this.curPostApi
            const voListName = this.curVoListName
            const grid = this.curGrid

            const rows = grid.getChangedRow()

            if (rows.length == 0) {
                return this.showTcComAlert(`수정된 항목이 없습니다.`)
            } else {
                form.query[voListName] = rows
                return postList(form.query)
                    .then((res) => {
                        console.log(res)
                        this.showTcComAlert(`정상적으로 처리되었습니다.`)

                        if (voListName == 'hndwrtDpstAccVoList') {
                            delete form.query[voListName]
                            this.viewForm(form.query)
                        }
                    })
                    .catch(errorHandle)
            }
        },

        dblClickCellAccPacEdiDepositReport(row) {
            const form = this.formAccPacEdiDepositDetail
            const getList = pacApi.getCardDpstsDtlList
            const getQuery = this.$refs.accSearchField.getQuery()

            form.query = row
            form.query.guBun2 = 'DTL'
            form.query.pageNum = 1
            form.query.pageSize = 15
            form.query.salePlc = row.salePlcCd
            form.query.orgLvl = row.orgLvl || row.orgLevel
            form.query.orgLevel = row.orgLvl || row.orgLevel
            form.query.searchCoClOrgCd = getQuery.searchCoClOrgCd
            form.query.payStaDtm = getQuery.payStaDtm.replace(/-/g, '')
            form.query.payEndDtm = getQuery.payEndDtm.replace(/-/g, '')

            return getList(form.query).then((res) => {
                form.data = [...res.ediCardDpstAccVoDtlVoPagingList.gridList]
                Object.assign(form.dtlInfo, form.query)
                this.changeTabMenu(3)

                // this.$nextTick(() => {
                //     console.log(
                //         '모지!!222222!',
                //         form.query.payStaDtm,
                //         form.query.payEndDtm
                //     )
                //     setTimeout(() => {
                //         this.accSearchField.setQuery({
                //             patmentDtPayDt: [
                //                 form.query.payStaDtm,
                //                 form.query.payEndDtm,
                //             ],
                //         })
                //     }, 1000)
                // })
            })
        },

        movePage(query) {
            const form = this.curForm
            Object.assign(form.query, query)

            this.viewForm(form.query)
        },

        changePageSize(query) {
            this.$refs.accSearchField.setQuery(query)
        },

        excelUpParseloadBtn(row) {
            console.log('부모row', row)
            const form = this.curForm

            form.data = row
            form.pagingInfo = {}
        },
    },
}
</script>
