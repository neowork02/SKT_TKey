<!-----------------------------------------------
 * 업무그룹명: 재고관리>수탁입고
 * 서브업무명: 수탁입고관리[DISINN00300]
 * 설명: 수탁입고관리를 조회한다.
 * 작성자: P179229
 * 작성일: 2022.05.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>수탁입고관리</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    @click="excelUpload"
                    :objAuth="this.objAuth"
                    >엑셀업로드</TCComButton
                >
            </li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="dtlBtn"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="입고일자"
                        calType="DP"
                        v-model="setDate"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.orgNm"
                        :codeVal.sync="reqParam.orgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :eRequired="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchOrgForm"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.inDealcoNm"
                        :codeVal.sync="reqParam.inDealcoCd"
                        labelName="입고처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="searchDealcosForm"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.prchsDealcoNm"
                        :codeVal.sync="reqParam.prchsDealcoCd"
                        labelName="매입처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOutDealEnterKey"
                        @appendIconClick="onOutDealIconClick"
                        @input="onOutDealInput"
                    />
                    <BasBcoOutDealsPopup
                        v-if="showBcoOutDeals"
                        :parentParam="searchOutDealParam"
                        :rows="resultOutDealRows"
                        :dialogShow.sync="showBcoOutDeals"
                        @confirm="onOutDealReturnData"
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZDIS_C_00020"
                        labelName="입고구분"
                        v-model="reqParam.inClCd"
                        :objAuth="this.objAuth"
                        :filterFunc="inClCdFilter"
                    ></TCComComboBox>
                </div>
                <div class="formitem div4_6"></div>
            </div>
        </div>
        <!-- // Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="입고관리 내역"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            >
                <template #gridBtnArea>
                    <TCComButton
                        :Vuetify="false"
                        eClass="btn_noline btn_ty04"
                        eAttr="ico_exeldown"
                        labelName="상세다운로드"
                        :objAuth="objAuth"
                        @click="onClickDownloadDtl"
                    />
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisInnInMgmts"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <!-- // gridWrap -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { DisInnInMgmtGRID_HEADER } from '@/const/grid/dis/inn/disInnInMgmtHeader'
import disInnInMgmtApi from '@/api/biz/dis/inn/disInnInMgmt'
import attachedFileApi from '@/api/common/attachedFile'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-전체조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-전체조직==================
//====================외부거래처(제조사,매입처,배송사 등) 팝업====================
import BasBcoOutDealsPopup from '@/components/common/BasBcoOutDealsPopup'
import basBcoOutDealsApi from '@/api/biz/bas/bco/basBcoOutDeals'
//====================//외부거래처(제조사,매입처,배송사 등) 팝업====================
import CommonMixin from '@/mixins'
import moment from 'moment'
import _ from 'lodash'

export default {
    name: 'DisCinConsigmentInMgmt',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
        BasBcoOutDealsPopup,
    },
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            indicatorOpt: { sort: 'ASC' },
            codeIDView: true,
            codeIDViewVal: '',
            objAuth: {},
            view: DisInnInMgmtGRID_HEADER,
            //====================내부조직팝업(권한)팝업관련====================
            orgDisabled: false,
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchOrgForm: {
                orgCd: '', // 조직id
                orgNm: '', // 조직명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //====================//내부조직팝업(권한)팝업관련==================
            //====================내부거래처-전체조직====================
            dealcoDisabled: false,
            showBasBcoDealcos: false,
            searchDealcosForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
            },
            resultDealcoRows: [],
            //====================//내부거래처-전체조직==================
            //====================외부거래처(제조사,매입처,배송사 등) 팝업====================
            showBcoOutDeals: false, // 외부거래처 팝업 오픈 여부
            searchOutDealParam: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: '3X', // 거래처그룹
                dealcoClCd1: '30', // 거래처구분
            },
            resultOutDealRows: [], // 외부거래처 팝업 오픈 여부
            //====================//외부거래처(제조사,매입처,배송사 등) 팝업==================
            reqParam: {
                fromDt: '', //from일자
                toDt: '', //to일자
                orgCd: '', //조직id
                orgNm: '', //조직명
                orgLvl: '', //조직level
                orgCdLvl0: '', //레벨0조직코드
                inDealcoCd: '', // 입고처
                inDealcoNm: '', // 입고처명
                prchsDealcoCd: '', //매입처
                prchsDealcoNm: '', //매입처명
                inClCd: '101', //입고구분
                consigment: 'Y', //수탁여부
            },
            serchParam: {},
            dtlParam: {},
            rowCnt: 15,
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.fromDt, this.reqParam.toDt]
            },
            set(val) {
                this.reqParam.fromDt = val[0]
                this.reqParam.toDt = val[1]
                this.searchDealcosForm.basDay = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMMDD'
                )
                this.searchOrgForm.basMth = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMM'
                )
                return val
            },
        },
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(true, false, false)
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked
        // 상세에서 받은 검색조건
        if (this.$route.params.search) {
            this.reqParam = this.$route.params.search
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
            if (!_.isEmpty(this.reqParam.orgCd)) {
                this.searchBtn()
            }
        } else {
            this.init()
        }
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.fromDt = moment(new Date()).format('YYYY-MM-01') // 입고일 from
            this.reqParam.toDt = moment(new Date()).format('YYYY-MM-DD') // 입고일 to
            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['orgCd'] = this.orgInfo['orgCd']
                this.reqParam['orgNm'] = this.orgInfo['orgNm']
                this.reqParam['orgLvl'] = this.orgInfo['orgLvl']
                this.reqParam['orgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.reqParam['inDealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['inDealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam') // 초기화 함수
            this.init()
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        //입고구분 Filter
        inClCdFilter(items) {
            return items.filter((item) => item['commCdVal'] === '101')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/inn/disInnInMgmtExcelList',
                this.searchForm
            )
        },
        //상세엑셀다운로드
        onClickDownloadDtl() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/inn/disInnInMgmtAllExcelList',
                this.searchForm
            )
        },
        //리스트 조회
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            this.searchForm = { ...this.reqParam }
            this.searchForm.fromDt = CommonUtil.replaceDash(
                this.searchForm.fromDt
            )
            this.searchForm.toDt = CommonUtil.replaceDash(this.searchForm.toDt)
            //첫 조회시 표시할 행의 갯수
            this.searchForm.pageSize = this.rowCnt
            this.searchForm.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getDisInnInMgmts(this.searchForm.pageNum)
        },
        getDisInnInMgmts(page) {
            this.searchForm.pageNum = page
            disInnInMgmtApi.getDisInnInMgmt(this.searchForm).then((res) => {
                //Get Row Data
                this.gridObj.setRows(res.gridList)
                this.gridObj.setGridIndicator(res.pagingDto, this.indicatorOpt) //순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData() //초기화
                this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj.setPageCount(res.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },
        isValidChk() {
            let validFromDt = CommonUtil.replaceDash(this.reqParam.fromDt)
            let validToDt = CommonUtil.replaceDash(this.reqParam.toDt)
            if (_.isEmpty(validFromDt)) {
                this.showTcComAlert('입고일자의 시작일(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(validToDt)) {
                this.showTcComAlert('입고일자의 종료일(을)를 입력해 주십시오.')
                return false
            }
            if (validFromDt.substr(0, 6) !== validToDt.substr(0, 6)) {
                this.showTcComAlert(
                    '시작일자와 종료일자를 동일한 월로 지정하세요.'
                )
                return false
            }
            if (validFromDt > validToDt) {
                this.showTcComAlert('입고일자의 시작일이 종료일보다 큽니다.')
                return false
            }
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 입력해 주십시오.')
                return false
            }
            return true
        },
        dtlBtn: function () {
            this.$router.push({
                name: '/dis/cin/DisCinConsigmentInMgmtDtl',
                params: { search: this.reqParam },
            })
        },
        onCellDblClicked(grid, clickData) {
            if (clickData?.dataRow >= 0) {
                const cellData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.dtlParam = { ...cellData }
                this.$router.push({
                    name: '/dis/cin/DisCinConsigmentInMgmtDtl',
                    params: { search: this.reqParam, datas: this.dtlParam },
                })
            }
        },
        excelUpload() {
            this.$router.push({
                name: '/dis/inn/DisInnInMgmtXlsUpld',
                params: { search: this.reqParam },
            })
        },
        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.searchOrgForm.orgCd = this.reqParam.orgCd
            this.searchOrgForm.orgNm = this.reqParam.orgNm
            this.searchOrgForm.orgLvl = this.reqParam.orgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchOrgForm)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.orgCd = _.get(res[0], 'orgCd')
                        this.reqParam.orgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                        this.reqParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.orgCd = ''
            this.reqParam.orgLvl = ''
            this.reqParam.orgCdLvl0 = ''
            this.reqParam.inDealcoCd = ''
            this.reqParam.inDealcoNm = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            this.reqParam.orgCd = _.get(retrunData, 'orgCd')
            this.reqParam.orgNm = _.get(retrunData, 'orgNm')
            this.reqParam.orgLvl = _.get(retrunData, 'orgLvl')
            this.reqParam.orgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
            this.reqParam.inDealcoCd = ''
            this.reqParam.inDealcoNm = ''
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchDealcosForm)
                .then((res) => {
                    // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.inDealcoCd = _.get(res[0], 'dealcoCd')
                        this.reqParam.inDealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultDealcoRows = res
                        this.showBasBcoDealcos = true
                    }
                })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }

            this.searchDealcosForm.orgCd = this.reqParam.orgCd
            this.searchDealcosForm.orgNm = this.reqParam.orgNm
            this.searchDealcosForm.orgLvl = this.reqParam.orgLvl
            this.searchDealcosForm.dealcoCd = this.reqParam.inDealcoCd
            this.searchDealcosForm.dealcoNm = this.reqParam.inDealcoNm
            // 팝업오픈
            this.showBasBcoDealcos = true
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.orgCd)) {
                this.showTcComAlert('조직을 선택하세요')
                return
            }
            this.searchDealcosForm.orgCd = this.reqParam.orgCd
            this.searchDealcosForm.orgNm = this.reqParam.orgNm
            this.searchDealcosForm.orgLvl = this.reqParam.orgLvl
            this.searchDealcosForm.dealcoCd = this.reqParam.inDealcoCd
            this.searchDealcosForm.dealcoNm = this.reqParam.inDealcoNm
            if (_.isEmpty(this.reqParam.inDealcoNm)) {
                // 팝업오픈
                this.showBasBcoDealcos = true
            } else {
                // 내부거래처-전체조직 정보 조회
                this.getDealcosList()
            }
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.reqParam.inDealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            this.reqParam.inDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.inDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처-전체조직팝업관련 methods ================================
        //===================== 외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
        // 외부거래처 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 외부거래처 팝업 오픈
        getOutDealList() {
            basBcoOutDealsApi
                .getOutDealList(this.searchOutDealParam)
                .then((res) => {
                    // 검색된 외부거래처 정보가 1건이면 TextField에 바로 설정
                    // 검색된 외부거래처 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 외부거래처 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.prchsDealcoCd = _.get(res[0], 'dealcoCd')
                        this.reqParam.prchsDealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealRows = res
                        this.showBcoOutDeals = true
                    }
                })
        },
        // 외부거래처 TextField 돋보기 Icon 이벤트 처리
        onOutDealIconClick() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            // 검색조건 외부거래처명이 빈값이 아니면 외부거래처 정보 조회
            // 그 이외는 외부거래처 팝업 오픈
            this.searchOutDealParam.dealcoCd = this.reqParam.prchsDealcoCd
            this.searchOutDealParam.dealcoNm = this.reqParam.prchsDealcoNm
            //팝업 오픈
            this.showBcoOutDeals = true
        },
        // 외부거래처 TextField 엔터키 이벤트 처리
        onOutDealEnterKey() {
            // 외부거래처 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealRows = []
            this.searchOutDealParam.dealcoCd = this.reqParam.prchsDealcoCd
            this.searchOutDealParam.dealcoNm = this.reqParam.prchsDealcoNm
            if (_.isEmpty(this.reqParam.prchsDealcoNm)) {
                //팝업 오픈
                this.showBcoOutDeals = true
            } else {
                // 외부거래처 정보 조회
                this.getOutDealList()
            }
        },
        // 외부거래처 TextField Input 이벤트 처리
        onOutDealInput() {
            // 입력되는 값이 있으면 외부거래처 코드 초기화
            if (_.isEmpty(this.reqParam.prchsDealcoNm)) {
                this.reqParam.prchsDealcoCd = ''
                this.searchOutDealParam.dealcoCd = ''
                this.searchOutDealParam.dealcoNm = ''
            }
        },
        // 외부거래처 팝업 리턴 이벤트 처리
        onOutDealReturnData(retrunData) {
            this.reqParam.prchsDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.prchsDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //외부거래처(제조사,매입처,배송사 등) 팝업관련 methods ================================
    },
}
</script>
