/*****************************************
 * 업무그룹명: 판매관리
 * 서브업무명: T수납대행관리
 * 설명: 판매관리-비회선상품관리-비회선상품판매현황(SALSEL)
 * 작성자: P179234
 * 작성일: 2022.10.24
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'ifOpStCd', // 매출조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procClCd', // 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyCd', // 판매처
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd', // 고객명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payDtm', // 가입처리일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payReqPlcNm', // 서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payReqPlcCd', // 사용상태
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'custNm', // 패키지업무 처리유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'svcNumMask', // 구독서비스유형
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'settlWayCd', // 구독상품ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'payObjAmt', // 구독상품(패키지)명
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'wcktDealTypYn', // 인증여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'revItmNm', // 옵션혜택상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opMthdCd', // 기본혜택인증일①11번가혜택
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procChgrgUserId', // 기본혜택인증일②클라우드혜택
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procChgrgUserNm', // 옵션혜택인증일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm', // 해지일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 서비스관리번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errorClCd', // 이동전화가입구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'slClCd', // 이동전화가입일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'linkey', // 조직
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opStCd', // 매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opDt', // 매장명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opTm', // 판매점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq', // 판매점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // 거래처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wcktDealTypCd', // 거래처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wcktDealTypCd1', // 단말기모델명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'wcktDealTypCd2', // 해지일자
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'ifOpStCd',
            fieldName: 'ifOpStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            styleName: 'multi-line-css',
            header: {
                text: '매출조직',
                showTooltip: false,
            },
        },
        {
            name: 'procClCd',
            fieldName: 'procClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            editable: false,
        },

        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매처',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '고객명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payDtm',
            fieldName: 'payDtm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '가입처리일',
                showTooltip: false,
            },
            textFormat:
                '([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})$;$1-$2-$3 $4:$5:$6',
        },
        {
            name: 'payReqPlcNm',
            fieldName: 'payReqPlcNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payReqPlcCd',
            fieldName: 'payReqPlcCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '사용상태',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'custNm',
            fieldName: 'custNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '패키지업무 처리유형',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'svcNumMask',
            fieldName: 'svcNumMask',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구독서비스유형',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'settlWayCd',
            fieldName: 'settlWayCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구독상품ID',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'payObjAmt',
            fieldName: 'payObjAmt',
            type: 'data',
            styleName: 'right-column',
            numberFormat: '#,##0',
            header: {
                text: '구독상품(패키지)명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'wcktDealTypYn',
            fieldName: 'wcktDealTypYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '인증여부',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'revItmNm',
            fieldName: 'revItmNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '옵션혜택상품명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'opMthdCd',
            fieldName: 'opMthdCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '기본혜택인증일①11번가혜택',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'procChgrgUserId',
            fieldName: 'procChgrgUserId',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '기본혜택인증일②클라우드혜택',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'procChgrgUserNm',
            fieldName: 'procChgrgUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '옵션혜택인증일',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '해지일자',
                showTooltip: false,
            },
            editable: false,
        },

        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서비스관리번호',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'errorClCd',
            fieldName: 'errorClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동전화가입구분',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'slClCd',
            fieldName: 'slClCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동전화가입일자',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'linkey',
            fieldName: 'linkey',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'opStCd',
            fieldName: 'opStCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'opDt',
            fieldName: 'opDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'opTm',
            fieldName: 'opTm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매점코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'seq',
            fieldName: 'seq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '판매점명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'updCnt',
            fieldName: 'updCnt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'wcktDealTypCd',
            fieldName: 'wcktDealTypCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'wcktDealTypCd1',
            fieldName: 'wcktDealTypCd1',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기모델명',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'wcktDealTypCd2',
            fieldName: 'wcktDealTypCd2',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '해지일자',
                showTooltip: false,
            },
            editable: false,
        },
    ],
    layout: [
        {
            name: '비회선상품정보',
            direction: 'horizontal',
            items: [
                'ifOpStCd',
                'procClCd',
                'modDtm',
                'sktAgencyCd',
                'sktSubCd',
                'payDtm',
                'payReqPlcNm',
                'payReqPlcCd',
                'custNm',
                'svcNumMask',
                'settlWayCd',
                'payObjAmt',
                'wcktDealTypYn',
                'revItmNm',
                'opMthdCd',
                'procChgrgUserId',
                'procChgrgUserNm',
                'userNm',
            ],
        },
        {
            name: '무선정보',
            direction: 'horizontal',
            items: [
                'rmks',
                'errorClCd',
                'slClCd',
                'linkey',
                'opStCd',
                'opDt',
                'opTm',
                'seq',
                'updCnt',
                'wcktDealTypCd',
                'wcktDealTypCd1',
                'wcktDealTypCd2',
            ],
        },
    ],
}
