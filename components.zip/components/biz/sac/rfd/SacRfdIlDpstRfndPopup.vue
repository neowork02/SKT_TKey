<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : RmtAccAccRptExcelUpload.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<!-----------------------------------------------
ASIS <> TOBE 변수매핑

var FV_CLOSE_DT;
==> this.accSearchField.dpstYymm

var FV_MOD; // 수정 또는 신규 구분
==> this.isModify

var FV_FIX_YN; // 확정여부(2,4일때는 저장/삭제 불가)
==> this.isFixYn

var FV_GUBUN; //요금, 기타, 불명, 카드
==> this.accSearchField.dpstCl

var FV_DEPO_YN = "N"; //  예금주 조회여부
==> this.statusCheckDepo

var FV_SEARCH_YN = "N"; // 조회여부 (Y/N)
==> this.isBeforeInquiry

var FV_PRE_RFND_CL = "0"; // 이전 환불구분
==> this.statusUpdateData (안씀)

var FV_RFND_AMT; // 환불금액
==> this.modifyData.rfndAmt

var FV_DEAL_CL; // 입금처/대리점 구분

var FV_MTH_CHK_YN; // 월마감여부
==> this.isMthChkYn

var FV_RESULT = "N"; //  예금주 일치여부 및 강제승인여부(Y:일치, N:불일치, F:강제승인)
isForceConfirm: 강제승인여부 true => F, false => N
강제승인: this.formPostSacRfdErrRfinds.query.forceAprvYn

div_search: 상단검색창 ID
==> this.accSearchField

ds_condition: 현재페이지 조회 때 사용되는 조건셋
==> this.accSearchField

ds_rowRfnd: 부모창에서 가져온 데이터셋
==> this.modifyData

ds_dpst_list: 입금내역 테이블 데이터셋
==> this.formGetSacRfdErrRfindsProcs.data.rsDpstProcList

ds_rfndproc: 채권내역 테이블 데이터셋
==> this.formGetSacRfdErrRfindsProcs.data.rsRfndProcList

ds_rfnd_info: 거래처정보 테이블
==> this.formPostSacRfdErrRfinds.query

div_process1: 거래처정보박스 ID
==> this.formPostSacRfdErrRfinds.query

ds_rfnd_deal_acc: 거래처 정보 > 환불거래처 셀렉트박스 데이터

ds_slcm_condtion: 예금주 조회용 api 조회 테이블
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="status" size="1400px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">환불처리</p>

                <div class="layerCont">
                    <AccSearchField
                        ref="accSearchField"
                        :offset="[
                            'btn-right-reset',
                            'btn-right-view',
                            'btn-right-close',
                            'search-dpstYymm',
                            'search-orgCd',
                            'search-stlPlc',
                            '!search-dpstCl',
                        ]"
                        :statusDisableSearch="{ dpstCl: true }"
                        :initValue="initValue"
                        :popupParamOrgCd="popupParamOrgCd"
                        :popupParamDealcoCd="popupParamDealcoCd"
                        @reset="resetForm"
                        @view="viewForm"
                        @close="closePopup"
                        @changeDpstYymm="changeDpstYymm"
                        @changeOrgCd="changeOrgCd"
                    />
                    <AccGridTable
                        title="입금내역"
                        ref="accGridTableDeposit"
                        isEditable
                        noPaging
                        :offset="[]"
                        :gridMeta="GRID_HEADER_DEPOSIT"
                        :data="formGetSacRfdErrRfindsProcs.data.rsDpstProcList"
                        @rowUpdated="depositRowUpdated"
                    />

                    <AccGridTable
                        title="채권내역"
                        ref="accGridTableBond"
                        noPaging
                        :offset="[]"
                        :gridMeta="GRID_HEADER_BOND"
                        :data="formGetSacRfdErrRfindsProcs.data.rsRfndProcList"
                    />

                    <div class="stitHead">
                        <h4 class="subTit">거래처정보</h4>
                        <span class="stitBtnRef2">
                            <TCComButton
                                eClass="btn_ty01"
                                @click="deleteForm"
                                v-if="isModPosYn"
                                >삭제</TCComButton
                            >

                            <TCComButton eClass="btn_ty01" @click="saveForm"
                                >저장</TCComButton
                            >
                        </span>
                    </div>

                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComComboBox
                                    :itemList="rfndDealList"
                                    itemText="label"
                                    itemValue="value"
                                    labelName="환불거래처"
                                    :disabled="isBeforeInquiry || isModify"
                                    v-model="
                                        formPostSacRfdErrRfinds.query.equalYn
                                    "
                                    return-object
                                    @change="changeEqualYn"
                                />
                            </div>

                            <div class="formitem div4">
                                <TCComInput
                                    labelName="환불계좌"
                                    :disabled="
                                        isBeforeInquiry ||
                                        isOwnerAccount ||
                                        isForceConfirm
                                    "
                                    v-model="
                                        formPostSacRfdErrRfinds.query.rfndAccNo
                                    "
                                />
                            </div>

                            <div class="formitem div4">
                                <TCComInput
                                    labelName="환불액"
                                    :disabled="
                                        isBeforeInquiry || isForceConfirm
                                    "
                                    v-model="
                                        formPostSacRfdErrRfinds.query.rfndAmt
                                    "
                                />
                            </div>

                            <div class="formitem div4">
                                <TCComComboBox
                                    codeId="ZBAS_C_00420"
                                    labelName="환불은행"
                                    :disabled="
                                        isBeforeInquiry ||
                                        isOwnerAccount ||
                                        isForceConfirm
                                    "
                                    v-model="
                                        formPostSacRfdErrRfinds.query.rfndBankCd
                                    "
                                />
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComDatePicker
                                    calType="D"
                                    labelName="환불적용일"
                                    :disabled="true"
                                    v-model="
                                        formPostSacRfdErrRfinds.query.rfndDt
                                    "
                                />
                            </div>

                            <div class="formitem div4">
                                <div class="arrayType btnType">
                                    <div class="colinput2">
                                        <TCComInput
                                            labelName="환불예금주"
                                            :disabled="
                                                isBeforeInquiry ||
                                                isOwnerAccount ||
                                                isForceConfirm
                                            "
                                            v-model="
                                                formPostSacRfdErrRfinds.query
                                                    .rfndDepo
                                            "
                                        />
                                    </div>
                                    <div class="colbtn">
                                        <TCComButton
                                            :Vuetify="false"
                                            :disabled="
                                                isBeforeInquiry ||
                                                isOwnerAccount ||
                                                isForceConfirm
                                            "
                                            eClass="btn_s btn_ty03"
                                            labelName="예금주조회"
                                            @click="clickAccountSearch"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div class="formitem result">
                                <TCComInput
                                    labelName="조회결과"
                                    :disabled="true"
                                    v-model="
                                        formPostSacRfdErrRfinds.query
                                            .sapRfndDepo
                                    "
                                />
                                <TCComInput
                                    class="full"
                                    :disabled="true"
                                    v-model="
                                        formPostSacRfdErrRfinds.query
                                            .depoAgreeNm
                                    "
                                />
                                <TCComButton
                                    eClass="btn_s btn_ty03"
                                    :Vuetify="false"
                                    :disabled="
                                        isBeforeInquiry ||
                                        isOwnerAccount ||
                                        (isOtherAccount && isCheckDepo) ||
                                        isForceConfirm
                                    "
                                    @click="clickForceConfirm"
                                    labelName="강제승인"
                                />
                                <TCComInput
                                    class="full"
                                    :disabled="true"
                                    v-model="
                                        formPostSacRfdErrRfinds.query
                                            .edtForceAprvNm
                                    "
                                />
                            </div>
                        </div>

                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    labelName="비고"
                                    :disabled="isBeforeInquiry"
                                    v-model="
                                        formPostSacRfdErrRfinds.query.remark
                                    "
                                />
                            </div>
                        </div>
                    </div>

                    <p class="infoTxt">
                        <span class="color-red"
                            >환불적용일은 최종마감일 +1일만 가능합니다.
                        </span>
                    </p>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">&nbsp;</div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <button
                        type="button"
                        class="layerClose b-close"
                        @click="closePopup"
                    >
                        닫기
                    </button>
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>
<style scoped>
.searchform .formitem.result {
    width: 50%;
    display: inline-flex;
}

.searchform .formitem.result :deep(.full) .iteminput {
    width: auto;
}
.searchform .formitem.result :deep(.btn_ty03) {
    margin: -6px 0 0 10px;
}
</style>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'
import {
    getTodayDate,
    // getCalcDays,
    convertDate,
    errorHandle,
} from '@/utils/accUtil'

import AccSearchField from '@/components/biz/common/acc/AccSearchField'
import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import { GRID_HEADER as GRID_HEADER_DEPOSIT } from '@/const/grid/sac/rfd/sacRfdIlDpstRfndNewPopupDeposit'
import { GRID_HEADER as GRID_HEADER_BOND } from '@/const/grid/sac/rfd/sacRfdIlDpstRfndNewPopupBond'

import rfdApi from '@/api/biz/sac/rfd'

export default {
    name: 'RmtAccAccRpt',
    mixins: [CommonMixin, accMixin],
    components: { AccSearchField, AccGridTable },
    props: {
        status: {
            default: false,
        },

        // 바닥페이지 조회조건
        floorViewCond: {
            default: () => ({}),
        },

        // 수정 row 데이터
        modifyRow: {
            default: () => [],
        },
    },
    data() {
        return {
            GRID_HEADER_DEPOSIT,
            GRID_HEADER_BOND,

            initValue: {},
            pickupDepositRow: null,

            formGetSacRfdErrRfindsProcs: {
                query: {
                    dpstYymm: '',
                },

                data: {
                    rsDpstProcList: [], // 입금내역
                    rsRfndProcList: [], // 채권목록
                    rsRfndDealAccList: [], // 계좌정보
                },
            },

            formPostSacRfdErrRfinds: {
                query: {
                    rfndDt: getTodayDate('YYYYMMDD'),
                    rfndBankCd: '001',
                    depoAgreeYn: '',
                    rfndAmt: '',
                    edtForceAprvNm: '',
                    forceAprvYn: '',
                },
                data: {},
            },

            formDeleteSacRfdErrRfinds: {
                query: {},
            },

            popupParamOrgCd: {
                basMth: '',
            },

            popupParamDealcoCd: {},

            rfndDealList: [
                {
                    value: 'Y',
                    label: '입금처',
                },
                {
                    value: 'N',
                    label: '타거래처(환불)',
                },
            ],

            statusUpdateData: false, // 수정중에 다시 조회를 해버린 경우를 체크함.
        }
    },

    computed: {
        modifyData: {
            get() {
                return this.modifyRow
            },

            set(val) {
                this.$emit('update:modifyRow', val)
            },
        },

        // 입금내역 그리드 참조
        accGridTableDeposit() {
            return this.$refs.accGridTableDeposit
        },

        // 채권내역 그리드 참조
        accGridTableBond() {
            return this.$refs.accGridTableBond
        },

        // 조회전
        isBeforeInquiry() {
            return !this.formGetSacRfdErrRfindsProcs.data.rsDpstProcList.length
        },

        // 조회후 (환불거래처 == 입금처 or 예금주조회 승인됨)
        isOwnerAccount() {
            return (
                !this.isBeforeInquiry &&
                (this.formPostSacRfdErrRfinds.query.equalYn == 'Y' ||
                    this.formPostSacRfdErrRfinds.query.depoAgreeYn == 'Y')
            )
        },

        // 조회후 (환불거래처 == 타거래처)
        isOtherAccount() {
            return (
                !this.isBeforeInquiry &&
                this.formPostSacRfdErrRfinds.query.equalYn == 'N'
            )
        },

        // 환불예금주 일치 여부 (일치하면 true)
        isCheckDepo() {
            return this.formPostSacRfdErrRfinds.query.depoAgreeYn == 'Y'
        },

        // 환불예금주 조회 여부 (조회 전 false, 조회 후 true)
        statusCheckDepo() {
            return this.formPostSacRfdErrRfinds.query.depoAgreeYn != ''
        },

        // 강제승인 여부
        isForceConfirm() {
            return this.formPostSacRfdErrRfinds.query.forceAprvYn == 'Y'
        },

        // 수정상태 여부
        isModify() {
            return this.modifyRow.length > 0 ? true : false
        },

        // 수정가능 여부
        isModPosYn() {
            return (
                this.formPostSacRfdErrRfinds.query.modPosYn &&
                this.formPostSacRfdErrRfinds.query.modPosYn == 'Y'
            )
        },

        // 전송여부(확정여부), 수정 시 에만 존재함
        isFixYn() {
            return (
                this.formPostSacRfdErrRfinds.query.fixYn &&
                (this.formPostSacRfdErrRfinds.query.fixYn == '2' ||
                    this.formPostSacRfdErrRfinds.query.fixYn == '4')
            )
        },
    },
    watch: {},

    created() {},
    mounted() {
        this.initPage()
    },

    methods: {
        initPage() {
            // 거래처정보 > 환불적용일
            this.formPostSacRfdErrRfinds.query.rfndDt = getTodayDate('YYYYMMDD')

            this.initValue = {
                dpstYymm: this.floorViewCond.rfndDt.substr(0, 6),
                searchCoClOrgCd: this.floorViewCond.searchCoClOrgCd,
                orgId: this.floorViewCond.orgId,
                orgCd: this.floorViewCond.orgCd,
                orgNm: this.floorViewCond.orgNm,
                orgLvl: this.floorViewCond.orgLvl,
                orgLevel: this.floorViewCond.orgLevel,
                dpstCl: this.floorViewCond.rfndCl,
                pageNum: 1,
                pageSize: 15,
            }

            if (this.isModify) {
                const modifyData = this.modifyData[0]

                // 조회 시 필요한 것들 세팅
                this.initValue.dpstYymm = modifyData.dpstYymm.substr(0, 6)
                this.initValue.stlPlc = modifyData.dpstPlc
                this.initValue.dealNm = modifyData.dpstPlcNm
                // this.initValue.dpstCl = modifyData.rfndCl

                this.initValue.dpstRfdPlc = modifyData.dpstRfdPlc
                this.initValue.dpstRfdDt = modifyData.dpstRfdDt
                this.initValue.dpstRfdTm = modifyData.dpstRfdTm
                this.initValue.dpstRfdImagAccNo = modifyData.dpstRfdImagAccNo
                this.initValue.dpstRfdSeq = modifyData.dpstRfdSeq
                this.initValue.mod = 'M'

                Object.assign(
                    this.formGetSacRfdErrRfindsProcs.query,
                    this.initValue
                )

                // 저장 시 필요한 것들 세팅
                Object.assign(
                    this.formPostSacRfdErrRfinds.query,
                    modifyData,
                    this.initValue
                )

                this.formPostSacRfdErrRfinds.query.oldRfndDt = modifyData.rfndDt
                // this.formPostSacRfdErrRfinds.query.rfndDt = getCalcDays(
                //     'today',
                //     { count: -1, per: 'days' },
                //     'YYYYMMDD'
                // )

                if (modifyData.depoAgreeYn == 'Y') {
                    this.formPostSacRfdErrRfinds.query.depoAgreeNm = '일치'
                } else if (modifyData.depoAgreeYn == 'N') {
                    this.formPostSacRfdErrRfinds.query.depoAgreeNm = '불일치'
                }

                if (modifyData.forceAprvYn == 'Y') {
                    this.formPostSacRfdErrRfinds.query.edtForceAprvNm =
                        '강제승인'
                }

                this.formPostSacRfdErrRfinds.query.mod = 'M'

                this.getSacRfdErrRfindsProcs()
            }

            this.accSearchField.setQuery(this.initValue)

            this.popupParamDealcoCd.orgLvl = this.floorViewCond.orgLvl
            this.popupParamDealcoCd.orgLevel = this.floorViewCond.orgLvl || ''
            this.popupParamDealcoCd.orgCd = this.floorViewCond.orgCd
            this.popupParamDealcoCd.orgNm = this.floorViewCond.orgNm
        },

        closePopup() {
            const query = Object.assign(
                {
                    isModify: this.isModify,
                },
                this.accSearchField.getQuery()
            )

            this.$emit('closePopup', query)
            this.$emit('update:status', false)
        },

        resetForm() {
            this.formPostSacRfdErrRfinds.query = {}
            this.formPostSacRfdErrRfinds.data = {}

            this.initPage()

            if (this.isModify) {
                this.changeDpstYymm(this.modifyData.dpstYymm.substr(0, 6))
                this.changeOrgCd({})
            } else {
                this.formGetSacRfdErrRfindsProcs.data.rsDpstProcList = []
                this.formGetSacRfdErrRfindsProcs.data.rsRfndProcList = []
                this.formGetSacRfdErrRfindsProcs.data.rsRfndDealAccList = []

                this.pickupDepositRow = null

                this.changeDpstYymm(this.floorViewCond.rfndDt)
                this.changeOrgCd({})
            }

            this.$forceUpdate()
            this.$emit('resetPopup')
        },

        async viewForm(query) {
            if (!query.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }
            if (!query.stlPlc) {
                return this.showTcComAlert('입금처를 선택해 주세요.')
            }

            if (this.isModify) {
                // if (
                //     await this.showTcComConfirm(
                //         '수정중인 내용이 사라집니다. 조회하시겠습니까?'
                //     )
                // ) {
                this.statusUpdateData = true
                this.modifyData = []
                // } else {
                //     return
                // }
            }

            Object.assign(this.formGetSacRfdErrRfindsProcs.query, query)
            this.getSacRfdErrRfindsProcs()
        },

        async saveForm() {
            // 환불 처리 여부를 검사
            if (this.formPostSacRfdErrRfinds.query.refundYn == 'Y') {
                return this.showTcComAlert('환불처리 된 데이터 입니다')
            }

            // 환불 처리 여부를 검사
            // if (!this.formPostSacRfdErrRfinds.query.rfndBankCd) {
            //     return this.showTcComAlert(
            //         '거래처 관리의 환불은행을 확인하십시오'
            //     )
            // }

            // if (!this.formPostSacRfdErrRfinds.query.rfndDealCo) {
            //     return this.showTcComAlert('환불거래처를 입력하세요')
            // }

            if (!this.formPostSacRfdErrRfinds.query.rfndAccNo) {
                return this.showTcComAlert('환불계좌를 입력하세요')
            }

            if (
                // !this.formPostSacRfdErrRfinds.query.rfndAccNo.test(/^[0-9]+$/g)
                isNaN(this.formPostSacRfdErrRfinds.query.rfndAccNo)
            ) {
                return this.showTcComAlert('환불계좌는 숫자만 가능합니다')
            }

            console.log('선택된 row =>', this.pickupDepositRow)
            if (!this.pickupDepositRow) {
                return this.showTcComAlert(
                    '환불진행시 환불 대상 입금내역을 선택해야 합니다'
                )
            }

            if (
                !this.formPostSacRfdErrRfinds.query.rfndAmt ||
                this.formPostSacRfdErrRfinds.query.rfndAmt == '0'
            ) {
                return this.showTcComAlert('환불액을 입력하세요.')
            }
            if (!this.formPostSacRfdErrRfinds.query.rfndBankCd) {
                return this.showTcComAlert('환불은행을 입력하세요')
            }

            if (!this.formPostSacRfdErrRfinds.query.rfndDepo) {
                return this.showTcComAlert('환불예금주를 입력하세요')
            }

            // 강제승인 상태
            if (this.isForceConfirm) {
                this.formPostSacRfdErrRfinds.query.depoAgreeYn = 'N'
            } else {
                if (this.formPostSacRfdErrRfinds.query.equalYn != 'Y') {
                    // 예금주 조회를 하지 않았으면
                    if (!this.statusCheckDepo) {
                        return this.showTcComAlert(
                            '환불예금주 확인후 저장하십시오. 적용하시려면 강제승인 후 저장하십시요'
                        )
                    }

                    // 환불예금주 조회여부 일치
                    if (this.formPostSacRfdErrRfinds.query.depoAgreeYn == 'Y') {
                        this.formPostSacRfdErrRfinds.query.forceAprvYn = 'N'
                    } else {
                        return this.showTcComAlert(
                            '환불예금주가 상이합니다.\n환불정보를 수정 후 재조회하거나, 적용하시려면\n강제승인후 저장하십시오.'
                        )
                    }
                }
            }

            if (
                this.formPostSacRfdErrRfinds.query.rfndAmt >
                this.pickupDepositRow.rfndPossAmt +
                    this.pickupDepositRow.rfndAmt
            ) {
                return this.showTcComAlert(
                    '환불액은 선택한 입금내역의 환불가능금액과 같거나 작아야 합니다.'
                )
            }

            if (this.isModify) {
                if (this.isFixYn) {
                    return this.showTcComAlert(
                        'ERP 전송건은 수정 또는 삭제하실 수 없습니다'
                    )
                }
                if (!this.isModPosYn) {
                    return this.showTcComAlert(
                        '마지막 환불금만 수정가능합니다.'
                    )
                }

                // 메인화면에서 넘겨준 수정대상과 현재 입금내역에 선택된 대상이 동일하지 않으면 오류
                // const dpstRow =
                //     this.formGetSacRfdErrRfindsProcs.data.rsDpstProcList[0]
                const dpstRow = this.pickupDepositRow

                if (
                    dpstRow.dpstPlc != this.modifyData[0].dpstRfdPlc ||
                    dpstRow.dpstDt != this.modifyData[0].dpstRfdDt ||
                    dpstRow.dpstTm != this.modifyData[0].dpstRfdTm ||
                    dpstRow.imagAccNo != this.modifyData[0].dpstRfdImagAccNo
                ) {
                    return this.showTcComAlert(
                        '선택한 수정대상의 입금내역이 아닙니다. 다시 확인하십시오.'
                    )
                }
            }

            if (await this.showTcComConfirm(`저장 하시겠습니까?`)) {
                const query = {
                    // rfndDealCo: this.modifyData[0].rfndDealCoCd,
                    rfndCl: this.formGetSacRfdErrRfindsProcs.query.dpstPlc,
                    dpstYymm: this.formGetSacRfdErrRfindsProcs.query.dpstYymm,
                    orgId: this.formGetSacRfdErrRfindsProcs.query.orgId,
                    dpstPlc: this.formGetSacRfdErrRfindsProcs.query.stlPlc,
                    bankCd: this.formPostSacRfdErrRfinds.query.rfndBankCd,
                }

                if (
                    this.formGetSacRfdErrRfindsProcs.data.rsRfndProcList.length
                ) {
                    query.imagAccNo =
                        this.formGetSacRfdErrRfindsProcs.data.rsRfndProcList[0].imagAccNo
                }

                // if (this.formPostSacRfdErrRfinds.query.dealCoCl == 'A2') {
                if (this.formPostSacRfdErrRfinds.query.rfndDealCoCl == 'A2') {
                    query.jourCd = 'R12'
                } else {
                    query.jourCd = 'R11'
                }

                if (this.isModify) {
                    // 2020.07.06     요건협의서 00002448 조직별오입금환불관리 ERP전송 구분 수정, 요금구분없앰
                    query.rfndDealCo = this.modifyData[0].rfndDealCoCd
                    query.rfndCl = this.modifyData[0].rfndCl
                    query.dpstYymm = this.modifyData[0].dpstYymm
                    query.orgId = this.modifyData[0].orgId
                    query.dpstId = this.modifyData[0].stlPlc
                    query.imagAccNo = this.modifyData[0].imagAccNo
                    query.bankCd = this.modifyData[0].bankCd
                }

                this.formPostSacRfdErrRfinds.query.rfindInfoVo = {
                    ...this.formPostSacRfdErrRfinds.query,
                    ...this.formGetSacRfdErrRfindsProcs.query,
                    ...query,
                }
                // this.formPostSacRfdErrRfinds.query.rfindInfoVoList = [query]
                this.formPostSacRfdErrRfinds.query.rsDpstProcList = [
                    this.pickupDepositRow,
                ]

                console.log('post 쿼리 =>', this.formPostSacRfdErrRfinds.query)

                return this.postSacRfdErrRfinds()
            } else {
                return this.showTcComAlert('저장이 취소되었습니다')
            }
        },

        //  수정일 경우만 삭제가 가능
        async deleteForm() {
            if (this.isFixYn) {
                return this.showTcComAlert(
                    `ERP 전송건은 수정 또는 삭제하실 수 없습니다.`
                )
            }

            if (
                convertDate(
                    this.formPostSacRfdErrRfinds.query.rfndDt,
                    'YYYYMM'
                ) != getTodayDate('YYYYMM')
            ) {
                return this.showTcComAlert(
                    `${getTodayDate('YYYY/MM')}월의 환불정보만 삭제가능합니다`
                )
            }

            // 입금내역 테이블 데이터와 메인화면에서 넘어온 데이타가 동일하지 않으면 오류. (조회를 다시 했다거나 하면 삭제 불가)
            if (
                this.pickupDepositRow.dpstPlc !=
                    this.modifyData[0].dpstRfdPlc ||
                this.pickupDepositRow.dpstDt != this.modifyData[0].dpstRfdDt ||
                this.pickupDepositRow.dpstTm != this.modifyData[0].dpstRfdTm ||
                this.pickupDepositRow.imagAccNo !=
                    this.modifyData[0].dpstRfdImagAccNo
            ) {
                return this.showTcComAlert(
                    `선택한 삭제대상 환불건의 입금내역이 아닙니다. 다시 확인하십시오.`
                )
            }

            this.formPostSacRfdErrRfinds.query.mod = 'D'
            this.formPostSacRfdErrRfinds.query.rfindInfoVo = {
                ...this.formPostSacRfdErrRfinds.query,
                ...this.formGetSacRfdErrRfindsProcs.query,
                // ...query,
            }

            // this.formPostSacRfdErrRfinds.query.mod = 'D'
            // this.formDeleteSacRfdErrRfinds.query.rfindInfoVoList = [
            //     {
            //         mod: 'D',
            //         chk: 1,
            //         ...this.formPostSacRfdErrRfinds.query,
            //     },
            // ]

            if (await this.showTcComConfirm('삭제 하시겠습니까?')) {
                // return this.deleteSacRfdErrRfinds()
                return this.postSacRfdErrRfinds()
                    .then(this.closePopup)
                    .catch(errorHandle)
            }
        },

        clickForceConfirm() {
            // if (!this.statusCheckDepo) {
            //     return this.showTcComAlert(
            //         '환불예금주 조회후 조회결과를 확인하신후에 처리하십시오.'
            //     )
            // }

            this.formPostSacRfdErrRfinds.query.forceAprvYn = 'Y'
            this.formPostSacRfdErrRfinds.query.edtForceAprvNm = '강제승인'

            return this.showTcComAlert('강제승인 처리 되었습니다')
        },

        clickAccountSearch() {
            if (this.formPostSacRfdErrRfinds.query.rfndAccNo == '') {
                return this.showTcComAlert('환불계좌를 입력하십시오.')
            }
            if (this.formPostSacRfdErrRfinds.query.rfndBankCd == '') {
                return this.showTcComAlert('환불은행을 선택하십시오.')
            }
            if (this.formPostSacRfdErrRfinds.query.rfndDepo == '') {
                return this.showTcComAlert('환불예금주를 입력해주세요.')
            }
            const query = {
                slcmDfryBankCd: this.formPostSacRfdErrRfinds.query.rfndBankCd,
                slcmDfryAccNo: this.formPostSacRfdErrRfinds.query.rfndAccNo,
                // slcmDfryDepo: this.formPostSacRfdErrRfinds.query.rfndDepo,
            }

            return rfdApi.getSacRfdScmDfryDepoes(query).then((res) => {
                if (
                    this.formPostSacRfdErrRfinds.query.rfndDepo ==
                    res.slcmDfryDepo
                ) {
                    this.formPostSacRfdErrRfinds.query.depoAgreeYn = 'Y'
                    this.formPostSacRfdErrRfinds.query.depoAgreeNm = '일치'
                    this.formPostSacRfdErrRfinds.query.sapRfndDepo =
                        res.slcmDfryDepo
                } else {
                    this.formPostSacRfdErrRfinds.query.depoAgreeYn = 'N'
                    this.formPostSacRfdErrRfinds.query.depoAgreeNm = '불일치'
                    this.formPostSacRfdErrRfinds.query.sapRfndDepo =
                        res.slcmDfryDepo
                }
            })
        },

        changeDpstYymm(date) {
            this.popupParamOrgCd.basMth = date
            this.popupParamDealcoCd.basDay = date
        },

        changeEqualYn(query) {
            this.formPostSacRfdErrRfinds.query.equalYn = query.value
            this.formPostSacRfdErrRfinds.query.rfndDealCoNm = query.label

            console.log(this.pickupDepositRow)
            if (query.value == 'N') {
                // 환불계좌, 환불액, 환불은행, 환불예금주
                this.formPostSacRfdErrRfinds.query.rfndAccNo = ''
                // this.formPostSacRfdErrRfinds.query.rfndAmt = ''
                this.formPostSacRfdErrRfinds.query.rfndBankCd = ''
                this.formPostSacRfdErrRfinds.query.rfndDepo = ''
            } else {
                Object.assign(
                    this.formPostSacRfdErrRfinds.query,
                    this.formPostSacRfdErrRfinds.data
                )
            }
        },

        changeOrgCd(query) {
            const { orgCd, orgNm, orgLvl, orgLevel } = query

            this.popupParamDealcoCd.orgLvl = orgLvl || ''
            this.popupParamDealcoCd.orgLevel = orgLevel || ''
            this.popupParamDealcoCd.orgCd = orgCd
            this.popupParamDealcoCd.orgNm = orgNm

            this.popupParamOrgCd.orgCd = orgCd
            this.popupParamOrgCd.orgNm = orgNm
        },

        postSaveReports() {
            return rfdApi
                .postRmtAccReports(this.formGetSacRfdErrRfindsProcs.query)
                .then((res) => {
                    console.log(res)
                    return this.showTcComAlert(`정상적으로 저장되었습니다.`)
                })
        },

        depositRowUpdated(row, rowIdx) {
            if (row.rfndPossAmt == 0) {
                this.accGridTableDeposit.modifyRowData(rowIdx, { rfndYn: '0' })
                return this.showTcComAlert('환불가능금액이 없습니다')
            }

            if (row.rfndYn == 0) {
                this.pickupDepositRow = null
            } else {
                this.pickupDepositRow =
                    this.accGridTableDeposit.getRowDataInIdx(rowIdx)
            }

            // 다른항목들의 rfndYn 을 0 처리한다.
            for (
                let a = 0,
                    b =
                        this.formGetSacRfdErrRfindsProcs.data.rsDpstProcList
                            .length;
                a < b;
                a++
            ) {
                if (a != rowIdx)
                    this.accGridTableDeposit.modifyRowData(a, { rfndYn: '0' })
            }

            // 신규 일 경우 환불가능금액을 환불액에 입력
            if (!this.isModify) {
                if (row.rfndYn == 0) {
                    this.formPostSacRfdErrRfinds.query.rfndAmt = ''
                } else {
                    this.formPostSacRfdErrRfinds.query.rfndAmt = row.rfndPossAmt
                }

                this.$forceUpdate()
            }
        },

        getSacRfdErrRfindsProcs() {
            // if (this.isModify) {
            //     this.formPostSacRfdErrRfinds.query.rfndDealCoNm =
            //         this.modifyData[0].rfndDealCoNm
            //     this.formPostSacRfdErrRfinds.query.rfndDealCoCd =
            //         this.modifyData[0].rfndDealCo

            //     if (
            //         this.modifyData[0].equalYn == 'Y' &&
            //         this.formPostSacRfdErrRfinds.query.rfndDealCoCd ==
            //             this.formGetSacRfdErrRfindsProcs.query.stlPlc
            //     ) {
            //         this.formPostSacRfdErrRfinds.query.rfndDealCoNm = '입금처'
            //         this.formPostSacRfdErrRfinds.query.equalYn = 'Y'
            //     } else if (
            //         this.modifyData[0].equalYn == 'N' &&
            //         this.formPostSacRfdErrRfinds.query.rfndDealCoCd == '99999'
            //     ) {
            //         this.formPostSacRfdErrRfinds.query.rfndDealCoNm =
            //             '타거래처(환불)'
            //         this.formPostSacRfdErrRfinds.query.equalYn = 'N'
            //     }

            //     this.formPostSacRfdErrRfinds.query.rfndAccNo =
            //         this.modifyData[0].rfndAccNo
            //     this.formPostSacRfdErrRfinds.query.rfndBankCd =
            //         this.modifyData[0].rfndBankCd
            //     this.formPostSacRfdErrRfinds.query.rfndDepo =
            //         this.modifyData[0].rfndDepo
            // } else {
            //     // MA or B&C MA
            //     if (
            //         MOCK_DATA.rsRfndDealAccList[0].rfndDealCoCl == 'M1' ||
            //         MOCK_DATA.rsRfndDealAccList[0].rfndDealCoCl == 'M2'
            //     ) {
            //         this.rfndDealList = [] // 환불거래처(입금처) 삭제
            //     } else {
            //         // 환불거래처명 수정(COMBO박스)
            //         this.rfndDealList = [
            //             {
            //                 value: 'Y',
            //                 label: '입금처',
            //             },
            //             {
            //                 value: 'N',
            //                 label: '타거래처(환불)',
            //             },
            //         ]
            //     }
            // }

            // Object.assign(
            //     this.formPostSacRfdErrRfinds.query,
            //     MOCK_DATA.rsRfndDealAccList[0]
            // )

            // this.formPostSacRfdErrRfinds.query.equalYn = 'Y'

            // this.formGetSacRfdErrRfindsProcs.data.rsDpstProcList =
            //     MOCK_DATA.rsDpstProcList // 입금내역
            // this.formGetSacRfdErrRfindsProcs.data.rsRfndProcList =
            //     MOCK_DATA.rsRfndProcList // 채권목록
            // this.formGetSacRfdErrRfindsProcs.data.rsRfndDealAccList =
            //     MOCK_DATA.rsRfndDealAccList // 계좌정보

            // return Promise.resolve()

            return rfdApi
                .getSacRfdErrRfindsProcs(this.formGetSacRfdErrRfindsProcs.query)
                .then((res) => {
                    console.log(res)

                    // this.formPostSacRfdErrRfinds.query.equalYn = 'Y'

                    this.formGetSacRfdErrRfindsProcs.data.rsDpstProcList =
                        res.rsDpstProcList // 입금내역
                    this.formGetSacRfdErrRfindsProcs.data.rsRfndProcList =
                        res.rsRfndProcList // 채권목록
                    this.formGetSacRfdErrRfindsProcs.data.rsRfndDealAccList =
                        res.rsRfndDealAccList // 계좌정보

                    this.formPostSacRfdErrRfinds.data = Object.assign(
                        {},
                        res.rsRfndDealAccList[0]
                    )

                    if (res.rsDpstProcList.length) {
                        this.formPostSacRfdErrRfinds.data.rfndDealCo =
                            res.rsDpstProcList[0].rfndDealCo
                    }

                    if (res.rsRfndProcList.length) {
                        this.formPostSacRfdErrRfinds.data.bankCd =
                            res.rsRfndProcList[0].bankCd
                    }

                    if (this.isModify) {
                        const modifyData = this.modifyData[0]

                        this.formPostSacRfdErrRfinds.data.rfndDealCoNm =
                            modifyData.rfndDealCoNm
                        this.formPostSacRfdErrRfinds.data.rfndDealCoCd =
                            modifyData.rfndDealCo

                        // 환불대상 체크된 데이터 기록
                        res.rsDpstProcList.forEach((arr) => {
                            if (arr.rfndYn == 1) this.pickupDepositRow = arr
                        })

                        if (
                            modifyData.equalYn == 'Y' &&
                            this.formPostSacRfdErrRfinds.data.rfndDealCoCd ==
                                this.formGetSacRfdErrRfindsProcs.query.stlPlc
                        ) {
                            this.formPostSacRfdErrRfinds.data.rfndDealCoNm =
                                '입금처'
                            this.formPostSacRfdErrRfinds.data.equalYn = 'Y'
                        } else if (modifyData.equalYn == 'N') {
                            this.formPostSacRfdErrRfinds.data.rfndDealCoNm =
                                '타거래처(환불)'
                            this.formPostSacRfdErrRfinds.data.equalYn = 'N'
                        }

                        // 수정진입 시 하나가 선택되어야 함
                        // this.formGetSacRfdErrRfindsProcs.data.rsDpstProcList.forEach(
                        //     (arr) => {
                        //         console.log(arr.dpstTm, modifyData.dpstRfdTm)
                        //         if (arr.dpstTm == modifyData.dpstRfdTm)
                        //             arr.rfndYn = 1
                        //     }
                        // )

                        this.formPostSacRfdErrRfinds.data.rfndDealCo =
                            modifyData.rfndDealCo
                        this.formPostSacRfdErrRfinds.data.rfndAccNo =
                            modifyData.rfndAccNo
                        this.formPostSacRfdErrRfinds.data.rfndBankCd =
                            modifyData.rfndBankCd
                        this.formPostSacRfdErrRfinds.data.rfndDepo =
                            modifyData.rfndDepo
                    } else {
                        // MA or B&C MA
                        if (
                            res.rsRfndDealAccList[0].rfndDealCoCl == 'M1' ||
                            res.rsRfndDealAccList[0].rfndDealCoCl == 'M2'
                        ) {
                            this.rfndDealList = [] // 환불거래처(입금처) 삭제
                        } else {
                            // 환불거래처명 수정(COMBO박스)
                            this.rfndDealList = [
                                {
                                    value: 'Y',
                                    label: '입금처',
                                },
                                {
                                    value: 'N',
                                    label: '타거래처(환불)',
                                },
                            ]
                        }
                    }

                    Object.assign(
                        this.formPostSacRfdErrRfinds.query,
                        this.formPostSacRfdErrRfinds.data
                    )
                })
        },

        postSacRfdErrRfinds() {
            const query = { ...this.formPostSacRfdErrRfinds.query }
            // query.mod = 'D'

            return rfdApi
                .postSacRfdErrRfinds(query)
                .then((res) => {
                    console.log(res)
                    if (res) {
                        this.showTcComAlert('저장되었습니다.')
                    }
                })
                .catch(errorHandle)
        },

        deleteSacRfdErrRfinds() {
            return rfdApi
                .deleteSacRfdErrRfinds(this.formDeleteSacRfdErrRfinds.query)
                .then((res) => {
                    console.log(res)
                    this.showTcComAlert(`정상적으로 처리되었습니다.`)
                })
        },
    },
}
</script>
