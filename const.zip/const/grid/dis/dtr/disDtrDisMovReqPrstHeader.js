import { ValueType } from 'realgrid'

export const DisDtrDisMovReqPrstGRID_HEADER = {
    fields: [
        {
            fieldName: 'reqDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'reqOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDealSktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repProdYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorUnrelYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnReqQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'movQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'approvalBtn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rejectBtn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'assignBtn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqFixUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqStCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqOrgCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'reqDt',
            fieldName: 'reqDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
            width: '100',
        },
        {
            name: 'reqOrgNm',
            fieldName: 'reqOrgNm',
            type: 'data',
            width: '400',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'reqDealSktCd',
            fieldName: 'reqDealSktCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'reqDealcoCd',
            fieldName: 'reqDealcoCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'reqDealcoNm',
            fieldName: 'reqDealcoNm',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청매장',
                showTooltip: false,
            },
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            width: '130',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '채널코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '150',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'petNm',
            fieldName: 'petNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '펫네임',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'reqClNm',
            fieldName: 'reqClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: '130',
            header: {
                text: '개봉상태',
                showTooltip: false,
            },
        },
        {
            name: 'repProdYn',
            fieldName: 'repProdYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorUnrelYn',
            fieldName: 'colorUnrelYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상무관',
                showTooltip: false,
            },
        },
        {
            name: 'disQty',
            fieldName: 'disQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장재고',
                showTooltip: false,
            },
        },
        {
            name: 'reqQty',
            fieldName: 'reqQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청수량',
                showTooltip: false,
            },
        },
        {
            name: 'asgnReqQty',
            fieldName: 'asgnReqQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정수량',
                showTooltip: false,
            },
        },
        {
            name: 'movQty',
            fieldName: 'movQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '이동수량',
                showTooltip: false,
            },
        },
        {
            name: 'reqStNm',
            fieldName: 'reqStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '진행상태',
                showTooltip: false,
            },
        },
        {
            name: 'approvalBtn',
            fieldName: 'approvalBtn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '승인',
                showTooltip: false,
            },
            editable: false,
            renderer: {
                type: 'button',
            },
            width: '100',
        },
        {
            name: 'rejectBtn',
            fieldName: 'rejectBtn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '반려',
                showTooltip: false,
            },
            editable: false,
            renderer: {
                type: 'button',
            },
            width: '100',
        },
        {
            name: 'assignBtn',
            fieldName: 'assignBtn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정',
                showTooltip: false,
            },
            editable: false,
            renderer: {
                type: 'button',
            },
            width: '100',
        },
        {
            name: 'reqFixUserNm',
            fieldName: 'reqFixUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
                showTooltip: false,
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'reqStCd',
            fieldName: 'reqStCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'reqMgmtNo',
            fieldName: 'reqMgmtNo',
            visible: false,
            type: 'data',
        },
        {
            name: 'reqOrgCd',
            fieldName: 'reqOrgCd',
            visible: false,
            type: 'data',
        },
    ],
}
