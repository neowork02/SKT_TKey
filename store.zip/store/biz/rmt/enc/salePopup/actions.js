import api from '@/api/biz/rmt/enc/rmtEncSalePopup'
import types from './mutation-types'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    // eslint-disable-next-line no-unused-vars
    async getRmtEncSalePopupListSale_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getRmtEncSalePopupListSale_', searchParams)
        await api.getRmtEncSalePopupListSale_({ searchParams }).then((data) => {
            console.log('🚀 ~ getRmtEncSalePopupListSale_ ~ .then ~ data', data)
            resultData = data
        })
        return resultData
    },
    // eslint-disable-next-line no-unused-vars
    async getRmtEncSalePopupListSvcNum_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getRmtEncSalePopupListSvcNum_', searchParams)
        await api
            .getRmtEncSalePopupListSvcNum_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ getRmtEncSalePopupListSvcNum_ ~ .then ~ data',
                    data
                )
                resultData = data
            })
        return resultData
    },
    // eslint-disable-next-line no-unused-vars
    async getRmtEncSalePopupListPcode_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getRmtEncSalePopupListPcode_', searchParams)
        await api
            .getRmtEncSalePopupListPcode_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ getRmtEncSalePopupListPcode_ ~ .then ~ data',
                    data
                )
                resultData = data
            })
        return resultData
    },
    // eslint-disable-next-line no-unused-vars
    async getRmtEncSalePopupList_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getRmtEncSalePopupList_', searchParams)
        await api.getRmtEncSalePopupList_({ searchParams }).then((data) => {
            console.log('🚀 ~ getRmtEncSalePopupList_ ~ .then ~ data', data)
            resultData = data
        })
        return resultData
    },
    // async getRmtEncSalePopupList_({ state, commit }) {
    //     let resultData
    //     let searchParams = state.searchParams
    //     searchParams.pageSize = state.initPaging.pageSize
    //     searchParams.pageNum = state.paging.pageNum
    //     console.log(
    //         '🚀 ~ file: actions.js ~ line 87 ~ searchParams',
    //         searchParams
    //     )
    //     await api
    //         .getRmtEncSalePopupList_({ searchParams })
    //         .then((data) => {
    //             console.log(
    //                 '🚀 ~ file: actions.js ~ getRmtEncSalePopupList_ ~ .then ~ data',
    //                 data
    //             )
    //             if (data !== undefined) {
    //                 commit(types.DEFAULT_ASSIGN, {
    //                     key: 'paging',
    //                     value: data.pagingDto,
    //                 })
    //                 let body = data.gridList
    //                 commit(types.DEFAULT_ASSIGN, {
    //                     key: 'resultList',
    //                     value: body,
    //                 })
    //             } else {
    //                 commit(types.DEFAULT_ASSIGN, {
    //                     key: 'paging',
    //                     value: state.initPaging,
    //                 })
    //                 commit(types.DEFAULT_ASSIGN, {
    //                     key: 'resultList',
    //                     value: [],
    //                 })
    //             }

    //             resultData = data
    //         })
    //         .catch((error) => {
    //             throw error
    //         })
    //     const _sleep = (delay) =>
    //         new Promise((resolve) => setTimeout(resolve, delay))
    //     const timer = async () => {
    //         await _sleep(200)
    //     }
    //     await timer()

    //     return resultData
    // },
    // eslint-disable-next-line no-unused-vars
    async saveSalePopup_({ state, commit }, formData) {
        console.log('🚀 ~ saveSalePopup_ ~ formData', formData)
        let result = await api.saveSalePopup_(formData)
        return result
    },
    // // eslint-disable-next-line no-unused-vars
    // async saveSalePopup_({ state, commit }, { saveRows }) {
    //     console.log('🚀 ~ file: actions.js ~ line 128 ~ saveRows', saveRows)
    //     let result = 0
    //     await api
    //         .saveSalePopup_(saveRows)
    //         .then((data) => {
    //             console.log(
    //                 '🚀 ~ file: actions.js ~ saveSalePopup_~ .then ~ data',
    //                 data
    //             )
    //             result = data
    //         })
    //         .catch((error) => {
    //             throw error
    //         })
    //     // const _sleep = (delay) =>
    //     //     new Promise((resolve) => setTimeout(resolve, delay))
    //     // const timer = async () => {
    //     //     await _sleep(1000)
    //     // }
    //     // await timer()
    //     return result
    // },
}
