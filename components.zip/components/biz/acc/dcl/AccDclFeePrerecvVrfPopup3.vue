<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccDclFeePrerecvVrfPopup3.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="statusShow" size="1000px">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <p class="popTitle">예수금미등록상세</p>

                <div class="layerCont">
                    <AccGridTable
                        ref="accGridTable"
                        isColumnNo
                        :offset="[]"
                        :gridMeta="GRID_HEADER"
                        :data="data"
                    />

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom"></div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <button
                        type="button"
                        class="layerClose b-close"
                        @click="closePopup"
                    >
                        닫기
                    </button>
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>
<script>
import CommonMixin from '@/mixins'
// import { getCalcDays } from '@/utils/accUtil'

import AccGridTable from '@/components/biz/common/acc/AccGridTable'

import { GRID_HEADER } from '@/const/grid/acc/dcl/AccDclFeePrerecvVrfPopup3Grid'

export default {
    name: 'AccDclFeePrerecvVrfPopup3',
    mixins: [CommonMixin],
    components: { AccGridTable },
    props: {
        status: {
            default: false,
        },

        data: {
            default: () => [],
        },
    },
    data() {
        return {
            GRID_HEADER,
        }
    },
    computed: {
        statusShow: {
            get() {
                return this.status
            },
            set(value) {
                this.$emit('update:status', value)
            },
        },
    },
    watch: {},

    created() {
        this.initPage()
    },
    mounted() {},
    methods: {
        initPage() {},

        closePopup() {
            this.statusShow = false
        },
    },
}
</script>
