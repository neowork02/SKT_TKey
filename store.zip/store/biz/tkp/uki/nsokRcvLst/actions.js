import api from '@/api/biz/tkp/uki/tkpUkiNsokRcvLst'
import types from './mutation-types'

export default {
    async defaultAssign_({ commit }, { key, value }) {
        commit(types.DEFAULT_ASSIGN, {
            key,
            value,
        })
    },
    async dropDownCmmonCodes_({ state, commit }, { key, columnName, option }) {
        let result = await api.dropDownCmmonCodes_(key)
        let values = []
        let labels = []
        values = result.map((a) => a.commCdVal)
        labels = result.map((a) => a.commCdValNm)
        if (option != undefined) {
            values.unshift('')
            labels.unshift(option)
        }

        let obj1 = {}
        obj1[columnName] = {
            values: values,
            labels: labels,
        }
        commit(types.DEFAULT_ASSIGN, {
            key: 'commDropDown',
            value: { ...state.commDropDown, ...obj1 },
        })
    },
    // eslint-disable-next-line no-unused-vars
    async getTkpUkiNsokRcvLstDetailIfs_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getTkpUkiNsokRcvLstDetailIfs_', searchParams)
        await api
            .getTkpUkiNsokRcvLstDetailIfs_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ getTkpUkiNsokRcvLstDetailIfs_ ~ .then ~ data',
                    data
                )
                resultData = data
            })
        return resultData
    },
    // eslint-disable-next-line no-unused-vars
    async getTkpUkiNsokRcvLstDetailMgmts_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getTkpUkiNsokRcvLstDetailMgmts_', searchParams)
        await api
            .getTkpUkiNsokRcvLstDetailMgmts_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ getTkpUkiNsokRcvLstDetailMgmts_ ~ .then ~ data',
                    data
                )
                resultData = data
            })
        return resultData
    },
    // eslint-disable-next-line no-unused-vars
    async getTkpUkiNsokRcvLstDetailIfStatus_({ state, commit }, { param }) {
        let resultData
        let searchParams = param
        console.log('🚀 ~ getTkpUkiNsokRcvLstDetailIfStatus_', searchParams)
        await api
            .getTkpUkiNsokRcvLstDetailIfStatus_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ getTkpUkiNsokRcvLstDetailIfStatus_ ~ .then ~ data',
                    data
                )
                resultData = data
            })
        return resultData
    },
    async getTkpUkiNsokRcvLstList_({ state, commit }) {
        let resultData
        let searchParams = state.searchParams
        searchParams.pageSize = state.initPaging.pageSize
        searchParams.pageNum = state.paging.pageNum
        console.log('🚀 ~ getTkpUkiNsokRcvLstList_', searchParams)
        await api
            .getTkpUkiNsokRcvLstList_({ searchParams })
            .then((data) => {
                console.log(
                    '🚀 ~ getTkpUkiNsokRcvLstList_ ~ .then ~ data',
                    data
                )
                if (data !== undefined) {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: data.pagingDto,
                    })
                    let body = data.gridList
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: body,
                    })
                } else {
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'paging',
                        value: state.initPaging,
                    })
                    commit(types.DEFAULT_ASSIGN, {
                        key: 'resultList',
                        value: [],
                    })
                }

                resultData = data
            })
            .catch((error) => {
                throw error
            })
        const _sleep = (delay) =>
            new Promise((resolve) => setTimeout(resolve, delay))
        const timer = async () => {
            await _sleep(200)
        }
        await timer()

        return resultData
    },
    // eslint-disable-next-line no-unused-vars
    async saveNsokRcvLst_({ state, commit }, formData) {
        console.log('🚀 ~ saveNsokRcvLst_ ~ formData', formData)
        let result = 0
        await api
            .saveNsokRcvLst_(formData)
            .then((data) => {
                console.log('🚀 ~ saveNsokRcvLst_~ .then ~ data', data)
                result = data
            })
            .catch((error) => {
                throw error
            })
        // const _sleep = (delay) =>
        //     new Promise((resolve) => setTimeout(resolve, delay))
        // const timer = async () => {
        //     await _sleep(1000)
        // }
        // await timer()
        return result
    },
    // eslint-disable-next-line no-unused-vars
    async updateSaleChgDtm_({ state, commit }, formData) {
        console.log('🚀 ~ updateSaleChgDtm_ ~ formData', formData)
        let result = await api.updateSaleChgDtm_(formData)
        return result
    },
    // eslint-disable-next-line no-unused-vars
    async cancelNsokDtlUpdate_({ state, commit }, formData) {
        console.log('🚀 ~ cancelNsokDtlUpdate_ ~ formData', formData)
        let result = await api.cancelNsokDtlUpdate_(formData)
        return result
    },
}
