export default {
    //alert message
    alertShow: false,
    alertHeaderText: '',
    alertBodyText: '',
    loadingShow: false,
    snackbar: false,
    snackbarText: '',
    //paging
    paging: {
        pageNum: 1, //fix
        pageSize: 100,
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    initPaging: {
        pageNum: 1, //fix
        pageSize: 100, //9999 9500건이 넘음 AS-IS 95건 ?? //100 테스트시 페이지 해제와 페이지 사이즈 100 이하 조정후 테스트 할것. 개발vdi BE 리소스 부족으로 테스트 못함
        totalPageCnt: 0,
        totalDataCnt: 0,
    },
    saveAction: false,
    saveDoneA: false,
    saveDoneB: false,

    commDropDown: {},

    commCdIds: [],
    resultList: [],
    resultListCopy: [],

    searchParams: {},
}
