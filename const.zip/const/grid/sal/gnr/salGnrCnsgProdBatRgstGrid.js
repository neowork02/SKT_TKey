import { ValueType } from 'realgrid'

export const GRIDHEADER = {
    fields: [
        {
            fieldName: 'chk',
            dataType: ValueType.TEXT, // 선택
        },
        {
            fieldName: 'jobFlag',
            dataType: ValueType.TEXT, // 작업유형
        },
        {
            fieldName: 'saleTypCd',
            dataType: ValueType.TEXT, // 판매유형코드
        },
        {
            fieldName: 'giveMthdCd',
            dataType: ValueType.TEXT, // 인도방식코드
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, // 일련번호
        },
        {
            fieldName: 'prodQty',
            dataType: ValueType.NUMBER, // 수량
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, // 상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, // 모델(상품명)
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, // 색상코드
        },
        {
            fieldName: 'prodDesc',
            dataType: ValueType.TEXT, // 상품설명
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, // 상품구분
        },
        {
            fieldName: 'saleUprc',
            dataType: ValueType.NUMBER, // 판매단가
        },
        {
            fieldName: 'fixStrdSalePrc',
            dataType: ValueType.NUMBER, // 확정기준판매가격
        },
        {
            fieldName: 'freeProdSaleNo',
            dataType: ValueType.TEXT, // 일반상품판매번호
        },
        {
            fieldName: 'freeProdSaleChgSeq',
            dataType: ValueType.TEXT, // 일반상품판매변경번호
        },
        {
            fieldName: 'pkgProdSaleNo',
            dataType: ValueType.TEXT, // 일반상품주문번호
        },
        {
            fieldName: 'pkgProdSaleChgSeq',
            dataType: ValueType.TEXT, // 일반상품주문변경순번
        },
        {
            fieldName: 'saleDtm',
            //dataType: ValueType.TEXT, // 판매일시
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'disAmt',
            dataType: ValueType.NUMBER, // 매입가
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT, // 처리자ID
        },
        {
            fieldName: 'opDt',
            //dataType: ValueType.TEXT, // 전문일자
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'opTm',
            dataType: ValueType.TEXT, // IF처리시각
        },
        {
            fieldName: 'opSeq',
            dataType: ValueType.TEXT, // 전문순번
        },
        {
            fieldName: 'twdOrdNo',
            dataType: ValueType.TEXT, // TWD주문번호
        },
        {
            fieldName: 'disClCd',
            dataType: ValueType.TEXT, // 재고구분코드
        },
        {
            fieldName: 'amt',
            dataType: ValueType.NUMBER, // 수량
        },
    ],
    columns: [
        {
            name: 'saleTypCd',
            fieldName: 'saleTypCd',
            type: 'data',
            width: '100',
            header: {
                text: '판매유형',
                showTooltip: false,
            },
            editable: false,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'giveMthdCd',
            fieldName: 'giveMthdCd',
            type: 'data',
            width: '100',
            header: {
                text: '배송구분',
                showTooltip: false,
            },
            editable: false,
            lookupDisplay: true,
            values: [],
            labels: [],
            editor: {
                type: 'dropdown',
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            styleName: 'left-column',
            header: {
                text: '모델',
                showTooltip: true,
            },
            button: 'action',
            buttonVisibility: 'always',
            buttonVisibleCallback(grid, index) {
                return grid.getValue(index.itemIndex, 'saleTypCd') === 'ST02'
            },
        },
        {
            name: 'amt',
            fieldName: 'amt',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '수량',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
            },
            numberFormat: '#,##0',
            editable: true,
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            header: {
                text: '일련번호',
                showTooltip: false,
            },
            button: 'action',
            buttonVisibility: 'always',
            buttonVisibleCallback(grid, index) {
                return grid.getValue(index.itemIndex, 'saleTypCd') !== 'ST02'
            },
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '120',
            styleName: 'left-column',
            header: {
                text: '색상',
                showTooltip: true,
            },
            editable: true,
            lookupDisplay: true,
            values: ['99'],
            labels: ['공통색상'],
            editor: {
                type: 'dropdown',
            },
            lookupSourceId: 'prodColorList',
            lookupKeyFields: ['prodCd', 'colorCd'],
            styleCallback(grid, dataCell) {
                let ret = {}
                let saleTypCd = grid.getValue(
                    dataCell.index.itemIndex,
                    'saleTypCd'
                )
                if (saleTypCd === 'ST02') {
                    ret.editor = {
                        type: 'dropdown',
                    }
                    ret.editable = true
                } else {
                    ret.editor = {
                        type: 'text',
                    }
                    ret.editable = false
                }
                return ret
            },
        },
        {
            name: 'prodDesc',
            fieldName: 'prodDesc',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            header: {
                text: '모델설명',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
            },
            numberFormat: '#,##0',
            editable: true,
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            width: '100',
            styleName: 'left-column',
            header: {
                text: '상품구분',
                showTooltip: true,
            },
            lookupDisplay: true,
            values: [],
            labels: [],
            // editor: {
            //     type: 'dropdown',
            // },
            editable: false,
            styleCallback(grid, dataCell) {
                let ret = {}
                let saleTypCd = grid.getValue(
                    dataCell.index.itemIndex,
                    'saleTypCd'
                )
                if (saleTypCd === 'ST02') {
                    ret.editor = {
                        type: 'dropdown',
                    }
                    // ret.editable = true
                } else {
                    ret.editor = {
                        type: 'text',
                    }
                    //ret.editable = false
                }
                return ret
            },
        },
        {
            name: 'saleUprc',
            fieldName: 'saleUprc',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            header: {
                text: '판매단가',
                showTooltip: false,
            },
            footer: {
                expression: 'sum',
            },
            numberFormat: '#,##0',
            editable: true,
        },
    ],
}
