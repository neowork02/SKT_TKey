'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: 'gnrlSaleNo',
        editable: false,
        header: { text: '판매번호' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'gnrlSaleChgSeq',
        editable: false,
        header: { text: '판매일련번호' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'prodNm',
        editable: false,
        header: { text: '모델' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'polNm',
        editable: false,
        header: { text: '정책명' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'basCmmsAmt',
        editable: false,
        header: { text: '기본단가정책수수료' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'svcCmmsAmt',
        editable: false,
        header: { text: '서비스정책수수료' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'vasCmmsAmt',
        editable: false,
        header: { text: 'VAS정책수수료' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'prcplnCmmsAmt',
        editable: false,
        header: { text: '요금제정책수수료' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
    {
        fieldName: 'upldCmmsAmt',
        editable: false,
        header: { text: '파일업로드정책수수료' },
        type: 'data',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,###',
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 300px`

const MOCK_DATA = {
    adpayMgmtVoList: [],
}

export { GRID_HEADER, MOCK_DATA }
