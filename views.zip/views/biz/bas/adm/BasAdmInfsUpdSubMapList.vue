<template>
    <div class="content">
        <h1>정산업로드판매점매핑</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearchClick"
                >
                    조회
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        v-model="searchParam.templetCd"
                        labelName="업로드"
                        codeId="CIP_TEMPLET_CD"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComDatePicker
                        v-model="calYearMonth"
                        calType="M"
                        labelName="정산년월"
                        :eRequired="true"
                    ></TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        labelName="매핑여부"
                        v-model="searchParam.mapGubun"
                        :itemList="mapYnList"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInput
                        v-model="searchParam.titleNm"
                        labelName="제목"
                        @enterKey="onSearchClick"
                    >
                    </TCComInput>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="updSubMapGridHeader"
                ref="updSubMapGridHeader"
                gridTitle="목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isExceldown="false"
            />
            <TCRealGrid
                id="updSubMapGrid"
                ref="updSubMapGrid"
                :fields="updSubMapHeader.fields"
                :columns="updSubMapHeader.columns"
                :editable="true"
                :updatable="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getUpdSubMapList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="onChgRowCnt"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import { UPD_SUB_MAP_HEADER } from '@/const/grid/bas/adm/basAdmInfsUpdSubMapHeader'
import basAdmInfsUpdSubMapApi from '@/api/biz/bas/adm/basAdmInfsUpdSubMapApi'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'BasAdmInfsUpdSubMapList',
    components: {},
    mixins: [CommonMixin],

    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            updSubMapHeader: UPD_SUB_MAP_HEADER,
            mapYnList: [
                { commCdVal: 'Y', commCdValNm: 'Y' },
                { commCdVal: 'N', commCdValNm: 'N' },
            ],
            rowCnt: 15,
            //각각 엘리먼트 컴포넌트 v-model
            searchParam: {
                templetCd: '',
                mapGubun: '',
                calYearMonth: '',
                titleNm: '',
                pageNum: 1,
                pageSize: 15,
            },
            calYearMonth: '',
            selectedJsonData: {},
            selectedRow: '',
        }
    },

    // watch: {
    //     calYearMonth(newValue) {
    //         this.searchParam.calYearMonth = newValue
    //     },
    // },

    created() {
        this.init()
    },

    mounted() {
        // console.log('menuInfo', this.menuInfo) //메뉴정보
        // console.log('orgInfo', this.orgInfo) //조직정보
        // console.log('userInfo', this.userInfo) //사용자정보
        // console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        this.gridObj = this.$refs.updSubMapGrid
        this.gridHeaderObj = this.$refs.updSubMapGridHeader
        this.gridObj.setGridState(true, false, false, false)
        this.setGridEvent()

        // 정산업로드판매점매핑 상세 화면에서 목록으로 라우터 후 검색조건 유지 후 조회
        if (!_.isEmpty(this.$route.params.parentSearchParam)) {
            this.getUpdSubMapList()
        }
    },

    methods: {
        init() {
            this.gridData = this.gridSetData()
            // 정산년월
            this.calYearMonth = CommonUtil.getCurrentMonth('YYYY-MM')
            // 정산업로드판매점매핑 상세 화면에서 목록으로 라우터 후 검색조건 유지
            if (!_.isEmpty(this.$route.params.parentSearchParam)) {
                this.searchParam = this.$route.params.parentSearchParam
                this.calYearMonth = CommonUtil.addDashDate(
                    this.$route.params.parentSearchParam.calYearMonth
                )
            }
        },

        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        setGridEvent() {
            this.gridObj.gridView.onCellClicked = (grid, clickData) => {
                console.log('onCellClicked: ', clickData)
                const column = clickData.column
                const dataRow = clickData.dataRow
                if (clickData.cellType === 'data') {
                    if (column === 'titleNm') {
                        const selectedGridRow = grid
                            .getDataSource()
                            .getJsonRow(dataRow)
                        this.$router.push({
                            name: '/bas/adm/BasAdmInfsUpdSubMapDtlList',
                            params: {
                                parentParam: selectedGridRow,
                                parentSearchParam: this.searchParam,
                            },
                        })
                    }
                }
            }
        },

        // 페이지 표시 행의 수 변경처리
        onChgRowCnt(val) {
            this.rowCnt = val
        },

        //조회 버튼 이벤트
        onSearchClick() {
            this.gridData.totalPage = 0
            this.getUpdSubMapList()
        },

        getUpdSubMapList(pageNum) {
            this.searchParam.calYearMonth = CommonUtil.replaceDash(
                this.calYearMonth
            )
            this.searchParam.pageNum = pageNum ?? 1
            this.searchParam.pageSize = this.rowCnt

            basAdmInfsUpdSubMapApi
                .getUpdSubMapList(this.searchParam)
                .then((result) => {
                    this.gridObj.dataProvider.setRows(result.gridList)
                    // 페이징 관련
                    // 순번(역순)이 필요한경우 계산하는 함수
                    this.gridObj.setGridIndicator(result.pagingDto)
                    // 초기화
                    this.gridData = this.gridSetData()
                    // 총페이지수
                    this.gridData.totalPage = result.pagingDto.totalPageCnt
                    // Grid Row 가져올때 페이지정보 Setting
                    this.gridHeaderObj.setPageCount(result.pagingDto)
                })
        },
    },
}
</script>
