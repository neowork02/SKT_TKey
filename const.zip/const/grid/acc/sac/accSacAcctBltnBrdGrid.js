// ----------------------------------------------------------------------
//  * 업무그룹명: 정산
//  * 서브업무명: 정산지원게시판 MAIN - GRID정의
//  * 소스 ID : AccSacAcctBltnBrdGrid.vue
//  * 설명: 정산완료 내역에 대해 각 판매점에서 정산담당에게 문의하는 기능
//  * 작성자: 고용진
//  * 작성일: 2022.04.05
//  * Copyright ⓒSN TECHNOLOGY. All Right Reserved
// ----------------------------------------------------------------------

import { ValueType } from 'realgrid'

export const GRID_HEADER = {
    fields: [
        {
            fieldName: 'boardNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inqTitle',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealCoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accDealCoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accProcStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accQueTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'accQueDtlNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'viewCnt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'makeDtmForm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'procNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'makeDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sortSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'boardNoBack',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'boardNo',
            fieldName: 'boardNo',
            type: 'data',
            // styleName: 'right-column',
            width: '70',
            header: { text: '순번' },
            styleCallback(grid, dataCell) {
                const ret = {}
                const sortSeq = grid.getValue(
                    dataCell.index.itemIndex,
                    'sortSeq'
                )
                if (sortSeq == '0') {
                    ret.styleName = 'skyblue-color2'
                } else {
                    ret.styleName = 'right-column'
                }

                return ret
            },
            displayCallback: function (grid, index) {
                let resTxt = ''
                const sortSeq = grid.getValue(index.itemIndex, 'sortSeq')
                if (sortSeq == '0') {
                    resTxt = '공지'
                } else {
                    resTxt = grid.getValue(index.itemIndex, 'boardNo')
                }

                return resTxt
            },
        },
        {
            name: 'inqTitle',
            fieldName: 'inqTitle',
            type: 'data',
            styleName: 'left-column multi-line-css',
            width: '300',
            header: { text: '제목' },
            styleCallback(grid, dataCell) {
                const ret = {}
                const sortSeq = grid.getValue(
                    dataCell.index.itemIndex,
                    'sortSeq'
                )
                if (sortSeq == '0') {
                    ret.styleName = 'left-column multi-line-css skyblue-color2'
                } else {
                    ret.styleName = 'left-column multi-line-css'
                }

                return ret
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            styleName: 'left-column',
            width: '200',
            header: { text: '영업PT' },
        },
        {
            name: 'accDealCoCd',
            fieldName: 'accDealCoCd',
            type: 'data',
            width: '70',
            header: { text: '정산처' },
        },
        {
            name: 'accDealCoNm',
            fieldName: 'accDealCoNm',
            type: 'data',
            styleName: 'left-column',
            width: '150',
            header: { text: '정산처명' },
        },
        {
            name: 'accProcStNm',
            fieldName: 'accProcStNm',
            type: 'data',
            styleName: 'left-column',
            width: '70',
            header: { text: '처리상태' },
        },
        {
            name: 'accQueTypNm',
            fieldName: 'accQueTypNm',
            type: 'data',
            styleName: 'left-column',
            width: '70',
            header: { text: '문의유형' },
        },
        {
            name: 'accQueDtlNm',
            fieldName: 'accQueDtlNm',
            type: 'data',
            styleName: 'left-column',
            width: '100',
            header: { text: '문의세부유형' },
        },

        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            width: '60',
            header: { text: 'P 코드' },
        },
        {
            name: 'viewCnt',
            fieldName: 'viewCnt',
            type: 'data',
            styleName: 'right-column',
            width: '50',
            header: { text: '조회수' },
        },
        {
            name: 'makeDtmForm',
            fieldName: 'makeDtmForm',
            type: 'data',
            width: '150',
            header: { text: '작성일시' },
        },
        {
            name: 'procNm',
            fieldName: 'procNm',
            type: 'data',
            width: '150',
            styleName: 'left-column',
            header: { text: '처리자' },
        },
        {
            fieldName: 'sortSeq',
            visible: false,
        },
        {
            fieldName: 'boardNoBack',
            visible: false,
        },
    ],
}
