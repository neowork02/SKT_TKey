<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 재고이동현황[DISDSM00400]
 * 설명: 재고이동현황을 조회한다.
 * 작성자: P179229
 * 작성일: 2022.06.10
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>재고이동현황</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="clearBtn"
                    :objAuth="this.objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="searchBtn"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
            </li>
        </ul>
        <!-- // Top BTN -->
        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="조회기간"
                        calType="DP"
                        v-model="setDate"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        :itemList="this.chrgrUserIdData"
                        labelName="영업담당"
                        v-model="reqParam.chrgrUserId"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.outOrgNm"
                        :codeVal.sync="reqParam.outOrgCd"
                        labelName="출고조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        @enterKey="onOutAuthOrgTreeEnterKey"
                        @appendIconClick="onOutAuthOrgTreeIconClick"
                        @input="onOutAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showOutBcoAuthOrgTrees"
                        :parentParam="searchOutAuthOrgTreesForm"
                        :rows="resultOutAuthOrgTreeRows"
                        :dialogShow.sync="showOutBcoAuthOrgTrees"
                        @confirm="onOutAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.outDealcoNm"
                        :codeVal.sync="reqParam.outDealcoCd"
                        labelName="출고처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onOutDealcoEnterKey"
                        @appendIconClick="onOutDealcoIconClick"
                        @input="onOutDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showOutBasBcoDealcos"
                        :parentParam="searchOutDealcosForm"
                        :rows="resultOutDealcoRows"
                        :dialogShow.sync="showOutBasBcoDealcos"
                        @confirm="onOutDealcoReturnData"
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00010"
                        labelName="상품구분"
                        v-model="reqParam.prodClCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComComboBox
                        codeId="ZBAS_C_00440"
                        labelName="통신방식"
                        v-model="reqParam.comMthdCd"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.inOrgNm"
                        :codeVal.sync="reqParam.inOrgCd"
                        labelName="입고조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="orgDisabled"
                        @enterKey="onInAuthOrgTreeEnterKey"
                        @appendIconClick="onInAuthOrgTreeIconClick"
                        @input="onInAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showInBcoAuthOrgTrees"
                        :parentParam="searchInAuthOrgTreesForm"
                        :rows="resultInAuthOrgTreeRows"
                        :dialogShow.sync="showInBcoAuthOrgTrees"
                        @confirm="onInAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="reqParam.inDealcoNm"
                        :codeVal.sync="reqParam.inDealcoCd"
                        labelName="입고처"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :disabled="dealcoDisabled"
                        @enterKey="onInDealcoEnterKey"
                        @appendIconClick="onInDealcoIconClick"
                        @input="onInDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showInBasBcoDealcos"
                        :parentParam="searchInDealcosForm"
                        :rows="resultInDealcoRows"
                        :dialogShow.sync="showInBasBcoDealcos"
                        @confirm="onInDealcoReturnData"
                    />
                </div>
            </div>
            <div class="searchform"></div>
        </div>
        <!-- // Search_div -->
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="재고이동현황 내역"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                @excelDownBtn="onClickDownload"
            >
                <template #gridBtnArea>
                    <TCComButton
                        :Vuetify="false"
                        eClass="btn_noline btn_ty04"
                        eAttr="ico_exeldown"
                        labelName="상세다운로드"
                        :objAuth="objAuth"
                        @click="onClickDownloadDtl"
                    />
                </template>
            </TCRealGridHeader>
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDisDtrDisMovPrsts"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
        <!-- //gridWrap -->
        <!-- popup -->
        <DisDtrDisMovPrstDtlPopup
            v-if="showDisDtrDisMovPrstDtl === true"
            ref="popup"
            :dialogShow.sync="showDisDtrDisMovPrstDtl"
            :dtlData.sync="dtlParam"
        />
        <!-- // popup -->
    </div>
</template>

<script>
import { CommonGrid, CommonUtil } from '@/utils'
import { DisDtrDisMovPrstGRID_HEADER } from '@/const/grid/dis/dtr/disDtrDisMovPrstHeader'
import disDtrDisMovPrstApi from '@/api/biz/dis/dtr/disDtrMovPrst'
import attachedFileApi from '@/api/common/attachedFile'
import DisDtrDisMovPrstDtlPopup from './DisDtrDisMovPrstDtlPopup'
//====================내부조직팝업(권한)팝업====================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================//내부조직팝업(권한)팝업====================
//====================내부거래처-전체조직====================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================//내부거래처-전체조직==================
import moment from 'moment'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'DisDtrDisMovPrst',
    mixins: [CommonMixin],
    components: {
        DisDtrDisMovPrstDtlPopup,
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
    },
    props: {},
    data() {
        return {
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},
            indicatorOpt: { sort: 'ASC' },
            objAuth: {},
            active: false,
            view: DisDtrDisMovPrstGRID_HEADER,
            showDisDtrDisMovPrstDtl: false,
            orgDisabled: false,
            dealcoDisabled: false,
            //====================출고 내부조직팝업(권한)팝업관련====================
            showOutBcoAuthOrgTrees: false, // 출고 내부조직팝업(권한) 팝업 오픈 여부
            searchOutAuthOrgTreesForm: {
                orgCd: '', //출고조직id
                orgNm: '', //출고조직명
                all: 'Y',
            },
            resultOutAuthOrgTreeRows: [], // 출고 내부조직팝업(권한) 팝업 오픈 여부
            //====================//출고 내부조직팝업(권한)팝업관련==================
            //====================입고 내부조직팝업(권한)팝업관련====================
            showInBcoAuthOrgTrees: false, // 입고 내부조직팝업(권한) 팝업 오픈 여부
            searchInAuthOrgTreesForm: {
                orgCd: '', //입고조직id
                orgNm: '', //입고조직명
                all: 'Y',
            },
            resultInAuthOrgTreeRows: [], // 입고 내부조직팝업(권한) 팝업 오픈 여부
            //====================//입고 내부조직팝업(권한)팝업관련==================
            //====================출고처 내부거래처-전체조직====================
            showOutBasBcoDealcos: false,
            searchOutDealcosForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
            },
            resultOutDealcoRows: [],
            //====================//출고처 내부거래처-전체조직==================
            //====================입고처 내부거래처-전체조직====================
            showInBasBcoDealcos: false,
            searchInDealcosForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
                dealcoGrpCd: 'ZZ,AY,YY', // 거래처그룹
                dealcoClCd1:
                    'A6,B1,AE,AD,A7,AF,A2,B2,M1,A3,D1,C1,E1,A5,Z1,Z2,AC', // 거래처구분
            },
            resultInDealcoRows: [],
            //====================//입고처 내부거래처-전체조직==================
            chrgrUserIdData: [],
            reqParam: {
                fromDt: '', //from일자
                toDt: '', //to일자
                outOrgCd: '', //출고조직id
                outOrgNm: '', //출고조직명
                outOrgLvl: '', //출고조직level
                outOrgCdLvl0: '', //출고레벨0조직코드
                outDealcoCd: '', // 출고처
                outDealcoNm: '', // 출고처명
                inOrgCd: '', //입고조직id
                inOrgNm: '', //입고조직명
                inOrgLvl: '', //입고조직level
                inOrgCdLvl0: '', //입고레벨0조직코드
                inDealcoCd: '', // 입고처
                inDealcoNm: '', // 입고처명
                chrgrUserId: '', //영업담당
                prodClCd: '', //상품구분
                comMthdCd: '', //통신방식
                eqpClCd: '', //단말기구분
            },
            serchParam: {},
            dtlParam: {},
            rowCnt: 15,
        }
    },
    computed: {
        setDate: {
            get() {
                return [this.reqParam.fromDt, this.reqParam.toDt]
            },
            set(val) {
                this.reqParam.fromDt = val[0]
                this.reqParam.toDt = val[1]
                this.searchOutDealcosForm.basDay = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMMDD'
                )
                this.searchInDealcosForm.basDay = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMMDD'
                )
                this.searchOutAuthOrgTreesForm.basMth = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMM'
                )
                this.searchInAuthOrgTreesForm.basMth = CommonUtil.getDayFormat(
                    val[1],
                    'YYYYMM'
                )
                return val
            },
        },
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        // Grid Component Obj / Grid Header Component Obj
        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader1
        this.gridObj.setGridState(true, false, false, true)
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        this.gridObj.gridView.onCellDblClicked = this.onCellDblClicked
        this.init()
    },
    methods: {
        init() {
            //검색영역
            this.reqParam.fromDt = moment(new Date()).format('YYYY-MM-01') // 입고일 from
            this.reqParam.toDt = moment(new Date()).format('YYYY-MM-DD') // 입고일 to
            //세션처리
            if (!_.isEmpty(this.userInfo['dealcoCd'])) {
                this.reqParam['outOrgCd'] = this.orgInfo['orgCd']
                this.reqParam['outOrgNm'] = this.orgInfo['orgNm']
                this.reqParam['outOrgLvl'] = this.orgInfo['orgLvl']
                this.reqParam['outOrgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.reqParam['outDealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['outDealcoNm'] = this.userInfo['dealcoNm']
                this.reqParam['inOrgCd'] = this.orgInfo['orgCd']
                this.reqParam['inOrgNm'] = this.orgInfo['orgNm']
                this.reqParam['inOrgLvl'] = this.orgInfo['orgLvl']
                this.reqParam['inOrgCdLvl0'] = this.orgInfo['orgCdLvl0']
                this.reqParam['inDealcoCd'] = this.userInfo['dealcoCd']
                this.reqParam['inDealcoNm'] = this.userInfo['dealcoNm']
                this.dealcoDisabled = true
                this.orgDisabled = true
            }
            this.getChrgrUserIdList() //영업담당 조회
        },
        //초기화 버튼 이벤트
        clearBtn: function () {
            CommonUtil.clearPage(this, 'reqParam')
            this.init()
        },
        //Grid Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, this.rowCnt, '', '')
        },
        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dtr/disDtrDisMovPrstExcelList',
                this.searchForm
            )
        },
        //상세엑셀다운로드
        onClickDownloadDtl() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dtr/disDtrDisMovPrstDtlExcelList',
                this.searchForm
            )
        },
        //리스트 조회
        searchBtn: function () {
            if (!this.isValidChk()) {
                return false
            }
            this.searchForm = { ...this.reqParam }
            this.searchForm.fromDt = CommonUtil.replaceDash(
                this.searchForm.fromDt
            )
            this.searchForm.toDt = CommonUtil.replaceDash(this.searchForm.toDt)
            //첫 조회시 표시할 행의 갯수
            this.searchForm.pageSize = this.rowCnt
            this.searchForm.pageNum = 1 //첫번째 페이지
            this.gridData.totalPage = 0 // 이전페이지정보 초기화
            this.getDisDtrDisMovPrsts(this.searchForm.pageNum)
        },
        getDisDtrDisMovPrsts(page) {
            this.searchForm.pageNum = page
            disDtrDisMovPrstApi
                .getDisDtrDisMovPrst(this.searchForm)
                .then((res) => {
                    this.gridObj.setRows(res.gridList)
                    this.gridObj.setGridIndicator(
                        res.pagingDto,
                        this.indicatorOpt
                    ) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = res.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(res.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                })
        },
        isValidChk() {
            let validFromDt = CommonUtil.replaceDash(this.reqParam.fromDt)
            let validToDt = CommonUtil.replaceDash(this.reqParam.toDt)
            if (_.isEmpty(validFromDt)) {
                this.showTcComAlert('조회일자의 시작일(을)를 입력해 주십시오.')
                return false
            }
            if (_.isEmpty(validToDt)) {
                this.showTcComAlert('조회일자의 종료일(을)를 입력해 주십시오.')
                return false
            }
            if (validFromDt.substr(0, 6) !== validToDt.substr(0, 6)) {
                this.showTcComAlert(
                    '조회 시작일자와 종료일자를 동일한 월로 지정하세요.'
                )
                return false
            }
            if (validFromDt > validToDt) {
                this.showTcComAlert('조회일자의 시작일이 종료일보다 큽니다.')
                return false
            }
            if (
                _.isEmpty(this.reqParam.outOrgCd) &&
                _.isEmpty(this.reqParam.inOrgCd)
            ) {
                this.showTcComAlert('조직을 입력해 주십시오.')
                return false
            }
            return true
        },
        //영업담당조회
        getChrgrUserIdList: function () {
            disDtrDisMovPrstApi.getChrgrUserId().then((res) => {
                res.disDtrChrgrUserIdVo.forEach((data) => {
                    const chrgrUserId = {}
                    chrgrUserId.commCdVal = _.get(data, 'chrgrUserId')
                    chrgrUserId.commCdValNm = _.get(data, 'chrgrUserNm')
                    this.chrgrUserIdData.push(chrgrUserId)
                })
            })
        },
        onCellDblClicked(grid, clickData) {
            if (clickData?.dataRow >= 0) {
                const cellData = this.gridObj.dataProvider.getJsonRow(
                    clickData.dataRow
                )
                this.dtlParam = Object.assign({}, this.reqParam)
                this.dtlParam.outSchdDt = moment(
                    _.get(cellData, 'outSchdDt')
                ).format('YYYYMMDD')
                this.dtlParam.outDealcoCd = _.get(cellData, 'outDealcoCd')
                this.dtlParam.inDealcoCd = _.get(cellData, 'inDealcoCd')
                this.showDisDtrDisMovPrstDtl = true
            }
        },
        //===================== 출고 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getOutAuthOrgTreeList() {
            this.searchOutAuthOrgTreesForm.orgCd = this.reqParam.outOrgCd
            this.searchOutAuthOrgTreesForm.orgNm = this.reqParam.outOrgNm
            this.searchOutAuthOrgTreesForm.orgLvl = this.reqParam.outOrgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchOutAuthOrgTreesForm)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.outOrgCd = _.get(res[0], 'orgCd')
                        this.reqParam.outOrgNm = _.get(res[0], 'orgNm')
                        this.reqParam.orgLvl = _.get(res[0], 'orgLvl')
                        this.reqParam.orgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultOutAuthOrgTreeRows = res
                        this.showOutBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onOutAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.outOrgNm)) {
                this.getOutAuthOrgTreeList()
            } else {
                this.showOutBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onOutAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultOutAuthOrgTreeRows = []
            // 내부조직팝업(권한) 정보 조회
            this.getOutAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onOutAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.outOrgCd = ''
            this.reqParam.outOrgLvl = ''
            this.reqParam.outOrgCdLvl0 = ''
            this.reqParam.outDealcoCd = ''
            this.reqParam.outDealcoNm = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onOutAuthOrgTreeReturnData(retrunData) {
            this.reqParam.outOrgCd = _.get(retrunData, 'orgCd')
            this.reqParam.outOrgNm = _.get(retrunData, 'orgNm')
            this.reqParam.outOrgLvl = _.get(retrunData, 'orgLvl')
            this.reqParam.outOrgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
            this.reqParam.outDealcoCd = ''
            this.reqParam.outDealcoNm = ''
        },
        //===================== //출고 내부조직팝업(권한)팝업관련 methods ================================
        //===================== 입고 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getInAuthOrgTreeList() {
            this.searchInAuthOrgTreesForm.orgCd = this.reqParam.inOrgCd
            this.searchInAuthOrgTreesForm.orgNm = this.reqParam.inOrgNm
            this.searchInAuthOrgTreesForm.orgLvl = this.reqParam.inOrgLvl
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchInAuthOrgTreesForm)
                .then((res) => {
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.inOrgCd = _.get(res[0], 'orgCd')
                        this.reqParam.inOrgNm = _.get(res[0], 'orgNm')
                        this.reqParam.inOrgLvl = _.get(res[0], 'orgLvl')
                        this.reqParam.inOrgCdLvl0 = _.get(res[0], 'orgCdLvl0')
                    } else {
                        this.resultInAuthOrgTreeRows = res
                        this.showInBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onInAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultInAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.reqParam.inOrgNm)) {
                this.getInAuthOrgTreeList()
            } else {
                this.showInBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onInAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultInAuthOrgTreeRows = []
            // 내부조직팝업(권한) 정보 조회
            this.getInAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onInAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.reqParam.inOrgCd = ''
            this.reqParam.inOrgLvl = ''
            this.reqParam.inOrgCdLvl0 = ''
            this.reqParam.inDealcoCd = ''
            this.reqParam.inDealcoNm = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onInAuthOrgTreeReturnData(retrunData) {
            this.reqParam.inOrgCd = _.get(retrunData, 'orgCd')
            this.reqParam.inOrgNm = _.get(retrunData, 'orgNm')
            this.reqParam.inOrgLvl = _.get(retrunData, 'orgLvl')
            this.reqParam.inOrgCdLvl0 = _.get(retrunData, 'orgCdLvl0')
            this.reqParam.inDealcoCd = ''
            this.reqParam.inDealcoNm = ''
        },
        //===================== //입고 내부조직팝업(권한)팝업관련 methods ================================
        //===================== 출고 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getOutDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchOutDealcosForm)
                .then((res) => {
                    // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.outDealcoCd = _.get(res[0], 'dealcoCd')
                        this.reqParam.outDealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultOutDealcoRows = res
                        this.showOutBasBcoDealcos = true
                    }
                })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onOutDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (_.isEmpty(this.reqParam.outOrgCd)) {
                this.showTcComAlert('출고조직을 선택하세요')
                return
            }
            this.searchOutDealcosForm.orgCd = this.reqParam.outOrgCd
            this.searchOutDealcosForm.orgNm = this.reqParam.outOrgNm
            this.searchOutDealcosForm.orgLvl = this.reqParam.outOrgLvl
            this.searchOutDealcosForm.dealcoCd = this.reqParam.outDealcoCd
            this.searchOutDealcosForm.dealcoNm = this.reqParam.outDealcoNm
            // 팝업오픈
            this.showOutBasBcoDealcos = true
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onOutDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultOutDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.outOrgCd)) {
                this.showTcComAlert('출고조직을 선택하세요')
                return
            }
            this.searchOutDealcosForm.orgCd = this.reqParam.outOrgCd
            this.searchOutDealcosForm.orgNm = this.reqParam.outOrgNm
            this.searchOutDealcosForm.orgLvl = this.reqParam.outOrgLvl
            this.searchOutDealcosForm.dealcoCd = this.reqParam.outDealcoCd
            this.searchOutDealcosForm.dealcoNm = this.reqParam.outDealcoNm
            if (_.isEmpty(this.reqParam.outDealcoNm)) {
                // 팝업오픈
                this.showOutBasBcoDealcos = true
            } else {
                // 내부거래처-전체조직 정보 조회
                this.getOutDealcosList()
            }
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onOutDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.reqParam.outDealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onOutDealcoReturnData(retrunData) {
            this.reqParam.outDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.outDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //출고 내부거래처-전체조직팝업관련 methods ================================
        //===================== 입고 내부거래처-전체조직팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getInDealcosList() {
            basBcoDealcosApi
                .getDealcosList(this.searchInDealcosForm)
                .then((res) => {
                    // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                    if (res.length === 1) {
                        this.reqParam.inDealcoCd = _.get(res[0], 'dealcoCd')
                        this.reqParam.inDealcoNm = _.get(res[0], 'dealcoNm')
                    } else {
                        this.resultInDealcoRows = res
                        this.showInBasBcoDealcos = true
                    }
                })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onInDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultInDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (_.isEmpty(this.reqParam.inOrgCd)) {
                this.showTcComAlert('입고조직을 선택하세요')
                return
            }
            this.searchInDealcosForm.orgCd = this.reqParam.inOrgCd
            this.searchInDealcosForm.orgNm = this.reqParam.inOrgNm
            this.searchInDealcosForm.orgLvl = this.reqParam.inOrgLvl
            this.searchInDealcosForm.dealcoCd = this.reqParam.inDealcoCd
            this.searchInDealcosForm.dealcoNm = this.reqParam.inDealcoNm
            // 팝업오픈
            this.showInBasBcoDealcos = true
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onInDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultInDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.reqParam.inOrgCd)) {
                this.showTcComAlert('입고조직을 선택하세요')
                return
            }
            this.searchInDealcosForm.orgCd = this.reqParam.inOrgCd
            this.searchInDealcosForm.orgNm = this.reqParam.inOrgNm
            this.searchInDealcosForm.orgLvl = this.reqParam.inOrgLvl
            this.searchInDealcosForm.dealcoCd = this.reqParam.inDealcoCd
            this.searchInDealcosForm.dealcoNm = this.reqParam.inDealcoNm
            if (_.isEmpty(this.reqParam.inDealcoNm)) {
                // 팝업오픈
                this.showInBasBcoDealcos = true
            } else {
                // 내부거래처-전체조직 정보 조회
                this.getInDealcosList()
            }
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onInDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.reqParam.inDealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onInDealcoReturnData(retrunData) {
            this.reqParam.inDealcoCd = _.get(retrunData, 'dealcoCd')
            this.reqParam.inDealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //입고 내부거래처-전체조직팝업관련 methods ================================
    },
}
</script>
