import { ValueType } from 'realgrid'

export class expartDisPrst_ReqParam {
    // 요청파라미터
    fromDt = '' // 시작 조회일자
    toDt = '' // 종료 조회일자
    orgId = '' // 조직코드
    orgLevel = '' // 조직레벨
    outPlcId = '' // 보유처(출고처)
    mfactId = '' // 제조사
    prodCd = '' // 모델코드
    serNum = '' // 일련번호
    prodCl = '' // 상품구분
    outYn = '' // 출고여부
    badYn = '' // 불량구분
    disSt = '' // 재고상태
    supOrg = ''
}

export const DisDsmExpartDisPrst_GRID_HEADER = {
    fields: [
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT, //조직
        },
        {
            fieldName: 'dealCoClNm1',
            dataType: ValueType.TEXT, //보유처구분
        },
        {
            fieldName: 'outPlcId',
            dataType: ValueType.TEXT, //보유처코드
        },
        {
            fieldName: 'outPlcIdNm',
            dataType: ValueType.TEXT, //보유처
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, //매장코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'mdlClCd',
            dataType: ValueType.TEXT, //단말기구분
        },
        {
            fieldName: 'badYnNm',
            dataType: ValueType.TEXT, //불량여부
        },
        {
            fieldName: 'disStNm',
            dataType: ValueType.TEXT, //재고상태
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //모델
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT, //일련번호
        },
        {
            fieldName: 'temp1',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //Swing등록일
        },
        {
            fieldName: 'temp2',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //Telp 등록일
        },
        {
            fieldName: 'temp3',
            dataType: ValueType.TEXT, //교품준비여부
        },
        {
            fieldName: 'temp4',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd', //교품출고 예정일
        },
        {
            fieldName: 'temp5',
            dataType: ValueType.TEXT, //출고여부
        },
        {
            fieldName: 'temp6',
            dataType: ValueType.TEXT, //입고 일련번호
        },
        {
            fieldName: 'lastInoutDtlClNm',
            dataType: ValueType.TEXT, //최종이력
        },
        {
            fieldName: 'outUserNm',
            dataType: ValueType.TEXT, //출고처리자
        },
        {
            fieldName: 'hldPlcIdNm',
            dataType: ValueType.TEXT, //현재보유처
        },
        {
            fieldName: 'hldPlcId',
            dataType: ValueType.TEXT, //현재보유처코드
        },
        {
            fieldName: 'curSktCd',
            dataType: ValueType.TEXT, //현재매장코드
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '350',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '조직',
                showTooltip: false,
            },
        },
        {
            name: 'dealCoClNm1',
            fieldName: 'dealCoClNm1',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처구분',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcId',
            fieldName: 'outPlcId',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'outPlcIdNm',
            fieldName: 'outPlcIdNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처',
                showTooltip: false,
            },
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '매장코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'mdlClCd',
            fieldName: 'mdlClCd',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분',
                showTooltip: false,
            },
        },
        {
            name: 'badYnNm',
            fieldName: 'badYnNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '불량여부',
                showTooltip: false,
            },
        },
        {
            name: 'disStNm',
            fieldName: 'disStNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '재고상태',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'temp1',
            fieldName: 'temp1',
            header: {
                text: 'Swing 등록일',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'temp2',
            fieldName: 'temp2',
            header: {
                text: 'Telp 등록일',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'temp3',
            fieldName: 'temp3',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '교품준비여부',
                showTooltip: false,
            },
        },
        {
            name: 'temp4',
            fieldName: 'temp4',
            header: {
                text: '교품출고 예정일',
            },
            width: '120',
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
            },
        },
        {
            name: 'temp5',
            fieldName: 'temp5',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고여부',
                showTooltip: false,
            },
        },
        {
            name: 'temp6',
            fieldName: 'temp6',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '입고 일련번호',
                showTooltip: false,
            },
        },
        {
            name: 'lastInoutDtlClNm',
            fieldName: 'lastInoutDtlClNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '최종이력',
                showTooltip: false,
            },
        },
        {
            name: 'outUserNm',
            fieldName: 'outUserNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '출고처리자',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcIdNm',
            fieldName: 'hldPlcIdNm',
            type: 'data',
            width: '100',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현재보유처',
                showTooltip: false,
            },
        },
        {
            name: 'hldPlcId',
            fieldName: 'hldPlcId',
            type: 'data',
            width: '120',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현재보유처코드',
                showTooltip: false,
            },
        },
        {
            name: 'curSktCd',
            fieldName: 'curSktCd',
            type: 'data',
            width: '110',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현재매장코드',
                showTooltip: false,
            },
        },
    ],
}
