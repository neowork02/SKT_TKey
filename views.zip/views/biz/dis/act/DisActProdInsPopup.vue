<!-----------------------------------------------
 * 업무그룹명: 재고실사관리
 * 서브업무명: 상품입력(재고실사)
 * 설명: 재고 상품을 입력한다
 * 작성자: P179890
 * 작성일: 2022.07.18
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1300px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">상품입력(재고실사)</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <ul class="btn_area top pop">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="addBarCodePop"
                                >2차원바코드입력</TCComButton
                            >
                        </li>
                    </ul>
                    <div class="gridWrap">
                        <!-- SubTit -->
                        <TCRealGridHeader
                            id="popupGridHeader"
                            ref="popupGridHeader"
                            gridTitle="상품내역"
                            :gridObj="gridObj"
                            :isAddRow="true"
                            :isDelRow="true"
                            @addRowBtn="gridAddRowBtn"
                            @chkDelRowBtn="gridchkDelRowBtn"
                        />
                        <!-- // SubTit -->
                        <!-- gridWrap -->
                        <div class="gridWrap">
                            <TCRealGrid
                                id="popupGrid"
                                ref="popupGrid"
                                :fields="view.fields"
                                :columns="view.columns"
                                :editable="true"
                                :styles="gridStyle"
                            />
                        </div>
                        <!-- //gridWrap -->
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="confirmBtn"
                        >
                            확인
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02"
                            :objAuth="objAuth"
                            @click="closeBtn"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <!--//Bottom BTN Group-->
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
                <!-- 2차원바코드입력POPUP -->
                <DisDcoProdInsBarCdPopup
                    v-if="showProdInsBarCdPop === true"
                    :dialogShow.sync="showProdInsBarCdPop"
                    :parentParam.sync="srchBarCodePopParam"
                    @confirm="barCodePopReturnData"
                />
                <!-- //2차원바코드입력POPUP -->
                <!-- 상품리스트팝업 -->
                <DisActProdListPopup
                    v-if="showDisProdListPop === true"
                    :dialogShow.sync="showDisProdListPop"
                    :disProdList.sync="popProdList"
                    @returnVal="disProdData"
                />
                <!-- //상품리스트팝업 -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid, CommonUtil, CommonMsg } from '@/utils'
import commonApi from '@/api/common/prototype'
import actApi from '@/api/biz/dis/act/disActProdIns.js'
import { DisActProdInsPopupGRID_HEADER } from '@/const/grid/dis/act/disActProdInsPopupHeader'
import DisDcoProdInsBarCdPopup from '@/views/biz/dis/dco/DisDcoProdInsBarCdPopup'
import DisActProdListPopup from '@/views/biz/dis/act/DisActProdListPopup'
import disDcoProdInsInApi from '@/api/biz/dis/dco/disDcoProdInsIn'
import _ from 'lodash'
import CommonMixin from '@/mixins'

export default {
    name: 'DisDcoProdInsOut',
    mixins: [CommonMixin],
    components: { DisDcoProdInsBarCdPopup, DisActProdListPopup },
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        params: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            //Paging Class init
            showProdInsBarCdPop: false,
            gridData: {},
            objAuth: {},
            view: DisActProdInsPopupGRID_HEADER,
            srchBarCodePopParam: {},
            gridObj: {},
            gridHeaderObj: {},
            alertHeadTxt: '상품입력(재고실사)',
            addData: {},
            sRow: -1,
            tRow: -1,
            showDisProdListPop: false,
            prodColorList: [],
            barCdTypCd: [],
            popProdList: [],
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
            sSearchCl: 'bar',
        }
    },
    created() {
        this.gridData = this.gridSetData()
    },
    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.popupGridHeader
        this.gridObj.setGridState(false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.onCurrentRowChanged = this.onCurrentRowChanged
        this.gridObj.gridView.onKeyUp = (grid, event) => {
            grid.editOptions.commitByCell = true
            if (event.keyCode == 13) {
                this.gridAddRowBtn()
            }
        }
        this.gridObj.gridView.onCellClicked = () => {
            this.gridObj.gridView.showEditor()
        }
        this.getDisDcoBarCdTypCd()
        this.getCommCodeList('ZBAS_C_00040', 'colorCd')
        this.getCommCodeList('ZDIS_C_00090', 'badYn')
        this.getCommCodeList('ZDIS_C_00100', 'disSt')
        setTimeout(() => {
            this.addRow()
        }, 1000)
    },
    watch: {},
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        init() {},
        //GridSetData
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, 10000, '', '')
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
            const current = this.gridObj.gridView.getCurrent()
            if (current.dataRow > -1) {
                const rowData = this.gridObj.dataProvider.getJsonRow(
                    current.dataRow
                )
                if (_.isEmpty(rowData['prodCd'])) {
                    this.gridObj.gridView.setColumnProperty(
                        'serNum',
                        'editable',
                        true
                    )
                } else {
                    this.gridObj.gridView.setColumnProperty(
                        'serNum',
                        'editable',
                        false
                    )
                }
            }
        },
        onCurrentRowChanged(grid, oldRow, newRow) {
            if (newRow > -1) {
                const rowData = grid._dataProvider.getRow(newRow)
                // 상품코드로 완료데이터인지 검증
                if (_.isEmpty(rowData[2])) {
                    grid.setColumnProperty('serNum', 'editable', true)
                } else {
                    grid.setColumnProperty('serNum', 'editable', false)
                }
            }
        },
        //바코드타입조회
        getDisDcoBarCdTypCd: function () {
            disDcoProdInsInApi.getDisDcoBarCdTypCd().then((res) => {
                res.disDcoBarCdTypeCdVo.forEach((data) => {
                    this.barCdTypCd.push(_.get(data, 'barCdType'))
                })
            })
        },
        // Add Row Event
        async gridAddRowBtn() {
            let requiredCol = ['serNum', 'prodCd']
            this.gridObj.gridView.commit()

            let valiGrid = this.gridObj.validationGrid(
                this.gridData,
                requiredCol
            )

            if (valiGrid.error == 'require') {
                const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
                const validRow = await this.getValidRow(rowData)

                if (validRow < 0) {
                    this.openAlert(
                        CommonMsg.getMessage('MSG_00083', '일련번호')
                    )
                    return
                }
                // 그리드 포커스 일련번호 유지
                this.gridObj.gridView.setCurrent({
                    itemIndex: this.sRow,
                    fieldName: 'serNum',
                })
                let sSerNum = rowData[this.sRow].serNum.replace('%', '')
                rowData[this.sRow].serNum = sSerNum
                /*
                 * 상품코드가 IPad 인경우 자릿수가 12 자리
                 */
                if (rowData[this.sRow].serNum.length < 12) {
                    this.getSerNumProdList(rowData[this.sRow])
                } else {
                    this.getProdListByBarCode(rowData[this.sRow].serNum)
                }
            } else {
                this.addRow()
            }
        },
        // 행추가
        addRow() {
            this.gridData.gridRows = this.gridHeaderObj.addRow(
                this.gridData.gridRows
            )
            this.gridObj.gridView.setCurrent({
                itemIndex: this.gridData.gridRows - 1,
                fieldName: 'serNum',
            })
            //focus간 셀 편집
            setTimeout(() => {
                this.gridObj.gridView.showEditor()
            }, 100)
        },
        // 그리드행 유효성 체크
        getValidRow(rowData) {
            return new Promise((resolve) => {
                rowData.forEach((data, i) => {
                    if (_.isEmpty(data.serNum)) {
                        resolve(-1)
                        this.sRow = i
                    } else if (_.isEmpty(data.prodCd)) {
                        resolve(i)
                        this.sRow = i
                    }
                })
            })
        },
        // 일련번호 컬럼 초기화
        setEmptySerNum() {
            this.gridObj.gridView.setColumnProperty('serNum', 'editable', true)
            this.gridObj.dataProvider.setValue(this.sRow, 'serNum', '')
            this.gridObj.gridView.setCurrent({
                itemIndex: this.sRow,
                fieldName: 'serNum',
            })
            //focus간 셀 편집
            setTimeout(() => {
                this.gridObj.gridView.showEditor()
            }, 100)
        },
        // 물품검증
        vrfProdList(prodList) {
            //04526996
            if (prodList.length === 0) {
                const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
                if (
                    rowData[this.sRow].serNum.length == 12 &&
                    this.sSearchCl == 'bar'
                ) {
                    this.getSerNumProdList(rowData[this.sRow])
                    return
                }
                this.openAlert(
                    CommonMsg.getMessage('MSG_00138', '비정상적인 바코드 정보')
                )
                this.setEmptySerNum()
                return
            }

            if (prodList.length === 1) {
                // 시리얼 길이가 12 이면서 바코드유형 : Apple 12(5) 이 아닐 경우
                // if (
                //     prodList[0].serNum.length == 12 &&
                //     prodList[0].serNum.barCdTyp != '5'
                // ) {
                //     this.getProdListByBarCode(prodList[0].serNum)
                //     return
                // } else {
                if (this.checkSerNum(prodList[0])) {
                    this.gridObj.gridView.setValues(this.sRow, prodList[0])
                    this.gridObj.gridView.setColumnProperty(
                        'serNum',
                        'editable',
                        false
                    )
                    this.addRow()
                }
                //}
            } else if (prodList.length > 1) {
                if (
                    prodList[0].serNum.length == 12 &&
                    prodList[0].serNum.barCdTyp != '5'
                ) {
                    this.getProdListByBarCode(prodList[0].serNum)
                    return
                } else {
                    this.popProdList = prodList
                    this.showDisProdListPop = true
                    return
                }
            }
        },
        // 일련번호+상품코드 중복체크
        checkSerNum(prodData, flag) {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            for (var i = 0; i < rowCount; i++) {
                let rowData = this.gridObj.dataProvider.getJsonRow(i)
                if (
                    prodData.serNum + prodData.prodCd + prodData.colorCd ==
                    rowData.serNum + rowData.prodCd + rowData.colorCd
                ) {
                    if (flag != 'barcode') {
                        this.openAlert(
                            CommonMsg.getMessage(
                                'MSG_00152',
                                (i + 1).toString()
                            )
                        )
                        this.setEmptySerNum()
                    }
                    return false
                }
            }
            return true
        },
        // 상품 정보 조회
        getSerNumProdList(form) {
            this.sSearchCl = 'prod'
            const sform = {
                serNum: form.serNum.toUpperCase(),
                hldPlcId: this.params.hldPlcId,
                aplyDt: CommonUtil.onlyNumber(this.params.aplyDt),
            }
            actApi.getSerNumProdList(sform).then((res) => {
                // 검색 물품 검증
                this.vrfProdList(res.gridList)
            })
        },
        // 상품 정보 조회(바코드로 전체케이스로 조회)
        getProdListByBarCode(serNum) {
            this.sSearchCl = 'bar'
            const form = {
                serNum: serNum.toUpperCase(),
                hldPlcId: this.params.hldPlcId,
            }
            actApi.getProdListByBarCode(form).then((res) => {
                // 검색 물품 검증
                this.vrfProdList(res.gridList)
            })
        },
        // 공통코드조회
        getCommCodeList(codeId, columnId) {
            commonApi.getCommonCodeList(codeId).then((res) => {
                let columnValues = []
                let columnLabels = []
                if (res.length) {
                    res.forEach((data) => {
                        columnValues.push(data.commCdVal)
                        columnLabels.push(data.commCdValNm)
                    })
                }
                // 그리드 컬럼 콤보박스 데이터 설정
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'values',
                    columnValues
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'labels',
                    columnLabels
                )
                this.gridObj.gridView.setColumnProperty(
                    columnId,
                    'lookupDisplay',
                    true
                )
            })
        },
        //확인
        async confirmBtn() {
            const rowCount = this.gridObj.dataProvider.getRowCount()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            const parentList = this.params.parentList // 부모창의 상품리스트
            let returnVal = []
            let duplicationCnt = 0 // 부모창 상품과의 중복수
            let compareCnt = 0 // 비교횟수

            if (rowCount == 0) {
                this.openAlert(
                    // '입력한 상품이 존재 하지 않습니다.'
                    CommonMsg.getMessage('MSG_00143')
                )
                return
            }
            if (
                rowCount == 1 &&
                (_.isEmpty(rowData[0].serNum) || _.isEmpty(rowData[0].prodCd))
            ) {
                this.openAlert(CommonMsg.getMessage('MSG_00143'))
                return
            }
            for (var i = 0; i < rowData.length; i++) {
                compareCnt = duplicationCnt

                // 부모창 리스트와의 중복데이터 체크
                if (parentList.length > 0) {
                    parentList.forEach((item) => {
                        if (
                            item['serNum'] == rowData[i].serNum &&
                            item['colorCd'] == rowData[i].colorCd &&
                            item['prodCd'] == rowData[i].prodCd &&
                            item['prodCl'] == rowData[i].prodCl
                        ) {
                            duplicationCnt++
                        }
                    })
                }

                if (duplicationCnt > compareCnt) {
                    continue
                }
                if (
                    _.isEmpty(rowData[i].serNum) ||
                    _.isEmpty(rowData[i].prodCd)
                ) {
                    continue
                }
                returnVal.push(rowData[i])
            }
            if (duplicationCnt > 0) {
                const confirm = await this.showTcComConfirm(
                    CommonMsg.getMessage('MSG_00156', '재고실사대상')
                )

                if (confirm) {
                    // 로직처리
                    this.$emit('returnVal', returnVal)
                    this.activeOpen = false
                }
            } else {
                this.$emit('returnVal', returnVal)
                this.activeOpen = false
            }
        },
        // alert창 호출
        openAlert(alertBodyTxt, alertSize) {
            this.showTcComAlert(alertBodyTxt, {
                header: this.alertHeadTxt,
                size: _.isEmpty(alertSize) ? '400' : alertSize,
            })
        },
        //2차원바코드입력팝업
        addBarCodePop() {
            this.gridObj.gridView.commit()
            this.srchBarCodePopParam.applyDt = CommonUtil.onlyNumber(
                this.params.aplyDt
            ) // 출고예정일
            this.srchBarCodePopParam.inOutClCd = '000'
            this.srchBarCodePopParam.outPlcId = this.params?.hldPlcId // 출고처코드
            this.srchBarCodePopParam.prchTyp = this.params?.prchTyp // 구매유형코드
            this.showProdInsBarCdPop = true
        },
        //2차원바코드입력팝업
        barCodePopReturnData(returnData) {
            // 2차원바코드입력 callback
            this.gridObj.gridView.commit()
            if (returnData.length > 0) {
                let index = this.gridObj.gridView.getItemCount()
                let data = {}
                let rowData = {}
                let duplicationCnt = 0
                for (var i = 0; i < returnData.length; i++) {
                    data = returnData[i]
                    if (!this.checkSerNum(data, 'barcode')) {
                        duplicationCnt++
                        continue
                    }

                    // 2차원바코드팝업 리턴 값 상품입력팝업 그리드 컬럼 매핑
                    data['mdlClCd'] = data['eqpClCd'] // 단말기구분
                    data['prodCl'] = data['prodClCd'] // 상품구분
                    data['hldPlcId'] = data['hldDealcoCd'] // 입출고처코드
                    data['disSt'] = data['disStCd'] // 재고상태코드
                    data['qty'] = 1 // 수량
                    data['barYn'] = 'Y' // 스캔여부

                    // 상품정보 append
                    rowData =
                        this.gridObj.gridView.getItemCount() == 0
                            ? null
                            : this.gridObj.dataProvider.getJsonRow(
                                  this.gridObj.gridView.getItemCount() - 1
                              )
                    if (rowData != null) {
                        if (
                            _.isEmpty(rowData.serNum) ||
                            _.isEmpty(rowData.prodCd)
                        ) {
                            // 검색완료되지 않은 해당행에 값 insert
                            index = this.gridObj.gridView.getItemCount() - 1
                            this.gridObj.gridView.setValues(index, data)
                        } else {
                            // 검색완료된행 다음행에 insert
                            index = this.gridObj.gridView.getItemCount()
                            this.gridObj.dataProvider.insertRow(index, data)
                        }
                    } else {
                        this.gridObj.dataProvider.insertRow(index, data)
                    }
                    index++
                }
                if (duplicationCnt > 0) {
                    this.openAlert(
                        '중복된 상품이 존재합니다. \n중복된 상품은 제외 후 추가됩니다.'
                    )
                }

                this.gridObj.gridView.setColumnProperty(
                    'serNum',
                    'editable',
                    false
                )
            }
        },
        // 재고상품리스트 callback 데이터
        disProdData(returnVal) {
            if (CommonUtil.isNotEmptyObject(returnVal)) {
                if (this.checkSerNum(returnVal)) {
                    this.gridObj.gridView.setValues(this.sRow, returnVal)
                    this.gridObj.gridView.setColumnProperty(
                        'serNum',
                        'editable',
                        false
                    )
                    this.addRow()
                }
            }
        },
    },
}
</script>
