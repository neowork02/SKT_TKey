import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'deptNm', // 부서
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyCd', // 대리점코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktAgencyNm', // 대리점명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dlvcoCd', // SKN 배송지 코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tkeyDlvcoCd', // 배송지 코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tkeyDlvcoNm', // 배송지명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tkeySaleClCd', // 매출구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'tkeySaleClNm', // 매출구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDt', // 매출일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodGrpCd', // 상품군
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodGrpNm', // 상품군명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd', // SKN 상품코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktProdCd', // Swing상품코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm', // 상품명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm', // 색상명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd', // 색상코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleQty', // 수량
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleUprc', // 단가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cashSaleAmt', // 현금매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'crdtSaleAmt', // 여신매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'svcCrdSaleAmt', // 개통여신
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'acntTrnsfSaleAmt', // 계좌이체
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cardSaleAmt', // 카드매출
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'vatAmt', // 부가세
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleTotAmt', // 금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'billSumClCd', // 집계구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'billSumClNm', // 집계구분명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'nshopId', // nSHOP ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'taxBillMgmtNo', // 세금계산서번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealDt', // 세금계산서 작성일
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn', // 삭제여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'updCnt', // 수정횟수
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'deptNm',
            fieldName: 'deptNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '부서',
        },
        {
            name: 'sktAgencyCd',
            fieldName: 'sktAgencyCd',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '대리점코드',
        },
        {
            name: 'sktAgencyNm',
            fieldName: 'sktAgencyNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '대리점명',
        },
        {
            name: 'dlvcoCd',
            fieldName: 'dlvcoCd',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: 'SKN 배송지 코드',
        },
        {
            name: 'tkeyDlvcoCd',
            fieldName: 'tkeyDlvcoCd',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '배송지 코드',
        },
        {
            name: 'tkeyDlvcoNm',
            fieldName: 'tkeyDlvcoNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '배송지명',
        },
        {
            name: 'tkeyDlvcoNm',
            fieldName: 'tkeyDlvcoNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '배송처',
        },
        {
            name: 'tkeySaleClNm',
            fieldName: 'tkeySaleClNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '매출구분',
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '조직코드',
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'saleDt',
            fieldName: 'saleDt',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '매출일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'prodGrpNm',
            fieldName: 'prodGrpNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '상품군',
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: 'SKN 상품코드',
        },
        {
            name: 'sktProdCd',
            fieldName: 'sktProdCd',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: 'Swing상품코드',
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '상품명',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '색상코드',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '색상명',
        },
        {
            name: 'saleQty',
            fieldName: 'saleQty',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '수량',
        },
        {
            name: 'saleUprc',
            fieldName: 'saleUprc',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '단가',
        },
        {
            name: 'cashSaleAmt',
            fieldName: 'cashSaleAmt',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '현금매출',
        },
        {
            name: 'crdtSaleAmt',
            fieldName: 'crdtSaleAmt',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '여신매출',
        },
        {
            name: 'svcCrdSaleAmt',
            fieldName: 'svcCrdSaleAmt',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '개통여신',
        },
        {
            name: 'acntTrnsfSaleAmt',
            fieldName: 'acntTrnsfSaleAmt',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '계좌이체',
        },
        {
            name: 'cardSaleAmt',
            fieldName: 'cardSaleAmt',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '카드매출',
        },
        {
            name: 'vatAmt',
            fieldName: 'vatAmt',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '부가세',
        },
        {
            name: 'saleTotAmt',
            fieldName: 'saleTotAmt',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            numberFormat: '#,##0',
            header: '금액',
        },
        {
            name: 'billSumClNm',
            fieldName: 'billSumClNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '집계구분',
        },
        {
            name: 'nshopId',
            fieldName: 'nshopId',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: 'nSHOP ID',
        },
        {
            name: 'taxBillMgmtNo',
            fieldName: 'taxBillMgmtNo',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '세금계산서번호',
        },
        {
            name: 'dealDt',
            fieldName: 'dealDt',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: '세금계산서 작성일',
            datetimeFormat: 'yyyy-MM-dd',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}
