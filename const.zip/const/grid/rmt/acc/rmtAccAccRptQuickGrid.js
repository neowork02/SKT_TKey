'use strict'

import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_HEADER = {}

/**
 * column, field
 * @description https://docs.realgrid.com/refs/cell-editor
 * @property {string} type - 'data'|'check'|'csv' 사용자가 지정한 렌더러 종류 (이름)
 * @property {boolean} visible - 그리드 표현 여부
 * @property {boolean} readonly - 그리드 편집 불가능 여부
 * @property {string} fieldDatetimeFormat - 원시데이터 포맷
 * @property {string} columnDatetimeFormat - 그리드데이터 포맷
 * @property {string} editor.type - 'line'|'password'|'multiline'|'number'|'date'|'btdate'|'list'|'search'|'Checklist'
 * @property {function} displayCallback - 그리드 필터 설정
 */
const GRID_META = [
    {
        fieldName: '__rowState',
        dataType: ValueType.TEXT,
        visible: false,
    },
    {
        fieldName: 'orgTree',
        editable: false,
        header: { text: '조직' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'accPlc',
        editable: false,
        header: { text: '정산처' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'ukeyChannelCd',
        editable: false,
        header: { text: 'P코드' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'saleChrgrNm',
        editable: false,
        header: { text: '영업담당자' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c1',
        editable: false,
        header: { text: 'C1' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c2',
        editable: false,
        header: { text: 'C2' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c3',
        editable: false,
        header: { text: 'C3' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c4',
        editable: false,
        header: { text: 'C4' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c5',
        editable: false,
        header: { text: 'C5' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c6',
        editable: false,
        header: { text: 'C6' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c7',
        editable: false,
        header: { text: 'C7' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c8',
        editable: false,
        header: { text: 'C8' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c9',
        editable: false,
        header: { text: 'C9' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c10',
        editable: false,
        header: { text: 'C10' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c11',
        editable: false,
        header: { text: 'C11' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c12',
        editable: false,
        header: { text: 'C12' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c13',
        editable: false,
        header: { text: 'C13' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c14',
        editable: false,
        header: { text: 'C14' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c15',
        editable: false,
        header: { text: 'C15' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c16',
        editable: false,
        header: { text: 'C16' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c17',
        editable: false,
        header: { text: 'C17' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c18',
        editable: false,
        header: { text: 'C18' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c19',
        editable: false,
        header: { text: 'C19' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c20',
        editable: false,
        header: { text: 'C20' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c21',
        editable: false,
        header: { text: 'C21' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c22',
        editable: false,
        header: { text: 'C22' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c23',
        editable: false,
        header: { text: 'C23' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c24',
        editable: false,
        header: { text: 'C24' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c25',
        editable: false,
        header: { text: 'C25' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c26',
        editable: false,
        header: { text: 'C26' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c27',
        editable: false,
        header: { text: 'C27' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c28',
        editable: false,
        header: { text: 'C28' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c29',
        editable: false,
        header: { text: 'C29' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c30',
        editable: false,
        header: { text: 'C30' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c31',
        editable: false,
        header: { text: 'C31' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c32',
        editable: false,
        header: { text: 'C32' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c33',
        editable: false,
        header: { text: 'C33' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c34',
        editable: false,
        header: { text: 'C34' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c35',
        editable: false,
        header: { text: 'C35' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c36',
        editable: false,
        header: { text: 'C36' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c37',
        editable: false,
        header: { text: 'C37' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c38',
        editable: false,
        header: { text: 'C38' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c39',
        editable: false,
        header: { text: 'C39' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c40',
        editable: false,
        header: { text: 'C40' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c41',
        editable: false,
        header: { text: 'C41' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c42',
        editable: false,
        header: { text: 'C42' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c43',
        editable: false,
        header: { text: 'C43' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c44',
        editable: false,
        header: { text: 'C44' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c45',
        editable: false,
        header: { text: 'C45' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c46',
        editable: false,
        header: { text: 'C46' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c47',
        editable: false,
        header: { text: 'C47' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
    {
        fieldName: 'c48',
        editable: false,
        header: { text: 'C48' },
        type: 'data',
        dataType: ValueType.TEXT,
    },
]

GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = []
GRID_HEADER.contextStyle = `height: 500px`

const MOCK_DATA = {
    adpayMgmtVoList: [],
}

export { GRID_HEADER, MOCK_DATA }
