import { ValueType } from 'realgrid'

export const SUB_UPLOAD_HEADER = {
    fields: [
        {
            fieldName: 'templetSeq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'templetCd',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'templetNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'title',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'calYearMonth',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstrUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'userNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'seq',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'phyFileNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'zipFileNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'regDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'templet_nm',
            fieldName: 'templet_nm',
            header: {
                text: '업로드구분',
            },
            editable: false,
        },
        {
            name: 'calYearMonth',
            fieldName: 'calYearMonth',
            header: {
                text: '정산월',
            },
            editable: false,
        },
        {
            name: 'title',
            fieldName: 'title',
            header: {
                text: '제목',
            },
            editable: false,
        },
        {
            name: 'userNm',
            fieldName: 'userNm',
            header: {
                text: '등록자',
            },
            editable: false,
        },
        {
            name: 'regDtm',
            fieldName: 'regDtm',
            header: {
                text: '등록일자',
            },
            editable: false,
        },
    ],
}
