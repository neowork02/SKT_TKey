<template>
    <div>
        <!-- gridWrap -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="배송지목록"
                :gridObj="this.gridObj"
                :isPageRows="true"
                :isExceldown="true"
                :isNextPage="true"
                :isPageCnt="true"
                @excelDownBtn="this.excelDown"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="paging1.totalPageCnt"
                :apiFunc="pageMove"
                :rowCnt="paging1.pageSize"
                @input="pageSizeChange"
            />
        </div>

        <DetailPopup
            v-if="localDialogShow"
            ref="popup"
            :parentParam="this.ifYn ? dtlParam2 : dtlParam"
            :dialogShow.sync="localDialogShow"
        />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/prm/dirDlvMgmt/helpers'
import { HEADER } from '@/const/grid/bas/prm/basPrmDirDlvMgmtHeader'

import { CommonGrid } from '@/utils'

import DetailPopup from './PopupContainer.vue'
import _ from 'lodash'
import attachedFileApi from '@/api/common/attachedFile'
import CommonMixin from '@/mixins'

export default {
    mixins: [CommonMixin],
    name: 'TableContainer',
    components: { DetailPopup },
    data() {
        return {
            activePage: 1, // 현재페이지
            rowCnt: 30,
            localDialogShow: false,
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            layout: HEADER.layout,
            gridData: this.GridSetData(),
            dtlParam: {
                ifYn: '',
                dealcoCd: '',
                hstSeq: '',
                isHst: false,
            },
            dtlParam2: {
                ifYn: '',
                sktAgencyCd: '',
                sktSubCd: '',
                salePlcCd: '',
                isHst: false,
            },
            ifYn: false, // true 인터페이스 / false : 기본
        }
    },
    mounted() {
        // grid
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader

        this.gridObj.setGridState(false, false, false)
        this.gridObj.gridView.setRowIndicator({
            visible: true,
            headText: 'No',
        })
        this.$refs.grid.gridView.displayOptions.selectionStyle = 'rows'
        this.$refs.grid.gridView.displayOptions.selectionStyle = 'even'

        this.gridObj.gridView.setColumnLayout(this.layout)

        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            if (typeof clickData.itemIndex !== 'undefined') {
                let ifYn = grid.getValue(clickData.itemIndex, 'ifYn')

                if (_.isEqual(ifYn, 'Y')) {
                    let data = {}
                    data.ifYn = 'Y'
                    data.sktAgencyCd = grid.getValue(
                        clickData.itemIndex,
                        'sktAgencyCd'
                    )
                    data.sktSubCd = grid.getValue(
                        clickData.itemIndex,
                        'sktSubCd'
                    )
                    data.salePlcCd = grid.getValue(
                        clickData.itemIndex,
                        'salePlcCd'
                    )
                    data.isHst = false

                    this.ifYn = true
                    this.dtlParam2 = data
                    /*
                        this.dtlParam2.ifYn = 'Y'
                        this.dtlParam2.sktAgencyCd = sktAgencyCd
                        this.dtlParam2.sktSubCd = sktSubCd
                        this.dtlParam2.salePlcCd = salePlcCd
                        this.dtlParam2.isHst = false
                        
                       */
                } else {
                    let data = {}
                    data.ifYn = 'N'
                    data.dealcoCd = grid.getValue(
                        clickData.itemIndex,
                        'dealcoCd'
                    )
                    data.hstSeq = grid.getValue(clickData.itemIndex, 'hstSeq')
                    data.isHst = false
                    this.dtlParam = data

                    /*
                        this.dtlParam.ifYn = 'N'
                        this.dtlParam.dealcoCd = dealcoCd
                        this.dtlParam.hstSeq = hstSeq
                        this.dtlParam.isHst = false
                        
                       */
                }
                this.detailPopup()
            }
        }
    },
    computed: {
        ...serviceComputed,
        resultList1: {
            get() {
                return this.resultList
            },
        },
        paging1: {
            get() {
                return this.paging
            },
        },
        searchParam: {
            get() {
                return this.searchParams
            },
        },
    },
    methods: {
        ...serviceMethods,
        async pageMove(page) {
            console.log('pageMove', page)
            //Page Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageNum: page },
            })
            this.$emit('Refresh', '') //next paging api call
        },
        async pageSizeChange(pageSize) {
            console.log('pageSizeChange', pageSize)
            //PageSize change Move
            await this.defaultAssign_({
                key: 'paging',
                value: { ...this.paging, pageSize: pageSize },
            })
            await this.defaultAssign_({
                key: 'initPaging',
                value: { ...this.paging, pageSize: pageSize },
            })
            if (this.paging.totalDataCnt > 0) this.$emit('Refresh', '') //refresh paging api call
        },
        SetPaging() {
            this.gridData = this.GridSetData() //초기화
            this.gridData.totalPage = this.paging.totalPageCnt // 총페이지수
            //Grid Row 가져올때 페이지정보 Setting
            console.log(
                '🚀 ~ file: TableContainer.vue ~ line 129 ~ SetPaging ~ paging',
                this.paging
            )
            this.gridHeaderObj.setPageCount(this.paging) //TCRealGridHeader 계산식이 좀 이상함??
        },
        /* 엑셀다운로드 */
        excelDown() {
            /*this.gridHeaderObj.exportGrid(
                `배송처관리-배송지목록${moment(new Date()).format(
                    'YYYYMMDDHHmmss'
                )}.xls`

             */

            if (_.isEmpty(this.searchParam.orgCd)) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다')
            } else {
                attachedFileApi.downLoadFile(
                    '/api/v1/backend-long/resource/bas/prm/dlv-co-excel-mgmt',
                    this.searchParam
                )
            }
        },
        detailPopup() {
            this.localDialogShow = true
        },
        //GridSet Init
        GridSetData: function () {
            return new CommonGrid(0, this.rowCnt, '', '') //totalPage, rowPerPage, saveRows, delRows
        },
    },
    watch: {
        resultList1(val, oldVal) {
            console.log('resultList1 watched: ', val, oldVal, this.pageSize)

            this.$refs.grid.setRows(this.resultList)
            this.gridObj.setRows(this.resultList)
        },
        paging1() {
            this.SetPaging()
        },
    },
}
</script>

<style scoped></style>
