import { ValueType } from 'realgrid'

export const BAS_BCO_AGENCYS_HEADER = {
    fields: [
        {
            fieldName: 'sktOrgClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'operDealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'sktOrgClCd',
            fieldName: 'sktOrgClCd',
            styles: {
                textAlignment: 'center',
            },
            editable: false,
            lookupDisplay: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
            },
            header: {
                text: '거래처구분',
            },
        },
        {
            name: 'sktOrgCd',
            fieldName: 'sktOrgCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
            },
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '서브코드',
            },
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            styleName: 'left-column',
            header: {
                text: '거래처명',
            },
        },
    ],
}
