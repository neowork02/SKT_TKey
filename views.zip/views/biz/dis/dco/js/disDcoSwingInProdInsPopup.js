export const SwingInProdIns = {
    /* 상품입력시 필수값 */
    prodClCd: '', //모델구분코드
    prodClNm: '', //상품구분명
    mfactCd: '', //제조사코드
    mfactNm: '', //제조사명
    prodCd: '', //모델코드
    prodNm: '', //모델명
    colorCd: '', // 색상코드
    colorNm: '', //색상명
    serNum: '', //일련번호
    /* 상품입력시 비 필수값 */
    chk: '', // 체크여부
    seq: '', //번호
    opDt: '', //처리일자
    opTm: '', //if처리일자
    rgstSeq: '', //등록순번
    inoutClCd: '', //입출고구분코드
    inoutPlcCd: '', //입출고처코드
    inoutSchdDt: '', //입고예정일
    toSerNum: '', //종료일련번호
    sktOrgCd: '', //SKT조직코드
    sktSubOrgCd: '', //SKT서브조직코드
    errorClCd: '', //오류내용
    sknRnpTypCd: '', //SKN수불유형코드
    sknOpClCd: '', //SKN처리구분코드
    errDesc: '',
    inQty: '',
    reflYn: '', //반영여부
    fixYn: '', //수정여부
    inoutClNm: '', //입출고처명
    inoutPlcNm: '', //입출고처코드
}
