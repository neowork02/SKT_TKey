<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : NewAccPacEdiAccMgmtSearchBoxEdi.vue
 * 설명: 
 * 작성자: 최우진
 * 작성일: 2022.09.23
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="searchLayer_wrap" v-if="tabIndex == nowTabIndex">
        <div class="searchform">
            <div class="formitem div3">
                <TCComDatePicker
                    labelName="조회월"
                    calType="M"
                    :eRequired="true"
                    v-model="searchParams.baseMth_"
                >
                </TCComDatePicker>
            </div>
            <div class="formitem div3">
                <TCComInputSearchText
                    v-model="searchParams.orgNm"
                    :codeVal.sync="searchParams.orgId"
                    labelName="조직"
                    placeholder="입력해주세요"
                    :disabled="false"
                    :disabledAfter="true"
                    :objAuth="objAuth"
                    :eRequired="true"
                    @enterKey="onAuthOrgTreeEnterKey"
                    @appendIconClick="onAuthOrgTreeIconClick"
                    @input="onAuthOrgTreeInput"
                />
                <BasBcoAuthOrgTreesPopup
                    v-if="showBcoAuthOrgTrees"
                    :parentParam="searchParams"
                    :rows="resultAuthOrgTreeRows"
                    :dialogShow.sync="showBcoAuthOrgTrees"
                    @confirm="onAuthOrgTreeReturnData"
                />
            </div>
            <div class="formitem div3">
                <TCComComboBox
                    codeId="ZACC_C_00460"
                    labelName="유형"
                    v-model="searchParams.payTypCd"
                    :disabled="false"
                    :addBlankItem="true"
                    blankItemText="전체"
                    blankItemValue="0"
                />
            </div>
        </div>
        <div class="searchform">
            <div class="formitem div3">
                <TCComInput
                    labelName="수납관리번호"
                    :eRequired="false"
                    :disabled="false"
                    v-model="searchParams.saleMgmtNo"
                />
            </div>
            <div class="formitem div3">
                <TCComInput
                    labelName="승인번호"
                    :eRequired="false"
                    :disabled="false"
                    v-model="searchParams.aprvNum"
                />
            </div>
            <div class="formitem div3"></div>
        </div>
    </div>
</template>

<script>
import _ from 'lodash'
import moment from 'moment'
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup' // 내부조직팝업(권한)
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees' // 내부조직팝업(권한)

export default {
    name: 'NewAccPacEdiAccMgmtSearchBoxEdi',
    components: {
        BasBcoAuthOrgTreesPopup, //  내부조직팝업(권한)
    },
    props: {
        tabIndex: {
            default: 0,
        },
        nowTabIndex: {
            default: 0,
        },
        objAuth: {
            default: {},
        },
        parentParams: {
            default: {},
        },
    },
    data() {
        return {
            showAlertBool: false,

            // 내부조직팝업(권한)
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [],

            // 조회조건
            searchParams: {
                baseMth_: moment().format('YYYY-MM'),
                baseMth: moment().format('YYYYMM'),
                orgId: '',
                orgNm: '',
                orgLevel: '',
                searchCoClOrgCd: '',
                payTypCd: '0',
                saleMgmtNo: '',
                aprvNum: '',
            },
        }
    },
    watch: {
        // parentParams의 값을 searchParams에 세팅한다.
        parentParams: {
            handler: function (json) {
                if (!_.isEmpty(json)) {
                    let keys = Object.keys(json)
                    for (let i = 0; i < keys.length; i++) {
                        this.searchParams[keys[i]] = json[keys[i]]
                    }
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        searchParams: {
            handler: function (newJson) {
                this.$emit('setSearchParams', newJson)
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        'searchParams.baseMth_'(newVal) {
            var _newVal = newVal
            if (!_.isEmpty(newVal)) {
                _newVal = newVal.replace(/-/g, '')
            }

            this.searchParams.baseMth = _newVal
        },
    },
    mounted() {
        // 부모에 변경된 값 전달
        this.$emit('setSearchParams', this.searchParams)
    },
    methods: {
        setParamJson(_method) {
            // 현재 tab의 조회조건을 this.searchParams 변수에 세팅한다.
            let _searchParams = _.cloneDeep(this.searchParams)

            // get방식으로 파라미터 넘길 때 오류로 인해 아래 제거함
            if (_method == 'GET') {
                delete _searchParams['baseMth_']
            }

            return _searchParams
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            let orgParams = {
                orgCd: this.searchParams.orgId,
                orgNm: this.searchParams.orgNm,
            }
            basBcoAuthOrgTreesApi.getAuthOrgTreeList(orgParams).then((res) => {
                console.log('getAuthOrgTreeList then : ', res)
                // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                if (res.length === 1) {
                    this.searchParams.orgId = _.get(res[0], 'orgCd')
                    this.searchParams.orgNm = _.get(res[0], 'orgNm')
                    this.searchParams.orgLevel = _.get(res[0], 'vLevel')
                    this.searchParams.searchCoClOrgCd = _.get(
                        res[0],
                        'orgCdLvl0'
                    )
                } else {
                    this.resultAuthOrgTreeRows = res
                    this.showBcoAuthOrgTrees = true
                }
            })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchParams.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParams.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchParams[this.getSearchOrgName()].orgId = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchParams.orgId = _.get(returnData, 'orgCd')
            this.searchParams.orgNm = _.get(returnData, 'orgNm')
            this.searchParams.orgLevel = _.get(returnData, 'orgLvl')
            this.searchParams.searchCoClOrgCd = _.get(returnData, 'orgCdLvl0')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
    },
}
</script>
