<template>
    <div>
        <search-container ref="searchContainer" />
        <div class="contBoth">
            <div>
                <table-container1 @PopupOpen="PopupOpen" @Refresh="Refresh" />
            </div>

            <div class="div4_6 cont2 right">
                <div class="contBoth">
                    <div>
                        <div>
                            <table-container
                                @PopupOpen="PopupOpen"
                                @Refresh="Refresh"
                            />
                        </div>
                    </div>
                    <div>
                        <button-container />
                    </div>
                    <div>
                        <table-container2
                            @PopupOpen="PopupOpen"
                            @Refresh="Refresh"
                        />
                    </div>
                </div>
            </div>
        </div>
        <button-container2 ref="buttonContainer2" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/adm/authMgmt/helpers'
import SearchContainer from './SearchContainer.vue'
import TableContainer from './TableContainer.vue'
import TableContainer1 from './TableContainer1.vue'
import TableContainer2 from './TableContainer2.vue'
import ButtonContainer from './ButtonContainer.vue'
// import ButtonContainer2 from './ButtonContainer2.vue'

export default {
    name: 'MainContent',
    components: {
        SearchContainer,
        TableContainer,
        TableContainer1,
        TableContainer2,
        ButtonContainer,
        // ButtonContainer2,
    },
    data() {
        return {
            objAuth: {},
        }
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
        PopupOpen(param) {
            this.$refs.popupContainer.open(param)
        },
        Refresh() {
            this.$refs.searchContainer.searchData()
        },
    },
}
</script>
