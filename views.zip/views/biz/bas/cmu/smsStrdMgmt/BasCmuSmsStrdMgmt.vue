<!-----------------------------------------------
 * 업무그룹명: 기준정보>기타
 * 서브업무명: SMS기준관리
 * 설명: SMS기준관리 조회/입력/수정 한다.
 * 작성자: P180392
 * 작성일: 2022.05.17
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <!-- <div class="content1"> -->
    <div class="content">
        <!-- Tit -->
        <h1>SMS기준관리</h1>
        <!-- // Tit -->
        <TCComTab
            :tab.sync="guideTab"
            :items="items"
            :itemName="itemName"
            :tabColor="tabColor"
            :textColor="textColor"
            :centered="centered"
            :grow="grow"
            :height="height"
            :hideSlider="hideSlider"
            :sliderColor="sliderColor"
            :vertical="vertical"
            @change="onActiveTabChange"
            sliderSize="8"
        >
            <template #Template1><main-content0 /></template>
            <template #Template2><main-content1 /></template>
            <template #Template3><main-content2 /></template>
            <template #Template4><main-content3 /></template>
            <template #Template5><main-content4 /></template>
        </TCComTab>
    </div>
    <!-- </div> -->
</template>

<script>
import MainContent0 from './smsTrmsTypHappyMgmt/BasCmuSmsTrmsTypHappyMgmt.vue'
import MainContent1 from './smsTrmsStrdMgmt/BasCmuSmsTrmsStrdMgmt.vue'
import MainContent2 from './dclsTrmsMgmt/BasCmuDclsTrmsMgmt.vue'
import MainContent3 from './dealcoSaleChrgrSmsMgmt/BasCmuDealcoSaleChrgrSmsMgmt.vue'
import MainContent4 from './dealcoBondSmsStrdMgmt/BasCmuDealcoBondSmsStrdMgmt.vue'

export default {
    name: 'BasCmuSmsStrdMgmt',
    created() {},
    beforeDestroy() {},
    components: {
        MainContent0,
        MainContent1,
        MainContent2,
        MainContent3,
        MainContent4,
    },
    data() {
        return {
            guideTab: 0,
            items: [
                'Template1',
                'Template2',
                'Template3',
                'Template4',
                'Template5',
            ],
            itemName: [
                'SMS전송유형관리',
                'SMS전송기준관리',
                '일마감전송관리',
                '거래처영업담당자관리SMS전송',
                '위탁거래처채권SMS기준관리',
            ],
            tabColor: '',
            textColor: '',
            height: '',
            sliderColor: '',
            centered: false,
            grow: false,
            hideSlider: false,
            vertical: false,
        }
    },
    computed: {},
    methods: {
        // eslint-disable-next-line no-unused-vars
        onActiveTabChange(tabIdx) {},
    },
}
</script>

<style>
.content1 {
    display: flex;
    height: 800px;
    gap: 1em;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
}
</style>
