<!-----------------------------------------------
 * 업무그룹명: DatePicker 컴포넌트
 * 서브업무명: DatePicker 공통함수
 * 설명: DatePicker 컴포넌트및 공통함수 
 * 작성자: 양현모
 * 작성일: 2022.04.07
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div>
        <span v-if="this.labelName" class="itemtit" :class="labelClass">
            <span v-if="this.eRequired" class="emph_txt">* </span>
            {{ this.labelName }}
        </span>
        <!--text field + search btn -->
        <span :class="elementClass">
            <div :class="cDivClass">
                <div :class="cSubDivClass">
                    <v-menu
                        v-model="dDialogShow"
                        :close-on-content-click="false"
                        transition="scale-transition"
                        offset-y
                        max-width="290px"
                        min-width="auto"
                    >
                        <template v-slot:activator="{}">
                            <v-text-field
                                ref="sDate"
                                v-model="dDate"
                                v-maska="getMasking"
                                outlined
                                dense
                                autocomplete="off"
                                :append-icon="cPrependIcon"
                                :placeholder="cPlaceHolder"
                                persistent-hint
                                single-line
                                :disabled="dEachDisabled.date"
                                :rules="getRules"
                                @click="onDataPickerShow"
                                @click:append="onDataPickerShow"
                                @keyup="onDateKeyUp"
                                @focus="emitFocus"
                            ></v-text-field>
                        </template>
                        <v-date-picker
                            v-model="dDateP"
                            no-title
                            locale="ko-KR"
                            :day-format="getDayFormat"
                            :type="cCalType"
                            @input="onDatePickerInput"
                            show-adjacent-months
                        />
                    </v-menu>
                </div>
                <div v-if="dHourShow" class="col9">
                    <v-text-field
                        v-if="dHourShow"
                        ref="sHour"
                        v-model="syncHourVal"
                        v-maska="`##`"
                        outlined
                        single-line
                        dense
                        maxlength="2"
                        :disabled="dEachDisabled.hour"
                        @focus="emitFocus"
                    />
                </div>
                <div v-if="dHourShow" class="col0">시</div>
                <div v-if="dMinuShow" class="col9">
                    <v-text-field
                        v-if="dMinuShow"
                        ref="sMinu"
                        v-model="syncMinuVal"
                        v-maska="`##`"
                        outlined
                        single-line
                        dense
                        maxlength="2"
                        :disabled="dEachDisabled.minu"
                        @focus="emitFocus"
                    />
                </div>
                <div v-if="dMinuShow" class="col0">분</div>
                <slot name="multiFrom" />
                <div v-if="dEndDateShow" class="col0">~</div>
                <div v-if="dEndDateShow" :class="cSubDivClass">
                    <v-menu
                        v-if="dEndDateShow"
                        v-model="dEndDialogShow"
                        :close-on-content-click="false"
                        transition="scale-transition"
                        offset-y
                        max-width="290px"
                        min-width="auto"
                    >
                        <template v-slot:activator="{}">
                            <v-text-field
                                ref="eDate"
                                v-model="dDateTo"
                                v-maska="getMasking"
                                outlined
                                dense
                                autocomplete="off"
                                :append-icon="cPrependIcon"
                                :placeholder="cPlaceHolder"
                                persistent-hint
                                single-line
                                :disabled="dEachDisabled.dateTo"
                                :rules="getRules"
                                @click="onEndDataPickerShow"
                                @click:append="onEndDataPickerShow"
                                @keyup="onDateToKeyUp"
                                @focus="emitFocus"
                            ></v-text-field>
                        </template>
                        <v-date-picker
                            v-model="dDateToP"
                            no-title
                            locale="ko-KR"
                            :day-format="getDayFormat"
                            :type="cCalType"
                            @input="onDateToPickerInput"
                            show-adjacent-months
                        />
                    </v-menu>
                </div>
                <div v-if="dEndHourShow" class="col9">
                    <v-text-field
                        ref="eHour"
                        v-model="syncEndHourVal"
                        v-maska="`##`"
                        outlined
                        dense
                        single-line
                        maxlength="2"
                        :disabled="dEachDisabled.endHour"
                        @focus="emitFocus"
                    />
                </div>
                <div class="col0" v-if="dEndHourShow">시</div>
                <div v-if="dEndMinuShow" class="col9">
                    <v-text-field
                        ref="eMinu"
                        v-model="syncEndMinuVal"
                        v-maska="`##`"
                        outlined
                        dense
                        single-line
                        maxlength="2"
                        :disabled="dEachDisabled.endMinu"
                        @focus="emitFocus"
                    />
                </div>
                <div v-if="dEndMinuShow" class="col0">분</div>
                <slot name="multiTo" />
            </div>
            <!--//text field + search btn -->
        </span>
    </div>
</template>

<script>
import { CommonUtil } from '@/utils'
import moment from 'moment'
import _ from 'lodash'
import { maska } from 'maska'
import CommonMixin from '@/mixins'
export default {
    directives: { maska },
    mixins: [CommonMixin],
    inheritAttrs: false,
    name: 'TCComDatePicker',
    components: {},
    props: {
        // 일자,월,시작일자
        value: {
            type: [String, Array],
            required: false,
        },
        //Class 적용
        elementClass: {
            type: String,
            default: 'iteminput',
            required: false,
        },
        //CSS Label Class
        labelClass: { type: String, default: '', required: false },
        //텍스트박스 명
        labelName: { type: String, default: '', required: false },
        //필수입력여부
        eRequired: { type: Boolean, default: false, required: false },
        //disabled
        disabled: { type: Boolean, default: false, required: false },
        //개별 disabled
        eachDisabled: {
            type: Object,
            default: () => {
                return {
                    date: false,
                    hour: false,
                    minu: false,
                    dateTo: false,
                    endHour: false,
                    endMinu: false,
                }
            },
            required: false,
        },
        // auth
        objAuth: { type: Object, default: () => {}, required: false },
        // 달력 구분
        // D->일별(TextBox + Icon)
        // M->월별(TextBox + Icon)
        // MP-> 기간월별(TextBox + Icon ~ TextBox + Icon)
        // DH->일별 시간(TextBox + Icon + TextBox)
        // DHM->일별 시간 분(TextBox + Icon + TextBox + TextBox)
        // DP->기간별(TextBox + Icon ~ TextBox + Icon)
        // DHP->기간별 시간(TextBox + Icon + TextBox ~ TextBox + Icon + TextBox)
        // DHMP->기간별 시간 분 (TextBox + Icon + TextBox + TextBox ~ TextBox + Icon + TextBox + TextBox)"
        calType: {
            type: String,
            default: 'D',
            required: false,
            validator: function (value) {
                var res = false
                if (
                    value == 'D' ||
                    value == 'M' ||
                    value == 'MP' ||
                    value == 'DH' ||
                    value == 'DHM' ||
                    value == 'DP' ||
                    value == 'DHP' ||
                    value == 'DHMP'
                ) {
                    res = true
                }
                return res
            },
        },
        // 시간,시작시간
        hourVal: { type: String, default: '', required: false },
        // 분,시작분
        minuVal: { type: String, default: '', required: false },
        // 종료시간
        endHourVal: { type: String, default: '', required: false },
        // 종료분
        endMinuVal: { type: String, default: '', required: false },
        // 함수, 부울 및 문자열의 혼합 배열을 사용할 수 있습니다.
        // 함수는 입력값을 인수로 전달하며 true/false 또는 오류 메시지를 포함하는 문자열을 반환해야 합니다.
        // 함수가 false를 반환하거나(또는 배열의 모든 값에 포함됨) 문자열인 경우 입력 필드가 오류 상태가 됩니다.
        rules: { required: false },
        // 기간 디폴트 옵션 여부
        periodDefaultOption: { type: Boolean, default: true, required: false },
    },
    data() {
        return {
            dDate: '',
            dDateTo: '',
            dDateP: '',
            dDateToP: '',
            dCalType: '',

            dAutofocus: false,
            dDialogShow: false,
            dHourShow: false, // 시간 입력박스 노출여부
            dMinuShow: false, // 분 입력박스 노출여부

            dEndDialogShow: false, // 종료일자 팝업
            dEndDateShow: false, // 종료일자 노출여부
            dEndHourShow: false, // 종료시간 노출여부
            dEndMinuShow: false, // 종료분 노출여부

            //날짜 / 시 / 분 개별 disabled
            dEachDisabled: {
                date: false,
                hour: false,
                minu: false,
                dateTo: false,
                endHour: false,
                endMinu: false,
            },
        }
    },
    computed: {
        syncHourVal: {
            get() {
                return this.hourVal
            },
            set(value) {
                this.$emit('update:hourVal', value)
            },
        },
        syncMinuVal: {
            get() {
                return this.minuVal
            },
            set(value) {
                this.$emit('update:minuVal', value)
            },
        },
        syncEndHourVal: {
            get() {
                return this.endHourVal
            },
            set(value) {
                this.$emit('update:endHourVal', value)
            },
        },
        syncEndMinuVal: {
            get() {
                return this.endMinuVal
            },
            set(value) {
                this.$emit('update:endMinuVal', value)
            },
        },
        cPrependIcon() {
            let res = 'mdi-calendar-month-outline'
            if (this.dCalType == 'D') {
                // res = 'mdi-calendar'
            } else if (this.dCalType == 'M') {
                // res = 'mdi-calendar-month'
            }
            return res
        },
        cCalType() {
            let res = 'date'
            // this.dCalType == 'D' ||
            // this.dCalType == 'DH' ||
            // this.dCalType == 'DHM' ||
            // this.dCalType == 'DP' ||
            // this.dCalType == 'DHP' ||
            // this.dCalType == 'DHMP'
            if (_.startsWith(this.dCalType, 'D')) {
                res = 'date'
            } else if (_.startsWith(this.dCalType, 'M')) {
                res = 'month'
            }
            return res
        },
        cPlaceHolder() {
            var res = ''
            if (_.startsWith(this.dCalType, 'D')) {
                res = '____--__--__'
            } else if (_.startsWith(this.dCalType, 'M')) {
                res = '____--__'
            }
            return res
        },
        // cSize() {
        //     let res = 'width:auto;'
        //     if (
        //         this.dCalType == 'DH' ||
        //         this.dCalType == 'DHM' ||
        //         this.dCalType == 'DHP' ||
        //         this.dCalType == 'DHMP'
        //     ) {
        //         // res = 'width:50%;'
        //     }

        //     return res
        // },

        //일자타입이 아닌경우 Div클래스 적용
        cDivClass() {
            let res = ''
            if (this.dCalType != 'D') {
                res = 'btnjoinType'
            }
            return res
        },

        //타입에 따라 Div클래스적용
        cSubDivClass() {
            let res = 'iteminput single'
            if (this.dCalType == 'DP' || this.dCalType == 'MP') {
                res = 'col5'
            } else if (this.dCalType == 'DH' || this.dCalType == 'DHM') {
                res = 'col6'
            } else if (this.dCalType == 'DHP' || this.dCalType == 'DHMP') {
                res = 'col7'
            } else {
                res = ''
            }
            return res
        },
        getRules() {
            let rules = []
            if (!_.isEmpty(this.rules)) {
                rules = _.concat(rules, this.rules)
            }
            return rules
        },
        getMasking() {
            let res = '####-##-##'
            if (_.startsWith(this.dCalType, 'M')) {
                res = '####-##'
            }
            return res
        },
    },
    // props 동적 제어
    watch: {
        value: function () {
            if (typeof this.value === 'string') {
                this.dDate = this.value
            } else {
                this.dDate = this.value[0]
                this.dDateTo = this.value[1]
            }
        },
        eachDisabled: {
            handler() {
                if (this.disabled === false) {
                    if (this.eachDisabled.date === true)
                        this.dEachDisabled.date = true //date disabled
                    else this.dEachDisabled.date = false

                    if (this.eachDisabled.hour === true)
                        this.dEachDisabled.hour = true //hour disabled
                    else this.dEachDisabled.hour = false

                    if (this.eachDisabled.minu === true)
                        this.dEachDisabled.minu = true //minu disabled
                    else this.dEachDisabled.minu = false

                    if (this.eachDisabled.dateTo === true)
                        this.dEachDisabled.dateTo = true //dateTo disabled
                    else this.dEachDisabled.dateTo = false

                    if (this.eachDisabled.endHour === true)
                        this.dEachDisabled.endHour = true //endHour disabled
                    else this.dEachDisabled.endHour = false

                    if (this.eachDisabled.endMinu === true)
                        this.dEachDisabled.endMinu = true //endMinu disabled
                    else this.dEachDisabled.endMinu = false
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: false, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        disabled: {
            handler() {
                if (this.disabled === true) {
                    this.dEachDisabled.date = true //date disabled
                    this.dEachDisabled.hour = true //hour disabled
                    this.dEachDisabled.minu = true //minu disabled
                    this.dEachDisabled.dateTo = true //dateTo disabled
                    this.dEachDisabled.endHour = true //endHour disabled
                    this.dEachDisabled.endMinu = true //endMinu disabled
                } else {
                    this.dEachDisabled.date = false //date disabled
                    this.dEachDisabled.hour = false //hour disabled
                    this.dEachDisabled.minu = false //minu disabled
                    this.dEachDisabled.dateTo = false //dateTo disabled
                    this.dEachDisabled.endHour = false //endHour disabled
                    this.dEachDisabled.endMinu = false //endMinu disabled
                }
            },
            deep: true, // 속성 내부까지 감시
            immediate: false, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
        dDate: function (value, oldValue) {
            //dDate 변화감지후 DatePicker도 변경
            if (_.startsWith(this.dCalType, 'M')) {
                if (!_.isEmpty(this.dDate) && this.dDate.length === 7) {
                    //입력받은 날짜를 - 구분자로 배열로 만듬
                    let arrDate = _.split(this.dDate, '-')
                    //월이 12월 이하
                    if (!_.isEmpty(arrDate[1]) && arrDate[1] <= 12) {
                        this.dDateP = this.dDate
                    }
                }
            } else {
                if (!_.isEmpty(this.dDate) && this.dDate.length === 10) {
                    //입력받은 날짜를 - 구분자로 배열로 만듬
                    let arrDate = _.split(this.dDate, '-')
                    //월이 12월 이하이고 일이 31일 이하
                    if (
                        !_.isEmpty(arrDate[1]) &&
                        arrDate[1] <= 12 &&
                        arrDate[1] <= 31
                    ) {
                        this.dDateP = this.dDate
                    }

                    // 기간인 경우 from 입력시 자동으로 from 기준 마지막일을 to에 설정
                    if (this.periodDefaultOption && this.checkPeriodDate()) {
                        if (!_.isEmpty(oldValue)) {
                            const repValue = CommonUtil.replaceDash(value)
                            const curMonth = Number(
                                CommonUtil.getCurrentMonth()
                            )
                            const selMonth = Number(
                                CommonUtil.getDayMonth(repValue)
                            )
                            // 선택한 날짜의 월이 현재 월보다 작으면(전월)
                            // 전월의 마지막 날짜로 설정
                            if (curMonth > selMonth) {
                                this.dDateTo = CommonUtil.getDayEndDay(
                                    repValue,
                                    'YYYY-MM-DD'
                                )
                                // 그 이외의 Case는 현재일로 설정
                            } else {
                                this.dDateTo = CommonUtil.getToday('YYYY-MM-DD')
                            }
                            this.dDateToP = this.dDateTo
                        }
                    }
                }
            }
            this.emitInput()
            this.emitChange()
        },
        dDateTo: function () {
            //dDateTo 변화감지후 DatePicker도 변경
            if (_.startsWith(this.dCalType, 'M')) {
                if (!_.isEmpty(this.dDateTo) && this.dDateTo.length === 7) {
                    //입력받은 날짜를 - 구분자로 배열로 만듬
                    let arrDate = _.split(this.dDate, '-')
                    //월이 12월 이하
                    if (!_.isEmpty(arrDate[1]) && arrDate[1] <= 12) {
                        this.dDateToP = this.dDateTo
                    }
                }
            } else {
                if (!_.isEmpty(this.dDateTo) && this.dDateTo.length === 10) {
                    //입력받은 날짜를 - 구분자로 배열로 만듬
                    let arrDate = _.split(this.dDateTo, '-')
                    //월이 12월 이하이고 일이 31일 이하
                    if (
                        !_.isEmpty(arrDate[1]) &&
                        arrDate[1] <= 12 &&
                        arrDate[1] <= 31
                    ) {
                        this.dDateToP = this.dDateTo
                    }
                }
            }
            this.emitInput()
            this.emitChange()
        },
    },
    created() {
        this.init()
    },
    mounted() {},
    methods: {
        init() {
            this.dCalType = this.calType
            if (!_.isEmpty(this.value)) {
                if (typeof this.value === 'string') {
                    this.dDate = this.value
                } else {
                    this.dDate = this.value[0]
                    this.dDateTo = this.value[1]
                }
            }

            // 일자+시간 노출
            if (this.dCalType == 'DH') {
                this.dHourShow = true
            }
            // 일자+시간+분 노출
            if (this.dCalType == 'DHM') {
                this.dHourShow = true
                this.dMinuShow = true
            }
            // 기간별 유형(전체) 일자 노출
            // this.dCalType == 'DP' ||
            // this.dCalType == 'MP' ||
            // this.dCalType == 'DHP' ||
            // this.dCalType == 'DHMP'
            if (this.checkPeriodDate()) {
                this.dEndDateShow = true
                if (this.dCalType == 'DHP') {
                    this.dEndHourShow = true
                    this.dHourShow = true
                }
                if (this.dCalType == 'DHMP') {
                    this.dEndHourShow = true //종료시간
                    this.dEndMinuShow = true //종료분
                    this.dHourShow = true //시작시간
                    this.dMinuShow = true //시작분
                }
            }

            if (this.disabled === true) {
                this.dEachDisabled.date = true //date disabled
                this.dEachDisabled.hour = true //hour disabled
                this.dEachDisabled.minu = true //minu disabled
                this.dEachDisabled.dateTo = true //dateTo disabled
                this.dEachDisabled.endHour = true //endHour disabled
                this.dEachDisabled.endMinu = true //endMinu disabled
            } else if (this.disabled === false) {
                if (this.eachDisabled.date === true)
                    this.dEachDisabled.date = true //date disabled
                if (this.eachDisabled.hour === true)
                    this.dEachDisabled.hour = true //hour disabled
                if (this.eachDisabled.minu === true)
                    this.dEachDisabled.minu = true //minu disabled
                if (this.eachDisabled.dateTo === true)
                    this.dEachDisabled.dateTo = true //dateTo disabled
                if (this.eachDisabled.endHour === true)
                    this.dEachDisabled.endHour = true //endHour disabled
                if (this.eachDisabled.endMinu === true)
                    this.dEachDisabled.endMinu = true //endMinu disabled
            }
        },
        // Date Type이 기간인지 여부 체크
        checkPeriodDate() {
            if (
                this.dCalType == 'DP' ||
                this.dCalType == 'MP' ||
                this.dCalType == 'DHP' ||
                this.dCalType == 'DHMP'
            ) {
                return true
            }

            return false
        },
        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },
        getDayFormat(date) {
            return new Date(date).getDate(date)
        },
        onDataPickerShow() {
            this.dDialogShow = !this.dDialogShow
        },
        // 종료일자 달력 팝업 오픈 여부
        onEndDataPickerShow() {
            this.dEndDialogShow = !this.dEndDialogShow
        },
        // 시작(일자,월) 값 양방향 바인딩
        emitInput() {
            let resDate
            // 기간별 유형(전체)
            // this.dCalType == 'DP' ||
            // this.dCalType == 'MP' ||
            // this.dCalType == 'DHP' ||
            // this.dCalType == 'DHMP'
            if (this.checkPeriodDate()) {
                resDate = [this.dDate, this.dDateTo]
            } else {
                resDate = this.dDate
            }

            this.$emit('input', resDate)
        },
        // 시작(일자,월) 값 양방향 바인딩
        emitChange() {
            let resDate
            // 기간별 유형(전체)
            // this.dCalType == 'DP' ||
            // this.dCalType == 'MP' ||
            // this.dCalType == 'DHP' ||
            // this.dCalType == 'DHMP'
            if (this.checkPeriodDate()) {
                resDate = [this.dDate, this.dDateTo]
            } else {
                resDate = this.dDate
            }
            this.$emit('change', resDate)
        },
        emitFocus(ev) {
            ev.target.select() //focus이벤트가 발생할때마다 전체선택
        },
        checkDate(value) {
            let bRet = false
            let dateRegexp = ''

            if (_.startsWith(this.dCalType, 'M')) {
                dateRegexp = /^\d{4}-(0[1-9]|1[012])$/
                if (!dateRegexp.test(value)) {
                    bRet = true
                }
            } else {
                dateRegexp = /^\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/
                if (!dateRegexp.test(value)) {
                    bRet = true
                }
            }
            return bRet
        },
        onDateKeyUp() {
            if (_.startsWith(this.dCalType, 'M')) {
                if (this.dDate.length === 7) {
                    if (this.checkDate(this.dDate)) {
                        this.showTcComAlert('날짜(월)가 유효하지 않습니다.')
                        this.dDate = ''
                    }
                    this.dDateP = this.dDate
                }
            } else {
                if (this.dDate.length === 10) {
                    if (this.checkDate(this.dDate)) {
                        this.showTcComAlert('날짜가 유효하지 않습니다.')
                        this.dDate = ''
                    }
                    this.dDateP = this.dDate
                }
            }
        },
        onDateToKeyUp() {
            if (_.startsWith(this.dCalType, 'M')) {
                if (this.dDateTo.length === 7) {
                    if (this.checkDate(this.dDateTo)) {
                        this.showTcComAlert('날짜(월)가 유효하지 않습니다.')
                        this.dDateTo = ''
                    }
                    this.dDateToP = this.dDateTo
                }
            } else {
                if (this.dDateTo.length === 10) {
                    if (this.checkDate(this.dDateTo)) {
                        this.showTcComAlert('날짜가 유효하지 않습니다.')
                        this.dDateTo = ''
                    }
                    this.dDateToP = this.dDateTo
                }
            }
        },
        onDatePickerInput(value) {
            this.dDate = value
            this.dDialogShow = !this.dDialogShow
        },
        onDateToPickerInput(value) {
            this.dDateTo = value
            this.dEndDialogShow = !this.dEndDialogShow
        },
        sDateFocus() {
            this.$refs.sDate.focus()
        },
        sHourFocus() {
            this.$refs.sHour.focus()
        },
        sMinuFocus() {
            this.$refs.sMinu.focus()
        },
        eDateFocus() {
            this.$refs.eDate.focus()
        },
        eHourFocus() {
            this.$refs.eHour.focus()
        },
        eMinuFocus() {
            this.$refs.eMinu.focus()
        },
    },
}
</script>

<style lang="scss" scoped>
// scss source
</style>
