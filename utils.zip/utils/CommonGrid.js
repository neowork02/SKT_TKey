class CommonGrid {
    //생성자 역할을 하는 constructor
    constructor(totalPage, gridRows, saveRows, delRows) {
        this.totalPage = totalPage //totalPage  : 총 페이지
        this.gridRows = gridRows //gridRows     : Grid Row수(하나페이지에 표시할 행의 개수)
        this.saveRows = saveRows //saveRows     : 변경되는 행 JsonData
        this.delRows = delRows //delRows     : 삭제되는 행 JsonData
    }

    //getter
    get currentPage() {
        return this._currentPage
    }

    //setter : class내 속성 값의 제한을 두어야 하는 경우 자주 사용
    set currentPage(value) {
        this._currentPage = value
    }

    //getter
    get totalPage() {
        return this._totalPage
    }

    //setter : class내 속성 값의 제한을 두어야 하는 경우 자주 사용
    set totalPage(value) {
        this._totalPage = value
    }

    //getter
    get gridRows() {
        return this._gridRows
    }

    //setter : class내 속성 값의 제한을 두어야 하는 경우 자주 사용
    set gridRows(value) {
        this._gridRows = value
    }

    //getter
    get saveRows() {
        return this._saveRows
    }

    //setter : class내 속성 값의 제한을 두어야 하는 경우 자주 사용
    set saveRows(value) {
        this._saveRows = value
    }

    //getter
    get delRows() {
        return this._delRows
    }

    //setter : class내 속성 값의 제한을 두어야 하는 경우 자주 사용
    set delRows(value) {
        this._delRows = value
    }

    //method
    Print() {
        console.log(
            '현재페이지 번호 : ' +
                this.currentPage +
                ' 총 페이지 : ' +
                this._totalPage +
                ' Grid Row수 : ' +
                this.gridRows +
                ' 현재페이지 Row수 : ' +
                this.pageRows
        )
    }
}
export default CommonGrid
