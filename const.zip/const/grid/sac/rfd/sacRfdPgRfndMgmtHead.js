import { ValueType } from 'realgrid'

export const G_HEADER = {
    fields: [
        {
            fieldName: 'chk', // 체크
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rowNum', // 순번
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstDealcoNm', // 입금처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstShopCd', // 입금처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndDealcoNm', // 환불처명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndShopCd', // 환불처매장코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndDt', // 환불일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndAcntNo', // 환불계좌
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndSeq', // 환불차수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstYm', // 입금월
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndClCd', // 환불구분코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndClNm', // 환불구분
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndAmt', // 환불금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'rfndUserNm', // 환불처리자명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixYn', // 전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixYnNm', // 전송여부명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rmks', // 비고
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstDealcoCd', // 입금처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndDealcoCd', // 환불처코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndUserId', // 환불처리자ID
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndBankCd', // 환불은행코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstrNm', // 예금주명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sapDpstrNm', // 예금주명(SAP)
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agrmtDpstrYn', // 예금주일치여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'forceAprvYn', // 강제승인여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndImagAcntNo', // 환불대상가상계좌번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rfndImagAcntSeq', // 환불가상계좌일련번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modPosYn', // 수정가능여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fixDt', // 확정일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsDt', // 전송일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mthChkYn', // 환불월 월마감체크
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd', // 조직코드
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgLvl', // 조직레벨
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm', // 조직명
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNmShot', // 조직명2
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstAmt', // 입금액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'bamt', // 잔액
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'procClCd', // 처리구분코드
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dpstDt', // 입금일자
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dpstSeq', // 입금계좌차수
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'vrAcntNo', // 가상계좌번호
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'trmsYn', // 전송여부
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bankCd', // 은행코드
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },
        {
            name: 'rfndDealcoNm',
            fieldName: 'rfndDealcoNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '환불처명',
        },
        {
            name: 'rfndDt',
            fieldName: 'rfndDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '환불일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'rfndAcntNo',
            fieldName: 'rfndAcntNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '환불계좌',
        },
        {
            name: 'rfndSeq',
            fieldName: 'rfndSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '환불차수',
        },
        {
            name: 'dpstYm',
            fieldName: 'dpstYm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입금월',
            textFormat: '([0-9]{4})([0-9]{2})$;$1-$2',
        },
        {
            name: 'rfndClNm',
            fieldName: 'rfndClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '구분',
        },
        {
            name: 'rfndAmt',
            fieldName: 'rfndAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '환불액',
            numberFormat: '#,##0',
        },
        {
            name: 'rfndUserNm',
            fieldName: 'rfndUserNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '환불처리자',
        },
        {
            name: 'fixYnNm',
            fieldName: 'fixYnNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '전송여부',
        },
        {
            name: 'rmks',
            fieldName: 'rmks',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '비고',
            width: '400',
        },
    ],
}

export const G_POPUP_HEADER = {
    columns: [
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '300',
            styles: {
                textAlignment: 'center',
            },
            header: '조직명',
        },

        {
            name: 'dpstDt',
            fieldName: 'dpstDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입금일자',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'vrAcntNo',
            fieldName: 'vrAcntNo',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '가상계좌',
            footer: {
                text: '합계',
            },
        },
        {
            name: 'dpstAmt',
            fieldName: 'dpstAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '입금액',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'rfndAmt',
            fieldName: 'rfndAmt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '환불액',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
            },
        },
        {
            name: 'bamt',
            fieldName: 'bamt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: '잔액',
            numberFormat: '#,##0',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,##0',
                valueCallback: function (
                    grid
                    // column,
                    // footerIndex,
                    // columnFooter,
                    // value
                ) {
                    return (
                        Number(grid.getSummary('dpstAmt', 'sum')) -
                        Number(grid.getSummary('rfndAmt', 'sum'))
                    )
                },
            },
        },
    ],
}
