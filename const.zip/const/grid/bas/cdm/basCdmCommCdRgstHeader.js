import { ValueType } from 'realgrid'

export const commCodeLstHeader = {
    fields: [
        {
            fieldName: 'commCdId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'commCdNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'commCdDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'supCommCdId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo01',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo02',
            dataType: ValueType.TEXT,
        },

        {
            fieldName: 'addInfo03',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo04',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo05',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo06',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo07',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo08',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo09',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'addInfo10',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'commCdId',
            fieldName: 'commCdId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 구분코드ID',
            },
        },
        {
            name: 'commCdNm',
            fieldName: 'commCdNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 구분코드명',
            },
        },
        {
            name: 'commCdDesc',
            fieldName: 'commCdDesc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '구분코드설명',
            },
        },
        {
            name: 'supCommCdId',
            fieldName: 'supCommCdId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            button: 'action',
            buttonVisibility: 'always',
            header: {
                text: '슈퍼공통코드ID',
            },
        },
        {
            name: 'rgstClCd',
            fieldName: 'rgstClCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 등록구분ID',
            },
        },
        {
            name: 'rgstClNm',
            fieldName: 'rgstClNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 등록구분',
            },
        },
        {
            name: 'delYn',
            fieldName: 'delYn',
            sortable: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '삭제여부',
            },
        },
        {
            name: 'addInfo01',
            fieldName: 'addInfo01',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가정보1',
            },
        },
        {
            name: 'addInfo02',
            fieldName: 'addInfo02',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가정보2',
            },
        },
        {
            name: 'addInfo03',
            fieldName: 'addInfo03',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가정보3',
            },
        },
        {
            name: 'addInfo04',
            fieldName: 'addInfo04',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가정보4',
            },
        },

        {
            name: 'addInfo05',
            fieldName: 'addInfo05',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가정보5',
            },
        },

        {
            name: 'addInfo06',
            fieldName: 'addInfo06',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가정보6',
            },
        },

        {
            name: 'addInfo07',
            fieldName: 'addInfo07',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가정보7',
            },
        },

        {
            name: 'addInfo08',
            fieldName: 'addInfo08',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가정보8',
            },
        },

        {
            name: 'addInfo09',
            fieldName: 'addInfo09',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가정보9',
            },
        },
        {
            name: 'addInfo10',
            fieldName: 'addInfo10',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '추가정보10',
            },
        },
        {
            name: 'modUserId',
            fieldName: 'modUserId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자ID',
            },
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리자',
            },
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '처리일시',
            },
        },
    ],
}

export const commCodeDtlHeader = {
    fields: [
        {
            fieldName: 'commCdId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'commCdVal',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'commCdValNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'commCdValDesc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prtSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effStaDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'effEndDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'subCommCdId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'rgstClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'delYn',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'commCdId',
            fieldName: 'commCdId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 구분코드ID',
            },
        },
        {
            name: 'commCdVal',
            fieldName: 'commCdVal',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 코드ID',
            },
        },
        {
            name: 'commCdValNm',
            fieldName: 'commCdValNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 코드명',
            },
        },
        {
            name: 'commCdValDesc',
            fieldName: 'commCdValDesc',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '코드설명',
            },
        },
        {
            name: 'prtSeq',
            fieldName: 'prtSeq',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 출력순서',
            },
        },
        {
            name: 'effStaDt',
            fieldName: 'effStaDt',
            header: {
                text: '* 유효시작일',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
                datetimeFormat: 'yyyy-MM-dd',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'effEndDt',
            fieldName: 'effEndDt',
            header: {
                text: '* 유효종료일',
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                type: 'date',
                textReadOnly: false,
                mask: {
                    editMask: '9999-99-99',
                    includedFormat: true,
                },
                datetimeFormat: 'yyyy-MM-dd',
            },
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'subCommCdId',
            fieldName: 'subCommCdId',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            button: 'action',
            buttonVisibility: 'always',
            header: {
                text: '하위공통코드ID',
            },
        },
        {
            name: 'rgstClCd',
            fieldName: 'rgstClCd',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '* 등록구분코드ID',
            },
        },
        {
            name: 'rgstClNm',
            fieldName: 'rgstClNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '등록구분코드',
            },
        },
        {
            name: 'delYn',
            fieldName: 'delYn',
            sortable: true,
            editor: {
                type: 'dropdown',
                dropDownCount: 10,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '삭제여부',
            },
        },
    ],
}
