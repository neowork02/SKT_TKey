<template>
    <TCComDialog :dialogShow.sync="activeOpen" :size="reportWidth">
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">Report Preview</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <ul class="btn_area top pop">
                        <li class="left"></li>
                        <li class="right">
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="reportPrint"
                            >
                                인쇄
                            </TCComButton>
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="reportZoomIn"
                            >
                                화면확대
                            </TCComButton>
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="reportZoomOut"
                            >
                                화면축소
                            </TCComButton>
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="reportZoomOriginal"
                            >
                                화면원본
                            </TCComButton>
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="exportImage"
                            >
                                이미지
                            </TCComButton>
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="exportDocument('hwp')"
                            >
                                Hwp
                            </TCComButton>
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="exportDocument('docx')"
                            >
                                Word
                            </TCComButton>
                            <TCComButton
                                eClass="btn_ty01"
                                :objAuth="objAuth"
                                @click="exportPdf"
                            >
                                PDF
                            </TCComButton>
                        </li>
                    </ul>
                    <!-- realreportWrap -->
                    <div class="realreportWrap">
                        <div class="scroller">
                            <div ref="realreport" id="realreport"></div>
                        </div>
                    </div>
                    <!-- //realreportWrap -->
                    <!-- Close BTN-->
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="onClose()"
                    >
                        닫기
                    </a>
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>
<script>
import { ReportViewer, ReportCompositeViewer } from 'realreport'
import 'realreport/dist/realreport.css'
import { CommonUtil } from '@/utils'
import _ from 'lodash'
export default {
    name: 'ReportPopup',
    components: {},
    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        //Dialog Width
        dialogWidth: { type: String, default: '', required: false },
    },
    data() {
        return {
            objAuth: {},
            viewer: null,
            reportContainer: null,
            windowPreview: null,
        }
    },
    mounted() {
        this.$nextTick(function () {
            this.reportContainer = this.$refs.realreport
            if (_.isArray(this.parentParam.formSets)) {
                this.viewer = new ReportCompositeViewer(
                    this.reportContainer,
                    this.parentParam.formSets
                )
            } else {
                this.viewer = new ReportViewer(this.reportContainer)
                this.viewer.reportForm = this.parentParam.report
                this.viewer.dataSet = this.parentParam.data
            }
            this.viewer.preview()
        })
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
        reportWidth() {
            return this.dialogWidth ? this.dialogWidth : '875px'
        },
    },
    watch: {},
    methods: {
        //dialog Close
        onClose() {
            this.activeOpen = false
        },
        //화면확대
        reportZoomIn() {
            if (this.viewer) this.viewer.zoomIn()
        },
        //화면축소
        reportZoomOut() {
            if (this.viewer) this.viewer.zoomOut()
        },
        //화면원본
        reportZoomOriginal() {
            if (this.viewer) this.viewer.zoom = 1
        },
        //인쇄 기능
        reportPrint() {
            if (this.viewer) {
                const html = document.querySelector('html')
                const printContents = this.viewer.getHtml()
                const printDiv = document.createElement('DIV')
                printDiv.className = 'print-div'

                html.appendChild(printDiv)
                printDiv.innerHTML = printContents
                document.body.style.display = 'none'
                window.print()
                document.body.style.display = 'block'
                printDiv.style.display = 'none'
            }
        },

        //이미지보기
        exportImage() {
            if (this.viewer) {
                this.viewer.exportImage({
                    type: 'png',
                    fileName: this.parentParam.name
                        ? this.parentParam.name
                        : '',
                })
            }
        },
        //문서보기(HWP, Word)
        exportDocument(type) {
            if (this.viewer) {
                this.viewer.exportDocument({
                    type: type,
                    fileName: this.parentParam.name
                        ? this.parentParam.name
                        : '',
                })
            }
        },

        //PDF보기
        exportPdf() {
            if (this.viewer) {
                CommonUtil.base64convert(
                    '/ext-js/pdffonts/malgun.ttf',
                    true
                ).then((regualrFont) => {
                    CommonUtil.base64convert(
                        '/ext-js/pdffonts/malgunbd.ttf',
                        true
                    ).then((boldFont) => {
                        if (regualrFont && boldFont) {
                            const fonts = [
                                {
                                    name: 'regular',
                                    content: regualrFont,
                                    style: 'normal',
                                    weight: 'normal',
                                },
                                {
                                    name: 'bold',
                                    content: boldFont,
                                    style: 'normal',
                                    weight: 'bold',
                                },
                            ]
                            if (this.viewer) {
                                this.viewer.exportPdf(fonts)
                            }
                        }
                    })
                })
            }
        },

        //=============================================================
        //해당 함수 기능 사용하지않음
        //=============================================================
        // fitToHeight() {
        //     this.viewer.fitToHeight()
        // },
        // fitToPage() {
        //     this.viewer.fitToPage()
        // },
        // fitToWidth() {
        //     this.viewer.fitToWidth()
        // },
        //=============================================================
    },
}
</script>
