<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동요청
 * 서브업무명: 재고이동요청현황 상세
 * 설명: 재고이동요청현황 상세를 조회한다.
 * 작성자: P179229
 * 작성일: 2022.07.11
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="800px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">재고이동요청 {{ procNm }}</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <div class="stitHead">
                        <h4 class="subTit">재고이동요청 {{ procNm }}</h4>
                    </div>
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.reqDealcoNm"
                                    :readonly="true"
                                    labelName="입고처"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="crdtLimit"
                                    :readonly="true"
                                    labelName="여신잔액"
                                    :objAuth="objAuth"
                                >
                                </TCComInput>
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.prodCd"
                                    labelName="상품코드"
                                    :readonly="true"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.prodNm"
                                    labelName="상품명"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.colorNm"
                                    labelName="색상"
                                    :readonly="true"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.unitPrc"
                                    labelName="단가"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.mfactNm"
                                    labelName="제조사"
                                    :readonly="true"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.petNm"
                                    labelName="펫네임"
                                    :readonly="true"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    codeId="ZDIS_C_00662"
                                    labelName="개봉상태"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.reqClCd"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComRadioBox
                                    :itemList="chkData"
                                    labelName="대표모델"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.repProdYn"
                                />
                            </div>
                            <div class="formitem div1">
                                <TCComRadioBox
                                    :itemList="chkData"
                                    labelName="색상무관"
                                    :readonly="true"
                                    :objAuth="objAuth"
                                    v-model="reqParam.colorUnrelYn"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.qckSvcCoNm"
                                    labelName="퀵서비스 업체명"
                                    :readonly="true"
                                />
                            </div>
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.qckSvcTelNo"
                                    :readonly="true"
                                    labelName="퀵서비스 연락처"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div2">
                                <TCComInput
                                    v-model="reqParam.reqQty"
                                    :readonly="true"
                                    inputRuleType="N"
                                    labelName="요청수량"
                                />
                            </div>
                        </div>
                        <div class="searchform">
                            <div class="formitem div1">
                                <TCComTextArea
                                    v-model="reqParam.reqFixDesc"
                                    :readonly="procCd === 'view'"
                                    labelName="비고"
                                    :rows="5"
                                />
                            </div>
                        </div>
                    </div>
                    <!-- // Search_div -->

                    <!-- btn -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            v-if="procCd !== 'view'"
                            @click="saveBtn()"
                        >
                            {{ procNm }}
                        </TCComButton>
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty01"
                            @click="closeBtn"
                            :objAuth="objAuth"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="closeBtn()"
                        >닫기</a
                    >
                    <!--// btn -->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import disDtrDisMovReqInApi from '@/api/biz/dis/dtr/disDtrMovReqIn'
import iioApi from '@/api/biz/dis/iio/disIioSaleOutMgmtDtl'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'DisDtrDisMovReqInDtlPopup',
    mixins: [CommonMixin],
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            objAuth: {},
            crdtLimit: 0, // 여신잔액
            reqParam: this.dtlData,
            procCd: '',
            procNm: '',
            chkData: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
        }
    },
    created() {},
    mounted() {
        this.procCd = this.reqParam.procCd
        this.procNm = this.reqParam.procNm
        //요청정보 조회
        this.getDisMovReqPrstDtl()
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        closeBtn: function () {
            this.activeOpen = false
        },
        //요청상세조회
        getDisMovReqPrstDtl() {
            disDtrDisMovReqInApi
                .getDisDtrDisMovReqInDtl(this.reqParam)
                .then((res) => {
                    //Get Row Data
                    this.reqParam = Object.assign(
                        {},
                        res.disDtrDisMovReqInDtlVo
                    )
                    //여신잔액 조회
                    this.getCrdtLimit()
                })
        },
        //저장
        saveBtn() {
            if (!this.isValidChk()) {
                return false
            }
            this.showTcComConfirm(this.procNm + '하시겠습니까?').then(
                (confirm) => {
                    if (confirm) {
                        if (this.procCd === 'approval') {
                            this.reqParam.reqStCd = '02'
                        } else if (this.procCd === 'reject') {
                            this.reqParam.reqStCd = '03'
                        }
                        disDtrDisMovReqInApi
                            .saveDisDtrDisMovReqInDtl(this.reqParam)
                            .then((res) => {
                                if (res === 1) {
                                    this.procCd = 'view'
                                    this.procNm = '상세'
                                    this.getDisMovReqPrstDtl()
                                    this.$parent.searchBtn()
                                }
                            })
                    }
                }
            )
        },
        isValidChk() {
            if (this.procCd === 'approval') {
                if (
                    this.reqParam.unitPrc * this.reqParam.reqQty >
                    this.crdtLimit
                ) {
                    this.showTcComAlert('여신금액을 초과할수 없습니다.')
                    return false
                }
            }
            return true
        },
        // 여신잔액 조회
        getCrdtLimit() {
            const param = {}
            if (!_.isEmpty(this.reqParam.reqDealcoCd)) {
                param.dealCoCd = this.reqParam.reqDealcoCd

                iioApi.getCrdtLimit(param).then((res) => {
                    this.crdtLimit = res.result.crdtLimit
                })
            }
        },
    },
}
</script>
