<template>
    <div class="content">
        <!-- Tit -->
        <h1>Swing대리점거래처매핑관리</h1>
        <!-- Top BTN -->
        <ul class="btn_area top">
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSave"
                    :objAuth="this.objAuth"
                >
                    저장
                </TCComButton>
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchAuthOrgTreeParam.orgNm"
                        :codeVal.sync="searchAuthOrgTreeParam.orgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :eRequired="true"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="searchAuthOrgTreeParam"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="orgAgencyParam.agencyNm"
                        :codeVal.sync="orgAgencyParam.agencyCd"
                        labelName="대리점"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onOrgAgencyEnterKey"
                        @appendIconClick="onOrgAgencyIconClick"
                        @input="onOrgAgencyInput"
                    />
                    <BasBcoOrgAgencysPopup
                        v-if="showBcoOrgAgencys"
                        :parentParam="orgAgencyParam"
                        :rows="resultOrgAgencyRows"
                        :dialogShow.sync="showBcoOrgAgencys"
                        @confirm="onOrgAgencyReturnData"
                    />
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="매핑정보"
                :gridObj="gridObj"
                :isAddRow="true"
                :isDelRow="true"
                @addRowBtn="btn_add_OnClick"
                @chkDelRowBtn="btn_del_OnClick"
            />
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
                :isGridReSize="true"
            />
            <BasBcoDealcosPopup
                v-if="showBasBcoDealcos"
                :parentParam="searchForm"
                :rows="resultDealcoRows"
                :dialogShow.sync="showBasBcoDealcos"
                @confirm="onDealcoReturnData"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDealList"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
// import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
import _ from 'lodash'
import { HEADER } from '@/const/grid/bas/prm/basPrmSwingAgnDealcoMappMgmtHeader'
import API from '@/api/biz/bas/prm/basPrmSwingAgnDealcoMappMgmt'
//====================조직별대리점팝업======================================================
import BasBcoOrgAgencysPopup from '@/components/common/BasBcoOrgAgencysPopup'
import basBcoOrgAgencysApi from '@/api/biz/bas/bco/basBcoOrgAgencys'
//====================내부조직팝업(권한)팝업================================================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================내부거래처(권한조직)==================================================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//=========================================================================================
import CommonMixin from '@/mixins'

export default {
    name: 'BasPrmSwingAgnDealcoMappMgmt',
    components: {
        BasBcoOrgAgencysPopup,
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            rowCnt: 30,
            objAuth: {},
            div_search: {
                edt_dealCoCd: '',
                edt_deptCd: '',
                edt_deptNm: '',
                rdo_condition: '0',
            },
            biIdList: [],
            deptCdList: [],
            dutyCdList: [],
            rpstyCdList: [],
            selectedJsonData: {},
            // 구분 코드 하드 코딩 (as-is와 같음)
            dealcoClCd1List: [
                { value: '1', label: '조직' },
                { value: '2', label: '거래처' },
            ],

            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchAuthOrgTreeParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                orgLvl: '',
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //================================================================
            showBcoOrgAgencys: false,
            orgAgencyParam: {
                agencyCd: '',
                agencyNm: '',
            },
            resultOrgAgencyRows: [],
            //====================내부거래처(권한조직)==========================
            showBasBcoDealcos: false,
            searchForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한조직)========================
            getData: '',
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정

        this.init()
        // this.dropDownSetting()
        console.log('dealcoClCd1List', this.dealcoClCd1List)
        this.gridObj.gridView.onCellEdited = (
            grid,
            itemIndex,
            dataRow,
            field
        ) => {
            // var column = grid.columnByField('accDealcoNm')
            this.gridObj.gridView.commit()
            this.getData = grid.getValue(itemIndex, field)
            // console.log('biIdList', this.wdrlDtList)
            console.log('dataRow', dataRow)
            console.log('field', field)
            if (field == 8) {
                this.dealcoClCd1List.map((dealcoClCd1) => {
                    if (dealcoClCd1.value == this.getData) {
                        grid.setValue(
                            itemIndex,
                            'dealcoClCd1',
                            dealcoClCd1.label
                        )
                        return
                    }
                })
            }
            this.selectedJsonData =
                this.gridObj.dataProvider.getJsonRow(dataRow)
            console.log('selectedJsonData', this.selectedJsonData)
        }

        // 그리드내의 부여조직 돋보기 클릭시 이벤트처리
        this.gridObj.gridView.onCellButtonClicked = (
            grid,
            itemIndex,
            column
        ) => {
            console.log('grid', grid)
            console.log('itemIndex', itemIndex)
            this.gridObj.gridView.commit()

            if (column.fieldName === 'dealcoCd') {
                console.log('getData', this.getData)
                if (this.getData == '1') {
                    this.onAuthOrgTreeIconClick()
                } else if (this.getData == '2') {
                    this.onDealcoIconClick()
                }
            }
        }

        // 조직코드 조회
        this.searchAuthOrgTreeParam.orgCd = this.orgInfo.orgCd
        this.searchAuthOrgTreeParam.orgNm = this.orgInfo.orgNm
        this.searchAuthOrgTreeParam.orgLvl = this.orgInfo.orgLvl
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.gridSetData()
            this.gridObj.setGridState()
            this.gridObj.gridView.setRowIndicator({ visible: true })
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchAuthOrgTreeParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    let cnt = 0

                    res.map((p) => {
                        if (p.orgLvl == '3') {
                            cnt++
                        }
                    })

                    if (cnt === 1) {
                        res.map((p) => {
                            this.searchAuthOrgTreeParam.orgCd = _.get(
                                p,
                                'orgCd'
                            )
                            this.searchAuthOrgTreeParam.orgNm = _.get(
                                p,
                                'orgNm'
                            )
                            this.searchAuthOrgTreeParam.orgLvl = _.get(
                                p,
                                'orgLvl'
                            )
                        })
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchAuthOrgTreeParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchAuthOrgTreeParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchAuthOrgTreeParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            let current = this.gridObj.gridView.getCurrent()
            console.log('current', current)
            this.searchAuthOrgTreeParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchAuthOrgTreeParam.orgNm = _.get(retrunData, 'orgNm')
            this.searchAuthOrgTreeParam.orgLvl = _.get(retrunData, 'orgLvl')
            let orgCdLvl1 = _.get(retrunData, 'orgCdLvl1')
            let orgCdLvl2 = _.get(retrunData, 'orgCdLvl2')
            let orgCdLvl3 = _.get(retrunData, 'orgCdLvl3')
            let orgNmLvl1 = _.get(retrunData, 'orgNmLvl1')
            let orgNmLvl2 = _.get(retrunData, 'orgNmLvl2')
            let orgNmLvl3 = _.get(retrunData, 'orgNmLvl3')
            console.log('orgNmLvl1', orgNmLvl1)
            console.log('orgNmLvl2', orgNmLvl2)
            console.log('orgNmLvl3', orgNmLvl3)
            // 그리드 거래처 SET
            this.gridObj.gridView.setValue(
                current.dataRow,
                'dealcoCd',
                this.searchAuthOrgTreeParam.orgCd
            )
            // 그리드 거래처명 SET
            this.gridObj.gridView.setValue(
                current.dataRow,
                'dealcoNm',
                this.searchAuthOrgTreeParam.orgNm
            )
            // 그리드 사업담당 SET
            this.gridObj.gridView.setValue(
                current.dataRow,
                'bizChrgOrgCd',
                orgCdLvl1
            )
            // 그리드 사업담당명 SET
            this.gridObj.gridView.setValue(
                current.dataRow,
                'bizChrgOrgNm',
                orgNmLvl1
            )
            // 그리드 팀 SET
            this.gridObj.gridView.setValue(
                current.dataRow,
                'teamOrgCd',
                orgCdLvl2
            )
            // 그리드 팀명 SET
            this.gridObj.gridView.setValue(
                current.dataRow,
                'teamOrgNm',
                orgNmLvl2
            )
            // 그리드 파트 SET
            this.gridObj.gridView.setValue(
                current.dataRow,
                'ptOrgCd',
                orgCdLvl3
            )
            // 그리드 파트명 SET
            this.gridObj.gridView.setValue(
                current.dataRow,
                'ptOrgNm',
                orgNmLvl3
            )
        },
        //===================== //조직별 대리점팝업관련 methods ================================

        /* 조직별 대리점팝업 */
        getOrgAgencyList() {
            basBcoOrgAgencysApi.getOrgAgencyList(this.reqParam).then((res) => {
                console.log('getOrgAgencyList then : ', res)
                if (res.length === 1) {
                    this.orgAgencyParam.agencyCd = _.get(res[0], 'agencyCd')
                    this.orgAgencyParam.agencyNm = _.get(res[0], 'agencyNm')
                } else {
                    this.resultOrgAgencyRows = res
                    this.showBcoOrgAgencys = true
                }
            })
        },
        /* 조직별 대리점팝업 - 돋보기 Icon 이벤트 */
        onOrgAgencyIconClick() {
            this.resultOrgAgencyRows = []
            if (!_.isEmpty(this.orgAgencyParam.agencyNm)) {
                this.getAllotBondDtls()
            } else {
                this.showBcoOrgAgencys = true
            }
        },
        /* 조직별 대리점팝업 - 엔터키 이벤트 */
        onOrgAgencyEnterKey() {
            this.resultOrgAgencyRows = []
            if (_.isEmpty(this.orgAgencyParam.agencyNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '대리점명을 입력해주세요.'
                return
            }
            this.getOrgAgencyList()
        },
        /* 조직별 대리점팝업 - Input 이벤트 */
        onOrgAgencyInput() {
            this.reqParam.agencyCd = ''
        },
        /* 조직별 대리점팝업 - 리턴 이벤트 */
        onOrgAgencyReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.orgAgencyParam.agencyCd = _.get(retrunData, 'agencyCd')
            this.orgAgencyParam.agencyNm = _.get(retrunData, 'agencyNm')
        },
        // ====================================================================
        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.searchForm.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.searchForm.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.searchForm.dealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchForm.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-전체조직명 입력해주세요.'
                return
            }
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.searchForm.dealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        // onDealcoReturnData(retrunData) {
        //     console.log('retrunData: ', retrunData)
        //     this.searchForm.dealcoCd = _.get(retrunData, 'dealcoCd')
        //     this.searchForm.dealcoNm = _.get(retrunData, 'dealcoNm')
        // },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(returnData) {
            console.log('returnData: ', returnData)

            let current = this.gridObj.gridView.getCurrent()
            console.log('current', current)
            let dealcoCd = _.get(returnData, 'dealcoCd')
            let dealcoNm = _.get(returnData, 'dealcoNm')
            // 그리드 거래처 SET
            this.gridObj.gridView.setValue(
                current.dataRow,
                'dealcoCd',
                dealcoCd
            )
            // 그리드 거래처명 SET
            this.gridObj.gridView.setValue(
                current.dataRow,
                'dealcoNm',
                dealcoNm
            )
            // 그리드 사업담당 SET
            this.gridObj.gridView.setValue(current.dataRow, '', dealcoNm)
            // 그리드 팀 SET
            this.gridObj.gridView.setValue(current.dataRow, '', dealcoNm)
            // 그리드 파트 SET
            this.gridObj.gridView.setValue(current.dataRow, '', dealcoNm)
        },
        //===================== //내부거래처(권한조직)팝업관련 methods =====================
        //조회 버튼 이벤트
        onSearch: function () {
            this.gridData.totalPage = 0
            this.getDealList(1)
        },

        getDealList(pageNum) {
            let reqParam = {
                orglevel: this.searchAuthOrgTreeParam.orgLvl
                    ? this.searchAuthOrgTreeParam.orgLvl
                    : '',
                orgCd: this.searchAuthOrgTreeParam.orgCd
                    ? this.searchAuthOrgTreeParam.orgCd
                    : '',
                // orgCd: 'AF1420',
                dealcoCd: this.orgAgencyParam.agencyCd
                    ? this.orgAgencyParam.agencyCd
                    : '',
            }
            reqParam.pageNum = pageNum
            reqParam.pageSize = this.rowCnt
            console.log('reqParam : ', reqParam)
            API.getDealList(reqParam).then((result) => {
                console.log('resultData : ', result.gridList)
                this.ds_list = result.gridList
                this.gridObj.setRows(result.gridList)
                // 페이징 관련
                this.gridObj.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                this.gridData = this.gridSetData() //초기화
                this.gridData.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                this.gridHeaderObj.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
            })
        },

        //저장 버튼 이벤트
        onSave: function () {
            this.gridObj.gridView.commit()
            let saveParamList = []
            // let getJson = {}
            let gridCreatedIndexArr =
                this.gridObj.dataProvider.getStateRows('created')
            let gridUpdatedIndexArr =
                this.gridObj.dataProvider.getStateRows('updated')

            console.log('gridCreatedIndexArr', gridCreatedIndexArr)
            console.log('gridUpdatedIndexArr', gridUpdatedIndexArr)

            for (let idx = 0; idx < gridCreatedIndexArr.length; idx++) {
                let getJson = this.gridObj.dataProvider.getJsonRow(
                    gridCreatedIndexArr[idx]
                )
                console.log('b/f getJson', getJson)
                getJson.agencyCd = getJson.agencyCd ? getJson.agencyCd : ''
                getJson.sktSubCd = getJson.sktSubCd ? getJson.sktSubCd : ''
                getJson.dealcoCd = getJson.dealcoCd ? getJson.dealcoCd : ''
                getJson.dealcoClCd1 = getJson.dealcoClCd1
                    ? getJson.dealcoClCd1
                    : ''
                getJson.bizChrgOrgCd = getJson.bizChrgOrgCd
                    ? getJson.bizChrgOrgCd
                    : ''
                getJson.teamOrgCd = getJson.teamOrgCd ? getJson.teamOrgCd : ''
                getJson.ptOrgCd = getJson.ptOrgCd ? getJson.ptOrgCd : ''
                getJson.adjtYn = getJson.adjtYn ? getJson.adjtYn : ''
                getJson.rowState = 'created'
                console.log('a/f getJson', getJson)
                saveParamList.push(getJson)
            }

            for (let idx = 0; idx < gridUpdatedIndexArr.length; idx++) {
                let getJson = this.gridObj.dataProvider.getJsonRow(
                    gridUpdatedIndexArr[idx]
                )
                getJson.agencyCd = getJson.agencyCd ? getJson.agencyCd : ''
                getJson.sktSubCd = getJson.sktSubCd ? getJson.sktSubCd : ''
                getJson.dealcoCd = getJson.dealcoCd ? getJson.dealcoCd : ''
                getJson.dealcoClCd1 = getJson.dealcoClCd1
                    ? getJson.dealcoClCd1
                    : ''
                getJson.bizChrgOrgCd = getJson.bizChrgOrgCd
                    ? getJson.bizChrgOrgCd
                    : ''
                getJson.teamOrgCd = getJson.teamOrgCd ? getJson.teamOrgCd : ''
                getJson.ptOrgCd = getJson.ptOrgCd ? getJson.ptOrgCd : ''
                getJson.adjtYn = getJson.adjtYn ? getJson.adjtYn : ''

                if (this.selectedJsonData.check == true) {
                    getJson.rowState = 'deleted'
                } else {
                    getJson.rowState = 'updated'
                }
                console.log('getJson', getJson)
                saveParamList.push(getJson)
            }

            API.saveDealList(saveParamList).then((result) => {
                console.log('result : ', result)
                if (result == 1) {
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    // 매핑정보 재조회
                    this.onSearch()
                } else {
                    this.showTcComAlert(result.message)
                }
            })
        },

        // 초기화
        onResetPage() {
            // CommonUtil.clearPage(this.$router)
            this.div_search = {
                edt_dealCoCd: '',
                edt_deptCd: '',
                edt_deptNm: '',
                rdo_condition: '0',
            }
            this.gridData = this.gridSetData()
            this.gridObj.dataProvider.clearRows()
        },

        // 추가근무지 목록 - 행추가
        btn_add_OnClick() {
            let rowCount = this.gridObj.dataProvider.getRowCount()
            let rowData = {
                dealcoClCd1: '--선택--',
                adjtYn: '--선택--',
                __rowState: 'created',
            }
            this.gridObj.dataProvider.insertRow(rowCount, rowData)
        },

        //추가근무지 목록 - 행삭제
        btn_del_OnClick() {
            let delIndexList = []
            let rows = this.gridObj.dataProvider.getRows()
            console.log('rows : ', rows)
            // checkbox에 체크(1)된 행들의 인덱스를 리스트에 담기
            for (let i = 0; i < rows.length; i++) {
                if (rows[i][0] == '1') {
                    delIndexList.push(i)
                }
            }
            console.log('delIndexList : ', delIndexList)
            // 인덱스 리스트를 이용해 로우 하나씩 삭제하는 메서드
            this.delRow(delIndexList)
        },

        delRow(delIndexList) {
            // 삭제할 행이 없을 경우에 바로 리턴
            if (delIndexList == undefined) {
                console.log('delIndexList is null...')
                return
            }
            // list에서 pop하며 하나씩 로우 삭제
            let list = delIndexList
            const index = list.pop()
            let getJson = this.gridObj.dataProvider.getJsonRow(index)
            console.log('getJson :', getJson)
            // 유효성검사 - 새로 생섣된 로우는 __rowState가 'created'
            if (getJson.__rowState == undefined) {
                this.showTcComAlert('추가된 Row에 한해서만 삭제 가능합니다')
                return
            } else {
                this.gridObj.dataProvider.removeRow(index)
                console.log('removed index : ', index)
            }
            // 인덱스리스트가 다 비워질 때까지 재귀호출
            if (delIndexList.length > 0) {
                this.delRow(list)
            } else {
                console.log('delete complete')
            }
        },

        // 그리드에 그룹명 dropdown셋팅 공통코드 api
        async dropDownSetting() {
            console.log('dropDownSetting')
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00250',
                columnName: 'wdrlDt',
                option: '--선택--',
            })
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00730',
                columnName: 'biId',
                option: '--선택--',
            })
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00740',
                columnName: 'deptCd',
                option: '--선택--',
            })
            await this.dropDownCmmonCodes({
                key: '',
                columnName: 'rpstyCd',
                option: '--선택--',
            })
        },

        async dropDownCmmonCodes({ key, columnName, option }) {
            console.log('key columnName option', key, columnName, option)
            let result = await API.dropDownCmmonCodes_(key)
            console.log('result', result)
            if (columnName == 'wdrlDt') {
                this.wdrlDtList = result
            }
            if (columnName == 'deptCd') {
                this.deptCdList = result
            }
            if (columnName == 'dutyCdList') {
                this.dutyCdList = result
            }
            if (columnName == 'rpstyCdList') {
                this.rpstyCdList = result
            }
            let values = []
            let labels = []
            values = result.map((a) => a.commCdVal)
            console.log('values', values)
            labels = result.map((a) => a.commCdValNm)
            console.log('labels', labels)
            if (option != undefined) {
                values.unshift('')
                labels.unshift(option)
            }
            if (columnName == 'userGrpNm') {
                let col1 = this.gridObj.gridView.columnByName(columnName)
                console.log('col1', col1)
                console.log('getColumn', col1)
                col1.values = values
                col1.labels = labels
                this.gridObj.gridView.setColumn(col1)
            }
        },
    },
}
</script>
