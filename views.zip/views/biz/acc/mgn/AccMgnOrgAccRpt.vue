<template>
    <div class="content">
        <h1>조직별 정산Report</h1>
        <ul class="btn_area top">
            <li class="left"></li>
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="screenInit"
                    :objAuth="objAuth"
                    >초기화</TCComButton
                >
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="loadData"
                    :objAuth="objAuth"
                    >조회</TCComButton
                >
            </li>
        </ul>

        <!-- Search_div -->
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        v-model="searchFormData.searchAccYm"
                        :eRequired="true"
                    >
                    </TCComDatePicker>
                </div>
                <div class="formitem div4">
                    <TCComInputSearchText
                        v-model="searchFormData.searchOrgNm"
                        :codeVal.sync="searchFormData.searchOrgCd"
                        labelName="조직"
                        placeholder="입력해주세요"
                        :disabled="false"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        :eRequired="true"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="orgParams"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div4"></div>
                <div class="formitem div4"></div>
            </div>
        </div>
        <!-- //Search_div -->

        <!-- Excel Download -->
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader1"
                ref="gridHeader1"
                gridTitle="조직별정산Report List"
                :gridObj="this.gridObj"
                :isExceldown="true"
                @excelDownBtn="this.excelDown"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :editable="false"
                :styles="gridStyle"
                :fields="view.fields"
                :columns="view.columns"
            />
        </div>
        <!-- Excel Download -->
    </div>
</template>

<script>
import mgnApi from '@/api/biz/acc/mgn'
import moment from 'moment'
import _ from 'lodash'
import { GRID_HEADER } from '@/const/grid/acc/mgn/accMgnOrgAccRptGrid'
import { CommonUtil } from '@/utils'
import CommonMixin from '@/mixins'

//  내부조직팝업(권한)
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//  내부조직팝업(권한)

export default {
    name: 'Home',
    components: {
        //  내부조직팝업(권한)
        BasBcoAuthOrgTreesPopup,
    },
    mixins: [CommonMixin],
    data() {
        return {
            //----- Excel Download
            gridObj: {},
            gridHeaderObj: {},
            //----- Excel Download

            view: GRID_HEADER,
            objAuth: {},
            list: [],
            listCount: 0,
            paramJson: {},
            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },
            searchFormData: {
                searchAccYm: moment(new Date()).format('YYYY-MM'),
                searchOrgCd: '',
                searchOrgNm: '',
                searchOrgLvl: '',
                searchLvOrgCd: '',
                searchCoClOrgCd: '',
            },

            //  내부조직팝업(권한)
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            orgParams: {},
            //  내부조직팝업(권한)
        }
    },
    watch: {
        'searchFormData.searchAccYm'(newVal) {
            var _newVal = newVal
            if (!_.isEmpty(newVal)) {
                _newVal = newVal.replace(/-/g, '')
            }

            this.orgParams.basMth = _newVal
        },
    },
    mounted() {
        //  그리드 초기화
        this.gridInit()

        //그리드 Header Layout 세팅하기
        this.$refs.grid1.gridView.setColumnLayout(this.view.layout)

        //목록출력하기
        this.$refs.grid1.setRows(this.list)

        this.searchFormData.searchCoClOrgCd = this.orgInfo.orgCdLvl0

        this.$refs.grid1.gridView.setFixedOptions({ colCount: 1 })
    },
    methods: {
        // 그리드 초기화
        gridInit: function () {
            this.gridObj = this.$refs.grid1
            this.gridHeaderObj = this.$refs.gridHeader1

            //  setGridState(indicator,statbar,checkbar,footer)
            this.gridObj.setGridState(true)
        },
        // 화면초기화
        screenInit: function () {
            // CommonUtil.clearPage(this.$router)
            CommonUtil.clearPage(this, 'searchFormData', this.gridObj)
        },
        setParamJson: function () {
            this.paramJson = _.cloneDeep(this.searchFormData)
            this.paramJson.searchAccYm = this.paramJson.searchAccYm.replace(
                /-/g,
                ''
            )

            return this.paramJson
        },
        loadData: function () {
            if (_.isEmpty(this.searchFormData.searchAccYm)) {
                this.showTcComAlert('정산월을 입력하십시오.')
                return
            }
            if (_.isEmpty(this.searchFormData.searchOrgCd)) {
                this.showTcComAlert('조직을 입력하십시오.')
                return
            }

            mgnApi
                .getAccMgnOrgAccRptList(this.setParamJson())
                .then((resultData) => {
                    this.list = resultData
                    this.$refs.grid1.setRows(this.list)
                })
        },
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            this.orgParams.orgCd = this.searchFormData.searchOrgCd
            this.orgParams.orgNm = this.searchFormData.searchOrgNm
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.orgParams)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 1) {
                        this.searchFormData.searchOrgCd = _.get(res[0], 'orgCd')
                        this.searchFormData.searchOrgNm = _.get(res[0], 'orgNm')
                        this.searchFormData.searchOrgLvl = _.get(
                            res[0],
                            'vLevel'
                        )
                        this.searchFormData.searchLvOrgCd = _.get(
                            res[0],
                            'orgCdLvl0'
                        )
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchFormData.searchOrgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []

            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchFormData.searchOrgNm)) {
                this.showTcComAlert('조직명을 입력해주세요.')
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchFormData.searchOrgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(returnData) {
            console.log('returnData: ', returnData)
            this.searchFormData.searchOrgCd = _.get(returnData, 'orgCd')
            this.searchFormData.searchOrgNm = _.get(returnData, 'orgNm')
            this.searchFormData.searchOrgLvl = _.get(returnData, 'orgLvl')
            this.searchFormData.searchLvOrgCd = _.get(returnData, 'orgCdLvl0')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================

        // Excecl Download
        excelDown: function () {
            mgnApi.downloadOrgAccRptExcel(this.searchFormData).then((rs) => {
                this.gridSetData(rs)
            })
        },
        // Excecl Download
    },
}
</script>

<style scoped>
.grid {
    height: 550px;
}
</style>
