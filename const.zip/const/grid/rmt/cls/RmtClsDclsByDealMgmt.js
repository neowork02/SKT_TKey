import { ValueType } from 'realgrid'

export const GRID_REQ_TAB = {
    fields: [
        { fieldName: 'dealcoCd', dateType: ValueType.TEXT },
        { fieldName: 'sktChnlCd', dateType: ValueType.TEXT },
        { fieldName: 'dealcoNm', dateType: ValueType.TEXT },
        { fieldName: 'clsDt', dateType: ValueType.TEXT },
        { fieldName: 'clsStCd', dateType: ValueType.TEXT },
        { fieldName: 'clsSt', dateType: ValueType.TEXT },
        { fieldName: 'reqUserNm', dateType: ValueType.TEXT },
        { fieldName: 'reqDtm', dateType: ValueType.TEXT },
        { fieldName: 'reqRmks', dateType: ValueType.TEXT },
        { fieldName: 'aprvUserNm', dateType: ValueType.TEXT },
        { fieldName: 'aprvDtm', dateType: ValueType.TEXT },
        { fieldName: 'aprvRmks', dateType: ValueType.TEXT },
        { fieldName: 'curCashBalAmt', dateType: ValueType.TEXT },
        { fieldName: 'curDeviceQty', dateType: ValueType.TEXT },
        { fieldName: 'curUsimQty', dateType: ValueType.TEXT },
        { fieldName: 'curSmartQty', dateType: ValueType.TEXT },
        { fieldName: 'limitTimeGap', dateType: ValueType.TEXT },
        { fieldName: 'cashPlusCnt', dateType: ValueType.TEXT },
        { fieldName: 'cashPlusAmt', dateType: ValueType.TEXT },
        { fieldName: 'cashMinusCnt', dateType: ValueType.TEXT },
        { fieldName: 'cashMinusAmt', dateType: ValueType.TEXT },
        { fieldName: 'dealCoCl', dateType: ValueType.TEXT },
        { fieldName: 'dealCoClNm', dateType: ValueType.TEXT },
        { fieldName: 'searchDtm', dateType: ValueType.TEXT },
    ],
    columns: [
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '60',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            width: '60',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            visible: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '60',
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            visible: false,
        },
        {
            name: 'clsDt',
            fieldName: 'clsDt',
            type: 'data',
            width: '60',
            header: {
                text: '마감일자',
                showTooltip: false,
            },
            styleName: 'center-column',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
            editable: false,
        },
        {
            name: 'clsStCd',
            fieldName: 'clsStCd',
            type: 'data',
            width: '60',
            header: {
                text: '상태코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'clsSt',
            fieldName: 'clsSt',
            type: 'data',
            width: '60',
            header: {
                text: '처리상태',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'reqUserNm',
            fieldName: 'reqUserNm',
            type: 'data',
            width: '60',
            header: {
                text: '요청자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'reqDtm',
            fieldName: 'reqDtm',
            type: 'data',
            width: '60',
            header: {
                text: '요청일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'reqRmks',
            fieldName: 'reqRmks',
            type: 'data',
            width: '60',
            header: {
                text: '요청비고',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'aprvUserNm',
            fieldName: 'aprvUserNm',
            type: 'data',
            width: '60',
            header: {
                text: '승인자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'aprvDtm',
            fieldName: 'aprvDtm',
            type: 'data',
            width: '60',
            header: {
                text: '승인일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'aprvRmks',
            fieldName: 'aprvRmks',
            type: 'data',
            width: '60',
            header: {
                text: '승인비고',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'curCashBalAmt',
            fieldName: 'curCashBalAmt',
            type: 'data',
            width: '60',
            header: {
                text: '승인요청시점현금금액',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'curDeviceQty',
            fieldName: 'curDeviceQty',
            type: 'data',
            width: '60',
            header: {
                text: '승인요청시점 단말기 수량',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'curUsimQty',
            fieldName: 'curUsimQty',
            type: 'data',
            width: '60',
            header: {
                text: '승인요청시점 USIM   수량',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'curSmartQty',
            fieldName: 'curSmartQty',
            type: 'data',
            width: '60',
            header: {
                text: '승인요청시점 SMART  수량',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'limitTimeGap',
            fieldName: 'limitTimeGap',
            type: 'data',
            width: '60',
            header: {
                text: '승인일시',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'cashPlusCnt',
            fieldName: 'cashPlusCnt',
            type: 'data',
            width: '60',
            header: {
                text: '승인요청시점 현금성매출 +건수',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'cashPlusAmt',
            fieldName: 'cashPlusAmt',
            type: 'data',
            width: '60',
            header: {
                text: '승인요청시점 현금성매출 +금액',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'cashMinusCnt',
            fieldName: 'cashMinusCnt',
            type: 'data',
            width: '60',
            header: {
                text: '승인요청시점 현금성매출 -건수',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'cashMinusAmt',
            fieldName: 'cashMinusAmt',
            type: 'data',
            width: '60',
            header: {
                text: '승인요청시점 현금성매출 -금액',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'dealCoCl',
            fieldName: 'dealCoCl',
            type: 'data',
            width: '60',
            header: {
                text: '거래처구분코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealCoClNm',
            fieldName: 'dealCoClNm',
            type: 'data',
            width: '60',
            header: {
                text: '거래처구분명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'searchDtm',
            fieldName: 'searchDtm',
            type: 'data',
            width: '60',
            header: {
                text: '승인일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
    layout: [
        'clsDt',
        'clsSt',
        'reqUserNm',
        'reqDtm',
        'reqRmks',
        'aprvUserNm',
        'aprvDtm',
        'aprvRmks',
    ],
}

export const GRID_SALE_TAB = {
    fields: [
        {
            fieldName: 'opCl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opClDtl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dayTotCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dayOpCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dayYetCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dayExcCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthTotCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthOpCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthYetCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthExcCnt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'opCl',
            fieldName: 'opCl',
            type: 'data',
            width: '60',
            header: {
                text: '구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'opClDtl',
            fieldName: 'opClDtl',
            type: 'data',
            width: '60',
            header: {
                text: '항목',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dayTotCnt',
            fieldName: 'dayTotCnt',
            type: 'data',
            width: '60',
            header: {
                text: '전송',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'dayOpCnt',
            fieldName: 'dayOpCnt',
            type: 'data',
            width: '60',
            header: {
                text: '처리',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'dayYetCnt',
            fieldName: 'dayYetCnt',
            type: 'data',
            width: '60',
            header: {
                text: '미처리',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'dayExcCnt',
            fieldName: 'dayExcCnt',
            type: 'data',
            width: '60',
            header: {
                text: '제외',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthTotCnt',
            fieldName: 'mthTotCnt',
            type: 'data',
            width: '60',
            header: {
                text: '전송',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthOpCnt',
            fieldName: 'mthOpCnt',
            type: 'data',
            width: '60',
            header: {
                text: '처리',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthYetCnt',
            fieldName: 'mthYetCnt',
            type: 'data',
            width: '60',
            header: {
                text: '미처리',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthExcCnt',
            fieldName: 'mthExcCnt',
            type: 'data',
            width: '60',
            header: {
                text: '제외',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
    ],
    layout: [
        'opCl',
        'opClDtl',
        {
            name: '그룹헤더',
            direction: 'horizontal',
            items: ['dayTotCnt', 'dayOpCnt', 'dayYetCnt', 'dayExcCnt'],
            header: {
                text: '당일',
            },
        },
        {
            name: '그룹헤더',
            direction: 'horizontal',
            items: ['mthTotCnt', 'mthOpCnt', 'mthYetCnt', 'mthExcCnt'],
            header: {
                text: '당월',
            },
        },
    ],
}

export const GRID_DIS_OP_TAB = {
    fields: [
        {
            fieldName: 'opCl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'opClDtl',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dayTotCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dayOpCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'dayYetCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthTotCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthOpCnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'mthYetCnt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'opCl',
            fieldName: 'opCl',
            type: 'data',
            width: '60',
            header: {
                text: '구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'opClDtl',
            fieldName: 'opClDtl',
            type: 'data',
            width: '60',
            header: {
                text: '항목',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dayTotCnt',
            fieldName: 'dayTotCnt',
            type: 'data',
            width: '60',
            header: {
                text: '예정',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'dayOpCnt',
            fieldName: 'dayOpCnt',
            type: 'data',
            width: '60',
            header: {
                text: '확정',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'dayYetCnt',
            fieldName: 'dayYetCnt',
            type: 'data',
            width: '60',
            header: {
                text: '미확정',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthTotCnt',
            fieldName: 'mthTotCnt',
            type: 'data',
            width: '60',
            header: {
                text: '예정',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthOpCnt',
            fieldName: 'mthOpCnt',
            type: 'data',
            width: '60',
            header: {
                text: '확정',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'mthYetCnt',
            fieldName: 'mthYetCnt',
            type: 'data',
            width: '60',
            header: {
                text: '미확정',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
    ],
    layout: [
        'opCl',
        'opClDtl',
        {
            name: '그룹헤더',
            direction: 'horizontal',
            items: ['dayTotCnt', 'dayOpCnt', 'dayYetCnt'],
            header: {
                text: '당일',
            },
        },
        {
            name: '그룹헤더',
            direction: 'horizontal',
            items: ['mthTotCnt', 'mthOpCnt', 'mthYetCnt'],
            header: {
                text: '당월',
            },
        },
    ],
}

export const GRID_DIS_QTY_TAB = {
    fields: [
        {
            fieldName: 'gubun',
            dataType: ValueType.TEXT, // 구분
        },
        {
            fieldName: 'gubunNm',
            dataType: ValueType.TEXT, // 구분명
        },
        {
            fieldName: 'bfQty',
            dataType: ValueType.NUMBER, // 전일재고
        },
        {
            fieldName: 'incQty', // 증가
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'decQty', // 감소
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'curQty', // 현재고
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'gubun',
            fieldName: 'gubun',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            editable: false,
            header: {
                text: '구분',
            },
            visible: false,
        },
        {
            name: 'gubunNm',
            fieldName: 'gubunNm',
            type: 'data',
            width: '100',
            styleName: 'center-column',
            editable: false,
            header: {
                text: '구분',
            },
        },
        {
            name: 'bfQty',
            fieldName: 'bfQty',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            header: {
                text: '전일재고',
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'incQty',
            fieldName: 'incQty',
            type: 'data',
            width: '60',
            header: {
                text: '증가',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'decQty',
            fieldName: 'decQty',
            type: 'data',
            width: '60',
            header: {
                text: '감소',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
        {
            name: 'curQty',
            fieldName: 'curQty',
            type: 'data',
            width: '100',
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
            header: {
                text: '현재고',
            },
            footer: {
                text: '0',
                expression: 'sum',
                numberFormat: '#,###,###,###',
            },
        },
    ],
}

export const GRID_CASH_TAB = {
    fields: [
        {
            fieldName: 'clsDt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'stlPlc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bfBondAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toFeesAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toCashAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toEtcmAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toDpstAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toRfndAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toRcvbAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toBondAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'clsDt',
            fieldName: 'clsDt',
            type: 'data',
            width: '60',
            header: {
                text: '마감일',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'stlPlc',
            fieldName: 'stlPlc',
            type: 'data',
            width: '60',
            header: {
                text: '정산처코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'bfBondAmt',
            fieldName: 'bfBondAmt',
            type: 'data',
            width: '60',
            header: {
                text: '전일현금잔액',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'toFeesAmt',
            fieldName: 'toFeesAmt',
            type: 'data',
            width: '60',
            header: {
                text: 'SKT수납',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'toCashAmt',
            fieldName: 'toCashAmt',
            type: 'data',
            width: '60',
            header: {
                text: '현금매출',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'toEtcmAmt',
            fieldName: 'toEtcmAmt',
            type: 'data',
            width: '60',
            header: {
                text: '기타수납',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'toDpstAmt',
            fieldName: 'toDpstAmt',
            type: 'data',
            width: '60',
            header: {
                text: '본사송금',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'toRfndAmt',
            fieldName: 'toRfndAmt',
            type: 'data',
            width: '60',
            header: {
                text: '오입금환불',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'toRcvbAmt',
            fieldName: 'toRcvbAmt',
            type: 'data',
            width: '60',
            header: {
                text: '기타미수금',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'toBondAmt',
            fieldName: 'toBondAmt',
            type: 'data',
            width: '60',
            header: {
                text: '당일현금잔액',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
    ],
    layout: [
        'bfBondAmt',
        {
            name: '그룹헤더',
            direction: 'horizontal',
            items: ['toFeesAmt', 'toCashAmt', 'toEtcmAmt'],
            header: {
                text: '당일현금증가',
            },
        },
        'toDpstAmt',
        'toRfndAmt',
        'toRcvbAmt',
        'toBondAmt',
    ],
}

export const GRID_QCK_TAB = {
    fields: [
        {
            fieldName: 'toDayQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toDayAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toMthQty',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'toMthAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'toDayQty',
            fieldName: 'toDayQty',
            type: 'data',
            width: '60',
            header: {
                text: '건수',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'toDayAmt',
            fieldName: 'toDayAmt',
            type: 'data',
            width: '60',
            header: {
                text: '금액',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'toMthQty',
            fieldName: 'toMthQty',
            type: 'data',
            width: '60',
            header: {
                text: '건수',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'toMthAmt',
            fieldName: 'toMthAmt',
            type: 'data',
            width: '60',
            header: {
                text: '금액',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
    ],
    layout: [
        {
            name: '그룹헤더',
            direction: 'horizontal',
            items: ['toDayQty', 'toDayAmt'],
            header: {
                text: '당일',
            },
        },
        {
            name: '그룹헤더',
            direction: 'horizontal',
            items: ['toMthQty', 'toMthAmt'],
            header: {
                text: '당월',
            },
        },
    ],
}

export const GRID_BOND_TAB = {
    fields: [
        {
            fieldName: 'bfBondAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'incBondAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'decBondAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'todayBondAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'bfBondAmt',
            fieldName: 'bfBondAmt',
            type: 'data',
            width: '60',
            header: {
                text: '전일채권금액',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'incBondAmt',
            fieldName: 'incBondAmt',
            type: 'data',
            width: '60',
            header: {
                text: '증가',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'decBondAmt',
            fieldName: 'decBondAmt',
            type: 'data',
            width: '60',
            header: {
                text: '감소',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
        {
            name: 'todayBondAmt',
            fieldName: 'todayBondAmt',
            type: 'data',
            width: '60',
            header: {
                text: '당일채권금액',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
            numberFormat: '#,###,###,###',
        },
    ],
    layout: ['bfBondAmt', 'incBondAmt', 'decBondAmt', 'todayBondAmt'],
}
const DIS_QTY_DATAS = {
    disQtyList: [
        {
            gubun: 1,
            gubunNm: '단말기',
            bfQty: 0,
            incQty: 0,
            decQty: 0,
            curQty: 0,
        },
        {
            gubun: 2,
            gubunNm: '유심',
            bfQty: 0,
            incQty: 0,
            decQty: 0,
            curQty: 0,
        },
        {
            gubun: 3,
            gubunNm: '스마트디바이스',
            bfQty: 0,
            incQty: 0,
            decQty: 0,
            curQty: 0,
        },
    ],
}

export { DIS_QTY_DATAS }
