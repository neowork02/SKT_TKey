<!-----------------------------------------------
 * 업무그룹명: 기준정보>조직관리
 * 서브업무명: 신조직관리
 * 설명: 신조직관리 조회/입력/수정/삭제 한다.
 * 작성자: P180392
 * 작성일: 2022.05.25
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content1">
        <main-content ref="mainContent" />
    </div>
</template>

<script>
import {
    serviceComputed,
    serviceMethods,
} from '@/store/biz/bas/ogm/orgMgmt/helpers'
import MainContent from './Content/MainContent.vue'
import store from '@/store/biz/bas/ogm/orgMgmt'

export default {
    name: 'BasOgmOrgMgmt',
    created() {
        console.log('created:' + this.$options.name)
        if (this.$store.hasModule('bas.ogm.orgMgmtStore') != true) {
            this.$store.registerModule('bas.ogm.orgMgmtStore', store)
        }
    },
    beforeDestroy() {
        console.log('beforeDestroy:' + this.$options.name)
        if (this.$store.hasModule('bas.ogm.orgMgmtStore') == true) {
            this.$store.unregisterModule('bas.ogm.orgMgmtStore')
        }
    },

    components: {
        MainContent,
    },
    data() {
        return {}
    },
    computed: {
        ...serviceComputed,
    },
    methods: {
        ...serviceMethods,
    },
}
</script>

<style>
.content1 {
    display: inline-block;
    height: 800px;
    gap: 1em;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
}
</style>
