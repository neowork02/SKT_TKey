import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = {
    /*엑셀업로드 그리드용 columns*/
    columns: [
        {
            fieldName: 'fixYn',
            header: { text: '확정여부' },
            width: '80',
        },
        {
            fieldName: 'fixDt',
            header: { text: '정산일' },
            width: '100',
            dataType: ValueType.DATETIME,
            fieldDatetimeFormat: 'yyyyMMdd',
            columnDatetimeFormat: 'yyyy-MM-dd',
        },
        {
            fieldName: 'payDtm',
            header: { text: '수납일' },
            width: '100',
            dataType: ValueType.DATETIME,
            fieldDatetimeFormat: 'yyyyMMdd',
            columnDatetimeFormat: 'yyyy-MM-dd',
        },
        {
            fieldName: 'supOrgCd',
            header: { text: '영업팀코드(숨김)', excelText: '영업팀' },
            visible: false,
        },
        {
            fieldName: 'supOrgNm',
            header: { text: '영업팀' },
            width: '150',
        },
        {
            fieldName: 'orgCd',
            header: { text: '영업파트코드(숨김)', excelText: '영업파트' },
            visible: false,
        },
        {
            fieldName: 'orgNm',
            header: { text: '영업파트' },
            width: '150',
        },
        {
            fieldName: 'dealcoCd',
            header: { text: '수납처' },
            width: '80',
        },
        {
            fieldName: 'dealcoNm',
            header: { text: '수납처명' },
            width: '150',
        },
        {
            fieldName: 'dealcoClCd1',
            header: { text: '거래처구분코드(숨김)', excelText: '거래처구분' },
            width: '150',
            visible: false,
        },
        {
            fieldName: 'dealcoClNm1',
            header: { text: '거래처구분' },
            width: '150',
        },
        {
            fieldName: 'accDealcoCd',
            header: { text: '정산처' },
            width: '80',
        },
        {
            fieldName: 'accDealcoNm',
            header: { text: '정산처명' },
            width: '150',
        },
        {
            fieldName: 'saleMgmtNo',
            header: { text: '수납관리번호' },
            width: '100',
        },
        {
            fieldName: 'saleMgmtSeq',
            header: { text: '변경순번' },
            width: '70',
        },
        {
            fieldName: 'saleClCd',
            header: { text: '수납구분코드(숨김)', excelText: '수납구분' },
            width: '150',
            visible: false,
        },
        {
            fieldName: 'saleClNm',
            header: { text: '수납구분' },
            width: '150',
        },
        {
            fieldName: 'opStCd',
            header: { text: '수납상태코드(숨김)', excelText: '수납상태' },
            width: '150',
            visible: false,
        },
        {
            fieldName: 'opStNm',
            header: { text: '수납상태' },
            width: '150',
        },
        {
            fieldName: 'payMgmtNo',
            header: { text: '수납번호' },
            width: '150',
        },
        {
            fieldName: 'cardCoCd',
            header: { text: '카드사코드(숨김)', excelText: '카드사' },
            width: '150',
            visible: false,
        },
        {
            fieldName: 'cardCoNm',
            header: { text: '카드사' },
            width: '150',
        },
        {
            fieldName: 'cardAprvNo',
            header: { text: '승인번호' },
            width: '150',
        },
        {
            fieldName: 'payAmt',
            header: { text: '수납금액' },
            width: '150',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'dpstAccAmt',
            header: { text: '입금금액' },
            width: '150',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'dpstAccCmmsAmt',
            header: { text: '수수료' },
            width: '150',
            styleName: 'right-column',
            dataType: ValueType.NUMBER,
            numberFormat: '#,###,###,##0',
        },
        {
            fieldName: 'errColumn',
            header: { text: '오류컬럼(숨김)' },
            width: '400',
            visible: false,
        },
        {
            fieldName: 'errDesc',
            header: { text: '오류내용' },
            width: '400',
            styleName: 'left-column',
        },
        {
            fieldName: 'accClCd',
            header: { text: '정산구분코드' },
            width: '150',
        },
        {
            fieldName: 'accClNm',
            header: { text: '정산구분' },
            width: '150',
        },
    ],
}

const GRID_HEADER = {}

/*엑셀업로드 그리드용 columns*/
GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META.columns)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META.columns)

export { GRID_HEADER }
