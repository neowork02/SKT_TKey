import { ValueType } from 'realgrid'

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'ordYn',
            dataType: ValueType.TEXT, //배정여부
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'asgnDt',
            dataType: ValueType.TEXT, //일자
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT, //상품구분코드
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'prodChrticCd4',
            dataType: ValueType.TEXT, //상품특성코드
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'sknAsgnQty',
            dataType: ValueType.TEXT, //배정수량
        },
        {
            fieldName: 'ordAsgnQty',
            dataType: ValueType.TEXT, //실 배정수량
        },
        {
            fieldName: 'lmtQty',
            dataType: ValueType.TEXT, //상한수량
        },
    ],
    columns: [
        {
            name: 'ordYn',
            fieldName: 'ordYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정여부',
                showTooltip: false,
            },
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'asgnDt',
            fieldName: 'asgnDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일자',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
            editable: false,
        },
        // {
        //     name: 'prodChrticCd4',
        //     fieldName: 'prodChrticCd4',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '상품특성',
        //         showTooltip: false,
        //     },
        //     editable: false,
        // },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'sknAsgnQty',
            fieldName: 'sknAsgnQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정수량',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'ordAsgnQty',
            fieldName: 'ordAsgnQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '실 배정수량',
                showTooltip: false,
            },
        },
        {
            name: 'lmtQty',
            fieldName: 'lmtQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '상한수량',
                showTooltip: false,
            },
        },
    ],
}

export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'ordYn',
            dataType: ValueType.TEXT, //배정여부
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT, //대리점
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT, //대리점코드
        },
        {
            fieldName: 'hldDealcoCd',
            dataType: ValueType.TEXT, //보유처코드
        },
        {
            fieldName: 'hldDealcoNm',
            dataType: ValueType.TEXT, //보유처명
        },
        {
            fieldName: 'asgnDt',
            dataType: ValueType.TEXT, //일자
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT, //상품구분
        },
        {
            fieldName: 'prodChrticCd4',
            dataType: ValueType.TEXT, //상품특성
        },
        {
            fieldName: 'prodChrticNm4',
            dataType: ValueType.TEXT, //상품특성명
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT, //상품코드
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT, //상품
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT, //색상코드
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT, //색상
        },
        {
            fieldName: 'disQty',
            dataType: ValueType.TEXT, //재고수량
        },
        {
            fieldName: 'sknAsgnQty',
            dataType: ValueType.TEXT, //배정수량
        },
        {
            fieldName: 'ordAsgnQty',
            dataType: ValueType.TEXT, //실배정수량
        },
        {
            fieldName: 'lmtQty',
            dataType: ValueType.TEXT, //상한수량
        },
        {
            fieldName: 'reqUserId',
            dataType: ValueType.TEXT, //요청자ID
        },
        {
            fieldName: 'hldShopCd',
            dataType: ValueType.TEXT, //보유처매장코드
        },
    ],
    columns: [
        {
            name: 'ordYn',
            fieldName: 'ordYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정여부',
                showTooltip: false,
            },
            editor: {
                type: 'dropdown',
                dropDownCount: 4,
                domainOnly: true,
                textReadOnly: true,
                values: ['Y', 'N'],
                labels: ['Y', 'N'],
            },
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대리점코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'hldDealcoCd',
            fieldName: 'hldDealcoCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '보유처코드',
                showTooltip: false,
            },
            editable: false,
            visible: false,
        },
        {
            name: 'asgnDt',
            fieldName: 'asgnDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '일자',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
            editable: false,
        },
        // {
        //     name: 'prodChrticCd4',
        //     fieldName: 'prodChrticCd4',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '상품특성',
        //         showTooltip: false,
        //     },
        //     editable: false,
        // },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상코드',
                showTooltip: false,
            },
            editable: false,
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
            editable: false,
        },
        // {
        //     name: 'disQty',
        //     fieldName: 'disQty',
        //     type: 'data',
        //     styles: {
        //         textAlignment: 'center',
        //     },
        //     header: {
        //         text: '재고수량',
        //         showTooltip: false,
        //     },
        // },
        {
            name: 'sknAsgnQty',
            fieldName: 'sknAsgnQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '배정수량',
                showTooltip: false,
            },
            editable: false, // <<<<<< 테스트하려면 임시로 풀어야할듯.. 데이터가 안내려와서..
        },
        {
            name: 'ordAsgnQty',
            fieldName: 'ordAsgnQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '실 배정수량',
                showTooltip: false,
            },
        },
        {
            name: 'lmtQty',
            fieldName: 'lmtQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            editor: {
                type: 'number',
            },
            header: {
                text: '상한수량',
                showTooltip: false,
            },
        },
    ],
}
