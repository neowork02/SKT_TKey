<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1500px">
        <template #content>
            <TCComAlert
                v-model="showAlertBool"
                :headerText="headerText"
                :bodyText="alertBodyText"
            ></TCComAlert>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">사용자등록</p>
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <ul class="btn_area top">
                        <li class="left">
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="onDutypChgHstMgmtClick"
                                >근무지변경이력</TCComButton
                            >
                            <BasUsmDutypChgHstMgmtPopup
                                v-if="showUsmDutypChgHstMgmt"
                                :parentParam="basUsmOrgHstVo"
                                :rows="resultDealcoRows"
                                :dialogShow.sync="showUsmDutypChgHstMgmt"
                                @confirm="onDealcoReturnData"
                            />
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="onAuthChgHstMgmtClick"
                                >권한변경이력</TCComButton
                            >
                            <BasUsmAuthChgHstMgmtPopup
                                v-if="showUsmAuthChgHstMgmt"
                                :parentParam="basUsmUserAuthVo"
                                :rows="resultDealcoRows"
                                :dialogShow.sync="showUsmAuthChgHstMgmt"
                                @confirm="onDealcoReturnData"
                            />
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="onAddDutypHstMgmtClick"
                                >추가근무지이력</TCComButton
                            >
                            <BasUsmAddDutypHstMgmtPopup
                                v-if="showUsmAddDutypHstMgmt"
                                :parentParam="basUsmAddDealHisVo"
                                :rows="resultDealcoRows"
                                :dialogShow.sync="showUsmAddDutypHstMgmt"
                                @confirm="onDealcoReturnData"
                            />
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="onAddOrgHstMgmtClick"
                                >추가조직이력</TCComButton
                            >
                            <BasUsmAddOrgHstMgmtPopup
                                v-if="showUsmAddOrgHstMgmt"
                                :parentParam="basUsmAddOrgHisVo"
                                :rows="resultDealcoRows"
                                :dialogShow.sync="showUsmAddOrgHstMgmt"
                                @confirm="onDealcoReturnData"
                            />
                            <TCComButton
                                :eOutlined="true"
                                eClass="btn_ty"
                                :objAuth="objAuth"
                                @click="onAddGrpHstMgmtClick"
                                >추가권한그룹</TCComButton
                            >
                            <BasUsmAddGrpHstMgmtPopup
                                v-if="showUsmAddGrpHstMgmt"
                                :parentParam="basUsmAddGrpHisVo"
                                :rows="resultDealcoRows"
                                :dialogShow.sync="showUsmAddGrpHstMgmt"
                                @confirm="onDealcoReturnData"
                            />
                        </li>
                        <li class="right">
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="onResetPage"
                                :objAuth="objAuth"
                                >초기화</TCComButton
                            >
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="onSave"
                                :objAuth="objAuth"
                                >저장</TCComButton
                            >
                            <TCComButton
                                color="btn2"
                                eClass="btn_ty01"
                                @click="onClose"
                                :objAuth="objAuth"
                                >닫기</TCComButton
                            >
                        </li>
                    </ul>

                    <div class="stitHead">
                        <h4 class="subTit">기본정보</h4>
                    </div>

                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div4">
                                <!--
                                <TCComInputSearchText
                                    v-model="searchSsoIdParam.loginUserId"
                                    labelName="통합 Login ID"
                                    :objAuth="objAuth"
                                    @enterKey="onSsoIdEnterKey"
                                    @appendIconClick="onSsoIdIconClick"
                                    :disabled="disabledLoginUserId"
                                >
                                </TCComInputSearchText>
                                <BasBcoSsoIdsPopup
                                    v-if="showBcoSsoIds"
                                    :parentParam="searchSsoIdParam"
                                    :rows="resultSsoIdRows"
                                    :dialogShow.sync="showBcoSsoIds"
                                    @confirm="onSsoIdReturnData"
                                />
                                -->
                                <TCComInput
                                    v-model="searchSsoIdParam.loginUserId"
                                    labelName="통합 Login ID"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    :disabled="disabledLoginUserId"
                                />
                            </div>

                            <div class="formitem div4">
                                <div class="arrayType btnType">
                                    <div class="colinput2">
                                        <TCComInput
                                            v-model="
                                                searchSsoIdParam.edt_UserId
                                            "
                                            labelName="사용자ID"
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            :disabled="disabledEdt_UserId"
                                        />
                                    </div>
                                    <div class="colbtn">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            :objAuth="objAuth"
                                            eAttr="ico_verification"
                                            labelName="중복확인"
                                            @click="btn_dupChk_onClick"
                                            @enterKey="btn_dupChk_onClick"
                                            :disabled="disabledDupl"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div class="formitem div4">
                                <TCComInput
                                    labelName="사용자명"
                                    v-model="div_base.edt_UserNm"
                                    :appendIconShow="true"
                                    :appendIconClass="''"
                                    :codeIDView="codeIDView"
                                    :codeIDViewVal="codeIDViewVal"
                                    @onAppendIconClick="btnClick08"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComComboBox
                                    :itemList="ds_effUserYn"
                                    labelName="유효사용자여부"
                                    v-model="div_base.chk_effUserYn"
                                    @change="chk_effUserYnOnClick"
                                    :disabled="disabledEffUserYn"
                                ></TCComComboBox>
                            </div>
                            <!--
                            <div class="formitem div4_3">
                                <TCComCheckBox
                                    labelName=""
                                    v-model="div_base.chk_agreeYn"
                                    :itemList="agreeYnCheckBox"
                                    cols="6"
                                    @change="chk_agreeYnOnClick"
                                    :disabled="disabledAgreeYn"
                                ></TCComCheckBox>
                            </div>
                            -->
                            <!-- <div class="formitem div4_3">
                                <TCComCheckBox
                                    labelName=""
                                    v-model="div_base.chk_effUserYn"
                                    :itemList="effUserYnCheckBox"
                                    cols="6"
                                    @change="chk_effUserYnOnClick"
                                    :disabled="disabledEffUserYn"
                                ></TCComCheckBox>
                            </div>-->
                        </div>
                        <div class="searchform">
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="Swing 무선전화"
                                    v-model="div_PSMbase.repMblPhonNo"
                                    :appendIconShow="true"
                                    :appendIconClass="''"
                                    :codeIDView="codeIDView"
                                    :codeIDViewVal="codeIDViewVal"
                                    :disabled="true"
                                    @onAppendIconClick="btnClick08"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="사용자 무선전화"
                                    v-model="div_PSMbase.mblPhonNo"
                                    :appendIconShow="true"
                                    :appendIconClass="''"
                                    :codeIDView="codeIDView"
                                    :codeIDViewVal="codeIDViewVal"
                                    @onAppendIconClick="btnClick08"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComInput
                                    labelName="사용자 유선전화"
                                    v-model="div_PSMbase.wphonNo"
                                    :appendIconShow="true"
                                    :appendIconClass="''"
                                    :codeIDView="codeIDView"
                                    :codeIDViewVal="codeIDViewVal"
                                    @onAppendIconClick="btnClick08"
                                >
                                </TCComInput>
                            </div>
                            <div class="formitem div4">
                                <TCComComboBox
                                    :itemList="attcCatList"
                                    v-model="reqParam.cmb_attcCat"
                                    labelName="소속유형"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    @change="cmb_attcCat_OnChanged"
                                    :eRequired="true"
                                    :objAuth="objAuth"
                                    :disabled="disabledAttcCat"
                                ></TCComComboBox>
                            </div>
                        </div>
                    </div>

                    <div class="stitHead">
                        <h4 class="subTit">조직정보</h4>
                    </div>

                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComComboBox
                                    :itemList="commUserGrpList"
                                    v-model="reqParam.userGrp"
                                    labelName="권한그룹"
                                    :addBlankItem="true"
                                    blankItemText="전체"
                                    blankItemValue=""
                                    :objAuth="objAuth"
                                    :eRequired="true"
                                    :disabled="disabledUserGrp"
                                ></TCComComboBox>
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="searchAuthOrgTreeParam.orgNm"
                                    :codeVal.sync="searchAuthOrgTreeParam.orgCd"
                                    labelName="관리조직"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :objAuth="objAuth"
                                    @enterKey="onAuthOrgTreeEnterKey"
                                    @appendIconClick="onAuthOrgTreeIconClick"
                                    @input="onAuthOrgTreeInput"
                                    :eRequired="true"
                                    :disabled="disabledAuthOrg"
                                />
                                <BasBcoAuthOrgTreesPopup
                                    v-if="showBcoAuthOrgTrees"
                                    :parentParam="searchAuthOrgTreeParam"
                                    :rows="resultAuthOrgTreeRows"
                                    :dialogShow.sync="showBcoAuthOrgTrees"
                                    @confirm="onAuthOrgTreeReturnData"
                                />
                            </div>
                            <div class="formitem div3">
                                <TCComInputSearchText
                                    v-model="searchForm.dealcoNm"
                                    :codeVal.sync="searchForm.dealcoCd"
                                    labelName="근무지"
                                    placeholder="입력해주세요"
                                    :disabledAfter="true"
                                    :eRequired="false"
                                    :objAuth="objAuth"
                                    @enterKey="onDealcoEnterKey"
                                    @appendIconClick="onDealcoIconClick"
                                    @input="onDealcoInput"
                                    :disabled="disabledDealco"
                                />
                                <BasBcoDealcosPopup
                                    v-if="showBasBcoDealcos"
                                    :parentParam="searchForm"
                                    :rows="resultDealcoRows"
                                    :dialogShow.sync="showBasBcoDealcos"
                                    @confirm="onDealcoReturnData"
                                />
                            </div>
                        </div>
                    </div>

                    <!--
                    <ul class="btn_area top">                        
                        <li class="right">
                            <TCComButton
                                eClass="btn_ty01"
                                @click="onSaveAddInfo"
                                :objAuth="objAuth"
                                >추가정보저장</TCComButton
                            >
                        </li>                        
                    </ul>
                    -->
                    <div class="contBoth">
                        <div class="div3_3 cont1 left">
                            <!--
                            <BasBcoInrDealcosPopup
                                v-if="showbasBcoInrDealcos"
                                :parentParam="searchInrDealcosParam"
                                :rows="resultInrDealcosRows"
                                :dialogShow.sync="showbasBcoInrDealcos"
                                @confirm="onInrDealcosReturnData"
                            />
                            -->
                            <TCRealGridHeader
                                id="gridHeader3"
                                ref="gridHeader3"
                                gridTitle="추가권한그룹"
                                :gridObj="gridObj3"
                                :isPageRows="true"
                                :isAddRow="true"
                                addRowLabel="권한추가"
                                :isDelRow="true"
                                delRowLabel="권한삭제"
                                :isPageCnt="true"
                                @addRowBtn="btn_add_userGrp_OnClick"
                                @chkDelRowBtn="btn_del_userGrp_OnClick"
                            />
                            <TCRealGrid
                                id="grid3"
                                ref="grid3"
                                :editable="true"
                                :movable="false"
                                :columnMovable="false"
                                :fields="view3.fields"
                                :columns="view3.columns"
                                :styles="gridStyle"
                            />
                        </div>

                        <div class="div3_3 cont2 left">
                            <TCRealGridHeader
                                id="gridHeader2"
                                ref="gridHeader2"
                                gridTitle="추가관리조직"
                                :gridObj="gridObj2"
                                :isPageRows="true"
                                :isAddRow="true"
                                addRowLabel="조직추가"
                                :isDelRow="true"
                                delRowLabel="조직삭제"
                                :isPageCnt="true"
                                @addRowBtn="btn_add_org_OnClick2"
                                @chkDelRowBtn="btn_del_org_OnClick2"
                            />

                            <TCRealGrid
                                id="grid2"
                                ref="grid2"
                                :editable="true"
                                :movable="false"
                                :columnMovable="false"
                                :fields="view2.fields"
                                :columns="view2.columns"
                                :styles="gridStyle"
                            />
                            <BasBcoOrgTreesPopup
                                v-if="showBcoOrgTrees"
                                :parentParam="searchParam"
                                :rows="resultOrgTreeRows"
                                :dialogShow.sync="showBcoOrgTrees"
                                @confirm="onOrgTreeReturnData"
                            />
                        </div>

                        <div class="div3_3 cont1 right">
                            <TCRealGridHeader
                                id="gridHeader1"
                                ref="gridHeader1"
                                gridTitle="추가근무지"
                                :gridObj="gridObj1"
                                :isPageRows="true"
                                :isAddRow="true"
                                addRowLabel="근무지추가"
                                :isDelRow="true"
                                delRowLabel="근무지삭제"
                                :isPageCnt="true"
                                @addRowBtn="btn_add_org_OnClick"
                                @chkDelRowBtn="btn_del_org_OnClick"
                            >
                            </TCRealGridHeader>
                            <TCRealGrid
                                id="grid1"
                                ref="grid1"
                                :editable="true"
                                :updatable="true"
                                :movable="false"
                                :columnMovable="false"
                                :fields="view1.fields"
                                :columns="view1.columns"
                                :styles="gridStyle"
                            />
                            <BasBcoDealcosPopup
                                v-if="showbasBcoAddDealcos"
                                :parentParam="searchAddDealcosParam"
                                :rows="resultAddDealcosRows"
                                :dialogShow.sync="showbasBcoAddDealcos"
                                @confirm="onAddDealcosReturnData"
                            />
                        </div>
                    </div>

                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader4"
                            ref="gridHeader4"
                            gridTitle="Swing ID 정보"
                            :gridObj="gridObj4"
                            :isPageRows="true"
                            :isAddRow="true"
                            :isDelRow="true"
                            :isPageCnt="true"
                            @addRowBtn="btn_add_ukey_OnClick"
                            @chkDelRowBtn="btn_del_ukey_OnClick"
                        >
                        </TCRealGridHeader>
                        <TCRealGrid
                            id="grid4"
                            ref="grid4"
                            :editable="true"
                            :updatable="true"
                            :movable="false"
                            :columnMovable="false"
                            :fields="view4.fields"
                            :columns="view4.columns"
                            :styles="gridStyle"
                        />
                        <BasUsmSktCodeSrchPopup
                            v-if="showBasUsmSktCodeSrch"
                            :parentParam="sktIdParam"
                            :rows="resultSktCodeRows"
                            :dialogShow.sync="showBasUsmSktCodeSrch"
                            @confirm="onSktCodeReturnData"
                        />
                    </div>

                    <div class="stitHead" v-show="showPSM">
                        <h4 class="subTit">PS&M 추가정보</h4>
                    </div>

                    <div class="searchLayer_wrap" v-show="showPSM">
                        <div class="searchform">
                            <div class="formitem div3">
                                <TCComInput
                                    labelName="BI ID"
                                    v-model="div_PSMbase.biId"
                                    disabled
                                />
                            </div>

                            <div class="formitem div3">
                                <div class="arrayType btnType">
                                    <div class="colinput2">
                                        <TCComInput
                                            labelName="사번"
                                            v-model="div_PSMbase.edt_UserCd"
                                            :eRequired="true"
                                            @change="edt_UserCd_OnChanged"
                                            :disabled="disabledEdt_UserCd"
                                        />
                                    </div>
                                    <div class="colbtn">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            labelName="유효검사"
                                            :objAuth="objAuth"
                                            @click="btn_chkUser_OnClick"
                                            :disabled="disabledChkUserBtn"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div class="formitem div3">
                                <TCComComboBox
                                    codeId="USER_ST"
                                    v-model="div_PSMbase.cmb_userSt"
                                    labelName="사용자상태"
                                    :addBlankItem="true"
                                    blankItemText="선택"
                                    blankItemValue=""
                                    @change="cmb_userSt_OnChanged"
                                    :eRequired="true"
                                    :disabled="disabledUserSt"
                                ></TCComComboBox>
                            </div>
                            <!--
                            <div class="formitem div3">
                                <div class="multiFormEmail">
                                    <div class="coltit">
                                        <TCComLabel
                                            labelName="Email"
                                            :eRequired="false"
                                        />
                                    </div>
                                    <div class="col1">
                                        <TCComTextField
                                            class="w100"
                                            v-model="div_PSMbase.edt_Email1"
                                        />
                                    </div>
                                    <div class="col0">@</div>
                                    <div class="col2">
                                        <TCComTextField
                                            class="w100"
                                            v-model="div_PSMbase.edt_Email2"
                                            :disabled="email2Disabled"
                                        />
                                    </div>
                                    <div class="col3">
                                        <TCComComboBox
                                            class="w200"
                                            codeId="EMAIL_ACC"
                                            v-model="div_PSMbase.cmb_mailList"
                                            :addBlankItem="true"
                                            blankItemText="선택"
                                            blankItemValue=""
                                            :eRequired="true"
                                            :objAuth="objAuth"
                                            @change="cmb_mailList_OnChanged"
                                            ref="emailList"
                                        />
                                    </div>
                                </div>
                            </div>
-->
                        </div>

                        <div class="searchform">
                            <!-- <div class="formitem div5">
                                <TCComInput
                                    labelName="대표유선전화"
                                    v-model="div_PSMbase.wphonNo"
                                    :appendIconShow="true"
                                    :appendIconClass="''"
                                    :codeIDView="codeIDView"
                                    :codeIDViewVal="codeIDViewVal"
                                    @onAppendIconClick="btnClick08"
                                    :eRequired="true"
                                >
                                </TCComInput>
                            </div> -->

                            <!-- <div class="formitem div5">
                                <TCComInput
                                    labelName="대표무선전화"
                                    v-model="div_PSMbase.repMblPhonNo"
                                    :appendIconShow="true"
                                    :appendIconClass="''"
                                    :codeIDView="codeIDView"
                                    :codeIDViewVal="codeIDViewVal"
                                    @onAppendIconClick="btnClick08"
                                >
                                </TCComInput>
                            </div> -->

                            <div class="formitem div3">
                                <TCComDatePicker
                                    calType="D"
                                    v-model="div_PSMbase.entDt"
                                    labelName="입사일"
                                    :disabled="disabledEntDt"
                                >
                                </TCComDatePicker>
                            </div>

                            <div class="formitem div3">
                                <TCComDatePicker
                                    calType="D"
                                    v-model="div_PSMbase.retirDt"
                                    labelName="퇴사일"
                                    :disabled="disabledRetirDt"
                                >
                                </TCComDatePicker>
                            </div>
                        </div>
                    </div>
                    <!--
                    <div class="textareaLayer_wrap">
                        <TCComTextArea
                            v-model="div_PSMbase.edt_Rmks"
                            labelName="비고"
                            class="boxtype"
                        ></TCComTextArea>
                    </div>
                    -->

                    <div class="gridWrap" v-show="showOrg">
                        <TCRealGridHeader
                            id="gridHeader5"
                            ref="gridHeader5"
                            gridTitle="원 소속조직"
                            :gridObj="gridObj5"
                            :isPageRows="true"
                            :isExceldown="false"
                        />
                        <TCRealGrid
                            id="grid5"
                            ref="grid5"
                            :fields="view5.fields"
                            :columns="view5.columns"
                            :styles="gridStyleOriginOrg"
                        />
                    </div>

                    <a href="#none" class="layerClose b-close" @click="onClose"
                        >닫기</a
                    >
                </div>
            </div>
        </template>
    </TCComDialog>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
import CommonUtil from '@/utils/CommonUtil.js'
import { SacCommon } from '@/views/biz/sac/js'
// import commonApi from '@/api/common/commonCode'
import CommonMsg from '@/utils/CommonMsg'
import {
    HEADER1,
    HEADER2,
    HEADER3,
    HEADER4,
    HEADER5,
} from '@/const/grid/bas/usm/basUsmUserRgstHeader'
import API from '@/api/biz/bas/usm/basUsmUserRgst'
import _ from 'lodash'
import moment from 'moment'
import CommonMixin from '@/mixins'
// import types from './mutation-types'
//====================내부조직팝업(권한)팝업==============================================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//======================================================================================
//====================내부거래처-권한조직=================================================
import BasBcoDealcosPopup from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//======================================================================================
//====================통합SSO ID팝업=====================================================
// import BasBcoSsoIdsPopup from '@/components/common/BasBcoSsoIdsPopup'
// import basBcoSsoIdsApi from '@/api/biz/bas/bco/basBcoSsoIds'
//======================================================================================
//====================내부거래처-전체조직 팝업============================================
// import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
// import BasBcoInrDealcosApi from '@/api/biz/bas/bco/BasBcoInrDealcos'
// import BasBcoInrDealcosPopup from '@/components/common/BasBcoInrDealcosPopup'
//======================================================================================
//====================내부조직팝업(전체)팝업==============================================
import BasBcoOrgTreesPopup from '@/components/common/BasBcoOrgTreesPopup'
import basBcoOrgTreesApi from '@/api/biz/bas/bco/basBcoOrgTrees'
//======================================================================================
//====================//근무지변경이력팝업================================================
import BasUsmDutypChgHstMgmtPopup from '@/views/biz/bas/usm/BasUsmDutypChgHstMgmtPopup'
//=======================================================================================
//====================//근무지변경이력팝업================================================
import BasUsmAuthChgHstMgmtPopup from '@/views/biz/bas/usm/BasUsmAuthChgHstMgmtPopup'
//=======================================================================================
//====================//근무지변경이력팝업================================================
import BasUsmAddDutypHstMgmtPopup from '@/views/biz/bas/usm/BasUsmAddDutypHstMgmtPopup'
//=======================================================================================
//====================//근무지변경이력팝업================================================
import BasUsmAddOrgHstMgmtPopup from '@/views/biz/bas/usm/BasUsmAddOrgHstMgmtPopup'
//=======================================================================================
//====================//근무지변경이력팝업================================================
import BasUsmAddGrpHstMgmtPopup from '@/views/biz/bas/usm/BasUsmAddGrpHstMgmtPopup'
//=======================================================================================
//====================//skt 코드 검색 팝업================================================
import BasUsmSktCodeSrchPopup from '@/views/biz/bas/usm/BasUsmSktCodeSrchPopup'
//=======================================================================================

export default {
    name: 'BasUsmUserRgst',
    mixins: [CommonMixin],
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPopup,
        // BasBcoSsoIdsPopup,
        // BasBcoInrDealcosPopup,
        BasBcoOrgTreesPopup,
        BasUsmDutypChgHstMgmtPopup,
        BasUsmAuthChgHstMgmtPopup,
        BasUsmAddDutypHstMgmtPopup,
        BasUsmAddOrgHstMgmtPopup,
        BasUsmAddGrpHstMgmtPopup,
        BasUsmSktCodeSrchPopup,
    },

    props: {
        // 팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
        // row 정보
        rows: { type: Array, default: () => [], required: false },
    },

    data() {
        return {
            gridStyle: {
                height: '180px', //그리드 높이 조절
            },
            gridStyleOriginOrg: {
                height: '10px', //그리드 높이 조절
            },
            gridData: {},
            gridData2: {},
            // gridData3: {},
            // gridData4: {},
            // gridData5: {},
            gridObj1: {},
            gridObj2: {},
            gridObj3: {},
            gridObj4: {},
            gridObj5: {},
            gridHeaderObj1: {},
            gridHeaderObj2: {},
            gridHeaderObj3: {},
            gridHeaderObj4: {},
            gridHeaderObj5: {},
            objAuth: {},
            commUserGrpOriginList: [],
            commUserGrpList: [],
            text: '',
            calType7: 'DHMP',
            sHourVal7: '11',
            eHourVal7: '23',
            sMinuVal7: '50',
            eMinuVal7: '59',
            calType5: 'M',
            rowCnt: 15,
            codeIDView: true,
            codeIDViewVal: '',
            list01: [],
            list02: [],
            view1: HEADER1,
            view2: HEADER2,
            view3: HEADER3,
            view4: HEADER4,
            view5: HEADER5,
            email2Disabled: false,
            disabledUserGrp: false,
            disabledDealco: false,
            disabledAuthOrg: false,
            disabledLoginUserId: false,
            disabledEdt_UserId: false,
            disabledEdt_UserCd: false,
            disabledDupl: false,
            disabledUserSt: false,
            disabledEntDt: false,
            disabledRetirDt: false,
            disabledAgreeYn: false, // 개인정보활용동의여부
            disabledEffUserYn: false, // 유효사용자여부
            disabledChkUserBtn: false,
            disabledAttcCat: false,
            //유효검사
            bUserGrpChk: false,
            agreeYnCheckBox: [
                {
                    commCdVal: 'Y',
                    commCdValNm: '개인정보활용동의',
                },
            ],
            // effUserYnCheckBox: [
            //     {
            //         commCdVal: 'Y',
            //         commCdValNm: '유효사용자여부',
            //     },
            // ],
            ds_effUserYn: [
                {
                    commCdVal: 'Y',
                    commCdValNm: 'Y',
                },
                {
                    commCdVal: 'N',
                    commCdValNm: 'N',
                },
            ],
            attcCatList: [],
            dCommItemList: [], // 추가사용자그룹 그리드의 그룹셀렉트박스데이터 조회를 위한 리스트
            // 사용자관리 화면에서 넘어오는 파라미터 셋팅할 전역변수
            propsParam: {},

            PV_USER_ID: '',
            pPortalId: '', // 통합 Login ID
            pInUserId: '', // 사용자 ID
            pInStatus: '', // 상태값(M:상세조회 및 비번수정, N:신규)
            pInModFlag: '', // 본인 여부(true: 본인은 비번 수정가능, false: 타인은 조회만 가능)

            pPTL_OrgID: '',
            PTL_RelOrgID: '',
            pUserGrp: '',
            pEff_Sta_dt: '',
            pEff_End_dt: '',

            pChannelCD: '',

            FV_USER_INFO_WINDOW_YN: '', // 판매점관리에 사용자정보 화면 여부
            lastDay: '9999/12/31',
            //=====================================================
            reqParam: {
                cmb_attcCat: '',
                userGrp: '',
            },
            //상세조회 OUTPUT
            ds_user: [],
            // 기본정보 그리드 DIV
            div_base: {},
            // PS&M 그리드 DIV
            div_PSMbase: {
                edt_Email1: '',
                edt_Email2: '',
                edt_UserCd: '',
                cmb_mailList: '',
                cmb_userSt: '',
                entDt: SacCommon.getToday(),
                retirDt: SacCommon.getToday(),
                edt_Rmks: '',
            },
            ds_input: {
                // userId: 'string',
                // ptlEffUserYn: 'string',
                // effUserYn: 'string',
                // portalUserId: 'string',
                // portalMappingYn: 'string',
                // userNm: 'string',
                // userClCd: 'string',
                // sktId: 'string',
                // userStCd: 'string',
                // wphonNo: 'string',
                // repMblPhonNo: 'string',
                // email1: 'string',
                // email2: 'string',
                // orgCd: 'string',
                // rmks: 'string',
                // updCnt: 'string',
                // modDtm: this.getToday().replaceAll('/', ''),
                // modUserId: 'string',
                // userGrpCd: 'string',
                // attcClCd: 0,
                // dealCoCd: 'string',
                // mblPhonNo: 'string',
                // mblPhonNo2: 'string',
                // mblPhonNo3: 'string',
                // accSmsYn1: 'string',
                // accSmsYn2: 'string',
                // indirInfoPraAgreeYn: 'string',
                // userCd: 'string',
                // dutyCd: 'string', // 직무
                // compCd: 'string',
                // pwdNo: 'string',
                // orgHstYn: 'string',
                // userAuthHstYn: 'string',
                // ptlAuditUserId: 'string',
                // ptlAuditDtm: 'string',
                // ptlTransDtm: 'string',
                // ptlEffStaDt: 'string',
                // ptlEffEndDt: 'string',
                // rpstyCd: 'string',
                // entDt: 'string',
                // retirDt: 'string',
                // // get__rowState: 'string',
            },
            showPSM: true,
            showOrg: true,
            // 중복체크데이터 받음 N / Y
            ds_userid_chk: '',
            //============================================================
            showAlertBool: false,
            alertBodyText: '',
            headerText: '',
            //====================상단이력팝업SETTING====================

            //사용자 기본 정보
            basUsmUserInfoVo: [],
            //사용자 소속 조직 정보
            basUsmOrgHstVo: [],
            //권한 변경 이력 정보
            basUsmUserAuthVo: [],
            //SKT_ID 조회
            basUsmSktIdVo: [],
            //HR 정보 조회
            basUsmUserHrInfoVo: [],
            //추가 근무지 이력조회
            basUsmAddDealHisVo: [],
            //추가 조직 이력조회
            basUsmAddOrgHisVo: [],
            // 추가 그룹 이력조회
            basUsmAddGrpHisVo: [],
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchAuthOrgTreeParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //================================================================
            //====================내부거래처(권한조직) 근무지===========================
            showBasBcoDealcos: false,
            searchForm: {
                dealcoCd: '',
                dealcoNm: '',
            },
            resultDealcoRows: [],
            //================================================================
            //===================통합 SSO ID 팝업관련==========================
            showBcoSsoIds: false, // 서비스상품 팝업 오픈 여부
            searchSsoIdParam: {
                loginUserId: '', // 통합 ID
                // userId: '', // 사용자 ID
            },
            resultSsoIdRows: [], // 서비스상품 팝업 오픈 여부
            //=================================================================
            //====================내부거래처(권한조직) 추가근무지===================
            showbasBcoAddDealcos: false,
            searchAddDealcosParam: {
                dealcoCd: '',
                dealcoNm: '',
            },
            resultAddDealcosRows: [],
            //=================================================================
            //====================내부조직팝업(전체)팝업관련=====================
            showBcoOrgTrees: false, // 내부조직팝업(전체) 팝업 오픈 여부
            searchParam: {
                orgCd: '', // 내부조직팝업(전체)코드
                orgNm: '', // 내부조직팝업(전체)명
            },
            resultOrgTreeRows: [], // 내부조직팝업(전체) 팝업 오픈 여부
            //=================================================================
            //====================근무지이력팝업관련====================
            showUsmDutypChgHstMgmt: false,
            //========================================================
            //====================권한이력팝업관련====================
            showUsmAuthChgHstMgmt: false,
            //========================================================
            //====================추가근무지이력팝업관련====================
            showUsmAddDutypHstMgmt: false,
            //========================================================
            //====================추가조직이력팝업관련====================
            showUsmAddOrgHstMgmt: false,
            //========================================================
            //====================추가권한그룹팝업관련====================
            showUsmAddGrpHstMgmt: false,
            //========================================================
            //====================skt 코드 검색 팝업관련=====================
            showBasUsmSktCodeSrch: false,
            sktIdParam: {
                sktId: '',
                sktIdNm: '',
            },
            resultSktCodeRows: [],
            //=================================================================
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },

    watch: {
        parentParam: {
            handler: function (value) {
                console.log('parentParam', value)
                this.propsParam = value
            },
            deep: true, // 속성 내부까지 감시
            immediate: true, // 처음 로드시 변경 감시 상관 없이 실행여부
        },
    },

    created() {
        console.log('------created------')
        this.init()
        console.log('this.$route Detail: ', this.$route)
    },

    async mounted() {
        console.log('------mounted------')
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)
        // TCRealGrid.methods.setRows(this.$refs.grid1, SAMPLE_D_DATA)

        this.gridHeaderObj1 = this.$refs.gridHeader1
        this.gridHeaderObj2 = this.$refs.gridHeader2
        this.gridHeaderObj3 = this.$refs.gridHeader3
        this.gridHeaderObj4 = this.$refs.gridHeader4
        this.gridHeaderObj5 = this.$refs.gridHeader5
        this.gridObj1 = this.$refs.grid1
        this.gridObj2 = this.$refs.grid2
        this.gridObj3 = this.$refs.grid3
        this.gridObj4 = this.$refs.grid4
        this.gridObj5 = this.$refs.grid5
        // "PS&Marketing" 이 아닐 시에 해당 컬럼 숨김
        if (this.orgInfo.orgCdLvl0 != 'O00000') {
            this.showOrg = false
            this.showPSM = false
        }
        //  "PS&Marketing"일 시에 소속유형 대리점, 판매점 안보이게 숨김
        // } else {
        // to-be
        // }

        this.initGrid()
        // // 사용자 권한그룹 셀렉트박스 소속유형에 맞게 필터링
        // this.setUserGrpLstCombo()
        this.init()

        // this.reqParam.userGrp = this.propsParam.selectedUserData.userGrpCd
        this.dropDownSetting()
        // this.setGetUserGrpLst()
        // 공통코드 API
        // this.getCommCodeList('ZBAS_C_00250')

        //소속구분이 임직원이거나 외부사용자이고 사용자 수정일 경우
        // console.log(e)
        // if ((e == '1' || e == '3') && this.pInStatus == 'M') {
        //     this.disabledEdt_UserCd = false
        // }
        // if (e != '1' && e != '3' && this.pInStatus == 'M') {
        //     this.disabledEdt_UserCd = true
        // }
        // 그리드내의 swing id 돋보기 클릭시 이벤트처리
        this.gridObj4.gridView.onCellButtonClicked = (
            grid,
            itemIndex,
            column
        ) => {
            this.gridObj4.gridView.commit()
            if (column.fieldName === 'sktId') {
                this.onSktCodeIconClick()
            }
        }
    },

    methods: {
        init() {
            this.gridData = this.gridSetData()
            this.gridData2 = this.gridSetData()
            this.parentSearchParam = this.propsParam.searchParam
            console.log('this.propsParam', this.propsParam)
            this.PV_USER_ID = this.propsParam.PV_USER_ID
            let sInUserId = this.propsParam.sInUserId
            let sInStatus = this.propsParam.sInStatus
            let sInModFlag = this.propsParam.sInModFlag
            let sPortalId = this.propsParam.sPortalId
            let sOrgID = this.propsParam.sOrgID
            let sRelOrgID = this.propsParam.sRelOrgID
            let sChannelCD = this.propsParam.sChannelCD
            this.div_base.chk_effUserYn = this.propsParam.effUserYn

            let sUserGrp = this.propsParam.sUserGrp
            let sEffSta = this.propsParam.sEffSta
            let sEffEnd = this.propsParam.sEffEnd
            let portalUserId = this.propsParam.portalUserId
            this.commUserGrpOriginList = this.propsParam.commUserGrpOriginList
            this.commUserGrpList = this.propsParam.commUserGrpList
            let selectedUserData = this.propsParam.selectedUserData
            console.log('selectedUserData', selectedUserData)
            if (sInStatus) {
                this.pPortalId = sPortalId
                this.pInUserId = sInUserId
                this.pInStatus = sInStatus
                this.pInModFlag = sInModFlag

                this.pPTL_OrgID = sOrgID
                this.PTL_RelOrgID = sRelOrgID
                this.pUserGrp = sUserGrp
                this.pEff_Sta_dt = sEffSta
                this.pEff_End_dt = sEffEnd

                this.pChannelCD = sChannelCD

                this.FV_USER_INFO_WINDOW_YN = 'N'
            } else {
                // 판매점관리에 있는 사용자 조회로 화면을 조회 시
                this.pInUserId = '' // gds_session.GetColumn(0, "loginId") 세션값으로 셋팅 TO-BE
                this.pInStatus = 'M'
                this.FV_USER_INFO_WINDOW_YN = 'Y'
            }
            // 사용자 권한그룹 셀렉트박스 소속유형에 맞게 필터링
            // this.setUserGrpLstCombo()

            //상세보기
            if (this.pInStatus == 'M' && !_.isEmpty(this.pInUserId)) {
                console.log('INIT 상세보기 INIT 상세보기 INIT 상세보기')
                console.log('PV_USER_ID', this.PV_USER_ID)
                this.ds_input.userId = this.PV_USER_ID
                console.log('this.ds_input', this.ds_input)
                this.getUserInfo()
                // this.getAddUserAuthInfoList()
                // this.getAddUserOrgInfoList()
                // this.getAddUserGrpInfoList()
                this.setEnable()

                // 사용자 권한그룹 셀렉트박스 소속유형에 맞게 필터링
                this.setUserGrpLstCombo(selectedUserData)
                // 조직정보
                this.searchAuthOrgTreeParam.orgNm = selectedUserData.orgNm
                this.searchAuthOrgTreeParam.orgCd = selectedUserData.orgCd
                // 근무지 셋팅
                this.searchForm.dealcoNm = selectedUserData.dealcoNm
                this.searchForm.dealcoCd = selectedUserData.dealcoCd
            }

            if (this.pInStatus == null) this.pInStatus = 'N'

            // 사용자 신규 생성
            if (this.pInStatus == 'N') {
                console.log('INIT 사용자 신규 생성')
                // 조직정보
                this.searchAuthOrgTreeParam.orgNm = selectedUserData.orgNm
                this.searchAuthOrgTreeParam.orgCd = selectedUserData.orgCd
                // 근무지 셋팅
                this.searchForm.dealcoNm = this.propsParam.dealParam.dealcoNm
                this.searchForm.dealcoCd = this.propsParam.dealParam.dealcoCd
                this.getPortalUserInfo(portalUserId)
                // ds_user.ClearData()
                // ds_user.AddRow()
                // // 통합 Login ID Setting
                // div_base.edt_PortalUserID.Text = pPortalId
                this.disabledDupl = false
                this.div_PSMbase.cmb_userSt = '1'
                this.div_PSMbase.entDt = this.getToday()
                this.div_PSMbase.retirDt = '9999-12-31'
                // div_base.chk_EffUserYn.Value = 'Y'
                this.f_editAllowed()
                // 유효사용자여부 신규시 디폴트 체크
                // let chk_effUserYnValues = this.effUserYnCheckBox.map(
                //     (a) => a.commCdVal
                // )
                // this.div_base.chk_effUserYn = chk_effUserYnValues
                this.div_base.chk_effUserYn = 'Y'
            }

            if (this.pInStatus == 'P') {
                this.f_editAllowed()
                // this.div_base.chk_effUserYn[0] = 'Y'
                this.div_base.chk_effUserYn = 'Y'
            }
            // 추가사용자그룹  그룹 공통코드 조회
            // this.dCommItemList = this.getCommCodeList()
            // console.log('HEADER3_before', this.dCommItemList)
            this.getToday()
            console.log('this.getToday()', this.getToday())
        },

        // 그리드 활성화 셋팅함수
        f_editAllowed() {
            if (this.pInStatus == 'N') {
                //신규
                this.disabledEdt_UserId = false
                this.disabledEdt_UserCd = false

                this.disabledAgreeYn = false
                this.disabledEffUserYn = false
                this.disabledAuthOrg = false
                this.disabledDealco = false

                this.disabledUserSt = false
            } else if (this.pInStatus == 'P') {
                this.disabledEdt_UserId = false
            } else {
                this.disabledEdt_UserId = true
            }
        },
        //GridSet Init
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수),  변경Row데이터),
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        async initGrid() {
            this.gridObj1.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj2.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj3.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj4.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj5.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
            this.gridObj1.setGridState()
            this.gridObj2.setGridState()
            this.gridObj3.setGridState()
            this.gridObj4.setGridState()
            this.gridObj5.setGridState()

            CommonMsg.$_log('init 함수호출')
        },

        // 사용자관리화면에서 사용자정보 더블클릭시에
        setEnable() {
            // this.disabledUserGrp = true
            this.disabledDealco = true
            // this.disabledAuthOrg = true
            this.disabledLoginUserId = true
            this.disabledEdt_UserId = true
            this.disabledDupl = true
            this.disabledUserSt = true
            this.disabledEntDt = true
            this.disabledRetirDt = true
            this.disabledAgreeYn = true
            this.disabledEffUserYn = true
        },

        // 공통코드 API
        // getCommCodeList(codeId) {
        //     commonApi.getCommonCodeListById(codeId).then((res) => {
        //         if (res !== undefined) {
        //             this.commUserGrpOriginList = res
        //             // this.dCommItemList = res
        //         }
        //     })
        // },

        // 사용자 권한 목록조회
        setUserGrpLstCombo(selectedUserData) {
            console.log('cmb_attcCat', this.reqParam.cmb_attcCat)

            this.commUserGrpList = this.propsParam.commUserGrpList
            this.reqParam.userGrp = selectedUserData.userGrpCd
            // .filter(
            //     (item) => item['attcClCd'] == this.reqParam.cmb_attcCat
            // )
            console.log(
                'this.commUserGrpOriginList',
                this.commUserGrpOriginList
            )
            console.log('this.commUserGrpList', this.commUserGrpList)
            // this.commUserGrpOriginList = res
            // this.commUserGrpList = res
            // this.dCommItemList = res
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.searchAuthOrgTreeParam)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    if (res.length === 4) {
                        this.searchAuthOrgTreeParam.orgCd = _.get(
                            res[3],
                            'orgCd'
                        )
                        this.searchAuthOrgTreeParam.orgNm = _.get(
                            res[3],
                            'orgNm'
                        )
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // this.searchAuthOrgTreeParam.basMth = CommonUtil.replaceDash(
            //     SacCommon.getToday()
            // )
            this.searchAuthOrgTreeParam.vLevel = '3' // 디스플레이제한레벨
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            if (!_.isEmpty(this.searchAuthOrgTreeParam.orgNm)) {
                this.getAuthOrgTreeList()
            } else {
                this.showBcoAuthOrgTrees = true
            }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // this.searchAuthOrgTreeParam.basMth = CommonUtil.replaceDash(
            //     SacCommon.getToday()
            // )
            this.searchAuthOrgTreeParam.vLevel = '3' // 디스플레이제한레벨
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchAuthOrgTreeParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.searchAuthOrgTreeParam.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchAuthOrgTreeParam.orgCd = _.get(retrunData, 'orgCd')
            this.searchAuthOrgTreeParam.orgNm = _.get(retrunData, 'orgNm')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================

        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처(권한조직) 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처(권한조직) 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.searchForm).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된내부거래처(권한조직) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처(권한조직) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.searchForm.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.searchForm.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처(권한조직) TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처(권한조직) 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.searchForm.orgCd = this.searchAuthOrgTreeParam.orgCd
            this.searchForm.orgNm = this.searchAuthOrgTreeParam.orgNm
            this.searchForm.basDay = CommonUtil.replaceDash(
                SacCommon.getToday()
            )
            // 검색조건 내부거래처(권한조직)명이 빈값이 아니면 내부거래처(권한조직) 정보 조회
            // 그 이외는 내부거래처(권한조직) 팝업 오픈
            if (!_.isEmpty(this.searchForm.dealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처(권한조직) TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처(권한조직) 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            this.searchForm.orgCd = this.searchAuthOrgTreeParam.orgCd
            this.searchForm.orgNm = this.searchAuthOrgTreeParam.orgNm
            this.searchForm.basDay = CommonUtil.replaceDash(
                SacCommon.getToday()
            )

            //replace     substring(0, 6)
            // 검색조건 내부거래처(권한조직)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchForm.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처(권한조직)명 입력해주세요.'
                return
            }
            // 내부거래처(권한조직) 정보 조회
            this.getDealcosList()
        },
        // 내부거래처(권한조직) TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처(권한조직) 코드 초기화
            this.searchForm.dealcoCd = ''
        },
        // 내부거래처(권한조직) 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchForm.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.searchForm.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===========================================================================================
        //===================== 통합 SSO ID 팝업관련 methods ================================
        // 통합 SSO ID 조회 후 1건이면 TextField에 바로 설정하고 아니면 통합 SSO ID 팝업 오픈
        // getSsoIdsList() {
        //     basBcoSsoIdsApi.getSsoIdsList(this.searchSsoIdParam).then((res) => {
        //         console.log('getSsoIdsList then : ', res)
        //         // 검색된 통합 SSO ID 정보가 1건이면 TextField에 바로 설정
        //         // 검색된 통합 SSO ID 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 통합 SSO ID 팝업 오픈
        //         if (res.length === 1) {
        //             this.searchSsoIdParam.loginUserId = _.get(
        //                 res[0],
        //                 'loginUserId'
        //             )
        //         } else {
        //             this.resultSsoIdRows = res
        //             this.showBcoSsoIds = true
        //         }
        //     })
        // },
        // 통합 SSO ID TextField 돋보기 Icon 이벤트 처리
        onSsoIdIconClick() {
            // 통합 SSO ID 팝업 Row 설정 Prop 변수 초기화
            this.resultSsoIdRows = []
            // 검색조건 통합 SSO ID가 빈값이 아니면 통합 SSO ID 정보 조회
            // 그 이외는 통합 SSO ID 팝업 오픈
            if (!_.isEmpty(this.searchSsoIdParam.loginUserId)) {
                this.getSsoIdsList()
            } else {
                this.showBcoSsoIds = true
            }
        },
        // 통합 SSO ID TextField 엔터키 이벤트 처리
        onSsoIdEnterKey() {
            // 통합 SSO ID 팝업 Row 설정 Prop 변수 초기화
            this.resultSsoIdRows = []
            // 검색조건 통합 SSO ID가 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchSsoIdParam.loginUserId)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '통합 SSO ID를 입력해주세요.'
                return
            }
            // 통합 SSO ID 정보 조회
            this.getSsoIdsList()
        },
        // 통합 SSO ID 팝업 리턴 이벤트 처리
        onSsoIdReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.searchSsoIdParam.loginUserId = _.get(retrunData, 'loginUserId')
        },
        //===================== //통합 SSO ID 팝업관련 methods ================================
        //===================== 내부거래처-전체조직 팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        // getList() {
        //     BasBcoInrDealcosApi.getList(this.searchAddDealcosParam).then(
        //         (res) => {
        //             console.log('getList then : ', res)
        //             // 검색된 내부거래처-전체조직 팝업 정보가 1건이면 TextField에 바로 설정
        //             // 검색된 내부거래처-전체조직 팝업 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
        //             if (res.length === 1) {
        //                 this.searchAddDealcosParam.dealcoCd = _.get(
        //                     res[0],
        //                     'dealCoCd'
        //                 )
        //                 this.searchAddDealcosParam.dealcoNm = _.get(
        //                     res[0],
        //                     'dealCoNm'
        //                 )
        //             } else {
        //                 this.resultInrDealcoRows = res
        //                 this.showbasBcoInrDealcos = true
        //             }
        //         }
        //     )
        // },
        // getAddDealcosList() {
        //     basBcoDealcosApi
        //         .getDealcosList(this.searchAddDealcosParam)
        //         .then((res) => {
        //             console.log('getList then : ', res)
        //             // 검색된 내부거래처-전체조직 팝업 정보가 1건이면 TextField에 바로 설정
        //             // 검색된 내부거래처-전체조직 팝업 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
        //             if (res.length === 1) {
        //                 this.searchAddDealcosParam.dealcoCd = _.get(
        //                     res[0],
        //                     'dealCoCd'
        //                 )
        //                 this.searchAddDealcosParam.dealcoNm = _.get(
        //                     res[0],
        //                     'dealCoNm'
        //                 )
        //             } else {
        //                 this.resultAddDealcosRows = res
        //                 this.showbasBcoAddDealcos = true
        //             }
        //         })
        // },

        // 내부거래처 팝업 TextField 돋보기 Icon 이벤트 처리
        onAddDealco() {
            console.log('checking where1')
            // 내부거래처팝업 Row 설정 Prop 변수 초기화
            this.resultAddDealcoRows = []
            this.searchAddDealcosParam.orgCd = this.searchAuthOrgTreeParam.orgCd
            this.searchAddDealcosParam.orgNm = this.searchAuthOrgTreeParam.orgNm
            this.searchAddDealcosParam.basDay = CommonUtil.replaceDash(
                SacCommon.getToday()
            )
            this.showbasBcoAddDealcos = true
        },
        // 내부거래처팝업(권한) TextField 엔터키 이벤트 처리
        // onAddDealcosEnterKey() {
        //     // 내부거래처팝업(권한) 팝업 Row 설정 Prop 변수 초기화
        //     this.resultInrDealcoRows = []
        //     this.searchInrDealcosParam.orgCd = this.searchAuthOrgTreeParam.orgCd
        //     this.searchInrDealcosParam.orgNm = this.searchAuthOrgTreeParam.orgNm
        //     this.searchInrDealcosParam.basDay = CommonUtil.replaceDash(
        //         SacCommon.getToday()
        //     )
        //     // 검색조건 내부거래처팝업(권한)명이 빈값이면 알림창 오픈
        //     if (_.isEmpty(this.searchInrDealcosParam.dealcoNm)) {
        //         this.showAlertBool = true
        //         this.headerText = '검색조건 필수'
        //         this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
        //         return
        //     }
        //     // 내부거래처팝업(권한) 정보 조회
        //     this.getList()
        // },
        // 내부거래처팝업(권한) TextField Input 이벤트 처리
        // onAddDealcosInput() {
        //     // 입력되는 값이 있으면 코드 초기화
        //     this.searchInrDealcosParam.dealcoCd = ''
        //     this.searchInrDealcosParam.dealcoNm = ''
        // },
        // 내부거래처팝업(권한) 팝업 리턴 이벤트 처리
        onAddDealcosReturnData(returnData) {
            console.log('checking where4')
            console.log('returnData: ', returnData)
            // this.searchAddDealcosParam.dealcoCd = _.get(returnData, 'dealcoCd')
            // this.searchAddDealcosParam.dealcoNm = _.get(returnData, 'dealcoNm')
            let rowData = {
                dealcoCd: _.get(returnData, 'dealcoCd'),
                dealcoNm: _.get(returnData, 'dealcoNm'),
                staDt: this.getToday().replaceAll('-', '/'),
                expirDt: this.lastDay,
            }
            // console.log('searchAddDealcosParam: ', this.searchAddDealcosParam)
            let rowCount = this.gridObj1.dataProvider.getRowCount()
            this.gridObj1.gridView.commit()
            this.gridObj1.dataProvider.insertRow(rowCount, rowData)
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================

        //===================== 내부조직팝업(전체)팝업관련 methods ================================
        // 내부조직팝업(전체) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(전체) 팝업 오픈
        getOrgTreeList() {
            basBcoOrgTreesApi.getOrgTreeList(this.searchParam).then((res) => {
                console.log('getOrgTreeList then : ', res)
                // 검색된 내부조직팝업(전체) 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부조직팝업(전체) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(전체) 팝업 오픈
                if (res.length === 1) {
                    this.searchParam.addOrgCd = _.get(res[0], 'orgCd')
                    this.searchParam.orgNm = _.get(res[0], 'orgNm')
                } else {
                    this.resultOrgTreeRows = res
                    this.showBcoOrgTrees = true
                }
            })
        },
        // 내부조직팝업(전체) TextField 돋보기 Icon 이벤트 처리
        onOrgTreeIconClick() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이 아니면 내부조직팝업(전체) 정보 조회
            // 그 이외는 내부조직팝업(전체) 팝업 오픈
            if (!_.isEmpty(this.searchParam.orgNm)) {
                this.getOrgTreeList()
            } else {
                this.showBcoOrgTrees = true
            }
        },
        // 내부조직팝업(전체) TextField 엔터키 이벤트 처리
        onOrgTreeEnterKey() {
            // 내부조직팝업(전체) 팝업 Row 설정 Prop 변수 초기화
            this.resultOrgTreeRows = []
            // 검색조건 내부조직팝업(전체)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.searchParam.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(전체)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(전체) 정보 조회
            this.getOrgTreeList()
        },
        // 내부조직팝업(전체) TextField Input 이벤트 처리
        onOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(전체) 코드 초기화
            this.searchParam.orgCd = ''
        },
        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onOrgTreeReturnData(returnData) {
            // let lastDay = '99991231'
            console.log(
                '내부조직팝업(전체) 팝업 리턴 이벤트 returnData: ',
                returnData
            )
            this.searchParam.addOrgCd = _.get(returnData, 'orgCd')
            this.searchParam.addOrgNm = _.get(returnData, 'orgNm')
            console.log('this.gridObj2.dataProvider: ', this.searchParam)
            let rowData = {
                addOrgCd: _.get(returnData, 'orgCd'),
                addOrgNm: _.get(returnData, 'orgNm'),
                staDt: this.getToday().replaceAll('-', '/'),
                expirDt: this.lastDay,
            }
            let rowCount = this.gridObj2.dataProvider.getRowCount()
            this.gridObj2.gridView.commit()
            this.gridObj2.dataProvider.insertRow(rowCount, rowData)
        },
        //===================== //내부조직팝업(전체)팝업관련 methods =========================

        //===================== 근무지이력관리팝업관련 methods ==================================
        // 근무지이력관리팝업버튼 이벤트 처리
        onDutypChgHstMgmtClick() {
            this.showUsmDutypChgHstMgmt = true
        },
        //==================================================================================
        //===================== 권한이력관리팝업관련 methods ==================================
        // 권한이력관리팝업버튼 이벤트 처리
        onAuthChgHstMgmtClick() {
            this.showUsmAuthChgHstMgmt = true
        },
        //==================================================================================
        //===================== 추가근무지이력팝업관련 methods ==================================
        // 추가근무지이력팝업버튼 이벤트 처리
        onAddDutypHstMgmtClick() {
            this.showUsmAddDutypHstMgmt = true
        },
        //==================================================================================
        //===================== 추가조직이력관리팝업관련 methods ==================================
        // 추가조직이력관리팝업버튼 이벤트 처리
        onAddOrgHstMgmtClick() {
            this.showUsmAddOrgHstMgmt = true
        },
        //==================================================================================
        //===================== 추가권한그룹팝업관련 methods ==================================
        // 추가권한그룹팝업버튼 이벤트 처리
        onAddGrpHstMgmtClick() {
            this.showUsmAddGrpHstMgmt = true
        },
        //==================================================================================
        //===================== skt코드 검색 팝업관련 methods ================================
        onSktCodeIconClick() {
            this.resultSktCodeRows = []
            this.sktIdParam.sktIdNm = this.div_base.edt_UserNm
            this.showBasUsmSktCodeSrch = true
        },

        // 내부조직팝업(전체) 팝업 리턴 이벤트 처리
        onSktCodeReturnData(returnData) {
            console.log(
                '내부조직팝업(전체) 팝업 리턴 이벤트 returnData: ',
                returnData
            )
            this.sktIdParam.sktId = _.get(returnData, 'sktId')
            this.sktIdParam.sktNm = _.get(returnData, 'sktNm')

            let current = this.gridObj4.gridView.getCurrent()

            this.gridObj4.gridView.setValue(
                current.dataRow,
                'sktId',
                _.get(returnData, 'sktId')
            )
            this.gridObj4.gridView.setValue(
                current.dataRow,
                'sktIdNm',
                _.get(returnData, 'sktIdNm')
            )
            this.gridObj4.gridView.setValue(
                current.dataRow,
                'sktUserId',
                _.get(returnData, 'sktUserId')
            )
            this.gridObj4.gridView.setValue(current.dataRow, 'useYn', 'Y')
            this.gridObj4.gridView.commit()
        },

        onClose() {
            console.log('this.$parent', this.$parent)
            this.activeOpen = false
        },

        // 초기화
        onResetPage() {
            this.gridObj1.gridView.commit()
            this.gridObj2.gridView.commit()
            this.gridObj3.gridView.commit()
            this.gridObj4.gridView.commit()
            this.gridObj5.gridView.commit()
            CommonUtil.clearPage(this, 'reqParam')
            CommonUtil.clearPage(this, 'ds_user')
            CommonUtil.clearPage(this, 'div_base')
            CommonUtil.clearPage(this, 'div_PSMbase')
            CommonUtil.clearPage(this, 'ds_input')

            // this.gridData1 = this.gridSetData()
            this.gridObj1.dataProvider.clearRows()
            this.gridObj2.dataProvider.clearRows()
            this.gridObj3.dataProvider.clearRows()
            this.gridObj4.dataProvider.clearRows()
            this.gridObj5.dataProvider.clearRows()

            this.init()
        },

        btnClick08() {},

        // 사용자 상세조회
        getUserInfo() {
            // this.gridData = this.GridSetData() // 초기화
            console.log('this.ds_input : ', this.ds_input.userId)
            let param = {
                userId: this.ds_input.userId,
            }
            API.getUserInfo(param).then((resultData) => {
                this.gridData = this.gridSetData() //초기화
                if (resultData) {
                    //사용자 기본 정보
                    this.basUsmUserInfoVo = resultData.basUsmUserInfoVo
                    //사용자 소속 조직 정보
                    this.basUsmOrgHstVo = resultData.basUsmOrgHstVo
                    // 권한 변경 이력 정보
                    this.basUsmUserAuthVo = resultData.basUsmUserAuthVo
                    //SKT_ID 조회
                    this.basUsmSktIdVo = resultData.basUsmSktIdVo
                    //HR 정보 조회
                    this.basUsmUserHrInfoVo = resultData.basUsmUserHrInfoVo
                    //추가 근무지 조회
                    this.basUsmAddDealHisVo = resultData.basUsmAddDealHisVo
                    //추가 그룹/조직 조회
                    this.basUsmAddOrgHisVo = resultData.basUsmAddOrgHisVo
                    this.basUsmAddGrpHisVo = resultData.basUsmAddGrpHisVo
                    console.log('사용자 기본 정보 : ', this.basUsmUserInfoVo)
                    console.log('사용자 소속 조직 정보 : ', this.basUsmOrgHstVo)
                    console.log('권한 변경 이력 정보 : ', this.basUsmUserAuthVo)
                    console.log('SKT_ID 조회 : ', this.basUsmSktIdVo)
                    console.log('HR 정보 조회 : ', this.basUsmUserHrInfoVo)
                    console.log('추가 근무지 조회 : ', this.basUsmAddDealHisVo)
                    console.log('추가 조직 조회 : ', this.basUsmAddOrgHisVo)
                    console.log('추가 그룹 조회 : ', this.basUsmAddGrpHisVo)
                    // 조직정보
                    this.reqParam.cmb_attcCat =
                        resultData.basUsmUserInfoVo[0].attcClCd
                    this.reqParam.userGrp =
                        resultData.basUsmUserInfoVo[0].userGrpCd

                    // this.searchAuthOrgTreeParam.orgNm =
                    //     this.parentSearchParam.orgNm
                    // // resultData.basUsmUserInfoVo[0].orgNm
                    // this.searchAuthOrgTreeParam.orgCd =
                    //     this.parentSearchParam.orgCd
                    // // resultData.basUsmUserInfoVo[0].orgCd

                    // // 콜백에있는 조직정보 셋팅
                    // if (
                    //     this.basUsmUserHrInfoVo.length > 0 &&
                    //     this.basUsmUserHrInfoVo[0].deptCd
                    // ) {
                    //     this.searchForm.dealcoCd =
                    //         this.parentSearchParam.dealcoCd
                    //     // resultData.basUsmUserHrInfoVo[0].dealcoCd
                    //     this.searchForm.dealcoCd =
                    //         this.parentSearchParam.dealcoNm
                    //     // resultData.basUsmUserHrInfoVo[0].dealcoNm
                    // } else {
                    //     this.searchForm.dealcoNm =
                    //         this.parentSearchParam.dealcoNm
                    //         // resultData.basUsmUserInfoVo[0].dealcoNm
                    //     this.searchForm.dealcoCd =
                    //         this.parentSearchParam.dealcoCd
                    //         // resultData.basUsmUserInfoVo[0].dealcoCd
                    // }
                    console.log('ERROR CHECK 1: ')
                    // 추가근무지
                    this.gridObj1.setRows(resultData.basUsmAddDealHisVo)
                    // 추가내부조직
                    this.gridObj2.setRows(resultData.basUsmAddOrgHisVo)
                    // 추가사용자그룹
                    this.gridObj3.setRows(resultData.basUsmAddGrpHisVo)
                    // 기본정보------------------------------------------------
                    this.searchSsoIdParam.loginUserId =
                        resultData.basUsmUserInfoVo[0].portalUserId
                    this.searchSsoIdParam.edt_UserId =
                        resultData.basUsmUserInfoVo[0].userId
                    this.div_base.edt_UserNm =
                        resultData.basUsmUserInfoVo[0].userNm
                    // 유효사용자여부
                    // let chk_effUserYnValues = this.effUserYnCheckBox.map(
                    //     (a) => a.commCdVal
                    // )
                    // this.div_base.chk_effUserYn = chk_effUserYnValues
                    this.div_base.chk_effUserYn =
                        resultData.basUsmUserInfoVo[0].effUserYn
                    //개인정보황용동의
                    let chk_agreeYnValues = this.agreeYnCheckBox.map(
                        (a) => a.commCdVal
                    )
                    this.div_base.chk_agreeYn = chk_agreeYnValues
                    //---------------------------------------------------------------
                    // Swing Id 정보
                    this.gridObj4.setRows(resultData.basUsmSktIdVo)
                    // 원 소속조직
                    this.gridObj5.setRows(resultData.basUsmUserHrInfoVo)

                    console.log('ERROR CHECK 2: ')
                    // PS&M 추가정보

                    if (resultData.basUsmUserHrInfoVo.length > 0) {
                        this.div_PSMbase.biId =
                            resultData.basUsmUserHrInfoVo[0].biId
                    }
                    console.log('ERROR CHECK 3: ')
                    if (resultData.basUsmUserInfoVo.length > 0) {
                        this.div_PSMbase.edt_UserCd =
                            resultData.basUsmUserInfoVo[0].userCd
                        this.div_PSMbase.cmb_userSt =
                            resultData.basUsmUserInfoVo[0].userStCd
                        this.div_PSMbase.edt_Email1 =
                            resultData.basUsmUserInfoVo[0].email1
                        this.div_PSMbase.edt_Email2 =
                            resultData.basUsmUserInfoVo[0].email2
                        // this.div_PSMbase.wphonNo =
                        //     resultData.basUsmUserInfoVo[0].wphonNo
                        this.div_PSMbase.repMblPhonNo =
                            resultData.basUsmUserInfoVo[0].repMblPhonNo
                        this.div_PSMbase.mblPhonNo =
                            resultData.basUsmUserInfoVo[0].mblPhonNo
                        this.div_PSMbase.wphonNo =
                            resultData.basUsmUserInfoVo[0].wphonNo
                        this.div_PSMbase.entDt = resultData.basUsmUserInfoVo[0]
                            .entDt
                            ? moment(
                                  resultData.basUsmUserInfoVo[0].entDt
                              ).format('YYYY-MM-DD')
                            : ''
                        this.div_PSMbase.retirDt = resultData
                            .basUsmUserInfoVo[0].retirDt
                            ? moment(
                                  resultData.basUsmUserInfoVo[0].retirDt
                              ).format('YYYY-MM-DD')
                            : ''
                        this.div_PSMbase.edt_Rmks =
                            resultData.basUsmUserInfoVo[0].rmks
                    }
                }
                console.log('ERROR CHECK 4: ')
                // 소속구분이 임직원일 경우 유효검사 활성화
                if (this.reqParam.cmb_attcCat == '1') {
                    this.disabledUserGrp = true
                    this.disabledEdt_UserCd = false
                    this.disabledChkUserBtn = false
                    this.disabledAuthOrg = true
                    this.disabledDealco = true
                    // this.disabledEffUserYn = true
                    this.disabledEffUserYn = true
                    // this.disabledAttcCat = true
                } else {
                    this.disabledUserGrp = false
                    this.disabledEdt_UserCd = true
                    this.disabledChkUserBtn = true
                    this.disabledAuthOrg = false
                    this.disabledDealco = false
                    this.disabledEffUserYn = false
                    this.disabledAttcCat = false
                }
                // 소속유형별 권한그룹 필터링
                this.setGetUserGrpLst()
            })
        },

        // 미매핑 사용자 상세 조회
        getPortalUserInfo(portalUserId) {
            console.log('portalUserId : ', portalUserId)
            let param = {
                userId: portalUserId,
            }
            API.getPortalUserInfo(param).then((result) => {
                this.gridData = this.gridSetData() //초기화
                if (result) {
                    let resultData = result[0]
                    // // 추가근무지
                    // this.gridObj1.setRows(resultData.basUsmAddDealHisVo)
                    // // 추가내부조직
                    // this.gridObj2.setRows(resultData.basUsmAddOrgHisVo)
                    // // 추가사용자그룹
                    // this.gridObj3.setRows(resultData.basUsmAddGrpHisVo)
                    // 기본정보------------------------------------------------
                    this.searchSsoIdParam.loginUserId = resultData.portalUserId
                    this.searchSsoIdParam.edt_UserId = resultData.userId
                        ? resultData.userId
                        : resultData.portalUserId
                    this.div_base.edt_UserNm = resultData.userNm

                    // this.div_base.chk_effUserYn =
                    //     resultData.basUsmUserInfoVo[0].effUserYn
                    //개인정보황용동의
                    // let chk_agreeYnValues = this.agreeYnCheckBox.map(
                    //     (a) => a.commCdVal
                    // )
                    // this.div_base.chk_agreeYn = chk_agreeYnValues
                    //---------------------------------------------------------------
                    // 원 소속조직
                    // this.gridObj4.setRows(resultData.basUsmUserHrInfoVo)

                    console.log('ERROR CHECK 2: ')
                    // PS&M 추가정보

                    // if (resultData.basUsmUserHrInfoVo.length > 0) {
                    //     this.div_PSMbase.biId =
                    //         resultData.basUsmUserHrInfoVo[0].biId
                    // }
                    console.log('ERROR CHECK 3: ')
                    // if (resultData.basUsmUserInfoVo.length > 0) {
                    // this.div_PSMbase.edt_UserCd =
                    //     resultData.basUsmUserInfoVo[0].userCd
                    // this.div_PSMbase.cmb_userSt =
                    //     resultData.basUsmUserInfoVo[0].userStCd
                    // this.div_PSMbase.edt_Email1 =
                    //     resultData.basUsmUserInfoVo[0].email1
                    // this.div_PSMbase.edt_Email2 =
                    //     resultData.basUsmUserInfoVo[0].email2
                    // this.div_PSMbase.wphonNo =
                    //     resultData.basUsmUserInfoVo[0].wphonNo
                    this.div_PSMbase.repMblPhonNo = resultData.repMblPhonNo
                    this.div_PSMbase.mblPhonNo = resultData.mblPhonNo
                        ? resultData.mblPhonNo
                        : resultData.repMblPhonNo
                    this.div_PSMbase.wphonNo = resultData.wphonNo
                    // this.div_PSMbase.entDt = resultData.basUsmUserInfoVo[0]
                    //     .entDt
                    //     ? moment(
                    //           resultData.basUsmUserInfoVo[0].entDt
                    //       ).format('YYYY-MM-DD')
                    //     : ''
                    // this.div_PSMbase.retirDt = resultData
                    //     .basUsmUserInfoVo[0].retirDt
                    //     ? moment(
                    //           resultData.basUsmUserInfoVo[0].retirDt
                    //       ).format('YYYY-MM-DD')
                    //     : ''
                    // this.div_PSMbase.edt_Rmks =
                    //     resultData.basUsmUserInfoVo[0].rmks
                    // }
                }
                console.log('ERROR CHECK 4: ')
                // 소속구분이 임직원일 경우 유효검사 활성화
                // if (this.reqParam.cmb_attcCat == '1') {
                //     this.disabledUserGrp = true
                //     this.disabledEdt_UserCd = false
                //     this.disabledChkUserBtn = false
                //     this.disabledAuthOrg = true
                // }
            })
        },

        // 사용자 ID 중복 체크
        btn_dupChk_onClick() {
            // console.log(
            //     'this.ds_user.userId.length',
            //     this.ds_user.userId.length
            // )
            // let param = {}
            // let sUserId = ''
            // if (this.basUsmUserInfoVo.length != 0) {
            //     console.log('1', this)

            //     sUserId = this.basUsmUserInfoVo[0].userId
            //     param = this.ds_user[0].userId
            // } else {
            let sUserId = this.searchSsoIdParam.edt_UserId

            let param = {
                userId: sUserId,
            }
            // }
            // console.log('sUserId.length', sUserId.length)
            console.log('ds_user', this.ds_user)
            if (!sUserId) {
                // sInStatus : N일경우
                // console.log('사용자ID를 입력하십시오?.')
                console.log('3', sUserId)
                this.showTcComAlert('사용자ID를 입력하십시오.')
                return
            }

            API.getUserIdChk(param).then((resultData) => {
                console.log('resultData : ', resultData)
                this.ds_userid_chk = resultData
                // 사용중일 경우
                if (resultData == 'N') {
                    this.showTcComAlert('사용가능한 사용자ID입니다.')
                } else {
                    this.showTcComAlert('사용자ID가 이미 존재합니다.')
                }
            })
        },

        chk_agreeYnOnClick(e) {
            console.log('개인정보활용동의 여부체크', e)
        },

        chk_effUserYnOnClick(e) {
            console.log('유효사용자 여부체크', e)
        },

        // 추가근무지 목록 - 행추가
        async btn_add_org_OnClick() {
            await this.onAddDealco()
            // this.gridData.gridRows = this.gridHeaderObj1.addRow(
            //     this.gridData.gridRows
            // )
            // let popUpData = {
            //     dealcoCd: this.searchInrDealcosParam.dealcoCd,
            //     dealcoNm: this.searchInrDealcosParam.dealcoNm,
            // }
            // this.gridData.gridRows = this.gridHeaderObj1.addRow(
            //     this.gridData.gridRows
            // )
        },

        //추가근무지 목록 - 행삭제
        btn_del_org_OnClick: function () {
            this.gridData = this.gridHeaderObj1.focusDelRow(this.gridData)
            console.log('gridData', this.gridData)
        },

        // 추가 내부 조직 목록 - 행추가
        async btn_add_org_OnClick2() {
            console.log('추가 내부 조직 목록 - 행추가')
            await this.onOrgTreeIconClick()
            // this.gridData.gridRows = this.gridHeaderObj2.addRow(
            //     this.gridData.gridRows
            // )
        },

        // 추가 내부 조직 목록 - 행삭제
        btn_del_org_OnClick2: function () {
            console.log('************************')
            this.gridData = this.gridHeaderObj2.focusDelRow(this.gridData)
        },

        // 추가권한그룹 목록 - 행추가
        btn_add_userGrp_OnClick: function () {
            // console.log('HEADER3_before', this.dCommItemList)
            // this.gridObj3.gridView.commit()
            this.gridObj3.gridView.commit()
            let rowData = {
                addUserGrpCd: '',
                staDt: this.getToday().replaceAll('-', '/'),
                expirDt: this.lastDay,
            }
            let rowCount = this.gridObj3.dataProvider.getRowCount()
            this.gridObj3.dataProvider.insertRow(rowCount, rowData)
            // this.gridData.gridRows = this.gridHeaderObj3.addRow(
            //     rowData // this.gridData.gridRows
            // )
        },

        // 추가사용자그룹 목록 - 행삭제
        btn_del_userGrp_OnClick: function () {
            console.log('************************')
            this.gridData = this.gridHeaderObj3.focusDelRow(this.gridData)
            console.log('행삭제gridData', this.gridData)
        },

        // 그리드에 dropdown셋팅 공통코드 api
        async dropDownSetting() {
            console.log('dropDownSetting')
            // await this.dropDownCmmonCodes({
            //     key: 'ZBAS_C_00250',
            //     columnName: 'addUserGrpCd',
            //     option: '선택',
            // })
            // 소속유형
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00380',
                columnName: 'attcCat',
                option: '선택',
            })

            let colStaDt = this.gridObj3.gridView.columnByName('staDt')
            console.log('colStaDt', colStaDt)
            colStaDt.values = [this.getToday()]
            colStaDt.labels = [this.getToday()]
            console.log('values', colStaDt.values)
            console.log('labels', colStaDt.labels)
            this.gridObj3.gridView.setColumn(colStaDt)
        },

        async dropDownCmmonCodes({ key, columnName, option }) {
            console.log('key columnName option', key, columnName, option)
            let result = await API.dropDownCmmonCodes_(key)
            console.log('result', result)
            // let values = []
            // let labels = []
            if (columnName == 'attcCat') {
                this.attcCatList = result
                console.log('resultAttcCat', result)
                // "PS&Marketing" 일시에 해당 대리점/판매점 콤보박스에서 숨김
                if (this.orgInfo.orgCdLvl0 == 'O00000') {
                    this.attcCatList = this.attcCatList
                        .filter((p) => p.commCdVal != 'D')
                        .filter((p) => p.commCdVal != 'P')
                } else {
                    this.attcCatList = this.attcCatList.filter(
                        (p) => p.commCdVal == ('D' || 'P')
                    )
                    // .filter((p) => p.commCdVal == 'P')
                }
            }

            // if (columnName == 'addUserGrpCd') {
            //     values = result.map((a) => a.commCdVal)
            //     console.log('values', values)
            //     labels = result.map((a) => a.commCdValNm)
            //     console.log('labels', labels)
            //     if (option != undefined) {
            //         values.unshift('')
            //         labels.unshift(option)
            //     }
            //     let col1 = this.gridObj3.gridView.columnByName('addUserGrpCd')
            //     console.log('addUserGrpCd', col1)
            //     col1.values = values
            //     col1.labels = labels
            //     this.gridObj3.gridView.setColumn(col1)
            // }
        },
        setGetUserGrpLst() {
            let values = []
            let labels = []
            // this.commUserGrpList = []
            // this.reqParam.userGrp = ''
            // if (this.reqParam.cmb_attcCat == '') {
            //     this.reqParam.userGrp = ''
            //     this.commUserGrpList = this.commUserGrpOriginList
            //     // this.disabledUserGrp = true
            // } else {
            //     // 소속유형에 따른 권한그룹 combobox filter
            //     this.commUserGrpList = this.commUserGrpOriginList.filter(
            //         (item) => item['attcClCd'] == this.reqParam.cmb_attcCat
            //     )
            // this.reqParam.userGrp = ''
            // }

            values = this.commUserGrpList.map((a) => a.commCdVal)
            console.log('values', values)
            labels = this.commUserGrpList.map((a) => a.commCdValNm)
            console.log('labels', labels)
            values.unshift('')
            labels.unshift('선택')

            let col1 = this.gridObj3.gridView.columnByName('addUserGrpCd')
            console.log('addUserGrpCd', col1)
            col1.values = values
            col1.labels = labels
            this.gridObj3.gridView.setColumn(col1)
        },
        // 현재일자 확인(yyyy-mm-dd)
        getToday() {
            return moment().format('YYYY-MM-DD') ?? ''
        },

        //유효검사
        btn_chkUser_OnClick() {
            if (_.isEmpty(this.div_PSMbase.edt_UserCd)) {
                this.showTcComAlert('사번을 입력해주세요')
                return
            }
            console.log('this.basUsmUserInfoVo[0]', this.basUsmUserInfoVo[0])
            let param = {
                sktId: this.basUsmSktIdVo.sktId ? this.basUsmSktIdVo.sktId : '',
                userId: this.basUsmSktIdVo.sktId
                    ? this.basUsmSktIdVo.userId
                    : this.searchSsoIdParam.edt_UserId,
                userCd: this.div_PSMbase.edt_UserCd
                    ? this.div_PSMbase.edt_UserCd
                    : '',
                sktIdNm: this.basUsmSktIdVo.sktIdNm
                    ? this.basUsmSktIdVo.sktIdNm
                    : '',
                useYn: this.basUsmSktIdVo.useYn ? this.basUsmSktIdVo.useYn : '',
                rmks: this.div_PSMbase.edt_Rmks
                    ? this.div_PSMbase.edt_Rmks
                    : '',
                sktUserId: this.basUsmSktIdVo.sktUserId
                    ? this.basUsmSktIdVo.sktUserId
                    : '',
                orgCd: this.basUsmUserInfoVo.orgCd
                    ? this.basUsmUserInfoVo.orgCd
                    : '',
                loginUserId: this.basUsmUserInfoVo.portalUserId
                    ? this.basUsmUserInfoVo.portalUserId
                    : '',
                userNm: this.basUsmUserInfoVo.userNm
                    ? this.basUsmUserInfoVo.userNm
                    : '',
                authTypCd: 'string',
                get__rowState: 'string',
            }

            // // 수정
            // if (this.basUsmUserInfoVo) {
            //     param = { ...this.basUsmUserInfoVo[0] }
            // }
            // // 신규
            // else if (!this.basUsmUserInfoVo[0].userId) {
            //     // param.userId = this.searchSsoIdParam.edt_UserId
            //     // param.userCd = this.div_PSMbase.edt_UserCd
            // }

            API.getChkUser(param).then((result) => {
                console.log('result : ', result)

                this.bUserGrpChk = true // 체크 초기화

                if (result.chkUser[0].cntIf == 0) {
                    this.bUserGrpChk = false // 체크 초기화
                    this.showTcComAlert('유효한 사번이 아닙니다.')
                    return false
                }
                if (result.chkUser[0].cntUser != 0) {
                    this.bUserGrpChk = false // 체크 초기화
                    this.showTcComAlert('중복된 사번입니다.')
                    return false
                }
                if (result.chkUser[0].cntBi == 0) {
                    this.bUserGrpChk = false // 체크 초기화
                    this.showTcComAlert(
                        '사용자그룹을 매핑할 정보가 없습니다. PI팀에 문의하세요. '
                    )
                    return false
                }
                if (result.userGrpSet.length > 0) {
                    this.searchAuthOrgTreeParam.orgCd =
                        result.userGrpSet[0].orgCd
                    this.searchAuthOrgTreeParam.orgNm =
                        result.userGrpSet[0].orgNm
                    this.reqParam.userGrp = result.userGrpSet[0].userGrpCd
                    this.searchForm.dealcoCd = result.userGrpSet[0].dealcoCd
                    this.searchForm.dealcoNm = result.userGrpSet[0].dealcoNm
                }
                if (result.basUsmUserHrInfoVo.length > 0) {
                    // 원 소속조직
                    //HR 정보 조회
                    this.basUsmUserHrInfoVo = result.basUsmUserHrInfoVo
                    this.div_PSMbase.biId = result.basUsmUserHrInfoVo[0].biId
                    this.gridObj5.setRows(result.basUsmUserHrInfoVo)
                }

                if (result.basUsmUserInfoVo.length > 0) {
                    this.div_PSMbase.edt_UserCd =
                        result.basUsmUserInfoVo[0].userCd
                    this.div_PSMbase.cmb_userSt =
                        result.basUsmUserInfoVo[0].userStCd

                    this.div_PSMbase.entDt = result.basUsmUserInfoVo[0].entDt
                        ? moment(result.basUsmUserInfoVo[0].entDt).format(
                              'YYYY-MM-DD'
                          )
                        : ''
                    this.div_PSMbase.retirDt = result.basUsmUserInfoVo[0]
                        .retirDt
                        ? moment(result.basUsmUserInfoVo[0].retirDt).format(
                              'YYYY-MM-DD'
                          )
                        : ''
                    this.div_base.chk_effUserYn =
                        result.basUsmUserInfoVo[0].userStCd === '1' ? 'Y' : 'N'
                }
            })
        },

        // @description    : 사번 변경 시 유효검사 초기화
        edt_UserCd_OnChanged() {
            console.log('사번 변경')
            this.bUserGrpChk = false
            // CommonUtil.clearPage(this, 'div_PSMbase')
            // this.div_base.chk_effUserYn = 'N'
        },

        //메일계정 선택 시
        cmb_mailList_OnChanged(e) {
            console.log('cmb_mailList_OnChangedcmb_mailList_OnChanged', e)
            // if (e == null || e == '') {
            //     this.email2Disabled = true
            //     this.div_PSMbase.cmb_mailList = ''
            // } else if (e == '99') {
            //     this.email2Disabled = false
            // } else {
            //     //this.ds_user.edt_Email2.Text = this.div_base.cmb_mailList.Text
            //     this.div_PSMbase.edt_Email2 =
            //         this.div_PSMbase.cmb_mailList.commCdValNm
            //     this.email2Disabled = true
            // }
            _.forEach(this.$refs.emailList.dCommItemList, (data) => {
                if (_.isEqual(e, data.commCdVal)) {
                    this.div_PSMbase.edt_Email2 = data.commCdValNm
                }
            })
            // if (_.isEqual(e, '99')) {
            //     // this.isEmail = false
            //     this.div_PSMbase.edt_Email2 = ''
            // } else {
            //     // this.isEmail = true
            // }
        },

        cmb_userSt_OnChanged: (e) => {
            console.log('cmb_userSt_OnChanged', e)
        },

        // 저장
        onSave() {
            this.gridObj1.gridView.commit()
            this.gridObj2.gridView.commit()
            this.gridObj3.gridView.commit()
            this.gridObj4.gridView.commit()
            this.f_userCnt()
        },

        f_userCnt() {
            // 추가정보 등록/수정
            // this.saveAddInfo()

            // 사용자 등록/수정
            this.f_save()
        },

        f_save() {
            if (this.pInStatus == 'M' && !_.isEmpty(this.pInUserId)) {
                this.df_update()
            }
            if (this.pInStatus == 'N' || this.pInStatus == 'P') {
                this.df_save()
            }
        },

        // 상세보기 및 비밀번호 수정
        async df_update() {
            if (this.lf_ValidSave() == false) return

            let sktList = []

            // 삭제정보저장
            if (this.gridData2._delRows && this.gridData2._delRows.length > 0) {
                for (let idx = 0; idx < this.gridData2._delRows.length; idx++) {
                    if (this.gridData2._delRows[idx].sktId) {
                        sktList.push(this.gridData2._delRows[idx])
                    }
                }
            }

            // Swing ID 정보 저장
            let grid4CreatedIndexArr =
                this.gridObj4.dataProvider.getStateRows('created')
            let grid4UpdatedIndexArr =
                this.gridObj4.dataProvider.getStateRows('updated')

            for (let idx = 0; idx < grid4CreatedIndexArr.length; idx++) {
                let getJson = this.gridObj4.dataProvider.getJsonRow(
                    grid4CreatedIndexArr[idx]
                )
                // getJson.sktId = this.PV_USER_ID
                //     ? this.PV_USER_ID
                //     : this.searchSsoIdParam.edt_UserId
                // getJson.userId = ''
                // getJson.userCd = ''
                // getJson.sktIdNm = ''
                // getJson.useYn = getJson.staDt
                //     ? getJson.staDt.replaceAll('/', '')
                //     : ''
                // getJson.rmks = getJson.expirDt
                //     ? getJson.expirDt.replaceAll('/', '')
                //     : ''
                // getJson.sktUserId = ''
                // getJson.orgCd = ''
                // getJson.loginUserId = ''
                // getJson.userNm = ''
                // getJson.authTypCd = ''
                getJson.__rowState = 'created'
                sktList.push(getJson)
            }
            for (let idx = 0; idx < grid4UpdatedIndexArr.length; idx++) {
                let getJson = this.gridObj4.dataProvider.getJsonRow(
                    grid4UpdatedIndexArr[idx]
                )
                getJson.sktId = this.basUsmSktIdVo[idx].sktId
                    ? this.basUsmSktIdVo[idx].sktId
                    : getJson.sktId
                //     ? this.PV_USER_ID
                //     : this.searchSsoIdParam.edt_UserId
                // getJson.userId = ''
                // getJson.userCd = ''
                // getJson.sktIdNm = ''
                // getJson.useYn = getJson.staDt
                //     ? getJson.staDt.replaceAll('/', '')
                //     : ''
                // getJson.rmks = getJson.expirDt
                //     ? getJson.expirDt.replaceAll('/', '')
                //     : ''
                // getJson.sktUserId = ''
                // getJson.orgCd = ''
                // getJson.loginUserId = ''
                // getJson.userNm = ''
                // getJson.authTypCd = ''
                getJson.__rowState = 'updated'
                sktList.push(getJson)
            }
            console.log('sktList', sktList)
            // this.ds_input.sktLst = sktList

            this.ds_input = {
                userId: this.PV_USER_ID,
                userNm: this.div_base.edt_UserNm,
                ptlEffUserYn: 'Y', // 판매점??
                // effUserYn: this.div_base.chk_effUserYn[0],
                effUserYn: this.div_base.chk_effUserYn,
                portalUserId: this.searchSsoIdParam.loginUserId,
                portalMappingYn: 'Y',
                userClCd: 'A',
                sktId: this.basUsmSktIdVo.sktId,
                userStCd: this.div_PSMbase.cmb_userSt,
                mblPhonNo: this.div_PSMbase.mblPhonNo,
                repMblPhonNo: this.div_PSMbase.repMblPhonNo,
                wphonNo: this.div_PSMbase.wphonNo,
                // email1: this.div_PSMbase.edt_Email1,
                // email2: this.div_PSMbase.edt_Email2,
                orgCd: this.searchAuthOrgTreeParam.orgCd,
                rmks: this.div_PSMbase.edt_Rmks
                    ? this.div_PSMbase.edt_Rmks
                    : '',
                updCnt: 'string',
                modDtm: this.getToday().replaceAll('/', ''),
                modUserId: this.PV_USER_ID,
                userGrpCd: this.reqParam.userGrp,
                attcClCd: parseInt(this.reqParam.cmb_attcCat),
                dealcoCd: this.searchForm.dealcoCd
                    ? this.searchForm.dealcoCd
                    : '',
                // 무선전화 repMblPhonNo로 합쳐짐?
                // mblPhonNo: '',
                mblPhonNo2: '',
                mblPhonNo3: '',
                //sms부분 삭제됨
                accSmsYn1: 'Y',
                accSmsYn2: 'Y',
                indirInfoPraAgreeYn: 'Y',
                userCd: this.div_PSMbase.edt_UserCd,
                dutyCd: 'A', //직무코드 AS-IS STELL
                compCd: 'A', //소속회사코드 AS-IS COMP
                pwdNo: '',
                orgHstYn: 'Y',
                userAuthHstYn: 'Y',
                ptlAuditUserId: '',
                ptlAuditDtm: '',
                ptlTransDtm: '',
                ptlEffStaDt: '',
                ptlEffEndDt: '',
                rpstyCd: 'A',
                entDt: this.div_PSMbase.entDt.replaceAll('/', ''),
                retirDt: this.div_PSMbase.retirDt.replaceAll('/', ''),
                sktLst: sktList,
                // get__rowState: 'string',
            }
            await API.updateUser(this.ds_input).then((result) => {
                console.log('저장result', result)
                if (result) {
                    // 추가정보 등록/수정
                    this.saveAddInfo()
                    // this.showTcComAlert('정상적으로 처리되었습니다.')
                    setTimeout(() => {
                        this.gridData = this.gridSetData() //초기화
                        this.$parent.onSearch()
                        this.onClose()
                    }, 2000)
                }
                // else {
                //     this.showTcComAlert(result.message)
                // }
            })
        },

        // 신규 사용자 추가
        df_save() {
            if (this.lf_ValidSave() == false) return

            console.log('사용자id 중복체크', this.ds_userid_chk)
            // 사용자id 중복체크
            if (this.ds_userid_chk == '') {
                this.showTcComAlert(
                    '중복확인 버튼으로 사용자ID 중복체크를 하십시오.'
                )
                return false
            }

            if (this.ds_userid_chk == 'Y') {
                //사용중일 경우
                this.showTcComAlert('사용자ID가 이미 존재합니다.')
                // alert('사용자ID가 이미 존재합니다.')
                // div_base.edt_userId.Text = ''
                // div_base.edt_userid.SetFocus()
                return false
            }

            // 추가정보 등록/수정
            // this.saveAddInfo()

            // Swing ID 정보 저장
            let grid4CreatedIndexArr =
                this.gridObj4.dataProvider.getStateRows('created')
            let addsktLst = []

            for (let idx = 0; idx < grid4CreatedIndexArr.length; idx++) {
                let getJson = this.gridObj4.dataProvider.getJsonRow(
                    grid4CreatedIndexArr[idx]
                )
                // getJson.sktId = this.PV_USER_ID
                //     ? this.PV_USER_ID
                //     : this.searchSsoIdParam.edt_UserId
                // getJson.userId = ''
                // getJson.userCd = ''
                // getJson.sktIdNm = ''
                // getJson.useYn = getJson.staDt
                //     ? getJson.staDt.replaceAll('/', '')
                //     : ''
                // getJson.rmks = getJson.expirDt
                //     ? getJson.expirDt.replaceAll('/', '')
                //     : ''
                // getJson.sktUserId = ''
                // getJson.orgCd = ''
                // getJson.loginUserId = ''
                // getJson.userNm = ''
                // getJson.authTypCd = ''
                getJson.__rowState = 'created'
                addsktLst.push(getJson)
            }

            this.ds_input = {
                userId: this.PV_USER_ID
                    ? this.PV_USER_ID
                    : this.searchSsoIdParam.edt_UserId,
                userCd: this.div_PSMbase.edt_UserCd,
                userNm: this.div_base.edt_UserNm,
                portalUserId: this.searchSsoIdParam.loginUserId,
                portalMappingYn: 'Y',
                userClCd: 'A',
                sktId: this.basUsmSktIdVo.sktId,
                // ptlEffUserYn: 'Y', // 판매점??
                userTypCd: '',
                userStCd: this.div_PSMbase.cmb_userSt,
                pwdNo: '',
                // effUserYn: this.div_base.chk_effUserYn[0],
                effUserYn: this.div_base.chk_effUserYn,
                mblPhonNo: this.div_PSMbase.mblPhonNo,
                repMblPhonNo: this.div_PSMbase.repMblPhonNo,
                wphonNo: this.div_PSMbase.wphonNo,
                // email1: this.div_PSMbase.edt_Email1,
                // email2: this.div_PSMbase.edt_Email2,
                orgCd: this.searchAuthOrgTreeParam.orgCd,
                dutyCd: 'A', //직무코드 AS-IS STELL
                rmks: this.div_PSMbase.edt_Rmks
                    ? this.div_PSMbase.edt_Rmks
                    : '',
                delYn: 'N',
                updCnt: '0',
                insUserId: this.searchSsoIdParam.edt_UserId,
                modDtm: this.getToday().replaceAll('/', ''),
                modUserId: this.PV_USER_ID,
                userGrpCd: this.reqParam.userGrp,
                attcClCd: parseInt(this.reqParam.cmb_attcCat),
                // 무선전화 repMblPhonNo로 합쳐짐?
                // mblPhonNo: '',
                mblPhonNo2: '',
                mblPhonNo3: '',
                //sms부분 삭제됨
                accSmsYn1: 'Y',
                accSmsYn2: 'Y',
                dealcoCd: this.searchForm.dealcoCd,
                indirInfoPraAgreeYn: 'Y',
                compCd: 'A', //소속회사코드 AS-IS COMP
                // portalMappingYn: 'N',
                ptlLoginUserId: this.searchSsoIdParam.loginUserId,
                ptlSysJobId: '',
                ptlOrgCd: '',
                ptlRelOrgCd: '',
                ptlUserTypCd: '',
                ptlHndStsCd: '',
                ptlEffStaDt: '',
                ptlEffEndDt: '',
                orgHstYn: 'Y',
                userAuthHstYn: 'Y',
                ptlAuditUserId: '',
                ptlAuditDtm: '',
                ptlTransDtm: '',
                ptlSysClCd: '',
                rpstyCd: 'A',
                entDt: this.div_PSMbase.entDt.replaceAll('/', ''),
                retirDt: this.div_PSMbase.retirDt.replaceAll('/', ''),
                addsktLst: addsktLst,
                // get__rowState: 'string',
            }

            API.addUser(this.ds_input).then((result) => {
                console.log('저장result', result)
                if (result) {
                    // 추가정보 등록/수정
                    this.saveAddInfo()
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    setTimeout(() => {
                        this.gridData = this.gridSetData() //초기화
                        this.$parent.onSearch()
                        this.onClose()
                    }, 2000)
                }
                // else {
                //     this.showTcComAlert(result.message)
                // }
            })
        },

        // 사용자 추가 정보 수정
        saveAddInfo() {
            this.gridObj1.gridView.commit()
            this.gridObj2.gridView.commit()
            this.gridObj3.gridView.commit()
            console.log('사용자 추가 정보 수정', this.gridData._delRows)
            let userUpdateParam = {}
            let addDealHisList = []
            let addOrgHisList = []

            // 삭제정보저장
            if (this.gridData._delRows.length > 0) {
                for (let idx = 0; idx < this.gridData._delRows.length; idx++) {
                    if (
                        this.gridData._delRows[idx].addUserGrpCd ||
                        this.gridData._delRows[idx].addOrgCd
                    ) {
                        addOrgHisList.push(this.gridData._delRows[idx])
                    } else {
                        addDealHisList.push(this.gridData._delRows[idx])
                    }
                }
            }

            // 추가근무지 저장
            let grid1CreatedIndexArr =
                this.gridObj1.dataProvider.getStateRows('created')
            let grid1UpdatedIndexArr =
                this.gridObj1.dataProvider.getStateRows('updated')
            console.log('grid1UpdatedIndexArr', grid1UpdatedIndexArr)
            for (let idx = 0; idx < grid1CreatedIndexArr.length; idx++) {
                let getJson = this.gridObj1.dataProvider.getJsonRow(
                    grid1CreatedIndexArr[idx]
                )
                getJson.userId = this.PV_USER_ID
                    ? this.PV_USER_ID
                    : this.searchSsoIdParam.edt_UserId
                getJson.hstSeq = ''
                getJson.serNo = ''
                // getJson.dealCoCd = ''
                getJson.staDt = getJson.staDt
                    ? getJson.staDt.replaceAll('/', '')
                    : ''
                getJson.expirDt = getJson.expirDt
                    ? getJson.expirDt.replaceAll('/', '')
                    : ''
                getJson.delYn = ''
                getJson.updCnt = ''
                getJson.insDtm = ''
                getJson.insUserId = ''
                getJson.modDtm = ''
                getJson.modUserId = ''
                getJson.menuId = ''
                getJson.__rowState = 'created'
                addDealHisList.push(getJson)
            }
            for (let idx = 0; idx < grid1UpdatedIndexArr.length; idx++) {
                let getJson = this.gridObj1.dataProvider.getJsonRow(
                    grid1UpdatedIndexArr[idx]
                )
                // getJson.addOrgCd = getJson.orgCd
                getJson.staDt = getJson.staDt.replaceAll('/', '')
                getJson.expirDt = getJson.expirDt.replaceAll('/', '')
                getJson.__rowState = 'updated'
                addDealHisList.push(getJson)
            }
            // 추가내부조직 정보 저장
            let grid2CreatedIndexArr =
                this.gridObj2.dataProvider.getStateRows('created')
            let grid2UpdatedIndexArr =
                this.gridObj2.dataProvider.getStateRows('updated')

            for (let idx = 0; idx < grid2CreatedIndexArr.length; idx++) {
                let getJson = this.gridObj2.dataProvider.getJsonRow(
                    grid2CreatedIndexArr[idx]
                )
                getJson.userId = this.PV_USER_ID
                    ? this.PV_USER_ID
                    : this.searchSsoIdParam.edt_UserId
                getJson.hstSeq = ''
                getJson.serNo = ''
                getJson.authTypCd = '1'
                getJson.addUserGrpCd = ''
                // getJson.addOrgCd = getJson.orgCd
                getJson.staDt = getJson.staDt
                    ? getJson.staDt.replaceAll('/', '')
                    : ''
                getJson.expirDt = getJson.expirDt
                    ? getJson.expirDt.replaceAll('/', '')
                    : ''
                getJson.delYn = ''
                getJson.updCnt = ''
                getJson.insDtm = ''
                getJson.insUserId = ''
                getJson.modDtm = ''
                getJson.modUserId = ''
                getJson.orgClCd = ''
                getJson.prodMenuId = ''
                getJson.__rowState = 'created'
                addOrgHisList.push(getJson)
            }
            for (let idx = 0; idx < grid2UpdatedIndexArr.length; idx++) {
                let getJson = this.gridObj2.dataProvider.getJsonRow(
                    grid2UpdatedIndexArr[idx]
                )
                // getJson.addOrgCd = getJson.orgCd
                getJson.authTypCd = '1'
                getJson.staDt = getJson.staDt.replaceAll('/', '')
                getJson.expirDt = getJson.expirDt.replaceAll('/', '')
                getJson.__rowState = 'updated'
                addOrgHisList.push(getJson)
            }
            //추가사용자그룹 저장
            let grid3CreatedIndexArr =
                this.gridObj3.dataProvider.getStateRows('created')
            let grid3UpdatedIndexArr =
                this.gridObj3.dataProvider.getStateRows('updated')
            console.log('grid3CreatedIndexArr', grid3CreatedIndexArr)
            console.log('grid3UpdatedIndexArr', grid3UpdatedIndexArr)

            for (let idx = 0; idx < grid3CreatedIndexArr.length; idx++) {
                let getJson = this.gridObj3.dataProvider.getJsonRow(
                    grid3CreatedIndexArr[idx]
                )
                getJson.userId = this.PV_USER_ID
                    ? this.PV_USER_ID
                    : this.searchSsoIdParam.edt_UserId
                getJson.hstSeq = ''
                getJson.serNo = ''
                getJson.authTypCd = '2'
                // getJson.addUserGrpCd = ''
                getJson.addOrgCd = ''
                getJson.staDt = getJson.staDt
                    ? getJson.staDt.replaceAll('/', '')
                    : ''
                getJson.expirDt = getJson.expirDt
                    ? getJson.expirDt.replaceAll('/', '')
                    : ''
                getJson.delYn = ''
                getJson.updCnt = ''
                getJson.insDtm = ''
                getJson.insUserId = ''
                getJson.modDtm = ''
                getJson.modUserId = ''
                getJson.orgClCd = ''
                getJson.prodMenuId = ''
                getJson.__rowState = 'created'
                addOrgHisList.push(getJson)
            }
            for (let idx = 0; idx < grid3UpdatedIndexArr.length; idx++) {
                let getJson = this.gridObj3.dataProvider.getJsonRow(
                    grid3UpdatedIndexArr[idx]
                )
                // getJson.addOrgCd = getJson.orgCd
                getJson.authTypCd = '2'
                getJson.staDt = getJson.staDt.replaceAll('/', '')
                getJson.expirDt = getJson.expirDt.replaceAll('/', '')
                getJson.__rowState = 'updated'
                addOrgHisList.push(getJson)
            }

            // console.log('deletedList', deletedList)
            //추가 근무지 조회 파람
            let addDealHisVo = this.basUsmAddDealHisVo
                ? this.basUsmAddDealHisVo
                : []
            console.log('addDealHisVo', addDealHisVo)
            //추가 그룹/조직 조회 파람
            let addOrgHisVo = this.basUsmAddOrgHisVo
                ? this.basUsmAddOrgHisVo
                : []
            console.log('addOrgHisVo', addOrgHisVo)

            userUpdateParam = {
                basUsmAddDealHisVo: addDealHisList,
                basUsmAddOrgHisVo: addOrgHisList,
            }
            console.log('userUpdateParam', userUpdateParam)
            API.updateAddUserInfo(userUpdateParam).then((resultData) => {
                console.log(resultData)
                //사용자상세정보 재조회
                this.getUserInfo()
            })
        },

        // 소속유형 이벤트
        cmb_attcCat_OnChanged(e) {
            // CommonUtil.clearPage(this, 'div_PSMbase')
            //소속구분이 임직원이거나 외부사용자이고 사용자 수정일 경우
            console.log(e)
            this.commUserGrpList = []

            if ((e == '1' || e == '3') && this.pInStatus == 'M') {
                this.disabledEdt_UserCd = false
            }
            if (e != '1' && e != '3' && this.pInStatus == 'M') {
                this.disabledEdt_UserCd = true
            }

            //협력구성원일때만 소속회사 활성
            // if (e == "3") {

            //     Static6.Visible = true;
            //     cmb_comp.Visible = true;
            // } else {
            //     // Static6.Visible = false;
            //     cmb_comp.Visible = false;
            //     cmb_comp.value = "";
            // }

            if (e == '1') {
                this.disabledUserGrp = true
                this.disabledChkUserBtn = false
                this.disabledAuthOrg = true
                this.disabledEdt_UserCd = false
            } else {
                this.disabledUserGrp = false
                this.disabledChkUserBtn = true
                this.disabledAuthOrg = false
                this.disabledEdt_UserCd = true
                // this.div_PSMbase.edt_UserCd = ''
            }

            //소속구분이 외부사용자일 경우
            // if (e == '4') {
            //     this.disabledDealco = false
            // }
            if (e != '1') {
                this.disabledDealco = false
            } else {
                this.disabledDealco = true
            }

            // if(!uf_isNull(strCode)) {
            //     ds_user_grp.Filter("ADD_INFO_01=='"+ strCode +"'");
            // } else {
            //     ds_user_grp.UnFilter();
            // }

            // if(!uf_isNull(div_user.cmb_attcCat.value) && div_user.cmb_attcCat.value != "1") {
            //     div_user.cmb_UserGrp.Enable = true;
            //     div_user.cmb_UserGrp.value = "";
            // } else {
            //     div_user.cmb_UserGrp.Enable = false;
            //     div_user.cmb_UserGrp.value = "";
            // }
            if (e == '') {
                this.reqParam.userGrp = ''
                this.commUserGrpList = this.commUserGrpOriginList
                this.disabledUserGrp = true
            } else {
                // 소속유형에 따른 권한그룹 combobox filter
                this.commUserGrpList = this.commUserGrpOriginList.filter(
                    (item) => item['attcClCd'] == e
                )
                this.reqParam.userGrp = ''
            }

            CommonUtil.clearPage(this, 'div_PSMbase')
            if (this.pInStatus == 'N') {
                this.div_PSMbase.cmb_userSt = '1'
            } else {
                this.div_PSMbase.cmb_userSt = this.basUsmUserInfoVo[0].userStCd
            }
        },

        lf_ValidSave() {
            // var sPwd = ds_user.GetColumn(0, 'pwd')

            if (
                _.isEmpty(this.reqParam.cmb_attcCat) ||
                this.reqParam.cmb_attcCat === '0'
            ) {
                this.showTcComAlert('소속유형을 선택하십시오.')
                return false
            }

            // 사용자그룹 임직원, 유효성체크 x 인 경우
            if (this.reqParam.cmb_attcCat == '1' && this.bUserGrpChk == false) {
                this.showTcComAlert('임직원인 경우 유효성검사 필수입니다.')
                return false
            }

            // if (_.isEmpty(this.searchSsoIdParam.edt_UserId)) {
            //     this.showTcComAlert('사용자ID를 입력하십시오.')
            //     return false
            // }

            // if (_.isEmpty(this.div_base.edt_UserNm)) {
            //     this.showTcComAlert('이름을 입력하십시오.')
            //     return false
            // }

            if (
                this.reqParam.cmb_attcCat != '1' &&
                _.isEmpty(this.reqParam.userGrp)
            ) {
                this.showTcComAlert('권한그룹을 선택하십시오.')
                return false
            }

            if (
                this.reqParam.cmb_attcCat != '1' &&
                _.isEmpty(this.searchAuthOrgTreeParam.orgCd)
            ) {
                this.showTcComAlert('관리조직을 선택하십시오.')
                return false
            }

            // if (_.isEmpty(this.div_PSMbase.cmb_userSt)) {
            //     this.showTcComAlert('사용자상태를 선택하십시오.')
            //     return false
            // }

            // if (_.isEmpty(this.div_base.chk_agreeYn)) {
            //     this.showTcComAlert('개인정보활용동의를 선택하십시오.')
            //     return false
            // }

            if (
                _.isEmpty(this.div_PSMbase.edt_UserCd) &&
                this.reqParam.cmb_attcCat == '1' &&
                this.div_base.chk_effUserYn == 'Y'
            ) {
                this.showTcComAlert('사번을 입력하십시오')
                // div_base.edt_UserCd.SetFocus()
                return false
            }

            //소속구분이 임직원이면 숫자7자리
            // if (
            //     div_user.cmb_attcCat.value == '1' &&
            //     div_base.chk_EffUserYn.value == 'Y'
            // ) {
            //     //숫자
            //     if (uf_toInt(div_base.edt_UserCd.value) != 0) {
            //         if (div_base.edt_UserCd.value.length != 7) {
            //             this.showTcComAlert('사번란에 7자리입력하세요.')
            //             return false
            //         }
            //     } else {
            //         this.showTcComAlert('사번란에 숫자만입력하세요.')
            //         return false
            //     }
            //     //협력구성원
            // } else if (
            //     div_user.cmb_attcCat.value == '3' &&
            //     div_base.chk_EffUserYn.value == 'Y'
            // ) {
            //     //그린피플 선택 시 사번 항목 숫자 10자리만 입력/저장
            //     if (cmb_comp.value == '1') {
            //         if (uf_toInt(div_base.edt_UserCd.value) != 0) {
            //             if (div_base.edt_UserCd.value.length != 10) {
            //                 this.showTcComAlert('사번란에 10자리입력하세요.')
            //                 return false
            //             }
            //         } else {
            //             this.showTcComAlert('사번란에 숫자만입력하세요.')
            //             return false
            //         }
            //         //제니엘 선택 시 사번 항목 알파벳 E + 숫자6자리(총 7자리)만 입력/저장
            //     } else if (cmb_comp.value == '2') {
            //         if (div_base.edt_UserCd.value.SubStr(0, 1) != 'E') {
            //             this.showTcComAlert('사번 시작을 E로 구성해주세요.')
            //             return false
            //         }
            //         if (div_base.edt_UserCd.value.length != 7) {
            //             this.showTcComAlert('사번란에 E + 숫자6자리입력하세요.')
            //             return false
            //         }
            //         if (uf_toInt(div_base.edt_UserCd.value.SubStr(1, 7)) == 0) {
            //             this.showTcComAlert('사번란에 E + 숫자6자리입력하세요.')
            //             return false
            //         }

            //         //유니에스 선택 시 사번 항목 숫자 8자리만 입력/저장
            //     } else if (cmb_comp.value == '3') {
            //         if (uf_toInt(div_base.edt_UserCd.value) != 0) {
            //             if (div_base.edt_UserCd.value.length != 8) {
            //                 this.showTcComAlert('사번란에 8자리입력하세요.')
            //                 return false
            //             }
            //         } else {
            //             this.showTcComAlert('사번란에 숫자만입력하세요.')
            //             return false
            //         }
            //     } else if (cmb_comp.value == '4') {
            //         if (div_base.edt_UserCd.value.SubStr(0, 2) != 'NJ') {
            //             this.showTcComAlert('사번 시작을 NJ로 구성해주세요.')
            //             return false
            //         }
            //         if (div_base.edt_UserCd.value.length != 7) {
            //             this.showTcComAlert('사번란에 NJ + 숫자5자리입력하세요.')
            //             return false
            //         }
            //         if (uf_toInt(div_base.edt_UserCd.value.SubStr(2, 7)) == 0) {
            //             this.showTcComAlert('사번란에 NJ + 숫자5자리입력하세요.')
            //             return false
            //         }
            //     }
            // }

            // //개인정보활용동의 선택
            // if (div_base.chk_ageeYn.Value == 'N') {
            //     this.showTcComAlert('개인정보활용동의를 선택하십시오.')
            //     div_base.chk_ageeYn.SetFocus()
            //     return false
            // }

            // if (ds_user.GetUpdate() == false) {
            //     this.showTcComAlert(MSG_00133) // "변경사항이 없습니다.";
            //     return false
            // }

            // if (div_base.edt_Email1.Text == '') {
            //     this.showTcComAlert(MSG_01018) //E-mail을 입력해주십시오.
            //     div_base.edt_Email1.SetFocus()
            //     return false
            // }

            // if (div_base.edt_Email2.Text == '') {
            //     this.showTcComAlert(MSG_01018) //E-mail을 입력해주십시오.
            //     div_base.edt_Email2.SetFocus()
            //     return false
            // }
            // if (
            //     div_base.edt_Email1.Text != '' &&
            //     div_base.edt_Email2.Text != ''
            // ) {
            //     if (
            //         !uf_checkEmailAddr(
            //             div_base.edt_Email1.Text +
            //                 '@' +
            //                 div_base.edt_Email2.Text
            //         )
            //     ) {
            //         return false
            //     }
            // }

            // if (uf_IsNull(div_user.cdiv_deal.edt_dealCd.Text)) {
            //     // 외부사용자 근무지 필수
            //     if (div_user.cmb_attcCat.Value == '4') {
            //         this.showTcComAlert('근무지가 입력 되지 않았습니다.')
            //         return false
            //     }

            //     if (
            //         !Confirm(
            //             '근무지가 입력 되지 않았습니다. 저장 하시겠습니까?'
            //         )
            //     ) {
            //         return false
            //     }
            // }

            return true
        },

        // UKEY ID 정보 추가
        btn_add_ukey_OnClick() {
            console.log('btn_add_ukey_OnClick')
            this.gridObj4.gridView.commit()
            let rowData = {
                // addUserGrpCd: '',
                // staDt: this.getToday().replaceAll('-', '/'),
                // expirDt: this.lastDay,
            }
            let rowCount = this.gridObj4.dataProvider.getRowCount()
            this.gridObj4.dataProvider.insertRow(rowCount, rowData)
        },

        // UKEY ID 정보 삭제
        btn_del_ukey_OnClick() {
            console.log('btn_del_ukey_OnClick')
            console.log('************************')
            this.gridData2 = this.gridHeaderObj4.focusDelRow(this.gridData)
            console.log('행삭제gridData', this.gridData2)
        },
    },
}
</script>
