export default {
    namespaced: true,
    state: {
        // auth: {
        //     userId: '',
        //     userName: '',
        //     userEname: '',
        //     userType: '',
        //     role: '',
        // },
        // access_token: '',
        _objAuthList: [],
    },
    actions: {
        // saveAuth({ commit, dispatch }, { auth, access_token }) {
        //     dispatch('deleteAuth')

        //     if (auth !== undefined && access_token !== undefined) {
        //         commit('access_token', access_token)
        //         commit('auth', auth)
        //     }
        // },

        // deleteAuth({ commit }) {
        //     commit('auth', {
        //         userId: '',
        //         userName: '',
        //         userEname: '',
        //         userType: '',
        //         role: '',
        //     })

        //     commit('access_token', '')
        // },
        setObjAuthList({ commit }, objAuthList) {
            commit('SET_OBJ_AUTH_LIST', objAuthList)
        },
    },
    getters: {
        // auth: (state) => {
        //     return state.auth
        // },
        // access_token: (state) => {
        //     return state.access_token
        // },
        objAuthList: (state) => {
            return state._objAuthList
        },
    },
    mutations: {
        // auth: (state, payload) => {
        //     state.auth = payload
        // },
        // access_token: (state, payload) => {
        //     state.access_token = payload
        // },
        SET_OBJ_AUTH_LIST: (state, payload) => {
            state._objAuthList = payload
        },
    },
}
