import { ValueType } from 'realgrid'

export const GRID_DEAL_TAB = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealCoCl1Nm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktChnlCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealStatus',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sendYn1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sendYn2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'dealEndYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsUserId1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsUserNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sms1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsPhone1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'chagAmt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'baseAmt',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            width: '60',
            header: {
                text: '조직코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '180',
            header: {
                text: '조직명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealCoCl1Nm',
            fieldName: 'dealCoCl1Nm',
            type: 'data',
            width: '80',
            header: {
                text: '거래처구분',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealcoNm',
            fieldName: 'dealcoNm',
            type: 'data',
            width: '150',
            header: {
                text: '거래처명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'dealcoCd',
            fieldName: 'dealcoCd',
            type: 'data',
            width: '60',
            header: {
                text: '거래처코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'sktChnlCd',
            fieldName: 'sktChnlCd',
            type: 'data',
            width: '60',
            header: {
                text: '매장코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'dealStatus',
            fieldName: 'dealStatus',
            type: 'data',
            width: '100',
            header: {
                text: '거래상태',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'sendYn1',
            fieldName: 'sendYn1',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'N',
            },
            width: '60',
            renderer: {
                type: 'check',
                editable: true,
                trueValues: 'Y',
                falseValues: 'N',
                startEditOnClick: true,
            },
        },
        {
            name: 'sendYn2',
            fieldName: 'sendYn2',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Y',
            },
            width: '60',
            renderer: {
                type: 'check',
                editable: true,
                trueValues: 'Y',
                falseValues: 'N',
                startEditOnClick: true,
            },
        },
        {
            name: 'dealEndYn',
            fieldName: 'dealEndYn',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '휴점여부',
                showTooltip: false,
            },
            width: '60',
            renderer: {
                type: 'check',
                editable: true,
                trueValues: 'Y',
                falseValues: 'N',
                startEditOnClick: true,
            },
        },
        {
            name: 'smsUserId1',
            fieldName: 'smsUserId1',
            type: 'data',
            width: '60',
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'smsUserNm1',
            fieldName: 'smsUserNm1',
            type: 'data',
            width: '80',
            header: {
                text: '처리자명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'sms1',
            fieldName: 'sms1',
            type: 'data',
            width: '60',
            header: {
                text: '처리자정보',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'smsPhone1',
            fieldName: 'smsPhone1',
            type: 'data',
            width: '60',
            header: {
                text: '처리자연락처',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '60',
            header: {
                text: '수정자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '100',
            header: {
                text: '수정일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'chagAmt',
            fieldName: 'chagAmt',
            type: 'data',
            width: '80',
            header: {
                text: '현금잔액(직영점)',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
        },
        {
            name: 'baseAmt',
            fieldName: 'baseAmt',
            type: 'data',
            width: '80',
            header: {
                text: '직영점기초시재',
                showTooltip: false,
            },
            styleName: 'right-column',
            editable: false,
        },
    ],
    layout: [
        'rowNum',
        'orgNm',
        //'orgCd',
        'sktChnlCd',
        'dealcoCd',
        'dealcoNm',
        'dealCoCl1Nm',
        'dealStatus',
        'chagAmt',
        'baseAmt',
        {
            name: '일마감여부',
            direction: 'horizontal',
            items: ['sendYn1', 'sendYn2'],
        },
        'dealEndYn',
        'modUserNm',
        'modDtm',
    ],
}

export const GRID_ORG_TAB = {
    fields: [
        {
            fieldName: 'rowNum',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sendYn1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sendYn2',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsUserId1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsUserNm1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sms1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'smsPhone1',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'modDtm',
            dataType: ValueType.TEXT,
        },
    ],

    columns: [
        {
            name: 'rowNum',
            fieldName: 'rowNum',
            type: 'data',
            width: '50',
            header: {
                text: 'No',
                showTooltip: false,
            },
            numberFormat: '#,##0',
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            width: '80',
            header: {
                text: '조직코드',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
            visible: false,
        },
        {
            name: 'orgNm',
            fieldName: 'orgNm',
            type: 'data',
            width: '220',
            header: {
                text: '조직명',
                showTooltip: false,
            },
            styleName: 'left-column',
            editable: false,
        },
        {
            name: 'sendYn1',
            fieldName: 'sendYn1',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'N',
            },
            renderer: {
                type: 'check',
                editable: true,
                trueValues: 'Y',
                falseValues: 'N',
                startEditOnClick: true,
            },
        },
        {
            name: 'sendYn2',
            fieldName: 'sendYn2',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: 'Y',
            },
            renderer: {
                type: 'check',
                editable: true,
                trueValues: 'Y',
                falseValues: 'N',
                startEditOnClick: true,
            },
        },
        {
            name: 'smsUserId1',
            fieldName: 'smsUserId1',
            type: 'data',
            width: '60',
            header: {
                text: '처리자ID',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'smsUserNm1',
            fieldName: 'smsUserNm1',
            type: 'data',
            width: '60',
            header: {
                text: '처리자명',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'sms1',
            fieldName: 'sms1',
            type: 'data',
            width: '60',
            header: {
                text: '처리자정보',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'smsPhone1',
            fieldName: 'smsPhone1',
            type: 'data',
            width: '60',
            header: {
                text: '처리자연락처',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'modUserNm',
            fieldName: 'modUserNm',
            type: 'data',
            width: '60',
            header: {
                text: '수정자',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
        {
            name: 'modDtm',
            fieldName: 'modDtm',
            type: 'data',
            width: '60',
            header: {
                text: '수정일시',
                showTooltip: false,
            },
            styleName: 'center-column',
            editable: false,
        },
    ],
    layout: [
        'rowNum',
        'orgNm',
        //'orgCd',
        {
            name: '일마감여부',
            direction: 'horizontal',
            items: ['sendYn1', 'sendYn2'],
        },
        'modUserNm',
        'modDtm',
    ],
}
