export default {
    _agencyTypList: [],
    _agencyPtnList: [],
    _agencyList: [],
    _searchParam: {},
    _searchDateModel: '', // 조회기준일(v-model)
}
