<template>
    <div class="content">
        <h1>거래종료확인서발행요청</h1>
        <ul class="btn_area top">
            <li class="left">
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="onCancel"
                    >취소</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="getDealEndConfimPrint()"
                    >출력-거래종료확인서</TCComButton
                >
                <TCComButton
                    :eOutlined="true"
                    eClass="btn_ty"
                    :objAuth="this.objAuth"
                    @click="getDisDtlPrint(1)"
                    >출력-재고세부리스트</TCComButton
                >
            </li>
            <RealReportPopup
                v-if="reportShow"
                :parentParam="viewParam"
                :dialogShow.sync="reportShow"
                :dialogWidth="reportWidth"
            />
            <li class="right">
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onResetPage"
                    :objAuth="this.objAuth"
                >
                    초기화
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onSearch"
                    :objAuth="this.objAuth"
                >
                    조회
                </TCComButton>
                <TCComButton
                    color="btn2"
                    eClass="btn_ty01"
                    @click="onRgstClick"
                    :objAuth="this.objAuth"
                >
                    신규
                </TCComButton>
                <BasPrmDealEndNeedReqRgstPopup
                    v-if="showRgstPopup"
                    :parentParam="parentData"
                    :rows="resultshowRgstPopupRows"
                    :dialogShow.sync="showRgstPopup"
                />
            </li>
        </ul>

        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div3">
                    <TCComDatePicker
                        v-if="v_saleDtm.visible"
                        labelName="요청일자"
                        v-model="div_search.saleDtm"
                        elementClass="iteminput"
                        calType="DP"
                        :disabled="!v_saleDtm.enable"
                        @change="onSaleDtmChange"
                    />
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="div_search.orgNm"
                        :codeVal.sync="div_search.orgCd"
                        labelName="소속조직"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onAuthOrgTreeEnterKey"
                        @appendIconClick="onAuthOrgTreeIconClick"
                        @input="onAuthOrgTreeInput"
                        :eRequired="true"
                    />
                    <BasBcoAuthOrgTreesPopup
                        v-if="showBcoAuthOrgTrees"
                        :parentParam="div_search"
                        :rows="resultAuthOrgTreeRows"
                        :dialogShow.sync="showBcoAuthOrgTrees"
                        @confirm="onAuthOrgTreeReturnData"
                    />
                </div>
                <div class="formitem div3">
                    <TCComInputSearchText
                        v-model="div_search.dealcoNm"
                        :codeVal.sync="div_search.dealcoCd"
                        labelName="거래처코드"
                        placeholder="입력해주세요"
                        :disabledAfter="true"
                        :objAuth="objAuth"
                        @enterKey="onDealcoEnterKey"
                        @appendIconClick="onDealcoIconClick"
                        @input="onDealcoInput"
                    />
                    <BasBcoDealcosPop
                        v-if="showBasBcoDealcos"
                        :parentParam="div_search"
                        :rows="resultDealcoRows"
                        :dialogShow.sync="showBasBcoDealcos"
                        @confirm="onDealcoReturnData"
                    />
                </div>
            </div>
            <div class="searchform">
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="유형"
                        v-model="div_search.cmb_reqTyp"
                        :itemList="ds_reqTyp"
                        :itemText="'text'"
                        :itemValue="'value'"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div3">
                    <TCComComboBox
                        labelName="요청상태"
                        v-model="div_search.cmb_reqStCd"
                        :itemList="ds_reqCd"
                        :itemText="'text'"
                        :itemValue="'value'"
                        :objAuth="this.objAuth"
                        :addBlankItem="true"
                        blankItemText="전체"
                        blankItemValue=""
                    ></TCComComboBox>
                </div>
                <div class="formitem div3">
                    <TCComInput
                        v-model="div_search.edt_reqUserId"
                        labelName="요청자명"
                        :objAuth="objAuth"
                        @enterKey="onSearch"
                    >
                    </TCComInput>
                </div>
            </div>
        </div>

        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="거래종료확인서발행관리 목록"
                :gridObj="gridObj"
                :isPageRows="true"
                :isDelRow="false"
                :isExceldown="true"
                :isPageCnt="true"
                :isNextPage="false"
                @excelDownBtn="onExcelDown"
            />
            <TCRealGrid
                id="grid1"
                ref="grid1"
                :fields="view.fields"
                :columns="view.columns"
                :editable="true"
                :updatable="true"
                :isGridReSize="true"
            />
            <TCComPaging
                :totalPage="gridData.totalPage"
                :apiFunc="getDealEndConfimReq"
                :rowCnt="rowCnt"
                :gridObj="gridObj"
                @input="chgRowCnt"
            />
        </div>
    </div>
</template>

<style></style>

<script>
import { CommonGrid } from '@/utils'
// import CommonUtil from '@/utils/CommonUtil.js'
import CommonMsg from '@/utils/CommonMsg'
import commonApi from '@/api/common/prototype'
import _ from 'lodash'
import moment from 'moment'
import { HEADER } from '@/const/grid/bas/prm/basPrmDealEndNeedReqHeader'
import API from '@/api/biz/bas/prm/basPrmDealEndNeedReq'
// import sampleReport1 from './report-sample-1.json'
import dealEndReport from './dealEndReport.json'
import disDtlReport from './disDtlReport.json'
import RealReportPopup from '@/components/common/RealReportPopup'
import 'realreport/dist/realreport.css'
//====================내부조직팝업(권한)팝업============================================
import BasBcoAuthOrgTreesPopup from '@/components/common/BasBcoAuthOrgTreesPopup'
import basBcoAuthOrgTreesApi from '@/api/biz/bas/bco/basBcoAuthOrgTrees'
//====================================================================================
//====================내부거래처(권한조직)==============================================
import BasBcoDealcosPop from '@/components/common/BasBcoDealcosPopup'
import basBcoDealcosApi from '@/api/biz/bas/bco/basBcoDealcos'
//====================================================================================
//====================거래종료확인서 발행요청 등록팝업==============================================
import BasPrmDealEndNeedReqRgstPopup from './BasPrmDealEndNeedReqRgstPopup'
//====================================================================================
import CommonMixin from '@/mixins'
// import { msgTxt } from '@/const/msg.Properties'
/**************************************************************************************************************
 * 공통 LIB import 영역
 **************************************************************************************************************/
import { NewLib } from '@/views/newlib'
import attachedFileApi from '@/api/common/attachedFile'

export default {
    name: 'BasPrmDealEndNeedReq',
    components: {
        BasBcoAuthOrgTreesPopup,
        BasBcoDealcosPop,
        BasPrmDealEndNeedReqRgstPopup,
        RealReportPopup,
    },
    mixins: [CommonMixin],

    data() {
        return {
            // v_btn_del: { visible: false },
            gridData: this.gridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            view: HEADER,
            rowCnt: 30,
            ds_reqTyp: [
                { text: '전체', value: '' },
                { text: '확인필요(담당임원 결재)', value: '1' },
                { text: '일반', value: '2' },
            ],
            ds_reqCd: [
                { text: '전체', value: '' },
                { text: '요청', value: '1' },
                { text: '취소', value: '2' },
                { text: '승인', value: '3' },
                { text: '반려', value: '4' },
                { text: '기간만료', value: '5' },
            ],
            v_saleDtm: { visible: true, enable: true },
            //각각 엘리먼트 컴포넌트 v-model
            div_search: {
                saleDtm: [
                    moment(new Date()).format('YYYY-MM-01'),
                    NewLib.cf_today(),
                ],
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                dealcoCd: '',
                dealcoNm: '',
                cmb_reqTyp: '', //유형
                cmb_reqStCd: '', //요청상태
                edt_reqUserId: '', //요청자명
            },
            paramObj: {},
            ds_result: [],
            objAuth: {},
            selectedJsonData: {},
            selectedRow: '',
            //====================realReport=================================
            reportShow: false,
            report1: dealEndReport,
            // report2: disDtlReport,
            viewParam: {},
            reportWidth: '',
            //====================내부조직팝업(권한)팝업관련====================
            showBcoAuthOrgTrees: false, // 내부조직팝업(권한) 팝업 오픈 여부
            searchAuthOrgTreeParam: {
                orgCd: '', // 내부조직팝업(권한)코드
                orgNm: '', // 내부조직팝업(권한)명
                orgLvl: '',
            },
            resultAuthOrgTreeRows: [], // 내부조직팝업(권한) 팝업 오픈 여부
            //================================================================
            //====================내부거래처(권한조직)====================
            showBasBcoDealcos: false,
            searchForm: {
                dealcoCd: '', // 거래처코드
                dealcoNm: '', // 거래처명
            },
            resultDealcoRows: [],
            //====================//내부거래처(권한조직)==================
            //====================거래처종료확인서 발행요청 등록팝업====================
            showRgstPopup: false,
            // searchForm: {
            //     dealcoCd: '', // 거래처코드
            //     dealcoNm: '', // 거래처명
            // },
            resultshowRgstPopupRows: [],
            //====================//내부거래처(권한조직)==================
            colorCdList: [],
            prodMapClCdList: [],
            ds_prodMapList: [], // 조회시 데이터셋
            ds_detailList: [],
            ds_ZBAS_C_00810: [],
            parentData: {},
        }
    },

    created() {
        this.init()
        console.log('this.$route Detail: ', this.$route)
        // this.searchParam = this.$route.params.search
    },

    mounted() {
        console.log('menuInfo', this.menuInfo) //메뉴정보
        console.log('orgInfo', this.orgInfo) //조직정보
        console.log('userInfo', this.userInfo) //사용자정보
        console.log('authInfo', this.authInfo) // 권한정보(속성권한)

        // 삭제버튼 보이기 (임시 기존: =='P13'으로 바꿔야함)
        // if (this.userInfo.userGrpCd !== 'P13') {
        //     this.v_btn_del.visible = true
        // }

        this.gridObj = this.$refs.grid1
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.gridView.setColumnLayout(this.layout)
        this.gridObj.gridView.displayOptions.fitStyle = 'even' // 자동간격조정
        this.gridObj.setGridState(true)

        // dropDown name 사용위해 set
        // this.dropDownSetting()

        // this.gridObj.gridView.onCellEdited = (
        //     grid,
        //     itemIndex,
        //     dataRow,
        //     field
        // ) => {
        //     // var column = grid.columnByField('accDealcoNm')
        //     this.gridObj.gridView.commit()
        //     const getData = grid.getValue(itemIndex, field)
        //     console.log('getData', getData)

        //     this.selectedJsonData =
        //         this.gridObj.dataProvider.getJsonRow(dataRow)
        //     console.log('selectedJsonData', this.selectedJsonData)
        // }

        // 공통코드 API
        // PSNM 대표자명, 사옥주소
        commonApi.getCommonCodeList('ZBAS_C_00810').then((res) => {
            this.ds_ZBAS_C_00810 = res[0]
            console.log('ds_ZBAS_C_00810', res)
        })

        // 싱글클릭 시 저장데이터 SET
        this.gridObj.gridView.onCellClicked = (grid, clickData) => {
            this.selectedJsonData = this.gridObj.dataProvider.getJsonRow(
                clickData.dataRow
            )
            this.selectedRow = clickData.dataRow
            console.log('selectedJsonData', this.selectedJsonData)
            console.log('clickData.dataRow', clickData.dataRow)
        }

        // 더블클릭 시 등록팝업오픈
        this.gridObj.gridView.onCellDblClicked = (grid, clickData) => {
            console.log('등록팝업오픈', clickData)
            clearTimeout(this.clickState)
            const jsonData = this.gridObj.dataProvider.getJsonRow(
                clickData.dataRow
            )

            // 상세조회
            this.onUpdateClick(jsonData)
        }
        // 검색영역 소속조직 default값 셋팅
        this.div_search.orgCd = this.orgInfo.orgCd
        this.div_search.orgNm = this.orgInfo.orgNm
        this.div_search.orgLvl = this.orgInfo.orgLvl
        // 검색영역 거래처코드 default값 셋팅
        this.div_search.dealcoCd = this.userInfo.dealcoCd
        this.div_search.dealcoNm = this.userInfo.dealcoNm

        this.gridObj.gridView.onEditCommit = (grid) => {
            grid.editOptions.commitByCell = true
        }
    },

    methods: {
        init: function () {
            CommonMsg.$_log('init 함수호출')
            this.gridData = this.gridSetData()
        },
        gridSetData() {
            return new CommonGrid(0, this.rowCnt, '', '')
        },

        // 페이지 표시 행의 수 변경처리
        chgRowCnt(val) {
            this.rowCnt = val
        },

        // 그리드에 그룹명 dropdown셋팅 공통코드 api
        async dropDownSetting() {
            console.log('dropDownSetting')
            // 색상 set
            await this.dropDownCmmonCodes({
                key: 'ZBAS_C_00040',
                columnName: 'colorCd',
                option: '--선택--',
            })
            // 상품매핑구분 set
            await this.dropDownCmmonCodes({
                key: 'ZDIS_C_00370',
                columnName: 'prodMapClCd',
                option: '--선택--',
            })
        },

        // async dropDownCmmonCodes({ key, columnName, option }) {
        //     console.log('key columnName option', key, columnName, option)
        //     let result = await API.dropDownCmmonCodes_(key)
        //     console.log('result', result)
        //     if (columnName == 'colorCd') {
        //         this.colorCdList = result
        //         this.colorCdList2 = result
        //     }
        //     if (columnName == 'prodMapClCd') {
        //         this.prodMapClCdList = result
        //     }

        //     let values = []
        //     let labels = []
        //     values = result.map((a) => a.commCdVal)
        //     console.log('values', values)
        //     labels = result.map((a) => a.commCdValNm)
        //     console.log('labels', labels)
        // },

        //조회 버튼 이벤트
        onSearch: function () {
            this.gridObj.setRows([])
            this.gridData.totalPage = 0
            this.getDealEndConfimReq(1)
        },

        // 거래종료확인서발행요청 목록 조회
        getDealEndConfimReq(pageNum) {
            this.paramObj = {
                orgCd: this.div_search.orgCd, // 조직코드 'AB1310', //
                orgLvl: this.div_search.orgLvl, // 조직레벨
                orgNm: this.div_search.orgNm, // 조직명
                dealcoCd: this.div_search.dealcoCd, // 거래처코드'86516', //
                dealcoNm: this.div_search.dealcoNm, // 거래처명
                saleDtmFrom: this.div_search.saleDtm[0].replaceAll('-', ''), // 거래기간(시작)
                saleDtmTo: this.div_search.saleDtm[1].replaceAll('-', ''), // 거래기간(끝)
                reqStCd: this.div_search.cmb_reqStCd, // 요청코드
                reqUserId: this.div_search.edt_reqUserId, // 요청자Id
                reqTypCd: this.div_search.cmb_reqTyp, // 요청분류코드
            }
            this.paramObj.pageNum = pageNum
            this.paramObj.pageSize = this.rowCnt
            API.getDealEndConfimReq(this.paramObj).then((result) => {
                console.log('result : ', result)
                if (result.gridList.length > 0) {
                    this.gridObj.setRows(result.gridList)
                    this.ds_result = result.gridList

                    // 페이징 관련
                    this.gridObj.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting
                }
            })
        },

        //취소 버튼 이벤트
        onCancel: function () {
            this.gridObj.gridView.commit()
            let aprvCnt = 0
            let saveParam = []

            for (let idx = 0; idx < this.ds_result.length; idx++) {
                let getJson = this.gridObj.dataProvider.getJsonRow(idx)
                console.log('getJson' + getJson)
                getJson.reqStCd = getJson.reqStCd ? getJson.reqStCd : ''
                getJson.reqSeq = getJson.reqSeq ? getJson.reqSeq : ''
                getJson.aprvSeq = getJson.aprvSeq ? getJson.aprvSeq : ''
                getJson.__rowState = 'updated'
                if (getJson.chk == true && getJson.reqStCd == '요청') {
                    getJson.reqStCd = '2'
                    saveParam.push(getJson)
                    aprvCnt++
                }
            }

            if (aprvCnt == 0) {
                alert('요청 상태만 취소 가능합니다.')
                return
            }

            console.log('saveParam', saveParam)
            API.saveDealEndConfimReqCnl(saveParam).then((result) => {
                console.log('result : ', result)
                if (result !== null) {
                    this.showTcComAlert('정상적으로 처리되었습니다.')
                    // 매핑정보 재조회
                    this.onSearch()
                } else {
                    this.showTcComAlert(result.message)
                }
            })
        },

        // 초기화
        onResetPage() {
            // CommonUtil.clearPage(this.$router)
            this.div_search = {
                saleDtm: [NewLib.cf_today(), NewLib.cf_today()],
                orgCd: '',
                orgNm: '',
                orgLvl: '',
                dealcoCd: '',
                dealcoNm: '',
                cmb_reqTyp: '', //유형
                cmb_reqStCd: '', //요청상태
                edt_reqUserId: '', //요청자명
            }
            this.gridData = this.gridSetData()
            this.gridObj.dataProvider.clearRows()
        },

        // 재고세부 LIST조회
        getDisDtlPrint(pageNum) {
            if (this.ds_result.length === 0) {
                this.showTcComAlert(
                    '거래종료확인서 발행요청목록 선택 후 조회가능합니다'
                )
                return
            }
            let paramObj = {
                orgLvl: this.div_search.orgLvl, // 조직레벨
                orgCd: this.div_search.orgCd, //this.div_search.orgCd, // 조직코드
                dealcoCd: this.selectedJsonData.dealcoCd, //this.div_search.dealcoCd, // 거래처코드
                reqDtm: this.selectedJsonData.reqDtm.substr(0, 8), //this.div_search.saleDtm[0].replaceAll('-', ''), //
            }
            paramObj.pageNum = pageNum
            paramObj.pageSize = this.rowCnt

            API.getDisDtlPrint(paramObj).then((result) => {
                console.log('result : ', result)
                let reportData = {}
                if (result.gridList && result.gridList.length > 0) {
                    this.ds_detailList = result.gridList

                    // 페이징 관련
                    this.gridObj.setGridIndicator(result.pagingDto) //순번이 필요한경우 계산하는 함수
                    this.gridData = this.gridSetData() //초기화
                    this.gridData.totalPage = result.pagingDto.totalPageCnt // 총페이지수
                    this.gridHeaderObj.setPageCount(result.pagingDto) //Grid Row 가져올때 페이지정보 Setting

                    reportData = {
                        ds_detailList: {
                            values: result.gridList,
                        },
                    }
                }
                this.reportOpen(disDtlReport, reportData)
            })
        },

        // 거래종료확인서 조회
        getDealEndConfimPrint() {
            let paramObj = {
                dealcoCd: '', //this.div_search.dealcoCd, // 거래처코드
                seq: '',
            }
            let aprvCnt = 0

            for (let idx = 0; idx < this.ds_result.length; idx++) {
                let getJson = this.gridObj.dataProvider.getJsonRow(idx)
                console.log('getJson' + getJson)
                // getJson.reqStCd = getJson.reqStCd ? getJson.reqStCd : ''
                // getJson.reqSeq = getJson.reqSeq ? getJson.reqSeq : ''
                // getJson.dealcoCd = getJson.dealcoCd ? getJson.dealcoCd : ''

                if (getJson.chk == true && getJson.reqStCd == '승인') {
                    // getJson.reqStCd = '2'
                    // saveParam.push(getJson)
                    paramObj.seq = getJson.reqSeq ? getJson.reqSeq : ''
                    paramObj.dealcoCd = getJson.dealcoCd ? getJson.dealcoCd : ''
                    aprvCnt++
                }
            }
            if (aprvCnt == 0) {
                alert('처리할 대상이 없거나 승인 상태만 출력 가능합니다.')
                return
            } else if (aprvCnt > 1) {
                alert('1건씩 처리 바랍니다.')
                return
            } else if (aprvCnt == 1) {
                API.getDealEndConfimPrint(paramObj).then((result) => {
                    console.log('result : ', result)
                    let reportData = {}
                    if (result.length > 0) {
                        this.ds_dealEndList = result[0]

                        reportData = {
                            // ds_dealEnd: {
                            //     values: result[0],
                            // },
                            ds_dealEndList: {
                                values: {
                                    위탁계약_거래종료시점: result[0].printDay,
                                    TO_BOND_AMT: result[0].tdayBondBamt,
                                    위탁자: '피에스앤마케팅 주식회사',
                                    위탁자_사업자번호:
                                        this.ds_ZBAS_C_00810.addInfo3,
                                    위탁자_대표이사:
                                        this.ds_ZBAS_C_00810.addInfo1,
                                    위탁자_주소: this.ds_ZBAS_C_00810.addInfo2,
                                    위탁자_담당마케터: '',
                                    수탁자: result[0].dealCoNm,
                                    수탁자_사업자번호: result[0].bizNum,
                                    수탁자_매장주소: result[0].addr,
                                    수탁자_거래처대표자: result[0].repUserNm,
                                    수탁자_거래종료일: result[0].printDay,
                                },
                            },
                        }
                    }
                    // report1, '', 'dealEnd'
                    this.reportOpen(dealEndReport, reportData)
                })
            }
        },

        // report popup Open
        reportOpen(report, data, type) {
            console.log('report::', report)
            console.log('data::', data)
            console.log('type::', type)
            this.viewParam.report = report
            this.viewParam.data = data
            this.viewParam.name = this.fileName
            this.reportWidth = '1200px'
            // if (type == 'dealEndReport') {
            //     // this.getDealEndConfimPrint()
            //     this.reportWidth = '1200px'
            // } else {
            //     // this.getDisDtlPrint()
            //     this.reportWidth = '1200px'
            // }

            console.log('reportWidth::', this.reportWidth)

            this.reportShow = true
        },

        // 적용기간 변경 이벤트
        onSaleDtmChange(val) {
            console.log('onSaleDtmChange::::', val)
            this.div_search.saleDtm = val
        },

        onExcelDown() {
            // let paramObj = {
            //     orgLvl: this.div_search.orgLvl, // 조직레벨
            //     orgCd: this.div_search.orgCd, // 조직코드
            //     dealcoCd: this.div_search.dealcoCd, // 거래처코드
            // }
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/bas/prm/deal-end-condoc-req-excel',
                this.paramObj
            )
        },

        //===================== 내부조직팝업(권한)팝업관련 methods ================================
        // 내부조직팝업(권한) 정보 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부조직팝업(권한) 팝업 오픈
        getAuthOrgTreeList() {
            basBcoAuthOrgTreesApi
                .getAuthOrgTreeList(this.div_search)
                .then((res) => {
                    console.log('getAuthOrgTreeList then : ', res)
                    // 검색된 내부조직팝업(권한) 정보가 1건이면 TextField에 바로 설정
                    // 검색된 내부조직팝업(권한) 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부조직팝업(권한) 팝업 오픈
                    let cnt = 0

                    res.map((p) => {
                        if (p.orgLvl == '3') {
                            cnt++
                        }
                    })

                    if (cnt === 1) {
                        res.map((p) => {
                            this.div_search.orgCd = _.get(p, 'orgCd')
                            this.div_search.orgNm = _.get(p, 'orgNm')
                            this.div_search.orgLvl = _.get(p, 'orgLvl')
                        })
                    } else {
                        this.resultAuthOrgTreeRows = res
                        this.showBcoAuthOrgTrees = true
                    }
                })
        },
        // 내부조직팝업(권한) TextField 돋보기 Icon 이벤트 처리
        onAuthOrgTreeIconClick() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이 아니면 내부조직팝업(권한) 정보 조회
            // 그 이외는 내부조직팝업(권한) 팝업 오픈
            // if (!_.isEmpty(this.searchAuthOrgTreeParam.orgNm)) {
            //     this.getAuthOrgTreeList()
            // } else {
            this.showBcoAuthOrgTrees = true
            // }
        },
        // 내부조직팝업(권한) TextField 엔터키 이벤트 처리
        onAuthOrgTreeEnterKey() {
            // 내부조직팝업(권한) 팝업 Row 설정 Prop 변수 초기화
            this.resultAuthOrgTreeRows = []
            // 검색조건 내부조직팝업(권한)명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.div_search.orgNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부조직팝업(권한)명을 입력해주세요.'
                return
            }
            // 내부조직팝업(권한) 정보 조회
            this.getAuthOrgTreeList()
        },
        // 내부조직팝업(권한) TextField Input 이벤트 처리
        onAuthOrgTreeInput() {
            // 입력되는 값이 있으면 내부조직팝업(권한) 코드 초기화
            this.div_search.orgCd = ''
        },
        // 내부조직팝업(권한) 팝업 리턴 이벤트 처리
        onAuthOrgTreeReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.div_search.orgCd = _.get(retrunData, 'orgCd')
            this.div_search.orgNm = _.get(retrunData, 'orgNm')
            this.div_search.orgLvl = _.get(retrunData, 'orgLvl')
        },
        //===================== //내부조직팝업(권한)팝업관련 methods ================================
        //===================== 내부거래처(권한조직)팝업관련 methods ================================
        // 내부거래처-전체조직 조회 후 1건이면 TextField에 바로 설정하고 아니면 내부거래처-전체조직 팝업 오픈
        getDealcosList() {
            basBcoDealcosApi.getDealcosList(this.div_search).then((res) => {
                console.log('getDealcosList then : ', res)
                // 검색된 내부거래처-전체조직 정보가 1건이면 TextField에 바로 설정
                // 검색된 내부거래처-전체조직 정보가 1건이 아니면 검색된 정보 Prop에 넘겨 줄 변수에 설정 후 내부거래처-전체조직 팝업 오픈
                if (res.length === 1) {
                    this.div_search.dealcoCd = _.get(res[0], 'dealcoCd')
                    this.div_search.dealcoNm = _.get(res[0], 'dealcoNm')
                } else {
                    this.resultDealcoRows = res
                    this.showBasBcoDealcos = true
                }
            })
        },
        // 내부거래처-전체조직 TextField 돋보기 Icon 이벤트 처리
        onDealcoIconClick() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이 아니면 내부거래처-전체조직 정보 조회
            // 그 이외는 내부거래처-전체조직 팝업 오픈
            if (!_.isEmpty(this.div_search.dealcoNm)) {
                this.getDealcosList()
            } else {
                this.showBasBcoDealcos = true
            }
        },
        // 내부거래처-전체조직 TextField 엔터키 이벤트 처리
        onDealcoEnterKey() {
            // 내부거래처-전체조직 팝업 Row 설정 Prop 변수 초기화
            this.resultDealcoRows = []
            // 검색조건 내부거래처-전체조직명이 빈값이면 알림창 오픈
            if (_.isEmpty(this.div_search.dealcoNm)) {
                this.showAlertBool = true
                this.headerText = '검색조건 필수'
                this.alertBodyText = '내부거래처-전체조직명 입력해주세요.'
                return
            }
            // 내부거래처-전체조직 정보 조회
            this.getDealcosList()
        },
        // 내부거래처-전체조직 TextField Input 이벤트 처리
        onDealcoInput() {
            // 입력되는 값이 있으면 내부거래처-전체조직 코드 초기화
            this.div_search.dealcoCd = ''
        },
        // 내부거래처-전체조직 팝업 리턴 이벤트 처리
        onDealcoReturnData(retrunData) {
            console.log('retrunData: ', retrunData)
            this.div_search.dealcoCd = _.get(retrunData, 'dealcoCd')
            this.div_search.dealcoNm = _.get(retrunData, 'dealcoNm')
        },
        //===================== //내부거래처(권한조직)팝업관련 methods ================================
        // onRgstClick(jsonData) {
        //     // this.gridObj.gridView.commit()
        //     this.parentData = jsonData
        //     this.parentData.chkNewYn = 'Y'
        //     this.showRgstPopup = true
        // },
        onRgstClick() {
            // this.gridObj.gridView.commit()
            console.log('111111111', this.div_search.orgNm) //메뉴정보
            this.parentData.orgCd = this.div_search.orgCd
            this.parentData.orgNm = this.div_search.orgNm
            this.parentData.chkNewYn = 'Y'
            this.showRgstPopup = true
        },
        onUpdateClick(jsonData) {
            // this.gridObj.gridView.commit()
            this.parentData = jsonData
            this.parentData.chkNewYn = 'N'
            this.showRgstPopup = true
        },
    },
}
</script>
