import { ValueType } from 'realgrid'

export const M_HEADER = {
    fields: [
        {
            fieldName: 'pagingSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ymdWrite',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'no',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fgFinal',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fgIo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'fgPc',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ynTurn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'ynIss',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cmpTaxSt',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'newOrgId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'errMsg',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sell',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'buy',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'pagingSeq',
            fieldName: 'pagingSeq',
            header: {
                text: 'No.',
            },
            width: '40',
        },
        {
            name: 'ymdWrite',
            fieldName: 'ymdWrite',
            type: 'data',
            width: '120',
            header: {
                text: '세금계산서일자',
            },
        },
        {
            name: 'no',
            fieldName: 'no',
            type: 'data',
            width: '80',
            header: {
                text: '요청번호',
            },
        },
        {
            name: 'fgFinal',
            fieldName: 'fgFinal',
            type: 'data',
            width: '80',
            header: {
                text: '상태코드',
            },
        },
        {
            name: 'fgIo',
            fieldName: 'fgIo',
            type: 'data',
            width: '80',
            header: {
                text: '거래구분',
            },
        },
        {
            name: 'fgPc',
            fieldName: 'fgPc',
            type: 'data',
            width: '80',
            header: {
                text: '기업구분',
            },
        },
        {
            name: 'ynTurn',
            fieldName: 'ynTurn',
            type: 'data',
            width: '80',
            header: {
                text: '발행구분',
            },
        },
        {
            name: 'ynIss',
            fieldName: 'ynIss',
            type: 'data',
            width: '100',
            header: {
                text: '국세청신고여부',
            },
        },
        {
            name: 'cmpTaxSt',
            fieldName: 'cmpTaxSt',
            type: 'data',
            width: '80',
            header: {
                text: '발송유무',
            },
        },
        {
            name: 'newOrgId',
            fieldName: 'newOrgId',
            type: 'data',
            width: '200',
            header: {
                text: '조직',
            },
        },
        {
            name: 'errMsg',
            fieldName: 'errMsg',
            type: 'data',
            width: '120',
            header: {
                text: '오류메시지',
            },
        },
        {
            name: 'sell',
            fieldName: 'sell',
            type: 'data',
            width: '400',
            header: {
                text: '공급자정보(등록번호/상호/대표자/Email/HP)',
            },
        },
        {
            name: 'buy',
            fieldName: 'buy',
            type: 'data',
            width: '400',
            header: {
                text: '구입자정보(등록번호/상호/대표자/Email/HP)',
            },
        },
    ],
}
