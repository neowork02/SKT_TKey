<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1000px">
        <!--  팝업 사이즈 가로 사이즈 줄일경우 최소 size="800px"정도로만 줄여주세요/ -->
        <template #content>
            <div class="layerPop overflow-y-auto">
                <!-- Popup_tit -->
                <p class="popTitle">템플릿업로드팝업</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- Search_div -->
                    <div class="searchLayer_wrap">
                        <!-- Search_line 1 -->
                        <div class="searchform">
                            <!-- item 1-1 -->
                            <div class="formitem div1">
                                <!-- arrayType -->
                                <div class="arrayType">
                                    <div class="col50">
                                        <TCComComboBox
                                            v-model="uploadInfo.templetCd"
                                            labelName="업로드"
                                            :itemList="templetList"
                                            :eRequired="false"
                                            @change="onUploadGubunChange"
                                        />
                                    </div>
                                    <div class="col0">
                                        <span class="basicTxt"
                                            >( 다운로드위치 : {{ downloadPath }}
                                        </span>
                                        <span class="ml5">
                                            <a
                                                href=""
                                                @click.prevent="
                                                    onSampleFileDownload
                                                "
                                                ><span
                                                    class="ico_filesave small"
                                                >
                                                    샘플다운로드
                                                </span></a
                                            ></span
                                        >)
                                    </div>
                                </div>
                                <!-- //arrayType -->
                            </div>
                            <!-- //item 1-1 -->
                        </div>
                        <!-- //Search_line 1 -->
                        <!-- Search_line 2 -->
                        <div class="searchform">
                            <!-- item 2-1 -->
                            <div class="formitem div1">
                                <TCComInput
                                    v-model="uploadInfo.titleNm"
                                    labelName="제목"
                                ></TCComInput>
                            </div>
                            <!-- //item 2-1 -->
                        </div>
                        <!-- //Search_line 2 -->
                        <!-- Search_line 3 -->
                        <div class="searchform">
                            <!-- item 3-1 -->
                            <div class="formitem div2">
                                <TCComDatePicker
                                    calType="M"
                                    v-model="uploadInfo.calYearMonth"
                                    labelName="정산"
                                ></TCComDatePicker>
                            </div>
                            <!-- //item 3-1 -->
                            <!-- item 3-1 -->
                            <div class="formitem div2">
                                <TCComFileInput
                                    v-model="uploadInfo.files"
                                    labelName="CVS파일"
                                    :accept="accept"
                                ></TCComFileInput>
                            </div>
                            <!-- //item 3-1 -->
                        </div>
                        <!-- //Search_line 3 -->
                    </div>
                    <!-- //Search_div -->
                    <p class="infoTxt">
                        <span class="color-red"
                            >한사람이 당일, 업로드구분, 정산월에 따라 최종 1개의
                            파일만 업로드 가능합니다./</span
                        ><span class="color-red"
                            >문서보안 CSV파일만 가능합니다.
                        </span>
                    </p>

                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02_point"
                            :eLarge="true"
                            @click="onSaveClick"
                            >저장</TCComButton
                        >
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="onCloseClick"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->

                    <!-- Close BTN-->
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="onCloseClick"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { FileUtil, CommonUtil } from '@/utils'
import commonApi from '@/api/common/commonCode'
import attachedFileApi from '@/api/common/attachedFile'
import basAdmInfsFileUploadApi from '@/api/biz/bas/adm/basAdmInfsFileUploadApi'
import CommonMixin from '@/mixins'
import _ from 'lodash'

export default {
    name: 'BasAdmInfsFileUploadPopup',
    components: {},
    mixins: [CommonMixin],
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 데이터
        parentParam: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            uploadInfo: {
                templetCd: '', // 업로드 구분
                calYearMonth: '', // 정산년월
                titleNm: '', // 제목
                files: null, // 파일
            },
            templetList: [],
            downloadPath: '',
            accept: '.csv',
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    created() {
        this.init()
    },
    mounted() {
        this.setBaseData()
    },
    methods: {
        init() {
            this.uploadInfo.templetCd = '1'
            this.downloadPath = '판매관리>판매현황'
            this.uploadInfo.calYearMonth = this.parentParam.calYearMonth
        },

        async setBaseData() {
            this.templetList = await this.getCommCodeList('CIP_TEMPLET_CD')
        },

        // 공통코드 API
        async getCommCodeList(codeId) {
            const res = await commonApi.getCommonCodeListById(codeId)
            console.log('getCommCodeList res: ', res)
            return res
        },

        async onSaveClick() {
            const form = new FormData()
            const files = this.uploadInfo.files
            const templetCd = this.uploadInfo.templetCd
            const calYearMonth = this.uploadInfo.calYearMonth
            const titleNm = this.uploadInfo.titleNm
            console.log('files: ', files)

            const fileType = {
                maxSize: 1024 * 1024 * 15,
                totalMaxSize: 1024 * 1024 * 30,
                mimeTypes: null,
                fileExts: ['csv'],
            }

            if (_.isEmpty(templetCd)) {
                this.showTcComAlert('업로드를 선택해주세요.')
                return
            }

            if (_.isEmpty(titleNm)) {
                this.showTcComAlert('제목을 입력해주세요.')
                return
            }

            if (_.isEmpty(calYearMonth)) {
                this.showTcComAlert('정산월을 입력해주세요.')
                return
            }

            if (!files) {
                this.showTcComAlert('파일이 없습니다. 파일을 선택해주세요.')
                return
            }

            const fileValid = FileUtil.vFileValid([], files, fileType)
            console.log('fileValid: ', fileValid)

            if (fileValid.errCode) {
                this.showTcComAlert(fileValid.warnningMessage)
                return
            }

            const confirm = await this.showTcComConfirm(
                '파일 업로드 하시겠습니까?'
            )

            if (confirm) {
                form.append('files', files)
                form.append('templetCd', templetCd)
                form.append('accYm', CommonUtil.replaceDash(calYearMonth))
                form.append('titleNm', titleNm)
                form.append('agencyCd', this.userInfo.sktAgencyCd)

                basAdmInfsFileUploadApi.processFileUpload(form).then(() => {
                    this.$parent.getFileUploadList()
                    this.onCloseClick()
                })
            }
        },

        onUploadGubunChange(value) {
            if (value === '1') {
                this.downloadPath = '판매관리>판매현황'
            } else if (value === '2') {
                this.downloadPath = '보고서>개통관련보고서>기기상세엑셀다운로드'
            } else {
                this.downloadPath = ''
            }
        },

        onSampleFileDownload() {
            const templetCd = this.uploadInfo.templetCd
            let sampleDocNo = ''
            if (templetCd === '1') {
                sampleDocNo = '503'
            } else if (templetCd === '2') {
                sampleDocNo = '504'
            }
            attachedFileApi.downloadSampleFile(sampleDocNo)
        },

        onCloseClick() {
            this.activeOpen = false
        },
    },
}
</script>
