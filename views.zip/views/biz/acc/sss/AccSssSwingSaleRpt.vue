<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: Swing매출리포트
 * 소스 ID : AccSssSwingSaleRpt
 * 설명: 
 * 작성자: 김성엽
 * 작성일: 2022.07.15
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <div class="content">
        <h1>Swing 매출리포트</h1>
        <ul class="btn_area top">
            <li class="right">
                <TCComButton eClass="btn_ty01" :objAuth="objAuth" @click="init"
                    >초기화</TCComButton
                >
                <TCComButton
                    eClass="btn_ty01"
                    :objAuth="objAuth"
                    @click="onSearch"
                    >조회</TCComButton
                >
            </li>
        </ul>
        <div class="searchLayer_wrap">
            <div class="searchform">
                <div class="formitem div4">
                    <TCComDatePicker
                        labelName="정산월"
                        calType="M"
                        :eRequired="true"
                        v-model="searchFormData.accYm_"
                        @change="changeAccMth"
                    >
                    </TCComDatePicker>
                </div>
            </div>
        </div>
        <div class="gridWrap">
            <TCRealGridHeader
                id="gridHeader"
                ref="gridHeader"
                gridTitle="Swing 매출리포트"
                :isExceldown="true"
                :gridObj="gridObj"
                @excelDownBtn="downloadExcelAll()"
            >
            </TCRealGridHeader>
            <TCRealGrid
                id="grid"
                ref="grid"
                :fields="view.fields"
                :columns="view.columns"
                :styles="gridStyle"
            />
        </div>
    </div>
</template>
<script>
import _ from 'lodash'
// import commonApi from '@/api/common/prototype'
import { CommonGrid, CommonUtil } from '@/utils'
import moment from 'moment'
import swingRptApi from '@/api/biz/acc/sss/AccSssSwingSaleRpt'
import { GRID_HEADER } from '@/const/grid/acc/sss/AccSssSwingSaleRptGrid'
import CommonMixin from '@/mixins'
export default {
    name: 'AccSssSkbCmmsIncenAccMgmt',
    mixins: [CommonMixin],
    data() {
        return {
            //Grid Class init
            view: GRID_HEADER,

            //Grid
            objAuth: {},
            gridData: {},
            gridObj: {},
            gridHeaderObj: {},

            /*그리드 스타일*/
            gridStyle: {
                height: '400px', //그리드 높이 조절
            },

            //요청 파라미터
            searchFormData: {
                accYm: moment(new Date()).format('YYYY-MM'),
                accYm_: moment(new Date()).format('YYYY-MM'),
                searchAccYm: '',
                searchCoClOrgCd: '',
            },

            reqParam: {
                basMth: '', //기준일자
                orgLvl: '', //조직level
                orgCdLvl0: '', //레벨0조직코드
            },
        }
    },
    mounted() {
        this.gridObj = this.$refs.grid
        this.gridHeaderObj = this.$refs.gridHeader
        this.gridObj.setGridState(false, false, false, true)
        this.gridObj.gridView.setFixedOptions({ colCount: 2 })
        this.gridObj.gridView.setColumnLayout(this.view.layout)
        this.gridObj.gridView.displayOptions.selectionStyle = 'rows'

        //  회사구분코드
        this.searchFormData.searchCoClOrgCd = this.orgInfo.orgCdLvl0
    },
    created() {
        this.gridData = this.gridSetData()
    },
    methods: {
        // 초기화
        init: function () {
            this.$refs.grid.setRows([])
            this.searchFormData.accYm_ = moment(new Date()).format('YYYY-MM')
            this.reqParam.basMth = CommonUtil.onlyNumber(
                this.searchFormData.accYm_
            )
        },

        gridSetData: function (rowCnt) {
            return new CommonGrid(0, rowCnt, '', '')
        },

        changeAccMth() {
            this.reqParam.basMth = CommonUtil.onlyNumber(
                this.searchFormData.accYm_
            )
        },

        //================================================
        // 전체 조회 :::: getSwingSaleReport
        //================================================
        onSearch: function () {
            const srchAccYm = this.searchFormData.accYm_
            if (_.isEmpty(srchAccYm)) {
                this.showTcComAlert('정산월을 확인하세요.')
            } else {
                this.searchFormData.searchAccYm = CommonUtil.onlyNumber(
                    this.searchFormData.accYm_
                )

                this.searchForms = { ...this.searchFormData }

                this.getSwingSaleReport()
            }
        },
        async getSwingSaleReport() {
            await swingRptApi
                .getSwingSaleReport(this.searchForms)
                .then((res) => {
                    if (res) {
                        this.confirmList = res
                        this.gridObj.setRows(res.gridList)
                        this.gridObj.setGridIndicator()
                        this.gridData = this.gridSetData()
                        this.searchForms = {}
                    } else {
                        this.showTcComAlert('검색 정보를 불러오시 못했습니다.')
                    }
                })
        },

        //================================================
        // EXCEL DOWNLOAD
        //================================================

        downloadExcelAll: function () {
            swingRptApi.downloadSwingSaleReportExcel(this.searchFormData)
        },
    },
}
</script>
