import { ValueType } from 'realgrid'
import { gridMetaUtil } from '@/utils/accUtil'

const GRID_META = [
    {
        fieldName: 'accStNm',
        header: { text: '정산상태' },
        width: '150',
    },
    {
        fieldName: 'fixYnNm',
        header: { text: '확정상태' },
        width: '150',
    },
    {
        fieldName: 'fixAccYm',
        header: { text: '확정정산월' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMM',
        columnDatetimeFormat: 'yyyy-MM',
    },
    {
        fieldName: 'gnrlSaleNo',
        header: { text: '판매번호' },
        width: '150',
    },
    {
        fieldName: 'accYm',
        header: { text: '최초정산월' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMM',
        columnDatetimeFormat: 'yyyy-MM',
    },
    {
        fieldName: 'saleChgDtm',
        header: { text: '매출일' },
        width: '150',
        dataType: ValueType.DATETIME,
        fieldDatetimeFormat: 'yyyyMMdd',
        columnDatetimeFormat: 'yyyy-MM-dd',
    },
    {
        fieldName: 'accDealcoCd',
        header: { text: '정산처' },
        width: '150',
    },
    {
        fieldName: 'accDealcoNm',
        header: { text: '정산처명' },
        width: '150',
    },
    {
        fieldName: 'saleClNm',
        header: { text: '판매처구분' },
        width: '150',
    },
    {
        fieldName: 'svcMgmtNum',
        header: { text: '서비스관리번호' },
        width: '150',
    },
    {
        fieldName: 'cntrctMgmtNo',
        header: { text: '계약관리번호' },
        width: '150',
    },
    {
        fieldName: 'custNm',
        header: { text: '고객명' },
        width: '150',
    },
    {
        fieldName: 'svcNum',
        header: { text: '개통번호' },
        width: '150',
    },
    {
        fieldName: 'agrmtClNm',
        header: { text: '약정구분' },
        width: '150',
    },
    {
        fieldName: 'saleDtlTypNm',
        header: { text: '판매유형' },
        width: '150',
    },
    {
        fieldName: 'cmmsClCd',
        header: { text: '수수료구분' },
        width: '150',
    },
    {
        fieldName: 'polId',
        header: { text: '정책ID' },
        width: '150',
    },
    {
        fieldName: 'polTs',
        header: { text: '정책차수' },
        width: '150',
    },
    {
        fieldName: 'polNm',
        header: { text: '정책명' },
        width: '150',
    },
    {
        fieldName: 'cmmsAmt',
        header: { text: '환수대상수수료' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'fixAdjtAmt',
        header: { text: '환수확정수수료' },
        width: '150',
        styleName: 'right-column',
        dataType: ValueType.NUMBER,
        numberFormat: '#,###,###,##0',
    },
    {
        fieldName: 'prcplnNms',
        header: { text: '요금제' },
        width: '150',
    },
    {
        fieldName: 'addPrcplnNms',
        header: { text: '부가요금제' },
        width: '150',
    },
    {
        fieldName: 'suplSvcNms',
        header: { text: '부가서비스' },
        width: '150',
    },
    {
        fieldName: 'prodNm',
        header: { text: '모델' },
        width: '150',
        group: 'eqp',
    },
    {
        fieldName: 'eqpColorNm',
        header: { text: '색상' },
        width: '150',
        group: 'eqp',
    },
    {
        fieldName: 'serNum',
        header: { text: '일련번호' },
        width: '150',
        group: 'eqp',
    },
    {
        fieldName: 'eqpDisClCdNm',
        header: { text: '재고구분' },
        width: '150',
        group: 'eqp',
    },
    {
        fieldName: 'eqpSettlCondNm',
        header: { text: '결재조건' },
        width: '150',
        group: 'eqp',
    },
]

const GRID_META_GROUP = {
    eqp: {
        direction: 'horizontal',
        header: { text: '단말기' },
        items: [],
    },
}

const GRID_HEADER = {}
GRID_HEADER.columns = gridMetaUtil.adjustColumns(GRID_META)
GRID_HEADER.fields = gridMetaUtil.adjustFields(GRID_META)
GRID_HEADER.layout = gridMetaUtil.adjustLayout(GRID_META, GRID_META_GROUP)

export { GRID_HEADER }
