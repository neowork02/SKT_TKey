<!-----------------------------------------------
 * 업무그룹명: 바로도착 재고 연동관리
 * 서브업무명: 권역별 제한상품 엑셀업로드
 * 설명: 권역별 제한상품 엑셀업로드한다.
 * 작성자: P179237
 * 작성일: 2022.04.05
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1100px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <p class="popTitle">권역별 제한상품 엑셀업로드</p>
                <div class="layerCont">
                    <div class="stitHead pop">
                        <h4 class="subTit">엑셀입력</h4>
                        <span class="stitBtnRef2">
                            <TCComButton eClass="btn_ty01" @click="init"
                                >초기화</TCComButton
                            >
                            <TCComButton
                                eClass="btn_ty01 "
                                @click="saveBtn"
                                :disabled="saveBtnDisabled"
                                >저장</TCComButton
                            >
                            <!-- <TCComButton eClass="btn_ty01" @click="closeBtn"
                                >닫기</TCComButton
                            > -->
                        </span>
                    </div>
                    <div class="searchLayer_wrap">
                        <div class="searchform">
                            <!-- <div class="formitem div5_1">
                                <TCComDatePicker
                                    labelName="등록일자"
                                    :calType="calType"
                                    :eRequired="true"
                                    v-model="demoOrdDt"
                                    :disabled="true"
                                />
                            </div> -->
                            <div class="formitem div3">
                                <TCComFileInput
                                    labelName="파일선택"
                                    v-model="files"
                                    @change="onFilesChange"
                                ></TCComFileInput>
                            </div>
                            <div class="formitem div3_3">
                                <div class="rightArea btn">
                                    <span class="inner">
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_verification"
                                            @click="errCheck"
                                            labelName="오류검증"
                                        />
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_del"
                                            @click="errClear"
                                            labelName="오류일괄제거"
                                            :disabled="errClearDisabled"
                                        />
                                        <TCComButton
                                            :Vuetify="false"
                                            eClass="btn_s btn_ty03"
                                            eAttr="ico_save"
                                            labelName="양식다운로드"
                                            @click="onExcelDown"
                                        />
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <p class="infoTxt">
                        <span class="color-red"
                            >양식 다운로드 버튼을 클릭하여 받으신 양식으로 입력
                            가능합니다.
                        </span>
                    </p>
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="gridHeader"
                            ref="gridHeader"
                            gridTitle="권역별 제한상품 업로드 목록 ( * 표시된 항목만 업로드 대상입니다. )"
                            :gridObj="gridObj"
                            :isDelRow="true"
                            @chkDelRowBtn="gridchkDelRowBtn"
                        />
                        <TCRealGrid
                            id="gridField"
                            ref="gridField"
                            :fields="gridSet.fields"
                            :columns="gridSet.columns"
                        />
                    </div>
                    <!-- Bottom BTN Group -->
                    <div class="btn_area_bottom">
                        <TCComButton
                            eClass="btn_ty02"
                            :eLarge="true"
                            @click="closeBtn"
                            >닫기</TCComButton
                        >
                    </div>
                    <!-- // Bottom BTN Group -->
                    <!-- Close BTN-->
                    <a href="#none" class="layerClose b-close" @click="closeBtn"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
            </div>
        </template>
    </TCComDialog>
</template>
<script>
import { CommonGrid, FileUtil } from '@/utils'
import { G_HEADER_REGISTER } from '@/const/grid/dis/dsm/disDsmDarrvlDisLnkgMgmtHead'
import api from '@/api/biz/dis/dsm/disDsmDarrvlDisLnkgMgmt'
import CommonMixin from '@/mixins'
import _ from 'lodash'
import * as XLSX from 'xlsx'
import { SacCommon } from '@/views/biz/sac/js'

import attachedFileApi from '@/api/common/attachedFile'

export default {
    name: 'DisDsmDarrvlDisLnkgXlsUpld',
    mixins: [CommonMixin],
    components: {},
    props: {
        dialogShow: { type: Boolean, default: false, required: false },
        // 부모 파라미터 정보
        parentParam: { type: Object, default: () => {}, required: false },
    },
    data() {
        return {
            files: null,
            errChk: false,
            //
            objAuth: {},
            gridData: this.GridSetData(),
            gridObj: {},
            gridHeaderObj: {},
            gridSet: G_HEADER_REGISTER,
            demoInfo: false,
            calType: 'D',
            reqParam: {
                strdDt: '',
                endDt: '',
            },
            demoOrdDt: '',
            // 저장버튼 활성화여부
            saveBtnDisabled: true,
            // 오류일괄제거 활성화여부
            errClearDisabled: true,
        }
    },
    computed: {
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    mounted() {
        this.initParam()
        this.setGrid()
    },
    methods: {
        /* 초기화 */
        init() {
            this.initParam()
            this.setGrid()
            this.files = null
            this.errClearDisabled = true // 오류일괄제거
            this.saveBtnDisabled = true // 저장버튼
        },
        /* 파라미터 초기화 */
        initParam() {
            this.demoOrdDt = SacCommon.getToday()
        },
        /* 그리드 설정 */
        setGrid() {
            this.gridObj = this.$refs.gridField
            this.gridHeaderObj = this.$refs.gridHeader
            // this.gridObj.gridView.setDisplayOptions({
            //     fitStyle: 'even',
            // })
            this.gridObj.setGridState(false, false, true)
            this.gridObj.gridView.setRowIndicator({
                visible: true,
                headText: 'NO',
            })
            this.gridObj.setRows({})
            // this.$refs.gridField.gridView.displayOptions.selectionStyle = 'rows'
        },
        GridSetData() {
            return new CommonGrid(-1, -1, '', '')
        },
        // Check Row Delete Event
        gridchkDelRowBtn: function () {
            this.gridObj.gridView.commit()
            this.gridData = this.gridHeaderObj.chkDelRow(this.gridData)
            this.deleleGridData = this.gridData.delRows
        },
        //양식다운로드
        onExcelDown() {
            attachedFileApi.downloadSampleFile('114')
            // this.gridHeaderObj.exportSampleGrid('바로도착_재고연동관리_.xlsx')
        },
        // 파일업로드
        onFilesChange(files) {
            // 엑셀 업로드 암호화문서 파싱 로직 추가 2023.01.03
            // this.excelUploadFile(files)
            const formData = new FormData()
            formData.append('files', files)
            api.parseXlsEncDoc(formData).then((res) => {
                this.gridObj.setRows(res)
            })

            this.errChk = false
            this.errClearDisabled = true // 오류일괄제거
            this.saveBtnDisabled = true // 저장버튼
        },
        excelUploadFile(files) {
            const f = files
            if (!_.isUndefined(f) && !_.isNull(f)) {
                const reader = new FileReader()
                // const name = f.name

                reader.onload = (e) => {
                    const data = e.target.result

                    // Array Buffer인 경우 base64로 변환 처리
                    const arr = FileUtil.arrayBufferFixdata(data)
                    const workbook = XLSX.read(FileUtil.encodeBase64(arr), {
                        type: 'base64',
                        cellText: true,
                        cellDates: true,
                    })
                    // 워크북 처리(1줄 헤더 포함 처리)
                    this.processWorkbook(workbook)
                }
                // binary
                // reader.readAsBinaryString(f)
                // Array Buffer
                reader.readAsArrayBuffer(f)
            }
        },
        // 워크북 처리(1줄 헤더 포함 처리)
        processWorkbook(wb) {
            const output = FileUtil.excelTojson(wb, {
                raw: false,
            })
            const sheetNames = Object.keys(output)
            if (sheetNames.length) {
                const colsObj = output[sheetNames][0]
                if (colsObj) {
                    const data = output[sheetNames]
                    if (data.length > 3000) {
                        this.showTcComAlert(
                            '1회당 업로드 데이터는 3000건까지 가능합니다.'
                        )
                        return
                    }
                    const mappedData = data.map((item) => {
                        return {
                            no: item['번호'],
                            rgnCd: item['권역코드'],
                            rgnNm: item['권역명'],
                            prodCd: item['상품코드'],
                            prodNm: item['상품명'],
                            errDesc: item['오류사항'],
                        }
                    })
                    this.gridObj.dataProvider.fillJsonData(mappedData, {})
                }
            } else {
                this.showTcComAlert(
                    '업로드 문서에 처리 할 데이터가 없습니다.\n업로드 문서를 확인하시기 바랍니다.'
                )
            }
        },
        //오류검증
        errCheck() {
            const rowData = this.gridObj.dataProvider.getOutputRows(
                { datetimeFormat: 'yyyyMMdd' },
                0,
                -1
            )
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
                return
            }
            if (rowData.length > 3000) {
                this.showTcComAlert(
                    '1회당 업로드 데이터는 3000건까지 가능합니다.'
                )
                return
            }

            console.log('오류검증데이터 ==============>> ', rowData)
            api.chkRgnRstProdXlsErrChk(rowData).then((res) => {
                this.gridObj.setRows(res)
                this.errChk = true
                this.errClearDisabled = false // 오류일괄제거 버튼 활성화
                this.saveBtnDisabled = false // 저장버튼 활성화
            })
        },
        //오류일괄변경
        errClear() {
            this.gridObj.gridView.commit()
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
                return
            }
            if (_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('처리할 데이터가 없습니다.')
            } else {
                this.gridObj.dataProvider.removeRows(this.getErrRow())
                this.gridObj.gridView.commit()
            }
        },
        //저장
        saveBtn() {
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            if (_.isEmpty(rowData)) {
                this.showTcComAlert('저장할 데이터가 없습니다.')
                return
            }
            if (!this.errChk) {
                this.showTcComAlert('오류검증을 하시기 바랍니다.')
                return
            }
            if (!_.isEmpty(this.getErrRow())) {
                this.showTcComAlert('오류제거를 하시기 바랍니다.')
                return
            }
            this.showTcComConfirm('저장하시겠습니까?').then((confirm) => {
                if (confirm) {
                    api.addRgnRstProdXlsUpld(rowData).then(() => {
                        this.$emit('confirm', true)
                        this.activeOpen = false
                    })
                }
            })
        },
        //오류ROW 조회
        getErrRow() {
            let errRow = []
            const rowData = this.gridObj.dataProvider.getJsonRows(0, -1)
            rowData.forEach((data, i) => {
                if (!_.isEmpty(_.get(data, 'errDesc'))) {
                    errRow.push(i)
                }
            })
            return errRow
        },
        closeBtn: function () {
            this.activeOpen = false
        },
    },
}
</script>
