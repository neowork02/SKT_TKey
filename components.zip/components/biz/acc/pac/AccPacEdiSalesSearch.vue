<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccPacEdiAccMgmt.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <AccSearchField
        ref="accSearchField"
        :offset="[
            'btn-right-reset',
            'btn-right-view',
            'btn-right-save',
            { slotSearch: 'selectedMenu' },
            'search-baseMth',
            'search-orgCd',
            '!search-payTypCd',
            '!search-saleMgmtNo',
            '!search-aprvNum',
        ]"
        :initValue="initValue"
        :popupParamOrgCd="popupParamOrgCd"
        @view="viewForm"
        @save="saveForm"
        @reset="resetForm"
        @changeBaseMth="changeBaseMth"
    >
        <template slot="selectedMenu" slot-scope="slotProps">
            <div class="formitem" :class="`div${slotProps.divideCellCount}`">
                <TCComComboBox
                    itemText="label"
                    itemValue="value"
                    :itemList="tabList"
                    labelName="조회구분"
                    v-model="activeTabIdx"
                ></TCComComboBox>
            </div>
        </template>
    </AccSearchField>
</template>
<script>
import CommonMixin from '@/mixins'
import accMixin from '@/mixins/accMixin'

import { getTodayDate } from '@/utils/accUtil'

import AccSearchField from '@/components/biz/common/acc/AccSearchField'

export default {
    name: 'AccPacEdiSalesSearch',
    mixins: [CommonMixin, accMixin],
    components: { AccSearchField },
    props: {
        curTabIdx: {
            default: 0,
        },

        tabInfo: {
            default: () => ({}),
        },
    },
    data() {
        return {
            initValue: {
                baseMth: getTodayDate('YYYY-MM'),
                payTypCd: '0',
                dataClCd: '1',
                pageSize: 15,
                pageNum: 1,
            },

            tabList: [],
            popupParamOrgCd: {
                basMth: '',
            },
        }
    },

    computed: {
        activeTabIdx: {
            get() {
                return this.curTabIdx
            },

            set(v) {
                this.$emit('update:curTabIdx', v)
            },
        },
    },

    created() {
        this.initPage()
    },
    methods: {
        initPage() {
            this.tabList = this.tabInfo.label.map((arr, idx) => ({
                value: idx,
                label: arr,
            }))
        },

        resetForm(query) {
            this.$emit('reset', query)
        },

        viewForm(query) {
            if (!query.orgCd) {
                return this.showTcComAlert('조직을 선택해 주세요.')
            }

            this.$emit('view', query)
        },

        saveForm() {
            this.$emit('save')
        },

        changeBaseMth(date) {
            this.popupParamOrgCd.basMth = date
        },

        getQuery() {
            return this.accSearchField.getQuery()
        },

        setQuery(query) {
            this.accSearchField.setQuery(query)
        },
    },
}
</script>
