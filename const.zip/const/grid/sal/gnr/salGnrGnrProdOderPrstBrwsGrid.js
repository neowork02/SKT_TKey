/*****************************************
 * 업무그룹명: 판매관리
 * 서브업무명: 소매매출
 * 설명: 판매관리-소매매출-일반상품판매현황(SALGNR00100) 그리드 헤더
 * 작성자: p179234
 * 작성일: 2022.08.23.
 * Copyright ⓒ SK TELECOM. All Right Reserved
 *****************************************/
import { ValueType } from 'realgrid'

export const GRID_HEADER1 = {
    fields: [
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT, //조직트리
        },
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT, // 매장코드
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'salePlcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inPlcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchTypCdInfo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'cnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'saleUprc',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'profitAmt',
            dataType: ValueType.NUMBER,
        },
    ],
    columns: [
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
        },
        {
            name: 'bizChrgOrgCd',
            fieldName: 'bizChrgOrgCd',
            type: 'data',
            styleName: 'center-column',
            header: '사업담당',
            visible: false,
        },
        {
            name: 'teamOrgCd',
            fieldName: 'teamOrgCd',
            type: 'data',
            styleName: 'center-column',
            header: '사업팀',
            visible: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styleName: 'center-column',
            header: '매출조직',
            visible: false,
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styleName: 'center-column',
            header: '매장코드',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styleName: 'center-column',
            header: '대리점',
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styleName: 'center-column',
            header: '대리점',
            visible: false,
        },
        {
            name: 'sktSubNm',
            fieldName: 'sktSubNm',
            type: 'data',
            styleName: 'center-column',
            header: '서브점명',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styleName: 'center-column',
            header: '서브점',
            visible: false,
        },
        {
            name: 'salePlcNm',
            fieldName: 'salePlcNm',
            type: 'data',
            styleName: 'center-column',
            header: '판매처',
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            styleName: 'center-column',
            header: '판매처코드',
        },
        {
            name: 'saleTypNm',
            fieldName: 'saleTypNm',
            type: 'data',
            styleName: 'center-column',
            header: '판매유형',
        },
        {
            name: 'saleTypCd',
            fieldName: 'saleTypCd',
            type: 'data',
            styleName: 'center-column',
            header: '판매유형',
            visible: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styleName: 'left-column',
            header: '모델',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styleName: 'left-column',
            header: '색상',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styleName: 'center-column',
            header: '색상',
            visible: false,
        },
        {
            name: 'inPlcNm',
            fieldName: 'inPlcNm',
            type: 'data',
            styleName: 'left-column',
            header: '매입처',
        },
        {
            name: 'prchTypCdInfo',
            fieldName: 'prchTypCdInfo',
            type: 'data',
            styleName: 'center-column',
            header: '거래유형',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styleName: 'left-column',
            header: '제조사',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styleName: 'left-column',
            header: '상품구분',
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            styleName: 'center-column',
            header: '상품구분',
            visible: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styleName: 'center-column',
            header: '상품코드',
        },
        {
            name: 'cnt',
            fieldName: 'cnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            header: {
                text: '수량',
                showTooltip: true,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'saleUprc',
            fieldName: 'saleUprc',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            header: {
                text: '판매단가',
                showTooltip: true,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'profitAmt',
            fieldName: 'profitAmt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            header: {
                text: '판매수익',
                showTooltip: true,
            },
            numberFormat: '#,##0',
        },
    ],
}

export const GRID_HEADER2 = {
    fields: [
        {
            fieldName: 'saleChgDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'treeOrgNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'bizChrgOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'teamOrgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'orgCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'agencyCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'sktSubCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'salePlcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleDealcoCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleTypCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleTypNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'serNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'twdOrdNum',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'inPlcNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prchTypCdInfo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'mfactNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleUprc',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'profitAmt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'cnt',
            dataType: ValueType.NUMBER,
        },
        {
            fieldName: 'insUserId',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insUserNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'insDtm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'saleStNm',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'saleChgDtm',
            fieldName: 'saleChgDtm',
            type: 'data',
            styleName: 'center-column',
            header: '매출일',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
        {
            name: 'treeOrgNm',
            fieldName: 'treeOrgNm',
            type: 'data',
            width: '350',
            styleName: 'left-column',
            header: '조직',
        },
        {
            name: 'bizChrgOrgCd',
            fieldName: 'bizChrgOrgCd',
            type: 'data',
            styleName: 'center-column',
            header: '사업담당',
            visible: false,
        },
        {
            name: 'teamOrgCd',
            fieldName: 'teamOrgCd',
            type: 'data',
            styleName: 'center-column',
            header: '사업팀',
            visible: false,
        },
        {
            name: 'orgCd',
            fieldName: 'orgCd',
            type: 'data',
            styleName: 'center-column',
            header: '매출조직',
            visible: false,
        },
        {
            name: 'sktCd',
            fieldName: 'sktCd',
            type: 'data',
            styleName: 'center-column',
            header: '매장코드',
        },
        {
            name: 'agencyNm',
            fieldName: 'agencyNm',
            type: 'data',
            styleName: 'center-column',
            header: '대리점',
        },
        {
            name: 'agencyCd',
            fieldName: 'agencyCd',
            type: 'data',
            styleName: 'center-column',
            header: '대리점',
            visible: false,
        },
        {
            name: 'sktSubNm',
            fieldName: 'sktSubNm',
            type: 'data',
            styleName: 'left-column',
            header: '서브점명',
        },
        {
            name: 'sktSubCd',
            fieldName: 'sktSubCd',
            type: 'data',
            styleName: 'center-column',
            header: '서브점',
            visible: false,
        },
        {
            name: 'salePlcNm',
            fieldName: 'salePlcNm',
            type: 'data',
            styleName: 'center-column',
            header: '판매처',
        },
        {
            name: 'saleDealcoCd',
            fieldName: 'saleDealcoCd',
            type: 'data',
            styleName: 'center-column',
            header: '판매처코드',
        },
        {
            name: 'saleTypNm',
            fieldName: 'saleTypNm',
            type: 'data',
            styleName: 'center-column',
            header: '판매유형',
        },
        {
            name: 'saleTypCd',
            fieldName: 'saleTypCd',
            type: 'data',
            styleName: 'center-column',
            header: '판매유형',
            visible: false,
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            styleName: 'left-column',
            header: '모델',
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styleName: 'center-column',
            header: '색상',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            type: 'data',
            styleName: 'center-column',
            header: '색상',
            visible: false,
        },
        {
            name: 'serNum',
            fieldName: 'serNum',
            type: 'data',
            styleName: 'center-column',
            header: '일련번호',
        },
        {
            name: 'twdOrdNum',
            fieldName: 'twdOrdNum',
            type: 'data',
            styleName: 'center-column',
            header: '주문번호',
        },
        {
            name: 'inPlcNm',
            fieldName: 'inPlcNm',
            type: 'data',
            styleName: 'center-column',
            header: '매입처',
        },
        {
            name: 'prchTypCdInfo',
            fieldName: 'prchTypCdInfo',
            type: 'data',
            styleName: 'center-column',
            header: '거래유형',
        },
        {
            name: 'mfactNm',
            fieldName: 'mfactNm',
            type: 'data',
            styleName: 'left-column',
            header: '제조사',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            styleName: 'center-column',
            header: '상품구분',
        },
        {
            name: 'prodClCd',
            fieldName: 'prodClCd',
            type: 'data',
            styleName: 'center-column',
            header: '상품구분',
            visible: false,
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            styleName: 'center-column',
            header: '상품코드',
        },
        {
            name: 'saleUprc',
            fieldName: 'saleUprc',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            header: {
                text: '판매단가',
                showTooltip: true,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'profitAmt',
            fieldName: 'profitAmt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            header: {
                text: '판매수익',
                showTooltip: true,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'cnt',
            fieldName: 'cnt',
            type: 'data',
            width: '80',
            styleName: 'right-column',
            header: {
                text: '수량',
                showTooltip: true,
            },
            numberFormat: '#,##0',
        },
        {
            name: 'saleStNm',
            fieldName: 'saleStNm',
            type: 'data',
            styleName: 'center-column',
            header: '판매상태',
        },
        {
            name: 'insUserId',
            fieldName: 'insUserId',
            type: 'data',
            styleName: 'center-column',
            header: '처리자ID',
        },
        {
            name: 'insUserNm',
            fieldName: 'insUserNm',
            type: 'data',
            styleName: 'center-column',
            header: '처리자명',
        },
        {
            name: 'insDtm',
            fieldName: 'insDtm',
            type: 'data',
            styleName: 'center-column',
            header: '처리일시',
            textFormat: '([0-9]{4})([0-9]{2})([0-9]{2})$;$1-$2-$3',
        },
    ],
}
