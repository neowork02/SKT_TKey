/**************************************************************************************************************
 * API정의 영역
 **************************************************************************************************************/
import restApi from '@/api/biz/sal/sel/salSelSaleMgmtApi.js'
import salCommonApi from '@/api/biz/sal/common/salCommonApi'

export default {
    //판매필요재고정보취득 조회
    async getSaleDisInfo_({ commit }, payload) {
        console.log('actions:getSaleDisInfo_:::', payload)
        let resultData
        await restApi
            .getSaleDisInfo(payload)
            .then((res) => {
                console.log('getSaleDisInfo_ === res', JSON.stringify(res))
                commit('setDisInfo', res.disInfo) //ds_getDisInfo
                resultData = res
            })
            .catch((error) => {
                throw error
            })
        return resultData
    },
    //USIM후불취소
    async getUsimPayChgIfInfo_({ commit }, payload) {
        console.log('actions:getUsimPayChgIfInfo_:::', payload)
        let resultData
        await restApi
            .getUsimPayChgIfInfo(payload)
            .then((res) => {
                console.log('getUsimPayChgIfInfo === res', JSON.stringify(res))
                commit('setUsimPayChgIfInfo', res) //ds_usimPayChgIfInfo
                resultData = res
            })
            .catch((error) => {
                throw error
            })
        return resultData
    },
    //약정변경IF정보
    async getDsNetChgIfInfo_({ commit }, payload) {
        console.log('actions:getDsNetChgIfInfo_:::', payload)
        let resultData
        await restApi
            .getDsNetChgIfInfo(payload)
            .then((res) => {
                console.log('getDsNetChgIfInfo === res', JSON.stringify(res))
                commit('setDsNetChgIfInfo', res.dsNetChgIfInfo) //ds_dsNetChgIfInfo
                commit('setEqpCashAmt', res.eqpCashAmt) //ds_EqpCashAmt
                resultData = res
            })
            .catch((error) => {
                throw error
            })
        return resultData
    },
    //채널변경IF정보
    async getChannelChgIfInfo_({ commit }, payload) {
        console.log('actions:getChannelChgIfInfo_:::', payload)
        let resultData
        await restApi
            .getChannelChgIfInfo(payload)
            .then((res) => {
                console.log('getChannelChgIfInfo_ === res', JSON.stringify(res))
                commit('setChannelChgIfInfo', res) //ds_channelChgIfInfo

                resultData = res
            })
            .catch((error) => {
                throw error
            })
        return resultData
    },
    //판매변경 상세정보 조회
    async getSaleChgDtl_({ commit }, payload) {
        console.log('actions:getSaleChgDtl_:::', payload)
        let resultData
        await restApi
            .getSaleChgDtl(payload)
            .then((res) => {
                //console.log('getSaleChgDtl_ === res', JSON.stringify(res))
                commit('setGeneralSaleInfo', res.generalSaleInfo) //ds_generalSale
                commit('setGeneralSaleDtlInfo', res.generalSaleDtlInfo) //ds_generalSaleDtl
                commit('setEquipmentSaleInfo', res.equipmentSaleInfo) //ds_equipmentSale
                commit('setSuplServiceInfo', res.suplServiceInfo) //ds_suplservice
                commit('setOldRtnEquipmentInfo', res.oldRtnEquipmentInfo) //ds_oldrtnEquipment
                commit('setAllotSaleInfo', res.allotSaleInfo) //ds_allotSale
                commit('setSktPrprcInfo', res.sktPrprcInfo) //ds_sktPrprc
                commit('setOcbMcardInfo', res.ocbMcardInfo) //ds_ocbMcard
                commit('setCashSaleInfo', res.cashSaleInfo) //ds_cashSale
                commit('setSaleCmmsInfo', res.saleCmmsInfo) //ds_saleCmms
                commit('setProdExchangeInfo', res.prodExchangeInfo) //ds_prodExchange
                commit('setPromotionMoneyInfo', res.promotionMoneyInfo) //ds_promotionMoney
                commit('setBundleInfo', res.bundleInfo) //ds_bundle
                commit('setPremiumRentInfo', res.premiumRentInfo) //ds_p_rent
                resultData = res
            })
            .catch((error) => {
                throw error
            })
        return resultData
    },
    //판매변경IF정보 취득
    async getGeneralSaleIfInfo_({ commit }, payload) {
        console.log('actions:getGeneralSaleIfInfo:::', payload)
        let resultData
        await restApi
            .getGeneralSaleIfInfo(payload)
            .then((res) => {
                //console.log('getGeneralSaleIfInfo === res', JSON.stringify(res))
                commit('setGeneralSaleIfInfo', res.generalSaleIfInfo[0]) //ds_generalSaleIfInfo
                commit('setEqpCashAmt', res.eqpCashAmt) //ds_EqpCashAmt
                resultData = res
            })
            .catch((error) => {
                throw error
            })
        return resultData
    },
    //자동판매 처리중 체크 API
    async getUkeyInfoYn_({ commit }, payload) {
        await restApi.getUkeyInfoYn(payload).then((res) => {
            console.log('getUkeyInfoYn === res', JSON.stringify(res))
            commit('setUkeyInfoYn', res.ukeyInfoYn)
        })
    },
    //일반판매 인터페이스 정보 조회
    async getUkeyIfInfoN_({ commit }, payload) {
        console.log('actions:getUkeyIfInfoN_:::', payload)
        let resultData
        await restApi
            .getUkeyIfInfoN(payload)
            .then((res) => {
                commit('setUkeyInfo', res.ukeyInfo) //신규판매전문
                commit('setSuplIfList', res.suplIfList) //부가서비스전문
                commit('setGear', res.gear) //Gear
                commit('setEqpInfo', res.eqpInfo) //판매필요재고정보취득
                commit('setEqpCashAmt', res.eqpCashAmt) //운영모델단가_확정여신가
                commit('setUsimInfo', res.usimInfo) //usimInfo
                commit('setGearInfo', res.gearInfo) //gearInfo
                resultData = res
            })
            .catch((error) => {
                throw error
            })
        return resultData
    },
    async getComCombo_({ commit }, payload) {
        await salCommonApi.getComCombo(payload).then((res) => {
            commit('setComCombo', res)
        })
    },
    // 판매공통콤보리스트조회 API
    async getSalCommonComboList_({ commit }, payload) {
        await salCommonApi.getSalCommonComboList(payload).then((res) => {
            commit('setSalCommonComboList', res)
        })
    },
}
