<!-----------------------------------------------
 * 업무그룹명: 재고관리>재고이동
 * 서브업무명: 재고이동현황 상세[DISDSM00500, DISDSM00600]
 * 설명: 재고이동현황 상세를 조회한다.
 * 작성자: P179229
 * 작성일: 2022.06.13
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <TCComDialog :dialogShow.sync="activeOpen" size="1200px">
        <template #content>
            <div class="layerPop overflow-y-auto long">
                <!-- Popup_tit -->
                <p class="popTitle">재고이동현황 상세</p>
                <!--// Popup_tit -->
                <!-- Popup_Cont -->
                <div class="layerCont">
                    <!-- gridWrap -->
                    <div class="gridWrap">
                        <TCRealGridHeader
                            id="popupGridHeader"
                            ref="popupGridHeader"
                            gridTitle="재고이동현황 상세"
                            :gridObj="gridObj"
                            :isExceldown="true"
                            @excelDownBtn="onClickDownload"
                        />
                        <TCRealGrid
                            id="popupGrid"
                            ref="popupGrid"
                            :fields="view.fields"
                            :columns="view.columns"
                        />
                    </div>
                    <!-- //gridWrap -->
                    <!-- Close BTN-->
                    <div class="btn_area_bottom">
                        <TCComButton
                            :eLarge="true"
                            eClass="btn_ty02_point"
                            :objAuth="objAuth"
                            @click="closeBtn"
                        >
                            닫기
                        </TCComButton>
                    </div>
                    <a
                        href="#none"
                        class="layerClose b-close"
                        @click="closeBtn()"
                        >닫기</a
                    >
                    <!--//Close BTN-->
                </div>
                <!-- //Popup_Cont -->
            </div>
        </template>
    </TCComDialog>
</template>

<script>
import { CommonGrid } from '@/utils'
import { DisDtrDisMovPrstDtlGRID_HEADER } from '@/const/grid/dis/dtr/disDtrDisMovPrstDtlPopupHeader'
import disDtrDisMovPrstApi from '@/api/biz/dis/dtr/disDtrMovPrst'
import attachedFileApi from '@/api/common/attachedFile'

export default {
    name: 'DisDtrDisMovPrstDtlPopup',
    components: {},
    props: {
        //팝업오픈 여부
        dialogShow: { type: Boolean, default: false, required: false },
        dtlData: {
            type: Object,
            default: () => {
                return {}
            },
            required: false,
        },
    },
    data() {
        return {
            //Paging Class init
            gridData: {},
            objAuth: {},
            view: DisDtrDisMovPrstDtlGRID_HEADER,
            gridObj: {},
            gridHeaderObj: {},
            reqParam: this.dtlData,
        }
    },
    created() {
        // 화면 default설정
        this.defaultSet()
    },
    mounted() {
        /****************** Grid **********************/
        this.gridObj = this.$refs.popupGrid
        this.gridHeaderObj = this.$refs.popupGridHeader
        this.gridObj.setGridState(false, false, false, true)
        this.gridObj.gridView.setRowIndicator({ visible: true })
        this.gridObj.gridView.setDisplayOptions({
            fitStyle: 'even',
        })
        //상세조회
        this.searchDtl()
    },
    computed: {
        dateFormatted() {
            return ''
        },
        activeOpen: {
            get() {
                return this.dialogShow
            },
            set(value) {
                this.$emit('update:dialogShow', value)
            },
        },
    },
    methods: {
        defaultSet() {
            this.gridData = this.gridSetData()
        },
        //gridSetData
        gridSetData: function () {
            //CommonGrid(총 페이지,  Grid Row수(하나페이지에 표시할 행의 개수), 변경된 행데이터, 삭제된 행데이터),
            return new CommonGrid(-1, 10, '', '')
        },
        closeBtn: function () {
            this.activeOpen = false
        },
        //상세 조회
        searchDtl: function () {
            disDtrDisMovPrstApi
                .getDisDtrDisMovPrstDtl(this.reqParam)
                .then((res) => {
                    //Get Row Data
                    console.log(JSON.stringify(res))
                    this.gridObj.setRows(res.gridList)
                })
        },
        //엑셀다운로드
        onClickDownload() {
            const rowCount = this.gridObj.dataProvider.getRowCount()

            if (rowCount == 0) {
                this.showTcComAlert('엑셀다운로드 대상이 존재하지 않습니다.')
                return
            }
            attachedFileApi.downLoadFile(
                '/api/v1/backend-long/resource/dis/dtr/disDtrDisMovPrstDtlExcelList',
                this.reqParam
            )
        },
    },
}
</script>
