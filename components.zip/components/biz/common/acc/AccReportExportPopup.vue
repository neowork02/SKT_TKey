<!-----------------------------------------------
 * 업무그룹명: 정산
 * 서브업무명: 
 * 소스 ID : AccReportExportPopup.vue
 * 설명: 
 * 작성자: 이희원
 * 작성일: 2022.05.16
 * Copyright ⓒSN TECHNOLOGY. All Right Reserved
------------------------------------------------>
<template>
    <RealReportPopup
        ref="AccReportExportPopup"
        v-if="statusShow"
        :parentParam="{
            report: { page: reportMeta.page },
            data: data,
        }"
        :dialogShow.sync="statusShow"
    />
</template>
<style lang="scss" scoped></style>
<script>
import CommonMixin from '@/mixins'
import RealReportPopup from '@/components/common/RealReportPopup'

export default {
    name: 'AccReportExportPopup',
    mixins: [CommonMixin],
    components: { RealReportPopup },
    props: {
        status: {
            default: false,
        },

        reportMeta: {
            default: () => ({}),
        },

        data: {
            default: () => [],
        },
    },
    computed: {
        statusShow: {
            get() {
                return this.status
            },
            set(value) {
                this.$emit('update:status', value)
            },
        },
    },
    watch: {},
    data() {
        return {}
    },
    created() {},
    mounted() {},
    methods: {},
}
</script>
