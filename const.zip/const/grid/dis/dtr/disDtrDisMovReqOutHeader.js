import { ValueType } from 'realgrid'

export const DisDtrDisMovReqOutGRID_HEADER = {
    fields: [
        {
            fieldName: 'reqDt',
            dataType: 'datetime',
            datetimeFormat: 'yyyyMMdd',
        },
        {
            fieldName: 'prodClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'eqpClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'prodNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'petNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqClNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'repProdYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorUnrelYn',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnReqQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnFixQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'disQty',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnStNm',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'reqMgmtNo',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnSeq',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'colorCd',
            dataType: ValueType.TEXT,
        },
        {
            fieldName: 'asgnStCd',
            dataType: ValueType.TEXT,
        },
    ],
    columns: [
        {
            name: 'reqDt',
            fieldName: 'reqDt',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청일자',
                showTooltip: false,
            },
            datetimeFormat: 'yyyy-MM-dd',
            editor: {
                datetimeFormat: 'yyyy-MM-dd',
            },
            width: '100',
        },
        {
            name: 'prodClNm',
            fieldName: 'prodClNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품구분',
                showTooltip: false,
            },
        },
        {
            name: 'eqpClNm',
            fieldName: 'eqpClNm',
            type: 'data',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '단말기구분',
                showTooltip: false,
            },
        },
        {
            name: 'prodCd',
            fieldName: 'prodCd',
            type: 'data',
            width: '150',
            editable: false,
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '상품코드',
                showTooltip: false,
            },
        },
        {
            name: 'prodNm',
            fieldName: 'prodNm',
            type: 'data',
            width: '200',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '모델',
                showTooltip: false,
            },
        },
        {
            name: 'petNm',
            fieldName: 'petNm',
            type: 'data',
            width: '150',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '펫네임',
                showTooltip: false,
            },
        },
        {
            name: 'colorNm',
            fieldName: 'colorNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상',
                showTooltip: false,
            },
        },
        {
            name: 'reqClNm',
            fieldName: 'reqClNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            width: '130',
            header: {
                text: '개봉상태',
                showTooltip: false,
            },
        },
        {
            name: 'repProdYn',
            fieldName: 'repProdYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '대표모델',
                showTooltip: false,
            },
        },
        {
            name: 'colorUnrelYn',
            fieldName: 'colorUnrelYn',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '색상무관',
                showTooltip: false,
            },
        },
        {
            name: 'asgnReqQty',
            fieldName: 'asgnReqQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '요청수량',
                showTooltip: false,
            },
        },
        {
            name: 'asgnFixQty',
            fieldName: 'asgnFixQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '확정수량',
                showTooltip: false,
            },
        },
        {
            name: 'disQty',
            fieldName: 'disQty',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '현재고',
                showTooltip: false,
            },
        },
        {
            name: 'asgnStNm',
            fieldName: 'asgnStNm',
            type: 'data',
            styles: {
                textAlignment: 'center',
            },
            header: {
                text: '진행상태',
                showTooltip: false,
            },
        },
        {
            name: 'reqMgmtNo',
            fieldName: 'reqMgmtNo',
            visible: false,
            type: 'data',
        },
        {
            name: 'asgnSeq',
            fieldName: 'asgnSeq',
            visible: false,
            type: 'data',
        },
        {
            name: 'colorCd',
            fieldName: 'colorCd',
            visible: false,
            type: 'data',
        },
        {
            name: 'asgnStCd',
            fieldName: 'asgnStCd',
            visible: false,
            type: 'data',
        },
    ],
}
